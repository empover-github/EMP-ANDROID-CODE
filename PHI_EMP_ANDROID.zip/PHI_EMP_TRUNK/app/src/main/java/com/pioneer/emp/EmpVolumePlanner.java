package com.pioneer.emp;

import android.app.Activity;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.pioneer.parivaar.dao.VolumePlannerDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.CurrentYearModel;
import com.pioneer.parivaar.model.VolumePlannerModel;
//import com.phi.parivaar.utils.MPUtil;
import com.pioneer.parivaar.utils.MPUtilEmpVolPlan;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import static com.pioneer.parivaar.utils.MPUtilEmpVolPlan.plannedYear;

public class EmpVolumePlanner extends AppCompatActivity implements View.OnClickListener {

    private EditText edtRice, edtMillet, edtCorn, edtMustard, edtTotal;
    private Button plan, reset;
    private TextView membershipTierTV, volumeTV, bonusPointsTV, basePointsTV, totalPointsTV, infoTV;
    private String st_rice, st_millet, st_corn, st_mustard, st_total;
    private BarChart chart;
    //    private List<DTO> list;
    ArrayList<VolumePlannerModel> list = new ArrayList<>();
    private int bassPts;
    private int bonusPts;
    private LinearLayout bottomLL/*, setTargetLL*/;
    private LinearLayout xLables;
    // private String membershipTierFromCuurentYearModel;
    ArrayList<CurrentYearModel> listYear = new ArrayList<>();
    String all_years = "0";
    private Toolbar toolbar;


    // Add text watcher
    TextWatcher watcher = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void afterTextChanged(Editable editable) {
            long total = 0;

            st_rice = edtRice.getText().toString();
            st_millet = edtMillet.getText().toString();
            st_corn = edtCorn.getText().toString();
            st_mustard = edtMustard.getText().toString();

            if (!st_rice.isEmpty())
                total += Long.valueOf(st_rice);
            if (!st_millet.isEmpty())
                total += Long.valueOf(st_millet);
            if (!st_corn.isEmpty())
                total += Long.valueOf(st_corn);
            if (!st_mustard.isEmpty())
                total += Long.valueOf(st_mustard);

            edtTotal.setText(String.valueOf(total));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_volume_planner);

        toolbar = findViewById(R.id.emp_volumePlanner_toolbar);
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setTitle(getResources().getString(R.string.volume_planner));
        toolbar.setNavigationIcon(R.mipmap.back_btn);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        // Bind components
        edtRice = findViewById(R.id.vp_rice_et);
        edtMillet = findViewById(R.id.vp_millet_et);
        edtCorn = findViewById(R.id.vp_corn_et);
        edtMustard = findViewById(R.id.vp_mustard_et);
        edtTotal = findViewById(R.id.vp_total_et);

        plan = findViewById(R.id.vp_plan_btn);
        reset = findViewById(R.id.vp_btn_reset);

        bottomLL = findViewById(R.id.bottom_contents_ll);
        xLables = findViewById(R.id.vp_xAxisLables_LL);
        chart = findViewById(R.id.chart);
        membershipTierTV = findViewById(R.id.vp_membership_tier_tv);
        //  targetRBMTV = (TextView)findViewById(R.id.vp_targetRbm_tv);
        volumeTV = findViewById(R.id.vp_volume_tv);
        bonusPointsTV = findViewById(R.id.vp_bonuspoints_tv);
        basePointsTV = findViewById(R.id.vp_basepoints_tv);
        totalPointsTV = findViewById(R.id.vp_totalpoints_tv);
        infoTV = findViewById(R.id.vp_info_tv);

       /* setTargetLL = (LinearLayout)findViewById(R.id.vp_setting_target_LL);*/

        edtRice.addTextChangedListener(watcher);
        edtMillet.addTextChangedListener(watcher);
        edtCorn.addTextChangedListener(watcher);
        edtMustard.addTextChangedListener(watcher);

        plan.setOnClickListener(this);
        reset.setOnClickListener(this);

        List<DTO> list = VolumePlannerDAO.getInstance().getRecords(DBHandler.getReadableDb(EmpVolumePlanner.this));
        this.list.clear();
        for (DTO mainDto : list) {
            this.list.add((VolumePlannerModel) mainDto);
        }
    }

    @Override
    public void onClick(View v) {
        int nextTierVolume = 0;
        int finalCurrentTierVolume = 0;
        switch (v.getId()) {
            case R.id.vp_plan_btn:

                /*if (AppConstants.USERTYPE_RET.equals(Utils.getType(EmpVolumePlanner.this))){
                    setTargetLL.setVisibility(View.VISIBLE);
                }*/
                ((InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE)).toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);

                st_total = edtTotal.getText().toString();
                if (!Utils.isNumeric(st_total))
                    return;
                int intTotal = Integer.parseInt(st_total);

                VolumePlannerModel planedTier = null;
                VolumePlannerModel nextTier = null;


                for (int i = 0; i < list.size(); i++) {
                    int vol = Integer.parseInt(list.get(i).getVolumePerKG());

                    String achievedTierString = list.get(i).getTire();
                   /* if (membershipTierFromCuurentYearModel.equals(achievedTierString)){
                        currentTier = Integer.parseInt(list.get(i).getVolumePerKG());
                    }*/
                    if (intTotal >= vol) {
                        planedTier = list.get(i);

                        if (i > 0) {
                            nextTier = list.get(i - 1);
                        } else {
                            nextTier = null;
                        }
                        break;
                    }
                }

                if (planedTier != null) {
                    finalCurrentTierVolume = Integer.valueOf(planedTier.getVolumePerKG());
                    bottomLL.setVisibility(View.VISIBLE);
                    volumeTV.setText(st_total);
                    int basePoints = Integer.parseInt(planedTier.getBaseptsPerKG());
                    int multiplyPoints = basePoints * intTotal;
                    basePointsTV.setText(String.valueOf(multiplyPoints));
                    bonusPointsTV.setText(planedTier.getBonusPts());
                    membershipTierTV.setText(" " + planedTier.getTire());
                    //membershipTierTV.setText(" "+membershipTierFromCuurentYearModel);
                    String st_info = "As per your planned Volume, You will attain membership tier of " + planedTier.getTire() + ".";

                    if (nextTier != null) {
                        nextTierVolume = Integer.parseInt(nextTier.getVolumePerKG());
                        int pointsRequired = nextTierVolume - intTotal;
                        st_info += " If you add additional " + pointsRequired + " Kg's you will attain membership tier of " + nextTier.getTire();
                    }

                    infoTV.setText(st_info);

                    int totalPtsTv = Integer.parseInt(basePointsTV.getText().toString()) + Integer.parseInt(bonusPointsTV.getText().toString());
                    totalPointsTV.setText(String.valueOf(totalPtsTv));
                }

                List<Float> dataList = new ArrayList<>();
                ArrayList<String> xdataList = new ArrayList<>();
                xLables.removeAllViews();
                for (int i = list.size() - 1; i >= 0; i--) {
                    VolumePlannerModel vpm = list.get(i);
                    dataList.add(Float.valueOf(vpm.getVolumePerKG()));
                    xdataList.add(vpm.getTireCode());
                    int coloredBar = Integer.parseInt(vpm.getVolumePerKG());
//                    if (coloredBar >= finalCurrentTierVolume && coloredBar <= nextTierVolume ){
                    if (/*coloredBar >= finalCurrentTierVolume &&*/ coloredBar <= finalCurrentTierVolume) {
                        plannedYear = coloredBar;
                    }

                    // Add textview XAxis Lables
                    TextView textView = new TextView(this);
                    textView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    textView.setText(vpm.getTireCode() + " : " + vpm.getTire());
                    textView.setTextColor(getResources().getColor(R.color.black));
                    textView.setPadding(20, 2, 20, 2);// in pixels (left, top, right, bottom)
                    xLables.addView(textView);

                }

                // here pass the currentMembership tier name and value from other table
                BarData barData2 = new BarData(xdataList, MPUtilEmpVolPlan.getDataSet(EmpVolumePlanner.this, dataList)); // here in getXAsisValues, yiu can enter any value, nothing will happen but in for loop you need to insert exaxt number on x-axis
                MPUtilEmpVolPlan.drawChart(EmpVolumePlanner.this, chart, barData2);

                break;

            case R.id.vp_btn_reset:
                edtRice.setText("");
                edtMillet.setText("");
                edtCorn.setText("");
                edtMustard.setText("");
                edtTotal.setText("");
                bottomLL.setVisibility(View.INVISIBLE);
                break;
        }
    }
}
