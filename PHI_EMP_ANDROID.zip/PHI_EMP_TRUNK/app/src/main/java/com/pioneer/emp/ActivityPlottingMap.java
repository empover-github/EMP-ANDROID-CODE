package com.pioneer.emp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.pioneer.emp.adapters.IdNameAdapter;
import com.pioneer.emp.cropDiagnostic.WebViewActivity;
import com.pioneer.emp.models.FilterSetModelForDashBoard;
import com.pioneer.emp.models.LoginModelForDashboard;
import com.pioneer.emp.models.MdrFilterActivtyModel;
import com.pioneer.emp.models.UserDataList;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;
import java.util.Calendar;


/**
 * Created by fatima.t on 12-06-2018.
 */

public class ActivityPlottingMap extends BaseActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener, SeekBar.OnSeekBarChangeListener {
    private Spinner spnYear, spnSeason, spnCrop, spnCuFilter, spnRegionFilter, spnTerritoryFilter, spnMdrFilter;
    private SeekBar radiusSb;
    private Button btnShowMap;
    private TextView mapsNoteTv;
    private TextView noDataAvailable;
    private LinearLayout spinnersLL;
    private ArrayList<UserDataList> seasonList = new ArrayList<>();
    private ArrayList<UserDataList> cropList = new ArrayList<>();
    private ArrayList<UserDataList> cuList = new ArrayList<>();
    private ArrayList<UserDataList> regionList = new ArrayList<>();
    private ArrayList<UserDataList> terrioryList = new ArrayList<>();
    private ArrayList<UserDataList> mdrList = new ArrayList<>();
    private ActivityPlottingMap filterMdrDgDashboardActivity;
    private MdrFilterActivtyModel response;
    private String mobileNumber;
    private String accessLevel;
    private long id;
    private IdNameAdapter seasonAdapter, cropAdapter, cuAdapter, regionAdapter, territoryAdapter, mdrAdapter;
    FilterSetModelForDashBoard model = new FilterSetModelForDashBoard();
    private UserDataList spinnerAllObject = new UserDataList(-1, AppConstants.SPINNER_DATA_ALL);
    //    private UserDataList spinnerSelectObject = new UserDataList(-1, AppConstants.SPINNER_DATA_SELECT);
    private long autoSelectCuId, autoSelectRegId, autoSelectTerrId, autoSelectMdrId;

    public static final String INTENT_TYPE = "intentType";
    private int selectedSeasonId, selectedCropId;

    private TextView seekBarValue;
    String intentType;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plotting_map);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        filterMdrDgDashboardActivity = this;
        TextView txtHeader = findViewById(R.id.hedder_text);

        Bundle bundle = getIntent().getExtras();
        intentType = getIntent().getStringExtra(INTENT_TYPE);

        spnYear = findViewById(R.id.filt_des_year_spinner);
        spnSeason = findViewById(R.id.filt_des_season_spinner);
        spnCrop = findViewById(R.id.filt_des_crop_spinner);
        spinnersLL = findViewById(R.id.all_spinnersLL);
        spnRegionFilter = findViewById(R.id.filt_des_region_spinner);
        spnTerritoryFilter = findViewById(R.id.filt_des_territory_spinner);
        spnMdrFilter = findViewById(R.id.filt_des_mdr_spinner);
        spnCuFilter = findViewById(R.id.filt_des_cu_spinner);
        radiusSb = findViewById(R.id.radius_SB_ap);

        LinearLayout yearLL = findViewById(R.id.filter_layout_year);
        LinearLayout seasonLL = findViewById(R.id.filter_layout_season);
        LinearLayout cropLL = findViewById(R.id.filter_layout_crop);
        LinearLayout radiudLL = findViewById(R.id.filter_layout_radius);
        seekBarValue = findViewById(R.id.seekbarValue);
        Button btnFilter = findViewById(R.id.btn_applyFileter);
        btnShowMap = findViewById(R.id.show_map_button);
        TextView radiusInfoTv = findViewById(R.id.tv_radius);
        mapsNoteTv = findViewById(R.id.filter_maps_noteTv);
        noDataAvailable = findViewById(R.id.no_data_availableTv);

        ImageView navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);

        spnYear.setOnItemSelectedListener(this);
        spnSeason.setOnItemSelectedListener(this);
        spnCrop.setOnItemSelectedListener(this);
        spnCuFilter.setOnItemSelectedListener(this);
        spnRegionFilter.setOnItemSelectedListener(this);
        spnTerritoryFilter.setOnItemSelectedListener(this);
        spnMdrFilter.setOnItemSelectedListener(this);
        radiusSb.setOnSeekBarChangeListener(this);

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        ArrayList<String> yearList = new ArrayList<>();
        yearList.add(String.valueOf(year));
        yearList.add(String.valueOf(year - 1));
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(ActivityPlottingMap.this, android.R.layout.simple_spinner_dropdown_item, yearList);
        spnYear.setAdapter(yearAdapter);

        seasonList.add(spinnerAllObject);
        cropList.add(spinnerAllObject);
        cuList.add(spinnerAllObject);
        regionList.add(spinnerAllObject);
        terrioryList.add(spinnerAllObject);
        mdrList.add(spinnerAllObject);

        seasonAdapter = new IdNameAdapter(this, seasonList);
        cropAdapter = new IdNameAdapter(this, cropList);
        cuAdapter = new IdNameAdapter(this, cuList);
        regionAdapter = new IdNameAdapter(this, regionList);
        territoryAdapter = new IdNameAdapter(this, terrioryList);
        mdrAdapter = new IdNameAdapter(this, mdrList);

        spnSeason.setAdapter(seasonAdapter);
        spnCrop.setAdapter(cropAdapter);
        spnCuFilter.setAdapter(cuAdapter);
        spnRegionFilter.setAdapter(regionAdapter);
        spnTerritoryFilter.setAdapter(territoryAdapter);
        spnMdrFilter.setAdapter(mdrAdapter);

        radiusSb.setMax(18);
        radiusSb.incrementProgressBy(1);
        radiusSb.setProgress(1);
        float progValue = getConvertedValue(radiusSb.getProgress());
        seekBarValue.setText(String.valueOf(progValue));

        btnFilter.setOnClickListener(this);
        btnShowMap.setOnClickListener(this);
        radiusInfoTv.setOnClickListener(this);

        if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING)) {
            txtHeader.setText(getString(R.string.activity_plotting));
            yearLL.setVisibility(View.VISIBLE);
            seasonLL.setVisibility(View.VISIBLE);
            cropLL.setVisibility(View.VISIBLE);
            radiudLL.setVisibility(View.VISIBLE);
            btnShowMap.setVisibility(View.VISIBLE);
            mapsNoteTv.setVisibility(View.VISIBLE);
            btnFilter.setVisibility(View.GONE);
            //Live
            mobileNumber = Utils.getUserMobile(filterMdrDgDashboardActivity);
            /*//Dummy data
            mobileNumber = "9304820755"; // Country Level
//            mobileNumber = "9919667741"; // CU
//            mobileNumber = "9431603985"; // RBM
//            mobileNumber = "9308285168"; // TBL*/
        } else {
            txtHeader.setText(getString(R.string.emp_filter_dg));
            yearLL.setVisibility(View.GONE);
            seasonLL.setVisibility(View.GONE);
            cropLL.setVisibility(View.GONE);
            radiudLL.setVisibility(View.GONE);
            btnShowMap.setVisibility(View.GONE);
            mapsNoteTv.setVisibility(View.GONE);
            btnFilter.setVisibility(View.VISIBLE);
            if (bundle != null) {
                model = (FilterSetModelForDashBoard) getIntent().getSerializableExtra(MdrDGDashboardActivity.EXTRA_SERIAZABLE_DATA);
                mobileNumber = model.getMobileNumber();
                accessLevel = model.getAccessLevel();
                id = model.getAccessLevelId();

                autoSelectCuId = model.getSelectedCuId();
                autoSelectRegId = model.getSelectedRegId();
                autoSelectTerrId = model.getSelectedTerrId();
                autoSelectMdrId = model.getSelectedMdrId();

            }
        }

        showLayouts(false);
        callFilterData(mobileNumber, id, accessLevel, intentType);
    }

    private void showLayouts(boolean b) {
        if (b) {
            spinnersLL.setVisibility(View.VISIBLE);
            btnShowMap.setVisibility(View.VISIBLE);
            noDataAvailable.setVisibility(View.GONE);
        } else {
            spinnersLL.setVisibility(View.GONE);
            btnShowMap.setVisibility(View.GONE);
            if (spnSeason.getSelectedItemPosition() == 0 && spnCrop.getSelectedItemPosition() == 0)
                noDataAvailable.setVisibility(View.GONE);
            else
                noDataAvailable.setVisibility(View.VISIBLE);

        }
    }


    private void callFilterData(String mobileNumber, long id, String accesLevel, String intentType) {

        LoginModelForDashboard loginModel = new LoginModelForDashboard();
        loginModel.setMobileNumber(mobileNumber);
        loginModel.setId(id);
        loginModel.setAccessLevel(accesLevel);
        loginModel.setYear(spnYear.getSelectedItem().toString());
        loginModel.setSeason(String.valueOf(selectedSeasonId));
        loginModel.setCrop(String.valueOf(selectedCropId));
        if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
            APIRequestHandler.getInstance().getMapFilterData(filterMdrDgDashboardActivity, loginModel, this, true);
        else
            APIRequestHandler.getInstance().getMdrFilterData(filterMdrDgDashboardActivity, loginModel, this, true);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_filter, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.action_reset:
                model.setSelectedCuId(-1);
                model.setSelectedRegId(-1);
                model.setSelectedTerrId(-1);
                model.setSelectedMdrId(-1);

                autoSelectCuId = -1;
                autoSelectRegId = -1;
                autoSelectTerrId = -1;
                autoSelectMdrId = -1;

                spnYear.setSelection(0);
                spnSeason.setSelection(0);
                spnCrop.setSelection(0);
                radiusSb.setProgress(1);
                selectedSeasonId = 0;
                selectedCropId = 0;
                showLayouts(false);
                callFilterData(mobileNumber, 0, null, intentType);

                break;
        }
        return false;
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null && responseObj instanceof MdrFilterActivtyModel) {
            MdrFilterActivtyModel resEntity = (MdrFilterActivtyModel) responseObj;
            if (AppConstants.STATUS_CODE_PRAVAKTA == resEntity.getStatusCode()) {
                response = resEntity.getResponseObj();
//                response = new Gson().fromJson(resEntity.getResponse(), MdrFilterActivtyModel.class); // did for testing without bridge
                setData(response);
            } else {
                DialogManager.showToast(filterMdrDgDashboardActivity, resEntity.getMessage());
            }
        }
    }

    private void setData(MdrFilterActivtyModel response) {
        if (response != null) {

            ArrayList<UserDataList> seasonData = response.getSeasonList();
            if (seasonData != null && !seasonData.isEmpty()) {
                seasonList.clear();
                seasonList.addAll(seasonData);
                seasonAdapter.notifyDataSetChanged();
            }

            ArrayList<UserDataList> cropData = response.getCropList();
            if (cropData != null && !cropData.isEmpty()) {
                cropList.clear();
                cropList.addAll(cropData);
                cropAdapter.notifyDataSetChanged();
            }
            if (Utils.isValidStr(response.getLastUpdatedTime())) {
                String lastUpdatedTime = Utils.convertDateTimeFromSSStoSS(response.getLastUpdatedTime());
                mapsNoteTv.setText(getString(R.string.maps_note).replace("$1", "\n\t\t" + lastUpdatedTime));
            }


            if ((response.getCommercialUnitUsersList() == null || response.getCommercialUnitUsersList().size() == 0) && (response.getRegionUsersList() == null || response.getRegionUsersList().size() == 0) && (response.getTerritoryUsersList() == null || response.getTerritoryUsersList().size() == 0) && (response.getMdrUsersList() == null || response.getMdrUsersList().size() == 0)) {
                showLayouts(false);
            } else {
                showLayouts(true);
                UserDataList territoryData = response.getTerritory();
                if (territoryData != null && territoryData.getId() != 0) {
                    terrioryList.clear();
                /*if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
                    terrioryList.add(spinnerSelectObject);
                else
                    terrioryList.add(spinnerAllObject);*/
                    terrioryList.add(spinnerAllObject);
                    terrioryList.add(territoryData);
                    territoryAdapter.notifyDataSetChanged();
                    spnTerritoryFilter.setSelection(1);
                    spnTerritoryFilter.setEnabled(false);
                    spnTerritoryFilter.setClickable(false);
                    spnTerritoryFilter.setFocusable(false);
                    autoSelectTerrId = -1;
                }
                UserDataList regionData = response.getRegion();
                if (regionData != null && regionData.getId() != 0) {
                    regionList.clear();
                /*if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
                    regionList.add(spinnerSelectObject);
                else
                    regionList.add(spinnerAllObject);*/
                    regionList.add(spinnerAllObject);
                    regionList.add(regionData);
                    regionAdapter.notifyDataSetChanged();
                    spnRegionFilter.setSelection(1);
                    spnRegionFilter.setEnabled(false);
                    spnRegionFilter.setClickable(false);
                    spnRegionFilter.setFocusable(false);
                    autoSelectRegId = -1;
                }
                UserDataList commercialData = response.getCommercialUnit();
                if (commercialData != null && commercialData.getId() != 0) {
                    cuList.clear();
                /*if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
                    cuList.add(spinnerSelectObject);
                else
                    cuList.add(spinnerAllObject);*/
                    cuList.add(spinnerAllObject);
                    cuList.add(commercialData);
                    cuAdapter.notifyDataSetChanged();
                    spnCuFilter.setSelection(1);
                    spnCuFilter.setEnabled(false);
                    spnCuFilter.setClickable(false);
                    spnCuFilter.setFocusable(false);
                    autoSelectCuId = -1;
                }
                String data = response.getAccessLevel();
                if (AppConstants.ACCESS_LEVEL_CU.equals(data)) {
                    ArrayList<UserDataList> cuData = response.getCommercialUnitUsersList();
                    if (cuData != null && cuData.size() > 0) {
                        if (autoSelectCuId > 0) {
                            int previousSelPos = 0;
                            int i = 0;
                            cuList.clear();
                            for (UserDataList dto : cuData) {
                                cuList.add(dto);
                                if (dto.getId() == autoSelectCuId)
                                    previousSelPos = i;
                                i++;
                            }
                            if (previousSelPos == 0)
                                autoSelectCuId = -1;
                            spnCuFilter.setSelection(previousSelPos);
                            cuAdapter.notifyDataSetChanged();
                        } else {
                            cuList.clear();
                            cuList.addAll(cuData);
                            cuAdapter.notifyDataSetChanged();
                            if (!cuList.isEmpty())
                                spnCuFilter.setSelection(0);
                        }
                    }
                } else if (AppConstants.ACCESS_LEVEL_REGION.equals(data)) {
                    ArrayList<UserDataList> regionDataList = response.getRegionUsersList();
                    if (regionDataList != null && regionDataList.size() > 0) {
                        if (autoSelectRegId > 0) {
                            int previousSelPos = 0;
                            int i = 0;
                            regionList.clear();
                            for (UserDataList dto : regionDataList) {
                                regionList.add(dto);
                                if (dto.getId() == autoSelectRegId)
                                    previousSelPos = i;
                                i++;
                            }
                            if (previousSelPos == 0)
                                autoSelectRegId = -1;
                            spnRegionFilter.setSelection(previousSelPos);
                            regionAdapter.notifyDataSetChanged();
                        } else {
                            regionList.clear();
                            regionList.addAll(regionDataList);
                            regionAdapter.notifyDataSetChanged();
                            if (!regionList.isEmpty())
                                spnRegionFilter.setSelection(0);
                        }
                    }
                } else if (AppConstants.ACCESS_LEVEL_TERRITORY.equals(data)) {
                    ArrayList<UserDataList> territoryDataList = response.getTerritoryUsersList();
                    if (territoryDataList != null && territoryDataList.size() > 0) {
                        if (autoSelectTerrId > 0) {
                            int previousSelPos = 0;
                            int i = 0;
                            terrioryList.clear();
                            for (UserDataList dto : territoryDataList) {
                                terrioryList.add(dto);
                                if (dto.getId() == autoSelectTerrId)
                                    previousSelPos = i;
                                i++;
                            }
                            if (previousSelPos == 0)
                                autoSelectTerrId = -1;
                            spnTerritoryFilter.setSelection(previousSelPos);
                            territoryAdapter.notifyDataSetChanged();
                        } else {
                            terrioryList.clear();
                            terrioryList.addAll(territoryDataList);
                            territoryAdapter.notifyDataSetChanged();
                            if (!terrioryList.isEmpty())
                                spnTerritoryFilter.setSelection(0);
                        }
                    }
                } else if (AppConstants.ACCESS_LEVEL_MDR.equals(data)) {
                    ArrayList<UserDataList> mdrData = response.getMdrUsersList();
                    if (mdrData != null && mdrData.size() > 0) {
                        if (autoSelectMdrId > 0) {
                            int previousSelPos = 0;
                            int i = 0;
                            mdrList.clear();
                            for (UserDataList dto : mdrData) {
                                mdrList.add(dto);
                                if (dto.getId() == autoSelectMdrId)
                                    previousSelPos = i;
                                i++;
                            }
                            if (previousSelPos == 0)
                                autoSelectMdrId = -1;
                            spnMdrFilter.setSelection(previousSelPos);
                            mdrAdapter.notifyDataSetChanged();
                        } else {
                            mdrList.clear();
                            mdrList.addAll(mdrData);
                            mdrAdapter.notifyDataSetChanged();
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
        switch (parent.getId()) {

            case R.id.filt_des_year_spinner:
                if (spnSeason.getSelectedItemPosition() > 0 && spnCrop.getSelectedItemPosition() > 0)
                    callFilterData(mobileNumber, id, accessLevel, intentType);

                break;
            case R.id.filt_des_season_spinner:
                selectedSeasonId = (int) seasonList.get(position).getId();
                if (spnCrop.getSelectedItemPosition() > 0)
                    callFilterData(mobileNumber, id, accessLevel, intentType);
                break;
            case R.id.filt_des_crop_spinner:
                selectedCropId = (int) cropList.get(position).getId();
                if (spnSeason.getSelectedItemPosition() > 0)
                    callFilterData(mobileNumber, id, accessLevel, intentType);
                break;
            case R.id.filt_des_cu_spinner:
                if (response != null && response.getRegion() != null)
                    return;
                regionList.clear();
                /*if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
                    regionList.add(spinnerSelectObject);
                else
                    regionList.add(spinnerAllObject);*/
                regionList.add(spinnerAllObject);
                regionAdapter.notifyDataSetChanged();
                model.setSelectedRegId(-1);
                model.setSelectedTerrId(-1);
                model.setSelectedMdrId(-1);
                if (position == 0) {
                    model.setSelectedCuId(-1);
                } else if (cuList != null && cuList.size() > 0) {
                    UserDataList selectedItem = (UserDataList) cuAdapter.getItem(position);
                    model.setSelectedCuId(selectedItem.getId());
                    model.setAccessLevelId(selectedItem.getId());
                    model.setAccessLevel(AppConstants.ACCESS_LEVEL_CU);
                    callFilterData(mobileNumber, model.getSelectedCuId(), model.getAccessLevel(), intentType);
                }

                break;
            case R.id.filt_des_region_spinner:
                if (response != null && response.getTerritory() != null)
                    return;
                terrioryList.clear();
               /* if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
                    terrioryList.add(spinnerSelectObject);
                else
                    terrioryList.add(spinnerAllObject);*/
                terrioryList.add(spinnerAllObject);
                territoryAdapter.notifyDataSetChanged();
                model.setSelectedTerrId(-1);
                model.setSelectedMdrId(-1);
                if (position == 0) {
                    model.setSelectedRegId(-1);
                    // model.setSelectedRegId(autoSelectRegId);
                } else if (regionList != null && regionList.size() > 0) {
                    UserDataList selectedItem = (UserDataList) regionAdapter.getItem(position);
                    model.setSelectedRegId(selectedItem.getId());
                    model.setAccessLevelId(selectedItem.getId());
                    model.setAccessLevel(AppConstants.ACCESS_LEVEL_REGION);
                    callFilterData(mobileNumber, model.getSelectedRegId(), model.getAccessLevel(), intentType);
                }
                break;
            case R.id.filt_des_territory_spinner:
                mdrList.clear();
               /* if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
                    mdrList.add(spinnerSelectObject);
                else
                    mdrList.add(spinnerAllObject);*/
                mdrList.add(spinnerAllObject);
                mdrAdapter.notifyDataSetChanged();
                model.setSelectedMdrId(-1);
                if (position == 0) {
                    model.setSelectedTerrId(-1);
                } else {
                    if (terrioryList != null && terrioryList.size() > 0) {
                        UserDataList selectedItem = (UserDataList) territoryAdapter.getItem(position);
                        model.setSelectedTerrId(selectedItem.getId());
                        model.setAccessLevelId(selectedItem.getId());
                        model.setAccessLevel(AppConstants.ACCESS_LEVEL_TERRITORY);
                        callFilterData(mobileNumber, model.getSelectedTerrId(), model.getAccessLevel(), intentType);
                    }
                }
                break;

            case R.id.filt_des_mdr_spinner:
                if (position > 0) {
                    if (mdrList != null && mdrList.size() > 0) {
                        UserDataList selectedItem = (UserDataList) mdrAdapter.getItem(position);
                        model.setSelectedMdrId(selectedItem.getId());
                        model.setAccessLevelId(selectedItem.getId());
                        model.setAccessLevel(AppConstants.ACCESS_LEVEL_MDR);
                    }
                } else {
                    model.setSelectedMdrId(-1);
                }
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void goBack() {
        /*if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING)) {
            super.onBackPressed();
        } else {
            DialogManager.showConformPopup(filterMdrDgDashboardActivity, new DialogMangerCallback() {
                @Override
                public void onOkClick(View v) {
                    btnFilter.performClick();
                }

                @Override
                public void onCancelClick(View view) {
                    setResult(RESULT_CANCELED);
                    finish();
                }
            }, getString(R.string.apply_filter_changes), getString(R.string.filterExitMsg), getString(R.string.apply), getString(R.string.filter_exit));
        }*/

        super.onBackPressed();
    }

    @Override
    public void onBackPressed() {
        goBack();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imgBacknav:
                goBack();
                break;
            /*case R.id.btn_applyFileter:

                UserDataList selectedModel = getSpinnersData();
                if (selectedModel != null) {
                    model.setAccessLevelId(selectedModel.getId());
                    model.setAccessLevelName(selectedModel.getName());
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(EXTRA_SERIAZABLE_DATA_BY_FILTER, model);
                    intent.putExtras(bundle);
                    setResult(RESULT_OK, intent);
                    finish();

                } else {
                    //Dummy doing nothing
                }
                break;*/
            case R.id.show_map_button:
                if (checkValidations()) {
                    UserDataList selectedData = /*getMapSpinnersData();*/ getSpinnersData();
                    if (selectedData != null) {
                        model.setAccessLevelId(selectedData.getId());
                        model.setAccessLevelName(selectedData.getName());
                        Intent intent = new Intent(filterMdrDgDashboardActivity, WebViewActivity.class);
                        String url = AppConstants.ACTIVITY_PLOTTING_URL;
                        url = url.replace("$Y", spnYear.getSelectedItem().toString()).replace("$S", String.valueOf(selectedSeasonId)).replace("$C", String.valueOf(selectedCropId)).replace("$D", String.valueOf(radiusSb.getProgress())).replace("$M", mobileNumber).replace("$A", model.getAccessLevel()).replace("$I", String.valueOf(model.getAccessLevelId()));
                        intent.putExtra(WebViewActivity.EXTRA_TITLE, getString(R.string.activity_plotting_map));
                        intent.putExtra(WebViewActivity.EXTRA_URL, url);
                        startActivity(intent);
                    }
                }
                break;
            case R.id.tv_radius:
                DialogManager.showSingleBtnPopup(filterMdrDgDashboardActivity, null, getString(R.string.info), getString(R.string.radius_in_kms), getString(R.string.ok));
                break;

        }
    }

    private boolean checkValidations() {
        if (spnYear.getSelectedItem().toString().equalsIgnoreCase(getString(R.string.select))) {
            DialogManager.showToast(filterMdrDgDashboardActivity, getString(R.string.retail_year));
            return false;
        } else if (spnSeason.getSelectedItemPosition() == 0/*spnSeason.getSelectedItem().toString().equalsIgnoreCase(getString(R.string.select))*/) {
            DialogManager.showToast(filterMdrDgDashboardActivity, getString(R.string.select_one_season));
            return false;
        } else if (spnCrop.getSelectedItemPosition() == 0/*spnCrop.getSelectedItem().toString().equalsIgnoreCase(getString(R.string.select))*/) {
            DialogManager.showToast(filterMdrDgDashboardActivity, getString(R.string.select_crop));
            return false;
        } /*else if (spnCuFilter.getSelectedItemPosition() == 0*//*spnCuFilter.getSelectedItem().toString().equalsIgnoreCase(getString(R.string.select))*//*) {
            DialogManager.showToast(filterMdrDgDashboardActivity, getString(R.string.select_cu));
            return false;
        } else if (spnRegionFilter.getSelectedItemPosition() == 0*//*spnRegionFilter.getSelectedItem().toString().equalsIgnoreCase(getString(R.string.select))*//*) {
            DialogManager.showToast(filterMdrDgDashboardActivity, getString(R.string.select_region));
            return false;
        } else if (spnTerritoryFilter.getSelectedItemPosition() == 0*//*spnTerritoryFilter.getSelectedItem().toString().equalsIgnoreCase(getString(R.string.select))*//*) {
            DialogManager.showToast(filterMdrDgDashboardActivity, getString(R.string.select_territory));
            return false;
        }*/
        return true;
    }

    private UserDataList getSpinnersData() {

        UserDataList selectedModel;

        if (AppConstants.SPINNER_DATA_ALL.equalsIgnoreCase(((UserDataList) cuAdapter.getItem(spnCuFilter.getSelectedItemPosition())).getName())) {
            // Toast.makeText(FilterMdrDgDashboardActivity.this, "Please select any filter value to apply filter", Toast.LENGTH_LONG).show();

            if (intentType.equals(EmpActivityTracker.INTENT_TYPE_ACTIVITY_PLOTTING))
                model.setAccessLevel("COUNTRY");
            else
                model.setAccessLevel("");
            selectedModel = (UserDataList) cuAdapter.getItem(spnCuFilter.getSelectedItemPosition());
//            model.setAccessLevel("");
        } else if (AppConstants.SPINNER_DATA_ALL.equalsIgnoreCase(((UserDataList) regionAdapter.getItem(spnRegionFilter.getSelectedItemPosition())).getName())) {
            selectedModel = (UserDataList) cuAdapter.getItem(spnCuFilter.getSelectedItemPosition());
            model.setAccessLevel(AppConstants.ACCESS_LEVEL_CU);
        } else if (AppConstants.SPINNER_DATA_ALL.equalsIgnoreCase(((UserDataList) territoryAdapter.getItem(spnTerritoryFilter.getSelectedItemPosition())).getName())) {
            selectedModel = (UserDataList) regionAdapter.getItem(spnRegionFilter.getSelectedItemPosition());
            model.setAccessLevel(AppConstants.ACCESS_LEVEL_REGION);
        } else if (AppConstants.SPINNER_DATA_ALL.equalsIgnoreCase(((UserDataList) mdrAdapter.getItem(spnMdrFilter.getSelectedItemPosition())).getName())) {
            selectedModel = (UserDataList) territoryAdapter.getItem(spnTerritoryFilter.getSelectedItemPosition());
            model.setAccessLevel(AppConstants.ACCESS_LEVEL_TERRITORY);
        } else {
            selectedModel = (UserDataList) mdrAdapter.getItem(spnMdrFilter.getSelectedItemPosition());
            model.setAccessLevel(AppConstants.ACCESS_LEVEL_MDR);
        }

        return selectedModel;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        switch (seekBar.getId()) {
            case R.id.radius_SB_ap:
                if (progress == 0)
                    radiusSb.setProgress(1);

                break;
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        switch (seekBar.getId()) {
            case R.id.radius_SB_ap:

                float val = getConvertedValue(seekBar.getProgress());
                BuildLog.e("ProgressVal", " " + val);
                float progValue = getConvertedValue(seekBar.getProgress());
                seekBarValue.setText(String.valueOf(progValue));

                break;
        }
    }

    private float getConvertedValue(int intVal) {
        float floatVal;
        floatVal = (float) intVal / 2;
        return floatVal;
    }
}
