package com.pioneer.emp.fab;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pioneer.emp.R;

public class GalleryActivity extends AppCompatActivity implements View.OnClickListener {

    private Button cancelBtn;
    private ImageView previousImg, imageView, nextImg;
    private TextView captionTxt;

    private int index = 0;
    private int arraySize;
    private String[] imagesArray;
    private String[] imageTagArray;

    public static final String IMAGE_TAGS_EXTRAS = "imageTags";
    public static final String EXTRAS_IMAGES = "Images";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_activity_fab_gallery);

        Intent getData = getIntent();
        String st_images = getData.getStringExtra(EXTRAS_IMAGES);
        imagesArray = st_images.split("#");
        arraySize = imagesArray.length;
        String st_imageTags = getData.getStringExtra(IMAGE_TAGS_EXTRAS);
        imageTagArray = st_imageTags.split("#");

        cancelBtn = findViewById(R.id.fga_cancel);
        previousImg = findViewById(R.id.fga_prev_button_img);
        imageView = findViewById(R.id.fga_imageview);
        nextImg = findViewById(R.id.fga_next_button_img);
        captionTxt = findViewById(R.id.fga_caption_txt);

        previousImg.setOnClickListener(this);
        nextImg.setOnClickListener(this);
        cancelBtn.setOnClickListener(this);

        if (imagesArray != null) {
            Glide.with(GalleryActivity.this).load(imagesArray[index]).error(R.mipmap.image_not_exist).into(imageView); // this works perfectly without zoom
            if (imageTagArray[index] != null)
                captionTxt.setText(imageTagArray[index]);
            previousImg.setVisibility(View.INVISIBLE);
            if (imagesArray.length == 1) {
                previousImg.setVisibility(View.INVISIBLE);
                nextImg.setVisibility(View.INVISIBLE);
            }
        }
    }

    /*private void initializeUI() {

       *//* cancelBtn = (Button) findViewById(R.id.fga_cancel);
        previousImg = (ImageView) findViewById(R.id.fga_prev_button_img);
        imageView = (ImageView) findViewById(R.id.fga_imageview);
        nextImg = (ImageView) findViewById(R.id.fga_next_button_img);
        captionTxt = (TextView) findViewById(R.id.fga_caption_txt);

        previousImg.setOnClickListener(this);
        nextImg.setOnClickListener(this);
        cancelBtn.setOnClickListener(this);*//*

        if (imagesArray != null) {
            Glide.with(GalleryActivity.this).load(imagesArray[index]).error(R.mipmap.image_not_exist).into(imageView); // this works perfectly without zoom
            if (imageTagArray[index] != null)
                captionTxt.setText(imageTagArray[index]);
            previousImg.setVisibility(View.INVISIBLE);
            if (imagesArray.length == 1) {
                previousImg.setVisibility(View.INVISIBLE);
                nextImg.setVisibility(View.INVISIBLE);
            }
        }
    }*/

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.fga_prev_button_img:
                index--;
                if (index <= 0){
//                    previous.setVisibility(View.GONE);
                    previousImg.setVisibility(View.INVISIBLE);
                    Glide.with(GalleryActivity.this).load(imagesArray[0]).error(R.mipmap.image_not_exist).into(imageView);
                    if (imageTagArray[index] != null)
                        captionTxt.setText(imageTagArray[index]);
                    nextImg.setVisibility(View.VISIBLE);
                }else if (index > 0){
                    previousImg.setVisibility(View.VISIBLE);
                    Glide.with(GalleryActivity.this).load(imagesArray[index]).error(R.mipmap.image_not_exist).into(imageView);
                    if (imageTagArray[index] != null)
                        captionTxt.setText(imageTagArray[index]);
                    nextImg.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.fga_next_button_img:

                index++;
                if (index == arraySize ){
//                    next.setVisibility(View.GONE);
                    nextImg.setVisibility(View.INVISIBLE);
                    Glide.with(GalleryActivity.this).load(imagesArray[index-1]).error(R.mipmap.image_not_exist).into(imageView);
                    if (imageTagArray[index] != null)
                        captionTxt.setText(imageTagArray[index]);
                    previousImg.setVisibility(View.VISIBLE);
                }else if (index < arraySize ){
                    nextImg.setVisibility(View.VISIBLE);
                    Glide.with(GalleryActivity.this).load(imagesArray[index]).error(R.mipmap.image_not_exist).into(imageView);
                    if (imageTagArray[index] != null)
                        captionTxt.setText(imageTagArray[index]);
                    previousImg.setVisibility(View.VISIBLE);
                    if (index == arraySize-1)
                        nextImg.setVisibility(View.INVISIBLE);
                }
                break;
            case R.id.fga_cancel:
                finish();
//                super.onCreate(null); // Clear the instance which is saved onConfigChange, getting unfortunately stopped bcz super is called 2 times
                break;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        cancelBtn = findViewById(R.id.fga_cancel);
        previousImg = findViewById(R.id.fga_prev_button_img);
        imageView = findViewById(R.id.fga_imageview);
        nextImg = findViewById(R.id.fga_next_button_img);
        captionTxt = findViewById(R.id.fga_caption_txt);

        outState.putInt("SavedIndex", index);

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
//        super.onRestoreInstanceState(savedInstanceState);

        cancelBtn = findViewById(R.id.fga_cancel);
        previousImg = findViewById(R.id.fga_prev_button_img);
        imageView = findViewById(R.id.fga_imageview);
        nextImg = findViewById(R.id.fga_next_button_img);
        captionTxt = findViewById(R.id.fga_caption_txt);

        index = savedInstanceState.getInt("SavedIndex");

        Glide.with(GalleryActivity.this).load(imagesArray[index]).error(R.mipmap.image_not_exist).into(imageView); // this works perfectly without zoom
        if (imageTagArray[index] != null)
            captionTxt.setText(imageTagArray[index]);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
