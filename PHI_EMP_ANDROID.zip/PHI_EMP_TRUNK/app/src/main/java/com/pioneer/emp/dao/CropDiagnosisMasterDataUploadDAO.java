package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.CropDiagnosisMasterDataUploadDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fatima.t on 28/09/2018.
 */

public class CropDiagnosisMasterDataUploadDAO implements DAO {
    private final String TAG = "CropDiagnosisMasterDataUploadDAO";
    private static CropDiagnosisMasterDataUploadDAO cropDiagnosisMasterDataUpload;

    public static CropDiagnosisMasterDataUploadDAO getInstance() {
        if (cropDiagnosisMasterDataUpload == null) {
            cropDiagnosisMasterDataUpload = new CropDiagnosisMasterDataUploadDAO();
        }
        return cropDiagnosisMasterDataUpload;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
           /* private long id;
    private long cropId;
    private String cropName;
    private long diseaseClassificationId;
    private String diseaseClassificationName;
    private String tags;
    private String imageUrls;
    private String latLongValues;
    private String address;
    private int imgTotCount;
    private int status;
    private long serverId; */
            CropDiagnosisMasterDataUploadDTO dto = (CropDiagnosisMasterDataUploadDTO) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("cropId", dto.getCropId());
            cv.put("cropName", dto.getCropName());
            cv.put("diseaseClassificationId", dto.getDiseaseClassificationId());
            cv.put("diseaseClassificationName", dto.getDiseaseClassificationName());
            cv.put("tags", dto.getTags());
            cv.put("imageUrls", dto.getImageUrls());
            cv.put("latLongValues", dto.getLatLongValues());
            cv.put("address", dto.getAddress());
            cv.put("imgTotCount", dto.getImgTotCount());
            cv.put("status", dto.getStatus());
            cv.put("transactionTime", dto.getTransactionTime());
//            cv.put("serverId", dto.getServerId());


            long rowsEffected = dbObject.insert(DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD, null, cv);
            if (rowsEffected > 0)
                return "";
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            CropDiagnosisMasterDataUploadDTO dto = (CropDiagnosisMasterDataUploadDTO) dtoObject;
            ContentValues cValues = new ContentValues();
            cValues.put("status", dto.getStatus());
            cValues.put("serverId", dto.getServerId());// here put status as 1
            dbObject.update(DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD, cValues, "id = '" + dto.getId() + "'", null);
        } catch (SQLException e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> cropData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropDiagnosisMasterDataUploadDTO dto = new CropDiagnosisMasterDataUploadDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setDiseaseClassificationId(cursor.getLong(cursor.getColumnIndex("diseaseClassificationId")));
                    dto.setDiseaseClassificationName(cursor.getString(cursor.getColumnIndex("diseaseClassificationName")));
                    dto.setTags(cursor.getString(cursor.getColumnIndex("tags")));
                    dto.setImageUrls(cursor.getString(cursor.getColumnIndex("imageUrls")));
                    dto.setLatLongValues(cursor.getString(cursor.getColumnIndex("latLongValues")));
                    dto.setAddress(cursor.getString(cursor.getColumnIndex("address")));
                    dto.setImgTotCount(cursor.getInt(cursor.getColumnIndex("imgTotCount")));
                    dto.setStatus(cursor.getInt(cursor.getColumnIndex("status")));
                    dto.setServerId(cursor.getInt(cursor.getColumnIndex("serverId")));
                    dto.setTransactionTime(cursor.getString(cursor.getColumnIndex("transactionTime")));

                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return cropData;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
    public List<CropDiagnosisMasterDataUploadDTO> getRecordById(long id, SQLiteDatabase dbObject) {
        List<CropDiagnosisMasterDataUploadDTO> cropData = new ArrayList<>();
        CropDiagnosisMasterDataUploadDTO dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new CropDiagnosisMasterDataUploadDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setDiseaseClassificationId(cursor.getLong(cursor.getColumnIndex("diseaseClassificationId")));
                    dto.setDiseaseClassificationName(cursor.getString(cursor.getColumnIndex("diseaseClassificationName")));
                    dto.setTags(cursor.getString(cursor.getColumnIndex("tags")));
                    dto.setImageUrls(cursor.getString(cursor.getColumnIndex("imageUrls")));
                    dto.setLatLongValues(cursor.getString(cursor.getColumnIndex("latLongValues")));
                    dto.setAddress(cursor.getString(cursor.getColumnIndex("address")));
                    dto.setImgTotCount(cursor.getInt(cursor.getColumnIndex("imgTotCount")));
                    dto.setStatus(cursor.getInt(cursor.getColumnIndex("status")));
                    dto.setServerId(cursor.getInt(cursor.getColumnIndex("serverId")));
                    dto.setTransactionTime(cursor.getString(cursor.getColumnIndex("transactionTime")));

                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return cropData;
    }

    public boolean deleteRecordById(long id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("DELETE FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + " where id='" + id + "'");
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {
            dbObject.close();
        }
        return false;
    }

    public boolean deleteRecordByServerId(long serverId, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("DELETE FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + " where serverId='" + serverId + "' AND status = 1");
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {
            dbObject.close();
        }
        return false;
    }

    public String getImagePathById(long id, SQLiteDatabase dbObject) {
        String imagePath = "";
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT imageUrls FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + " WHERE id = '" + id + "'", null);
            imagePath = cursor.getString(cursor.getColumnIndex("imageUrls"));
            return imagePath;
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
            return "";
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
    }

    public ArrayList<CropDiagnosisMasterDataUploadDTO> getALLRecords(SQLiteDatabase dbObject) {
        ArrayList<CropDiagnosisMasterDataUploadDTO> cropData = new ArrayList<>();
        Cursor cursor = null;
        try {
            // here status 0 means pending record
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + " WHERE status = 0", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropDiagnosisMasterDataUploadDTO dto = new CropDiagnosisMasterDataUploadDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setDiseaseClassificationId(cursor.getLong(cursor.getColumnIndex("diseaseClassificationId")));
                    dto.setDiseaseClassificationName(cursor.getString(cursor.getColumnIndex("diseaseClassificationName")));
                    dto.setTags(cursor.getString(cursor.getColumnIndex("tags")));
                    dto.setImageUrls(cursor.getString(cursor.getColumnIndex("imageUrls")));
                    dto.setLatLongValues(cursor.getString(cursor.getColumnIndex("latLongValues")));
                    dto.setAddress(cursor.getString(cursor.getColumnIndex("address")));
                    dto.setImgTotCount(cursor.getInt(cursor.getColumnIndex("imgTotCount")));
                    dto.setStatus(cursor.getInt(cursor.getColumnIndex("status")));
                    dto.setServerId(cursor.getInt(cursor.getColumnIndex("serverId")));
                    dto.setTransactionTime(cursor.getString(cursor.getColumnIndex("transactionTime")));

                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return cropData;
    }

    public int isDataPending(SQLiteDatabase dbObject) {
        ArrayList<CropDiagnosisMasterDataUploadDTO> cropData = new ArrayList<>();
        Cursor cursor = null;
        try {
            // here status 0 means pending record
            cursor = dbObject.rawQuery("SELECT count(*) FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + " WHERE status = 0", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return 0;
    }

    public CropDiagnosisMasterDataUploadDTO getRecordByIdSingleRecord(long id, SQLiteDatabase dbObject) {

        CropDiagnosisMasterDataUploadDTO dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new CropDiagnosisMasterDataUploadDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setDiseaseClassificationId(cursor.getLong(cursor.getColumnIndex("diseaseClassificationId")));
                    dto.setDiseaseClassificationName(cursor.getString(cursor.getColumnIndex("diseaseClassificationName")));
                    dto.setTags(cursor.getString(cursor.getColumnIndex("tags")));
                    dto.setImageUrls(cursor.getString(cursor.getColumnIndex("imageUrls")));
                    dto.setLatLongValues(cursor.getString(cursor.getColumnIndex("latLongValues")));
                    dto.setAddress(cursor.getString(cursor.getColumnIndex("address")));
                    dto.setImgTotCount(cursor.getInt(cursor.getColumnIndex("imgTotCount")));
                    dto.setStatus(cursor.getInt(cursor.getColumnIndex("status")));
                    dto.setServerId(cursor.getInt(cursor.getColumnIndex("serverId")));
                    dto.setTransactionTime(cursor.getString(cursor.getColumnIndex("transactionTime")));

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }

    public boolean updateRecordById(DTO mainDTO, SQLiteDatabase dbObject) {
        try {
            CropDiagnosisMasterDataUploadDTO dto = (CropDiagnosisMasterDataUploadDTO) mainDTO;
            ContentValues cValues = new ContentValues();

            /* private long id;
    private long cropId;
    private String cropName;
    private long diseaseClassificationId;
    private String diseaseClassificationName;
    private String tags;
    private String imageUrls;
    private String latLongValues;
    private String address;
    private int imgTotCount;
    private int status;
    private long serverId; */

            if (dto.getCropId() != 0)
                cValues.put("cropId", dto.getCropId());
            if (Utils.isValidStr(dto.getCropName()))
                cValues.put("cropName", dto.getCropName());
            if (dto.getDiseaseClassificationId() != 0)
                cValues.put("diseaseClassificationId", dto.getDiseaseClassificationId());
            if (Utils.isValidStr(dto.getDiseaseClassificationName()))
                cValues.put("diseaseClassificationName", dto.getDiseaseClassificationName());
            if (Utils.isValidStr(dto.getTags()))
                cValues.put("tags", dto.getTags());
            if (Utils.isValidStr(dto.getImageUrls()))
                cValues.put("imageUrls", dto.getImageUrls());
            if (Utils.isValidStr(dto.getLatLongValues()))
                cValues.put("latLongValues", dto.getLatLongValues());
            if (Utils.isValidStr(dto.getAddress()))
                cValues.put("address", dto.getAddress());
            if (dto.getImgTotCount() != 0) {
                cValues.put("imgTotCount", dto.getImgTotCount());
            }
            if (dto.getStatus() != 0) {
                cValues.put("status", dto.getStatus());
            }
            if (dto.getServerId() != 0) {
                cValues.put("serverId", dto.getServerId());
            }

            if (Utils.isValidStr(dto.getTransactionTime()))
                cValues.put("transactionTime", dto.getTransactionTime());

            dbObject.update(DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD, cValues, "id = '"+dto.getId()+"'", null);
            return true;
        } catch (Exception e) {
            BuildLog.d(TAG, "updateRecordById: ");
        } finally {
            dbObject.close();
        }
        return false;
    }

    public ArrayList<CropDiagnosisMasterDataUploadDTO> getRecordsAll(SQLiteDatabase dbObject) {
        ArrayList<CropDiagnosisMasterDataUploadDTO> cropData = new ArrayList<>();
        Cursor cursor = null;
        try {
            // here status 0 means pending record
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD , null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropDiagnosisMasterDataUploadDTO dto = new CropDiagnosisMasterDataUploadDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setDiseaseClassificationId(cursor.getLong(cursor.getColumnIndex("diseaseClassificationId")));
                    dto.setDiseaseClassificationName(cursor.getString(cursor.getColumnIndex("diseaseClassificationName")));
                    dto.setTags(cursor.getString(cursor.getColumnIndex("tags")));
                    dto.setImageUrls(cursor.getString(cursor.getColumnIndex("imageUrls")));
                    dto.setLatLongValues(cursor.getString(cursor.getColumnIndex("latLongValues")));
                    dto.setAddress(cursor.getString(cursor.getColumnIndex("address")));
                    dto.setImgTotCount(cursor.getInt(cursor.getColumnIndex("imgTotCount")));
                    dto.setStatus(cursor.getInt(cursor.getColumnIndex("status")));
                    dto.setServerId(cursor.getInt(cursor.getColumnIndex("serverId")));
                    dto.setTransactionTime(cursor.getString(cursor.getColumnIndex("transactionTime")));

                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return cropData;
    }

}
