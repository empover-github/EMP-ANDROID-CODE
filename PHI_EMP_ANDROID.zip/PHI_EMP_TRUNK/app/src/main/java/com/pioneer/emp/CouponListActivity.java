package com.pioneer.emp;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.adapters.CouponListAdapter;
import com.pioneer.emp.dto.CouponBookletDTO;
import com.pioneer.emp.dto.CouponListDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.CouponsListResponse;
import com.pioneer.emp.models.PravaktaAssistanceOtpModel;
import com.pioneer.emp.models.PravaktaCouponSharedResponse;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;

/**
 * Created by hareesh.a on 7/11/2017.
 */

public class CouponListActivity extends BaseActivity implements OnBookletClickListener {
    RecyclerView recyclerview;
    Toolbar toolbar;
    private CouponBookletDTO couponbookletDTO;
    private ArrayList<CouponListDTO> couponlistDTO;
    private CouponListAdapter couponlistAdapter;
    private PravaktaAssistanceOtpModel pravaktaDetailsBundle;
    String pravakthaId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_activity_coupon_list);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null && bundle.containsKey("couponList")) {
            couponbookletDTO = (CouponBookletDTO) bundle.getSerializable("couponList");
        }
        if (bundle != null && bundle.containsKey("pravaktaDetails")) {
           // pravaktaDetailsBundle = (PravaktaAssistanceOtpModel) bundle.getSerializable("pravaktaDetails");
            pravakthaId = (String) bundle.getSerializable("pravaktaDetails");
        }
        initToolBar();
        recyclerview = findViewById(R.id.cl_recycler_view);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerview.setLayoutManager(layoutManager);
        couponlistDTO = couponbookletDTO.getCouponList();
        couponlistAdapter = new CouponListAdapter(this, couponlistDTO, this);
        recyclerview.setAdapter(couponlistAdapter);

    }

    public void initToolBar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(0xFFFFFFFF);
        getSupportActionBar().setTitle(couponbookletDTO.getCrop() + " " + "-" + " " + couponbookletDTO.getSeason() + " " + "-" + " " + couponbookletDTO.getYear());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        switch (view.getId()) {
            case R.id.cl_coupon_details:
                informationShowOTPPopup(position, CouponListActivity.this);
                break;
            case R.id.cl_coupon_share:
                showOTPPopup(position, CouponListActivity.this);
                break;
        }
    }

    public void showOTPPopup(final int position, final Context mContext) {

        final Button mshareBtn, mcancelBtn;
        final EditText mEditText;

        final Dialog mDialog = Utils.getDialog(mContext, R.layout.emp_popup_share_btn);
        mDialog.setCancelable(true);
        mDialog.setCanceledOnTouchOutside(true);

        ViewGroup root = mDialog
                .findViewById(R.id.rc_parent_view_for_font);

        mEditText = mDialog.findViewById(R.id.cl_mobile_no);
        mshareBtn = mDialog.findViewById(R.id.cl_share_btn);
        mcancelBtn = mDialog.findViewById(R.id.cancel_btn);
        mcancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mshareBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (Utils.isNetworkConnection(CouponListActivity.this)) {
                    if (mEditText.getText().toString().trim().length() >= 10) {
                        CouponListDTO couponDTO = couponlistDTO.get(position);
                        APIRequestHandler.getInstance().getPravaktaCouponShareResponse(CouponListActivity.this, mEditText.getText().toString(), couponDTO.getCouponId(), /*pravaktaDetailsBundle.getPravaktaId()*/pravakthaId, CouponListActivity.this);
                        mDialog.dismiss();
                    } else {
                        DialogManager.showToast(mContext, "Enter valid mobile number");
                    }

                } else {
                    DialogManager.showToast(getApplicationContext(), getString(R.string.no_internet));
                }

            }
        });
        mDialog.show();

    }

    public void informationShowOTPPopup(final int position, final Context mContext) {

        final Button mokBtn;
        final TextView headertxt, resposetxt, datetxt;
        final LinearLayout namelinear, mobilelinear;

        final Dialog mDialog = Utils.getDialog(mContext, R.layout.emp_popup_information_share_btn);
        mDialog.setCancelable(false);
        mDialog.setCanceledOnTouchOutside(false);

        ViewGroup root = mDialog
                .findViewById(R.id.pr_parent_view_for_font);

        headertxt = mDialog.findViewById(R.id.pr_sharedBy_txt);
        resposetxt = mDialog.findViewById(R.id.pr_sharedByMobileNo_txt);
        datetxt = mDialog.findViewById(R.id.pr_sharedByDate_txt);
        mokBtn = mDialog.findViewById(R.id.pr_ok_btn);
        namelinear = mDialog.findViewById(R.id.cl_linear_inform_name);
        mobilelinear = mDialog.findViewById(R.id.cl_linear_inform_mobile);

        CouponListDTO couponDTO = couponlistDTO.get(position);
        if (couponDTO.getSharedToName() == null) {
            namelinear.setVisibility(View.GONE);
        } else {
            headertxt.setText(couponDTO.getSharedToName());
        }
        resposetxt.setText(couponDTO.getSharedToMobileNo());
        datetxt.setText(couponDTO.getSharedOn());
        mokBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                mDialog.dismiss();
            }
        });
        mDialog.show();

    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);
        if (responseObj != null) {
            if (responseObj instanceof PravaktaCouponSharedResponse) {
                PravaktaCouponSharedResponse pravaktaCouponSharedResponse = (PravaktaCouponSharedResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == pravaktaCouponSharedResponse.getStatusCode()) {
                    CouponsListResponse CouoponModel = pravaktaCouponSharedResponse.getResponseObj();
                    couponlistDTO.clear();
                    couponlistDTO.addAll(CouoponModel.getCouponList());
                    couponlistAdapter.notifyDataSetChanged();
                } else if (AppConstants.ALREADY_COUPON_ALLOTED_CODE == pravaktaCouponSharedResponse.getStatusCode()) {
                    DialogManager.showToast(CouponListActivity.this, pravaktaCouponSharedResponse.getMessage());
                } else if (AppConstants.COUPON_ALREADY_USED_CODE == pravaktaCouponSharedResponse.getStatusCode()) {
                    DialogManager.showToast(CouponListActivity.this, pravaktaCouponSharedResponse.getMessage());
                } else if (AppConstants.COUPON_CAN_BE_SHARED_TO_FARMER_ONLY_CODE == pravaktaCouponSharedResponse.getStatusCode()) {
                    DialogManager.showToast(CouponListActivity.this, pravaktaCouponSharedResponse.getMessage());
                } else {
                    DialogManager.showToast(CouponListActivity.this, pravaktaCouponSharedResponse.getMessage());
                }

            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}

