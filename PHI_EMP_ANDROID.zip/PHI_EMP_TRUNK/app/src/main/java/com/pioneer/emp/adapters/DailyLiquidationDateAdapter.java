package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dto.DailyLiquidationTopTenRetailersVolumeDTO;
import com.pioneer.parivaar.apiInterfaces.OnEditTextChanged;

import java.util.List;

public class DailyLiquidationDateAdapter extends RecyclerView.Adapter<DailyLiquidationDateAdapter.DailyLiqDateHolder> {
    private Context context;
    private List<DailyLiquidationTopTenRetailersVolumeDTO> dailyLiqdateList;

    private OnEditTextChanged onEditTextChanged;

    public DailyLiquidationDateAdapter(Context mContext, List<DailyLiquidationTopTenRetailersVolumeDTO> retailersData, OnEditTextChanged onEditTextChanged) {
        this.context = mContext;
        this.dailyLiqdateList = retailersData;
        this.onEditTextChanged = onEditTextChanged;
    }

    @NonNull
    @Override
    public DailyLiqDateHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View myHolder = LayoutInflater.from(parent.getContext()).inflate(R.layout.daily_liquidation_date_item_list, parent, false);
        return new DailyLiqDateHolder(myHolder);
    }

    @Override
    public int getItemCount() {
        return dailyLiqdateList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(DailyLiqDateHolder holder, int position) {

        holder.bind(dailyLiqdateList.get(position), position);

        holder.etPioneer.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                onEditTextChanged.onTextChanged(R.id.dl_item_pioneerET, position, holder.etPioneer.getText().toString());
            }
        });

        holder.etComp1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                onEditTextChanged.onTextChanged(R.id.dl_item_comp1ET, position, holder.etComp1.getText().toString());
            }
        });

        holder.etComp2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                onEditTextChanged.onTextChanged(R.id.dl_item_comp2ET, position, holder.etComp2.getText().toString());
            }
        });

        holder.etOthers.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                onEditTextChanged.onTextChanged(R.id.dl_item_othersET, position, holder.etOthers.getText().toString());
            }
        });

    }

    public class DailyLiqDateHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvFirmName;
        EditText etPioneer, etComp1, etComp2, etOthers;

        DailyLiqDateHolder(View itemView) {
            super(itemView);
            tvFirmName = itemView.findViewById(R.id.dl_item_companyNameTv);
            etPioneer = itemView.findViewById(R.id.dl_item_pioneerET);
            etComp1 = itemView.findViewById(R.id.dl_item_comp1ET);
            etComp2 = itemView.findViewById(R.id.dl_item_comp2ET);
            etOthers = itemView.findViewById(R.id.dl_item_othersET);

        }

        @Override
        public void onClick(View v) {
            /*listener.onItemClick(v, getAdapterPosition());*/
        }

        public void bind(final DailyLiquidationTopTenRetailersVolumeDTO dto, int position) {
            if (dto != null) {
                tvFirmName.setText(dto.getRetailerFirmName() + " : " + dto.getRetailerMobileNumber());
            }
        }
    }

}
