package com.pioneer.emp.customviews;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Marker;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.google.maps.android.ui.IconGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;
import com.pioneer.emp.farmservices.models.MyItem;
import com.pioneer.emp.R;
import com.pioneer.emp.listeners.CustomClusterMarkerListener;
import com.pioneer.parivaar.activities.MyApplication;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by zak on 8/23/2016.
 */
public class ReportRenderer extends DefaultClusterRenderer<MyItem> {
    private final int mDimension;
    private final int mPadding;
    private final DisplayImageOptions options;
    private final ImageView mClusterImageView;
    private final IconGenerator mClusterIconGenerator;
    private final ImageView mClusterItemImageView;
    private final IconGenerator mClusterItemIconGenerator;
    private final ImageLoaderConfiguration config;
    private LayoutInflater inflater;
    public CustomClusterMarkerListener customClusterMarkerListener;


    //Set for holding a reference to marker targets --> targets won't get carbage collected during looping and loading images
    Set<ClusterItemMarkerTarget> myClusterItemMarkerTargets = new HashSet<>();
    Set<ClusterMarkerTarget>     myClusterMarkerTargets  = new HashSet<>();
    private int clustersize;

    public ReportRenderer(ClusterManager<MyItem> mClusterManager, GoogleMap map, CustomClusterMarkerListener customClusterMarkerListener) {
        super(MyApplication.mInstance, map, mClusterManager);
        this.customClusterMarkerListener = customClusterMarkerListener;
        inflater = (LayoutInflater) MyApplication.mInstance.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        mDimension  = (int) MyApplication.mInstance.getResources().getDimension(R.dimen.custom_profile_image);
        mPadding    = (int) MyApplication.mInstance.getResources().getDimension(R.dimen.custom_profile_padding);

        // initialize cluster icon generator
        View multiReport = inflater.inflate(R.layout.multi_profile, null);
        mClusterImageView = multiReport.findViewById(R.id.image);
        mClusterIconGenerator = new IconGenerator(MyApplication.mInstance);
        mClusterIconGenerator.setContentView(multiReport);

        // initialize cluster item icon generator
        mClusterItemImageView = new ImageView(MyApplication.mInstance);
        mClusterItemImageView.setLayoutParams(new ViewGroup.LayoutParams(mDimension, mDimension));
        mClusterItemImageView.setPadding(mPadding, mPadding, mPadding, mPadding);
        mClusterItemIconGenerator = new IconGenerator(MyApplication.mInstance);
        mClusterItemIconGenerator.setContentView(mClusterItemImageView);

        // initialize image loader
        options = new DisplayImageOptions.Builder()
//                .showImageOnLoading(R.drawable.loading)
//                .showImageForEmptyUri(R.drawable.warning)
//                .showImageOnFail(R.drawable.fail)
//                Dummy commented image loading cases
                .showImageOnLoading(R.drawable.marker_icon)
                .showImageForEmptyUri(R.drawable.marker_icon)
                .showImageOnFail(R.drawable.marker_icon)
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .considerExifParams(true)
                //.bitmapConfig(Bitmap.Config.RGB_565)
                .build();
        config = new ImageLoaderConfiguration.Builder(MyApplication.mInstance)
                .defaultDisplayImageOptions(options)
                .build();
        ImageLoader.getInstance().init(config);
    }

    @Override
    protected void onClusterItemRendered(MyItem clusterItem, Marker marker) {

        final ClusterItemMarkerTarget pm_ClusterItem = new ClusterItemMarkerTarget(marker);

        myClusterItemMarkerTargets.add(pm_ClusterItem);

        HardRefSimpleImageLoadingListener loadingListener = new HardRefSimpleImageLoadingListener() {
            @Override
            public void onLoadingFailed(String s, View view, FailReason failReason) {
                myClusterItemMarkerTargets.remove(pm_ClusterItem);
            }

            @Override
            public void onLoadingComplete(String s, View view, Bitmap bitmap) {
                mClusterItemImageView.setImageBitmap(bitmap);
                pm_ClusterItem.myIcon_cluster = mClusterItemIconGenerator.makeIcon();
                pm_ClusterItem.mMarker.setIcon(BitmapDescriptorFactory.fromBitmap(pm_ClusterItem.myIcon_cluster));
                myClusterItemMarkerTargets.remove(pm_ClusterItem);
            }

            @Override
            public void onLoadingCancelled(String s, View view) {
                myClusterItemMarkerTargets.remove(pm_ClusterItem);
            }
        };

        ImageLoader.getInstance().displayImage(clusterItem.getMarkerUrl(), pm_ClusterItem.myClusterItemImageView ,   loadingListener );

        customClusterMarkerListener.onClusterMarkerAdd(clusterItem, marker);
        super.onClusterItemRendered(clusterItem, marker);
    }

    @Override
    protected void onClusterRendered(Cluster<MyItem> cluster, Marker marker) {

        int i=0;
        clustersize = cluster.getSize();

        final ClusterMarkerTarget pm_Cluster = new ClusterMarkerTarget(marker, cluster);
        marker.setTag("cluster");
        myClusterMarkerTargets.add(pm_Cluster);

        for (MyItem r : cluster.getItems()) {
            // Draw 1 at most.
            if (i == 1 ) {
                break;
            }

            HardRefSimpleImageLoadingListener loadingListener = new HardRefSimpleImageLoadingListener() {

                @Override
                public void onLoadingFailed(String s, View view, FailReason failReason) {
                    myClusterMarkerTargets.remove(pm_Cluster);
                }

                @Override
                public void onLoadingComplete(String s, View view, Bitmap bitmap) {
                    mClusterImageView.setImageBitmap(bitmap); // = (ImageView) view; //pm.myClusterImageView;
                    pm_Cluster.myIcon_clusterItem = mClusterIconGenerator.makeIcon(String.valueOf(clustersize));
                    pm_Cluster.myMarker.setIcon(BitmapDescriptorFactory.fromBitmap(pm_Cluster.myIcon_clusterItem));
                    myClusterMarkerTargets.remove(pm_Cluster);
                }

                @Override
                public void onLoadingCancelled(String s, View view) {
                    myClusterMarkerTargets.remove(pm_Cluster);
                }
            };

            ImageLoader.getInstance().displayImage(r.getMarkerUrl(), pm_Cluster.myClusterImageView, loadingListener);

            i++;
        }
    }

    //cluster marker with image loaded by Ultimate Image Loader

    //cluster item marker with image loaded by Ultimate Image Loader
    class ClusterItemMarkerTarget {

        Marker mMarker;
        ImageView myClusterItemImageView;
        public Bitmap myIcon_cluster;

        public ClusterItemMarkerTarget(Marker marker) {
            mMarker = marker;
            myClusterItemImageView =  new ImageView(MyApplication.mInstance);
            myClusterItemImageView.setLayoutParams(new ViewGroup.LayoutParams(mDimension, mDimension));
            int padding = (int) MyApplication.mInstance.getResources().getDimension(R.dimen.custom_profile_padding);
            myClusterItemImageView.setPadding(padding, padding, padding, padding);
        }
    }

    class ClusterMarkerTarget {

        Marker myMarker;
        ImageView myClusterImageView;
        public Bitmap myIcon_clusterItem;

        public ClusterMarkerTarget(Marker marker, Cluster<MyItem> cluster) {
            myMarker = marker;
            View multiReport = inflater.inflate(R.layout.multi_profile, null);
            myClusterImageView = multiReport.findViewById(R.id.image);
        }
    }

    class HardRefSimpleImageLoadingListener extends SimpleImageLoadingListener {
        public ImageView mView;

        @Override
        public void onLoadingStarted(String imageUri, View view) {
            mView = (ImageView) view;
        }
    }

}