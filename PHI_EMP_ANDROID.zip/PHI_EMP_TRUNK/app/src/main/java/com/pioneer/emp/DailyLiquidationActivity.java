package com.pioneer.emp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.utility.Utility;
import com.google.gson.Gson;
import com.pioneer.emp.adapters.CropAdapter;
import com.pioneer.emp.adapters.DailyLiquidationAdapter;
import com.pioneer.emp.dao.CompetitorMasterDAO;
import com.pioneer.emp.dao.CropMasterDAO;
import com.pioneer.emp.dao.SeasonMasterDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.DailyLiquidationDownloadDTO;
import com.pioneer.emp.models.DailyLiquidationModel;
import com.pioneer.emp.models.LiquidSeasonIds;
import com.pioneer.emp.models.LiquidationCalendarList;
import com.pioneer.emp.models.LiquidationDetailsResponseModel;
import com.pioneer.emp.models.LiquidationMasterResponse;
import com.pioneer.emp.models.UpdateDailyLiquidationModel;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.listeners.DialogMangerCallback;
import com.pioneer.parivaar.model.IdNameModel;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static com.pioneer.parivaar.utils.DialogManager.getDialog;


public class DailyLiquidationActivity extends BaseActivity implements OnBookletClickListener {
    private RecyclerView recyclerView;
    private DailyLiquidationAdapter dailyLiquidationAdapter;
    private DailyLiquidationActivity dailyLiquidationActivity;
    private ArrayList<IdNameModel> seasonList = new ArrayList<>();
    private CropAdapter seasonAdapter, cropAdapter, comp1Adapter, comp2Adapter;
    private List<IdNameModel> competitor1List = new ArrayList<>();
    private List<IdNameModel> competitor2List = new ArrayList<>();
    private List<IdNameModel> competitorOriginalList = new ArrayList<>();
    private List<IdNameModel> cropList = new ArrayList<>();
    private String enteredDate = null;
    public Dialog dialog;
    private String convertEnteredDate = null;
    private String convertEnteredEndDate = null;
    private Spinner myDialogSpnYear, myDialogSpnSeason, myDialogSpnCrop, myDialogSpnCompetitor1, myDialogSpnCompetitor2, myDialogSpnStatus;
    private EditText myDialogStartDate, myDialogEndDate;
    private Button myDialogBtnCreate, myDialogCancelBtn;
    private String startDate, endDate, latLongValues;
    private long seasonId, cropId, competitor1_id, competitor2_id;
    private ArrayList<DailyLiquidationDownloadDTO> liquidationDaily = new ArrayList<>();
    private static Dialog myDialog;
    private TextView tvNoCalendar;
    private LinearLayout noCalendarDataLL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_daily_liquidation);
        recyclerView = findViewById(R.id.recyle_liquidation);
        noCalendarDataLL = findViewById(R.id.layout_no_calendar);
        tvNoCalendar = findViewById(R.id.tv_daily_no_calendar);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(dailyLiquidationActivity);
        recyclerView.setLayoutManager(layoutManager);

        dailyLiquidationAdapter = new DailyLiquidationAdapter(DailyLiquidationActivity.this, liquidationDaily, this);
        recyclerView.setAdapter(dailyLiquidationAdapter);

        checkNoData();

        dailyLiquidationActivity = this;
        initializationView();
        if (checkLocPermission()) {
            if (Utility.checkPlayServices(dailyLiquidationActivity)) {
                buildGoogleApiClient();
            }
        }
        callMasterData();
        callDailyLiquidationList();

    }

    private void checkNoData() {
        if (liquidationDaily != null && liquidationDaily.size() > 0) {
            noCalendarDataLL.setVisibility(View.GONE);
        } else {
            noCalendarDataLL.setVisibility(View.VISIBLE);
        }
    }

    // if already calenders created
    private void callDailyLiquidationList() {
        if (Utility.networkAvailability(dailyLiquidationActivity)) {
            DailyLiquidationModel model = new DailyLiquidationModel();
            model.setMobileNumber(Utils.getUserMobile(dailyLiquidationActivity));
            model.setVersionName(Utils.getAppVersionName(dailyLiquidationActivity));
            model.setEmpId(Utils.getUserId(dailyLiquidationActivity));
            model.setDeviceType(AppConstants.DEVICE_TYPE_ANDROID);
            Gson gson = new Gson();
            String data = gson.toJson(model);

            String jwtToken = Utils.getJWTToken(data, dailyLiquidationActivity);
            APIRequestHandler.getInstance().getDailyLiquidationList(dailyLiquidationActivity, jwtToken, this, true);
        } else {
            DialogManager.showToast(dailyLiquidationActivity, getString(R.string.checkNetwork));
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (geoLocation == null) {
            if (checkLocPermission())
                getCurrentLocation(dailyLiquidationActivity);
        }
    }

    @Override
    public void refresh() {
        onLocationReceived(geoLocation);
    }


    private void callMasterData() {
        if (Utility.networkAvailability(dailyLiquidationActivity)) {
            DailyLiquidationModel model = new DailyLiquidationModel();
            model.setMobileNumber(Utils.getUserMobile(dailyLiquidationActivity));
            model.setVersionName(Utils.getAppVersionName(dailyLiquidationActivity));
            model.setEmpId(Utils.getUserId(dailyLiquidationActivity));
            model.setDeviceType(AppConstants.DEVICE_TYPE_ANDROID);
            Gson gson = new Gson();
            String data = gson.toJson(model);
            String jwtToken = Utils.getJWTToken(data, dailyLiquidationActivity);
            APIRequestHandler.getInstance().SyncMasterDataForDailyLiquidation(dailyLiquidationActivity, jwtToken, this, true);
        } else {
            DialogManager.showToast(dailyLiquidationActivity, getString(R.string.checkNetwork));
        }
    }

    public void onLocationReceived(String location) {
        if (location != null && !location.isEmpty()) {
            String lat = location.split(",")[0];
            String lon = location.split(",")[1];
            //  sendLoctionValues(lat, lon);

        }
    }

    private boolean checkLocPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return ActivityCompat.checkSelfPermission(dailyLiquidationActivity, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return true;
        }
    }

    private void initializationView() {
        Toolbar myToolBar = findViewById(R.id.toolbar);
        setSupportActionBar(myToolBar);

        TextView lblTitle = findViewById(R.id.header_text);
        ImageView imgBackNav = findViewById(R.id.imgBacknav);
        imgBackNav.setVisibility(View.VISIBLE);
        lblTitle.setVisibility(View.VISIBLE);
        lblTitle.setText(getString(R.string.daily_liquidation));
        ImageView imageAddSurvey = findViewById(R.id.daily_liq_addBtn);
        imageAddSurvey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopWindowForSeason();
            }
        });
        imgBackNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        /*imgBackNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });*/

    }

    private void showPopWindowForSeason() {
        myDialog = getDialog(DailyLiquidationActivity.this, R.layout.popup_create_season);
        myDialog.setCancelable(false);
        myDialog.setCanceledOnTouchOutside(false);

        myDialogSpnYear = myDialog.findViewById(R.id.spn_year);
        myDialogSpnSeason = myDialog.findViewById(R.id.spn_season);
        myDialogSpnCrop = myDialog.findViewById(R.id.spn_crop);
        myDialogSpnCompetitor1 = myDialog.findViewById(R.id.spn_comp1);
        myDialogSpnCompetitor2 = myDialog.findViewById(R.id.spn_comp2);
        myDialogStartDate = myDialog.findViewById(R.id.etStartDate);
        myDialogEndDate = myDialog.findViewById(R.id.etEndDate);
        myDialogCancelBtn = myDialog.findViewById(R.id.cancel_btn_liq);
        //newly added
        myDialogSpnStatus = myDialog.findViewById(R.id.spn_status);
        myDialogCancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myDialog != null) {
                    if (isDataAvailable()) {
                        goBack();
                    } else {
                        myDialog.dismiss();
                    }
                }

            }
        });
        ArrayList<String> yearList = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);

        yearList.add(String.valueOf(year));
        yearList.add(String.valueOf(year + 1));
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(dailyLiquidationActivity, android.R.layout.simple_spinner_item, yearList);
        myDialogSpnYear.setAdapter(yearAdapter);
        //newly added


        List<DTO> seasonDTOList = SeasonMasterDAO.getInstance().getRecords(com.pioneer.emp.dbHandler.DBHandler.getReadableDb(this));
        seasonList.clear();
        seasonList.add(new IdNameModel(getString(R.string.select)));
        if (seasonDTOList != null && seasonDTOList.size() > 0) {
            for (DTO dto : seasonDTOList) {
                seasonList.add((IdNameModel) dto);
            }
        }
        seasonAdapter = new CropAdapter(dailyLiquidationActivity, seasonList);
        myDialogSpnSeason.setAdapter(seasonAdapter);

        List<DTO> competitorDTOList = CompetitorMasterDAO.getInstance().getRecords(com.pioneer.emp.dbHandler.DBHandler.getReadableDb(this));
        if (competitorDTOList != null && competitorDTOList.size() > 0) {
            competitor1List.clear();
            competitorOriginalList.clear();
            competitor1List.add(new IdNameModel(getString(R.string.select_company)));
            for (DTO dto : competitorDTOList) {
                IdNameModel competitorMasterDTO = (IdNameModel) dto;
                competitorOriginalList.add(competitorMasterDTO);
                competitor1List.add(competitorMasterDTO);
            }
        }
        comp1Adapter = new CropAdapter(dailyLiquidationActivity, competitor1List);

//        competitor2List.clear();
//        competitor2List.addAll(competitor1List);
//        comp2Adapter = new CropAdapter(dailyLiquidationActivity, competitor2List);

        myDialogSpnCompetitor1.setAdapter(comp1Adapter);
        // myDialogSpnCompetitor2.setAdapter(comp1Adapter);

        myDialogSpnSeason.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cropList.clear();
                if (position > 0) {
                    IdNameModel data = seasonList.get(position);
                    myDialogSpnSeason.setTag(data);

                    List<DTO> cropDTOList = CropMasterDAO.getInstance().getRecordById(data.getId(), com.pioneer.emp.dbHandler.DBHandler.getReadableDb(dailyLiquidationActivity));
                    cropList.add(new IdNameModel(getString(R.string.select)));
                    if (cropDTOList != null && cropDTOList.size() > 0) {
                        for (com.pioneer.parivaar.dto.DTO cropDto : cropDTOList) {
                            LiquidSeasonIds cropMasterDTO = (LiquidSeasonIds) cropDto;
                            cropList.add(cropMasterDTO);
                        }
                        cropAdapter = new CropAdapter(dailyLiquidationActivity, cropList);
                        myDialogSpnCrop.setAdapter(cropAdapter);
                    }
                } else {
                    myDialogSpnSeason.setTag(null);
                }
                if (cropAdapter != null)
                    cropAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        myDialogSpnCrop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    myDialogSpnCrop.setTag(cropList.get(position));
                } else {
                    myDialogSpnCrop.setTag(null);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        myDialogSpnCompetitor1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // IdNameModel data = competitor1List.get(position - 1);
                competitor2List.clear();
                competitor2List.add(new IdNameModel(getString(R.string.select_company)));
                if (position != 0) {
                    competitor2List.addAll(competitorOriginalList);
                    IdNameModel data = competitor1List.get(position);
                    competitor2List.remove(data);
                    myDialogSpnCompetitor1.setTag(data);
                } else {
                    myDialogSpnCompetitor1.setTag(null);
                }
                myDialogSpnCompetitor2.setSelection(0);
                comp2Adapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        comp2Adapter = new CropAdapter(dailyLiquidationActivity, competitor2List);
        myDialogSpnCompetitor2.setAdapter(comp2Adapter);

        myDialogSpnCompetitor2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    // IdNameModel data = competitor1List.get(position - 1);
                    IdNameModel data = competitor2List.get(position);
                    myDialogSpnCompetitor2.setTag(data);
                } else {
                    myDialogSpnCompetitor2.setTag(null);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        myDialogBtnCreate = myDialog.findViewById(R.id.daily_liq_create);

        myDialogStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enteredDate = null;
                myDialogEndDate.setText("");
                showDatePickerPopup("Select start date", myDialogStartDate.getText().toString().trim(), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startDate = (String) v.getTag();
                        myDialogStartDate.setText(((String) v.getTag()));
                    }
                });
            }
        });
        myDialogEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enteredDate = null;

                if (myDialogStartDate.getText().toString().equals("") || myDialogStartDate.getText().toString() == null) {
                    DialogManager.showToast(dailyLiquidationActivity, "Please select start date");
                } else {
                    String endDate2 = myDialogEndDate.getText().toString();
                    String startDate2 = myDialogStartDate.getText().toString();
                    if (Utils.isValidStr(startDate)) {
                        showDatePickerPopupByEnd("Select end date", /*myDialogStartDate*/myDialogEndDate.getText().toString().trim(), new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                endDate = (String) v.getTag();
                                myDialogEndDate.setText(((String) v.getTag()));
                            }
                        });

                    }

                }


            }
        });
        myDialogBtnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String liquidationsValidation = dailyLiquidationsValidation();
                if (liquidationsValidation == null) {
                    if (Utils.isNetworkConnection(dailyLiquidationActivity)) {
                        if (geoLocation == null) {
                            if (checkLocPermission())
                                getCurrentLocation(dailyLiquidationActivity);
                        } else {
                            DailyLiquidationModel liquidationDto = new DailyLiquidationModel();
                            seasonId = ((IdNameModel) myDialogSpnSeason.getTag()).getId();
                            cropId = ((IdNameModel) myDialogSpnCrop.getTag()).getId();
                            competitor1_id = ((IdNameModel) myDialogSpnCompetitor1.getTag()).getId();
                            competitor2_id = ((IdNameModel) myDialogSpnCompetitor2.getTag()).getId();

                            liquidationDto.setMobileNumber(Utils.getUserMobile(dailyLiquidationActivity));
                            liquidationDto.setEmpId(Utils.getUserId(dailyLiquidationActivity));
                            liquidationDto.setVersionName(Utils.getVersionName(dailyLiquidationActivity));
                            liquidationDto.setDeviceType(AppConstants.DEVICE_TYPE_ANDROID);
                            liquidationDto.setYear(myDialogSpnYear.getSelectedItem().toString());
                            liquidationDto.setSeasonId(seasonId);
                            liquidationDto.setCropId(cropId);

                            liquidationDto.setStartDate(getServerConvertString(startDate));
                            liquidationDto.setEndDate(getServerConvertString(endDate));
                            liquidationDto.setCompetitor1Id(competitor1_id);
                            liquidationDto.setCompetitor2Id(competitor2_id);
                            liquidationDto.setGeoLocation(geoLocation);
                            //new added
                            if (myDialogSpnStatus.getSelectedItem().toString().equalsIgnoreCase("Active")) {
                                liquidationDto.setStatus(true);
                            } else {
                                liquidationDto.setStatus(false);
                            }
                            getLiquidationData(liquidationDto);
                        }


                    } else {
                        DialogManager.showToast(DailyLiquidationActivity.this, getString(R.string.no_internet));
                    }


                } else {
                    DialogManager.showSingleBtnPopup(dailyLiquidationActivity, null, getString(R.string.alert), liquidationsValidation, getString(R.string.ok));
                }

            }

        });
        myDialog.show();
    }

    private void getLiquidationData(DailyLiquidationModel liquidationDto) {
        Gson gson = new Gson();
        String data = gson.toJson(liquidationDto);
        String jwtToken = Utils.getJWTToken(data, dailyLiquidationActivity);
        APIRequestHandler.getInstance().getDailyLiquidationListDetails(dailyLiquidationActivity, jwtToken, dailyLiquidationActivity, true);

    }

    private void getUpdateLiquidationData(UpdateDailyLiquidationModel liquidationDto) {
        Gson gson = new Gson();
        String data = gson.toJson(liquidationDto);
        String jwtToken = Utils.getJWTToken(data, dailyLiquidationActivity);
        APIRequestHandler.getInstance().getUpdateDailyLiquidationListDetails(dailyLiquidationActivity, jwtToken, dailyLiquidationActivity, true);

    }

    private String dailyLiquidationsValidation() {
        if (myDialogSpnSeason.getSelectedItemPosition() == 0) {
            return getString(R.string.please_select_season_error);
        }
        if (myDialogSpnCrop.getSelectedItemPosition() == 0) {
            return getString(R.string.please_select_crop_error);
        }
        if (getEdtText(myDialogStartDate).isEmpty()) {
            return getString(R.string.please_select_start_date);
        }
        if (getEdtText(myDialogEndDate).isEmpty()) {
            return getString(R.string.please_select_end_date);
        }
        if (myDialogSpnCompetitor1.getSelectedItemPosition() == 0) {
            return getString(R.string.please_select_comp1);
        }
        if (myDialogSpnCompetitor2.getSelectedItemPosition() == 0) {
            return getString(R.string.please_select_comp2);
        }

        if (myDialogSpnStatus.getSelectedItemPosition() == 0) {
            return getString(R.string.please_select_status);
        }
        return null;
    }


    private String updateDailyLiquidationsValidation() {

        if (getEdtText(myDialogEndDate).isEmpty()) {
            return getString(R.string.please_select_end_date);
        }
        if (myDialogSpnStatus.getSelectedItemPosition() == 0) {
            return getString(R.string.please_select_status);
        }
        return null;
    }

    private String getEdtText(EditText editText) {
        return editText.getText().toString().trim();
    }

    private void showDatePickerPopup(String label, String dateStr, final View.OnClickListener listener) {
        enteredDate = dateStr;
        Date date = Utils.formatDateFromStrToDate2(dateStr);
        Calendar myCalendar = Calendar.getInstance();
        myCalendar.setTime(date);

        int mYear = myCalendar.get(Calendar.YEAR);
        int mMonth = myCalendar.get(Calendar.MONTH);
        int mDay = myCalendar.get(Calendar.DAY_OF_MONTH);
        dialog = new Dialog(DailyLiquidationActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.date_picker_dialog);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        TextView textView = dialog.findViewById(R.id.tv_date_label);
        textView.setText(label);
        DatePicker dp = dialog.findViewById(R.id.dp);
        dp.updateDate(mYear, mMonth, mDay);

        int mnt = mMonth + 1;
        enteredDate = String.valueOf(checkDigit(mnt)) + "-" + String.valueOf(checkDigit(mDay)) + "-" + String.valueOf(mYear);
        convertEnteredDate = getDateConvertString(enteredDate);

        Button ok_btn = dialog.findViewById(R.id.btn_calendar_ok);
        Button close = dialog.findViewById(R.id.cancel_btn);
        close.setVisibility(View.VISIBLE);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        Calendar minCalendar = Calendar.getInstance();

        dp.setMinDate(minCalendar.getTimeInMillis());
        dp.init(mYear, mMonth, mDay, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // Do something when the date changed from date picker object
                // Create a Date variable/object with user chosen date
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(0);
                cal.set(year, monthOfYear, dayOfMonth, 0, 0, 0);
                Date chosenDate = cal.getTime();
                // Format the date
                DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
                String formattedDate = df.format(chosenDate);
                int mnth = monthOfYear + 1;
                enteredDate = String.valueOf(checkDigit(mnth)) + "-" + String.valueOf(checkDigit(dayOfMonth)) + "-" + String.valueOf(year);
                // String myDate = getDateConvertString(enteredDate);

                convertEnteredDate = getDateConvertString(enteredDate);
                //view.setTag(enteredDate);
                //listener.onDateChanged(view, year, monthOfYear, dayOfMonth);
            }
        });

        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isValidStr(convertEnteredDate)) {
                    dialog.dismiss();
                    v.setTag(convertEnteredDate);
                    listener.onClick(v);
                } else {
                    DialogManager.showToast(DailyLiquidationActivity.this, "Please select Date");
                }

            }
        });


        dialog.show();
    }

    private void showDatePickerPopupByEnd(String label, String dateStr, final View.OnClickListener listener) {
        enteredDate = dateStr;

        Calendar myCalendar = Calendar.getInstance();
        if (Utils.isValidStr(enteredDate)) {
            Date date = Utils.formatDateFromStrToDate2(enteredDate);
            myCalendar.setTime(date);
        } else {
            Date date = Utils.formatDateFromStrToDate2(startDate);
            myCalendar.setTime(date);
            myCalendar.add(Calendar.DATE, 1);
        }

        // Calendar myCalendar = Calendar.getInstance();
        int mYear = myCalendar.get(Calendar.YEAR);
        int mMonth = myCalendar.get(Calendar.MONTH);
        int mDay = myCalendar.get(Calendar.DAY_OF_MONTH);
        dialog = new Dialog(DailyLiquidationActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.at_date_picker_dialog);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        TextView textView = dialog.findViewById(R.id.tv_date_label);
        textView.setText(label);
        DatePicker dp = dialog.findViewById(R.id.dp);
        dp.updateDate(mYear, mMonth, mDay);

        int mnth = mMonth + 1;
        enteredDate = String.valueOf(checkDigit(mnth)) + "-" + String.valueOf(checkDigit(mDay)) + "-" + String.valueOf(mYear);
        convertEnteredEndDate = Utils.formatUpdateDate(enteredDate);


        Button ok_btn = dialog.findViewById(R.id.btn_calendar_ok);
        Button close = dialog.findViewById(R.id.cancel_btn);
        close.setVisibility(View.VISIBLE);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        Calendar maxCalendar = Calendar.getInstance();
        maxCalendar.add(Calendar.DATE, 1);

        if (Utils.isValidStr(startDate)) {
            Calendar c = Calendar.getInstance();
            Date date = Utils.formatDateFromStrToDate2(startDate);
            c.setTime(date);
            c.add(Calendar.DATE, 1);
            dp.setMinDate(c.getTimeInMillis());
//            dp.setMinDate(Utils.convertStrMonToMilliSeconds(startDate));

        }

        dp.init(mYear, mMonth, mDay, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // Do something when the date changed from date picker object
                // Create a Date variable/object with user chosen date
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(0);
                cal.set(year, monthOfYear, dayOfMonth, 0, 0, 0);
                Date chosenDate = cal.getTime();
                // Format the date
                DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
                String formattedDate = df.format(chosenDate);
                int mnth = monthOfYear + 1;
                enteredDate = String.valueOf(checkDigit(mnth)) + "-" + String.valueOf(checkDigit(dayOfMonth)) + "-" + String.valueOf(year);
                // String myDate = getDateConvertString(enteredDate);
                convertEnteredEndDate = getDateConvertString(enteredDate);

            }
        });

        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isValidStr(convertEnteredEndDate)) {
                    dialog.dismiss();
                    v.setTag(convertEnteredEndDate);
                    listener.onClick(v);
                } else {
                    DialogManager.showToast(DailyLiquidationActivity.this, "Please select Date");
                }
                //marriage_anniverary_date_ed.setText(enteredDate);
            }
        });

        dialog.show();
    }


    private void showDatePickerPopupByEndListData(String label, String dateStr, final View.OnClickListener listener) {
        enteredDate = dateStr;

        Calendar myCalendar = Calendar.getInstance();
        if (Utils.isValidStr(enteredDate)) {
            Date date = Utils.formatDateFromStrToDate2(enteredDate);
            myCalendar.setTime(date);
        }

        // Calendar myCalendar = Calendar.getInstance();
        int mYear = myCalendar.get(Calendar.YEAR);
        int mMonth = myCalendar.get(Calendar.MONTH);
        int mDay = myCalendar.get(Calendar.DAY_OF_MONTH);
        dialog = new Dialog(DailyLiquidationActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.at_date_picker_dialog);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        TextView textView = dialog.findViewById(R.id.tv_date_label);
        textView.setText(label);
        DatePicker dp = dialog.findViewById(R.id.dp);
        dp.updateDate(mYear, mMonth, mDay);

        int mnth = mMonth + 1;
        enteredDate = String.valueOf(checkDigit(mnth)) + "-" + String.valueOf(checkDigit(mDay)) + "-" + String.valueOf(mYear);
        convertEnteredEndDate = getDateConvertString(enteredDate);


        Button ok_btn = dialog.findViewById(R.id.btn_calendar_ok);
        Button close = dialog.findViewById(R.id.cancel_btn);
        close.setVisibility(View.VISIBLE);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        Calendar maxCalendar = Calendar.getInstance();
        maxCalendar.add(Calendar.DATE, 1);

        Calendar calendar = Calendar.getInstance();
        Date date = Utils.formatDateFromStrToDate2(String.valueOf(calendar.getTime()));
        calendar.setTime(date);
        calendar.add(Calendar.DATE, 0);
        dp.setMinDate(calendar.getTimeInMillis());

        dp.init(mYear, mMonth, mDay, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // Do something when the date changed from date picker object
                // Create a Date variable/object with user chosen date
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(0);
                cal.set(year, monthOfYear, dayOfMonth, 0, 0, 0);
                Date chosenDate = cal.getTime();
                // Format the date
                DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
                String formattedDate = df.format(chosenDate);
                int mnth = monthOfYear + 1;
                enteredDate = String.valueOf(checkDigit(mnth)) + "-" + String.valueOf(checkDigit(dayOfMonth)) + "-" + String.valueOf(year);
                // String myDate = getDateConvertString(enteredDate);
                convertEnteredEndDate = getDateConvertString(enteredDate);

            }
        });

        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utils.isValidStr(convertEnteredEndDate)) {
                    dialog.dismiss();
                    v.setTag(convertEnteredEndDate);
                    listener.onClick(v);
                } else {
                    DialogManager.showToast(DailyLiquidationActivity.this, "Please select Date");
                }
                //marriage_anniverary_date_ed.setText(enteredDate);
            }
        });

        dialog.show();
    }

    public String checkDigit(int number) {
        return number <= 9 ? "0" + number : String.valueOf(number);
    }

    protected void getCurrentLocation(final Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (mGoogleApiClient != null) {
                if (mGoogleApiClient.isConnected()) {
                    mGoogleApiClient.disconnect();
                }
                mGoogleApiClient.connect();
            }
            CountDownTimer start = new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

                @Override
                public void onTick(long millisUntilFinished) {
                    if (geoLocation != null) {
                        latLongValues = geoLocation;
                        hideProgressDialog();

                        this.cancel();
                    }
                }

                @Override
                public void onFinish() {
                    hideProgressDialog();
                    this.cancel();
                }
            }.start();
        } else {
            DialogManager.showSingleBtnPopup(dailyLiquidationActivity, null, getString(com.activitytrack.activity.R.string.alert), getString(com.activitytrack.activity.R.string.gps), getString(com.activitytrack.activity.R.string.ok));
        }
    }

    protected ProgressDialog showProgressDialog1(Context context) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        progressDialog.setTitle("Getting Location");
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        return progressDialog;
    }

    private String getDateConvertString(String convertdate) {
        String date = convertdate;
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        Date myDate = null;
        try {
            myDate = dateFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat timeFormat = new SimpleDateFormat("dd-MMM-yyyy");
        String finaldate = timeFormat.format(myDate);
        return finaldate;
    }

    private String getServerConvertString(String convertDate) {
        String date = convertDate;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        Date myDate = null;
        try {
            myDate = dateFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd");
        String finalDate = timeFormat.format(myDate);
        return finalDate;
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null) {
            if (responseObj instanceof LiquidationMasterResponse) {
                LiquidationMasterResponse masterResponse = (LiquidationMasterResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == masterResponse.getStatusCode()) {
                    String jsonRes = masterResponse.getResponse();
                    LiquidationMasterResponse response = new Gson().fromJson(jsonRes, LiquidationMasterResponse.class);


                    if (response == null)
                        return;
                    processDaiilyLiquationData(dailyLiquidationActivity, response);

                } else {
                    DialogManager.showToast(dailyLiquidationActivity, masterResponse.getRespMsg());
                }
            } else if (responseObj instanceof LiquidationDetailsResponseModel) {
                LiquidationDetailsResponseModel masterResponse = (LiquidationDetailsResponseModel) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == masterResponse.getStatusCode()) {
                    String jsonRes = masterResponse.getResponse();
                    final LiquidationDetailsResponseModel response = new Gson().fromJson(jsonRes, LiquidationDetailsResponseModel.class);

                    if (response == null)
                        return;
                    String message = null;
                    if (masterResponse.isFlag()) {
                        message = getString(R.string.update_liquidation_succ);
                    } else {
                        message = getString(R.string.created_liquidation_succ);
                    }

                    DialogManager.showSingleBtnPopup(dailyLiquidationActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            processDailyListData(response);
                            myDialog.dismiss();
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, getString(R.string.alert), message, getString(R.string.ok));


                } else {
                    DialogManager.showToast(dailyLiquidationActivity, masterResponse.getMessage());
                }
            } else if (responseObj instanceof LiquidationCalendarList) {
                LiquidationCalendarList masterResponse = (LiquidationCalendarList) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == masterResponse.getStatusCode()) {
                    String jsonRes = masterResponse.getResponse();
                    LiquidationCalendarList response = new Gson().fromJson(jsonRes, LiquidationCalendarList.class);
                    if (response == null)
                        return;

                    List<DailyLiquidationDownloadDTO> liquidationDailyDetails = response.getLiquidationCalendarList();
                    liquidationDaily.clear();
                    if (liquidationDailyDetails != null && liquidationDailyDetails.size() > 0) {
                        liquidationDaily.addAll(liquidationDailyDetails);
                    }
                    checkNoData();
                    dailyLiquidationAdapter.notifyDataSetChanged();
                }
            } else {

            }
        }
    }

    private void processDailyListData(LiquidationDetailsResponseModel response) {
        List<DailyLiquidationDownloadDTO> liquidationDailyDetails = response.getLiquidationCalendarList();
        // List<DailyLiquidationDownloadDTO> liquidationDailyDetails = response.getDailyLiquidationCalendar().getLiquidationCalendarList();
        liquidationDaily.clear();
        if (liquidationDailyDetails != null && liquidationDailyDetails.size() > 0) {
            liquidationDaily.addAll(liquidationDailyDetails);
        }
        checkNoData();
        dailyLiquidationAdapter.notifyDataSetChanged();
    }

    private static void processDaiilyLiquationData(DailyLiquidationActivity
                                                           thisActivity, LiquidationMasterResponse response) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("yyyy-MM-dd");
        Utils.setLastSyncedDate(mdformat.format(calendar.getTime()), thisActivity);

        CropMasterDAO.getInstance().deleteTableData(com.pioneer.emp.dbHandler.DBHandler.getWritableDb(thisActivity));
        SeasonMasterDAO.getInstance().deleteTableData(com.pioneer.emp.dbHandler.DBHandler.getWritableDb(thisActivity));
        CompetitorMasterDAO.getInstance().deleteTableData(com.pioneer.emp.dbHandler.DBHandler.getWritableDb(thisActivity));


        //Utils.setLastUpdatedOn(response.getLastUpdatedOn(), thisActivity);
        // Utils.setYearList(response.getYearList(), thisActivity);


        if (response.getCropMaster() != null) {
            for (LiquidSeasonIds ids : response.getCropMaster()) {
                CropMasterDAO.getInstance().insert(ids, DBHandler.getWritableDb(thisActivity));
            }
        }
        if (response.getSeasonMaster() != null) {
            for (IdNameModel ids : response.getSeasonMaster()) {
                SeasonMasterDAO.getInstance().insert(ids, com.pioneer.emp.dbHandler.DBHandler.getWritableDb(thisActivity));
            }
        }
        if (response.getCompetitorMaster() != null) {
            for (IdNameModel ids : response.getCompetitorMaster()) {
                CompetitorMasterDAO.getInstance().insert(ids, com.pioneer.emp.dbHandler.DBHandler.getWritableDb(thisActivity));
            }
        }


    }

    @Override
    public void onBackPressed() {
        finish();
        /*if (isDataAvailable()) {
            goBack();
        } else if (myDialog != null && myDialog.isShowing()) {
            DialogManager.showToast(getApplicationContext(), "Dialog Already Displayed");
        } else {
            finish();
        }*/
        //closeFragment();
    }

    public boolean isDataAvailable() {

        if (myDialogSpnSeason.getSelectedItemPosition() > 0)
            return true;

        if (myDialogSpnCrop.getSelectedItemPosition() > 0)
            return true;

        if (myDialogStartDate.getText().toString().trim().length() > 0)
            return true;

        if (myDialogEndDate.getText().toString().trim().length() > 0)
            return true;

        if (myDialogSpnCompetitor1.getSelectedItemPosition() > 0)
            return true;

        if (myDialogSpnCompetitor2.getSelectedItemPosition() > 0)
            return true;

        return myDialogSpnStatus.getSelectedItemPosition() > 0;
    }

    public void goBack() {
        DialogManager.showConformPopup(dailyLiquidationActivity, new DialogMangerCallback() {
            @Override
            public void onOkClick(View v) {
                if (myDialog != null && myDialog.isShowing()) {
                    myDialog.dismiss();
                }
               /* setResult(RESULT_CANCELED);
                finish();*/
            }

            @Override
            public void onCancelClick(View view) {

            }
        }, getString(R.string.alert), getString(R.string.formExitMsg), getString(R.string.yes), getString(R.string.no));
    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        DailyLiquidationDownloadDTO dto = (DailyLiquidationDownloadDTO) view.getTag();
        showPopWindowForListData(dto);
    }


    private void showPopWindowForListData(DailyLiquidationDownloadDTO listDTO) {
        myDialog = getDialog(DailyLiquidationActivity.this, R.layout.popup_create_click_list_daily_data);
        myDialog.setCancelable(false);
        myDialog.setCanceledOnTouchOutside(false);

        myDialogSpnYear = myDialog.findViewById(R.id.spn_year);
        myDialogSpnSeason = myDialog.findViewById(R.id.spn_season);
        myDialogSpnCrop = myDialog.findViewById(R.id.spn_crop);
        myDialogSpnCompetitor1 = myDialog.findViewById(R.id.spn_comp1);
        myDialogSpnCompetitor2 = myDialog.findViewById(R.id.spn_comp2);
        myDialogStartDate = myDialog.findViewById(R.id.etStartDate);
        myDialogEndDate = myDialog.findViewById(R.id.etEndDate);
        myDialogCancelBtn = myDialog.findViewById(R.id.cancel_btn_liq);
        //newly added
        myDialogSpnStatus = myDialog.findViewById(R.id.spn_status);
        myDialogCancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });


        ArrayList<String> yearList = new ArrayList<>();
        yearList.clear();
        yearList.add(listDTO.getYear());
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(dailyLiquidationActivity, android.R.layout.simple_spinner_item, yearList);
        myDialogSpnYear.setAdapter(yearAdapter);
        myDialogSpnYear.setEnabled(false);
        //newly added


        List<DTO> seasonDTOList = SeasonMasterDAO.getInstance().getRecords(com.pioneer.emp.dbHandler.DBHandler.getReadableDb(this));
        seasonList.clear();
        seasonList.add(new IdNameModel(listDTO.getSeasonName()));
        seasonAdapter = new CropAdapter(dailyLiquidationActivity, seasonList);
        myDialogSpnSeason.setAdapter(seasonAdapter);
        myDialogSpnSeason.setEnabled(false);

        competitor1List.clear();
        competitor1List.add(new IdNameModel(listDTO.getCompetitor1Name()));
        comp1Adapter = new CropAdapter(dailyLiquidationActivity, competitor1List);
        myDialogSpnCompetitor1.setAdapter(comp1Adapter);
        myDialogSpnCompetitor1.setEnabled(false);


        cropList.clear();
        cropList.add(new IdNameModel(listDTO.getCropName()));
        cropAdapter = new CropAdapter(dailyLiquidationActivity, cropList);
        myDialogSpnCrop.setAdapter(cropAdapter);
        myDialogSpnCrop.setEnabled(false);

        competitor2List.clear();
        competitor2List.add(new IdNameModel(listDTO.getCompetitor2Name()));
        comp2Adapter = new CropAdapter(dailyLiquidationActivity, competitor2List);
        myDialogSpnCompetitor2.setAdapter(comp2Adapter);
        myDialogSpnCompetitor2.setEnabled(false);

        myDialogBtnCreate = myDialog.findViewById(R.id.daily_liq_create);
        myDialogStartDate.setText(Utils.formatDateToUser(listDTO.getStartDate()));
        myDialogStartDate.setEnabled(false);


        myDialogEndDate.setText(Utils.formatDateToUser(listDTO.getEndDate()));

        myDialogEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enteredDate = null;
                showDatePickerPopupByEndListData("Select end date", /*myDialogStartDate*/myDialogEndDate.getText().toString().trim(), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        endDate = (String) v.getTag();
                        myDialogEndDate.setText(((String) v.getTag()));
                    }
                });
            }
        });

        ArrayList<String> statusList = new ArrayList<>();
        statusList.clear();
        statusList.add(getString(R.string.select));
        statusList.add("Active");
        statusList.add("Inactive");
        String status;
        if (listDTO.isStatus()) {
            status = "Active";
        } else {
            status = "Inactive";
        }
        ArrayAdapter<String> statusAdapter = new ArrayAdapter<String>(dailyLiquidationActivity, android.R.layout.simple_spinner_item, statusList);
        myDialogSpnStatus.setAdapter(statusAdapter);
        for (int i = 0; i < statusList.size(); i++) {
            if (status.equalsIgnoreCase(statusList.get(i))) {
                myDialogSpnStatus.setSelection(i);
            }
            statusAdapter.notifyDataSetChanged();
        }
        myDialogBtnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updateDailyLiquidationsValidation = updateDailyLiquidationsValidation();
                if (updateDailyLiquidationsValidation == null) {
                    if (Utils.isNetworkConnection(dailyLiquidationActivity)) {
                        UpdateDailyLiquidationModel liquidationDto = new UpdateDailyLiquidationModel();
                        liquidationDto.setMobileNumber(Utils.getUserMobile(dailyLiquidationActivity));
                        liquidationDto.setVersionName(Utils.getVersionName(dailyLiquidationActivity));
                        liquidationDto.setDeviceType(Utils.getDeviceId(dailyLiquidationActivity));
                        liquidationDto.setEmpId(Utils.getUserId(dailyLiquidationActivity));
                        liquidationDto.setCalendarId(listDTO.getCalendarId());
                        liquidationDto.setEndDate(getServerConvertString(myDialogEndDate.getText().toString()));
                        if (myDialogSpnStatus.getSelectedItem().toString().equalsIgnoreCase("Active")) {
                            liquidationDto.setStatus(true);
                        } else {
                            liquidationDto.setStatus(false);
                        }
                        getUpdateLiquidationData(liquidationDto);
                    } else {

                        DialogManager.showToast(DailyLiquidationActivity.this, getString(R.string.no_internet));
                    }
                } else {
                    DialogManager.showSingleBtnPopup(dailyLiquidationActivity, null, getString(R.string.alert), updateDailyLiquidationsValidation, getString(R.string.ok));
                }

            }

        });
        myDialog.show();
    }
}
