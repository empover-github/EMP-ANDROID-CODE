package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.SelectedCropAdvisoryModelMain;
import com.pioneer.emp.R;

import java.util.ArrayList;

/**
 * Created by fatima.t on 21-08-2017.
 */

public class OfflineCropAdvisoryAdapterr extends RecyclerView.Adapter<OfflineCropAdvisoryAdapterr.MYHolder> {

    Context context;
    ArrayList<SelectedCropAdvisoryModelMain> list;
    private final OnBookletClickListener listener;

    public OfflineCropAdvisoryAdapterr(Context context, ArrayList<SelectedCropAdvisoryModelMain> couponsDTOArrayList, OnBookletClickListener listener) {
        this.context = context;
        this.list = couponsDTOArrayList;
        this.listener = listener;
    }

    @Override
    public MYHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.emp_offline_crop_advisory_item,parent,false);
        return new MYHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MYHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MYHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView stateTxt, seasonTxt, cropTxt, hybridTxt, startDateTxt, endDateTxt;
        LinearLayout dataLL;
        ImageView deleteData;

        public MYHolder(View view) {
            super(view);

             stateTxt = view.findViewById(R.id.stateTV);
             seasonTxt = view.findViewById(R.id.seasonTV);
             cropTxt = view.findViewById(R.id.cropTV);
             hybridTxt = view.findViewById(R.id.hybridTV);
             startDateTxt = view.findViewById(R.id.startDateTV);
             endDateTxt = view.findViewById(R.id.endDateTV);

             dataLL = view.findViewById(R.id.dataLL);
             deleteData = view.findViewById(R.id.deleteImgBtn);

        }

        public void bind(final int position) {
            SelectedCropAdvisoryModelMain index = list.get(position);

            stateTxt.setText(index.getStateName());
            seasonTxt.setText(index.getSeasonName());
            cropTxt.setText(index.getCropName());
            hybridTxt.setText(index.getHybridName());
            startDateTxt.setText(index.getStartDate());
            endDateTxt.setText(index.getEndDate());

            dataLL.setTag(position);
            deleteData.setTag(position);

            dataLL.setOnClickListener(this);
            deleteData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = (int) v.getTag();
            listener.onItemClick(v, position);
        }
    }
}
