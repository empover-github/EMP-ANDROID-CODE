package com.pioneer.emp.adapters;

import android.content.Context;
import android.graphics.Paint;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dto.MdrEvaluationDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.utils.AppConstants;

import java.util.ArrayList;

/**
 * Created by fatima.t on 04-06-2018.
 */

public class MdrEvaluationAdapter extends RecyclerView.Adapter<MdrEvaluationAdapter.MdrEvaluationHolder> {
    Context context;
    ArrayList<MdrEvaluationDTO> arrayList;
    private OnBookletClickListener listener;

    public MdrEvaluationAdapter(Context context, ArrayList<MdrEvaluationDTO> profilesList, OnBookletClickListener listener) {
        this.context = context;
        this.arrayList = profilesList;
        this.listener = listener;
    }

    @Override
    public MdrEvaluationHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.mdr_evaluation_list_item,parent,false);
        return new MdrEvaluationHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MdrEvaluationHolder holder, int position) {
        holder.bind(arrayList.get(position), position);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class MdrEvaluationHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvEmpId, tvEmpName, tvScore, tvStatus;
        View tvView;
        public MdrEvaluationHolder(View view) {
            super(view);
            tvEmpId = (TextView) view.findViewById(R.id.mdre_li_empId);
            tvEmpName = (TextView) view.findViewById(R.id.mdre_li_empName);
            tvScore = (TextView) view.findViewById(R.id.mdre_li_score);
            tvStatus = (TextView) view.findViewById(R.id.mdre_li_status);
            tvView = view.findViewById(R.id.mdre_bottom_tv_line);

            tvStatus.setOnClickListener(this);
            tvScore.setOnClickListener(this);

        }

        public void bind(final MdrEvaluationDTO listModel, int position) {
            tvEmpId.setText(listModel.getMdrEmployeeId());
            tvEmpName.setText(listModel.getMdrName());
            tvScore.setText(listModel.getNineBoxScore());
            if (listModel.getNineBoxScore().equals("1") || listModel.getNineBoxScore().equals("2") || listModel.getNineBoxScore().equals("3")){
                tvScore.setTextColor(context.getResources().getColor(R.color.white));
                tvScore.setBackgroundColor(context.getResources().getColor(R.color.red));
            } else if (listModel.getNineBoxScore().equals("4") || listModel.getNineBoxScore().equals("5") || listModel.getNineBoxScore().equals("6")){
                tvScore.setTextColor(context.getResources().getColor(R.color.black));
                tvScore.setBackgroundColor(context.getResources().getColor(R.color.yellow));
            } else if (listModel.getNineBoxScore().equals("7") || listModel.getNineBoxScore().equals("8") || listModel.getNineBoxScore().equals("9")){
                tvScore.setTextColor(context.getResources().getColor(R.color.white));
                tvScore.setBackgroundColor(context.getResources().getColor(R.color.app_color));
            } else {
                tvScore.setTextColor(context.getResources().getColor(R.color.black));
                tvScore.setBackgroundColor(context.getResources().getColor(R.color.white));
            }

            if (AppConstants.PENDING_EVALUATION.equalsIgnoreCase(listModel.getStatus())){
                tvStatus.setPaintFlags(tvStatus.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
                tvStatus.setTextColor(context.getResources().getColor(R.color.hyper_link_not_visited));
            }  else if (AppConstants.EVALUATED.equalsIgnoreCase(listModel.getStatus())){
                tvStatus.setPaintFlags(tvStatus.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
                tvStatus.setTextColor(context.getResources().getColor(R.color.hyper_link_visited));
            } else {
                tvStatus.setPaintFlags(tvStatus.getPaintFlags() & (~ Paint.UNDERLINE_TEXT_FLAG));
                tvStatus.setTextColor(context.getResources().getColor(R.color.black));
            }

            tvStatus.setText(listModel.getStatus());

            if (position == arrayList.size()-1)
                tvView.setVisibility(View.GONE);
            else
                tvView.setVisibility(View.VISIBLE);


            tvStatus.setTag(listModel);
            tvScore.setTag(listModel);
        }

        @Override
        public void onClick(View v) {
            listener.onItemClick(v, getAdapterPosition());
        }
    }
}
