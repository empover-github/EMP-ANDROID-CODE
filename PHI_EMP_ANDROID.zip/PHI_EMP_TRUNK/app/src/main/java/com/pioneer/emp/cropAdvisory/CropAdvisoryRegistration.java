package com.pioneer.emp.cropAdvisory;

import android.app.Dialog;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;
import com.pioneer.emp.R;
import com.pioneer.emp.adapters.CategoryAdapter;
import com.pioneer.emp.fab.adapters.CropAdapter;
import com.pioneer.emp.fab.adapters.HybridAdapter;
import com.pioneer.emp.fab.adapters.SeasonAdapter;
import com.pioneer.emp.fab.adapters.StatesAdapter;
import com.pioneer.emp.fab.models.CropMasterEntity;
import com.pioneer.emp.fab.models.HybridMasterEntity;
import com.pioneer.emp.fab.models.SeasonMasterEntity;
import com.pioneer.emp.fab.models.StateCodeEntity;
import com.pioneer.emp.models.CategoryMasterEntity;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.listeners.DialogMangerCallback;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CropAdvisoryRegistration extends BaseActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    private CropAdvisoryRegistration thisActivity;
    private Toolbar toolbar;
    private TextView txtHeader;
    private ImageView navBackBtn;

    private Spinner spnCategoty, spnState, spnCrop, spnHybrid, spnSession;
    private EditText etPincode, etDateOfShowing, etNoOfAcers;
    private Button btnRegister, btnGetCropAdvisory;
    private LinearLayout dataLL;
    private TextView noDataAvailable;

    ArrayList<CategoryMasterEntity> allCategoryInfo;
    ArrayList<SeasonMasterEntity> allSeasonInfo;
    ArrayList<StateCodeEntity> allStatesInfo;
    ArrayList<HybridMasterEntity> allHybrids;
    ArrayList<CropMasterEntity> allCropsInfo;
    String selectedCropId;
    String st_selectedCategory, st_selectedState, st_selectedCrop, st_selectedHybrid, st_selectedSeason, st_noOfAcres, st_selectedDate;
    String st_selectedCategoryID, st_selectedStateID, st_selectedCropID, st_selectedHybridID, st_selectedSeasonID;

    private int mYear, mMonth, mDay;
    private Dialog d;
    String formattedDate;
    Calendar c;
    private String startDate, endDate;

    ArrayList<StateCodeEntity> selectedStates;
    ArrayList<CropMasterEntity> selectedCrops;
    ArrayList<HybridMasterEntity> selectedHybrids;
    ArrayList<SeasonMasterEntity> selectedSeasons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.crop_advisory_registration);
        thisActivity = this;

        // ActionBar Related components
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        txtHeader = findViewById(R.id.header_text);
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        txtHeader.setText(getString(R.string.cropAdvisory));
        navBackBtn.setOnClickListener(this);

        initializeViews();
    }

    private void initializeViews() {

        dataLL = findViewById(R.id.car_dataLL);
        noDataAvailable = findViewById(R.id.car_noDataText);

        // in the first Visit both are invisible
        dataLL.setVisibility(View.GONE);
        noDataAvailable.setVisibility(View.GONE);

        etPincode = findViewById(R.id.car_etPincode);
        spnCategoty = findViewById(R.id.spnCategory);
        spnState = findViewById(R.id.spnState);
        spnCrop = findViewById(R.id.spnCrop);
        spnHybrid = findViewById(R.id.spnHybridName);
        spnSession = findViewById(R.id.spnSeassion);
        etDateOfShowing = findViewById(R.id.etShowingDate);
        etNoOfAcers = findViewById(R.id.etNoOfAcers);
        btnRegister = findViewById(R.id.car_btnSubmit);
        btnGetCropAdvisory = findViewById(R.id.car_getCropAdvisryBtn);

        spnCategoty.setOnItemSelectedListener(this);
        spnState.setOnItemSelectedListener(this);
        spnCrop.setOnItemSelectedListener(this);
        spnHybrid.setOnItemSelectedListener(this);
        spnSession.setOnItemSelectedListener(this);
        etDateOfShowing.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
        btnGetCropAdvisory.setOnClickListener(this);

        allStatesInfo = new ArrayList<>();
        allCategoryInfo = new ArrayList<>();
        allSeasonInfo = new ArrayList<>();
        allHybrids = new ArrayList<>();
        allCropsInfo = new ArrayList<>();
        clearData();

        if (Utils.isValidStr(fDataCache.getFarmerPincode())) {
            etPincode.setText(fDataCache.getFarmerPincode());
            getAllCropInfo();
        }


    }

    private void getAllCropInfo() {

        if (Utils.isNetworkConnection(thisActivity)) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("pincode", etPincode.getText().toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            String jwtToken = Utils.getJWTToken(jsonObject.toString(), thisActivity);
            APIRequestHandler.getInstance().getCropAdvisoryMaster(this, jwtToken, this, true);
        } else {
            DialogManager.showToast(thisActivity, getString(R.string.no_internet));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgBacknav:
                onBackPressed();
                break;
            case R.id.car_btnSubmit:
                //Save selected Crop info into Server.
                st_noOfAcres = etNoOfAcers.getText().toString().trim();

                if (validateData()) {
                    CropAdvisorySubscriptionReq subscriptionReq = new CropAdvisorySubscriptionReq();
                    subscriptionReq.setCustomerId(fDataCache.getCustomerId());
                    subscriptionReq.setCategory(st_selectedCategoryID);
                    subscriptionReq.setState(st_selectedStateID);
                    subscriptionReq.setCrop(st_selectedCropID);
                    subscriptionReq.setHybrid(st_selectedHybridID);
                    subscriptionReq.setSeason(st_selectedSeasonID);
                    subscriptionReq.setSowingDate(Utils.formatDateToServer(etDateOfShowing.getText().toString()));
                    subscriptionReq.setAcressowed(st_noOfAcres);
                    subscriptionReq.setMobileNumber(fDataCache.getMobileNo());
                    subscriptionReq.setPincode(etPincode.getText().toString());
                    if (Utils.isNetworkConnection(thisActivity)) {
                        String subscriptionInfo = new Gson().toJson(subscriptionReq, CropAdvisorySubscriptionReq.class);
                        String jwtToken = Utils.getJWTToken(subscriptionInfo, thisActivity);
                        APIRequestHandler.getInstance().subscribeCropAdvisory(thisActivity, jwtToken, this, true);
                    } else {
                        DialogManager.showToast(thisActivity, getString(R.string.no_internet));
                    }

                }
                break;
            case R.id.etShowingDate:
                formattedDate = etDateOfShowing.getText().toString();
                openDatePicker(formattedDate);
                break;
            case R.id.btn_calendar_ok:
                d.dismiss();
                //    DialogManager.showToast(thisActivity,getString(R.string.your_selected_date_is)+st_selectedDate);
                break;

            case R.id.car_getCropAdvisryBtn:
                // make Api call to get crop advisory in entered pincode
                if (Utils.isValidStr(etPincode.getText().toString()) && etPincode.length() == 6) {
                    getAllCropInfo();
                } else {
                    DialogManager.showToast(thisActivity, getString(R.string.valid_pincode_error));
                }
                break;
        }

    }

    @Override
    public void onBackPressed() {
        if (isDataAvailable()) {
            DialogManager.showConformPopup(thisActivity, new DialogMangerCallback() {
                @Override
                public void onOkClick(View v) {
                    finish();
                }

                @Override
                public void onCancelClick(View view) {

                }
            }, getString(R.string.alert), getString(R.string.go_back_msg), getString(R.string.yes), getString(R.string.no));
        } else {
            finish();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.spnCategory:
                st_selectedCategory = allCategoryInfo.get(position).getName();
                st_selectedCategoryID = allCategoryInfo.get(position).getId();
                setStateSpinner(st_selectedCategoryID);
                break;
            case R.id.spnState:
                st_selectedState = selectedStates.get(position).getName();
                st_selectedStateID = selectedStates.get(position).getId();
                String categoryId_state = selectedStates.get(position).getCategoryId();
                setCropSpinner(categoryId_state, st_selectedStateID);
                break;
            case R.id.spnCrop:
                st_selectedCrop = selectedCrops.get(position).getName();
                selectedCropId = selectedCrops.get(position).getId();
                st_selectedCropID = selectedCrops.get(position).getId();
                String categoryId_crop = selectedCrops.get(position).getCategoryId();
                String stateId_crop = selectedCrops.get(position).getStateId();
                setHybridSpinner(categoryId_crop, stateId_crop, selectedCropId);
                break;
            case R.id.spnHybridName:
                st_selectedHybrid = selectedHybrids.get(position).getName();
                st_selectedHybridID = selectedHybrids.get(position).getId();
                String categoryId_hybrid = selectedHybrids.get(position).getCategoryId();
                String stateId_hybrid = selectedHybrids.get(position).getStateId();
                String cropId_hybrid = selectedHybrids.get(position).getCropId();
                setSeasonSpinner(categoryId_hybrid, stateId_hybrid, cropId_hybrid, st_selectedHybridID);
                break;
            case R.id.spnSeassion:
                st_selectedSeason = selectedSeasons.get(position).getName();
                st_selectedSeasonID = selectedSeasons.get(position).getId();
                startDate = selectedSeasons.get(position).getStartDate();
                endDate = selectedSeasons.get(position).getEndDate();
                if (Utils.isValidStr(startDate)) {
                    etDateOfShowing.setText(Utils.formatDateToUser(startDate));
                }
                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void setStateSpinner(String selectedCategoryId) {

        selectedStates = new ArrayList<>();

        for (int i = 0; i < allStatesInfo.size(); i++) {
            String categoryId = allStatesInfo.get(i).getCategoryId();
            if (categoryId.equals(selectedCategoryId)) {
                selectedStates.add(allStatesInfo.get(i));
            }
        }
        StatesAdapter stateAd = new StatesAdapter(thisActivity, selectedStates);
        spnState.setAdapter(stateAd);

    }

    private void setCropSpinner(String selectedCategoryId, String selectedStateID) {

        selectedCrops = new ArrayList<>();

        for (int i = 0; i < allCropsInfo.size(); i++) {
            String categoryId = allCropsInfo.get(i).getCategoryId();
            String stateId = allCropsInfo.get(i).getStateId();
            if (categoryId.equals(selectedCategoryId) && stateId.equals(selectedStateID)) {
                selectedCrops.add(allCropsInfo.get(i));
            }
        }
        CropAdapter cropAd = new CropAdapter(thisActivity, selectedCrops);
        spnCrop.setAdapter(cropAd);

    }

    private void setHybridSpinner(String selectedCategory, String selectedState, String selectedCropId) {

        selectedHybrids = new ArrayList<>();

        for (int i = 0; i < allHybrids.size(); i++) {
            String cropId = allHybrids.get(i).getCropId();
            String categoryId = allHybrids.get(i).getCategoryId();
            String stateId = allHybrids.get(i).getStateId();
            if (cropId.equals(selectedCropId) && categoryId.equals(selectedCategory) && stateId.equals(selectedState)) {
                selectedHybrids.add(allHybrids.get(i));
            }
        }

        HybridAdapter hybridAd = new HybridAdapter(thisActivity, selectedHybrids);
        spnHybrid.setAdapter(hybridAd);
    }

    private void setSeasonSpinner(String selectedCategoryId, String selectedStateID, String selectedCropId, String selectedHybridId) {

        selectedSeasons = new ArrayList<>();

        if (allSeasonInfo == null) {
            SeasonMasterEntity sme = new SeasonMasterEntity();
            sme.setId("0");
            sme.setName(getString(R.string.no_season));
            sme.setCategoryId(selectedCategoryId);
            sme.setStateId(selectedStateID);
            sme.setCropId(selectedCropId);
            sme.setHybridId(selectedHybridId);
            selectedSeasons.add(sme);
        } else {
            for (int i = 0; i < allSeasonInfo.size(); i++) {
                String categoryId = allSeasonInfo.get(i).getCategoryId();
                String stateId = allSeasonInfo.get(i).getStateId();
                String cropId = allSeasonInfo.get(i).getCropId();
                String hybridId = allSeasonInfo.get(i).getHybridId();
                if (categoryId.equals(selectedCategoryId) && stateId.equals(selectedStateID) && cropId.equals(selectedCropId) && hybridId.equals(selectedHybridId)) {
                    selectedSeasons.add(allSeasonInfo.get(i));
                }
            }
        }
        SeasonAdapter seasonAd = new SeasonAdapter(thisActivity, selectedSeasons);
        spnSession.setAdapter(seasonAd);
    }

    private boolean validateData() {
        String dateSelected = etDateOfShowing.getText().toString().trim();
        st_noOfAcres = etNoOfAcers.getText().toString().trim();
        if (!Utils.isValidStr(st_selectedCategory)) {
            DialogManager.showToast(thisActivity, getString(R.string.select_category_error));
            return false;
        } else if (!Utils.isValidStr(st_selectedState)) {
            DialogManager.showToast(thisActivity, getString(R.string.select_state_error));
            return false;
        } else if (!Utils.isValidStr(st_selectedCrop)) {
            DialogManager.showToast(thisActivity, getString(R.string.select_crop_error));
            return false;
        } else if (!Utils.isValidStr(st_selectedHybrid)) {
            DialogManager.showToast(thisActivity, getString(R.string.select_hybrid_error));
            return false;
        } else if (!Utils.isValidStr(st_selectedSeason)) {
            DialogManager.showToast(thisActivity, getString(R.string.select_season_error));
            return false;
        } else if (!Utils.isValidStr(dateSelected)) {
            DialogManager.showToast(thisActivity, getString(R.string.select_date_error));
            return false;
        } else if (!Utils.isValidStr(st_noOfAcres)) {
            DialogManager.showToast(thisActivity, getString(R.string.enter_sowed_acres_error));
            return false;
        }
        return true;
    }

    public void openDatePicker(String s) {
        Date date = Utils.formatDateFromStrToDate2(s);
        Calendar myCalendar = Calendar.getInstance();
        myCalendar.setTime(date);
        mYear = myCalendar.get(Calendar.YEAR);
        mMonth = myCalendar.get(Calendar.MONTH);
        mDay = myCalendar.get(Calendar.DAY_OF_MONTH);

        d = new Dialog(thisActivity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(R.layout.at_date_picker_dialog);
        d.setCancelable(false);
        final TextView tv = d.findViewById(R.id.tv_date_label);
//        tv.setText(getString(R.string.your_selected_date_is));
        DatePicker dp = d.findViewById(R.id.dp);
        dp.updateDate(mYear, mMonth, mDay);
        Button ok_btn = d.findViewById(R.id.btn_calendar_ok);
        ok_btn.setOnClickListener(this);
        if (Utils.isValidStr(endDate)) {
            dp.setMaxDate(Utils.convertStrToMilliSeconds(endDate));
        }
        if (Utils.isValidStr(startDate)) {
            dp.setMinDate(Utils.convertStrToMilliSeconds(startDate));
        }
        //  etDateOfShowing.setText(st_selectedDate);

        DateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy");
        formattedDate = df1.format(myCalendar.getTime());
        tv.setText(getString(R.string.your_selected_date_is) + " " + formattedDate);


        dp.init(mYear, mMonth, mDay, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // Do something when the date changed from date picker object

                // Create a Date variable/object with user chosen date
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(0);
                cal.set(year, monthOfYear, dayOfMonth, 0, 0, 0);

                //          st_selectedDate = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                //etDateOfShowing.setText(st_selectedDate);
                Date chosenDate = cal.getTime();

                // Format the date
                DateFormat df2 = new SimpleDateFormat("dd-MMM-yyyy");
                formattedDate = df2.format(chosenDate);
//                etDateOfShowing.setText(formattedDate);

                /*tv.setText("Your selected date is\n");
                tv.setText((tv.getText() +" "+ formattedDate));*/
                String setTextValue = getString(R.string.your_selected_date_is) + " " + formattedDate;
                tv.setText(setTextValue);

            }
        });
        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                st_selectedDate = formattedDate;
                etDateOfShowing.setText(formattedDate);
            }
        });
        d.show();

    }


    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);
        if (responseObj != null) {
            if (responseObj instanceof CropAdvisoryModel) {
                CropAdvisoryModel commonResponse = (CropAdvisoryModel) responseObj;

                if (AppConstants.STATUS_CODE_PRAVAKTA == commonResponse.getStatusCode()) {
                    String cropAdviRes =commonResponse.getResponse();
                    CropAdvisoryModel allAdvisoryInfo = new Gson().fromJson(cropAdviRes, CropAdvisoryModel.class);

                    setAllAdapterInfo(allAdvisoryInfo);

                } else if (AppConstants.CROP_ADVISORY_NOT_AVAILABLE_CODE_INT == commonResponse.getStatusCode()) {
                    btnRegister.setVisibility(View.GONE);
                    dataLL.setVisibility(View.GONE);
                    noDataAvailable.setText(commonResponse.getMessage());
                    noDataAvailable.setVisibility(View.VISIBLE);
                    String msg = commonResponse.getMessage() + getString(R.string.click_on_edit_exit_global).replace("$1", getString(R.string.pincode_small_case)).replace("$2", getString(R.string.cropAdvisory));
                    DialogManager.showConformPopup(thisActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            clearData();
                        }

                        @Override
                        public void onCancelClick(View view) {
                            finish();
                        }
                    }, getString(R.string.alert), msg, getString(R.string.edit), getString(R.string.ext));
                } /*else if (AppConstants.STATUS_CODE_LOGOUT_INT == commonResponse.getStatusCode()) {
                    logoutUser(thisActivity);
                }*/ else {
                    DialogManager.showToast(thisActivity, commonResponse.getMessage());
                }
            } else if (responseObj instanceof CropAdvisorySubscriptionReq) {
                CropAdvisorySubscriptionReq subscribeInfo = (CropAdvisorySubscriptionReq) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == subscribeInfo.getStatusCode()) {
                    DialogManager.showSingleBtnPopup(thisActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            // it should go back or stay on screen?
                            clearData();
                            finish();
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, getString(R.string.congratulations), subscribeInfo.getMessage(), getString(R.string.ok));

                } /*else if (AppConstants.STATUS_CODE_LOGOUT_INT == subscribeInfo.getStatusCode()) {
                    logoutUser(thisActivity);
                } */ else if (AppConstants.CROP_ADVISORY_NOT_AVAILABLE_CODE_INT == subscribeInfo.getStatusCode()) {
                    String msg = subscribeInfo.getMessage() + getString(R.string.click_on_edit_exit_global).replace("$1", getString(R.string.pincode_small_case)).replace("$2", getString(R.string.cropAdvisory));
                    DialogManager.showConformPopup(thisActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            clearData();
                        }

                        @Override
                        public void onCancelClick(View view) {
                            finish();
                        }
                    }, getString(R.string.alert), msg, getString(R.string.edit), getString(R.string.ext));
                }  else {
                    DialogManager.showToast(thisActivity, subscribeInfo.getMessage());
                }

            }
        }
    }


    private void setAllAdapterInfo(CropAdvisoryModel allAdvisoryInfo) {
        allCategoryInfo = (ArrayList<CategoryMasterEntity>) allAdvisoryInfo.getCategoryMaster();
        allStatesInfo = (ArrayList<StateCodeEntity>) allAdvisoryInfo.getStateCodeMaster();
        allSeasonInfo = (ArrayList<SeasonMasterEntity>) allAdvisoryInfo.getSeasonMaster();
        allHybrids = (ArrayList<HybridMasterEntity>) allAdvisoryInfo.getHybridMaster();
        allCropsInfo = (ArrayList<CropMasterEntity>) allAdvisoryInfo.getCropMaster();

        if (allCategoryInfo == null || allStatesInfo == null || allCropsInfo == null || allHybrids == null || allSeasonInfo == null) {
            btnRegister.setVisibility(View.GONE);
            noDataAvailable.setVisibility(View.VISIBLE);
            dataLL.setVisibility(View.GONE);
        } else {

            btnGetCropAdvisory.setEnabled(false);
            etPincode.setEnabled(false);
            etPincode.setTextColor(getResources().getColor(R.color.drak_grey));
            noDataAvailable.setVisibility(View.GONE);
            dataLL.setVisibility(View.VISIBLE);
            btnRegister.setVisibility(View.VISIBLE);
            CategoryAdapter categoryAd = new CategoryAdapter(thisActivity, allCategoryInfo);
            spnCategoty.setAdapter(categoryAd);
            categoryAd.notifyDataSetChanged();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_reset_text, menu);
        return  super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_reset_text) {
            // refresh screen
            clearData();
            return true;
        }
        return false;
    }

    private void clearData() {
        etPincode.setText("");
        etPincode.setEnabled(true);
        etPincode.setTextColor(getResources().getColor(R.color.textColor));
        btnGetCropAdvisory.setEnabled(true);
        btnRegister.setVisibility(View.GONE);
        dataLL.setVisibility(View.GONE);
        noDataAvailable.setVisibility(View.GONE);
    }

    private boolean isDataAvailable() {

        if (etPincode.getText().toString().trim().length() > 0)
            return true;

        /*if (!btnGetCropAdvisory.isEnabled())
            return true;*/

        return dataLL.getVisibility() == View.VISIBLE;

    }


}
