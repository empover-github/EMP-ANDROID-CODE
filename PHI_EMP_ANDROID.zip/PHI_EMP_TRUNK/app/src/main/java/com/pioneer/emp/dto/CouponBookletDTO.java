package com.pioneer.emp.dto;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by hareesh.a on 7/11/2017.
 */

public class CouponBookletDTO implements Serializable{
    private long bookletId;
    private String crop;
    private String season;
    private int year;
    private String validTill;
    private long couponsInBooklet;
    private long couponsShared;
    private ArrayList<CouponListDTO>couponList;

    public long getBookletId() {
        return bookletId;
    }

    public void setBookletId(long bookletId) {
        this.bookletId = bookletId;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getValidTill() {
        return validTill;
    }

    public void setValidTill(String validTill) {
        this.validTill = validTill;
    }

    public long getCouponsInBooklet() {
        return couponsInBooklet;
    }

    public void setCouponsInBooklet(long couponsInBooklet) {
        this.couponsInBooklet = couponsInBooklet;
    }

    public long getCouponsShared() {
        return couponsShared;
    }

    public void setCouponsShared(long couponsShared) {
        this.couponsShared = couponsShared;
    }
    public ArrayList<CouponListDTO> getCouponList() {
        return couponList;
    }

    public void setCouponList(ArrayList<CouponListDTO> couponList) {
        this.couponList = couponList;
    }
}
