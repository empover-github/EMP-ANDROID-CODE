package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.models.CategoryMasterEntity;
import com.pioneer.emp.R;

import java.util.ArrayList;

/**
 * Created by fatima.t on 08-05-2017.
 */

public class CategoryAdapter extends BaseAdapter{
    ArrayList<CategoryMasterEntity> allCategoryList;
    LayoutInflater inflter;
    Context context;

    public CategoryAdapter(Context context, ArrayList<CategoryMasterEntity> allCrops) {
        inflter = (LayoutInflater.from(context));
        this.allCategoryList = allCrops;
        this.context = context;

    }

    @Override
    public int getCount() {
        return allCategoryList.size();
    }

    @Override
    public Object getItem(int position) {
        return allCategoryList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


//        View view = convertView;
        convertView =  inflter.inflate(R.layout.emp_fab_custom_spinner_items, null);
        TextView stateText = convertView.findViewById(R.id.spinner_textView);

        stateText.setText(allCategoryList.get(position).getName());

        /*LayoutInflater mInflater = (LayoutInflater) getContext().getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        view = mInflater.inflate(R.layout.list_view_items, null);*/
        return convertView;
    }
}
