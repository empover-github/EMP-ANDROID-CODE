package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.pioneer.emp.models.CropAdvisoryStagesModel;
import com.pioneer.emp.R;

import java.util.ArrayList;

/**
 * Created by fatima.t on 14-08-2017.
 */

public class SelectedCropAdvisoryAdapter extends BaseAdapter {

    ArrayList<CropAdvisoryStagesModel> allCropsList;
    LayoutInflater inflter;
    Context context;

    public SelectedCropAdvisoryAdapter(Context context, ArrayList<CropAdvisoryStagesModel> allCrops) {
        inflter = (LayoutInflater.from(context));
        this.allCropsList = allCrops;
        this.context = context;

    }
    @Override
    public int getCount() {
        return allCropsList.size();
    }

    @Override
    public Object getItem(int position) {
        return allCropsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView =  inflter.inflate(R.layout.emp_crop_advisory_list_item, null);

        TextView engMsg = convertView.findViewById(R.id.emp_ca_list_item_eng_msgTxt);
        TextView localMsg = convertView.findViewById(R.id.emp_ca_list_item_local_msgTxt);
        ImageView audioBtn = convertView.findViewById(R.id.emp_crop_advisory_list_item_audioBtn);

        engMsg.setText(allCropsList.get(position).getMessage());
        localMsg.setText(allCropsList.get(position).getMessageInLocaLang());

        return convertView;
    }
}
