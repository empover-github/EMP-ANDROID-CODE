package com.pioneer.emp.fab.fragments;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.fab.AudioPalyer;
import com.pioneer.emp.fab.GalleryActivity;
import com.pioneer.emp.fab.PDFViewerActivity;
import com.pioneer.emp.fab.VideoPlayerActivity;
import com.pioneer.emp.fab.dao.FabMasterDAO;
import com.pioneer.emp.fab.models.FabMasterModel;
import com.pioneer.parivaar.fragments.BaseFragment;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by fatima.t on 10-07-2017.
 */

public class FabCategoryFragments extends BaseFragment implements View.OnClickListener {

    View mRootView;
    FabMasterModel fabMasterDTO;
    private TextView noDataAvailableText;
    private RelativeLayout dataAvailableRL;
    private TextView messageText, messageNoText;
    private ImageView pdfButton, imagesButton, audioButton, videoButton;
    private LinearLayout bottomRowLL, feaMessageLL;

    private ArrayList<String> imgServerUrl = new ArrayList<>();
    private ArrayList<String> imgLocalUrls = new ArrayList<>();
    private ArrayList<String> imgsToDownload = new ArrayList<>();
    private ArrayList<String> imgsDownloaded = new ArrayList<>();

    private String st_message, st_message_local, st_image_url_array, st_audio_url, st_video_url, st_image_tag_array, st_pdf_url;
    private String local_img_url_array, local_audio_url, local_video_url, local_pdf_url;
    private MediaPlayer player;
    private String category;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle getArgs = getArguments();
        if (getArgs != null && getArgs.containsKey("fabArguments")) {
            fabMasterDTO = (FabMasterModel) getArgs.getSerializable("fabArguments");
            category = getArgs.getString("fabCategory");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.emp_fragment_features, container, false);
//        setHasOptionsMenu(true);
        return mRootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeViews();
        refresh();
    }

    @Override
    public void refresh() {
        if (isAdded()) {
            fabMasterDTO = FabMasterDAO.getInstance().getRecordById(fabMasterDTO.getId(), DBHandler.getReadableDb(getActivity()));
            /*if (fabMasterDTO != null)
                return;*/
            displayData(fabMasterDTO);
        }
    }

    private void initializeViews() {
        noDataAvailableText = mRootView.findViewById(R.id.fea_noDataAvailable_text);
        dataAvailableRL = mRootView.findViewById(R.id.fea_dataAvaialble_RL);
        messageText = mRootView.findViewById(R.id.fea_message_text);
        messageNoText = mRootView.findViewById(R.id.fea_message_no_text);
        pdfButton = mRootView.findViewById(R.id.fea_pdf_img);
        imagesButton = mRootView.findViewById(R.id.fea_images_img);
        audioButton = mRootView.findViewById(R.id.fea_audio_img);
        videoButton = mRootView.findViewById(R.id.fea_video_img);
        bottomRowLL = mRootView.findViewById(R.id.fea_botton_row_LL);
        feaMessageLL = mRootView.findViewById(R.id.fea_messages_LL);

        pdfButton.setOnClickListener(this);
        imagesButton.setOnClickListener(this);
        audioButton.setOnClickListener(this);
        videoButton.setOnClickListener(this);
        displayData(fabMasterDTO);
    }

    private void displayData(FabMasterModel fabMasterDTO) {

        if (fabMasterDTO != null) {

            if (category.equals(AppConstants.FAB_FEATURES)) {
                st_message = fabMasterDTO.getF_message();
                st_message_local = fabMasterDTO.getF_localLangMessage();
                st_image_url_array = fabMasterDTO.getF_images();
                st_audio_url = fabMasterDTO.getF_voiceFile();
                st_video_url = fabMasterDTO.getF_videoFile();
                st_pdf_url = fabMasterDTO.getF_pdfFile();
                st_image_tag_array = fabMasterDTO.getF_image_tags();

                local_img_url_array = fabMasterDTO.getF_images_local();
                local_audio_url = fabMasterDTO.getF_voiceFile_local();
                local_video_url = fabMasterDTO.getF_videoFile_local();
                local_pdf_url = fabMasterDTO.getF_pdfFile_local();

                StringBuilder msgBuilder = new StringBuilder();
                if (Utils.isValidStr(st_message))
                    msgBuilder.append(st_message);
                if (msgBuilder.length() > 0)
                    msgBuilder.append("\n\n");
                if (Utils.isValidStr(st_message_local))
                    msgBuilder.append(st_message_local);

                if (msgBuilder.length() > 0) {
                    messageText.setText(msgBuilder.toString());
                    messageText.setVisibility(View.VISIBLE);
                    messageNoText.setVisibility(View.GONE);
                } else {
                    /*messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);*/
                    feaMessageLL.removeAllViews();
                    // FrameLayout is the parent for LinearLayout
                    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    params.gravity = Gravity.CENTER | Gravity.CENTER_VERTICAL;
                    feaMessageLL.setLayoutParams(params);
                    messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);
                    feaMessageLL.addView(messageNoText);
                }

                if (Utils.isValidStr(st_audio_url)) {
                    // take file name from URL and check whether it exist locally or not
                } else {
                    audioButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_video_url)) {
                } else {
                    videoButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_image_url_array)) {
                    // split the string seperated by # and make an array of it, then check each and every file whether exist locally or not
                } else {
                    imagesButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_pdf_url)) {

                } else {
                    pdfButton.setVisibility(View.GONE);
                }
                if (!Utils.isValidStr(st_image_url_array) && !Utils.isValidStr(st_audio_url) && !Utils.isValidStr(st_video_url) && !Utils.isValidStr(st_pdf_url)) {
                    bottomRowLL.setVisibility(View.GONE);
                }
            } else if (category.equals(AppConstants.FAB_ADVANTAGES)) {
                st_message = fabMasterDTO.getA_message();
                st_message_local = fabMasterDTO.getA_localLangMessage();
                st_image_url_array = fabMasterDTO.getA_images();
                st_audio_url = fabMasterDTO.getA_voiceFile();
                st_video_url = fabMasterDTO.getA_videoFile();
                st_pdf_url = fabMasterDTO.getA_pdfFile();
                st_image_tag_array = fabMasterDTO.getA_image_tags();

                local_img_url_array = fabMasterDTO.getA_images_local();
                local_audio_url = fabMasterDTO.getA_voiceFile_local();
                local_video_url = fabMasterDTO.getA_videoFile_local();
                local_pdf_url = fabMasterDTO.getA_pdfFile_local();

                StringBuilder msgBuilder = new StringBuilder();
                if (Utils.isValidStr(st_message))
                    msgBuilder.append(st_message);
                if (msgBuilder.length() > 0)
                    msgBuilder.append("\n\n");
                if (Utils.isValidStr(st_message_local))
                    msgBuilder.append(st_message_local);

                if (msgBuilder.length() > 0) {
                    messageText.setText(msgBuilder.toString());
                    messageText.setVisibility(View.VISIBLE);
                    messageNoText.setVisibility(View.GONE);
                } else {
                    /*messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);*/
                    feaMessageLL.removeAllViews();
                    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    params.gravity = Gravity.CENTER | Gravity.CENTER_VERTICAL;
                    feaMessageLL.setLayoutParams(params);
                    messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);
                    feaMessageLL.addView(messageNoText);
                }
                if (Utils.isValidStr(st_audio_url)) {
                    // take file name from URL and check whether it exist locally or not
                } else {
                    audioButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_video_url)) {
                } else {
                    videoButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_image_url_array)) {
                    // split the string seperated by # and make an array of it, then check each and every file whether exist locally or not
                } else {
                    imagesButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_pdf_url)) {

                } else {
                    pdfButton.setVisibility(View.GONE);
                }
                if (!Utils.isValidStr(st_image_url_array) && !Utils.isValidStr(st_audio_url) && !Utils.isValidStr(st_video_url) && !Utils.isValidStr(st_pdf_url)) {
                    bottomRowLL.setVisibility(View.GONE);
                }
            } else if (category.equals(AppConstants.FAB_BENEFITS)) {
                st_message = fabMasterDTO.getB_message();
                st_message_local = fabMasterDTO.getB_localLangMessage();
                st_image_url_array = fabMasterDTO.getB_images();
                st_audio_url = fabMasterDTO.getB_voiceFile();
                st_video_url = fabMasterDTO.getB_videoFile();
                st_pdf_url = fabMasterDTO.getB_pdfFile();
                st_image_tag_array = fabMasterDTO.getB_image_tags();

                local_img_url_array = fabMasterDTO.getB_images_local();
                local_audio_url = fabMasterDTO.getB_voiceFile_local();
                local_video_url = fabMasterDTO.getB_videoFile_local();
                local_pdf_url = fabMasterDTO.getB_pdfFile_local();

                StringBuilder msgBuilder = new StringBuilder();
                if (Utils.isValidStr(st_message))
                    msgBuilder.append(st_message);
                if (msgBuilder.length() > 0)
                    msgBuilder.append("\n\n");
                if (Utils.isValidStr(st_message_local))
                    msgBuilder.append(st_message_local);

                if (msgBuilder.length() > 0) {
                    messageText.setText(msgBuilder.toString());
                    messageText.setVisibility(View.VISIBLE);
                    messageNoText.setVisibility(View.GONE);
                } else {
                    /*feaMessageLL.removeAllViews();
                    feaMessageLL.setGravity(Gravity.CENTER);*/
                   /* messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);*/
//                    feaMessageLL.addView(messageNoText);
                    // Change the layout_gravity (not gravity) of the LinearLayout
                    feaMessageLL.removeAllViews();
                    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    params.gravity = Gravity.CENTER | Gravity.CENTER_VERTICAL;
                    feaMessageLL.setLayoutParams(params);
                    messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);
                    feaMessageLL.addView(messageNoText);
                }

                if (Utils.isValidStr(st_audio_url)) {
                    // take file name from URL and check whether it exist locally or not
                } else {
                    audioButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_video_url)) {
                } else {
                    videoButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_image_url_array)) {
                    // split the string seperated by # and make an array of it, then check each and every file whether exist locally or not
                } else {
                    imagesButton.setVisibility(View.GONE);
                }
                if (Utils.isValidStr(st_pdf_url)) {

                } else {
                    pdfButton.setVisibility(View.GONE);
                }
                if (!Utils.isValidStr(st_image_url_array) && !Utils.isValidStr(st_audio_url) && !Utils.isValidStr(st_video_url) && !Utils.isValidStr(st_pdf_url)) {
                    bottomRowLL.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fea_images_img:
                String images = null;
                String imageTags = null;
                String imagesOnline = null;
                switch (category) {
                    case AppConstants.FAB_FEATURES:
                        images = fabMasterDTO.getF_images_local();
                        imageTags = fabMasterDTO.getF_image_tags();
                        imagesOnline = fabMasterDTO.getF_images();
                        break;

                    case AppConstants.FAB_ADVANTAGES:
                        images = fabMasterDTO.getA_images_local();
                        imagesOnline = fabMasterDTO.getA_images();
                        imageTags = fabMasterDTO.getA_image_tags();
                        break;

                    case AppConstants.FAB_BENEFITS:
                        images = fabMasterDTO.getB_images_local();
                        imagesOnline = fabMasterDTO.getB_images();
                        imageTags = fabMasterDTO.getB_image_tags();
                        break;
                }

                if (Utils.isValidStr(images)) {
//                        DialogManager.showGalleryPopup(mActivity, images.split("#"));
                    Intent gotofabGalleryActivity = new Intent(getActivity(), GalleryActivity.class);
                    gotofabGalleryActivity.putExtra(GalleryActivity.EXTRAS_IMAGES, images);
                    gotofabGalleryActivity.putExtra(GalleryActivity.IMAGE_TAGS_EXTRAS, imageTags);
                    startActivity(gotofabGalleryActivity);
                } else if (Utils.isNetworkConnection(getActivity())) {
                    //write something here
                    Intent gotofabGalleryActivity = new Intent(getActivity(), GalleryActivity.class);
                    gotofabGalleryActivity.putExtra(GalleryActivity.EXTRAS_IMAGES, imagesOnline);
                    gotofabGalleryActivity.putExtra(GalleryActivity.IMAGE_TAGS_EXTRAS, imageTags);
                    startActivity(gotofabGalleryActivity);
                }

                break;
            case R.id.fea_audio_img:
                String audioFilePath = null;
                String audioFilePathOnline = null;
                switch (category) {
                    case AppConstants.FAB_FEATURES:
                        audioFilePath = fabMasterDTO.getF_voiceFile_local();
                        audioFilePathOnline = fabMasterDTO.getF_voiceFile();
                        break;
                    case AppConstants.FAB_ADVANTAGES:
                        audioFilePath = fabMasterDTO.getA_voiceFile_local();
                        audioFilePathOnline = fabMasterDTO.getA_voiceFile();
                        break;
                    case AppConstants.FAB_BENEFITS:
                        audioFilePath = fabMasterDTO.getB_voiceFile_local();
                        audioFilePathOnline = fabMasterDTO.getB_voiceFile();
                        break;
                }
                if (Utils.isValidStr(audioFilePath)) {
                    File newFile = new File(audioFilePath);
                    if (newFile.exists()) {
                        Intent intent = new Intent(getActivity(), AudioPalyer.class);
                        // intent.setAction(android.content.Intent.ACTION_VIEW);
                      /*  File file = new File(audioFilePath);
                        intent.setDataAndType(Uri.fromFile(file), "audio*//*");*/
                        intent.putExtra("audioPath", audioFilePath);
                        startActivity(intent);
                    }
                } else if (Utils.isNetworkConnection(getActivity())) {
                    Intent intent = new Intent(getActivity(), AudioPalyer.class);
                    intent.putExtra("audioPath", audioFilePathOnline);
                    startActivity(intent);
                }
                break;
            case R.id.fea_video_img:
                String videoFilePath = null;
                String videoFilePathOnline = null;
                switch (category) {
                    case AppConstants.FAB_FEATURES:
                        videoFilePath = fabMasterDTO.getF_videoFile_local();
                        videoFilePathOnline = fabMasterDTO.getF_videoFile();
                        break;
                    case AppConstants.FAB_ADVANTAGES:
                        videoFilePath = fabMasterDTO.getA_videoFile_local();
                        videoFilePathOnline = fabMasterDTO.getA_videoFile();
                        break;
                    case AppConstants.FAB_BENEFITS:
                        videoFilePath = fabMasterDTO.getB_videoFile_local();
                        videoFilePathOnline = fabMasterDTO.getB_videoFile();
                        break;
                }
                if (Utils.isValidStr(videoFilePath)) {
                    File newFile = new File(videoFilePath);
                    if (newFile.exists()) {
                        String fileExtention = videoFilePath.substring(videoFilePath.lastIndexOf(".") + 1, videoFilePath.length());
                        BuildLog.e("FIleNameExtention", fileExtention);
                        if (fileExtention.equals(AppConstants.GIF_FILE)) {
                            final Uri givFilePathUri = Uri.parse(videoFilePath);
                            DialogManager.showGifPopup(getActivity(), String.valueOf(givFilePathUri));

                        } else {
                            Intent intent = new Intent(getActivity(), VideoPlayerActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString(VideoPlayerActivity.VIDEO_EXTRAS, videoFilePath);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }
                    }
                } else if (Utils.isNetworkConnection(getActivity())) {
                    String fileExtention = videoFilePathOnline.substring(videoFilePathOnline.lastIndexOf(".") + 1, videoFilePathOnline.length());
                    if (fileExtention.equals(AppConstants.GIF_FILE)) {
                        final Uri givFilePathUri = Uri.parse(videoFilePathOnline);
                        DialogManager.showGifPopup(getActivity(), String.valueOf(givFilePathUri));

                    } else {
                        Intent intent = new Intent(getActivity(), VideoPlayerActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString(VideoPlayerActivity.VIDEO_EXTRAS, videoFilePathOnline);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }
                break;

            case R.id.fea_pdf_img:
                String pdfFilePath = null;
                String pdfFilePathOnline = null;
                switch (category) {
                    case AppConstants.FAB_FEATURES:
                        pdfFilePath = fabMasterDTO.getF_pdfFile_local();
                        pdfFilePathOnline = fabMasterDTO.getF_pdfFile();
                        break;
                    case AppConstants.FAB_ADVANTAGES:
                        pdfFilePath = fabMasterDTO.getA_pdfFile_local();
                        pdfFilePathOnline = fabMasterDTO.getA_pdfFile();
                        break;
                    case AppConstants.FAB_BENEFITS:
                        pdfFilePath = fabMasterDTO.getB_pdfFile_local();
                        pdfFilePathOnline = fabMasterDTO.getB_pdfFile();
                        break;
                }
                if (Utils.isValidStr(pdfFilePath)) {
                    File pdfFile = new File(pdfFilePath);
                    if (pdfFile.exists()) {
                        Intent gotoPdfViewer = new Intent(getActivity(), PDFViewerActivity.class);
                        gotoPdfViewer.putExtra("PdfFilePathKey", pdfFilePath);
                        startActivity(gotoPdfViewer);
                    }
                } else if (Utils.isNetworkConnection(getActivity())) {
                    Intent gotoPdfViewer = new Intent(getActivity(), PDFViewerActivity.class);
                    gotoPdfViewer.putExtra("PdfFilePathKey", pdfFilePathOnline);
                    startActivity(gotoPdfViewer);
                }
                break;
        }
    }
    /*
    View mRootView;
//    FabMasterDTO fabMasterDTO;
    FabMasterModel fabMasterDTO;
    private TextView noDataAvailableText;
    private RelativeLayout dataAvailableRL;
    private TextView messageText, messageNoText;
    private ImageView imagesButton, audioButton, videoButton, pdfButton;
    private LinearLayout bottomRowLL, feaMessageLL;

    private ArrayList<String> imgServerUrl = new ArrayList<>();
    private ArrayList<String> imgLocalUrls = new ArrayList<>();
    private ArrayList<String> imgsToDownload = new ArrayList<>();
    private ArrayList<String> imgsDownloaded = new ArrayList<>();

    private String st_message, st_message_local, st_image_url_array, st_audio_url, st_video_url,st_pdf_url;
    private String local_img_url_array, local_audio_url, local_video_url, local_pdf_url;
    private MediaPlayer player;
    private String category;
    private String empUserType;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle getArgs = getArguments();
        if (getArgs != null && getArgs.containsKey("fabArguments")) {
//            fabMasterDTO = (FabMasterDTO) getArgs.getSerializable("fabArguments");
            fabMasterDTO = (FabMasterModel) getArgs.getSerializable("fabArguments");
            category = getArgs.getString("fabCategory");
        }

        *//*if (AppConstants.USERTYPE_EMP.equals(Utils.getType(mActivity))){
            empUserType = AppConstants.USERTYPE_EMP;
        } else {
            empUserType = "";
        }*//*
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.emp_fragment_features, container, false);
        return mRootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initializeViews();
        refresh();
    }

    @Override
    public void refresh() {
        if(isAdded()) {
            fabMasterDTO = FabMasterDAO.getInstance().getRecordById(fabMasterDTO.getId(), DBHandler.getReadableDb(getActivity()));
            displayData(fabMasterDTO);
        }
    }

    private void initializeViews() {
        noDataAvailableText = (TextView) mRootView.findViewById(R.id.fea_noDataAvailable_text);
        dataAvailableRL = (RelativeLayout) mRootView.findViewById(R.id.fea_dataAvaialble_RL);
        messageText = (TextView) mRootView.findViewById(R.id.fea_message_text);
        messageNoText = (TextView) mRootView.findViewById(R.id.fea_message_no_text);
        imagesButton = (ImageView) mRootView.findViewById(R.id.fea_images_img);
        audioButton = (ImageView) mRootView.findViewById(R.id.fea_audio_img);
        videoButton = (ImageView) mRootView.findViewById(R.id.fea_video_img);
        pdfButton = (ImageView) mRootView.findViewById(R.id.fea_pdf_img);
        bottomRowLL = (LinearLayout) mRootView.findViewById(R.id.fea_botton_row_LL);
        feaMessageLL = (LinearLayout) mRootView.findViewById(R.id.fea_messages_LL);

        imagesButton.setOnClickListener(this);
        audioButton.setOnClickListener(this);
        videoButton.setOnClickListener(this);
        pdfButton.setOnClickListener(this);

        if (isAdded()) {
            if (AppConstants.USERTYPE_EMP.equals(Utils.getType(getActivity()))) {
                empUserType = AppConstants.USERTYPE_EMP;
            } else {
                empUserType = "";
            }
            displayData(fabMasterDTO);
        }
    }

//    private void displayData(FabMasterDTO fabMasterDTO) {
    private void displayData(FabMasterModel fabMasterDTO) {

        if (fabMasterDTO != null) {

                if (category.equals(AppConstants.FAB_FEATURES)) {
                    st_message = fabMasterDTO.getF_message();
                    st_message_local = fabMasterDTO.getF_localLangMessage();
                    st_image_url_array = fabMasterDTO.getF_images();
                    st_audio_url = fabMasterDTO.getF_voiceFile();
                    st_video_url = fabMasterDTO.getF_videoFile();
                    st_pdf_url = fabMasterDTO.getF_pdfFile();

                    local_img_url_array = fabMasterDTO.getF_images_local();
                    local_audio_url = fabMasterDTO.getF_voiceFile_local();
                    local_video_url = fabMasterDTO.getF_videoFile_local();
                    local_pdf_url = fabMasterDTO.getF_pdfFile_local();

                    StringBuilder msgBuilder = new StringBuilder();
                    if (Utils.isValidStr(st_message))
                        msgBuilder.append(st_message);
                    if (msgBuilder.length() > 0)
                        msgBuilder.append("\n\n");
                    if (Utils.isValidStr(st_message_local))
                        msgBuilder.append(st_message_local);

                    if (msgBuilder.length() > 0) {
                        messageText.setText(msgBuilder.toString());
                        messageText.setVisibility(View.VISIBLE);
                        messageNoText.setVisibility(View.GONE);
                    } else {
                    *//*messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);*//*
                        feaMessageLL.removeAllViews();
                        // FrameLayout is the parent for LinearLayout
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                        params.gravity = Gravity.CENTER | Gravity.CENTER_VERTICAL;
                        feaMessageLL.setLayoutParams(params);
                        messageText.setVisibility(View.GONE);
                        messageNoText.setVisibility(View.VISIBLE);
                        feaMessageLL.addView(messageNoText);
                    }

                    if (Utils.isValidStr(st_audio_url)) {
                        // take file name from URL and check whether it exist locally or not
                    } else {
                        audioButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_video_url)) {
                    } else {
                        videoButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_image_url_array)) {
                        // split the string seperated by # and make an array of it, then check each and every file whether exist locally or not
                    } else {
                        imagesButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_pdf_url) *//*&& AppConstants.USERTYPE_EMP.equals(Utils.getType(mActivity))*//* && Utils.isValidStr(empUserType)) {
                        // split the string seperated by # and make an array of it, then check each and every file whether exist locally or not
                    } else {
                        pdfButton.setVisibility(View.GONE);
                    }
                    if (!Utils.isValidStr(st_image_url_array) && !Utils.isValidStr(st_audio_url) && !Utils.isValidStr(st_video_url)) {

                        bottomRowLL.setVisibility(View.GONE);
                    }
                } else if (category.equals(AppConstants.FAB_ADVANTAGES)) {
                    st_message = fabMasterDTO.getA_message();
                    st_message_local = fabMasterDTO.getA_localLangMessage();
                    st_image_url_array = fabMasterDTO.getA_images();
                    st_audio_url = fabMasterDTO.getA_voiceFile();
                    st_video_url = fabMasterDTO.getA_videoFile();
                    st_pdf_url = fabMasterDTO.getA_pdfFile();

                    local_img_url_array = fabMasterDTO.getA_images_local();
                    local_audio_url = fabMasterDTO.getA_voiceFile_local();
                    local_video_url = fabMasterDTO.getA_videoFile_local();
                    local_pdf_url = fabMasterDTO.getA_pdfFile_local();

                    StringBuilder msgBuilder = new StringBuilder();
                    if (Utils.isValidStr(st_message))
                        msgBuilder.append(st_message);
                    if (msgBuilder.length() > 0)
                        msgBuilder.append("\n\n");
                    if (Utils.isValidStr(st_message_local))
                        msgBuilder.append(st_message_local);

                    if (msgBuilder.length() > 0) {
                        messageText.setText(msgBuilder.toString());
                        messageText.setVisibility(View.VISIBLE);
                        messageNoText.setVisibility(View.GONE);
                    } else {
                    *//*messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);*//*
                        feaMessageLL.removeAllViews();
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                        params.gravity = Gravity.CENTER | Gravity.CENTER_VERTICAL;
                        feaMessageLL.setLayoutParams(params);
                        messageText.setVisibility(View.GONE);
                        messageNoText.setVisibility(View.VISIBLE);
                        feaMessageLL.addView(messageNoText);
                    }
                    if (Utils.isValidStr(st_audio_url)) {
                        // take file name from URL and check whether it exist locally or not
                    } else {
                        audioButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_video_url)) {
                    } else {
                        videoButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_pdf_url) && Utils.isValidStr(empUserType)) {
                    } else {
                        pdfButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_image_url_array)) {
                        // split the string seperated by # and make an array of it, then check each and every file whether exist locally or not
                    } else {
                        imagesButton.setVisibility(View.GONE);
                    }
                    if (!Utils.isValidStr(st_image_url_array) && !Utils.isValidStr(st_audio_url) && !Utils.isValidStr(st_video_url)) {
                        bottomRowLL.setVisibility(View.GONE);
                    }
                } else if (category.equals(AppConstants.FAB_BENEFITS)) {
                    st_message = fabMasterDTO.getB_message();
                    st_message_local = fabMasterDTO.getB_localLangMessage();
                    st_image_url_array = fabMasterDTO.getB_images();
                    st_audio_url = fabMasterDTO.getB_voiceFile();
                    st_video_url = fabMasterDTO.getB_videoFile();
                    st_pdf_url = fabMasterDTO.getB_pdfFile();

                    local_img_url_array = fabMasterDTO.getB_images_local();
                    local_audio_url = fabMasterDTO.getB_voiceFile_local();
                    local_video_url = fabMasterDTO.getB_videoFile_local();
                    local_pdf_url = fabMasterDTO.getB_pdfFile_local();

                    StringBuilder msgBuilder = new StringBuilder();
                    if (Utils.isValidStr(st_message))
                        msgBuilder.append(st_message);
                    if (msgBuilder.length() > 0)
                        msgBuilder.append("\n\n");
                    if (Utils.isValidStr(st_message_local))
                        msgBuilder.append(st_message_local);

                    if (msgBuilder.length() > 0) {
                        messageText.setText(msgBuilder.toString());
                        messageText.setVisibility(View.VISIBLE);
                        messageNoText.setVisibility(View.GONE);
                    } else {
                    *//*feaMessageLL.removeAllViews();
                    feaMessageLL.setGravity(Gravity.CENTER);*//*
                   *//* messageText.setVisibility(View.GONE);
                    messageNoText.setVisibility(View.VISIBLE);*//*
//                    feaMessageLL.addView(messageNoText);
                        // Change the layout_gravity (not gravity) of the LinearLayout
                        feaMessageLL.removeAllViews();
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                        params.gravity = Gravity.CENTER | Gravity.CENTER_VERTICAL;
                        feaMessageLL.setLayoutParams(params);
                        messageText.setVisibility(View.GONE);
                        messageNoText.setVisibility(View.VISIBLE);
                        feaMessageLL.addView(messageNoText);
                    }

                    if (Utils.isValidStr(st_audio_url)) {
                        // take file name from URL and check whether it exist locally or not
                    } else {
                        audioButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_video_url)) {
                    } else {
                        videoButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_pdf_url) && Utils.isValidStr(empUserType)) {
                        pdfButton.setVisibility(View.VISIBLE);
                    } else {
                        pdfButton.setVisibility(View.GONE);
                    }
                    if (Utils.isValidStr(st_image_url_array)) {
                        // split the string seperated by # and make an array of it, then check each and every file whether exist locally or not
                    } else {
                        imagesButton.setVisibility(View.GONE);
                    }
                    if (!Utils.isValidStr(st_image_url_array) && !Utils.isValidStr(st_audio_url) && !Utils.isValidStr(st_video_url)) {
                        bottomRowLL.setVisibility(View.GONE);
                    }
                }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fea_images_img:

                if (category.equals(AppConstants.FAB_FEATURES)) {
                    String images = fabMasterDTO.getF_images_local();
                    if (Utils.isValidStr(images)) {
                        DialogManager.showGalleryPopup(getActivity(), images.split("#"));
                    } else {
                        //write something here
                    }
                } else if (category.equals(AppConstants.FAB_ADVANTAGES)){
                    String images = fabMasterDTO.getA_images_local();
                    if (Utils.isValidStr(images)) {
                        DialogManager.showGalleryPopup(getActivity(), images.split("#"));
                    } else {
                        //write something here
                    }
                } else if (category.equals(AppConstants.FAB_BENEFITS)){
                    String images = fabMasterDTO.getB_images_local();
                    if (Utils.isValidStr(images)) {
                        DialogManager.showGalleryPopup(getActivity(), images.split("#"));
                    } else {
                        //write something here
                    }
                }
                break;
            case R.id.fea_audio_img:
                String audioFilePath = null;
                if (category.equals(AppConstants.FAB_FEATURES)) {
                    audioFilePath = fabMasterDTO.getF_voiceFile_local();
                    *//*if (Utils.isValidStr(audioFilePath)) {
                        File newFile = new File(audioFilePath);
                        if (newFile.exists()) {
                            Intent intent = new Intent();
                            intent.setAction(android.content.Intent.ACTION_VIEW);
                            File file = new File(audioFilePath);
                            intent.setDataAndType(Uri.fromFile(file), "audio*//**//*");
                            startActivity(intent);
                        }
                    }*//*
                } else if (category.equals(AppConstants.FAB_ADVANTAGES)){
                     audioFilePath = fabMasterDTO.getA_voiceFile_local();
                    *//*if (Utils.isValidStr(audioFilePath)) {
                        File newFile = new File(audioFilePath);
                        if (newFile.exists()) {
                            Intent intent = new Intent();
                            intent.setAction(android.content.Intent.ACTION_VIEW);
                            File file = new File(audioFilePath);
                            intent.setDataAndType(Uri.fromFile(file), "audio*//**//*");
                            startActivity(intent);
                        }
                    }*//*
                } else if (category.equals(AppConstants.FAB_BENEFITS)){
                    audioFilePath = fabMasterDTO.getB_voiceFile_local();
                    *//*if (Utils.isValidStr(audioFilePath)) {
                        File newFile = new File(audioFilePath);
                        if (newFile.exists()) {
                            Intent intent = new Intent();
                            intent.setAction(android.content.Intent.ACTION_VIEW);
                            File file = new File(audioFilePath);
                            intent.setDataAndType(Uri.fromFile(file), "audio*//**//*");
                            startActivity(intent);
                        }
                    }*//*
                }
                if (Utils.isValidStr(audioFilePath)) {
                    File newFile = new File(audioFilePath);
                    if (newFile.exists()) {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        File file = new File(audioFilePath);
                        intent.setDataAndType(Uri.fromFile(file), "audio*//*");
                        startActivity(intent);
                    }
                }
                break;
            case R.id.fea_video_img:
                String videoFilePath = null;
                if (category.equals(AppConstants.FAB_FEATURES)) {
                    videoFilePath = fabMasterDTO.getF_videoFile_local();
                } else if (category.equals(AppConstants.FAB_ADVANTAGES)){
                    videoFilePath = fabMasterDTO.getA_videoFile_local();
                } else if (category.equals(AppConstants.FAB_BENEFITS)){
                    videoFilePath = fabMasterDTO.getB_videoFile_local();
                }
                if (Utils.isValidStr(videoFilePath)) {
                    File newFile = new File(videoFilePath);
                    if (newFile.exists()) {

                        String fileExtention= videoFilePath.substring(videoFilePath.lastIndexOf(".") + 1, videoFilePath.length());
                        BuildLog.e("FIleNameExtention", fileExtention);
                        if (fileExtention.equals(AppConstants.GIF_FILE)){
                            final Uri givFilePathUri = Uri.parse(videoFilePath);
                            DialogManager.showGifPopup(getActivity(), String.valueOf(givFilePathUri));

                        } else {
                            final Uri videoFilePathUri = Uri.parse(videoFilePath);
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setDataAndType(videoFilePathUri, "video/mp4");
                            startActivity(intent);
                        }
                    }
                }
                break;
            case R.id.fea_pdf_img:
                String pdfFilePath = null;
                if (category.equals(AppConstants.FAB_FEATURES)){
                    pdfFilePath = fabMasterDTO.getF_pdfFile_local();
                }else if (category.equals(AppConstants.FAB_ADVANTAGES)){
                    pdfFilePath = fabMasterDTO.getA_pdfFile_local();
                } else if (category.equals(AppConstants.FAB_BENEFITS)){
                    pdfFilePath = fabMasterDTO.getB_pdfFile_local();
                }

                Intent gotoPdfViewer = new Intent(getActivity(), PDFViewerActivity.class);
                gotoPdfViewer.putExtra("PdfFilePathKey", pdfFilePath);
                startActivity(gotoPdfViewer);

                break;
        }
    }*/
}
