package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.LiquidSeasonIds;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.RetailSeasonIds;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

public class CropMasterDAO implements DAO {
    private final String TAG = "CropMasterDAO";
    private static CropMasterDAO cropMasterDao;

    public static CropMasterDAO getInstance() {
        if (cropMasterDao == null) {
            cropMasterDao = new CropMasterDAO();
        }
        return cropMasterDao;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            LiquidSeasonIds dto = (LiquidSeasonIds) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("id", dto.getId());
            cv.put("name", dto.getName());
            cv.put("seasonId", dto.getSeasonId());

            long rowsEffected = dbObject.insert(DBHandler.TABLE_CROP_LIQUID, null, cv);
            if (rowsEffected > 0)
                return "";
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> cropData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_CROP_LIQUID, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    LiquidSeasonIds dto = new LiquidSeasonIds();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return cropData;
    }
    public List<DTO> getRecordById(long id, SQLiteDatabase dbObject) {
        List<DTO> cropData = new ArrayList<>();
        LiquidSeasonIds dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + DBHandler.TABLE_CROP_LIQUID + " WHERE seasonId = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new LiquidSeasonIds();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return cropData;
    }
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_CROP_LIQUID).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
}
