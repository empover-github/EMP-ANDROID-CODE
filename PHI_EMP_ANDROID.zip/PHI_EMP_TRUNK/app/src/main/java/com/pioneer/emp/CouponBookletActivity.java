package com.pioneer.emp;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.adapters.CouponBookletAdapter;
import com.pioneer.emp.dto.CouponBookletDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.CouponsBookletDetailsResponse;
import com.pioneer.emp.models.PravaktaAssistanceOtpModel;
import com.pioneer.emp.models.PravaktaBookletResponse;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.apiInterfaces.CommonInterface;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;

/**
 * Created by hareesh.a on 7/11/2017.
 */

public class CouponBookletActivity extends BaseActivity implements OnBookletClickListener, CommonInterface {

    RecyclerView recyclerView;
    TextView tvnetwork, tvtryagain;
    LinearLayout tvlinear;
    Toolbar toolbar;
    private CouponBookletAdapter couponAdapter;
    ArrayList<CouponBookletDTO> couponsList;
    private PravaktaAssistanceOtpModel pravaktaDetails = new PravaktaAssistanceOtpModel();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_activity_coupon_booklet);
        /*pravaktaDetailsbundle = getIntent().getExtras();
        if (pravaktaDetailsbundle !=null && pravaktaDetailsbundle.containsKey(PravaktaAssistantActivity.EXTRA_PRAVAKTA_DETAILS)) {
            pravaktaDetails = (PravaktaAssistanceOtpModel) pravaktaDetailsbundle.getSerializable(PravaktaAssistantActivity.EXTRA_PRAVAKTA_DETAILS);
        }*/
        Intent getDataFromPAA = getIntent();
        /*if (getDataFromPAA != null){*/
        if (getDataFromPAA.hasExtra(PravaktaAssistantActivity.PUT_EXTRA_CUSTOMER_ID_PRAVAKTA) || getDataFromPAA.hasExtra(PravaktaAssistantActivity.PUT_EXTRA_CUSTOMER_MOBILE_NO_PRAVAKTA)) {
            pravaktaDetails.setPravaktaId(getDataFromPAA.getStringExtra(PravaktaAssistantActivity.PUT_EXTRA_CUSTOMER_ID_PRAVAKTA));
            pravaktaDetails.setMobileNumber(getDataFromPAA.getStringExtra(PravaktaAssistantActivity.PUT_EXTRA_CUSTOMER_MOBILE_NO_PRAVAKTA));
        }
        initToolBar();
        tvnetwork = findViewById(R.id.network_connection_TV);
        tvtryagain = findViewById(R.id.try_again_TV);
        tvlinear = findViewById(R.id.TV_linear);
        recyclerView = findViewById(R.id.recycler_view);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        couponsList = new ArrayList<>();
        couponAdapter = new CouponBookletAdapter(this, couponsList, this);
        recyclerView.setAdapter(couponAdapter);
    }

    public void initToolBar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(0xFFFFFFFF);
        getSupportActionBar().setTitle(getResources().getString(R.string.booklet));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);
        /*toolbar.setNavigationOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                    }
                }
        );*/
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (Utils.isNetworkConnection(CouponBookletActivity.this)) {
            recyclerView.setVisibility(View.VISIBLE);
            APIRequestHandler.getInstance().getPravaktaBookletResponse(CouponBookletActivity.this, pravaktaDetails.getMobileNumber(), CouponBookletActivity.this);
        } else {
            tvlinear.setVisibility(View.VISIBLE);
            tvnetwork.setVisibility(View.VISIBLE);
            tvtryagain.setVisibility(View.VISIBLE);
            tvnetwork.setText(R.string.no_internet);
            tvtryagain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onStart();
                }
            });
        }
    }

    /* private ArrayList<CouponBookletDTO> getNotificationsData() {
        try {
            InputStream is = this.getAssets().open("couponsBooklet.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            CouponsBookletDetailsResponse allProdInfo = new Gson().fromJson(sb.toString(), CouponsBookletDetailsResponse.class);

            return allProdInfo.getBookletList();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }*/

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        CouponBookletDTO dto = couponsList.get(position);
        Intent couponListIntent = new Intent(this, CouponListActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("couponList", dto);
        bundle.putSerializable("pravaktaDetails",pravaktaDetails.getPravaktaId());
        couponListIntent.putExtras(bundle);
        startActivity(couponListIntent);
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);
        if (responseObj != null) {
            if (responseObj instanceof PravaktaBookletResponse) {
                PravaktaBookletResponse pravaktaBookletResponse = (PravaktaBookletResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == pravaktaBookletResponse.getStatusCode()) {
                    CouponsBookletDetailsResponse BookletModel = pravaktaBookletResponse.getResponseObj();
                    couponsList.clear();
                    couponsList.addAll(BookletModel.getBookletList());
                    couponAdapter.notifyDataSetChanged();
                } else if (AppConstants.NO_BOOKLETS_AVAILABLE_CODE == pravaktaBookletResponse.getStatusCode()) {
                    recyclerView.setVisibility(View.GONE);
                    tvlinear.setVisibility(View.VISIBLE);
                    tvnetwork.setVisibility(View.VISIBLE);
                    tvnetwork.setText(pravaktaBookletResponse.getMessage());
                } else {
                    DialogManager.showToast(CouponBookletActivity.this, pravaktaBookletResponse.getMessage());
                }

            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}

