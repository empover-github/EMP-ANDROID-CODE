package com.pioneer.emp.cropDiagnostic;

import java.io.Serializable;

/**
 * Created by Yakaswamy.g on 8/16/2017.
 */

public class CropDiseaseModel implements Serializable{
    private String diseaseName;
    private String diseaseScientificName;
    private boolean exactMatch;
    private float probability;
    private String imagePath;
    private long id;
    private long diseaseId;
    private String diseaseRequestId;
    private String cdi_images_local;// extra added
    private String diseaseType;

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public String getDiseaseScientificName() {
        return diseaseScientificName;
    }

    public void setDiseaseScientificName(String diseaseScientificName) {
        this.diseaseScientificName = diseaseScientificName;
    }

    public boolean isExactMatch() {
        return exactMatch;
    }

    public void setExactMatch(boolean exactMatch) {
        this.exactMatch = exactMatch;
    }

    public float getProbability() {
        return probability;
    }

    public void setProbability(float probability) {
        this.probability = probability;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDiseaseId() {
        return diseaseId;
    }

    public void setDiseaseId(long diseaseId) {
        this.diseaseId = diseaseId;
    }

    public String getDiseaseRequestId() {
        return diseaseRequestId;
    }

    public void setDiseaseRequestId(String diseaseRequestId) {
        this.diseaseRequestId = diseaseRequestId;
    }

    public String getCdi_images_local() {
        return cdi_images_local;
    }

    public void setCdi_images_local(String cdi_images_local) {
        this.cdi_images_local = cdi_images_local;
    }

    public String getDiseaseType() {
        return diseaseType;
    }

    public void setDiseaseType(String diseaseType) {
        this.diseaseType = diseaseType;
    }
}
