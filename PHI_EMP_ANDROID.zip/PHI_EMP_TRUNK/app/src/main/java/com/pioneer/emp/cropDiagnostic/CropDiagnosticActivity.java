package com.pioneer.emp.cropDiagnostic;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.activitytrack.utility.Utility;
import com.pioneer.emp.R;
import com.pioneer.emp.models.CommonResEntity;
import com.pioneer.emp.models.DiagnosisFeedbackResponse;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.apiInterfaces.CommonInterface;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import retrofit.RetrofitError;

/**
 * Created by fatima.t on 19-09-2017.
 */

public class CropDiagnosticActivity extends BaseActivity implements View.OnClickListener, CommonInterface {
    public static final String EXTRA_IS_LIBRARY = "isLibrary";
    public static final String EXTRA_CROP = "crop";
    private ArrayList<CropDiseaseModel> diagnosisList;
    private boolean isLibrary;
    public static final String EXTRA_RESPONSE = "diseaseResponse";
    RecyclerView recyclerView;
    private DiseasesAdapter notificationAdapter;
    private Toolbar toolbar;
    private TextView txtHeader;
    private ActionBar actionBar;
    private String crop;
    private LinearLayout footerLayout;
    //newly added
    private Button btnFeedBackSubmit;
    private DiagnosisFeedbackResponse diagnosisFeedbackResponse;
    private boolean likeImageClicked, unLikeImageClicked;
    private static final String TAG = "cropDiagnosticActivity";
    private long feedBackId,diseaseId;
    public static final String EXTRA_FEEDBACK_ID = "id";
    //newly added
    private EditText edtMentdisease;
    private LinearLayout feedBackLayout;
    private ImageView imgLikeView, imgUnLikeView;
    //newly added
    private TextView tvCustomerCare;
    public static final String EXTRA_DISEASE_ID = "diseaseId";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_diagnostic);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setTitle(getString(R.string.how_to_capture_photo));
        txtHeader = findViewById(R.id.header_text);

        footerLayout = findViewById(R.id.footerLayout);
        //newly added
        edtMentdisease = findViewById(R.id.cd_edt_menti_disease);
        feedBackLayout = findViewById(R.id.cd_feedback_layout);
        imgLikeView = findViewById(R.id.cd_img_like);
        imgUnLikeView = findViewById(R.id.cd_img_unlike);

        btnFeedBackSubmit = findViewById(R.id.cd_btnSubmit);
        btnFeedBackSubmit.setOnClickListener(this);
        imgLikeView.setOnClickListener(this);
        imgUnLikeView.setOnClickListener(this);
        btnFeedBackSubmit.setVisibility(View.GONE);

        //newly added
        tvCustomerCare = (TextView) findViewById(R.id.txt_customer_care);
        SpannableString ss = new SpannableString(
                getResources().getString(R.string.customer_care));
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                String number = "+91-18001039799";
                String dialNo = number.trim().replaceAll("\\D+", "");
                if (dialNo.startsWith("91")) {
                    dialNo = "+" + dialNo;
                    intent.setData(Uri.parse("tel:" + dialNo));
                    view.getContext().startActivity(intent);
                }
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(getResources().getColor(R.color.blue_marker));
            }
        };

        ss.setSpan(clickableSpan, 57, 70, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvCustomerCare.setText(ss);
        tvCustomerCare.setMovementMethod(LinkMovementMethod.getInstance());
        Bundle bundle = getIntent().getExtras();
        if (bundle != null && bundle.containsKey(EXTRA_RESPONSE)) {
            diagnosisList = (ArrayList<CropDiseaseModel>) bundle.getSerializable(EXTRA_RESPONSE);
        }

        if (bundle != null && bundle.containsKey(EXTRA_IS_LIBRARY)) {
            isLibrary = bundle.getBoolean(EXTRA_IS_LIBRARY);
        }

        if (bundle != null && bundle.containsKey(EXTRA_CROP)) {
            crop = bundle.getString(EXTRA_CROP);
        }

        if (isLibrary) {
            txtHeader.setText(crop + " - " + getString(R.string.title_diseases));
            footerLayout.setVisibility(View.GONE);
        } else {
            txtHeader.setText(getString(R.string.title_diagnosis_chance));
            footerLayout.setVisibility(View.VISIBLE);
        }
        if (bundle != null && bundle.containsKey(EXTRA_FEEDBACK_ID)) {
            feedBackId = bundle.getLong(EXTRA_FEEDBACK_ID);
        }
        if (bundle != null && bundle.containsKey(EXTRA_DISEASE_ID)) {
            diseaseId = bundle.getLong(EXTRA_DISEASE_ID);
        }
        recyclerView = findViewById(R.id.recycler_view);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(CropDiagnosticActivity.this);
        recyclerView.setLayoutManager(layoutManager);

        if (diagnosisList == null) {
            diagnosisList = new ArrayList<>();
        }
        notificationAdapter = new DiseasesAdapter(CropDiagnosticActivity.this, diagnosisList, crop);
        recyclerView.setAdapter(notificationAdapter);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null) {
            if (responseObj instanceof CommonResEntity) {
                CommonResEntity commonResEntity = (CommonResEntity) responseObj;
                if (AppConstants.STATUS_CODE.equals(commonResEntity.getStatusCode())) {
                    DialogManager.showToast(CropDiagnosticActivity.this, commonResEntity.getMessage());
                    btnFeedBackSubmit.setVisibility(View.INVISIBLE);
                    feedBackLayout.setVisibility(View.GONE);

                } else if (AppConstants.SOMETHING_WENT_WRONG.equals(commonResEntity.getStatusCode())) {
                    DialogManager.showToast(CropDiagnosticActivity.this, commonResEntity.getMessage());
                    feedBackLayout.setVisibility(View.VISIBLE);
                }
            }
        }

    }

    @Override
    public void onRequestFailure(RetrofitError errorCode, String errorFrom) {
        super.onRequestFailure(errorCode, errorFrom);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cd_img_like:
                likeImageClicked = true;
                footerLayout.setVisibility(View.VISIBLE);
                imgLikeView.setImageResource(R.drawable.like_image);
                imgUnLikeView.setImageResource(R.drawable.unlike_image_grey);
                edtMentdisease.setVisibility(View.GONE);
                btnFeedBackSubmit.setVisibility(View.GONE);
                if (Utility.networkAvailability(CropDiagnosticActivity.this)) {
                    JSONObject jsonObject = new JSONObject();
                    try {

                        /*jsonObject.put(EXTRA_FEEDBACK_ID, feedBackId);
                        jsonObject.put("isLike", true);*/
                        jsonObject.put("userType", AppConstants.EMPLOYEE);
                        jsonObject.put("customerId", Utils.getUserId(CropDiagnosticActivity.this));
                        jsonObject.put("mobileNo", Utils.getUserMobile(CropDiagnosticActivity.this));
                        jsonObject.put("accrracyFlag", "true");
                        jsonObject.put("comments", "");
                        jsonObject.put(EXTRA_DISEASE_ID, diseaseId);
                        Log.d(TAG, "likeImageCliked is true");
                        likeImageClicked = false;


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String jwtToken = Utils.getJWTTokenFC(jsonObject.toString(), CropDiagnosticActivity.this);
                    APIRequestHandler.getInstance().cropDiagnosisFeedBackRequest(jwtToken, CropDiagnosticActivity.this, CropDiagnosticActivity.this, true);
                } else {
                    DialogManager.showToast(CropDiagnosticActivity.this, getString(R.string.no_internet));
                }
                break;
            case R.id.cd_img_unlike:
                footerLayout.setVisibility(View.VISIBLE);
                unLikeImageClicked = true;
                imgLikeView.setImageResource(R.drawable.like_grey_image);
                imgUnLikeView.setImageResource(R.drawable.unlike_image);
                edtMentdisease.setVisibility(View.VISIBLE);
                btnFeedBackSubmit.setVisibility(View.VISIBLE);


                break;
            case R.id.cd_btnSubmit:
                if (Utility.networkAvailability(CropDiagnosticActivity.this)) {
                    JSONObject jsonObject = new JSONObject();
                    try {

                       /* jsonObject.put(EXTRA_FEEDBACK_ID, feedBackId);
                        jsonObject.put("isLike", false);
                        jsonObject.put("diseasenameByCustomer", edtMentdisease.getText().toString());*/
                        jsonObject.put("userType", AppConstants.EMPLOYEE);
                        jsonObject.put("customerId", Utils.getUserId(CropDiagnosticActivity.this));
                        jsonObject.put("mobileNo", Utils.getUserMobile(CropDiagnosticActivity.this));
                        jsonObject.put("accrracyFlag", "false");
                        jsonObject.put("comments", edtMentdisease.getText().toString());
                        jsonObject.put(EXTRA_DISEASE_ID, diseaseId);
                        String data = edtMentdisease.getText().toString();
                        Log.d(TAG, "diseasenameByCustomer is " + data);
                        unLikeImageClicked = false;
                        Log.d(TAG, "isLike ,UnlikeImageCliked is false");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    String jwtToken = Utils.getJWTTokenFC(jsonObject.toString(), CropDiagnosticActivity.this);
                    APIRequestHandler.getInstance().cropDiagnosisFeedBackRequest(jwtToken, CropDiagnosticActivity.this, CropDiagnosticActivity.this, true);
                } else {
                    DialogManager.showToast(CropDiagnosticActivity.this, getString(R.string.no_internet));
                }
                break;
        }
    }
}
