package com.pioneer.emp.dto;

import java.io.Serializable;

/**
 * Created by hareesh.a on 7/11/2017.
 */

public class CouponListDTO implements Serializable {

    private String couponNumber;
    private Boolean isShared;
    private String sharedToMobileNo;
    private String sharedToName;
    private String couponId;
    private String sharedOn;

    public String getCouponNumber() {
        return couponNumber;
    }

    public void setCouponNumber(String couponNumber) {
        this.couponNumber = couponNumber;
    }

    public Boolean getShared() {
        return isShared;
    }

    public void setShared(Boolean shared) {
        isShared = shared;
    }

    public String getSharedToMobileNo() {
        return sharedToMobileNo;
    }

    public void setSharedToMobileNo(String sharedToMobileNo) {
        this.sharedToMobileNo = sharedToMobileNo;
    }

    public String getSharedToName() {
        return sharedToName;
    }

    public void setSharedToName(String sharedToName) {
        this.sharedToName = sharedToName;
    }

    public String getCouponId() {
        return couponId;
    }

    public void setCouponId(String couponId) {
        this.couponId = couponId;
    }

    public String getSharedOn() {
        return sharedOn;
    }

    public void setSharedOn(String sharedOn) {
        this.sharedOn = sharedOn;
    }
}
