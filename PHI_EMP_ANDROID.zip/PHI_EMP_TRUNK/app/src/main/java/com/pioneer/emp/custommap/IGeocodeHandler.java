package com.pioneer.emp.custommap;

import android.location.Address;

/**
 * Created by Fatima on 09-01-2018.
 */
public interface IGeocodeHandler {

    void onGeocodeSuccess(Address address);
    void onGeocodeError(String message);

}
