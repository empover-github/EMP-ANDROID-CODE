package com.pioneer.emp.fab.asyncTasks;

import android.app.Activity;
import android.content.ContextWrapper;
import android.os.AsyncTask;

import com.pioneer.emp.fab.dto.DownloadFileDTO;
import com.pioneer.emp.fab.listeners.AsyncCallback;
import com.pioneer.emp.fab.services.DownloadFileService;
import static com.pioneer.emp.fab.services.DownloadFileService.*;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.Utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by rambabu.a on 07-07-2017.
 */

public class DownloadFileAsync extends AsyncTask<String, String, DownloadFileDTO> {

    private DownloadFileDTO downloadFileDTO;
    private AsyncCallback asyncCallback;
    private ContextWrapper contextWrapper;

    public DownloadFileAsync(ContextWrapper contextWrapper,DownloadFileDTO downloadFileDTO, AsyncCallback asyncCallback){
        this.contextWrapper = contextWrapper;
        this.downloadFileDTO = downloadFileDTO;
        this.asyncCallback = asyncCallback;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected DownloadFileDTO doInBackground(String... params) {
        return downloadFile(params);
    }

    @Override
    protected void onPostExecute(DownloadFileDTO s) {
        super.onPostExecute(s);
        if (s.getResultCode() == RESULT_SUCCESS){
            asyncCallback.onSuccess(downloadFileDTO);
        }else {
            asyncCallback.onFailure(downloadFileDTO);
        }
    }

    private DownloadFileDTO downloadFile(String... dwnload_file_path) {
        try {
            String downloadFileUrl = dwnload_file_path[0];
            URL url = new URL(downloadFileUrl);
            HttpURLConnection urlConnection = (HttpURLConnection) url
                    .openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setDoOutput(true);
            urlConnection.connect();
            String extStorage = getFolderPath();
            File fileDir = new File(extStorage);
            if (!fileDir.exists())
                fileDir.mkdirs();
            File file = new File(fileDir, downloadFileUrl.substring(downloadFileUrl.lastIndexOf('/')+1));
            FileOutputStream fileOutput = new FileOutputStream(file);
            InputStream inputStream = urlConnection.getInputStream();
            byte[] buffer = new byte[10 * 1024];
            int bufferLength = 0;
            while ((bufferLength = inputStream.read(buffer)) != -1) {
                fileOutput.write(buffer, 0, bufferLength);
            }
            downloadFileDTO.setResultCode(RESULT_SUCCESS);
            downloadFileDTO.setLocalURL(file.getAbsolutePath());
            fileOutput.flush(); // Written by TARA
            fileOutput.close();
            inputStream.close(); // Written by TARA
        } catch (MalformedURLException e) {
            BuildLog.d("Error", "MalformedURLException " + e);
            e.printStackTrace();
            downloadFileDTO.setResultCode(RESULT_EXP_MF);
        } catch (IOException e) {
            downloadFileDTO.setResultCode(RESULT_EXP_IO);
            if(e instanceof FileNotFoundException)
                downloadFileDTO.setResultCode(RESULT_EXP_FNF);
            BuildLog.d("Error", "IOException " + e);
            e.printStackTrace();
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            downloadFileDTO.setResultCode(RESULT_EXP_OFM);
        } catch (Exception e) {
            e.printStackTrace();
            downloadFileDTO.setResultCode(RESULT_FAILED);
        }
        return downloadFileDTO;
    }

    private String getFolderPath() {

        String dirPath = contextWrapper.getFilesDir().getAbsolutePath();//Environment.getExternalStorageDirectory().toString();
        dirPath = dirPath + File.separator+"Files"+File.separator+"Former_Connect";
        if (AppConstants.CDI_IMAGE.equalsIgnoreCase(downloadFileDTO.getCategory())) {
            dirPath = dirPath + File.separator + "CDI_Images";
        } else if (AppConstants.AGRO_IMAGE.equalsIgnoreCase(downloadFileDTO.getCategory())) {
            dirPath = dirPath + File.separator + "AGRO_Images";
        } else if(AppConstants.IMAGE_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath + File.separator+"Images";
        } else if(AppConstants.VOICE_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath +File.separator+"Audio";
        } else if(AppConstants.VIDEO_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath + File.separator+"Videos";
        } else if(AppConstants.PDF_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath + File.separator+"PDFs";
        }
        return dirPath;
    }
}
