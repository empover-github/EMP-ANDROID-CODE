package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.models.CropAdvisoryStagesModel;
import com.pioneer.emp.R;
import com.pioneer.emp.listeners.OnItemClickListener;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;

/**
 * Created by hareesh.a on 5/8/2017.
 */

public class CropMessageListViewAdapter extends RecyclerView.Adapter<CropMessageListViewAdapter.ViewHolder> {
    private final OnItemClickListener listener;
    private Context context;
    private ArrayList<CropAdvisoryStagesModel> categorymessageDTOArrayList;

    public CropMessageListViewAdapter(Context context, ArrayList<CropAdvisoryStagesModel> categorymessageDTOArrayList, OnItemClickListener listener) {
        this.context = context;
        this.categorymessageDTOArrayList = categorymessageDTOArrayList;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View messageView = LayoutInflater.from(parent.getContext()).inflate(R.layout.emp_crop_message_list_view, parent, false);
        return new ViewHolder(messageView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.bind(categorymessageDTOArrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return categorymessageDTOArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView localmsg, msg, /*date,*/ days /*stage, expected*/;
        LinearLayout lo_msg_lin,msg_lin,no_days_lin/*,stage_lin,expected_lin*/ ,audio_play_lin;
        ImageView play_image;
        String audio;

        public ViewHolder(View view) {
            super(view);
            localmsg = view.findViewById(R.id.local_msg_TV);
            msg = view.findViewById(R.id.msg_TV);
//            date = (TextView) view.findViewById(R.id.sent_on_TV);
            play_image = view.findViewById(R.id.play_image);
            days = view.findViewById(R.id.cmlv_no_of_days_TV);
//            stage = (TextView) view.findViewById(R.id.cmlv_stage_TV);
//            expected = (TextView) view.findViewById(R.id.cmlv_expected_date_TV);
            no_days_lin = view.findViewById(R.id.no_of_days_linear);
//            stage_lin = (LinearLayout) view.findViewById(R.id.stage_linear);
//            expected_lin = (LinearLayout) view.findViewById(R.id.expecteddate_linear);
            lo_msg_lin = view.findViewById(R.id.local_msg_linear);
            msg_lin = view.findViewById(R.id.msg_linear);

            audio_play_lin = view.findViewById(R.id.play_audio_linear);
        }

        void bind(final CropAdvisoryStagesModel categorymessage) {
            if (Utils.isValidStr(categorymessage.getMessage())) {
                msg_lin.setVisibility(View.VISIBLE);
                msg.setText(categorymessage.getMessage());
            } else {
                msg_lin.setVisibility(View.GONE);
            }

            if (Utils.isValidStr(categorymessage.getMessageInLocaLang())) {
                lo_msg_lin.setVisibility(View.VISIBLE);
                localmsg.setText(categorymessage.getMessageInLocaLang());
            } else {
                lo_msg_lin.setVisibility(View.GONE);
            }

            if (Utils.isValidStr(categorymessage.getNoOfDays())) {
                no_days_lin.setVisibility(View.VISIBLE);
                days.setText(categorymessage.getNoOfDays());
            } else {
                no_days_lin.setVisibility(View.GONE);
            }

            /*if (Utils.isValidStr(categorymessage.getStageName())) {
                stage_lin.setVisibility(View.VISIBLE);
                stage.setText(categorymessage.getStageName());
            } else {
                stage_lin.setVisibility(View.GONE);
            }*/

           /* if (Utils.isValidStr(categorymessage.getSupposeToBeOn())) {
                expected_lin.setVisibility(View.VISIBLE);
                expected.setText(categorymessage.getSupposeToBeOn());
            } else {
                expected_lin.setVisibility(View.GONE);
            }*/

           if (Utils.isValidStr(categorymessage.getVoiceFileName()) /*|| Utils.isValidStr(categorymessage.getVoiceFileLocalPath())*/){
               audio_play_lin.setVisibility(View.VISIBLE);
               audio = categorymessage.getVoiceFileName();
           } else {
               audio_play_lin.setVisibility(View.GONE);
           }



//            date.setText(getDateConvertString(categorymessage.getSentOn()));


            play_image.setOnClickListener(this);
            if (audio != null && !audio.trim().isEmpty()) {
                play_image.setVisibility(View.VISIBLE);
                play_image.setTag(categorymessage);

                if (categorymessage.isPlaying())
                    play_image.setImageResource(R.mipmap.ic_pause_button);
                else
                    play_image.setImageResource(R.mipmap.ic_play_button);
            } else {
                play_image.setVisibility(View.GONE);
                play_image.setTag(null);
            }
        }

        @Override
        public void onClick(View v) {
            Object obj = v.getTag();
            if (obj == null)
                return;
            listener.onItemClick(v, null);

        }

    }

    /*private String getDateConvertString(String convertdate) {
        String date = convertdate;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date myDate = null;
        try {
            myDate = dateFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat timeFormat = new SimpleDateFormat("dd-MMM-yyyy");
        String finaldate = timeFormat.format(myDate);
        return finaldate;
    }*/

}
