package com.pioneer.emp.dto;


import com.pioneer.parivaar.dto.DTO;

/**
 * Created by rambabu.a on 09-03-2018.
 */

public class UpLoadRetailAuditFileDTO implements DTO {
    private String imageUrlPath;
    private int isSync;
    private long serverId;

    public String getImageUrlPath() {
        return imageUrlPath;
    }

    public void setImageUrlPath(String imageUrlPath) {
        this.imageUrlPath = imageUrlPath;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public long getServerId() {
        return serverId;
    }

    public void setServerId(long serverId) {
        this.serverId = serverId;
    }
}
