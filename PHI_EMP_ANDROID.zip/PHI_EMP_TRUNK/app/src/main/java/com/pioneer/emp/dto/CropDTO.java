package com.pioneer.emp.dto;

import java.io.Serializable;

/**
 * Created by hareesh.a on 7/28/2017.
 */

public class CropDTO implements Serializable {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
