package com.pioneer.emp.custommap;

/**
 * Created by Fatima on 09-01-2018.
 */

import android.content.Context;
import androidx.annotation.StringRes;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Base64;

import java.nio.charset.Charset;

public class StringUtils {
    public static final String SPACER = " ";
    public static final String COMMA_SEPARATOR = ",";
    public static final String SHARED_PREFERENCE_XSTORY = "xstory_memory";
    public static final String SHARED_PREFERENCE_AUTH_TOKEN = "authtoken";
    public static final String INTENT_IS_SOCIAL = "isSocial";
    public static final String INTENT_SOCIAL_AUTH_DATA = "socialAuthData";
    public static final String AUTH_METHOD_FACEBOOK = "FACEBOOK";
    public static final String AUTH_METHOD_GOOGLE = "GOOGLE";
    public static final String AUTH_METHOD_DIRECT = "DIRECT";

    //Zoom Levels
    public static final float zoomLevelHome = 11;
    public static final float zoomLevelNavigation = 11;
    public static final float zoomLevelAddStory = 17;
    public static final float zoomLevelStoryDetails = 15;
    public static final float zoomLevelHelpScreen = 14;

    //Story Refresh Distance In KiloMeter
    public static final double homeStoryRefreshInKm = 0.5;
    public static final double navigationStoryRefreshInKm = 0.5;

    public static final String SHARED_PREFERENCE_DEVICE_ID = "device_id";
    public static final String SHARED_PREFERENCE_AUTOPLAY_STATUS = "autoPlayStatus";
    public static final String SHARED_PREFERENCE_DISTANCE_RADIUS = "distanceRadius";

    public static final String SHARED_PREFERENCE_API_HOST = "api_host";
    public static final String SHARED_PREFERENCE_API_PORT = "api_port";

    public static final String SHARED_PREFERENCE_LATITUDE = "geo_latitude";
    public static final String SHARED_PREFERENCE_LONGITUDE = "geo_longitude";
    public static final String SHARED_PREFERENCE_USER_ID = "user_id";
    public static final String SHARED_PREFERENCE_USER_NAME = "user_name";
    public static final String SHARED_PREFERENCE_DISPLAY_NAME = "user_displayname";
    public static final String SHARED_PREFERENCE_USER_EMAIL = "user_email";
    public static final String SHARED_PREFERENCE_USER_PHONE = "user_phone";
    public static final String SHARED_PREFERENCE_USER_DOB = "user_dob";
    public static final String SHARED_PREFERENCE_USER_PHOTO_SERVER = "photo_server";
    public static final String SHARED_PREFERENCE_USER_PHOTO_LOCAL = "photo_local";
    public static final String SHARED_PREFERENCE_USER_PREFFERED_lANG = "preffered_languages";
    public static final String SHARED_PREFERENCE_USER_PREFFERED_lANG_IDS = "preffered_languages_ids";
    public static final String SHARED_PREFERENCE_STORY_COUNT = "story_count";
    public static final String SHARED_PREFERENCE_FOLLOWER_COUNT = "follower_count";
    public static final String SHARED_PREFERENCE_FOLLOWING_COUNT = "following_count";
    public static final String SHARED_PREFERENCE_LISTEN_STORIES_COUNT = "listen_stories_count";
    public static final String SHARED_PREFERENCE_IS_STORYTELLER = "is_story_teller";
    public static final String SHARED_PREFERENCE_LOGIN_METHOD = "login_method";
    public static final String SHARED_PREFERENCE_TEMP_FILE = "temporary_file";
    public static final String SHARED_PREFERENCE_SIGNUP_METHOD = "signup_method";
    public static final String SHARED_PREFERENCE_IS_NOTIFICATION_ON = "is_notification_on";
    public static final String SHARED_PREFERENCE_GENDER = "user_gender";
    public static final String SHARED_PREFERENCE_LAST_ADDED_STORY_LAN = "last_added_story_language";

    public static final String SHARED_PREFERENCE_RATE_US_DONT_SHOW_AGAIN = "rate_us_dont_show_again";
    public static final String SHARED_PREFERENCE_RATE_US_DATE_FIRTS_LAUNCH = "rate_us_date_first_launch";
    public static final String SHARED_PREFERENCE_RATE_US_LAUNCH_COUNT = "rate_us_launch_count";

    public static final String SHARED_PREFERENCE_SEARCH_FROM_LAT = "search_from_lat";
    public static final String SHARED_PREFERENCE_SEARCH_FROM_LONG = "search_from_long";
    public static final String SHARED_PREFERENCE_SEARCH_TO_LAT = "search_to_lat";
    public static final String SHARED_PREFERENCE_SEARCH_TO_LONG = "search_to_long";

    public static final String SHARED_PREFERENCE_SEARCH_FROM_LOCATION = "search_from_location";
    public static final String SHARED_PREFERENCE_SEARCH_TO_LOCATION = "search_to_location";

    public static final String SHARED_PREFERENCE_FILTER_MY_STORY = "filter_my_story";

    public static final String FILE_TYPE_IMAGE = "IMAGES";
    public static final String ERR_NO_RESULT = "No results";
    public static final String STR_EMPTY = "";
    public static final String DISPLAY_NAME = "DISPLAY_NAME";
    public static final String TELLER_NAME = "TELLER_NAME";
    public static final String EMAIL = "EMAIL";
    public static final String USER_NAME = "USER_NAME";
    public static final String SHARED_PREFERENCE_IS_EMAIL_VEFIRIED = "IS_EMAIL_VEFIRIED";
    public static final long MAX_ADD_STORY_RECORD_TIME = 60000;
    public static final String FEMALE = "Female";
    public static final String MALE = "Male";
    public static final String SELECT_GENDER = "Select Gender";

    public static final String API_SUCCESS = "SUCCESS";
    public static final String API_FAILED = "FAILED";
    public static final String FOLLOW= "FOLLOW";
    public static final String UNFOLLOW= "UNFOLLOW";

    public static final String STORY_LIKE= "STORY_LIKE";
    public static final String STORY_UNLIKE= "STORY_UNLIKE";
    public static final String STORY_TELLER_ID= "STORY_TELLER_ID";

    public static final String SEARCH_BY_PLACE= "PLACE";
    public static final String SEARCH_BY_NAME= "NAME";

    public static final String GET_PLAYING_STORY_ID= "getPlayingStoryId";
    public static final String IS_STORY_PLAYING_FLAG= "isStoryPlaying";
    public static final String IS_CLOUD_FRONT_CALL= "isCloudFrontCall";
    public static final String GET_CLOUD_FRONT_CALL_STORY_ID= "getCloudFrontCallStoryId";

    public static final String IS_SAVE_TO_CACHE= "isaveToCache";
    public static final String GET_SAVE_TO_CACHE_STORY_ID= "getSaveToCacheStoryId";
    public static final String IS_CANCEL_PREVIOUS= "IS_CANCEL_PREVIOUS";

    public static final String BC_CALLING= "API_CALLING";
    public static final String BC_SUCCESS= "API_SUCCESS";
    public static final String BC_STORY_PLAYING= "STORY_PLAYING";
    public static final String BC_STORY_RESUMING= "STORY_RESUMING";
    public static final String BC_STORY_COMPLETED= "STORY_COMPLETED";
    public static final String BC_STOPPED ="STORY_STOPPED" ;
    public static final String BC_PAUSED= "STORY_PAUSED";
    public static final String BC_FAILED= "API_FAILED";
    public static final String BC_STOP_NEXT= "API_dssss";
    public static final String BC_INTENT= "story-player-broadcast";
    public static final String BC_INTENT_STORYID= "story_id";
    public static final String BC_INTENT_ACTION= "bc_status";

    public static final String NO_STORIES_MSG= "No stories found";
    public static final String NO_FOLLOWERS_MSG= "No one is following you ";
    public static final String NO_FOLLOWING_MSG= "You are not following anyone till now ";
    public static final String NO_STORY_TELLER_MSG= "No storyteller found for the search parameter";
    public static final String NO_STORY_TELLER_FOLLOWERS_MSG= "No followers ";
    public static final String NO_STORY_TELLER_FOLLOWING_MSG= "No following ";

    public static final Integer PASSWORD_REQUIRED_MINIMUM_LENGTH = 6;
    public static final String NO_INTERNET_MSG = "Can't load data ";
    public static final String FROM_LAYOUT = "FROM";
    public static final String TO_LAYOUT = "TO";

    public static final String ARG_NOTIFICATION = "arg_notification";
    public static final String ARG_STORY_COMPLETE = "arg_story_complete";
    // home fragment
    public static final String LAYOUT_SLIDING = "sliding_layout";
    public static final String LAYOUT_STACK = "stack_layout ";
    public static final String LAYOUT_DEFAULT = "default_layout ";
    public static final String STORY_TELLER_MAP_FRAGMENT = "StoryTellerMapFragment";
    public static final String MY_STORIES_MAP_FRAGMENT = "MyStoriesMapFragment";

    public static final int PER_PAGE =10 ;

    public static final String ARG_TYPE ="type";
    public static final String ARG_FOLLOW ="follow";
    public static final String ARG_MY_STORIES ="mystories";
    public static final String ARG_SHARED_STORY ="shared_Story";
    public static final String ARG_STORY_TELLER ="storytellers";
    public static final String ARG_STORY_TELLER_FROM_NOTIF ="storytellersFromNotif";
    public static final String ARG_STORY_OBJ="stories";
    public static final String ARG_STORY_POS="position";
    public static final String ARG_SELF_STORY_TELLER="self_story_teller";
    public static final String ARG_STORY_LIST="stories_list";
    public static final String MARKER_GREEN = "green_marker";
    public static final String MARKER_PLAY = "play_marker";
    public static final String WEB_PAGE = "web_page";
    public static final String PRIVACY_POLICY = "privacy_policy";
    public static final String TERMS_OF_SERVICE = "terms_of_service";
    public static final String FAQ = "faq";

    public static final int FETCH_STORY_MIN_DISTANCE_IF_NULL = 10 ;
    public static final int FETCH_STORY_PAGE_NUMBER = 1;
    public static final int FETCH_STORY_PER_PAGE = 700;
    public static final String PRELOAD_LOADING= "loading_layout";
    public static final String PRELOAD_NO_RECORD= "no_record_layout";
    public static final String PRELOAD_NO_INTERNET= "no_internet_layout";
    public static final String PRELOAD_RECYCLER= "recycler_layout";

    //fragment Tags
    public static final String FRAGMENT_TAG_MY_STORIES = "MyStoriesListFragment";
    public static final String FRAGMENT_TAG_MY_ACCOUNT = "my_aacount";
    public static final String FRAGMENT_TAG_HOME = "HomeFragment";
    public static final String FRAGMENT_TAG_ADD_STORY = "AddStory";
    public static final String FRAGMENT_TAG_STORY_DETAILS = "StoryDetailsFragment";
    public static final String FRAGMENT_TAG_STORY_TELLER_PROFILE = "StoryTellerProfileFragment";
    public static final String FRAGMENT_TAG_STORY_TELLER_MAP = "StoryTellerMapFragment";
    public static final String FRAGMENT_TAG_MY_STORIES_MAP = "MyStoriesMapFragment";
    public static final String FRAGMENT_TAG_XTORY_USER_DETAILS = "XtoryUserDetailsFragment";
    public static final String FRAGMENT_TAG_ADD_STORY_COMPLETE = "AddStoryCompleteFragment";
    public static final String FRAGMENT_TAG_ADD_STORY_RECORD = "AddStoryRecordFragment";


    public static final String SHARED_PREFERENCE_SENT_GCM_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String SHARED_PREFERENCE_GCM_REGISTRATION_COMPLETE = "gcmRegistartionComplete";
    public static final String SHARED_PREFERENCE_GCM_ID = "gcmRegistartionID";
    public static final String SHARED_PREFERENCE_GCM_APP_VERSION = "GcmappVersion";
    public static final String NO_NOTIFICATIONS_MSG = "No Notifications";
    public static final String AUDIO_STOP = "STOP_AUDIO";
    public static final String AUDIO_PAUSE = "PAUSE_AUDIO";
    public static final String AUDIO_PLAY = "PLAY_AUDIO";
    public static final String AUDIO_RESUME = "RESUME_AUDIO";
    public static final String IS_STORY_PAUSE_FLAG = "is_story_pause";

    public static final String NOTIF_TYPE_LIKE_STORY = "LIKE";
    public static final String NOTIF_TYPE_FOLLOWING = "FOLLOWING";
    public static final String NOTIF_TYPE_COMMENT = "COMMENT";
    public static final String NOTIF_TYPE_LISTEN_STORY = "LISTEN";
    public static final String NOTIF_TYPE_APP_UPDATE = "APP_UPDATE";
    public static final String NOTIF_TYPE_FOLLOWING_STORY_ADD = "FOLLOWING_STORY_ADD";
    public static final String NOTIF_TYPE_MILESTONE_FOLLOW = "MILESTONE_FOLLOW";
    public static final String NOTIF_TYPE_MILESTONE_LIKE = "MILESTONE_LIKE";
    public static final String NOTIF_TYPE_MILESTONE_LISTEN = "MILESTONE_LISTEN";
    public static final String NOTIF_TYPE_STORY_SHARE = "STORY_SHARE";

    public static final String MSG_MULTIPLE_NOTIFICATIONS = "You have few notifications";
    public static final String MSG_SINGLE_NOTIFICATION = "You have a notification";
    public static final String HAS_MULTIPLE = "has_multiple";
    public static final String NOTIFICATION_ID = "notification_id";

    public static final String LOADING_MESSAGE = "Loading";
    public static final String XTORY_USER_ID = "XTORY_USER_ID";

    public static final String INTENT_NOTIFICATION = "intentNotification";
    public static final int BOTTOM_OFFSET = 180;

    public static final String SHARE_SOCIAL_FACEBOOK = "FACEBOOK";
    public static final String SHARE_SOCIAL_WHATSAPP = "WHATSAPP";
    public static final String SHARE_SOCIAL_TWITTER = "TWITTER";

    public static final String SHARE_IS_CUSTOM_URL = "isCustomUrl";
    public static final String API_ERROR_SIGN_UP_FAILED = "Sign up failed";
    public static final String API_ERROR_FORGOT_PASSWORD_FAILED = "Forgot password failed";
    public static final long CLICK_DELAY = 300;
    public static final String NOTIF_POP_USER_DETAILS = "notif_pop_user_details_array";
    public static final String NOTIF_POP_OBJ = "notif_pop_notification_obj";
    public static final String SHARED_PREFERENCE_LANGUAGE_SYNCED_TIME = "language_synced_time";


    //Search Related Strings
    public static final String SEARCH_TYPE = "search_type";
    public static final String SEARCH_PLACE = "place";
    public static final String SEARCH_TYPE_ACTION = "action_search";
    public static final String SEARCH_TYPE_FROM = "from_layout";
    public static final String SEARCH_TYPE_TO = "to_layout";
    public static final String NAVIGATION_FROM_LATLNG = "navigation_from_latlng";
    public static final String NAVIGATION_TO_LATLNG = "navigation_to_latlng";
    public static final String NAVIGATION_ORIGIN_SCREEN = "navigation_origin_screen";
    public static final String NAVIGATION_MYSTORIES_SCREEN = "navigation_my_stories_screen";
    public static final String NAVIGATION_OTHER_SCREEN = "navigation_other_screen";
    public static final String STORY_DELETED = "STORY_DELETED";
    public static final double BIAS_RADIOUS = 1000;
    public static final String ARG_IS_MY_STORIES = "is_my_profile";

    /**
     * Checks if a String is whitespace, empty ("") or null.
     *
     * <pre>
     *  StringUtils.isBlank(null)      = true
     *  StringUtils.isBlank("")        = true
     *  StringUtils.isBlank(" ")       = true
     *  StringUtils.isBlank("bob")     = false
     *  StringUtils.isBlank("  bob  ") = false
     * </pre>
     *
     * @param value
     *            the String to check, may be null
     * @return <code>true</code> if the String is null, empty or whitespace
     */
        public static boolean isBlank(String value) {
            return value == null || value.trim().length() == 0 ;
        }

        /**
         * Checks if a String is not empty (""), not null and not whitespace only.
         *
         * <pre>
         *  StringUtils.isNotBlank(null)      = false
         *  StringUtils.isNotBlank("")        = false
         *  StringUtils.isNotBlank(" ")       = false
         *  StringUtils.isNotBlank("bob")     = true
         *  StringUtils.isNotBlank("  bob  ") = true
         * </pre>
         *
         * @param value
         *            the String to check, may be null
         * @return <code>true</code> if the String is not empty and not null and not whitespace
         */
        public static boolean isNotBlank(String value) {
            return !isBlank(value);
        }

    /**
     * Base 64 encode a string
     * @param token
     * @return
     */
    public static String base64Encode(String token) {
        byte[] encodedBytes = Base64.encode(token.getBytes(), Base64.DEFAULT);
        return new String(encodedBytes, Charset.forName("UTF-8"));
    }

    public static SpannableStringBuilder buildClickableSpan(Context context,
                                                            SpannableStringBuilder spannableBuilder,
                                                            @StringRes int inputStringId,
                                                            @StringRes int targetStringId,
                                                            ClickableSpan span) {

        String inputString = context.getString(inputStringId);
        String targetString = context.getString(targetStringId);
        spannableBuilder.setSpan(span, inputString.indexOf(targetString),
                inputString.indexOf(targetString) + targetString.length(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableBuilder;
    }

    /**
     * Builds a span to change the color of a part of input string.
     *
     * @param spannableBuilder spannable builder whose span needs to be set.
     * @param inputStringId      complete input string whose part needs to be bold.
     * @param targetStringId     substring of input string which needs to be bold.
     * @param colorSpan        ForegroundColorSpan that defines the color.
     * @return Modified spannable string builder.
     */
    public static SpannableStringBuilder buildSpannableColor(Context context,
                                                             SpannableStringBuilder spannableBuilder,
                                                             @StringRes int inputStringId,
                                                             @StringRes int targetStringId,
                                                             ForegroundColorSpan colorSpan) {
        String inputString = context.getString(inputStringId);
        String targetString = context.getString(targetStringId);
        spannableBuilder.setSpan(colorSpan, inputString.indexOf(targetString),
                inputString.indexOf(targetString) + targetString.length(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableBuilder;
    }

}