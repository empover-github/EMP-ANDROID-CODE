package com.pioneer.emp;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;
import com.pioneer.emp.adapters.CategoryAdapter;
import com.pioneer.emp.fab.adapters.CropAdapter;
import com.pioneer.emp.fab.adapters.HybridAdapter;
import com.pioneer.emp.fab.adapters.SeasonAdapter;
import com.pioneer.emp.fab.adapters.StatesAdapter;
import com.pioneer.emp.fab.models.CropMasterEntity;
import com.pioneer.emp.fab.models.HybridMasterEntity;
import com.pioneer.emp.fab.models.SeasonMasterEntity;
import com.pioneer.emp.fab.models.StateCodeEntity;
import com.pioneer.emp.models.CategoryMasterEntity;
import com.pioneer.emp.models.CropAdvisoryMasterModelMain;
import com.pioneer.emp.models.CropAdvisoryResponse;
import com.pioneer.emp.models.CropAdvisorySubscriptionReq;
import com.pioneer.emp.models.SelectedCropAdvisoryModelMain;
import com.pioneer.emp.models.SelectedCropAdvisoryResponse;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.apiInterfaces.CommonInterface;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;

import retrofit.RetrofitError;

public class CropAdvisoryActivity extends BaseActivity implements AdapterView.OnItemSelectedListener, CommonInterface, View.OnClickListener {
    Spinner spnCategory, spnState, spnCrop,spnHybrid, spnSeason;
    Button btnSubmit;
    private TextView noCropAdvisoryAvailableTxt;
    private LinearLayout cropAdvisoryDataAvailableLL;

    private ArrayList<CategoryMasterEntity> allCategoryList;
    private ArrayList<StateCodeEntity> allStateList;
    private ArrayList<CropMasterEntity> allCropList;
    private ArrayList<HybridMasterEntity> allHybridList;
    private ArrayList<SeasonMasterEntity> allSeasonList;

//    private ArrayList<CategoryMasterEntity> allCategoryList;
    private ArrayList<StateCodeEntity> selectedStateList;
    private ArrayList<CropMasterEntity> selectedCropList;
    private ArrayList<HybridMasterEntity> selectedHybridList;
    private ArrayList<SeasonMasterEntity> selectedSeasonList;

    String st_selectedCategory, st_selectedState, st_selectedCrop, st_selectedHybrid, st_selectedSeason;
    String st_selectedCategoryID, st_selectedStateID, st_selectedCropID, st_selectedHybridID, st_selectedSeasonID;

    private FloatingActionButton fabButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_activity_crop_advisory);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setHomeButtonEnabled(false);
        ImageView mBackButton = findViewById(R.id.imgBacknav);
        mBackButton.setVisibility(View.VISIBLE);
        TextView mTitleTxt = findViewById(R.id.hedder_text);
        mTitleTxt.setVisibility(View.VISIBLE);
        mTitleTxt.setText(getString(R.string.cropAdvisory));
        mBackButton.setOnClickListener(this);

        initilizeViews();
    }

    private void initilizeViews() {

        spnCategory = findViewById(R.id.spnCategory);
        spnState = findViewById(R.id.spnState);
        spnCrop = findViewById(R.id.spnCrop);
        spnHybrid = findViewById(R.id.spnHybrid);
        spnSeason = findViewById(R.id.spnSeassion);

        btnSubmit = findViewById(R.id.btnSubmit);
        noCropAdvisoryAvailableTxt = findViewById(R.id.caa_noDataText);
        cropAdvisoryDataAvailableLL = findViewById(R.id.caa_dataAvailableLL);

        spnCategory.setOnItemSelectedListener(this);
        spnState.setOnItemSelectedListener(this);
        spnCrop.setOnItemSelectedListener(this);
        spnHybrid.setOnItemSelectedListener(this);
        spnSeason.setOnItemSelectedListener(this);
        btnSubmit.setOnClickListener(this);

        // here Write Floating point Button functionality
        fabButton = findViewById(R.id.caa_fabtn);
        fabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(CropAdvisoryActivity.this, ShowOfflineCropAdvisoryActivity.class);
                startActivity(intent);
            }
        });


        getAllCropsMasterInfo();
    }

    private void getAllCropsMasterInfo() {

        if (Utils.isNetworkConnection(CropAdvisoryActivity.this)) {
            APIRequestHandler.getInstance().getCropsMasterInfo(this, "", this, true);
        } else {
            noCropAdvisoryAvailableTxt.setText(getString(R.string.cropAdvisoryInternetOffMsg));
            DisplayNoMasterDataAvailable();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()){
            case R.id.spnCategory:
                st_selectedCategory = allCategoryList.get(position).getName();
                st_selectedCategoryID = allCategoryList.get(position).getId();
                setStateSpinner(st_selectedCategoryID);
                break;
            case R.id.spnState:
                st_selectedState = selectedStateList.get(position).getName();
                st_selectedStateID = selectedStateList.get(position).getId();
                String categoryId_state = selectedStateList.get(position).getCategoryId();
                setCropSpinner(categoryId_state, st_selectedStateID);
                break;

            case R.id.spnCrop:
                st_selectedCrop = selectedCropList.get(position).getName();
                st_selectedCropID = selectedCropList.get(position).getId();
                String categoryId_crop = selectedCropList.get(position).getCategoryId();
                String stateId_crop = selectedCropList.get(position).getStateId();
                setHybridSpinner(categoryId_crop,stateId_crop,st_selectedCropID);
                break;
            case R.id.spnHybrid:

                st_selectedHybrid = selectedHybridList.get(position).getName();
                st_selectedHybridID = selectedHybridList.get(position).getId();
                String categoryId_hybrid = selectedHybridList.get(position).getCategoryId();
                String stateId_hybrid = selectedHybridList.get(position).getStateId();
                String cropId_hybrid = selectedHybridList.get(position).getCropId();
                setSeasonSpinner(categoryId_hybrid,stateId_hybrid,cropId_hybrid,st_selectedHybridID);
                break;
            case R.id.spnSeassion:

                st_selectedSeason = selectedSeasonList.get(position).getName();
                st_selectedSeasonID = selectedSeasonList.get(position).getId();
                break;
        }
    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if(responseObj != null) {

            if(responseObj instanceof CropAdvisoryResponse){
                CropAdvisoryResponse response = (CropAdvisoryResponse) responseObj;
                if (AppConstants.RESP_CODE_INVALID_USER == response.getRespCd()) {
                    logoutUser(CropAdvisoryActivity.this);
                } else if (AppConstants.RESP_CODE_SUCCESS == response.getRespCd()){
                    String st_commonResponse = Utils.getJWTResponse(response.getData(), this);
                    Gson gson = new Gson();
                     CropAdvisoryResponse commonResEntity = gson.fromJson(st_commonResponse, CropAdvisoryResponse.class);
                    if (AppConstants.STATUS_CODE_PRAVAKTA == commonResEntity.getStatusCode()) {
                        if (Utils.isValidStr(commonResEntity.getResponse())){

                            CropAdvisoryMasterModelMain allAdvisoryInfo = new Gson().fromJson(commonResEntity.getResponse(), CropAdvisoryMasterModelMain.class);
                            setAllAdapterInfo(allAdvisoryInfo);

                        }
                    } else if (AppConstants.FAB_ADVISORY_NOT_AVAILABLE_CODE_INT == commonResEntity.getStatusCode()) {
                        noCropAdvisoryAvailableTxt.setText(commonResEntity.getMessage());
                        DisplayNoMasterDataAvailable();
                    }else if (AppConstants.SOMETHING_WENT_WRONG_INT == commonResEntity.getStatusCode()) {
                        noCropAdvisoryAvailableTxt.setText(commonResEntity.getMessage());
                        DisplayNoMasterDataAvailable();
                    }
                } else {
                    DialogManager.showToast(CropAdvisoryActivity.this, response.getRespMsg());
                }
            } else if (responseObj instanceof SelectedCropAdvisoryResponse){
                SelectedCropAdvisoryResponse response = (SelectedCropAdvisoryResponse) responseObj;
                if (AppConstants.RESP_CODE_INVALID_USER == response.getRespCd()){
                    logoutUser(CropAdvisoryActivity.this);
                } else if (AppConstants.RESP_CODE_SUCCESS == response.getRespCd()){
                    String st_commonResponse = Utils.getJWTResponse(response.getData(), this);
                    Gson gson = new Gson();
                    SelectedCropAdvisoryResponse commonResEntity = gson.fromJson(st_commonResponse, SelectedCropAdvisoryResponse.class);
                    if (AppConstants.STATUS_CODE_PRAVAKTA == commonResEntity.getStatusCode()){
                        if (Utils.isValidStr(commonResEntity.getResponse())){

                            SelectedCropAdvisoryModelMain mainModel = new Gson().fromJson(commonResEntity.getResponse(), SelectedCropAdvisoryModelMain.class);

                            /*long selectedCropAdvisoryId = mainModel.getId();*/

//                            EmpCropAdvisoryMasterDAO.getInstance().insert(mainModel, DBHandler.getWritableDb(this));
                            Bundle bundle=new Bundle();
                            bundle.putSerializable("SelectedCropModel", mainModel);
                            Intent gotoSelectedCAActivity = new Intent(CropAdvisoryActivity.this, ShowSelectedCropAdvisoryMsgsActivity.class);
                            gotoSelectedCAActivity.putExtras(bundle);
                            startActivity(gotoSelectedCAActivity);

                        }
                    } else if (AppConstants.CROP_ADVISORY_NOT_AVAILABLE_CODE_INT == commonResEntity.getStatusCode()) {
                        DialogManager.showToast(this, commonResEntity.getMessage());
                    }else if (AppConstants.SOMETHING_WENT_WRONG_INT == commonResEntity.getStatusCode()) {
                        DialogManager.showToast(this, commonResEntity.getMessage());
                    }
                } else {
                    DialogManager.showToast(CropAdvisoryActivity.this, response.getRespMsg());
                }

            }
        }
    }

    @Override
    public void onRequestFailure(RetrofitError errorCode, String errorFrom) {

        super.onRequestFailure(errorCode, errorFrom);
    }
    private void setStateSpinner(String st_selectedCategoryID) {
        /*selectedStateList = new ArrayList<>();
        spnCrop.setAdapter(null);
        spnHybrid.setAdapter(null);
        spnSeason.setAdapter(null);*/

        selectedStateList = new ArrayList<>();

        for (int i=0; i<allStateList.size();i++){
            String categoryId = allStateList.get(i).getCategoryId();
            if (categoryId.equals(st_selectedCategoryID)){
                selectedStateList.add(allStateList.get(i));
            }
        }
        StatesAdapter stateAd = new StatesAdapter(CropAdvisoryActivity.this, selectedStateList);
        spnState.setAdapter(stateAd);

    }
    private void setCropSpinner(String st_selectedCategoryID, String selectedStateID) {
        /*allCropList = new ArrayList<>();
        spnHybrid.setAdapter(null);
        spnSeason.setAdapter(null);

        List<CropMasterEntity> cropList = EmpCropAdvisoryMasterDAO.getInstance().getCrops(st_selectedCategoryID,DBHandler.getReadableDb(this));
        allCropList = (ArrayList<CropMasterEntity>) cropList;
        if (cropList != null && !cropList.isEmpty()){
            IdNameAdapter cropAd = new IdNameAdapter(CropAdvisoryActivity.this, allCropList);
            spnCrop.setAdapter(cropAd);
        } else {
            DisplayNoMasterDataAvailable();
        }*/

        selectedCropList = new ArrayList<>();

        for (int i=0; i<allCropList.size();i++){
            String categoryId = allCropList.get(i).getCategoryId();
            String stateId = allCropList.get(i).getStateId();
            if (categoryId.equals(st_selectedCategoryID) && stateId.equals(selectedStateID)){
                selectedCropList.add(allCropList.get(i));
            }
        }
        CropAdapter cropAd = new CropAdapter(CropAdvisoryActivity.this, selectedCropList);
        spnCrop.setAdapter(cropAd);

    }
    private void setHybridSpinner(String selectedCategory, String selectedState,String selectedCropId) {
        /*allHybridList = new ArrayList<>();
        spnSeason.setAdapter(null);

        List<HybridMasterEntity> hybridList = EmpCropAdvisoryMasterDAO.getInstance().getHybrids(st_selectedCategoryID,st_selectedCropID,DBHandler.getReadableDb(this));
        allHybridList = (ArrayList<HybridMasterEntity>) hybridList;
        if (hybridList != null && !hybridList.isEmpty()){
            HybridAdapter hybridAd = new HybridAdapter(CropAdvisoryActivity.this, allHybridList);
            spnHybrid.setAdapter(hybridAd);
        } else {
            DisplayNoMasterDataAvailable();
        }*/

        selectedHybridList = new ArrayList<>();

        for (int i=0; i<allHybridList.size();i++){
            String cropId = allHybridList.get(i).getCropId();
            String categoryId = allHybridList.get(i).getCategoryId();
            String stateId = allHybridList.get(i).getStateId();
            if (cropId.equals(selectedCropId) && categoryId.equals(selectedCategory) && stateId.equals(selectedState) ){
                selectedHybridList.add(allHybridList.get(i));
            }
        }
        HybridAdapter hybridAd = new HybridAdapter(CropAdvisoryActivity.this, selectedHybridList);
        spnHybrid.setAdapter(hybridAd);

    }
    private void setSeasonSpinner(String selectedCategoryId, String selectedStateID, String selectedCropId, String selectedHybridId) {
        /*allSeasonList = new ArrayList<>();

        List<SeasonMasterEntity> seasonList = EmpCropAdvisoryMasterDAO.getInstance().getSeasons(st_selectedCategoryID,st_selectedCropID, st_selectedHybridID,DBHandler.getReadableDb(this));
        allSeasonList = (ArrayList<SeasonMasterEntity>) seasonList;
        if (seasonList != null && !seasonList.isEmpty()){
            SeasonAdapter seasonAd = new SeasonAdapter(CropAdvisoryActivity.this, allSeasonList);
            spnSeason.setAdapter(seasonAd);
        } else {
            DisplayNoMasterDataAvailable();
        }*/
        selectedSeasonList = new ArrayList<>();

        if ( allSeasonList == null){
            SeasonMasterEntity sme = new SeasonMasterEntity();
            sme.setId("0");
            sme.setName("No Season Available");
            sme.setCategoryId(selectedCategoryId);
            sme.setStateId(selectedStateID);
            sme.setCropId(selectedCropId);
            sme.setHybridId(selectedHybridId);
            selectedSeasonList.add(sme);
        }
        else {
            for (int i=0; i<allSeasonList.size();i++){
                String categoryId = allSeasonList.get(i).getCategoryId();
                String stateId = allSeasonList.get(i).getStateId();
                String cropId = allSeasonList.get(i).getCropId();
                String hybridId = allSeasonList.get(i).getHybridId();
                if (categoryId.equals(selectedCategoryId) && stateId.equals(selectedStateID) && cropId.equals(selectedCropId) && hybridId.equals(selectedHybridId)){
                    selectedSeasonList.add(allSeasonList.get(i));
                }
            }
        }
        SeasonAdapter seasonAd = new SeasonAdapter(CropAdvisoryActivity.this, selectedSeasonList);
        spnSeason.setAdapter(seasonAd);

    }


    private void DisplayNoMasterDataAvailable() {
        noCropAdvisoryAvailableTxt.setVisibility(View.VISIBLE);
        cropAdvisoryDataAvailableLL.setVisibility(View.GONE);
        btnSubmit.setVisibility(View.GONE);
    }

    private void setAllAdapterInfo(CropAdvisoryMasterModelMain allAdvisoryInfo) {

        allCategoryList = (ArrayList<CategoryMasterEntity>) allAdvisoryInfo.getCategoryMaster();
        allStateList = (ArrayList<StateCodeEntity>) allAdvisoryInfo.getStateCodeMaster();
        allCropList = (ArrayList<CropMasterEntity>) allAdvisoryInfo.getCropMaster();
        allHybridList = (ArrayList<HybridMasterEntity>) allAdvisoryInfo.getHybridMaster();
        allSeasonList = (ArrayList<SeasonMasterEntity>) allAdvisoryInfo.getSeasonMaster();

        if (allCategoryList == null || allStateList == null || allCropList == null || allHybridList == null || allSeasonList == null){
            DisplayNoMasterDataAvailable();
        } else {
            CategoryAdapter categoryAd = new CategoryAdapter(CropAdvisoryActivity.this, allCategoryList);
            spnCategory.setAdapter(categoryAd);
            categoryAd.notifyDataSetChanged();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSubmit:
                if(validateData()){
                    CropAdvisorySubscriptionReq subscriptionReq = new CropAdvisorySubscriptionReq();
                    subscriptionReq.setCategoryId(st_selectedCategoryID);
                    subscriptionReq.setStateId(st_selectedStateID);
                    subscriptionReq.setCropId(st_selectedCropID);
                    subscriptionReq.setHybridId(st_selectedHybridID);
                    subscriptionReq.setSeasonId(st_selectedSeasonID);
                    if (Utils.isNetworkConnection(this)){
                        String subscriptionInfo = new Gson().toJson(subscriptionReq,CropAdvisorySubscriptionReq.class);
                        String jwtToken = Utils.getJWTToken(subscriptionInfo, this);
                        APIRequestHandler.getInstance().getEncodedFCBridgeForSelectedCropAdvisory(this,jwtToken,this);
                    }

                }
                break;
            case R.id.imgBacknav:
                finish();
                break;
        }
    }

    private boolean validateData() {

        if(!Utils.isValidStr(st_selectedCategory)){
            DialogManager.showToast(this,"Please Select Any Category");
            return  false;
        }else if (!Utils.isValidStr(st_selectedState)){
            DialogManager.showToast(this,"Please Select Any State");
            return  false;
        }else if (!Utils.isValidStr(st_selectedCrop)){
            DialogManager.showToast(this,"Please Select Any Crop");
            return  false;
        }else if (!Utils.isValidStr(st_selectedHybrid)){
            DialogManager.showToast(this,"Please Select Any Hybrid");
            return  false;
        }else if (!Utils.isValidStr(st_selectedSeason)){
            DialogManager.showToast(this,"Please Select Any Season");
            return  false;
        }
        return true;
    }
}
