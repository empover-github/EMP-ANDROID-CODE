package com.pioneer.emp.dto;


import com.pioneer.parivaar.dto.DTO;

import java.io.Serializable;

/**
 * Created by fatima.t on 11-04-2018.
 */

public class MdrEvaluationDTO implements DTO,Serializable {
    private long id;
    private String mdrId;  // this is record Id
    private String mdrName;
    private String nineBoxScore;
    private String status;
    private String mdrMobileNumber;
    private String mdrEmployeeId;


    //Below attributes used for send data from one activity to another;
    private String selectedYear;
    private String selectedCropName;
    private long selectedCropid;
    private String selectedSeasonName;
    private long selectedSeasonId;

    public MdrEvaluationDTO(String mdrId, String mdrEmployeeId, String mdrName, String nineBoxScore, String status) {
        this.mdrId = mdrId;
        this.mdrEmployeeId = mdrEmployeeId;
        this.mdrName = mdrName;
        this.nineBoxScore = nineBoxScore;
        this.status = status;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMdrId() {
        return mdrId;
    }

    public void setMdrId(String mdrId) {
        this.mdrId = mdrId;
    }

    public String getMdrName() {
        return mdrName;
    }

    public void setMdrName(String mdrName) {
        this.mdrName = mdrName;
    }

    public String getNineBoxScore() {
        return nineBoxScore;
    }

    public void setNineBoxScore(String nineBoxScore) {
        this.nineBoxScore = nineBoxScore;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSelectedYear() {
        return selectedYear;
    }

    public void setSelectedYear(String selectedYear) {
        this.selectedYear = selectedYear;
    }

    public String getSelectedCropName() {
        return selectedCropName;
    }

    public void setSelectedCropName(String selectedCropName) {
        this.selectedCropName = selectedCropName;
    }

    public long getSelectedCropid() {
        return selectedCropid;
    }

    public void setSelectedCropid(long selectedCropid) {
        this.selectedCropid = selectedCropid;
    }

    public String getMdrMobileNumber() {
        return mdrMobileNumber;
    }

    public void setMdrMobileNumber(String mdrMobileNumber) {
        this.mdrMobileNumber = mdrMobileNumber;
    }

    public String getMdrEmployeeId() {
        return mdrEmployeeId;
    }

    public void setMdrEmployeeId(String mdrEmployeeId) {
        this.mdrEmployeeId = mdrEmployeeId;
    }

    public String getSelectedSeasonName() {
        return selectedSeasonName;
    }

    public void setSelectedSeasonName(String selectedSeasonName) {
        this.selectedSeasonName = selectedSeasonName;
    }

    public long getSelectedSeasonId() {
        return selectedSeasonId;
    }

    public void setSelectedSeasonId(long selectedSeasonId) {
        this.selectedSeasonId = selectedSeasonId;
    }
}
