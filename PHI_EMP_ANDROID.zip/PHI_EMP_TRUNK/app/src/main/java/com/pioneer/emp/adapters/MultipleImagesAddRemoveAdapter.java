package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.pioneer.emp.R;
import com.pioneer.emp.customviews.RoundedCornersTransfGlide;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.utils.AppConstants;

import java.util.ArrayList;

/**
 * Created by fatima.t on 27-09-2018.
 */

public class MultipleImagesAddRemoveAdapter extends RecyclerView.Adapter<MultipleImagesAddRemoveAdapter.MyViewsHolder> {

    private Context mContext;
    private ArrayList<String> addEquipmentList;
    private OnBookletClickListener listenser;

    public MultipleImagesAddRemoveAdapter(Context context, ArrayList<String> addEquipmentList, OnBookletClickListener listenser) {
        this.mContext = context;
        this.addEquipmentList = addEquipmentList;
        this.listenser = listenser;

    }

    @Override
    public MyViewsHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_image_cancel,parent,false);
        return new MyViewsHolder(myView);
    }

    @Override
    public void onBindViewHolder(MyViewsHolder holder, int position) {
        holder.bind(addEquipmentList.get(position));
    }

    @Override
    public int getItemCount() {
        return addEquipmentList.size();
    }


    public class MyViewsHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView imgView;
        private Button cancelBtn;
        private RelativeLayout parentLayout;

        public MyViewsHolder(View itemView) {
            super(itemView);
            imgView = itemView.findViewById(R.id.list_imageView);
            cancelBtn = itemView.findViewById(R.id.list_cancel_btn);
            parentLayout = itemView.findViewById(R.id.img_list_parent);
            parentLayout.setOnClickListener(this);
            cancelBtn.setOnClickListener(this);
        }

        public void bind(final String imagePath) {
            Glide.with(mContext)
                    .load(imagePath)
                    .error(R.drawable.image_placeholder).transform(new RoundedCornersTransfGlide(mContext, AppConstants.IMAGE_CORNER_RADIOS, AppConstants.IMAGE_MARGIN))
                    .placeholder(R.drawable.image_placeholder)
                    .dontAnimate().into(imgView);

            parentLayout.setTag(imagePath);
            cancelBtn.setTag(imagePath);
        }

        @Override
        public void onClick(View v) {
            listenser.onItemClick(v, getAdapterPosition());
        }
    }
}
