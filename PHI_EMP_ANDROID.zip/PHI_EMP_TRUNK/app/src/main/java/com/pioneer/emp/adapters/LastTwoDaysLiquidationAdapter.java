package com.pioneer.emp.adapters;

import android.content.Context;
/*import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;*/
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.pioneer.emp.R;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.DailyLiquidationDownloadDTO;
import com.pioneer.emp.models.LastTwoDaysRespEntity;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;


public class LastTwoDaysLiquidationAdapter extends RecyclerView.Adapter<LastTwoDaysLiquidationAdapter.LastTwoLiquidation> {
    private Context context;
    private ArrayList<LastTwoDaysRespEntity> lastTwoDaysRespEntities;


    public LastTwoDaysLiquidationAdapter(Context mContext, ArrayList<LastTwoDaysRespEntity> lastTwoDaysRespEntities) {
        this.context = mContext;
        this.lastTwoDaysRespEntities = lastTwoDaysRespEntities;
    }


    @Override
    public LastTwoLiquidation onCreateViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.last_twodays_liquidation_list_layout, parent, false);
        LastTwoLiquidation myHolder = new LastTwoLiquidation(layout);
        return myHolder;

    }

    @Override
    public void onBindViewHolder(LastTwoDaysLiquidationAdapter.LastTwoLiquidation holder, int position) {

        LastTwoDaysRespEntity entity = lastTwoDaysRespEntities.get(position);
        if (entity != null) {

            holder.tv_terName.setText(Utils.isValidStr(entity.getTerritoryName()) ? entity.getTerritoryName() : "Not Available");
            holder.tv_tblName.setText(Utils.isValidStr(entity.getTblName()) ? entity.getTblName() :"Not Nvailable");
            holder.tv_comp1_heading.setText(Utils.isValidStr(entity.getCompetitor1Name()) ? entity.getCompetitor1Name() : "0");
            holder.tv_comp2_heading.setText(Utils.isValidStr(entity.getCompetitor2Name())? entity.getCompetitor2Name() : "0");
            holder.tv_date_prev.setText(Utils.isValidStr(entity.getDate1())? entity.getDate1() : "0");
            holder.tv_pioneer_prev.setText(Utils.isValidStr(entity.getDate1PioneerSales())? entity.getDate1PioneerSales() : "0");
            holder.tv_comp1_prev.setText(Utils.isValidStr(entity.getDate1Competitor1Sales())? entity.getDate1Competitor1Sales() : "0");
            holder.tv_comp2_prev.setText(Utils.isValidStr(entity.getDate1Competitor2Sales())? entity.getDate1Competitor2Sales() : "0");
            holder.tv_others_prev.setText(Utils.isValidStr(entity.getDate1OtherSales())? entity.getDate1OtherSales() : "0");
            holder.tv_total_prev.setText(Utils.isValidStr(entity.getDate1TotalSales())? entity.getDate1TotalSales() : "0");
            holder.tv_date_latest.setText(Utils.isValidStr(entity.getDate2())? entity.getDate2() : "0");
            holder.tv_pioneer_latest.setText(Utils.isValidStr(entity.getDate2PioneerSales())? entity.getDate2PioneerSales() : "0");
            holder.tv_comp1_latest.setText(Utils.isValidStr(entity.getDate2Competitor1Sales())? entity.getDate2Competitor1Sales() : "0");
            holder.tv_comp2_latest.setText(Utils.isValidStr(entity.getDate2Competitor2Sales())? entity.getDate2Competitor2Sales() : "0");
            holder.tv_others_latest.setText(Utils.isValidStr(entity.getDate2OtherSales())? entity.getDate2OtherSales() : "0");
            holder.tv_total_latest.setText(Utils.isValidStr(entity.getDate2TotalSales())? entity.getDate2TotalSales() : "0");
        }

    }

    @Override
    public int getItemCount() {
        return lastTwoDaysRespEntities.size();
    }

    public class LastTwoLiquidation extends RecyclerView.ViewHolder {
        TextView tv_terName, tv_tblName, tv_comp1_heading, tv_comp2_heading,
                tv_date_prev, tv_pioneer_prev, tv_comp1_prev, tv_comp2_prev, tv_others_prev, tv_total_prev,
                tv_date_latest, tv_pioneer_latest, tv_comp1_latest, tv_comp2_latest, tv_others_latest, tv_total_latest;

        LastTwoLiquidation(View itemView) {
            super(itemView);

            tv_terName = itemView.findViewById(R.id.tv_terName);
            tv_tblName = itemView.findViewById(R.id.tv_tblName);
            tv_comp1_heading = itemView.findViewById(R.id.tv_comp1_heading);
            tv_comp2_heading = itemView.findViewById(R.id.tv_comp2_heading);

            tv_date_prev = itemView.findViewById(R.id.tv_date_prev);
            tv_pioneer_prev = itemView.findViewById(R.id.tv_pioneer_prev);
            tv_comp1_prev = itemView.findViewById(R.id.tv_comp1_prev);
            tv_comp2_prev = itemView.findViewById(R.id.tv_comp2_prev);
            tv_others_prev = itemView.findViewById(R.id.tv_others_prev);
            tv_total_prev = itemView.findViewById(R.id.tv_total_prev);
            tv_date_latest = itemView.findViewById(R.id.tv_date_latest);
            tv_pioneer_latest = itemView.findViewById(R.id.tv_pioneer_latest);
            tv_comp1_latest = itemView.findViewById(R.id.tv_comp1_latest);
            tv_comp2_latest = itemView.findViewById(R.id.tv_comp2_latest);
            tv_others_latest = itemView.findViewById(R.id.tv_others_latest);
            tv_total_latest = itemView.findViewById(R.id.tv_total_latest);

        }
    }
}
