package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.IdNameModel;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

public class CompetitorMasterDAO implements DAO {
    private final String TAG = "CompetitorMasterDAO";
    private static CompetitorMasterDAO competitorMasterDAO;

    public static CompetitorMasterDAO getInstance() {
        if (competitorMasterDAO == null) {
            competitorMasterDAO = new CompetitorMasterDAO();
        }
        return competitorMasterDAO;
    }
    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            IdNameModel dto = (IdNameModel) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("id", dto.getId());
            cv.put("name", dto.getName());

            long rowsEffected = dbObject.insert(DBHandler.TABLE_COMPETITOR_LIQUID, null, cv);
            if (rowsEffected > 0)
                return "";

        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }

        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> competitorData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_COMPETITOR_LIQUID, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    IdNameModel dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));

                    competitorData.add(dto);
                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return competitorData;
    }
    public boolean deleteTableData(SQLiteDatabase db) {
        try {
            db.compileStatement("DELETE FROM " + DBHandler.TABLE_COMPETITOR_LIQUID).execute();
            return true;
        } catch (Exception e) {

        } finally {
            db.close();
        }
        return false;
    }
}
