package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.model.IdNameModel;

import java.util.ArrayList;

/**
 * Created by fatima.t on 1/10/2018.
 */

public class SearchActivityAdapter extends RecyclerView.Adapter<SearchActivityAdapter.MYHolder> {
    Context context;
    ArrayList<IdNameModel> dto;
    private final OnBookletClickListener listener;

    public SearchActivityAdapter(Context context, ArrayList<IdNameModel> dto, OnBookletClickListener listener) {
        this.context = context;
        this.dto = dto;
        this.listener = listener;
    }

    @Override
    public MYHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_activity_adapter, parent, false);
        return new MYHolder(view) {
        };
    }

    @Override
    public void onBindViewHolder(MYHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return dto.size();
    }

    public class MYHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView txtName;
        LinearLayout lnrsearch;

        public MYHolder(View itemView) {
            super(itemView);
            txtName = itemView.findViewById(R.id.txt_name);
            lnrsearch = itemView.findViewById(R.id.lnr_search);
        }

        public void bind(int position) {
            IdNameModel getDTO = dto.get(position);
            txtName.setText(getDTO.getName());
            lnrsearch.setOnClickListener(this);
            lnrsearch.setTag(position);
        }

        @Override
        public void onClick(View v) {
            int position = (int) v.getTag();
            listener.onItemClick(v, position);
        }
    }


}
