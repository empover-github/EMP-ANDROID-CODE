package com.pioneer.emp.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.activitytrack.utility.ATBuildLog;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.DailyLiquidationDownloadDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;

import java.util.ArrayList;
import java.util.List;

public class DailyLiquidationCalendarDAO implements DAO {

    private final String TAG = "DailyLiquidationCalendarDAO";
    private static DailyLiquidationCalendarDAO dailyLiquidationCalendarDAO;

    public static DailyLiquidationCalendarDAO getInstance() {
        if (dailyLiquidationCalendarDAO == null) {
            dailyLiquidationCalendarDAO = new DailyLiquidationCalendarDAO();
        }

        return dailyLiquidationCalendarDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        DailyLiquidationDownloadDTO dto = (DailyLiquidationDownloadDTO) dtoObject;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("year", dto.getYear());
            contentValues.put("seasonName", dto.getSeasonName());
            contentValues.put("cropName", dto.getCropName());
            contentValues.put("calendarId", dto.getCalendarId());
            contentValues.put("startDate", dto.getStartDate());
            contentValues.put("endDate", dto.getEndDate());
            contentValues.put("competitor1Name", dto.getCompetitor1Name());
            contentValues.put("competitor2Name", dto.getCompetitor2Name());
            contentValues.put("status", dto.isStatus());

            long rowAffected = dbObject.insert(DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR, null, contentValues);
            if (rowAffected > 0)
                return "";
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DailyLiquidationDownloadDTO dto = (DailyLiquidationDownloadDTO) dtoObject;

            ContentValues contentValues = new ContentValues();

            if (dto.getYear() != null)
                contentValues.put("year", dto.getYear());

            if (dto.getSeasonName() != null)
                contentValues.put("seasonName", dto.getSeasonName());

            if (dto.getCropName() != null)
                contentValues.put("cropName", dto.getCropName());

            if (dto.getCalendarId() != 0)
                contentValues.put("calendarId", dto.getCalendarId());

            if (dto.getStartDate() != null)
                contentValues.put("startDate", dto.getStartDate());

            if (dto.getEndDate() != null)
                contentValues.put("endDate", dto.getEndDate());

            if (dto.getCompetitor1Name() != null)
                contentValues.put("competitor1Name", dto.getCompetitor1Name());

            if (dto.getCompetitor2Name() != null)
                contentValues.put("competitor2Name", dto.getCompetitor2Name());

            contentValues.put("status", dto.isStatus());

            int rowsEffected = dbObject.update(DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR, contentValues, "calendarId='" + dto.getCalendarId() + "' ", null);
            if (rowsEffected > 0)
                return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @SuppressLint("LongLogTag")
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> dailyLiquidationInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DailyLiquidationDownloadDTO dto = new DailyLiquidationDownloadDTO();
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));
                    dto.setSeasonName(cursor.getString(cursor.getColumnIndex("seasonName")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setStartDate(cursor.getString(cursor.getColumnIndex("startDate")));
                    dto.setEndDate(cursor.getString(cursor.getColumnIndex("endDate")));
                    dto.setCompetitor1Name(cursor.getString(cursor.getColumnIndex("competitor1Name")));
                    dto.setCompetitor2Name(cursor.getString(cursor.getColumnIndex("competitor2Name")));
                    dto.setStatus(cursor.getInt(cursor.getColumnIndex("status")) > 0);
                    dailyLiquidationInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return dailyLiquidationInfo;
    }


    public List<DailyLiquidationDownloadDTO> getRecordsForUploadByCalendarId(Context context, SQLiteDatabase dbObject, long calendarId) {
        Cursor cursor = null;
        List<DailyLiquidationDownloadDTO> dailyLiquidationInfo = new ArrayList<DailyLiquidationDownloadDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_SALES_MASTER + " WHERE calendarId = '" + calendarId + "'", null);
            // cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR + " WHERE isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DailyLiquidationDownloadDTO dto = new DailyLiquidationDownloadDTO();

                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));
                    dto.setSalesMaster(DailyLiquidationSalesDAO.getInstance().getRecordsForUploadByCalendarId(calendarId, DBHandler.getReadableDb(context)));
                    dto.setTop10RetailersSales(DailyLiquidationRetailersSalesDAO.getInstance().getRecordsForUploadByCalendarId(calendarId, DBHandler.getReadableDb(context), context));
                    dto.setTillDateSales(DailyLiquidationTillDateSalesDAO.getInstance().getRecordsForUploadByCalendarId(calendarId, DBHandler.getReadableDb(context)));

                    dailyLiquidationInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dailyLiquidationInfo;
    }


    public DailyLiquidationDownloadDTO getRecordsByCalendarId(long calendarId, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        // List<DailyLiquidationDownloadDTO> dailyLiquidationInfo = new ArrayList<DailyLiquidationDownloadDTO>();
        try {
            //cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR + " WHERE calendarId = '" + calendarId + "' and isSync = '1'", null);
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR + " WHERE calendarId = '" + calendarId + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                DailyLiquidationDownloadDTO dto;
                do {
                    dto = new DailyLiquidationDownloadDTO();

                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));
                    dto.setSeasonName(cursor.getString(cursor.getColumnIndex("seasonName")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setStartDate(cursor.getString(cursor.getColumnIndex("startDate")));
                    dto.setEndDate(cursor.getString(cursor.getColumnIndex("endDate")));
                    dto.setCompetitor1Name(cursor.getString(cursor.getColumnIndex("competitor1Name")));
                    dto.setCompetitor2Name(cursor.getString(cursor.getColumnIndex("competitor2Name")));
                    dto.setStatus(cursor.getInt(cursor.getColumnIndex("status")) > 0);

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR).execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    public List<DailyLiquidationDownloadDTO> getPendingRecordsToUpload(Context context, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        List<DailyLiquidationDownloadDTO> dailyLiquidationInfo = new ArrayList<DailyLiquidationDownloadDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_CALENDAR, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DailyLiquidationDownloadDTO calendarDto = new DailyLiquidationDownloadDTO();
                    calendarDto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    calendarDto.setSalesMaster(DailyLiquidationSalesDAO.getInstance().getRecordsForUploadByCalendarId(calendarDto.getCalendarId(), DBHandler.getReadableDb(context)));
                    calendarDto.setTop10RetailersSales(DailyLiquidationRetailersSalesDAO.getInstance().getRecordsForUploadByCalendarId(calendarDto.getCalendarId(), DBHandler.getReadableDb(context), context));
                    calendarDto.setTillDateSales(DailyLiquidationTillDateSalesDAO.getInstance().getRecordsForUploadByCalendarId(calendarDto.getCalendarId(), DBHandler.getReadableDb(context)));
                    //newly added
                    calendarDto.setDateWiseRetailerWiseSales(DailyLiquidationDateWiseRetailerSalesDAO.getInstance().getRecordsForUploadByCalendarId(calendarDto.getCalendarId(), DBHandler.getReadableDb(context)));


                    if (calendarDto.getSalesMaster() == null && calendarDto.getTop10RetailersSales() == null
                            && (calendarDto.getTillDateSales() == null || calendarDto.getTillDateSales().isEmpty() && calendarDto.getDateWiseRetailerWiseSales() == null || calendarDto.getDateWiseRetailerWiseSales().isEmpty()))
                        continue;
                    dailyLiquidationInfo.add(calendarDto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dailyLiquidationInfo;
    }
}
