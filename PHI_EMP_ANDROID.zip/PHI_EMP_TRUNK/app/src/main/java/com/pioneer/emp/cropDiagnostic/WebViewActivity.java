package com.pioneer.emp.cropDiagnostic;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
//import com.journeyapps.barcodescanner.Util;
import com.pioneer.emp.R;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;
public class WebViewActivity extends BaseActivity implements View.OnClickListener {

	public static final String EXTRA_TITLE = "title";
	public static final String EXTRA_URL = "url";

	private WebView mWebView;

	private ProgressDialog progressDialog;
	private String mTitle, mUrl;
	private TextView lblHeaderTitle;
	private ImageView imgNavItem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_webview);

		Bundle bundle = getIntent().getExtras();
		if(bundle != null){
			if(bundle.containsKey(EXTRA_TITLE))
				mTitle = bundle.getString(EXTRA_TITLE);

			if(bundle.containsKey(EXTRA_URL))
				mUrl = bundle.getString(EXTRA_URL);
		}

		mWebView = findViewById(R.id.webView);

		lblHeaderTitle = findViewById(R.id.hedder_text);
		lblHeaderTitle.setVisibility(View.VISIBLE);
		lblHeaderTitle.setText(mTitle);
		imgNavItem = findViewById(R.id.imgBacknav);
		imgNavItem.setVisibility(View.VISIBLE);
		imgNavItem.setOnClickListener(this);

		loadURL();
		//initComponents();
	}

	private void loadURL(){
		mWebView.getSettings().setJavaScriptEnabled(true); // enable javascript
		mWebView.getSettings().setDomStorageEnabled(true);

		mWebView.setWebViewClient(new WebViewClient() {
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
//                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
				//view.loadUrl("javascript:alert('hi')");
			}

			@Override
			public void onLoadResource(WebView view, String url) {
				super.onLoadResource(view, url);
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				showProgress();
				super.onPageStarted(view, url, favicon);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				hideProgress();
				super.onPageFinished(view, url);
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            	return super.shouldOverrideUrlLoading(view, mUrl);
				view.loadUrl(url);
				return true;
			}

		});

		//mWebView.setWebViewClient(new MyWebViewClient());
		mWebView.setWebChromeClient(new MyWebChromeClient());

		if(Utils.isNetworkConnection(this)){
			mWebView.loadUrl(mUrl);
		}else{
			DialogManager.showToast(WebViewActivity.this,"Check your internet connection");
		}
	}

	@Override
	public void onBackPressed() {
		backOperation();
	}

	private void backOperation() {
		if (mWebView.canGoBack()) {
			mWebView.goBack();
		} else {
			finish();
		}
	}

	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.imgBacknav){
			backOperation();
//			finish();
		}
	}

	private class MyWebChromeClient extends WebChromeClient {
		@Override
		public boolean onJsAlert(WebView view, String url, String message, final android.webkit.JsResult result)
		{
			result.confirm();
			return true;
		}

		@Override
		public void onProgressChanged(WebView view, int newProgress) {
			WebViewActivity.this.setProgress(newProgress * 1000);
		}
	}

	private void showProgress(){
		if(progressDialog == null){
			progressDialog = new ProgressDialog(WebViewActivity.this);
			progressDialog.setMessage("Loading...");
			progressDialog.setCancelable(false);
			progressDialog.setCanceledOnTouchOutside(false);
		}
		progressDialog.show();
	}

	private void hideProgress(){
		if(progressDialog != null)
			progressDialog.cancel();
	}

}