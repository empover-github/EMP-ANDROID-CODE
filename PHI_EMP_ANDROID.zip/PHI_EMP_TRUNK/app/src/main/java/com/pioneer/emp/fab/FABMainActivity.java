package com.pioneer.emp.fab;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pioneer.emp.R;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.fab.adapters.CropAdapter;
import com.pioneer.emp.fab.adapters.HybridAdapter;
import com.pioneer.emp.fab.adapters.SeasonAdapter;
import com.pioneer.emp.fab.adapters.StatesAdapter;
import com.pioneer.emp.fab.dao.DownloadingFileDAO;
import com.pioneer.emp.fab.dao.FabMasterDAO;
import com.pioneer.emp.fab.dto.DownloadFileDTO;
import com.pioneer.emp.fab.dto.FabMasterDTO;
import com.pioneer.emp.fab.fragments.FabCategoryFragments;
import com.pioneer.emp.fab.models.CropAdvisoryModel;
import com.pioneer.emp.fab.models.CropMasterEntity;
import com.pioneer.emp.fab.models.FABCropsResponse;
import com.pioneer.emp.fab.models.FabMasterModel;
import com.pioneer.emp.fab.models.FabMasterReqEntity;
import com.pioneer.emp.fab.models.HybridMasterEntity;
import com.pioneer.emp.fab.models.SeasonMasterEntity;
import com.pioneer.emp.fab.models.StateCodeEntity;
import com.pioneer.emp.fab.services.DownloadFileService;
import com.pioneer.emp.fab.services.DownloadFileServiceNewJob;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.apiInterfaces.CommonInterface;
import com.pioneer.parivaar.fragments.BaseFragment;
import com.pioneer.parivaar.listeners.DialogMangerCallback;
import com.pioneer.parivaar.model.EditProfileStateDetailsResponse;
import com.pioneer.parivaar.model.StateModel;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by fatima.t on 11-07-2017.
 */

public class FABMainActivity extends BaseActivity implements AdapterView.OnItemSelectedListener, CommonInterface, DialogMangerCallback, View.OnClickListener {
    private Toolbar toolbar;
    private PagerAdapter pageAdapter;
    private BaseFragment featureFrag, advantageFrag, benefitsFrag;
    private Button fabDetailsButton;
    private LinearLayout fabSpinersLL, fabTabsLL, descriptionLL;
    private RelativeLayout fabFragmentsAvailable;
    private TextView fabNoMasterDataAvailable, fabFragmentsNotAvailable, descriptionText;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Spinner spnCrop, spnHybrid, spnSeason, spnState;
    private ArrayList<CropMasterEntity> allCropsInfo;
    private ArrayList<HybridMasterEntity> allHybrids;
    private ArrayList<SeasonMasterEntity> allSeasonInfo;

    //    ArrayList<StateCodeEntity> allStatesInfoNew;
    private ArrayList<StateCodeEntity> allStatesInfo;
    private ArrayList<CropMasterEntity> selectedCrops;
    private ArrayList<HybridMasterEntity> selectedHybrids;
    private ArrayList<SeasonMasterEntity> selectedSeasons;
    private ArrayList<StateCodeEntity> selectedStates;
    private String st_selectedCrop, st_selectedHybrid, st_selectedSeason, st_selectedState;
    private String st_selectedCropID, st_selectedHybridID, st_selectedSeasonID, st_selectedStateID;
    private String versionNumber;

    private Menu menuVisible;
    private ImageView imgBacknav;
    private TextView hedderText;

    private LinearLayout stateSpinnerTR;

    private ArrayList<String> statearraylist = new ArrayList<>();
    private String selectState = "Select State";

    BroadcastReceiver br = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("ACTION_DOWNLOAD_COMPLETE")) {
                //Refresh data in Features, Advantages and Benefits screens

                featureFrag.refresh();
                advantageFrag.refresh();
                benefitsFrag.refresh();
            }
        }

    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_activity_feature_and_benefits);

        toolbar = findViewById(R.id.toolbar);
        hedderText = findViewById(R.id.hedder_text);
        hedderText.setVisibility(View.VISIBLE);
        imgBacknav = findViewById(R.id.imgBacknav);
        imgBacknav.setVisibility(View.VISIBLE);
        imgBacknav.setOnClickListener(this);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(Color.WHITE);
        hedderText.setText(getString(R.string.featuresAndBenefits));

        initializeViews();

        // Registering Broadcast Receiver
        IntentFilter filter = new IntentFilter();
        filter.addAction("ACTION_DOWNLOAD_COMPLETE");
        registerReceiver(br, filter);

        // Creating Fragment Instatnce
        featureFrag = new FabCategoryFragments();
        advantageFrag = new FabCategoryFragments();
        benefitsFrag = new FabCategoryFragments();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // UnRegisterBroadcast Receiver
        unregisterReceiver(br);
    }

    private void initializeViews() {
        fabSpinersLL = findViewById(R.id.fab_spinners_LL);
        fabTabsLL = findViewById(R.id.fab_tabs_LL);
        descriptionLL = findViewById(R.id.decription_LL);
        fabTabsLL.setVisibility(View.GONE);
        fabFragmentsAvailable = findViewById(R.id.fab_featureAbdBenefitsAvaiable_RL);
        fabFragmentsNotAvailable = findViewById(R.id.fab_noFeatureAbdBenefitsAvaiableText);
        fabNoMasterDataAvailable = findViewById(R.id.fab_noMasterDataAvailable);
        descriptionText = findViewById(R.id.fab_crop_descriptionText);

        spnCrop = findViewById(R.id.fab_spnCrop);
        spnHybrid = findViewById(R.id.fab_spnHybrid);
        spnSeason = findViewById(R.id.fab_spnSeasion);
        spnState = findViewById(R.id.fab_spnState);

        stateSpinnerTR = findViewById(R.id.stateSpinnerTR);

        spnCrop.setOnItemSelectedListener(this);
        spnHybrid.setOnItemSelectedListener(this);
        spnSeason.setOnItemSelectedListener(this);
        spnState.setOnItemSelectedListener(this);

        fabDetailsButton = findViewById(R.id.fab_getFABDetails_button);
        fabDetailsButton.setText(getString(R.string.st_get_fab_details));

        fabDetailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (fabDetailsButton.getText().toString().equals(getString(R.string.st_get_fab_details))) {
                    FabMasterModel selectedFabDetailsList = FabMasterDAO.getInstance().getSelectedRecord(st_selectedCropID, st_selectedHybridID, st_selectedSeasonID, DBHandler.getReadableDb(FABMainActivity.this));
                    if (selectedFabDetailsList != null) {
                        displayFragments(selectedFabDetailsList);
                        if (Utils.isNetworkConnection(FABMainActivity.this)) {
                            // get version number from DB and hit API
                            stateSpinnerTR.setVisibility(View.GONE);
                            versionNumber = selectedFabDetailsList.getVersion();
                            getSelectedFABDetailsAPI(versionNumber, st_selectedCropID, st_selectedHybridID, st_selectedSeasonID, st_selectedStateID);
                        }
                    } else {
                        if (Utils.isNetworkConnection(FABMainActivity.this)) {
                            stateSpinnerTR.setVisibility(View.GONE);
                            versionNumber = "0";
                            getSelectedFABDetailsAPI(versionNumber, st_selectedCropID, st_selectedHybridID, st_selectedSeasonID, st_selectedStateID);
                        } else {
                            DisplayNoMasterDataAvailable();
                        }
                    }
                }
            }
        });

        allCropsInfo = new ArrayList<>();
        allHybrids = new ArrayList<>();
        allSeasonInfo = new ArrayList<>();
        allStatesInfo = new ArrayList<>();

        if (Utils.isNetworkConnection(this)) {

            // here get State List instead of master Data
            APIRequestHandler.getInstance().getStateDetailsForFAB("India", this);
            //getAllCropInfoFromServerAPI(); call this in StateSuccessResponse
        } else {
            // get DB data here and pass array lists
            DialogManager.showSingleBtnPopup(FABMainActivity.this, this, getString(R.string.noInternet), getString(R.string.fabInternetOffMsg), getString(R.string.ok));
            getAllCropInfoFromLocal();
        }

    }

    private void getAllCropInfoFromServerAPI() {


        String mobileNo = Utils.getUserMobile(this);
        String customerId = Utils.getUserId(this);
        String userType = Utils.getUserType(this);

        APIRequestHandler.getInstance().getFABCrops(this, mobileNo, customerId, userType, this, true);

//        APIRequestHandler.getInstance().getFABCropsNew(this,mobileNo,customerId,userType,this, true);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.fab_spnState:
                if (Utils.isNetworkConnection(FABMainActivity.this)) {
//                    String text = spnState.getSelectedItem().toString();
                    String stateName = statearraylist.get(position);
                    if (stateName.equals(selectState)) {
//                        DialogManager.showToast(FABMainActivity.this, "Please Select State");
                        spnState.setVisibility(View.VISIBLE);
                        fabNoMasterDataAvailable.setText("Please Select State");
                        DisplayNoMasterDataAvailable();
                    } else {
                        APIRequestHandler.getInstance().getFABCropsNew(this, stateName, this, true);
                    }
                } else {
                    st_selectedState = allStatesInfo.get(position).getName();
                    st_selectedStateID = allStatesInfo.get(position).getId();
                    setCropSpinner(st_selectedStateID);
                }
                /*if (position == 0){
                    DialogManager.showToast(FABMainActivity.this, "Please Select State");
                } else {
                    // here Bridge Call, before we were calling directly
                    String stateName = statearraylist.get(position);
                    DialogManager.showToast(FABMainActivity.this, stateName);

                    if (Utils.isNetworkConnection(FABMainActivity.this)){
                        APIRequestHandler.getInstance().getFABCropsNew(this,stateName,this, true);
                    } else {
                        st_selectedState = allStatesInfo.get(position).getName();
                        st_selectedStateID = allStatesInfo.get(position).getId();
                        setCropSpinner(st_selectedStateID);
                    }

                }*/
                break;
            case R.id.fab_spnCrop:
                st_selectedCrop = selectedCrops.get(position).getName();
                st_selectedCropID = selectedCrops.get(position).getId();
                String stateId_cropId = selectedCrops.get(position).getStateId();

                /*st_selectedCrop = allCropsInfo.get(position).getName();
                st_selectedCropID = allCropsInfo.get(position).getId();*/
                setHybridSpinner(stateId_cropId, st_selectedCropID);
                break;
            case R.id.fab_spnHybrid:
                st_selectedHybrid = selectedHybrids.get(position).getName();
                st_selectedHybridID = selectedHybrids.get(position).getId();

                String stateId_hybrid = selectedHybrids.get(position).getStateId();
                String cropId_hybrid = selectedHybrids.get(position).getCropId();
                setSeasonSpinner(stateId_hybrid, cropId_hybrid, st_selectedHybridID);
                break;
            case R.id.fab_spnSeasion:
                st_selectedSeason = selectedSeasons.get(position).getName();
                st_selectedSeasonID = selectedSeasons.get(position).getId();
                break;
        }
    }

    private void setCropSpinner(String selectedStateId) {

        selectedCrops = new ArrayList<>();

        for (int i=0; i<allCropsInfo.size();i++){
            String stateId = allCropsInfo.get(i).getStateId();
            if (stateId.equals(selectedStateId)){
                selectedCrops.add(allCropsInfo.get(i));
            }
        }

        CropAdapter cropAd = new CropAdapter(this, selectedCrops);
        spnCrop.setAdapter(cropAd);
    }

    private void setHybridSpinner(String selectedStateId, String selectedCropId) {

        selectedHybrids = new ArrayList<>();

        for (int i = 0; i < allHybrids.size(); i++) {
            String stateId = allHybrids.get(i).getStateId();
            String cropId = allHybrids.get(i).getCropId();
            if (stateId.equals(stateId) && cropId.equals(selectedCropId)) {
                selectedHybrids.add(allHybrids.get(i));
            }
        }

        HybridAdapter hybridAd = new HybridAdapter(this, selectedHybrids);
        spnHybrid.setAdapter(hybridAd);
    }

    private void setSeasonSpinner(String selectedStateId, String selectedCropId, String selectedHybridId) {

        selectedSeasons = new ArrayList<>();
        if (allSeasonInfo == null) {
            SeasonMasterEntity sme = new SeasonMasterEntity();
            sme.setId("0");
            sme.setName("No Season Available");
            sme.setStateId(selectedStateId);
            sme.setCropId(selectedCropId);
            sme.setHybridId(selectedHybridId);
            selectedSeasons.add(sme);
        } else {
            for (int i = 0; i < allSeasonInfo.size(); i++) {
                /*String categoryId = allSeasonInfo.get(i).getCategoryId();
                String stateId = allSeasonInfo.get(i).getStateId();*/
                String stateId = allSeasonInfo.get(i).getStateId();
                String cropId = allSeasonInfo.get(i).getCropId();
                String hybridId = allSeasonInfo.get(i).getHybridId();
                if (stateId.equals(selectedStateId) && cropId.equals(selectedCropId) && hybridId.equals(selectedHybridId)) {
                    selectedSeasons.add(allSeasonInfo.get(i));
                }
            }
        }
        SeasonAdapter seasonAd = new SeasonAdapter(this, selectedSeasons);
        spnSeason.setAdapter(seasonAd);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // here OnRequestFailure has to be implemented

    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);
        if (responseObj != null) {
            if (responseObj instanceof FABCropsResponse) {
                FABCropsResponse response = (FABCropsResponse) responseObj;
                if (AppConstants.RESP_CODE_INVALID_USER == response.getRespCd()) {
                   logoutUser(FABMainActivity.this);
                } else if (AppConstants.RESP_CODE_SUCCESS == response.getRespCd()) {
                    String st_commonResponse = Utils.getJWTResponse(response.getData(), this);
                    Gson gson = new Gson();
                    FABCropsResponse commonResEntity = gson.fromJson(st_commonResponse, FABCropsResponse.class);
                    if (AppConstants.STATUS_CODE_PRAVAKTA == commonResEntity.getStatusCode()) {
                        if (Utils.isValidStr(commonResEntity.getResponse())) {

//                            CropAdvisoryModel model = commonResEntity.getResponse();
                            CropAdvisoryModel model = new Gson().fromJson(commonResEntity.getResponse(), CropAdvisoryModel.class);
                            setAllAdapterInfo(model);

                            /*CropAdvisoryMasterModelMain allAdvisoryInfo = new Gson().fromJson(commonResEntity.getResponse(), CropAdvisoryMasterModelMain.class);
                            setAllAdapterInfo(allAdvisoryInfo);*/
                        }
                    } else if (AppConstants.FAB_ADVISORY_NOT_AVAILABLE_CODE_INT == commonResEntity.getStatusCode()) {
                        fabNoMasterDataAvailable.setText(commonResEntity.getMessage());
                        DisplayNoMasterDataAvailable();
//                        DialogManager.showToast(FABMainActivity.this, commonResEntity.getMessage() );
                    } else if (AppConstants.SOMETHING_WENT_WRONG_INT == commonResEntity.getStatusCode()) {
                        fabNoMasterDataAvailable.setText(commonResEntity.getMessage());
                        DisplayNoMasterDataAvailable();
//                        DialogManager.showToast(FABMainActivity.this, commonResEntity.getMessage() );
                    }
                } else {
                    DialogManager.showToast(FABMainActivity.this, response.getRespMsg());
                }

                /*if (AppConstants.RESP_CODE_INVALID_USER == commonResponse.getRespCd()) {
                    clearAllUserData(FABMainActivity.this);
                    Intent gotoLogin = new Intent(FABMainActivity.this, LoginActivity.class);
                    finish();
                    startActivity(gotoLogin);
                } else {
                    String st_commonResponse = Utils.getJWTResponse(commonResponse.getData(), this);
                    FABCropsResponse commonResEntity = new Gson().fromJson(st_commonResponse, FABCropsResponse.class);
                    if (AppConstants.STATUS_CODE.equals(commonResEntity.getStatusCode())) {
                        CropAdvisoryModel model = commonResEntity.getResponse();
                        setAllAdapterInfo(model);
                    } else if (AppConstants.FAB_ADVISORY_NOT_AVAILABLE_CODE.equals(commonResEntity.getStatusCode())) {
//                        DialogManager.showToast(mActivity,commonResponse.getMessage());
                        fabNoMasterDataAvailable.setText(commonResEntity.getMessage());
                        DisplayNoMasterDataAvailable();
                    }else if (AppConstants.SOMETHING_WENT_WRONG.equals(commonResEntity.getStatusCode())) {
//                        DialogManager.showToast(mActivity,commonResponse.getMessage());
                        fabNoMasterDataAvailable.setText(commonResEntity.getMessage());
                        DisplayNoMasterDataAvailable();
                    }
                }*/
            } else if (responseObj instanceof FabMasterDTO) {
                FabMasterDTO commonResponse = (FabMasterDTO) responseObj;
                if (AppConstants.RESP_CODE_INVALID_USER == commonResponse.getRespCd()) {
                    logoutUser(FABMainActivity.this);
                } else if (AppConstants.RESP_CODE_SUCCESS == commonResponse.getRespCd()) {
                    String st_commonResponse = Utils.getJWTResponse(commonResponse.getData(), this);
                    FabMasterDTO fabMasterDto = new Gson().fromJson(st_commonResponse, FabMasterDTO.class);
//                    FabMasterModel fabMasterDto = new Gson().fromJson(st_commonResponse, FabMasterModel.class);
                    if (AppConstants.STATUS_CODE_PRAVAKTA == fabMasterDto.getStatusCode()/*AppConstants.STATUS_CODE.equals(fabMasterDto.getStatusCode())*/) {


                        /*if (Utils.isValidStr(fabMasterDto.getResponse())){
                            FabMasterModel justData = new Gson().fromJson(fabMasterDto.getResponse(), FabMasterModel.class);
                        }*/
//                        FabMasterModel justData = fabMasterDto.getResponse();
                        FabMasterModel justData = new Gson().fromJson(fabMasterDto.getResponse(), FabMasterModel.class);
                        displayFragments(justData);
//                        if (FabMasterDAO.getInstance().isDataExist(fabMasterDto.getId(), DBHandler.getReadableDb(this))) {
                        if (FabMasterDAO.getInstance().isDataExist(justData.getId(), DBHandler.getReadableDb(this))) {

                            List<DownloadFileDTO> downloadFileDTOs = new ArrayList<>();

                            // update record
                            // write update Method here
                            // get old record first, basically to check images/vide/audio/pdf

                            FabMasterModel oldRecord = FabMasterDAO.getInstance().getSelectedRecordById(String.valueOf(justData.getId()), DBHandler.getReadableDb(this));

                            String F_existingPdfUrlServer = oldRecord.getF_pdfFile();
                            String F_existingVoiceUrlServer = oldRecord.getF_voiceFile();
                            String F_existingVideoUrlServer = oldRecord.getF_videoFile();
                            String F_existingImagesUrlServer = oldRecord.getF_images();

                            if (!Utils.isValidStr(justData.getF_pdfFile())) {
                                justData.setF_pdfFile_local("");
                            } else if (!justData.getF_pdfFile().equals(F_existingPdfUrlServer)) {
                                justData.setF_pdfFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_FEATURES);
                                dto.setUrl(justData.getF_pdfFile());
                                dto.setType(AppConstants.PDF_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (!Utils.isValidStr(justData.getF_voiceFile())) {
                                justData.setF_voiceFile_local("");
                            } else if (!justData.getF_voiceFile().equals(F_existingVoiceUrlServer)) {
                                justData.setF_voiceFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_FEATURES);
                                dto.setUrl(justData.getF_voiceFile());
                                dto.setType(AppConstants.VOICE_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (!Utils.isValidStr(justData.getF_videoFile())) {
                                justData.setF_videoFile_local("");
                            } else if (!justData.getF_videoFile().equals(F_existingVideoUrlServer)) {
                                justData.setF_videoFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_FEATURES);
                                dto.setUrl(justData.getF_videoFile());
                                dto.setType(AppConstants.VIDEO_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (!Utils.isValidStr(F_existingImagesUrlServer) && !Utils.isValidStr(justData.getF_images())) {
                                //Do nothing
                            } else if (!Utils.isValidStr(F_existingImagesUrlServer) && Utils.isValidStr(justData.getF_images())) {
                                String[] imgs = justData.getF_images().split("#");
                                String[] imgTags = justData.getF_image_tags().split("#");
//                                for (String img : imgs) {
                                for (int i = 0; i < imgs.length; i++) {
                                    String img = imgs[i];
                                    DownloadFileDTO dto = new DownloadFileDTO();
                                    dto.setId(justData.getId());
                                    dto.setCategory(AppConstants.FAB_FEATURES);
                                    dto.setUrl(img);
                                    dto.setType(AppConstants.IMAGE_TYPE);
                                    dto.setTag(imgTags[i]);
                                    downloadFileDTOs.add(dto);
                                }
                            } else if (Utils.isValidStr(F_existingImagesUrlServer) && !Utils.isValidStr(justData.getF_images())) {
                                justData.setF_images_local("");
                                justData.setF_image_tags("");
                            } else if (F_existingImagesUrlServer != null) {
                                if (!F_existingImagesUrlServer.equals(justData.getF_images())) {
                                    String[] imgs = justData.getF_images().split("#");
                                    String[] oldImgs = oldRecord.getF_images_local().split("#");
                                    String[] imgTags = justData.getF_image_tags().split("#");
                                    String[] oldImgTags = oldRecord.getF_image_tags().split("#");
                                    StringBuilder imgsBuilder = new StringBuilder();
                                    StringBuilder imgsTagsBuilder = new StringBuilder();
//                                    for (String img : imgs) {
                                    for (int i = 0; i < imgs.length; i++) {
                                        String img = imgs[i];
                                        if (!F_existingImagesUrlServer.contains(img)) {
                                            DownloadFileDTO dto = new DownloadFileDTO();
                                            dto.setId(justData.getId());
                                            dto.setCategory(AppConstants.FAB_FEATURES);
                                            dto.setUrl(img);
                                            dto.setType(AppConstants.IMAGE_TYPE);
                                            dto.setTag(imgTags[i]);
                                            downloadFileDTOs.add(dto);
                                        } else {
                                            String imageName = img.substring(img.lastIndexOf("/") + 1);
                                            String imageTag = imgTags[i];
//                                            for (String imgOld : oldImgs) {
                                            for (int j = 0; j < oldImgs.length; j++) {
                                                String imgOld = oldImgs[j];
                                                String imgTagOld = oldImgTags[j];
                                                if (imgOld.contains(imageName)) {
                                                    if (imgsBuilder.length() > 0)
                                                        imgsBuilder.append("#").append(imgOld);
                                                    else
                                                        imgsBuilder.append(imgOld);
                                                    if (imgsTagsBuilder.length() > 0)
                                                        imgsTagsBuilder.append("#").append(imgTagOld);
                                                    else
                                                        imgsTagsBuilder.append(imgTagOld);
                                                }
                                            }
                                        }
                                    }

                                    if (imgsBuilder.length() > 0)
                                        justData.setF_images_local(imgsBuilder.toString());
                                    else
                                        justData.setF_images_local("");
                                    if (imgsTagsBuilder.length() > 0)
                                        justData.setF_image_tags(imgsTagsBuilder.toString());
                                    else
                                        justData.setF_image_tags("");
                                }
                            }

                            String A_existingPdfUrlServer = oldRecord.getA_pdfFile();
                            String A_existingVoiceUrlServer = oldRecord.getA_voiceFile();
                            String A_existingVideoUrlServer = oldRecord.getA_videoFile();
                            String A_existingImagesUrlServer = oldRecord.getA_images();

                            if (!Utils.isValidStr(justData.getA_pdfFile())) {
                                justData.setA_pdfFile_local("");
                            } else if (!justData.getA_pdfFile().equals(A_existingPdfUrlServer)) {
                                justData.setA_pdfFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                dto.setUrl(justData.getA_pdfFile());
                                dto.setType(AppConstants.PDF_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (!Utils.isValidStr(justData.getA_voiceFile())) {
                                justData.setA_voiceFile_local("");
                            } else if (!justData.getA_voiceFile().equals(A_existingVoiceUrlServer)) {
                                justData.setA_voiceFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                dto.setUrl(justData.getA_voiceFile());
                                dto.setType(AppConstants.VOICE_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (!Utils.isValidStr(justData.getA_videoFile())) {
                                justData.setA_videoFile_local("");
                            } else if (!justData.getA_videoFile().equals(A_existingVideoUrlServer)) {
                                justData.setA_videoFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                dto.setUrl(justData.getA_videoFile());
                                dto.setType(AppConstants.VIDEO_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (!Utils.isValidStr(A_existingImagesUrlServer) && !Utils.isValidStr(justData.getA_images())) {
                                //Do nothing
                            } else if (!Utils.isValidStr(A_existingImagesUrlServer) && Utils.isValidStr(justData.getA_images())) {
                                String[] imgs = justData.getA_images().split("#");
                                String[] imgTags = justData.getA_image_tags().split("#");
//                                for (String img : imgs) {
                                for (int i = 0; i < imgs.length; i++) {
                                    String img = imgs[i];
                                    DownloadFileDTO dto = new DownloadFileDTO();
                                    dto.setId(justData.getId());
                                    dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                    dto.setUrl(img);
                                    dto.setType(AppConstants.IMAGE_TYPE);
                                    dto.setTag(imgTags[i]);
                                    downloadFileDTOs.add(dto);
                                }
                            } else if (Utils.isValidStr(A_existingImagesUrlServer) && !Utils.isValidStr(justData.getA_images())) {
                                justData.setA_images_local("");
                                justData.setA_image_tags("");
                            } else if (A_existingImagesUrlServer != null) {
                                if (!A_existingImagesUrlServer.equals(justData.getA_images())) {
                                    String[] imgs = justData.getA_images().split("#");
                                    String[] oldImgs = oldRecord.getA_images_local().split("#");
                                    String[] imgTags = justData.getA_image_tags().split("#");
                                    String[] oldImgTags = oldRecord.getA_image_tags().split("#");
                                    StringBuilder imgsBuilder = new StringBuilder();
                                    StringBuilder imgsTagsBuilder = new StringBuilder();
                                    //                                for (String img : imgs) {
                                    for (int i = 0; i < imgs.length; i++) {
                                        String img = imgs[i];
                                        if (!A_existingImagesUrlServer.contains(img)) {
                                            DownloadFileDTO dto = new DownloadFileDTO();
                                            dto.setId(justData.getId());
                                            dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                            dto.setUrl(img);
                                            dto.setType(AppConstants.IMAGE_TYPE);
                                            dto.setTag(imgTags[i]);
                                            downloadFileDTOs.add(dto);
                                        } else {
                                            String imageName = img.substring(img.lastIndexOf("/") + 1);
                                            String imageTag = imgTags[i];
                                            //                                        for (String imgOld : oldImgs) {
                                            for (int j = 0; j < oldImgs.length; j++) {
                                                String imgOld = oldImgs[j];
                                                String imgTagOld = oldImgTags[j];
                                                if (imgOld.contains(imageName)) {
                                                    if (imgsBuilder.length() > 0)
                                                        imgsBuilder.append("#").append(imgOld);
                                                    else
                                                        imgsBuilder.append(imgOld);
                                                    if (imgsTagsBuilder.length() > 0)
                                                        imgsTagsBuilder.append("#").append(imgTagOld);
                                                    else
                                                        imgsTagsBuilder.append(imgTagOld);
                                                    //                                                break;
                                                }
                                            }
                                        }
                                    }

                                    if (imgsBuilder.length() > 0)
                                        justData.setA_images_local(imgsBuilder.toString());
                                    else
                                        justData.setA_images_local("");

                                    if (imgsTagsBuilder.length() > 0)
                                        justData.setA_image_tags(imgsTagsBuilder.toString());
                                    else
                                        justData.setA_image_tags("");
                                }
                            }

                            String B_existingPdfUrlServer = oldRecord.getB_pdfFile();
                            String B_existingVoiceUrlServer = oldRecord.getB_voiceFile();
                            String B_existingVideoUrlServer = oldRecord.getB_videoFile();
                            String B_existingImagesUrlServer = oldRecord.getB_images();

                            if (!Utils.isValidStr(justData.getB_pdfFile())) {
                                justData.setB_pdfFile_local("");
                            } else if (!justData.getB_pdfFile().equals(B_existingPdfUrlServer)) {
                                justData.setB_pdfFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_BENEFITS);
                                dto.setUrl(justData.getB_pdfFile());
                                dto.setType(AppConstants.PDF_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (!Utils.isValidStr(justData.getB_voiceFile())) {
                                justData.setB_voiceFile_local("");
                            } else if (!justData.getB_voiceFile().equals(B_existingVoiceUrlServer)) {
                                justData.setB_voiceFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_BENEFITS);
                                dto.setUrl(justData.getB_voiceFile());
                                dto.setType(AppConstants.VOICE_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (!Utils.isValidStr(justData.getB_videoFile())) {
                                justData.setB_videoFile_local("");
                            } else if (!justData.getB_videoFile().equals(B_existingVideoUrlServer)) {
                                justData.setB_videoFile_local("");
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_BENEFITS);
                                dto.setUrl(justData.getB_videoFile());
                                dto.setType(AppConstants.VIDEO_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (!Utils.isValidStr(B_existingImagesUrlServer) && !Utils.isValidStr(justData.getB_images())) {
                                //Do nothing
                            } else if (!Utils.isValidStr(B_existingImagesUrlServer) && Utils.isValidStr(justData.getB_images())) {
                                String[] imgs = justData.getB_images().split("#");
                                String[] imgTags = justData.getB_image_tags().split("#");
//                                for (String img : imgs) {
                                for (int i = 0; i < imgs.length; i++) {
                                    String img = imgs[i];
                                    DownloadFileDTO dto = new DownloadFileDTO();
                                    dto.setId(justData.getId());
                                    dto.setCategory(AppConstants.FAB_BENEFITS);
                                    dto.setUrl(img);
                                    dto.setType(AppConstants.IMAGE_TYPE);
                                    dto.setTag(imgTags[i]);
                                    downloadFileDTOs.add(dto);
                                }
                            } else if (Utils.isValidStr(B_existingImagesUrlServer) && !Utils.isValidStr(justData.getB_images())) {
                                justData.setB_images_local("");
                                justData.setB_image_tags("");
                            } else if (B_existingImagesUrlServer != null) {
                                if (!B_existingImagesUrlServer.equals(justData.getB_images())) {
                                    String[] imgs = justData.getB_images().split("#");
                                    String[] oldImgs = oldRecord.getB_images_local().split("#");
                                    String[] imgTags = justData.getB_image_tags().split("#");
                                    String[] oldImgTags = oldRecord.getB_image_tags().split("#");
                                    StringBuilder imgsBuilder = new StringBuilder();
                                    StringBuilder imgsTagsBuilder = new StringBuilder();
                                    //                                for (String img : imgs) {
                                    for (int i = 0; i < imgs.length; i++) {
                                        String img = imgs[i];
                                        if (!B_existingImagesUrlServer.contains(img)) {
                                            DownloadFileDTO dto = new DownloadFileDTO();
                                            dto.setId(justData.getId());
                                            dto.setCategory(AppConstants.FAB_BENEFITS);
                                            dto.setUrl(img);
                                            dto.setType(AppConstants.IMAGE_TYPE);
                                            dto.setTag(imgTags[i]);
                                            downloadFileDTOs.add(dto);
                                        } else {
                                            String imageName = img.substring(img.lastIndexOf("/") + 1);
                                            String imageTag = imgTags[i];
                                            //                                        for (String imgOld : oldImgs) {
                                            for (int j = 0; j < oldImgs.length; j++) {
                                                String imgOld = oldImgs[j];
                                                String imgTagOld = oldImgTags[j];
                                                if (imgOld.contains(imageName)) {
                                                    if (imgsBuilder.length() > 0)
                                                        imgsBuilder.append("#").append(imgOld);
                                                    else
                                                        imgsBuilder.append(imgOld);
                                                    if (imgsTagsBuilder.length() > 0)
                                                        imgsTagsBuilder.append("#").append(imgTagOld);
                                                    else
                                                        imgsTagsBuilder.append(imgTagOld);
                                                    //                                                break;
                                                }
                                            }
                                        }
                                    }

                                    if (imgsBuilder.length() > 0)
                                        justData.setB_images_local(imgsBuilder.toString());
                                    else
                                        justData.setB_images_local("");

                                    if (imgsTagsBuilder.length() > 0)
                                        justData.setB_image_tags(imgsTagsBuilder.toString());
                                    else
                                        justData.setB_image_tags("");

                                }
                            }

                            for (DownloadFileDTO dto : downloadFileDTOs) {
                                DownloadingFileDAO.getInstance().insert(dto, DBHandler.getWritableDb(this));
                            }

                            FabMasterDAO.getInstance().updateRecordById(fabMasterDto, DBHandler.getWritableDb(this));

                        } else {
                            List<DownloadFileDTO> downloadFileDTOs = new ArrayList<>();
                            if (Utils.isValidStr(justData.getF_pdfFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_FEATURES);
                                dto.setUrl(justData.getF_pdfFile());
                                dto.setType(AppConstants.PDF_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (Utils.isValidStr(justData.getF_voiceFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_FEATURES);
                                dto.setUrl(justData.getF_voiceFile());
                                dto.setType(AppConstants.VOICE_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (Utils.isValidStr(justData.getF_videoFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_FEATURES);
                                dto.setUrl(justData.getF_videoFile());
                                dto.setType(AppConstants.VIDEO_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (Utils.isValidStr(justData.getF_images())) {
                                String[] imgs = justData.getF_images().split("#");
                                String[] imgsTags = justData.getF_image_tags().split("#");
//                                for (String img : imgs) {
                                for (int i = 0; i < imgs.length; i++) {
                                    String img = imgs[i];
                                    String imgTag = imgsTags[i];
                                    DownloadFileDTO dto = new DownloadFileDTO();
                                    dto.setId(justData.getId());
                                    dto.setCategory(AppConstants.FAB_FEATURES);
                                    dto.setUrl(img);
                                    dto.setType(AppConstants.IMAGE_TYPE);
                                    dto.setTag(imgTag);
                                    downloadFileDTOs.add(dto);
                                }
                            }

                            if (Utils.isValidStr(justData.getA_pdfFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                dto.setUrl(justData.getA_pdfFile());
                                dto.setType(AppConstants.PDF_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (Utils.isValidStr(justData.getA_voiceFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                dto.setUrl(justData.getA_voiceFile());
                                dto.setType(AppConstants.VOICE_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (Utils.isValidStr(justData.getA_videoFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                dto.setUrl(justData.getA_videoFile());
                                dto.setType(AppConstants.VIDEO_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (Utils.isValidStr(justData.getA_images())) {
                                String[] imgs = justData.getA_images().split("#");
                                String[] imgsTags = justData.getA_image_tags().split("#");
//                                for (String img : imgs) {
                                for (int i = 0; i < imgs.length; i++) {
                                    String img = imgs[i];
                                    String imgTag = imgsTags[i];
                                    DownloadFileDTO dto = new DownloadFileDTO();
                                    dto.setId(justData.getId());
                                    dto.setCategory(AppConstants.FAB_ADVANTAGES);
                                    dto.setUrl(img);
                                    dto.setType(AppConstants.IMAGE_TYPE);
                                    dto.setTag(imgTag);
                                    downloadFileDTOs.add(dto);
                                }
                            }

                            if (Utils.isValidStr(justData.getB_pdfFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_BENEFITS);
                                dto.setUrl(justData.getB_pdfFile());
                                dto.setType(AppConstants.PDF_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (Utils.isValidStr(justData.getB_voiceFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_BENEFITS);
                                dto.setUrl(justData.getB_voiceFile());
                                dto.setType(AppConstants.VOICE_TYPE);
                                downloadFileDTOs.add(dto);
                            }
                            if (Utils.isValidStr(justData.getB_videoFile())) {
                                DownloadFileDTO dto = new DownloadFileDTO();
                                dto.setId(justData.getId());
                                dto.setCategory(AppConstants.FAB_BENEFITS);
                                dto.setUrl(justData.getB_videoFile());
                                dto.setType(AppConstants.VIDEO_TYPE);
                                downloadFileDTOs.add(dto);
                            }

                            if (Utils.isValidStr(justData.getB_images())) {
                                String[] imgs = justData.getB_images().split("#");
                                String[] imgsTags = justData.getB_image_tags().split("#");
//                                for (String img : imgs) {
                                for (int i = 0; i < imgs.length; i++) {
                                    String img = imgs[i];
                                    String imgTag = imgsTags[i];
                                    DownloadFileDTO dto = new DownloadFileDTO();
                                    dto.setId(justData.getId());
                                    dto.setCategory(AppConstants.FAB_BENEFITS);
                                    dto.setUrl(img);
                                    dto.setType(AppConstants.IMAGE_TYPE);
                                    dto.setTag(imgTag);
                                    downloadFileDTOs.add(dto);
                                }
                            }

                            for (DownloadFileDTO dto : downloadFileDTOs) {
                                DownloadingFileDAO.getInstance().insert(dto, DBHandler.getWritableDb(this));
                            }

//                            FabMasterDAO.getInstance().insert(fabMasterDto, DBHandler.getWritableDb(this));
                            FabMasterDAO.getInstance().insert(justData, DBHandler.getWritableDb(this));
                        }
                        displayFragments(justData);

                        startDownloadService();
                    } else if (AppConstants.SOMETHING_WENT_WRONG_INT == fabMasterDto.getStatusCode()/*AppConstants.SOMETHING_WENT_WRONG.equals(fabMasterDto.getStatusCode())*/) {
                        DialogManager.showToast(this, fabMasterDto.getMessage());
                        fabFragmentsAvailable.setVisibility(View.GONE);
                        fabFragmentsNotAvailable.setText(fabMasterDto.getMessage());
                        fabFragmentsNotAvailable.setVisibility(View.VISIBLE);
                    } else if (AppConstants.FAB_ADVISORY_NOT_AVAILABLE_CODE_INT == fabMasterDto.getStatusCode()/*AppConstants.FAB_ADVISORY_NOT_AVAILABLE_CODE.equals(fabMasterDto.getStatusCode())*/) {
                        fabFragmentsAvailable.setVisibility(View.GONE);
                        fabFragmentsNotAvailable.setText(fabMasterDto.getMessage());
                        fabFragmentsNotAvailable.setVisibility(View.VISIBLE);
                    } else if (AppConstants.NO_CHANGES_IN_CURRENT_VERSION_FAB_INT == fabMasterDto.getStatusCode()/*AppConstants.NO_CHANGES_IN_CURRENT_VERSION_FAB.equals(fabMasterDto.getStatusCode())*/) {
                        // don't do any thing because you are populating data before making an API call only.
                    }
                    /*else if (AppConstants.STATUS_CODE_LOGOUT_INT == fabMasterDto.getStatusCode()){
                        clearAllUserData(FABMainActivity.this);
                        Intent gotoLogin = new Intent(FABMainActivity.this, LoginActivity.class);
                        finish();
                        startActivity(gotoLogin);
                    }*/

                } else {
                    DialogManager.showToast(FABMainActivity.this, commonResponse.getRespMsg());
                }
            } else if (responseObj instanceof EditProfileStateDetailsResponse) {
                EditProfileStateDetailsResponse response = (EditProfileStateDetailsResponse) responseObj;
                if (response.getRespCd() == AppConstants.RESP_CODE_SUCCESS) {
                    Gson gson = new Gson();
                    Type listType = new TypeToken<List<StateModel>>() {
                    }.getType();
                    List<StateModel> states = gson.fromJson(response.getData(), listType);

                    if (states != null && !states.isEmpty()) {
                        statearraylist.clear();
                        statearraylist.add(selectState);
                        for (StateModel state : states) {
                            statearraylist.add(state.getStatename());
                        }

                        allStatesInfo = new ArrayList<>();
                        for (String state : statearraylist) {
                            allStatesInfo.add(new StateCodeEntity().setName(state));
                        }

                        StatesAdapter stateAd = new StatesAdapter(this, allStatesInfo);
                        spnState.setAdapter(stateAd);
                        /*for (int i = 0; i < statearraylist.size(); i++) {
                            if (statearraylist.get(i).equalsIgnoreCase(get_state)) {
                                spnState.setSelection(i);
                                break;
                            }
                        }
                        stateAdapter.notifyDataSetChanged();*/
                    } else {
                        spnState.setAdapter(null);
                        DisplayNoMasterDataAvailable();
                    }
                }else {
                    DialogManager.showToast(FABMainActivity.this, response.getRespMsg());
                }
            }
        }
    }

    private void startDownloadService() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O){
            Intent intent = new Intent(this, DownloadFileServiceNewJob.class);
            DownloadFileServiceNewJob.enqueueWork(this,intent);

        }else{

            Intent intent = new Intent(this, DownloadFileService.class);
            startService(intent);
        }
    }


    private void DisplayNoMasterDataAvailable() {
        fabNoMasterDataAvailable.setVisibility(View.VISIBLE);
        fabSpinersLL.setVisibility(View.GONE);
//        fabDetailsButton.setVisibility(View.GONE);
        fabTabsLL.setVisibility(View.GONE);
    }

    private void setAllAdapterInfo(CropAdvisoryModel allAdvisoryInfo) {

        allCropsInfo = (ArrayList<CropMasterEntity>) allAdvisoryInfo.getCropMaster();
        allHybrids = (ArrayList<HybridMasterEntity>) allAdvisoryInfo.getHybridMaster();
        allSeasonInfo = (ArrayList<SeasonMasterEntity>) allAdvisoryInfo.getSeasonMaster();
        allStatesInfo = (ArrayList<StateCodeEntity>) allAdvisoryInfo.getStateCodeMaster();

        if (allCropsInfo == null || allHybrids == null || allSeasonInfo == null || allStatesInfo == null) {
            // Do your stuff
            /*fabNoMasterDataAvailable.setVisibility(View.VISIBLE);
            fabSpinersLL.setVisibility(View.GONE);
            fabDetailsButton.setVisibility(View.GONE);
            fabTabsLL.setVisibility(View.GONE);*/
            fabNoMasterDataAvailable.setText(getResources().getString(R.string.no_data_available));
            DisplayNoMasterDataAvailable();

        } else {

            st_selectedState = allStatesInfo.get(0).getName();
            st_selectedStateID = allStatesInfo.get(0).getId();
            fabNoMasterDataAvailable.setText("");
            fabNoMasterDataAvailable.setVisibility(View.GONE);
            fabSpinersLL.setVisibility(View.VISIBLE);
            setCropSpinner(st_selectedStateID);

            /*IdNameAdapter cropAd = new IdNameAdapter(this, allCropsInfo);
            spnCrop.setAdapter(cropAd);
            cropAd.notifyDataSetChanged();*/
        }

    }

    private void getAllCropInfoFromLocal() {
        int val = FabMasterDAO.getInstance().isDataAvailable(DBHandler.getReadableDb(this));
        if (val > 0) {

            // Get all list from Local DB
            allCropsInfo = (ArrayList<CropMasterEntity>) FabMasterDAO.getInstance().getCrops(DBHandler.getReadableDb(this));
            allHybrids = (ArrayList<HybridMasterEntity>) FabMasterDAO.getInstance().getHybrids(DBHandler.getReadableDb(this));
            allSeasonInfo = (ArrayList<SeasonMasterEntity>) FabMasterDAO.getInstance().getSeasons(DBHandler.getReadableDb(this));
            allStatesInfo = (ArrayList<StateCodeEntity>) FabMasterDAO.getInstance().getState(DBHandler.getReadableDb(this));

            if (allCropsInfo == null || allHybrids == null || allSeasonInfo == null) {
                // Do your stuff
                fabNoMasterDataAvailable.setText(getResources().getString(R.string.no_data_available));
                DisplayNoMasterDataAvailable();
            } else {

                StatesAdapter stateAd = new StatesAdapter(this, allStatesInfo);
                spnState.setAdapter(stateAd);
                /*IdNameAdapter cropAd = new IdNameAdapter(this, allCropsInfo);
                spnCrop.setAdapter(cropAd);
                cropAd.notifyDataSetChanged();*/
                st_selectedState = allStatesInfo.get(0).getName();
                st_selectedStateID = allStatesInfo.get(0).getId();
            }
        } else {
            fabNoMasterDataAvailable.setText(getResources().getString(R.string.no_data_available));
            DisplayNoMasterDataAvailable();
        }
    }

    @Override
    public void onOkClick(View v) {

    }

    @Override
    public void onCancelClick(View view) {

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.imgBacknav) {
            finish();
        }
    }

    public class PagerAdapter extends FragmentStatePagerAdapter {
        FabMasterModel fabMasterDTO;

        private String tabTitles[] = new String[]{getString(R.string.featureFragment), getString(R.string.advantagesFragment), getString(R.string.benefitsFragment)};

        public PagerAdapter(FragmentManager fm, FabMasterModel fabMasterDTO) {
            super(fm);
            this.fabMasterDTO = fabMasterDTO;
        }


        @Override
        public CharSequence getPageTitle(int position) {
            return tabTitles[position];
        }

        @Override
        public Fragment getItem(int position) {

            Bundle setArgs = new Bundle();
            setArgs.putSerializable("fabArguments", fabMasterDTO);
            switch (position) {
                case 0:
                    setArgs.putString("fabCategory", AppConstants.FAB_FEATURES);
                    featureFrag.setArguments(setArgs);
                    return featureFrag;
                case 1:
                    setArgs.putString("fabCategory", AppConstants.FAB_ADVANTAGES);
                    advantageFrag.setArguments(setArgs);
                    return advantageFrag;
                case 2:
                    setArgs.putString("fabCategory", AppConstants.FAB_BENEFITS);
                    benefitsFrag.setArguments(setArgs);
                    return benefitsFrag;
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }
    }

    //    private void displayFragments(FabMasterDTO selectedFabDeetailsList) {
    private void displayFragments(FabMasterModel selectedFabDeetailsList) {

        //List<FabMasterDTO> selectedFabDeetailsList = FabMasterDAO.getInstance().getSelectedRecord(st_selectedCropID,st_selectedHybridID,st_selectedSeasonID, MyDbHelper.getReadableDb(mActivity));
        if (selectedFabDeetailsList != null) {

            if (menuVisible != null) {
                menuVisible.findItem(R.id.action_reset).setVisible(true);
            }
//            fabDetailsButton.setText(getString(R.string.st_reset_fab_button_txt));
            //fabDetailsButton.setBackground(getActivity().getResources().getDrawable(R.drawable.button_pressed));
//            fabDetailsButton.setBackgroundResource(R.drawable.button_pressed);
            fabNoMasterDataAvailable.setVisibility(View.GONE);
            fabFragmentsNotAvailable.setVisibility(View.GONE);
            fabFragmentsAvailable.setVisibility(View.VISIBLE);
            fabSpinersLL.setVisibility(View.GONE);
            fabTabsLL.setVisibility(View.VISIBLE);

            String st_description = selectedFabDeetailsList.getDescription();
            StringBuilder descriptionBuilder = new StringBuilder();
            if (Utils.isValidStr(st_description))
                descriptionBuilder.append(st_description);
            if (descriptionBuilder.length() > 0)
                descriptionText.setText(descriptionBuilder.toString());
            else
                descriptionLL.setVisibility(View.GONE);

            tabLayout = findViewById(R.id.featureAndBenefitsTabs);
            viewPager = findViewById(R.id.featureAndBenefitsViewPager);

            pageAdapter = new PagerAdapter(getSupportFragmentManager(), selectedFabDeetailsList);
            viewPager.setAdapter(pageAdapter);

            viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
            tabLayout.setupWithViewPager(viewPager);

            // set the divider between tabs
            View root = tabLayout.getChildAt(0);
            if (root instanceof LinearLayout) {
                ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
                GradientDrawable drawable = new GradientDrawable();
                drawable.setColor(getResources().getColor(R.color.white));
                drawable.setSize(2, 1);
                ((LinearLayout) root).setDividerPadding(0);
                ((LinearLayout) root).setDividerDrawable(drawable);
            }

            st_selectedState = allStatesInfo.get(0).getName();
            st_selectedStateID = allStatesInfo.get(0).getId();
        } else {
            // You  dont have any data
            fabNoMasterDataAvailable.setVisibility(View.VISIBLE);
        }
    }

    private void getSelectedFABDetailsAPI(String versionNumber, String st_selectedCropID, String st_selectedHybridID, String st_selectedSeasonID, String st_selectedStateID) {
//        FabSelectedReq fabMasterReq= new FabSelectedReq();
        FabMasterReqEntity fabMasterReq = new FabMasterReqEntity();
        fabMasterReq.setVersion(versionNumber);
        fabMasterReq.setStateId(st_selectedStateID);
        fabMasterReq.setCropId(st_selectedCropID);
        fabMasterReq.setHybridId(st_selectedHybridID);
        fabMasterReq.setSeasonId(st_selectedSeasonID);
        fabMasterReq.setMobileNumber(Utils.getUserMobile(this));
        fabMasterReq.setDeviceToken(Utils.getToken(this));

        String selectedInfo = new Gson().toJson(fabMasterReq, FabMasterReqEntity.class);
        String jwtToken = Utils.getJWTToken(selectedInfo, this);
//        APIRequestHandler.getInstance().getSelectedFABDetailsAPI(this,jwtToken,this, true);
        APIRequestHandler.getInstance().getSelectedFABDetailsAPINew(this, jwtToken, this, true);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_fab, menu);
        this.menuVisible = menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.action_reset:
               /* fabDetailsButton.setText(getActivity().getString(R.string.st_get_fab_details));
                fabDetailsButton.setBackgroundResource(R.drawable.button_unpressed);*/
                fabDetailsButton.setVisibility(View.VISIBLE);
                fabTabsLL.setVisibility(View.GONE);
                fabSpinersLL.setVisibility(View.VISIBLE);
                item.setVisible(false);
                hedderText.setText(AppConstants.FEATURESANDBENEFITS);
                break;
        }
        return false;

    }
}
