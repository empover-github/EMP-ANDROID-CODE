package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.activitytrack.utility.ATBuildLog;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.UploadImagesDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rambabu.a on 09-03-2018.
 */

public class UpLoadImagesDAO implements DAO {
    private final String TAG = "RetailAuditActivity";

    private static UpLoadImagesDAO upLoadFileRetailAuditDAO;

    public static UpLoadImagesDAO getInstance() {
        if (upLoadFileRetailAuditDAO == null) {
            upLoadFileRetailAuditDAO = new UpLoadImagesDAO();
        }
        return upLoadFileRetailAuditDAO;
    }


    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {


        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        try
        {
            UploadImagesDTO dto = (UploadImagesDTO) dtoObject;
            dbObject.execSQL("delete from "+DBHandler.TABLE_UPLOAD_IMAGES+" where imageId='"+dto.getServerId()+"'");
            return true;
        }catch(Exception e)
        {
            ATBuildLog.e(TAG +"delete",e.getMessage());
        }finally
        {
            dbObject.close();

        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public boolean deleteDataById(long id, SQLiteDatabase dbObject) {
        try
        {
            dbObject.execSQL("delete from "+DBHandler.TABLE_UPLOAD_IMAGES+" where imageId='"+id+"'");
            return true;
        }catch(Exception e)
        {
            ATBuildLog.e(TAG +"delete",e.getMessage());
        }finally
        {
            dbObject.close();

        }
        return false;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try
        {
            UploadImagesDTO dto = (UploadImagesDTO) dtoObject;

            /*private long imageId; // autoIncreamentKey
            private String imagePath;
            private long serverId;*/
            ContentValues cValues = new ContentValues();

            cValues.put("imagePath", dto.getImagePath());
            cValues.put("serverId", dto.getServerId());

            dbObject.insert(DBHandler.TABLE_UPLOAD_IMAGES, null, cValues);
            return "";
        } catch (SQLException e)
        {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return "";
        } finally
        {
            dbObject.close();
        }
    }

    public List<UploadImagesDTO> getRecordsToUpload(SQLiteDatabase dbObject, Context context) {
        Cursor cursor = null;
        List<UploadImagesDTO> list = new ArrayList<UploadImagesDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_UPLOAD_IMAGES/*+" WHERE isSync = 1"*/, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                UploadImagesDTO dto;
                do {
                     /*private long imageId;
            private String imagePath;
            private long serverId;*/
                    dto = new UploadImagesDTO();
                    dto.setImageId(cursor.getLong(cursor.getColumnIndex("imageId")));
                    dto.setImagePath(cursor.getString(cursor.getColumnIndex("imagePath")));
                    dto.setServerId(cursor.getLong(cursor.getColumnIndex("serverId")));
                    list.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return list;
    }

    public int isDataAvailableToUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        List<UploadImagesDTO> list = new ArrayList<UploadImagesDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT count(*) FROM "+DBHandler.TABLE_UPLOAD_IMAGES/*+" WHERE isSync = 1"*/, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0);
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return 0;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " +DBHandler.TABLE_UPLOAD_IMAGES).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }


    public List<UploadImagesDTO> getRecordsOfserverId(long serverId ,SQLiteDatabase dbObject, Context context) {
        Cursor cursor = null;
        List<UploadImagesDTO> list = new ArrayList<UploadImagesDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_UPLOAD_IMAGES+" where serverId='"+serverId+"'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                UploadImagesDTO dto;
                do {
                     /* private long imageId;
            private String imagePath;
            private long serverId; */
                    dto = new UploadImagesDTO();
                    dto.setImageId(cursor.getLong(cursor.getColumnIndex("imageId")));
                    dto.setImagePath(cursor.getString(cursor.getColumnIndex("imagePath")));
                    dto.setServerId(cursor.getLong(cursor.getColumnIndex("serverId")));
                    list.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return list;
    }
}
