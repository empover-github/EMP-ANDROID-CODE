package com.pioneer.emp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class EmpCropAdvisory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_activity_crop_advisory);
    }
}
