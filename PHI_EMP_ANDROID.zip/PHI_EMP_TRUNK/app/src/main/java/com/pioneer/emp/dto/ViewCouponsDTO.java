package com.pioneer.emp.dto;

import java.io.Serializable;

/**
 * Created by hareesh.a on 7/12/2017.
 */

public class ViewCouponsDTO implements Serializable {

    private String crop;
    private String season;
    private String year;
    private String couponNumber;
    private String validTill;
    private String sharedBy;
    private String sharedByMobileNo;

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getCouponNumber() {
        return couponNumber;
    }

    public void setCouponNumber(String couponNumber) {
        this.couponNumber = couponNumber;
    }

    public String getValidTill() {
        return validTill;
    }

    public void setValidTill(String validTill) {
        this.validTill = validTill;
    }

    public String getSharedBy() {
        return sharedBy;
    }

    public void setSharedBy(String sharedBy) {
        this.sharedBy = sharedBy;
    }

    public String getSharedByMobileNo() {
        return sharedByMobileNo;
    }

    public void setSharedByMobileNo(String sharedByMobileNo) {
        this.sharedByMobileNo = sharedByMobileNo;
    }
}
