package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dto.DailyLiquidationTopTenRetailersVolumeDTO;
import com.pioneer.emp.models.TopTenRetailerModel;


import java.util.List;

public class RetailerAdapter extends BaseAdapter {
    List<DailyLiquidationTopTenRetailersVolumeDTO> cuMobileData;
    Context context;

    public RetailerAdapter(Context context, List<DailyLiquidationTopTenRetailersVolumeDTO> data) {
        this.cuMobileData = data;
        this.context = context;
    }

    @Override
    public int getCount() {
        return cuMobileData.size();
    }

    @Override
    public Object getItem(int position) {
        return cuMobileData.get(position);
    }

    public void updateList(List<DailyLiquidationTopTenRetailersVolumeDTO> data) {
        cuMobileData = data;
        notifyDataSetChanged();
    }
    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            //  convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, null);
            convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, parent,false);
        }
        TextView textView = convertView.findViewById(R.id.textView1);
        DailyLiquidationTopTenRetailersVolumeDTO id = cuMobileData.get(position);
        textView.setText(id.getRetailerFirmName());


        return convertView;
    }


    @Override
    public View getDropDownView(int position, View convertView,
                                ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, null);
        }

        TextView textView = convertView.findViewById(R.id.textView1);
        DailyLiquidationTopTenRetailersVolumeDTO id = cuMobileData.get(position);
        textView.setText(id.getRetailerFirmName());

        return convertView;

    }
}
