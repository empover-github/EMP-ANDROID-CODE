package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dao.DailyLiquidationRetailersSalesDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.DailyLiquidationTopTenRetailersVolumeDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;


import java.text.DecimalFormat;
import java.util.List;

public class TopTenRetailersAdapter extends RecyclerView.Adapter<TopTenRetailersAdapter.TopTenRetailers> {
    private Context context;
    private List<DailyLiquidationTopTenRetailersVolumeDTO> topTenRetailerList;
    private OnBookletClickListener listener;
    private boolean isRetailerExist;

    public TopTenRetailersAdapter(Context mContext, List<DailyLiquidationTopTenRetailersVolumeDTO> retailersData, OnBookletClickListener onBookletClickListener) {
        this.context = mContext;
        this.topTenRetailerList = retailersData;
        this.listener = onBookletClickListener;
    }

    @NonNull
    @Override
    public TopTenRetailers onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_ten_retailers_list_item, parent, false);
        TopTenRetailers myHolder = new TopTenRetailers(layout);
        return myHolder;
    }

    @Override
    public int getItemCount() {
        return topTenRetailerList.size();
    }


    @Override
    public void onBindViewHolder(TopTenRetailersAdapter.TopTenRetailers holder, int position) {

        holder.bind(topTenRetailerList.get(position), position);

    }

    public class TopTenRetailers extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvRetailersName, tvPioneer, tvComp1, tvComp2, tvOthers, tvTotal;
        LinearLayout mainLayout;
        ImageView imgEdit;

        TopTenRetailers(View itemView) {
            super(itemView);

            tvRetailersName = itemView.findViewById(R.id.tv_list_retailers);
            tvPioneer = itemView.findViewById(R.id.tv_list_pioneer);
            tvComp1 = itemView.findViewById(R.id.tv_list_comp1);
            tvComp2 = itemView.findViewById(R.id.tv_list_comp2);
            tvOthers = itemView.findViewById(R.id.tv_list_others);
            tvTotal = itemView.findViewById(R.id.tv_list_total);
            mainLayout = itemView.findViewById(R.id.mainlayout_topTenRetailers);
            imgEdit = itemView.findViewById(R.id.img_list_edt);
            // mainLayout.setOnClickListener(this);
            imgEdit.setOnClickListener(this);
            if (topTenRetailerList != null) {
                for (int i = 0; i < topTenRetailerList.size(); i++) {
                    long calendarId = topTenRetailerList.get(i).getCalendarId();
                    isRetailerExist = DailyLiquidationRetailersSalesDAO.getInstance().isRetailerExist(calendarId, DBHandler.getReadableDb(context));
                }

            }

            if (topTenRetailerList.size() == 0 || isRetailerExist) {
                imgEdit.setVisibility(View.GONE);
            } else {
                imgEdit.setVisibility(View.VISIBLE);
            }

        }

        @Override
        public void onClick(View v) {
            listener.onItemClick(v, getAdapterPosition());
        }

        public void bind(final DailyLiquidationTopTenRetailersVolumeDTO dto, int position) {
            DecimalFormat df2 = new DecimalFormat("#.#");
            if (dto != null) {
                if (dto.getRetailerFirmName() != null && dto.getRetailerMobileNumber() != null)
                    tvRetailersName.setText(dto.getRetailerFirmName() + " : " + dto.getRetailerMobileNumber());
                // tvRetailersMobNo.setText(" : " + dto.getRetailerMobileNumber());
                tvPioneer.setText(String.valueOf(df2.format(dto.getPioneerSales())));
              //  tvPioneer.setText(String.valueOf(dto.getPioneerSales()));
                tvComp1.setText(String.valueOf(df2.format(dto.getCompetitor1Sales())));
               // tvComp1.setText(String.valueOf(dto.getCompetitor1Sales()));
                tvComp2.setText(String.valueOf(df2.format(dto.getCompetitor2Sales())));
                //tvComp2.setText(String.valueOf(dto.getCompetitor2Sales()));
                //tvOthers.setText(String.valueOf(dto.getOthersSales()));
                tvOthers.setText(String.valueOf(df2.format(dto.getOthersSales())));
                tvTotal.setText(String.valueOf(df2.format(dto.getTotalSales())));
                //tvTotal.setText(String.valueOf(dto.getTotalSales()));
            }
            // mainLayout.setTag(dto);
            imgEdit.setTag(dto);

        }
    }
}
