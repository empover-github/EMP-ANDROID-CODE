package com.pioneer.emp.cropDiagnostic;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.pioneer.emp.R;
import com.pioneer.emp.listeners.OnBookletClickListener;

import java.util.ArrayList;

/**
 * Created by fatima.t on 21-02-2018.
 */

public class CDHDHorizontalRecycleAdapter extends RecyclerView.Adapter<CDHDHorizontalRecycleAdapter.viewHolder> {
    private Context context;
    private ArrayList<String> imageUrl;
    private ArrayList<String> imageId;
    private final OnBookletClickListener listener;

    public CDHDHorizontalRecycleAdapter(Context context, ArrayList<String> imageId, ArrayList<String> imageUrl, OnBookletClickListener listener) {
        this.context = context;
        this.imageId = imageId;
        this.imageUrl = imageUrl;
        this.listener = listener;
    }

    @Override
    public viewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View messageView = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_list_item, parent, false);
        return new viewHolder(messageView);
    }



    @Override
    public void onBindViewHolder(viewHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return imageId.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView euipmentImg;

        public viewHolder(View view) {
            super(view);
            euipmentImg = view.findViewById(R.id.grid_image);
        }

        void bind(final int position) {
            Glide.with(context).load(imageUrl.get(position)).error(R.mipmap.image_not_exist).into(euipmentImg);
            euipmentImg.setTag(position);
//            euipmentImg.setTag(imageId.get(position));
            euipmentImg.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            int position = (int) v.getTag();
            listener.onItemClick(v, position);
        }
    }




}

