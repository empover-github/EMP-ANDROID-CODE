package com.pioneer.emp.cropDiagnostic;

import java.util.ArrayList;

/**
 * Created by Yakaswamy.g on 8/16/2017.
 */

public class CropDiseaseResponse {

    private ArrayList<CropDiseaseModel> cropDiagnosisResponseDTO;
    //new added
    private long id;

    public ArrayList<CropDiseaseModel> getCropDiagnosisResponseDTO() {
        return cropDiagnosisResponseDTO;
    }

    public void setCropDiagnosisResponseDTO(ArrayList<CropDiseaseModel> cropDiagnosisResponseDTO) {
        this.cropDiagnosisResponseDTO = cropDiagnosisResponseDTO;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
