package com.pioneer.emp.cropDiagnostic;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.adapters.CDAllProductsAdapter;
import com.pioneer.emp.dao.AgroDiseaseProductMappingDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.AgroDiseaseProductMappingDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.activities.BaseActivity;

import java.util.ArrayList;

/**
 * Created by rambabu.a on 17-01-2018.
 */

public class CDAllProductsActivity extends BaseActivity implements View.OnClickListener, OnBookletClickListener {
    private ArrayList<AgroDiseaseProductMappingDTO> diagnosisList;
    RecyclerView recyclerView;
    private TextView allProdNoDataAvaialableTxt;
    private CDAllProductsAdapter notificationAdapter;

    private Toolbar toolbar;
    private TextView txtHeader;
    private ImageView navBackBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cd_all_products);

        // ActionBar Related components
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        txtHeader = findViewById(R.id.header_text);
        txtHeader.setText(getString(R.string.cdAllProducts));
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);

        recyclerView = findViewById(R.id.recycler_view);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(CDAllProductsActivity.this);
        recyclerView.setLayoutManager(layoutManager);

        allProdNoDataAvaialableTxt = findViewById(R.id.all_prod_noDataAvailableTxt);

        diagnosisList = (ArrayList<AgroDiseaseProductMappingDTO>) AgroDiseaseProductMappingDAO.getInstance().getAllRecords(DBHandler.getReadableDb(CDAllProductsActivity.this));

        if (diagnosisList != null && !diagnosisList.isEmpty()) {
            notificationAdapter = new CDAllProductsAdapter(CDAllProductsActivity.this, diagnosisList, this);
            recyclerView.setAdapter(notificationAdapter);
            recyclerView.setVisibility(View.VISIBLE);
            allProdNoDataAvaialableTxt.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.GONE);
            allProdNoDataAvaialableTxt.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onItemLongClick(View view, int position) {
        // DO nothing
    }

    @Override
    public void onItemClick(View view, int position) {

        int productId = (int) view.getTag();
        Intent intent = new Intent(CDAllProductsActivity.this, CDProductDetailsActivity.class);
        intent.putExtra(CDProductDetailsActivity.EXTRA_PRODUCT_MAPPING_ID, String.valueOf(productId));
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imgBacknav:
                onBackPressed();
                break;
        }
    }
}
