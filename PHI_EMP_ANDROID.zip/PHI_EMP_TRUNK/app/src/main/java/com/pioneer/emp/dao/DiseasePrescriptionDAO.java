package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.cropDiagnostic.CropDiseaseModel;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.DiseasePrescriptionDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

import static com.pioneer.emp.dbHandler.DBHandler.TABLE_DISEASE_PRESCRIPTION;

/**
 * Created by hareesh.a on 12/18/2017.
 */

public class DiseasePrescriptionDAO implements DAO {
    private final String TAG = "Disease";
    private static DiseasePrescriptionDAO diseasePrescription;

    public static DiseasePrescriptionDAO getInstance() {
        if (diseasePrescription == null) {
            diseasePrescription = new DiseasePrescriptionDAO();
        }
        return diseasePrescription;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DiseasePrescriptionDTO dto = (DiseasePrescriptionDTO) dtoObject;
            ContentValues values = new ContentValues();

            values.put("diseaseId", dto.getDiseaseId());
            values.put("diseaseName", dto.getDiseaseName());
            values.put("diseaseBiologicalName", dto.getDiseaseBiologicalName());
            values.put("crop", dto.getCrop());
            values.put("diseaseType", dto.getDiseaseType());
            values.put("hosts", dto.getHosts());
            values.put("inANutshell", dto.getInANutshell());
            values.put("symptoms", dto.getSymptoms());
            values.put("trigger", dto.getTrigger());
            values.put("preventiveMeasures", dto.getPreventiveMeasures());
            values.put("biologicalControl", dto.getBiologicalControl());
            values.put("chemicalControl", dto.getChemicalControl());
            values.put("hazadDescription", dto.getHazadDescription());
            values.put("diseaseImageFile", dto.getDiseaseImageFile());
            values.put("active", dto.getActive());
            values.put("deleted", dto.getDeleted());
            values.put("productMapping", dto.getProductMapping());
            values.put("productMappingImage", dto.getProductMappingImage());
            values.put("createdOn", dto.getCreatedOn());
            values.put("updatedOn", dto.getUpdatedOn());
            values.put("id", dto.getId());
            values.put("status", dto.getStatus());
            values.put("cdi_images_local", dto.getCdi_images_local());

            long rowsEffected = dbObject.insert(TABLE_DISEASE_PRESCRIPTION, null, values);
            if (rowsEffected > 0)
                return "";

        } catch (SQLException e) {
            BuildLog.i(TAG + "insert()", e.getMessage());
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public boolean deleteRecordById(long id, SQLiteDatabase dbObject) {
        try {
            int rowsEffected = dbObject.delete(TABLE_DISEASE_PRESCRIPTION, "id = '" + id + "'", null);
            return rowsEffected > 0;
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }


    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  " + DBHandler.TABLE_DISEASE_PRESCRIPTION).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public List<CropDiseaseModel> getHazardTypeList(String cropName, String hazardType, SQLiteDatabase dbObject) {
        List<CropDiseaseModel> listInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_DISEASE_PRESCRIPTION + " WHERE crop = '" + cropName + "' AND diseaseType = '" + hazardType + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropDiseaseModel dto = new CropDiseaseModel();
                    dto.setDiseaseId(cursor.getLong(cursor.getColumnIndex("diseaseId")));
                    dto.setDiseaseName(cursor.getString(cursor.getColumnIndex("diseaseName")));
                    dto.setDiseaseType(cursor.getString(cursor.getColumnIndex("diseaseType")));
                    dto.setDiseaseScientificName(cursor.getString(cursor.getColumnIndex("diseaseBiologicalName")));
                    dto.setImagePath(cursor.getString(cursor.getColumnIndex("diseaseImageFile")));
                    dto.setCdi_images_local(cursor.getString(cursor.getColumnIndex("cdi_images_local")));

                    listInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return listInfo;
    }

    public List<CropDiseaseModel> getDiseaseTypeList(String cropName, String fugalType, String bacType, String viraType, SQLiteDatabase dbObject) {
        List<CropDiseaseModel> listInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_DISEASE_PRESCRIPTION + " WHERE crop = '" + cropName + "' AND (diseaseType = '" + fugalType + "' OR diseaseType = '" + bacType + "' OR diseaseType = '" + viraType + "') ORDER BY diseaseType ASC", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropDiseaseModel dto = new CropDiseaseModel();
                    dto.setDiseaseId(cursor.getLong(cursor.getColumnIndex("diseaseId")));
                    dto.setDiseaseName(cursor.getString(cursor.getColumnIndex("diseaseName")));
                    dto.setDiseaseScientificName(cursor.getString(cursor.getColumnIndex("diseaseBiologicalName")));
                    dto.setImagePath(cursor.getString(cursor.getColumnIndex("diseaseImageFile")));
                    dto.setCdi_images_local(cursor.getString(cursor.getColumnIndex("cdi_images_local")));
                    dto.setDiseaseType(cursor.getString(cursor.getColumnIndex("diseaseType")));

                    listInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return listInfo;
    }


    public List<CropDiseaseModel> getNutritionalTypeList(String cropName, String npkType, String microType, SQLiteDatabase dbObject) {
        List<CropDiseaseModel> listInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_DISEASE_PRESCRIPTION + " WHERE crop = '" + cropName + "' AND (diseaseType = '" + npkType + "' OR diseaseType = '" + microType + "') ORDER BY diseaseType ASC", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropDiseaseModel dto = new CropDiseaseModel();
                    dto.setDiseaseId(cursor.getLong(cursor.getColumnIndex("diseaseId")));
                    dto.setDiseaseName(cursor.getString(cursor.getColumnIndex("diseaseName")));
                    dto.setDiseaseScientificName(cursor.getString(cursor.getColumnIndex("diseaseBiologicalName")));
                    dto.setImagePath(cursor.getString(cursor.getColumnIndex("diseaseImageFile")));
                    dto.setCdi_images_local(cursor.getString(cursor.getColumnIndex("cdi_images_local")));
                    dto.setDiseaseType(cursor.getString(cursor.getColumnIndex("diseaseType")));

                    listInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return listInfo;
    }

    public DiseasePrescriptionDTO getSelectedRecordByDiseaseId(String cropName, String hazardType, long diseaseId, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_DISEASE_PRESCRIPTION + " WHERE crop = '" + cropName + "' AND diseaseType = '" + hazardType + "' AND diseaseId = '" + diseaseId + "'", null);
//            cursor = dbObject.rawQuery("Select diseaseName, diseaseImageFile, hazadDescription, productMapping from "+TABLE_DISEASE_PRESCRIPTION + " WHERE crop = '"+cropName+"' AND diseaseType = '"+hazardType+"' AND diseaseId = '"+diseaseId+"'",null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DiseasePrescriptionDTO dto = new DiseasePrescriptionDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setDiseaseId(cursor.getString(cursor.getColumnIndex("diseaseId")));
                    dto.setDiseaseName(cursor.getString(cursor.getColumnIndex("diseaseName")));
                    dto.setDiseaseBiologicalName(cursor.getString(cursor.getColumnIndex("diseaseBiologicalName")));
                    dto.setCrop(cursor.getString(cursor.getColumnIndex("crop")));
                    dto.setDiseaseType(cursor.getString(cursor.getColumnIndex("diseaseType")));
                    dto.setHosts(cursor.getString(cursor.getColumnIndex("hosts")));
                    dto.setInANutshell(cursor.getString(cursor.getColumnIndex("inANutshell")));
                    dto.setSymptoms(cursor.getString(cursor.getColumnIndex("symptoms")));
                    dto.setTrigger(cursor.getString(cursor.getColumnIndex("trigger")));
                    dto.setPreventiveMeasures(cursor.getString(cursor.getColumnIndex("preventiveMeasures")));
                    dto.setBiologicalControl(cursor.getString(cursor.getColumnIndex("biologicalControl")));
                    dto.setChemicalControl(cursor.getString(cursor.getColumnIndex("chemicalControl")));
                    dto.setHazadDescription(cursor.getString(cursor.getColumnIndex("hazadDescription")));
                    dto.setDiseaseImageFile(cursor.getString(cursor.getColumnIndex("diseaseImageFile")));
                    dto.setActive(cursor.getString(cursor.getColumnIndex("active")));
                    dto.setDeleted(cursor.getString(cursor.getColumnIndex("deleted")));
                    dto.setProductMapping(cursor.getString(cursor.getColumnIndex("productMapping")));
                    dto.setProductMappingImage(cursor.getString(cursor.getColumnIndex("productMappingImage")));
                    dto.setCreatedOn(cursor.getString(cursor.getColumnIndex("createdOn")));
                    dto.setUpdatedOn(cursor.getString(cursor.getColumnIndex("updatedOn")));
                    dto.setStatus(cursor.getString(cursor.getColumnIndex("status")));
                    dto.setCdi_images_local(cursor.getString(cursor.getColumnIndex("cdi_images_local")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }

    public DiseasePrescriptionDTO getSelectedRecordByDiseaseName(String cropName, String hazardType, String diseaseName, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_DISEASE_PRESCRIPTION + " WHERE crop = '" + cropName + "' AND diseaseType = '" + hazardType + "' AND diseaseName = '" + diseaseName + "'", null);
//            cursor = dbObject.rawQuery("Select diseaseName, diseaseImageFile, hazadDescription, productMapping from "+TABLE_DISEASE_PRESCRIPTION + " WHERE crop = '"+cropName+"' AND diseaseType = '"+hazardType+"' AND diseaseId = '"+diseaseId+"'",null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DiseasePrescriptionDTO dto = new DiseasePrescriptionDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setDiseaseId(cursor.getString(cursor.getColumnIndex("diseaseId")));
                    dto.setDiseaseName(cursor.getString(cursor.getColumnIndex("diseaseName")));
                    dto.setDiseaseBiologicalName(cursor.getString(cursor.getColumnIndex("diseaseBiologicalName")));
                    dto.setCrop(cursor.getString(cursor.getColumnIndex("crop")));
                    dto.setDiseaseType(cursor.getString(cursor.getColumnIndex("diseaseType")));
                    dto.setHosts(cursor.getString(cursor.getColumnIndex("hosts")));
                    dto.setInANutshell(cursor.getString(cursor.getColumnIndex("inANutshell")));
                    dto.setSymptoms(cursor.getString(cursor.getColumnIndex("symptoms")));
                    dto.setTrigger(cursor.getString(cursor.getColumnIndex("trigger")));
                    dto.setPreventiveMeasures(cursor.getString(cursor.getColumnIndex("preventiveMeasures")));
                    dto.setBiologicalControl(cursor.getString(cursor.getColumnIndex("biologicalControl")));
                    dto.setChemicalControl(cursor.getString(cursor.getColumnIndex("chemicalControl")));
                    dto.setHazadDescription(cursor.getString(cursor.getColumnIndex("hazadDescription")));
                    dto.setDiseaseImageFile(cursor.getString(cursor.getColumnIndex("diseaseImageFile")));
                    dto.setActive(cursor.getString(cursor.getColumnIndex("active")));
                    dto.setDeleted(cursor.getString(cursor.getColumnIndex("deleted")));
                    dto.setProductMapping(cursor.getString(cursor.getColumnIndex("productMapping")));
                    dto.setProductMappingImage(cursor.getString(cursor.getColumnIndex("productMappingImage")));
                    dto.setCreatedOn(cursor.getString(cursor.getColumnIndex("createdOn")));
                    dto.setUpdatedOn(cursor.getString(cursor.getColumnIndex("updatedOn")));
                    dto.setStatus(cursor.getString(cursor.getColumnIndex("status")));
                    dto.setCdi_images_local(cursor.getString(cursor.getColumnIndex("cdi_images_local")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }

    public DiseasePrescriptionDTO getRecordById(long id, SQLiteDatabase dbObject) {
        DiseasePrescriptionDTO response = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_DISEASE_PRESCRIPTION + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    response = new DiseasePrescriptionDTO();

                    response.setDiseaseId(cursor.getString(cursor.getColumnIndex("diseaseId")));
                    response.setDiseaseName(cursor.getString(cursor.getColumnIndex("diseaseName")));
                    response.setDiseaseBiologicalName(cursor.getString(cursor.getColumnIndex("diseaseBiologicalName")));
                    response.setCrop(cursor.getString(cursor.getColumnIndex("crop")));
                    response.setDiseaseType(cursor.getString(cursor.getColumnIndex("diseaseType")));
                    response.setHosts(cursor.getString(cursor.getColumnIndex("hosts")));
                    response.setInANutshell(cursor.getString(cursor.getColumnIndex("inANutshell")));
                    response.setSymptoms(cursor.getString(cursor.getColumnIndex("symptoms")));
                    response.setTrigger(cursor.getString(cursor.getColumnIndex("trigger")));
                    response.setPreventiveMeasures(cursor.getString(cursor.getColumnIndex("preventiveMeasures")));
                    response.setBiologicalControl(cursor.getString(cursor.getColumnIndex("biologicalControl")));
                    response.setChemicalControl(cursor.getString(cursor.getColumnIndex("chemicalControl")));
                    response.setHazadDescription(cursor.getString(cursor.getColumnIndex("hazadDescription")));
                    response.setDiseaseImageFile(cursor.getString(cursor.getColumnIndex("diseaseImageFile")));
                    response.setActive(cursor.getString(cursor.getColumnIndex("active")));
                    response.setDeleted(cursor.getString(cursor.getColumnIndex("deleted")));
                    response.setProductMapping(cursor.getString(cursor.getColumnIndex("productMapping")));
                    response.setCreatedOn(cursor.getString(cursor.getColumnIndex("createdOn")));
                    response.setUpdatedOn(cursor.getString(cursor.getColumnIndex("updatedOn")));
                    response.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    response.setStatus(cursor.getString(cursor.getColumnIndex("status")));
                    response.setCdi_images_local(cursor.getString(cursor.getColumnIndex("cdi_images_local")));

                    return response;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return response;
    }

    public boolean updateRecordById(DTO mainDTO, SQLiteDatabase dbObject) {
        DiseasePrescriptionDTO dto = null;
        try {
            dto = (DiseasePrescriptionDTO) mainDTO;
            ContentValues values = new ContentValues();

            values.put("diseaseId", dto.getDiseaseId());
            values.put("diseaseName", dto.getDiseaseName());
            values.put("diseaseBiologicalName", dto.getDiseaseBiologicalName());
            values.put("crop", dto.getCrop());
            values.put("diseaseType", dto.getDiseaseType());
            values.put("hosts", dto.getHosts());
            values.put("inANutshell", dto.getInANutshell());
            values.put("symptoms", dto.getSymptoms());
            values.put("trigger", dto.getTrigger());
            values.put("preventiveMeasures", dto.getPreventiveMeasures());
            values.put("biologicalControl", dto.getBiologicalControl());
            values.put("chemicalControl", dto.getChemicalControl());
            values.put("hazadDescription", dto.getHazadDescription());
            values.put("diseaseImageFile", dto.getDiseaseImageFile());
            values.put("active", dto.getActive());
            values.put("deleted", dto.getDeleted());
            values.put("productMapping", dto.getProductMapping());
            values.put("createdOn", dto.getCreatedOn());
            values.put("updatedOn", dto.getUpdatedOn());
            values.put("id", dto.getId());
            values.put("status", dto.getStatus());

            if (dto.getCdi_images_local() != null)
                values.put("cdi_images_local", dto.getCdi_images_local());

            dbObject.update(TABLE_DISEASE_PRESCRIPTION, values, "id = '" + dto.getId() + "'", null);
            return true;
        } catch (Exception e) {
            BuildLog.d(TAG, "updateRecordById: "+e);
        } finally {
            dbObject.close();
        }
        return false;
    }

    public boolean isExists(String id, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select count(*) from " + TABLE_DISEASE_PRESCRIPTION + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0) > 0;
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }
}
