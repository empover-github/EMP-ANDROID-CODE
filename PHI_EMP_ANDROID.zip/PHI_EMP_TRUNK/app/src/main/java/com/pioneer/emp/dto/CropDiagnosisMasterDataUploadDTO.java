package com.pioneer.emp.dto;

import com.pioneer.parivaar.dto.DTO;

import java.io.Serializable;

public class CropDiagnosisMasterDataUploadDTO implements DTO {
    private long id;
    private long cropId;
    private String cropName;
    private long diseaseClassificationId;
    private String diseaseClassificationName;
    private String tags;
    private String imageUrls;
    private String latLongValues;
    private String address;
    private int imgTotCount;
    private int status;
    private long serverId;
    private String transactionTime;

    private String imagePending;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public long getDiseaseClassificationId() {
        return diseaseClassificationId;
    }

    public void setDiseaseClassificationId(long diseaseClassificationId) {
        this.diseaseClassificationId = diseaseClassificationId;
    }

    public String getDiseaseClassificationName() {
        return diseaseClassificationName;
    }

    public void setDiseaseClassificationName(String diseaseClassificationName) {
        this.diseaseClassificationName = diseaseClassificationName;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getImageUrls() {
        return imageUrls;
    }

    public void setImageUrls(String imageUrls) {
        this.imageUrls = imageUrls;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getLatLongValues() {
        return latLongValues;
    }

    public void setLatLongValues(String latLongValues) {
        this.latLongValues = latLongValues;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getImgTotCount() {
        return imgTotCount;
    }

    public void setImgTotCount(int imgTotCount) {
        this.imgTotCount = imgTotCount;
    }

    public long getServerId() {
        return serverId;
    }

    public void setServerId(long serverId) {
        this.serverId = serverId;
    }

    public String getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getImagePending() {
        return imagePending;
    }

    public void setImagePending(String imagePending) {
        this.imagePending = imagePending;
    }
}
