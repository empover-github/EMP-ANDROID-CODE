package com.pioneer.emp.cropDiagnostic;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.pioneer.emp.R;
import com.pioneer.emp.adapters.CropDiagnosisGridAdapter;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.CommonResponseEntity;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.CommonInterface;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit.RetrofitError;

import static com.pioneer.parivaar.utils.DialogManager.getDialog;

public class CropDiagnosisMainActivity extends BaseActivity implements View.OnClickListener, CommonInterface, OnBookletClickListener {

    //    private ImageView imgRice, imgCorn, imgMillet, imgMustard;
//    private ImageView imgRiceLib, imgCornLib, imgMilletLib, imgMustardLib;
    private Toolbar toolbar;
    private ImageView imgBack;
    private TextView txtTitle;
    private String crop;
    private RecyclerView gridView;
    private GridLayoutManager gridlayout;
    private CropDiagnosisGridAdapter adapter;
    private List<String> cropList = new ArrayList<>();
    //newly added
    private ImageView libImage;
    public Dialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emp_crop_diagnosis_activity);
        initializeViews();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        imgBack = findViewById(R.id.imgBacknav);
        imgBack.setVisibility(View.VISIBLE);
        txtTitle = findViewById(R.id.hedder_text);
        imgBack.setOnClickListener(this);
        txtTitle.setText(getString(R.string.cropDiagnosis));
        setSupportActionBar(toolbar);

        gridView = findViewById(R.id.recycle);
        gridlayout = new GridLayoutManager(CropDiagnosisMainActivity.this, 3);
        gridView.setHasFixedSize(true);
        gridView.setLayoutManager(gridlayout);
        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.margin7);
        gridView.addItemDecoration(new SpacesItemDecoration(spacingInPixels));
        //newly added
        libImage = findViewById(R.id.image1Lib);
        libImage.setOnClickListener(this);

        cropList.clear();
        cropList.add(AppConstants.RICE);
        cropList.add(AppConstants.MILLET);
        cropList.add(AppConstants.CORN);
        cropList.add(AppConstants.MUSTARD);
        cropList.add(AppConstants.SOYABEAN);
        cropList.add(AppConstants.CHILLI);
        cropList.add(AppConstants.COTTON);

        adapter = new CropDiagnosisGridAdapter(CropDiagnosisMainActivity.this, cropList, this);

        gridView.setAdapter(adapter);

//        imgRice = (ImageView) findViewById(R.id.image1);
//        imgCorn = (ImageView) findViewById(R.id.image2);
//        imgMillet = (ImageView) findViewById(R.id.image3);
//        imgMustard = (ImageView) findViewById(R.id.image4);
//
//        imgRiceLib = (ImageView) findViewById(R.id.image1Lib);
//        imgCornLib = (ImageView) findViewById(R.id.image2Lib);
//        imgMilletLib = (ImageView) findViewById(R.id.image3Lib);
//        imgMustardLib = (ImageView) findViewById(R.id.image4Lib);
//        setListeners();
    }

//    private void setListeners() {
//        imgRice.setOnClickListener(this);
//        imgCorn.setOnClickListener(this);
//        imgMustard.setOnClickListener(this);
//        imgMillet.setOnClickListener(this);
//
//        imgRiceLib.setOnClickListener(this);
//        imgCornLib.setOnClickListener(this);
//        imgMustardLib.setOnClickListener(this);
//        imgMilletLib.setOnClickListener(this);
//    }

    /*private void callDiseaseLibrary(String crop) {
        this.crop = crop;
        CropDiagnosticReq cropDiagnosticReq = new CropDiagnosticReq();
        cropDiagnosticReq.setCrop(crop);
        cropDiagnosticReq.setCustomerId(Utils.getUserId(CropDiagnosisMainActivity.this));
        cropDiagnosticReq.setMobileNumber(Utils.getUserMobile(CropDiagnosisMainActivity.this));

        //cropDiagnosticReq.setCrop(crop);
        APIRequestHandler.getInstance().uploadImage(cropDiagnosticReq, CropDiagnosisMainActivity.this, this, false);
    }*/

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null) {
            if (responseObj instanceof CommonResponseEntity) {
                CommonResponseEntity commonResEntity = (CommonResponseEntity) responseObj;
                if (AppConstants.RESP_CODE_INVALID_USER == commonResEntity.getRespCd()) {
                    logoutUser(CropDiagnosisMainActivity.this);
                } else if (AppConstants.RESP_CODE_SUCCESS == commonResEntity.getRespCd()) {
                    String st_commonResponse = Utils.getJWTResponse(commonResEntity.getData(), CropDiagnosisMainActivity.this);
                    Gson gson = new Gson();
                    CommonResponseEntity responseEntity = gson.fromJson(st_commonResponse, CommonResponseEntity.class);
                    if (AppConstants.STATUS_CODE_PRAVAKTA == responseEntity.getStatusCode()) {
                        String resJson = responseEntity.getResponse();
//                        String resJson = Utils.getJWTResponse(responseEntity.getResponse(), CropDiagnosisMainActivity.this);
                        CropDiseaseResponse response = new Gson().fromJson(resJson, CropDiseaseResponse.class);
                        if (response != null && response.getCropDiagnosisResponseDTO() != null && !response.getCropDiagnosisResponseDTO().isEmpty()) {
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(CropDiagnosticActivity.EXTRA_RESPONSE, response.getCropDiagnosisResponseDTO());
                            bundle.putBoolean(CropDiagnosticActivity.EXTRA_IS_LIBRARY, true);
                            bundle.putString(CropDiagnosticActivity.EXTRA_CROP, crop);
                            Intent intent = new Intent(CropDiagnosisMainActivity.this, CropDiagnosticActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        } else {
                            DialogManager.showToast(CropDiagnosisMainActivity.this, "Diseases not available ");
                        }
                    } else {
                        DialogManager.showToast(CropDiagnosisMainActivity.this, responseEntity.getMessage());
                    }
                } else {
                    DialogManager.showToast(CropDiagnosisMainActivity.this, commonResEntity.getRespMsg());
                }

            }
        }
    }

    private void moveToOflineLibActivity(String cropName) {

       /* mDataCache.setCdPestList(cropDiagnosisResponseDTO);
        mDataCache.setCdWeedList(cropDiagnosisResponseDTO);
        mDataCache.setCdDiseaseList(cropDiagnosisResponseDTO);*/

        Bundle bundle = new Bundle();
//        bundle.putSerializable(CropDiagnosisOfflineLibActvity.EXTRA_CROP_NAME, cropName);
        bundle.putString(CropDiagnosisOfflineLibActvity.EXTRA_CROP_NAME, cropName);
        Intent i = new Intent(CropDiagnosisMainActivity.this, CropDiagnosisOfflineLibActvity.class);
        i.putExtras(bundle);
        startActivity(i);
    }

    @Override
    public void onRequestFailure(RetrofitError errorCode, String errorFrom) {
        super.onRequestFailure(errorCode, errorFrom);
    }

    @Override
    public void onClick(View v) {
        Bundle bundle = new Bundle();
        switch (v.getId()) {

            case R.id.imgBacknav:
                finish();
                break;
            case R.id.image1Lib:
                showCropsListPopup();
                break;

            case R.id.popup_rice:
                moveToOflineLibActivity((String) v.getTag());
                mDialog.dismiss();
                break;
            case R.id.popup_millet:
                moveToOflineLibActivity((String) v.getTag());
                mDialog.dismiss();
                break;
            case R.id.popup_corn:
                moveToOflineLibActivity((String) v.getTag());
                mDialog.dismiss();
                break;
            case R.id.popup_mustard:
                moveToOflineLibActivity((String) v.getTag());
                mDialog.dismiss();
                break;

            case R.id.popup_soybean:
                moveToOflineLibActivity((String) v.getTag());
                mDialog.dismiss();
                break;
            case R.id.popup_chilli:
                moveToOflineLibActivity((String) v.getTag());
                mDialog.dismiss();
                break;
            case R.id.popup_cotton:
                moveToOflineLibActivity((String) v.getTag());
                mDialog.dismiss();
                break;


//            case R.id.image1:
//            case R.id.image2:
//            case R.id.image3:
//            case R.id.image4:
//                bundle.putString(CropDiagnosisHintActivity.EXTRA_CROP, (String) v.getTag());
//                Intent intent = new Intent(CropDiagnosisMainActivity.this, CropDiagnosisHintActivity.class);
//                intent.putExtras(bundle);
//                startActivity(intent);
//                break;
//            case R.id.image1Lib:
//            case R.id.image2Lib:
//            case R.id.image3Lib:
//            case R.id.image4Lib:
//                // newly added
//                String cropName = (String) v.getTag();
//                moveToOflineLibActivity(cropName);
//                /*if(Utils.isNetworkConnection(CropDiagnosisMainActivity.this))
//                    callDiseaseLibrary((String) v.getTag());*/
//                break;
        }

    }

    private void showCropsListPopup() {

        final Button cancelBtn;
        final TextView tvHeader, tvRice, tvMillet, tvCorn, tvMustard, tvSoybean, tvChilli, tvCotton;
        mDialog = getDialog(CropDiagnosisMainActivity.this, R.layout.popup_crops_textviews);
        mDialog.setCancelable(false);
        mDialog.setCanceledOnTouchOutside(false);

        tvHeader = mDialog.findViewById(R.id.popupHeader);
        tvRice = mDialog.findViewById(R.id.popup_rice);
        tvCorn = mDialog.findViewById(R.id.popup_corn);
        tvMillet = mDialog.findViewById(R.id.popup_millet);
        tvMustard = mDialog.findViewById(R.id.popup_mustard);
        tvSoybean = mDialog.findViewById(R.id.popup_soybean);
        tvChilli = mDialog.findViewById(R.id.popup_chilli);
        tvCotton = mDialog.findViewById(R.id.popup_cotton);

        cancelBtn = mDialog.findViewById(R.id.cancel_btn);

        tvHeader.setText(getString(R.string.select_crop));
        tvRice.setText(getString(R.string.rice));
        tvCorn.setText(getString(R.string.corn));
        tvMillet.setText(getString(R.string.millet));
        tvMustard.setText(getString(R.string.mustard));
        tvSoybean.setText(getString(R.string.soybean));
        tvChilli.setText(getString(R.string.chilli));
        tvCotton.setText(getString(R.string.cotton));

        tvRice.setOnClickListener(this);
        tvCorn.setOnClickListener(this);
        tvMillet.setOnClickListener(this);
        tvMustard.setOnClickListener(this);
        tvSoybean.setOnClickListener(this);
        tvChilli.setOnClickListener(this);
        tvCotton.setOnClickListener(this);

        tvRice.setTag(getString(R.string.rice));
        tvMillet.setTag(getString(R.string.millet));
        tvCorn.setTag(getString(R.string.corn));
        tvMustard.setTag(getString(R.string.mustard));
        tvSoybean.setTag(getString(R.string.soybean));
        tvChilli.setTag(getString(R.string.chilli));
        tvCotton.setTag(getString(R.string.cotton));


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        switch (view.getId()) {
            case R.id.fcdm_image1:
                if (Utils.isNetworkConnection(CropDiagnosisMainActivity.this)) {
                    String crop = cropList.get(position);
                    Bundle bundle = new Bundle();
                    bundle.putString(CropDiagnosisHintActivity.EXTRA_CROP, crop);
                    Intent intent = new Intent(CropDiagnosisMainActivity.this, CropDiagnosisHintActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                } else {
                    DialogManager.showToast(CropDiagnosisMainActivity.this, getString(R.string.internetRequired));
                }
                break;
        }
    }

    public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
        private int space;

        public SpacesItemDecoration(int space) {
            this.space = space;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view,
                                   RecyclerView parent, RecyclerView.State state) {
            outRect.left = space;
            outRect.right = space;
            outRect.bottom = space;

            // Add top margin only for the first item to avoid double space between items
            if (parent.getChildLayoutPosition(view) == 0) {
                outRect.top = space;
            } else {
                outRect.top = space;
            }
        }

    }

}
