package com.pioneer.emp.custommap;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import androidx.annotation.Nullable;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.app.ActivityCompat;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.pioneer.emp.R;
import com.pioneer.parivaar.fragments.BaseFragment;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;

/**
 * Created by Fatima on 09-01-2018.
 */

public class AddStoryLocSelectingFragment extends BaseFragment implements OnMapReadyCallback, GoogleMap.OnCameraChangeListener {

    private GoogleMap mMap;
    protected GoogleApiClient mGoogleApiClient;
    private LatLng mSelectedLatLng=new LatLng(0,0);
    private Double mSelectedLatitude;
    private Double mSelectedLongitude;
    private String mSelected_place;
    private int mZoomLevel;
//    AddStoryTagsFragment mTagsFragment;
    Bundle args=new Bundle();
    private Double currentlocationLatitude = 0.0;
    private Double currentlocationLongitude = 0.0;
    private boolean searchEnabled=false;
    private final float ZOOM_LEVEL = StringUtils.zoomLevelAddStory;
    private boolean isGeoCoding;
    private List<LatLng> geoLocations;
    private Geocoder geocoder;
    Snackbar connectionSnackBar;
    private static AddStoryLocSelectingFragment self;

    private static final String TAG = AddStoryLocSelectingFragment.class.getSimpleName();
//    OnLoLayoutClickListener onLoLayoutClickListener;

    private Views mViews;
    private View rootView = null;


    // final ActionBar actionBar = getSupportActionBar();

    static class Views extends BaseViews {

        /*@BindView(R.id.btn_next_add_story_loc)
        Button mBtnNext;

        @BindView(R.id.text_place_selected)
        TextView mTxtViewSelected;

        @BindView(R.id.layout_cur_loc)
        LinearLayout mLayoutCurrLoc;

        @BindView(R.id.layout_zoom_plus)
        LinearLayout mLytZoomPlus;

        @BindView(R.id.layout_zoom_minus)
        LinearLayout mLytZoomMinus;

        @BindView(R.id.loc_sel_loc_layout)
        RelativeLayout mlocLayout;*/

        @BindView(R.id.imgabove)
        ImageView mMarkerAbove;

        @BindView(R.id.imgpinn)
        ImageView mMarkerBelow;

        @BindView(R.id.imgclose)
        ImageView mImgClose;

        @BindView(R.id.imgdottedline_above)
        ImageView mDottedLineAbove;

        Views(View view) {
            super(view);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        self = this;
        if(rootView == null) {
            try {
                rootView = inflater.inflate(R.layout.fragement_addstory_loc_selecting, container, false);
                mViews = new Views(rootView);
                geoLocations = new ArrayList<LatLng>();
                geocoder = new Geocoder(getContext(), Locale.ENGLISH);
                setUpMapIfNeeded();
                //LatLng latLng = checkForSearchLocation();
                setUpClickListeners();
                connectionSnackBarInit();
            } catch (Exception e) {
                BuildLog.e(TAG, "Exception onCreateView : ", e);
            }
        }
        return rootView;

    }

    /*private LatLng checkForSearchLocation() {
        Bundle arguments = getArguments();
        BuildLog.e(TAG , " place search " +arguments + " "+arguments.getDouble(AddStoryActivity.LATITUDE) );
        LatLng newLoc=null;

        if (arguments != null) {
            Double latitude = arguments.getDouble(AddStoryActivity.LATITUDE);
            Double longitude = arguments.getDouble(AddStoryActivity.LONGITUDE);
            if (latitude != null && longitude != null) {
                BuildLog.d(TAG, "Showing location for location searched :" + latitude + " , " + longitude);
                currentlocationLatitude=latitude;
                currentlocationLongitude=longitude;
                searchEnabled=true;
                newLoc=new LatLng(currentlocationLatitude,currentlocationLongitude);
            }

        }
           return newLoc;

    }*/

    private void setUpClickListeners() {
        /*mViews.mlocLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLoLayoutClickListener.onLocLayoutClick();
            }
        });

        mViews.mBtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        performNextBtnClick();
                    }
                },StringUtils.CLICK_DELAY);

            }
        });
        mViews.mLayoutCurrLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getMyLocation();

            }
        });
        mViews.mLytZoomPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mMap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        });
        mViews.mLytZoomMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mMap.animateCamera(CameraUpdateFactory.zoomOut());

            }
        });*/

    }

    /*private void performNextBtnClick() {

//        BuildLog.d(TAG,"selected_placce"+mSelected_place);
        if(mSelected_place==null) {
            Toast.makeText(getContext(),getContext().getString(R.string.error_please_select_location),Toast.LENGTH_SHORT).show();
        }else
        {
            mTagsFragment = new AddStoryTagsFragment();
            addStoryRequestModel = AddStoryRequestModel.getInstance();
            addStoryRequestModel.setMap_place_name(mSelected_place);
            addStoryRequestModel.setLatitude(mSelectedLatitude.toString());
            addStoryRequestModel.setLongitude(mSelectedLongitude.toString());
            addStoryRequestModel.setUploaded_latitude(currentlocationLatitude.toString());
            addStoryRequestModel.setUploaded_longitude(currentlocationLongitude.toString());
            addStoryRequestModel.setName(mSelected_place);
            addStoryRequestModel.setZoom_level(mZoomLevel);
            navigateToTagsFragment();
        }
    }*/

/*    private void navigateToTagsFragment() {

       // ((AddStoryActivity) getContext()).getNavigationFragmentManager().addFragmentToBackStack(mTagsFragment);

        AddStoryLanguageFragment mLangFragment = new AddStoryLanguageFragment();
        ((BaseActionBarActivity) getContext()).getNavigationFragmentManager().addFragmentToBackStack(mLangFragment);

    }*/

    private void getMyLocation() {

        Location location = this.mMap.getMyLocation();
        if (location != null) {

            LatLng target = new LatLng(location.getLatitude(), location.getLongitude());
            CameraPosition position = this.mMap.getCameraPosition();
            CameraPosition.Builder builder = new CameraPosition.Builder();
            builder.zoom(ZOOM_LEVEL);
            builder.target(target);
            this.mMap.animateCamera(CameraUpdateFactory.newCameraPosition(builder.build()));
        }
    }

    public static Address getLocationDetails(LatLng latng, Geocoder geocoder, Context context ) {
        if (geocoder == null) {
            geocoder = new Geocoder(context, Locale.ENGLISH);
        }
        Address address = null;
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(latng.latitude, latng.longitude, 2);
            if (addresses != null) {
                address = addresses.get(0);
            }
        } catch (Exception e) {
            // CommonUtil.showLog("Exception : " + e);
        }
        return address;
    }



    private void setUpMapIfNeeded() {
        BuildLog.w(TAG,"Called setUpMapIfNeeded  : "+mMap );
        if (mMap == null) {
           // SupportMapFragment mapFragment = (SupportMapFragment)getChildFragmentManager().findFragmentById(R.id.map_add_stroy);

            // using custom map fragment
            CustomMapFragment customMapFragment=((CustomMapFragment)getChildFragmentManager().findFragmentById(R.id.map_add_stroy));


            customMapFragment.setOnActionDownListener(new CustomMapWrapperLayout.OnMapActionDown() {
                @Override
                public void onMapDown(MotionEvent motionEvent) {
                  /*  mViews.mMarkerBelow.setVisibility(View.INVISIBLE);
                    mViews.mMarkerAbove.setVisibility(View.VISIBLE);*/

                    BuildLog.d("Action","Action_down");
                }
            });

            customMapFragment.setOnDragListener(new CustomMapWrapperLayout.OnDragListener() {
                @Override
                public void onDrag(MotionEvent motionEvent) {
                    mViews.mMarkerBelow.setVisibility(View.INVISIBLE);
                    mViews.mMarkerAbove.setVisibility(View.VISIBLE);
                    mViews.mImgClose.setVisibility(View.VISIBLE);
                    mViews.mDottedLineAbove.setVisibility(View.VISIBLE);

                    BuildLog.d("Action","Action_drag");
                }
            });


            customMapFragment.setOnActionUpListener(new CustomMapWrapperLayout.OnMapActionUp() {
                @Override
                public void onMapUp(MotionEvent motionEvent) {
                    mViews.mMarkerBelow.setVisibility(View.VISIBLE);
                    mViews.mMarkerAbove.setVisibility(View.INVISIBLE);
                    mViews.mImgClose.setVisibility(View.INVISIBLE);
                    mViews.mDottedLineAbove.setVisibility(View.INVISIBLE);
                    BuildLog.d("Action","Action_Up");

                }
            });


            customMapFragment.getMapAsync(this);

        }
    }

    private void setUpMap() {
        BuildLog.w(TAG,"Here @ setUpMap");
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        } else {
            LatLng newLatLng = new LatLng(17.437560, 78.395197);
            setLocation(newLatLng);
        }

        this.mMap.setOnCameraChangeListener(this);
    }

    private void setLocation(final LatLng latlng) {
        try {
            CameraUpdate cameraUpdate;
            //mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            this.mMap.setMyLocationEnabled(true);
            final float maxZoomLevel = mMap.getMaxZoomLevel() > ZOOM_LEVEL ? ZOOM_LEVEL :  mMap.getMaxZoomLevel();
            if (latlng != null) {
                cameraUpdate = CameraUpdateFactory.newLatLngZoom(latlng, 14);
                mMap.moveCamera(cameraUpdate);

                Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        AddStoryLocSelectingFragment.this.getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latlng, maxZoomLevel);
                                mMap.animateCamera(cameraUpdate);
                            }
                        });
                    }
                }, 1000);
            }
        }catch (Exception e){
            BuildLog.d(TAG,"Error"+e);
        }



    }

    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        LatLng position = cameraPosition.target;

        mZoomLevel=(int)cameraPosition.zoom;
        getGeocode(position);




//Address address = getLocationDetails(position , null ,getActivity().getApplicationContext());
 //       LatLng selected_latlng = position;
//        String selected_place = getDisplayNameFromAddress(address);
//        mSelected_place=selected_place;
//        mSelectedLatLng=selected_latlng;
//        mSelectedLatitude=selected_latlng.latitude;
//        mSelectedLongitude=selected_latlng.longitude;
//        BuildLog.d(TAG,"location>>>"+selected_place);
//        mViews.mTxtViewSelected.setText(selected_place);

    }

    @Override
    public void onDestroyView(){
        super.onDestroyView();

        BuildLog.w(TAG,"HERE AT onDestroyView ---------------> ");

//        Fragment fragment = (getFragmentManager().findFragmentById(R.id.map));
//        FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
//        ft.remove(fragment);
//        ft.commit();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap=googleMap;
        mMap.setMyLocationEnabled(true);
        this.mMap.getUiSettings().setCompassEnabled(true);
        this.mMap.getUiSettings().setMyLocationButtonEnabled(false);
        setUpMap();

    }

    @Override
    public void onAttach(Activity activity) {

        super.onAttach(activity);
//        onLoLayoutClickListener=(OnLoLayoutClickListener) activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }


    /**
     * Use this factory method to create a new instance of
     * this fragment
     *
     * @return A new instance of fragment RegisterScreenFragment.
     */
    public static AddStoryLocSelectingFragment newInstance() {
        AddStoryLocSelectingFragment fragment = new AddStoryLocSelectingFragment();
        return fragment;
    }

    public static AddStoryLocSelectingFragment getInstance(){
        return self;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /*private void updateTitle() {
        ((BaseActionBarActivity) getActivity()).getSupportActionBar().setTitle(getResources().getString(R.string.title_loc_selecting_fragment));

    }*/
    public interface OnLoLayoutClickListener {
        void onLocLayoutClick();
    }

    public void showSnackBarBottom(boolean isOnline){
        if(!isOnline){
            connectionSnackBarInit();
           if(connectionSnackBar !=null) connectionSnackBar.show();
        }else{
            if(connectionSnackBar !=null) connectionSnackBar.dismiss();
            if(mMap!=null){
                LatLng position = mMap.getCameraPosition().target;
                mZoomLevel=(int)mMap.getCameraPosition().zoom;
                getGeocode(position);
            }
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(!Utils.isNetworkConnection(getContext())){
            if(connectionSnackBar !=null) connectionSnackBar.show();
        }
    }

    private void connectionSnackBarInit(){
        try{
            connectionSnackBar = Snackbar.make(getView(), getContext().getString(R.string.no_internet), Snackbar.LENGTH_INDEFINITE);
            View sbView = connectionSnackBar.getView();
            TextView textView = sbView.findViewById(R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
        }catch (Exception e){
            BuildLog.e(TAG, " Exception in connectionSnackBarInit : ",e);
        }
    }

    public void getGeocode(LatLng position){
        if(position==null)return;
        geoLocations.add(position);
        if(!isGeoCoding){
            BuildLog.d(TAG,"geocode requesting for address details !!");
            final LatLng geoLocation = geoLocations.get(geoLocations.size()- 1);
            geoLocations.clear();
            isGeoCoding = true;
            if(geocoder == null) geocoder = new Geocoder(getContext(), Locale.ENGLISH);
            new GeocodeHelper().execute( geocoder , geoLocation , new IGeocodeHandler() {
                @Override
                public void onGeocodeSuccess(Address address) {
                    isGeoCoding = false;
                    //String selected_place = CommonUtil.getDisplayNameFromAddress(address);

                    //mSelected_place = selected_place;
                    mSelectedLatLng = geoLocation;
                    mSelectedLatitude = geoLocation.latitude;
                    mSelectedLongitude = geoLocation.longitude;
                    //mViews.mTxtViewSelected.setText(selected_place);

                }
                @Override
                public void onGeocodeError(String message) {
                    isGeoCoding = false;
                    BuildLog.d(TAG,"onGeocodeError : ");
                }
            });
        }else{
            BuildLog.w(TAG,"Geocoding already in work , skipping !!");
        }
    }


}
