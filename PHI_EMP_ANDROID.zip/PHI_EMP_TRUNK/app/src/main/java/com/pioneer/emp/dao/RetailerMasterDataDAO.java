package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.DailyLiquidationTopTenRetailersVolumeDTO;
import com.pioneer.emp.models.TopTenRetailerModel;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

public class RetailerMasterDataDAO implements DAO {
    private final String TAG = "RetailerMasterDataDAO";
    private static RetailerMasterDataDAO retailerMasterDataDAO;

    public static RetailerMasterDataDAO getInstance() {
        if (retailerMasterDataDAO == null) {
            retailerMasterDataDAO = new RetailerMasterDataDAO();
        }
        return retailerMasterDataDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DailyLiquidationTopTenRetailersVolumeDTO dto = (DailyLiquidationTopTenRetailersVolumeDTO) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("retailerId", dto.getRetailerId());
            cv.put("retailerFirmName", dto.getRetailerFirmName());
            cv.put("retailerPINCode", dto.getRetailerPINCode());
            cv.put("retailerMobileNumber", dto.getRetailerMobileNumber());

            long rowsEffected = dbObject.insert(DBHandler.TABLE_DAILY_LIQUIDATION_RETAILER_MASTER, null, cv);
            if (rowsEffected > 0)
                return "inserted";

        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }

        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> competitorData = new ArrayList<>();
        Cursor cursor = null;
        try {
            // cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILER_MASTER, null);
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILER_MASTER + " ORDER BY retailerFirmName COLLATE NOCASE ASC", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DailyLiquidationTopTenRetailersVolumeDTO dto = new DailyLiquidationTopTenRetailersVolumeDTO();
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setRetailerFirmName(cursor.getString(cursor.getColumnIndex("retailerFirmName")));
                    dto.setRetailerPINCode(cursor.getString(cursor.getColumnIndex("retailerPINCode")));
                    dto.setRetailerMobileNumber(cursor.getString(cursor.getColumnIndex("retailerMobileNumber")));

                    competitorData.add(dto);
                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return competitorData;
    }

    public boolean deleteTableData(SQLiteDatabase db) {
        try {
            db.compileStatement("DELETE FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILER_MASTER).execute();
            return true;
        } catch (Exception e) {

        } finally {
            db.close();
        }
        return false;
    }

    //newly added
    public List<DailyLiquidationTopTenRetailersVolumeDTO> getRecordByMobile(String mobileNumber, SQLiteDatabase dbObject) {
        List<DailyLiquidationTopTenRetailersVolumeDTO> mobileNoData = new ArrayList<>();
        DailyLiquidationTopTenRetailersVolumeDTO dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILER_MASTER + " WHERE retailerMobileNumber = '" + mobileNumber + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new DailyLiquidationTopTenRetailersVolumeDTO();
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setRetailerFirmName(cursor.getString(cursor.getColumnIndex("retailerFirmName")));
                    dto.setRetailerPINCode(cursor.getString(cursor.getColumnIndex("retailerPINCode")));
                    dto.setRetailerMobileNumber(cursor.getString(cursor.getColumnIndex("retailerMobileNumber")));
                    mobileNoData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return mobileNoData;

    }
}
