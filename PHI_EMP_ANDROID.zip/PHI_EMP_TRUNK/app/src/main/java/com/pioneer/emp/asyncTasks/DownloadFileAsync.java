package com.pioneer.emp.asyncTasks;

import android.content.ContextWrapper;
import android.os.AsyncTask;

import com.pioneer.emp.fab.dto.DownloadFileDTO;
import com.pioneer.emp.listeners.AsyncCallback;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.Utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by rambabu.a on 07-07-2017.
 */

public class DownloadFileAsync extends AsyncTask<String, String, String> {

    private DownloadFileDTO downloadFileDTO;
    private AsyncCallback asyncCallback;
    private ContextWrapper contextWrapper;

    public DownloadFileAsync(ContextWrapper contextWrapper, DownloadFileDTO downloadFileDTO, AsyncCallback asyncCallback){
        this.contextWrapper = contextWrapper;
        this.downloadFileDTO = downloadFileDTO;
        this.asyncCallback = asyncCallback;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        return downloadFile(params);
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if (Utils.isValidStr(s)){
//            downloadFileDTO.setVoiceFileLocalPath(s);
            downloadFileDTO.setLocalURL(s);
            asyncCallback.onSuccess(downloadFileDTO);
        }else {
            asyncCallback.onFailure(downloadFileDTO);
        }
    }

    private String downloadFile(String... dwnload_file_path) {
        String response = "";
        try {
            String downloadFileUrl = dwnload_file_path[0];
            URL url = new URL(downloadFileUrl);
            HttpURLConnection urlConnection = (HttpURLConnection) url
                    .openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setDoOutput(true);
            urlConnection.connect();
            String extStorage = getFolderPath();
            File fileDir = new File(extStorage);
            if (!fileDir.exists())
                fileDir.mkdirs();
            File file = new File(fileDir, downloadFileUrl.substring(downloadFileUrl.lastIndexOf('/')+1));
            FileOutputStream fileOutput = new FileOutputStream(file);
            InputStream inputStream = urlConnection.getInputStream();
            byte[] buffer = new byte[10 * 1024];
            int bufferLength = 0;
            while ((bufferLength = inputStream.read(buffer)) != -1) {
                fileOutput.write(buffer, 0, bufferLength);
            }
            response = file.getAbsolutePath();
            fileOutput.flush(); // Written by TARA
            fileOutput.close();
            inputStream.close(); // Written by TARA
        } catch (MalformedURLException e) {
            BuildLog.d("Error", "MalformedURLException " + e);
            e.printStackTrace();
            response = null;
        } catch (IOException e) {
            BuildLog.d("Error", "IOException " + e);
            e.printStackTrace();
            response = null;
        } catch (Exception e) {
            BuildLog.d("Error", "Please check your internet connection " + e);
            e.printStackTrace();
            response = null;
        }
        return response;
    }

    private String getFolderPath() {
        String dirPath = contextWrapper.getFilesDir().getAbsolutePath();//Environment.getExternalStorageDirectory().toString();
        dirPath = dirPath + File.separator+"Files"+File.separator+"Emp_Crop_Advisory";
        dirPath = dirPath +File.separator+"Audio";

       /* if(AppConstants.IMAGE_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath + File.separator+"Images";
        } else if(AppConstants.VOICE_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath +File.separator+"Audio";
        } else if(AppConstants.VIDEO_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath + File.separator+"Videos";
        } else if(AppConstants.PDF_TYPE.equals(downloadFileDTO.getType())){
            dirPath = dirPath + File.separator+"PDFs";
        }*/
        return dirPath;
    }
}
