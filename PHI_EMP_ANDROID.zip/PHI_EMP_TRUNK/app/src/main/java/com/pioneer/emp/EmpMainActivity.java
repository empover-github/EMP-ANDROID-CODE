package com.pioneer.emp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.activitytrack.activity.ATMainActivity;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.utility.Utility;
import com.google.gson.Gson;
import com.pioneer.data.local.SessionManager;
import com.pioneer.emp.cropDiagnostic.CropDiagnosisMainActivity;
import com.pioneer.emp.cropDiagnostic.DiseaseResponseModel;
import com.pioneer.emp.dao.AgroDiseaseProductMappingDAO;
import com.pioneer.emp.dao.CropDiagnosisMasterDataUploadDAO;
import com.pioneer.emp.dao.DiseasePrescriptionDAO;
import com.pioneer.emp.dao.FawSightingDAO;
import com.pioneer.emp.dao.ImagesUploadDAO;
import com.pioneer.emp.dao.TblWeeklyLiqDAO;
import com.pioneer.emp.dao.UpLoadImagesDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.AgroDiseaseProductMappingDTO;
import com.pioneer.emp.dto.CropDiagnosisMasterDataUploadDTO;
import com.pioneer.emp.dto.DiseasePrescriptionDTO;
import com.pioneer.emp.dto.TBLWeeklyLiqDTO;
import com.pioneer.emp.dto.UploadImagesDTO;
import com.pioneer.emp.fab.FABMainActivity;
import com.pioneer.emp.fab.dao.DownloadingFileDAO;
import com.pioneer.emp.fab.dto.DownloadFileDTO;
import com.pioneer.emp.fab.services.DownloadFileService;
import com.pioneer.emp.fab.services.DownloadFileServiceNewJob;
import com.pioneer.emp.farmerDashboard.ui.FarmerDashboardMainActivity;
import com.pioneer.emp.fawSighting.FawRequestModel;
import com.pioneer.emp.fawSighting.FawSightingActivity;
import com.pioneer.emp.fawSighting.FawSightingReqModel;
import com.pioneer.emp.fawSighting.FawSightingSubmitRes;
import com.pioneer.emp.fragments.FragmentDrawer;
import com.pioneer.emp.fragments.HomeFragment;
import com.pioneer.emp.germination.GerminationActivity;
import com.pioneer.emp.germination.GerminationAgreementActivity;
import com.pioneer.emp.germination.GerminationMasterResponseModel;
import com.pioneer.emp.germination.GerminationSubscriptionListActivity;
import com.pioneer.emp.mandi.fragments.MandiPricesMainFragment;
import com.pioneer.emp.mandi.models.DiseaseSyncReq;
import com.pioneer.emp.mdrEvaluation.MdrEvaluationListActivity;
import com.pioneer.emp.mdrEvaluation.MdrReportsActivity;
import com.pioneer.emp.models.CropDiagnosisMasterDataUploadReuqest;
import com.pioneer.emp.models.CropDiagnosisMasterResponse;
import com.pioneer.emp.models.DataUploadResponse;
import com.pioneer.emp.models.FarmerAssistanceMobileNoResponse;
import com.pioneer.emp.models.FarmerAssistanceOTPDetailsResponse;
import com.pioneer.emp.models.FarmerAssistanceOtpResponse;
import com.pioneer.emp.models.FarmerAssistanceResponse;
import com.pioneer.emp.models.FarmerGerminationSchemeResponse;
import com.pioneer.emp.models.GenuinityCheckReq;
import com.pioneer.emp.models.IdServerIdModel;
import com.pioneer.emp.models.PravaktaAssistanceOtpModel;
import com.pioneer.emp.models.PravaktaAssistanceOtpResponse;
import com.pioneer.emp.models.PravakthaAssistanceModel;
import com.pioneer.emp.models.PravakthaAssistanceResponse;
import com.pioneer.emp.models.RegResEntity;
import com.pioneer.emp.models.SioAuthenticationRes;
import com.pioneer.emp.models.TblWeeklyLiqMasterMain;
import com.pioneer.emp.networkReceiver.NetworkChangeReceiver;
import com.pioneer.emp.retailerApprovals.RetailerApprovalListActivity;
import com.pioneer.emp.rootsDashboard.RootsDashboardActivity;
import com.pioneer.emp.services.CdMasterUpLoadFileService;
import com.pioneer.emp.services.CdMasterUpLoadFileServiceNewJob;
import com.pioneer.emp.services.ImageUpLoadFileService;
import com.pioneer.emp.services.ImageUploadFileServiceJob;
import com.pioneer.emp.weather.fragments.WeatherReportFragment;
import com.pioneer.emp.weeklyLiquidation.RBMWeeklyLiqListActivity;
import com.pioneer.emp.weeklyLiquidation.TBLWeeklyLiqActivity;
import com.pioneer.emp.weeklyLiquidation.TblSubmitWLReqModel;
import com.pioneer.emp.weeklyLiquidation.TblSubmitWLResModel;
import com.pioneer.emp.weeklyLiquidation.WLCropMasterDataDAO;
import com.pioneer.emp.weeklyLiquidation.WLHybridMasterDataDAO;
import com.pioneer.emp.weeklyLiquidation.WLSeasonMasterDataDAO;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.activities.MainActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.apiInterfaces.CommonInterface;
import com.pioneer.parivaar.fragments.BaseFragment;
import com.pioneer.parivaar.listeners.DialogMangerCallback;
import com.pioneer.parivaar.model.CommonResponse;
import com.pioneer.parivaar.model.IdNameModel;
import com.pioneer.parivaar.model.LoginModel;
import com.pioneer.parivaar.model.LoginResponse;
import com.pioneer.parivaar.model.RetailHybridIds;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;
import com.pioneer.ui.component.dashboard.DashboardActivity;
import com.pioneer.ui.component.splash.SplashActivity;
import com.uniqolabel.sdk.UniqolabelVerifier;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import retrofit.RetrofitError;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static com.pioneer.parivaar.utils.DialogManager.getDialog;

public class EmpMainActivity extends BaseActivity implements FragmentDrawer.FragmentDrawerListener, View.OnClickListener, CommonInterface {
    private final String TAG = "EmpMainActivity";

    private static final int REQUEST_LOCATION_FOR_WEATHER = 10000;
    private static final int REQ_STORAGE_CDI = 2001;
    private final int CALLING_FROM_MENU = 1000;
    private final int CALLING_FROM_BACK_PRESS = 1001;
//    private static String TAG = MainActivity.class.getSimpleName();

    private Toolbar mToolbar;
    private FragmentDrawer drawerFragment;
    /* A HashMap of stacks, where we use tab identifier as keys.. */
    public HashMap<String, Stack<BaseFragment>> mStacks;
    private String mCurrentMob;
    TextView lblTitleName;
    EditText edtSearch;
    BaseFragment fragment = null;
    BaseFragment mCurrentFragment = null;
    boolean isSearchOpend;
    private MenuItem mSearchAction;
    public static Menu mymenu;
    RelativeLayout rlCartIcon;
    RelativeLayout rlCartTotIcon;
    TextView lblCartItemCount;
    int cartCount = 0;
    //    public ArrayList<ProductInfoModel> allProductsList;
//    CartInfoModel responseCart;
    Dialog mDialog;

    private Button msubmitBtn, mcancelBtn, mOtpSubmit;
    private EditText mEditText, mOtpEdittext;
    private TextView tvHeader;
    private String stMobileNo;
    private String parvaktaAssistanceMobileNo;
    private String farmerAssistanceMobileNo;

    private NetworkChangeReceiver networkChangeReceiver;
    IntentFilter intentFilter;
    private EmpMainActivity thisActivity;

    private Context context;
    private boolean isFromGermination;

    private static final int GO_TO_REGISTER_PAGE_REQ = 123;
    public static final int MOVE_TO_GERMINATION_AGREEMENT_SCREEN_REQUEST = 5001;
    public static final int MOVE_TO_GERMINATION_SUBSCRIPTION_LIST_SCREEN_REQUEST = 5002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_main);
        thisActivity = this;
        context = this;

        mToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        intilizeToolBar();

        setStacks();

        drawerFragment = (FragmentDrawer) getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, findViewById(R.id.drawer_layout), mToolbar);
        drawerFragment.setDrawerListener(this);

        //creating object for oreo broadcaast Reciever
        networkChangeReceiver = new NetworkChangeReceiver();


        // display the first navigation drawer view on app launch
//        allProductsList = new ArrayList<>();
        displayView(1);
        //     Utils.getShowCropDiagnosis(thisActivity)
        if (Utils.isNetworkConnection(EmpMainActivity.this) && checkStoragePermission()) {
            callDiseaseRequest();
            callApiForCDMasterDataUpload();  // commented this for running again and agian in testing purpose
            callApiForFAWSightingUpload();
        } else if (!checkStoragePermission()) {
            requestForStoragePermission(REQ_STORAGE_CDI);
        }

        /*// below code is for WeeklyLiquidation. Commenting this because, not needed for this year.
        if (Utils.getDesignationName(EmpMainActivity.this).equals(AppConstants.USERTYPE_TERRITORY_BUSINESS_LEAD))
            callAPiForTBLWeeklyLiquiMasterData();*/
    }

    private void callApiForFAWSightingUpload() {
        ArrayList<FawSightingReqModel> FawUploadList = FawSightingDAO.getInstance().getRecordsForUpload(DBHandler.getReadableDb(EmpMainActivity.this));
        if (FawUploadList.size() > 0) {
            FawRequestModel request = new FawRequestModel();
            request.setMobileNumber(Utils.getUserMobile(thisActivity));
            request.setDeviceId(Utils.getDeviceId(thisActivity));
            request.setDeviceType(AppConstants.DEVICE_TYPE_ANDROID);
            request.setVersionNo(Utils.getAppVersionName(thisActivity));
            request.setFawSightingList(FawUploadList);
            String jwtToken = Utils.getJWTToken(new Gson().toJson(request), EmpMainActivity.this);
            APIRequestHandler.getInstance().submitFAWRecords(EmpMainActivity.this, jwtToken, this, false);
        } else {
            List<UploadImagesDTO> uploadFilesList = ImagesUploadDAO.getInstance().getRecordsToUpload(DBHandler.getReadableDb(this), this);
            if (uploadFilesList != null && uploadFilesList.size() > 0)
                startUploadImageService();
        }
    }


    /*@Override
    protected void onStart() {
        super.onStart();
        intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(networkChangeReceiver, intentFilter);
    }*/

    @Override
    protected void onResume() {

        intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(networkChangeReceiver, intentFilter);

        super.onResume();
    }

    @Override
    protected void onStop() {
        try {
            if (networkChangeReceiver != null)
                unregisterReceiver(networkChangeReceiver);
        } catch (Exception e) {
            Log.e("error", e.getMessage());
        }
        super.onStop();
    }

    public void callApiForCDMasterDataUpload() {
        ArrayList<CropDiagnosisMasterDataUploadDTO> uploadingList = CropDiagnosisMasterDataUploadDAO.getInstance().getALLRecords(DBHandler.getReadableDb(EmpMainActivity.this));
        if (uploadingList.size() > 0) {
            CropDiagnosisMasterDataUploadReuqest request = new CropDiagnosisMasterDataUploadReuqest();
            request.setCropDiseaseMasterList(uploadingList);
            String jwtToken = Utils.getJWTTokenFC(new Gson().toJson(request), EmpMainActivity.this);
            APIRequestHandler.getInstance().cropDiagnosisMasterDataUpload(jwtToken, EmpMainActivity.this, this, false);
        } else {
            List<UploadImagesDTO> uploadFilesList = UpLoadImagesDAO.getInstance().getRecordsToUpload(DBHandler.getReadableDb(this), this);
            if (uploadFilesList != null && uploadFilesList.size() > 0)
                startUploadService();
        }
    }

    private void callAPiForTBLWeeklyLiquiMasterData() {
        if (Utils.isNetworkConnection(EmpMainActivity.this) && Utils.getDesignationName(EmpMainActivity.this).equalsIgnoreCase(AppConstants.DES_TBL)) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("mobileNumber", Utils.getUserMobile(EmpMainActivity.this));
//                jsonObject.put("mobileNumber",AppConstants.Tbl_static_mobile_number);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            String jwtToken = Utils.getJWTToken(jsonObject.toString(), EmpMainActivity.this);
            APIRequestHandler.getInstance().getEncodedFCBridgeForWeeklyLiquidation(EmpMainActivity.this, jwtToken, this, false);
            ArrayList<TBLWeeklyLiqDTO> submitList = TblWeeklyLiqDAO.getInstance().getAllRecords(DBHandler.getReadableDb(EmpMainActivity.this));
            TblSubmitWLReqModel submitModel = new TblSubmitWLReqModel();
            submitModel.setMobileNumber(Utils.getUserMobile(EmpMainActivity.this));
//            submitModel.setMobileNumber(AppConstants.Tbl_static_mobile_number);
            submitModel.setLastUpdatedTime(Utils.getTblLastSubmittedTime(EmpMainActivity.this));
            submitModel.setLiquidationActualsDTOList(submitList);
            APIRequestHandler.getInstance().bridgeForSubmitWeeklyLiquidationByTbl(EmpMainActivity.this, submitModel, this, false);
        }
    }

    private void callDiseaseRequest() {
        if (Utils.isNetworkConnection(this)) {
            DiseaseSyncReq req1 = new DiseaseSyncReq(Utils.getProductsSyncTime(EmpMainActivity.this));
            APIRequestHandler.getInstance().getDiseaseRequest(EmpMainActivity.this, req1, this);
        } else {
            DialogManager.showToast(EmpMainActivity.this, getString(R.string.no_internet));
        }
    }

    private boolean checkStoragePermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return ActivityCompat.checkSelfPermission(EmpMainActivity.this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

        } else {
            return true;
        }
    }

    private void requestForStoragePermission(final int reqCode) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(EmpMainActivity.this, WRITE_EXTERNAL_STORAGE)) {

            // Show an explanation to the user *asynchronously* -- don't block
            // this thread waiting for the user's response! After the user
            // sees the explanation, try again to request the permission.
            DialogManager.showSingleBtnPopup(EmpMainActivity.this, new DialogMangerCallback() {
                @Override
                public void onOkClick(View view) {
                    ActivityCompat.requestPermissions(EmpMainActivity.this,
                            new String[]{WRITE_EXTERNAL_STORAGE},
                            reqCode);
                }

                @Override
                public void onCancelClick(View view) {

                }
            }, getString(R.string.app_name), getString(R.string.storage_permission_msg), getString(R.string.ok));
        } else {

            // No explanation needed, we can request the permission.

            ActivityCompat.requestPermissions(EmpMainActivity.this,
                    new String[]{WRITE_EXTERNAL_STORAGE},
                    reqCode);

            // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
            // app-defined int constant. The callback method gets the
            // result of the request.
        }
    }

    private void setStacks() {
        mStacks = new HashMap<String, Stack<BaseFragment>>();

        mStacks.put(AppConstants.MOB_HOME, new Stack<BaseFragment>());
        mStacks.put(AppConstants.EMP_MANDI_PRICES, new Stack<BaseFragment>());
        mStacks.put(AppConstants.EMP_WEATHER_REPORT, new Stack<BaseFragment>());

    }

    private void intilizeToolBar() {
        lblTitleName = findViewById(R.id.hedder_text);
        lblTitleName.setVisibility(View.VISIBLE);
        edtSearch = findViewById(R.id.edtSearch);
        rlCartIcon = findViewById(R.id.llCartIcon);
        edtSearch.setVisibility(View.GONE);
        edtSearch.addTextChangedListener(searchTextChangeListener);

    }


    @Override
    public void onDrawerItemSelected(View view, int position) {
        displayView(position);
        disableSearch();
    }
//
//    public String loadJSONFromAsset(Context context) {
//        String json = null;
//        try {
//            InputStream is = context.getAssets().open("requestData.json");
//            int size = is.available();
//            byte[] buffer = new byte[size];
//            is.read(buffer);
//            is.close();
//            json = new String(buffer, "UTF-8");
//        } catch (IOException ex) {
//            ex.printStackTrace();
//            return null;
//        }
//        return json;
//    }
//
//


    public void displayView(int position) {

        String title = getString(R.string.app_name);
        Bundle bInfo = new Bundle();

        switch (position) {
            case 1:
                // All Fragment
                mCurrentMob = AppConstants.MOB_HOME;
                mStacks.get(mCurrentMob).clear();
               /* fragment = new AllFragment();
                title = AppConstants.ALL;*/
//                getAllPriceList();
                fragment = new HomeFragment();
                break;
            case 2:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    DialogManager.openEmpAssistDialog(EmpMainActivity.this, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            // Make Api Call to Confirm or get Details of Retailer
                            stMobileNo = DialogManager.stMobileNo;
                            APIRequestHandler.getInstance().getRetailerInfo(stMobileNo, EmpMainActivity.this);
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, AppConstants.EMP_RETAILER_ASSIST, getString(R.string.submit));
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                }
                break;
            case 3:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    DialogManager.openEmpAssistDialog(EmpMainActivity.this, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            // Make Api Call to Confirm or get Details of Pravakta
                            stMobileNo = DialogManager.stMobileNo;
                            APIRequestHandler.getInstance().getPravaktaAssistanceMobileNoResponse(EmpMainActivity.this, stMobileNo, EmpMainActivity.this);

                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, AppConstants.EMP_PRAVAKTA_ASSIST, getString(R.string.submit));
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                }
                /*  Intent booklet_intent = new Intent(this, CouponBookletActivity.class);
                startActivity(booklet_intent);*/
                break;
            case 4:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    DialogManager.openEmpAssistDialog(EmpMainActivity.this, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            // Make Api Call to Confirm or get Details of Farmer
                            stMobileNo = DialogManager.stMobileNo;
                            APIRequestHandler.getInstance().getFramerAssistanceMobileNoResponse(EmpMainActivity.this, stMobileNo, EmpMainActivity.this);
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, AppConstants.EMP_FARMER_ASSIST, getString(R.string.submit));
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                }
                break;
            case 5:
                fragment = null;
                Intent gotoFAB = new Intent(EmpMainActivity.this, FABMainActivity.class);
                startActivity(gotoFAB);
                /* String jsonDataStr = loadJSONFromAsset(EmpMainActivity.this);
                Utils.getJWTToken(jsonDataStr,EmpMainActivity.this);*/
                break;
            case 6:
                fragment = null;
                Intent gotoVolActivity = new Intent(EmpMainActivity.this, EmpVolumePlanner.class);
                startActivity(gotoVolActivity);
                break;
            case 7:
                fragment = null;
                Intent gotoCropAdvisory = new Intent(EmpMainActivity.this, CropAdvisoryActivity.class);
                startActivity(gotoCropAdvisory);
                break;
            case 8:
                fragment = null;
                if (Utils.isNetworkConnection(getApplicationContext())) {
                    if (checkLocPermission()) {
                        mCurrentMob = AppConstants.EMP_WEATHER_REPORT;
                        mStacks.get(mCurrentMob).clear();
                        fragment = new WeatherReportFragment();
                        title = AppConstants.EMP_WEATHER_REPORT;
                    } else {
                        requestForLocPermission(REQUEST_LOCATION_FOR_WEATHER);
                        return;
                    }
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
                    return;
                }
                break;

            case 9:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    mCurrentMob = AppConstants.EMP_MANDI_PRICES;
                    mStacks.get(mCurrentMob).clear();
                    title = AppConstants.EMP_MANDI_PRICES;
                    fragment = new MandiPricesMainFragment();
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("userType", AppConstants.USER_TYPE_EMPLOYEE);
                        jsonObject.put("mobileNumber", Utils.getUserMobile(EmpMainActivity.this));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    String jwtToken = Utils.getJWTToken(jsonObject.toString(), EmpMainActivity.this);
                    APIRequestHandler.getInstance().getMandiAnalyticResponse(jwtToken, EmpMainActivity.this);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                }
                break;
            /*case 20:
                fragment = null;
                mStacks.get(mCurrentMob).clear();
                DialogManager.showToast(EmpMainActivity.this, getString(R.string.privacyPolicy));

                Intent gotoEmpHome = new Intent(this, EmpHomeActivity.class);
                startActivity(gotoEmpHome);
                break;*/
            case 10:
                fragment = null;

                if (Utility.isDataPending(EmpMainActivity.this)) {
                    String message = getString(R.string.logoutATMsg);
                    DialogManager.showSingleBtnPopup(EmpMainActivity.this, null, getString(R.string.alert), message, getString(R.string.ok));
                } else {
                    DialogManager.showConformPopup(EmpMainActivity.this, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            APIRequestHandler.getInstance().getLogout(EmpMainActivity.this, EmpMainActivity.this);
                            //Dummy
                            // Add AT logout msg and clear AT data also
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, "Alert!", getString(R.string.logoutMsg), getString(R.string.yes), getString(R.string.no));
                }
                break;
            case 11:
                fragment = null;
                Intent gotoCropDiagnosis = new Intent(EmpMainActivity.this, CropDiagnosisMainActivity.class);
                startActivity(gotoCropDiagnosis);
                break;
            case 12:
                fragment = null;
                Intent activityTackerIntent = null;
                // for putting trigger removed below code
                if (AppConstants.DES_MDR.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
                    if (!MdrMasterDAO.getInstance().isDataAvailable(com.activitytrack.database.DBHandler.getInstance(EmpMainActivity.this).getDBObject(0))) {
                        //Check network
                        if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                            activityTackerIntent = new Intent(EmpMainActivity.this, com.activitytrack.activity.OTPActivity.class);
                        } else {
                            DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                            return;
                        }
                    } else {
                        activityTackerIntent = new Intent(EmpMainActivity.this, ATMainActivity.class);
                    }
                } else {
                    if (Utils.isNetworkConnection(EmpMainActivity.this)) {
//                            activityTackerIntent = new Intent(EmpMainActivity.this, MdrDGDashboardActivity.class);
                        activityTackerIntent = new Intent(EmpMainActivity.this, EmpActivityTracker.class);
                    } else if (AppConstants.DES_TBL.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
                        activityTackerIntent = new Intent(EmpMainActivity.this, EmpActivityTracker.class);
                    } else {
                        DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
                        return;
                    }
                }

                Bundle bundle = new Bundle();
                bundle.putString("loginId", Utils.getLoginId(EmpMainActivity.this));
                bundle.putString("mobileNumber", Utils.getUserMobile(EmpMainActivity.this));
                bundle.putString("versionNo", AppConstants.USERTYPE_EMP + "_" + Utils.getAppVersionName(EmpMainActivity.this));
                activityTackerIntent.putExtras(bundle);
                startActivity(activityTackerIntent);
                break;
            case 13:
                fragment = null;
                Intent bigFarmerIntent = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    bigFarmerIntent = new Intent(EmpMainActivity.this, BigFarmerActivity.class);
                    startActivity(bigFarmerIntent);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                }
                break;
            case 14:
                fragment = null;
                Intent phiIntent = new Intent(EmpMainActivity.this, RetailAuditActivity.class);
                startActivity(phiIntent);
                break;
            case 15:
                fragment = null;
                Intent weeklyLiquidation = null;
                if (AppConstants.DES_TBL.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
                    weeklyLiquidation = new Intent(EmpMainActivity.this, TBLWeeklyLiqActivity.class);
                } else if (AppConstants.DES_RBM.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
                    weeklyLiquidation = new Intent(EmpMainActivity.this, RBMWeeklyLiqListActivity.class);
                }
                startActivity(weeklyLiquidation);
                break;
            case 16:

                fragment = null;
                openGenuinityCheck();
                break;

            case 17:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    Intent gotoApprovalList = new Intent(EmpMainActivity.this, RetailerApprovalListActivity.class);
                    startActivity(gotoApprovalList);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
                }
                break;

            case 18:
                fragment = null;
                Intent gotoCDI = new Intent(EmpMainActivity.this, CropDiasnosisMasterDataCreationActivity.class);
                startActivity(gotoCDI);
                break;

            case 19:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {

                    SessionManager mSession = SessionManager.getInstance(EmpMainActivity.this);
                    if (mSession.isUserLoggedIn()) {
                        DashboardActivity.openDashBoardActivity(EmpMainActivity.this);
                    } else {
                        Intent gotoSoilHealth = new Intent(EmpMainActivity.this, SplashActivity.class);
                        Bundle soilBundle = new Bundle();
                        soilBundle.putString("userid", Utils.getUserId(EmpMainActivity.this));
                        soilBundle.putString("mobile_no", Utils.getUserMobile(EmpMainActivity.this));
                        soilBundle.putString("loginId", Utils.getLoginId(EmpMainActivity.this));
                        soilBundle.putString("userType", Utils.getUserType(EmpMainActivity.this));
                        gotoSoilHealth.putExtras(soilBundle);
                        startActivity(gotoSoilHealth);
                    }
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
                }
                break;
            case 20:
                fragment = null;
                showTextListPopup();
                break;


            case 21:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    if (AppConstants.DES_TBL.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
                        Intent gotoMdrEvaluation = new Intent(EmpMainActivity.this, MdrEvaluationListActivity.class);
                        startActivity(gotoMdrEvaluation);
                    } else {
                        Intent gotoMdrEvaluation = new Intent(EmpMainActivity.this, MdrReportsActivity.class);
                        startActivity(gotoMdrEvaluation);
                    }
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
                }
                break;
            case 22:
                // check here master data is there or not. if not don't move
                fragment = null;
                Intent gotoFawSighting = new Intent(EmpMainActivity.this, FawSightingActivity.class);
                startActivity(gotoFawSighting);
                break;
            case 23:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    Intent intent = new Intent(EmpMainActivity.this, RootsDashboardActivity.class);
                    //Intent intent=new Intent(EmpMainActivity.this, RootsDashboardActivity.class);
                    startActivity(intent);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
                }
                break;
            case 24:
                //This case is for Farmer DashBoard
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    logClickEvent();
                    Intent intent = new Intent(EmpMainActivity.this, FarmerDashboardMainActivity.class);
                    startActivity(intent);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
                }
                break;
            case 25:
                /*// call API for authentication purpose. On success of response navigate to SIO module
                fragment = null;
                callApiToAuthenticateCpUser();*/
                break;
            case 26:
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    DialogManager.openEmpAssistDialog(EmpMainActivity.this, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            // Make Api Call to Confirm or get Details of Farmer
                            stMobileNo = DialogManager.stMobileNo;
                            fDataCache.setMobileNo(stMobileNo);
                            if (Utils.isValidStr(stMobileNo)) {
                                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                                    APIRequestHandler.getInstance().getFarmerGerminationSchemeResponse(EmpMainActivity.this, stMobileNo, EmpMainActivity.this);
                                } else {
                                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.no_internet));
                                }
//                                callApiGerminationScheme(stMobileNo);
                            }
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, AppConstants.EMP_GERMINATION_SCEME, getString(R.string.submit));
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                }
                break;
            case 27:
//                DialogManager.showToast(thisActivity,getString(R.string.germination_claim));
                fragment = null;
                if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                    DialogManager.openEmpAssistDialog(EmpMainActivity.this, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            // Make Api Call to Confirm or get Details of Farmer
                            stMobileNo = DialogManager.stMobileNo;
                            fDataCache.setMobileNo(stMobileNo);
                            Intent gotoClaims = new Intent(thisActivity, GerminationActivity.class);
                            startActivity(gotoClaims);

//                            APIRequestHandler.getInstance().getGerminationScemeMobileNoResponse(EmpMainActivity.this, stMobileNo, EmpMainActivity.this);
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, AppConstants.EMP_GERMINATION_CLAIM, getString(R.string.submit));
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequiredfirsttime));
                }
                break;
            case 200:
                popFragments();
                break;
            case 100:
                mCurrentMob = AppConstants.MOB_HOME;
                mStacks.get(mCurrentMob).clear();
               /* fragment = new AllFragment();
                title = getString(R.string.all);*/
//                DialogManager.showToast(EmpMainActivity.this, "case 100");
                break;
            case 300:
                //Implement Logout information hear.
//                APIRequestHandler.getInstance().logout("", this);
//                DialogManager.showToast(EmpMainActivity.this, "case 300");
                break;
            default:
                break;
        }

        if (fragment != null) {
            if (mCurrentMob.equals(AppConstants.MOB_HOME)) {
                bInfo.putString(AppConstants.FRAG_TYPE, title);
                fragment.setArguments(bInfo);
            }
            fragment.setArguments(bInfo);

            pushFragments(mCurrentMob, fragment, false, true);
        }
        rlCartIcon.setVisibility(View.GONE);
        setTitle(title);
    }

    private void logClickEvent() {
        Bundle analyticsBundle = new Bundle();
        analyticsBundle.putString("User_Id", Utils.getUserId(context));
        analyticsBundle.putString("Mobile_Number", Utils.getUserMobile(context));
        analyticsBundle.putString(AppConstants.Firebase_Screen_Name, AppConstants.EMP_MAIN_SCREEN);
        mFirebaseAnalytics.setUserProperty("designation", Utils.getDesignationName(getApplicationContext()));
        mFirebaseAnalytics.logEvent("Main_FD_Icon_Click", analyticsBundle);
    }

    private void callApiToAuthenticateCpUser() {
        if (Utils.isNetworkConnection(thisActivity)) {
            Map<String, String> params = new HashMap<>();
            try {
                params.put("UserName", Utils.getUserMobile(thisActivity));
                params.put("Password", Utils.getCpPassword(thisActivity));
            } catch (Exception e) {
                e.printStackTrace();
            }
            APIRequestHandler.getInstance().authenticateSio(params, thisActivity, this);
        } else {
            DialogManager.showToast(thisActivity, getString(R.string.no_internet));
        }
    }

    private boolean checkLocPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return ActivityCompat.checkSelfPermission(EmpMainActivity.this, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return true;
        }
    }

    private void requestForLocPermission(final int reqCode) {
        // Should we show an explanation?
        if (ActivityCompat.shouldShowRequestPermissionRationale(EmpMainActivity.this, ACCESS_FINE_LOCATION)) {

            // Show an explanation to the user *asynchronously* -- don't block
            // this thread waiting for the user's response! After the user
            // sees the explanation, try again to request the permission.
            DialogManager.showSingleBtnPopup(EmpMainActivity.this, new DialogMangerCallback() {
                @Override
                public void onOkClick(View v) {
                    ActivityCompat.requestPermissions(EmpMainActivity.this,
                            new String[]{ACCESS_FINE_LOCATION},
                            reqCode);
                }

                @Override
                public void onCancelClick(View view) {

                }
            }, getString(R.string.app_name), getString(R.string.locationPermissionMsg), getString(R.string.ok));
        } else {

            // No explanation needed, we can request the permission.

            ActivityCompat.requestPermissions(EmpMainActivity.this,
                    new String[]{ACCESS_FINE_LOCATION},
                    reqCode);

            // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
            // app-defined int constant. The callback method gets the
            // result of the request.
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_LOCATION_FOR_WEATHER:
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                    displayView(8);

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.noAccessToWeather));
                }
                break;
            case REQ_STORAGE_CDI:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (Utils.isNetworkConnection(EmpMainActivity.this))
                        callDiseaseRequest();
                } else {
                    DialogManager.showToast(EmpMainActivity.this, getString(R.string.storage_permission_denied));
                }
                break;

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    public void setTitle(CharSequence title) {
        lblTitleName.setText(title);
    }

    /*private ArrayList<ProductInfoModel> getFilterItems(String title, ArrayList<ProductInfoModel> allProductsList) {
        String changeTxt = title.toLowerCase();
        final ArrayList<ProductInfoModel> allAddrsList = new ArrayList<>();
        if (changeTxt.equalsIgnoreCase(AppConstants.ALL)) {
            return allProductsList;
        } else {
            for (ProductInfoModel model : allProductsList) {
                String prodName = model.getProductTypeName().toLowerCase();
                if (prodName.equals(changeTxt)) {
                    allAddrsList.add(model);
                }
            }
        }
        return allAddrsList;
    }*/

    /*public void navigateToProfile() {
        Intent myProfile = new Intent(getApplicationContext(), MyProfileActivity.class);
        myProfile.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(myProfile);

    }*/

    public void pushFragments(String tag, BaseFragment fragment,
                              boolean shouldAnimate, boolean shouldAdd) {
        if (shouldAdd)
            mStacks.get(tag).push(fragment);
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        /*
         * if(shouldAnimate) ft.setCustomAnimations(R.anim.slide_in_right,
         * R.anim.slide_out_left);
         */
        ft.replace(R.id.container_body, fragment);
        mCurrentFragment = fragment;
        try {
            ft.commitAllowingStateLoss();
//            ft.commit();
        } catch (Exception e) {
        }
    }


    public void popFragments() {
        /*
         * Select the second last fragment in current tab's stack.. which will
         * be shown after the fragment transaction given below
         */
        Fragment fragment = mStacks.get(mCurrentMob).elementAt(
                mStacks.get(mCurrentMob).size() - 2);

        /* pop current fragment from stack.. */
        mStacks.get(mCurrentMob).pop();

        /*
         * We have the target fragment in hand.. Just show it.. Show a standard
         * navigation animation
         */
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        // ft.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right);
        ft.replace(R.id.container_body, fragment);
        ft.commit();
    }

    @Override
    public void onBackPressed() {
        boolean temp = true;

        if (temp) {
            temp = false;
            if (drawerFragment.isDrawerOpen(Gravity.LEFT)) {
                drawerFragment.closeDrawer(Gravity.LEFT);
                return;
            }
            /*
             * top fragment in current tab doesn't handles back press,
             * we can do our thing, which is
             *
             * if current tab has only one fragment in stack, ie first
             * fragment is showing for this tab. finish the activity
             * else pop to previous fragment in stack for the same tab
             */

            if (mStacks.get(mCurrentMob).size() == 1) {
                if (mCurrentMob.equals(AppConstants.MOB_HOME)) {
                    alertDialog();
                } else {
                    int stackSize = mStacks.get(mCurrentMob).size();
                    BaseFragment fragment = mStacks.get(mCurrentMob).get(stackSize - 1);
                    //fragment.onBackPressed();
                    if (fragment.onBackPressed())
                        displayView(1);
                }
                /*
                 * if (trackingButtonTextStatus.equals("STOP TRACKING"))
                 * { } else {
                 */
                // super.onBackPressed(); // or call finish..
                // alertDialog();
                // }
            } else {
                int stackSize = mStacks.get(mCurrentMob).size();
                BaseFragment fragment = mStacks.get(mCurrentMob).get(stackSize - 1);
//						if(fragment.onBackPressed())
//							popFragments();
                fragment.onBackPressed();
            }

            if (mStacks.get(mCurrentMob).size() == 1) {
                if (mCurrentMob.equals(AppConstants.MOB_HOME)) {
                    //alertDialog();
                } else {
                    int stackSize = mStacks.get(mCurrentMob).size();
                    BaseFragment fragment = mStacks.get(mCurrentMob).get(stackSize - 1);
                    fragment.onBackPressed();
//							if(fragment.onBackPressed())
//								displayView(10);
                }
                /*
                 * if (trackingButtonTextStatus.equals("STOP TRACKING"))
                 * { } else {
                 */
                // super.onBackPressed(); // or call finish..
                // alertDialog();
                // }
            } else {
                int stackSize = mStacks.get(mCurrentMob).size();
                BaseFragment fragment = mStacks.get(mCurrentMob).get(stackSize - 1);
//						if(fragment.onBackPressed())
//							popFragments();
                fragment.onBackPressed();
            }
        } else {
            // do nothing.. fragment already handled back button press.
        }
        /*
         * top fragment in current tab doesn't handles back press,
         * we can do our thing, which is
         *
         * if current tab has only one fragment in stack, ie first
         * fragment is showing for this tab. finish the activity
         * else pop to previous fragment in stack for the same tab
         */


        /*temp = true;
        if (isSearchOpend) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(edtSearch.getWindowToken(), 0);

            edtSearch.setVisibility(View.GONE);
            //add the search icon in the action bar
            mSearchAction.setIcon(getResources().getDrawable(R.mipmap.ic_menu_search));

            fragment.doSearch("");
            fragment.elasticSearch("");

            isSearchOpend = false;
        } else {
//            finish();
        }*/

    }

    private void showTextListPopup() {

        final Button cancelBtn;
        final TextView tvHeader, tvCalendar, tvReports, last_twodays_reports;
        View view_one, view_two;
        Dialog mDialog = getDialog(EmpMainActivity.this, R.layout.popup_two_textviews);
        mDialog.setCancelable(false);
        mDialog.setCanceledOnTouchOutside(false);

        tvHeader = mDialog.findViewById(R.id.popupHeader);
        tvCalendar = mDialog.findViewById(R.id.pupup_text_one);
        tvReports = mDialog.findViewById(R.id.pupup_text_two);
        view_one = mDialog.findViewById(R.id.view_one);
        view_two = mDialog.findViewById(R.id.view_two);
        last_twodays_reports = mDialog.findViewById(R.id.popup_text_three);
        cancelBtn = mDialog.findViewById(R.id.cancel_btn);

        tvHeader.setText(getString(R.string.daily_liquidation));
        tvReports.setText(getString(R.string.reports_dialog));
        if (AppConstants.DES_TBL.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
            tvCalendar.setText(getString(R.string.calendar_dialog));
            view_two.setVisibility(View.GONE);
            last_twodays_reports.setVisibility(View.GONE);
        } else if (AppConstants.DES_RBM.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
            tvCalendar.setText(getString(R.string.calendar_dialog));
            view_two.setVisibility(View.VISIBLE);
            last_twodays_reports.setVisibility(View.VISIBLE);
            last_twodays_reports.setText(R.string.last_two_days_liquidation);
        } else {

            tvCalendar.setVisibility(View.GONE);
            view_one.setVisibility(View.GONE);

            view_two.setVisibility(View.VISIBLE);
            last_twodays_reports.setVisibility(View.VISIBLE);
            last_twodays_reports.setText(R.string.last_two_days_liquidation);
        }


        tvCalendar.setOnClickListener(view -> {
            Intent dailyLiquidation = null;

            if (AppConstants.DES_TBL.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
                dailyLiquidation = new Intent(EmpMainActivity.this, TblDailyLiquidationActivity.class);
            } else if (AppConstants.DES_RBM.equalsIgnoreCase(Utils.getDesignationName(EmpMainActivity.this))) {
                dailyLiquidation = new Intent(EmpMainActivity.this, DailyLiquidationActivity.class);
            }
            if (dailyLiquidation != null)
                startActivity(dailyLiquidation);
            mDialog.dismiss();
        });
        tvReports.setOnClickListener(view -> {
            if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                Intent in = new Intent(EmpMainActivity.this, LiquidationTrendActivity.class);
                startActivity(in);
            } else {
                DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
            }
            mDialog.dismiss();
        });

        last_twodays_reports.setOnClickListener(view -> {
            if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                Intent in = new Intent(EmpMainActivity.this, LastTwoDaysLiquidationActivity.class);
                startActivity(in);
            } else {
                DialogManager.showToast(EmpMainActivity.this, getString(R.string.internetRequired));
            }
            mDialog.dismiss();

        });

        cancelBtn.setOnClickListener(v -> mDialog.dismiss());
        mDialog.show();
    }


    private void alertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Alert");
        builder.setMessage("Are you sure you want to exit?")
                .setCancelable(false)
                .setPositiveButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                })
                .setNegativeButton("Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                setResult(RESULT_OK);
                                finish();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        mymenu = menu;
        /*if(isFirstTime) {
            isFirstTime=false;
            viewPager.setCurrentItem(1);
            setOptionMenu(1);

        }*/
       /* mSearchAction = menu.findItem(R.id.action_search);
        MenuItem cartMenu = menu.findItem(R.id.action_cart);*/
        if (mCurrentMob == null) {
            mCurrentMob = AppConstants.MOB_HOME;
        }
        if (mymenu != null) {
            if (mCurrentMob.equals(AppConstants.MOB_HOME) || mCurrentMob.equals(AppConstants.MOB_MILLET) || mCurrentMob.equals(AppConstants.MOB_RICE) || mCurrentMob.equals(AppConstants.MOB_CORN) || mCurrentMob.equals(AppConstants.MOB_MUSTAD)) {
//                cartMenu.setVisible(true);
//                mSearchAction.setVisible(true);
            } else {
//                cartMenu.setVisible(false);
//                mSearchAction.setVisible(false);
            }
        }

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.emp_menu_main, menu);
        MenuItem cartItem = menu.findItem(R.id.action_cart);
        MenuItemCompat.setActionView(cartItem, R.layout.emp_custom_cart_count);
        rlCartTotIcon = (RelativeLayout) MenuItemCompat.getActionView(cartItem);
        lblCartItemCount = rlCartTotIcon.findViewById(R.id.lblNotifCount);

        if (cartCount <= 0) {
            lblCartItemCount.setVisibility(View.GONE);
        } else {
            lblCartItemCount.setVisibility(View.VISIBLE);
            lblCartItemCount.setText(("" + cartCount));

        }


        /*rlCartTotIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               *//* if(cartCount>0)
                    displayView(13);
                else{
                    DialogManager.showToast(getApplicationContext(),"Cart is empty.");
                }*//*
                if (isSearchOpend) {
                    disableSearch();
                    mSearchAction.setIcon(getResources().getDrawable(R.mipmap.ic_menu_search));

                }
                try {
                    JSONObject myCartInfo = new JSONObject();
                    myCartInfo.put("customerId", Utils.getUserId(getApplicationContext()));
                    String jwtResCart = Utils.getJWTToken(myCartInfo.toString());
                    APIRequestHandler.getInstance().getAllCartprods(MainActivity.this, jwtResCart, MainActivity.this);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //      invalidateOptionsMenu();

                // Toast.makeText(getApplicationContext(),"Clicked Cart Icon ",Toast.LENGTH_SHORT).show();
            }
        });*/
        return true;
    }

    private void disableSearch() {

        isSearchOpend = false;

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(edtSearch.getWindowToken(), 0);
        edtSearch.setText("");
        edtSearch.setVisibility(View.GONE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_search) {
            handleMenuSearch();
            return true;
        } else return item.getItemId() == R.id.action_cart;

    }


    protected void handleMenuSearch() {
        ActionBar action = getSupportActionBar(); //get the actionbar

        if (isSearchOpend) { //test if the search is open

            //action.setDisplayShowCustomEnabled(false); //disable a custom view inside the actionbar
            //action.setDisplayShowTitleEnabled(false); //show the title in the action bar
            //action.setBackgroundDrawable(getResources().getDrawable(R.drawable.meetin_intro_tool));
            //hides the keyboard


            edtSearch.setVisibility(View.GONE);

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(edtSearch.getWindowToken(), 0);
            //add the search icon in the action bar
//            mSearchAction.setIcon(getResources().getDrawable(R.mipmap.ic_menu_search));

//            fragment.doSearch("");
            //   fragment.elasticSearch("");

            isSearchOpend = false;
        } else { //open the search entry

            edtSearch.setVisibility(View.VISIBLE);

            edtSearch.setText("");

            edtSearch.setImeOptions(EditorInfo.IME_ACTION_SEARCH);


            //this is a listener to do a search when the user clicks on search button
            edtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(edtSearch.getWindowToken(), 0);
//                        fragment.doSearch(edtSearch.getText().toString());
                        return true;
                    }
                    return false;
                }
            });

            edtSearch.requestFocus();

            //open the keyboard focused in the edtSearch
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(edtSearch, InputMethodManager.SHOW_IMPLICIT);


            //add the close icon
//            mSearchAction.setIcon(getResources().getDrawable(R.drawable.menu_close_icon));
            isSearchOpend = true;
        }
    }

    private TextWatcher searchTextChangeListener = new TextWatcher() {
        private static final char hyphen_symbol = '-';

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            /*String text_change = edtSearch.getText().toString();
            text_change = text_change.replace("-", "");
            if (edtSearch.getText().toString().length() >= 3
                    && text_change.matches("[0-9]+")) {
                if (s.length() > 0 && (s.length() % 4) == 0) {
                    final char c = s.charAt(s.length() - 1);
                    if (hyphen_symbol == c) {
                        s.delete(s.length() - 1, s.length());
                    }
                }
                if (s.length() > 0 && (s.length() % 4) == 0) {
                    char c = s.charAt(s.length() - 1);
                    if (Character.isDigit(c)
                            && TextUtils.split(s.toString(),
                            String.valueOf(hyphen_symbol)).length <= 2) {
                        s.insert(s.length() - 1,
                                String.valueOf(hyphen_symbol));
                    }
                }
            }*/

            // fragment.elasticSearch(s.toString());
        }
    };

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rlCartTot:
            /* try {
                 JSONObject myCartInfo = new JSONObject();
                 myCartInfo.put("customerId", Utils.getUserId(getApplicationContext()));
                 String jwtResCart = Utils.getJWTToken(myCartInfo.toString());
                 APIRequestHandler.getInstance().getAllCartprods(jwtResCart, this);
             }catch (Exception e){
                 e.printStackTrace();
             }*/
                //displayView(13);
                //Toast.makeText(getApplicationContext(),"Clicked Cart Icon :",Toast.LENGTH_SHORT).show();
                break;

        }
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);
        if (responseObj != null) {
            if (responseObj instanceof LoginResponse) {
                LoginResponse response = (LoginResponse) responseObj;
                if (response.getRespCd() == AppConstants.RESP_CODE_SUCCESS) {
                    String resp = Utils.getJWTResponse(response.getData(), EmpMainActivity.this);
                    Gson gson = new Gson();
                    final LoginModel lm = gson.fromJson(resp, LoginModel.class);

                    String msg = "Retailer Firm/shop name : " + lm.getNameOfTheFirm() +
                            " \n Owner name : " + lm.getOwnerName() +
                            "\n do you want to proceed for this retailer ?";

                    DialogManager.showConformPopup(EmpMainActivity.this, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("retailerData", lm);
                            Intent intent = new Intent(EmpMainActivity.this, MainActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }

                        @Override
                        public void onCancelClick(View view) {

                        }
                    }, getString(R.string.app_name), msg, getString(R.string.yes), getString(R.string.no));

                } else {
                    DialogManager.showToast(EmpMainActivity.this, response.getRespMsg());
                }
            } else if (responseObj instanceof PravakthaAssistanceResponse) {
                PravakthaAssistanceResponse pravakthaAssistanceResponse = (PravakthaAssistanceResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == pravakthaAssistanceResponse.getStatusCode()) {
                    PravakthaAssistanceModel model = pravakthaAssistanceResponse.getResponseObj();
                    parvaktaAssistanceMobileNo = model.getMobileNumber();
                    BuildLog.e("PravaktaAssistanceOtp ", model.getOtp());
                    DialogManager.mDialog.dismiss();
                    showPravaktaOTPPopup(EmpMainActivity.this);
                } else if (AppConstants.PRAVAKTA_NOT_EXIST == pravakthaAssistanceResponse.getStatusCode()) {
                    DialogManager.showToast(EmpMainActivity.this, pravakthaAssistanceResponse.getMessage());
                } else {
                    DialogManager.showToast(EmpMainActivity.this, pravakthaAssistanceResponse.getMessage());
                }
            } else if (responseObj instanceof PravaktaAssistanceOtpResponse) {
                PravaktaAssistanceOtpResponse pravaktaAssistanceOtpResponse = (PravaktaAssistanceOtpResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == pravaktaAssistanceOtpResponse.getStatusCode()) {
                    PravaktaAssistanceOtpModel otpModel = pravaktaAssistanceOtpResponse.getResponseObj();
                    mDialog.dismiss();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(PravaktaAssistantActivity.EXTRA_PRAVAKTA_DETAILS, otpModel);
//                    startActivity(new Intent(EmpMainActivity.this, CouponBookletActivity.class).putExtras(bundle));
                    startActivity(new Intent(EmpMainActivity.this, PravaktaAssistantActivity.class).putExtras(bundle));
                } else if (AppConstants.OTP_INVALID_CODE == pravaktaAssistanceOtpResponse.getStatusCode()) {
                    DialogManager.showToast(EmpMainActivity.this, pravaktaAssistanceOtpResponse.getMessage());
                } else {
                    DialogManager.showToast(EmpMainActivity.this, pravaktaAssistanceOtpResponse.getMessage());
                }
            } else if (responseObj instanceof FarmerAssistanceResponse) {
                FarmerAssistanceResponse farmerAssistanceResponse = (FarmerAssistanceResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == farmerAssistanceResponse.getStatusCode()) {
                    FarmerAssistanceMobileNoResponse model = farmerAssistanceResponse.getResponseObj();
                    farmerAssistanceMobileNo = model.getMobileNumber();
                    BuildLog.e("FarmerAssistanceOtp ", model.getOtp());
                    DialogManager.mDialog.dismiss();
                    showFarmerOTPPopup(EmpMainActivity.this);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, farmerAssistanceResponse.getMessage());
                }

            } else if (responseObj instanceof FarmerAssistanceOTPDetailsResponse) {
                FarmerAssistanceOTPDetailsResponse farmerAssistanceOTPDetailsResponse = (FarmerAssistanceOTPDetailsResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == farmerAssistanceOTPDetailsResponse.getStatusCode()) {
                    FarmerAssistanceOtpResponse farmerModel = farmerAssistanceOTPDetailsResponse.getResponseObj();
                    mDialog.dismiss();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("farmerDetails", farmerModel);
                    startActivity(new Intent(EmpMainActivity.this, FarmerAssistantActivity.class).putExtras(bundle));
                } else if (AppConstants.OTP_INVALID_CODE == farmerAssistanceOTPDetailsResponse.getStatusCode()) {
                    DialogManager.showToast(EmpMainActivity.this, farmerAssistanceOTPDetailsResponse.getMessage());
                } else {
                    DialogManager.showToast(EmpMainActivity.this, farmerAssistanceOTPDetailsResponse.getMessage());
                }

            } else if (responseObj instanceof FarmerGerminationSchemeResponse) {
                FarmerGerminationSchemeResponse farmerGerminationSchemeResponse = (FarmerGerminationSchemeResponse) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == farmerGerminationSchemeResponse.getStatusCode()) {
                    FarmerAssistanceOtpResponse farmerModel = farmerGerminationSchemeResponse.getResponseObj();
//                    mDialog.dismiss();

                    fDataCache.setCustomerId(farmerModel.getFarmerId());
                    fDataCache.setMobileNo(farmerModel.getMobileNumber());
                    fDataCache.setShowGermination(farmerModel.isShowGermination());
                    fDataCache.setGerminationSchemeAvailable(farmerModel.isGerminationSchemeAvailable());
                    fDataCache.setAreGerminationClaimsAvailable(farmerModel.isAreGerminationClaimsAvailable());
                    fDataCache.setFarmerPincode(farmerModel.getFarmerPincode());

                    if (Utility.isValidStr(fDataCache.getMobileNo())) {
                        callApiGerminationScheme(fDataCache.getMobileNo());
                    }
//                    startActivity(new Intent(EmpMainActivity.this, FarmerAssistantActivity.class).putExtras(bundle));
                } else {
                    DialogManager.showToast(EmpMainActivity.this, farmerGerminationSchemeResponse.getMessage());
                }

            } else if (responseObj instanceof DiseaseResponseModel) {
                DiseaseResponseModel diseaseModel = (DiseaseResponseModel) responseObj;
                if (AppConstants.STATUS_CODE.equals(String.valueOf(diseaseModel.getStatusCode()))) {
                    Utils.setProductsSyncTime(diseaseModel.getLastSyncedOn(), EmpMainActivity.this);
                    List<DownloadFileDTO> downloadFiles = new ArrayList<>();
                    if (diseaseModel.getDiseasePrescriptions() != null && !diseaseModel.getDiseasePrescriptions().isEmpty()) {
                        for (DiseasePrescriptionDTO dto : diseaseModel.getDiseasePrescriptions()) {
                            if (AppConstants.STATUS_INSERT.equalsIgnoreCase(dto.getStatus()) || AppConstants.STATUS_UPDATE.equalsIgnoreCase(dto.getStatus())) {
                                DiseasePrescriptionDTO disease = DiseasePrescriptionDAO.getInstance().getRecordById(dto.getId(), DBHandler.getReadableDb(EmpMainActivity.this));
                                if (disease != null) {
                                    DownloadFileDTO download = null;
                                    if (Utils.isValidStr(disease.getDiseaseImageFile()) && Utils.isValidStr(dto.getDiseaseImageFile()) && !disease.getDiseaseImageFile().equals(dto.getDiseaseImageFile())) {
                                        dto.setCdi_images_local("");
                                        download = new DownloadFileDTO();
                                        download.setUrl(dto.getDiseaseImageFile());
                                    } else if (Utils.isValidStr(disease.getDiseaseImageFile()) && !Utils.isValidStr(dto.getDiseaseImageFile())) {
                                        dto.setCdi_images_local("");
                                    } else if (!Utils.isValidStr(disease.getDiseaseImageFile()) && Utils.isValidStr(dto.getDiseaseImageFile())) {
                                        download = new DownloadFileDTO();
                                        download.setUrl(dto.getDiseaseImageFile());
                                    }
                                    DiseasePrescriptionDAO.getInstance().updateRecordById(dto, DBHandler.getWritableDb(EmpMainActivity.this));

                                    if (download != null) {
                                        download.setId(dto.getId());
                                        download.setCategory(AppConstants.CDI_IMAGE);
                                        download.setType(AppConstants.IMAGE_TYPE);
                                        downloadFiles.add(download);
                                    }
                                } else {
                                    DiseasePrescriptionDAO.getInstance().insert(dto, DBHandler.getWritableDb(EmpMainActivity.this));
                                    if (Utils.isValidStr(dto.getDiseaseImageFile())) {
                                        DownloadFileDTO download = new DownloadFileDTO();
                                        download.setId(dto.getId());
                                        download.setCategory(AppConstants.CDI_IMAGE);
                                        download.setUrl(dto.getDiseaseImageFile());
                                        download.setType(AppConstants.IMAGE_TYPE);
                                        downloadFiles.add(download);
                                    }
                                }
                            } else if (AppConstants.STATUS_DELETE.equalsIgnoreCase(dto.getStatus())) {
                                DiseasePrescriptionDAO.getInstance().deleteRecordById(dto.getId(), DBHandler.getWritableDb(EmpMainActivity.this));
                            }
                        }
                    }

                    if (diseaseModel.getAgroProductMasters() != null && !diseaseModel.getAgroProductMasters().isEmpty()) {
                        for (AgroDiseaseProductMappingDTO dto : diseaseModel.getAgroProductMasters()) {
                            if (AppConstants.STATUS_INSERT.equalsIgnoreCase(dto.getStatus()) || AppConstants.STATUS_UPDATE.equalsIgnoreCase(dto.getStatus())) {
                                AgroDiseaseProductMappingDTO disease = AgroDiseaseProductMappingDAO.getInstance().getRecordById(dto.getId(), DBHandler.getReadableDb(EmpMainActivity.this));
                                if (disease != null) {
                                    DownloadFileDTO download = null;
                                    if (Utils.isValidStr(disease.getProductImage()) && Utils.isValidStr(dto.getProductImage()) && !disease.getProductImage().equals(dto.getProductImage())) {
                                        dto.setAgro_images_local("");
                                        download = new DownloadFileDTO();
                                        download.setUrl(dto.getProductImage());
                                    } else if (Utils.isValidStr(disease.getProductImage()) && !Utils.isValidStr(dto.getProductImage())) {
                                        dto.setAgro_images_local("");
                                    } else if (!Utils.isValidStr(disease.getProductImage()) && Utils.isValidStr(dto.getProductImage())) {
                                        download = new DownloadFileDTO();
                                        download.setUrl(dto.getProductImage());
                                    }
                                    AgroDiseaseProductMappingDAO.getInstance().updateRecordById(dto, DBHandler.getWritableDb(EmpMainActivity.this));

                                    if (download != null) {
                                        download.setId(dto.getId());
                                        download.setCategory(AppConstants.AGRO_IMAGE);
                                        download.setType(AppConstants.IMAGE_TYPE);
                                        downloadFiles.add(download);
                                    }
                                } else {
                                    AgroDiseaseProductMappingDAO.getInstance().insert(dto, DBHandler.getWritableDb(EmpMainActivity.this));
                                    if (Utils.isValidStr(dto.getProductImage())) {
                                        DownloadFileDTO download = new DownloadFileDTO();
                                        download.setId(dto.getId());
                                        download.setCategory(AppConstants.AGRO_IMAGE);
                                        download.setUrl(dto.getProductImage());
                                        download.setType(AppConstants.IMAGE_TYPE);
                                        downloadFiles.add(download);
                                    }
                                }
                            } else if (AppConstants.STATUS_DELETE.equalsIgnoreCase(dto.getStatus())) {
                                AgroDiseaseProductMappingDAO.getInstance().deleteRecordById(dto.getId(), DBHandler.getWritableDb(EmpMainActivity.this));
                            }
                        }
                    }
                    for (DownloadFileDTO downloadDTO : downloadFiles) {
                        DownloadingFileDAO.getInstance().insert(downloadDTO, DBHandler.getWritableDb(EmpMainActivity.this));
                    }

                    startDownloadService();
                }
            } else if (responseObj instanceof TblWeeklyLiqMasterMain) {
                TblWeeklyLiqMasterMain response = (TblWeeklyLiqMasterMain) responseObj;

                if (AppConstants.STATUS_CODE_PRAVAKTA == response.getStatusCode()) {
                    Gson gson = new Gson();
                    TblWeeklyLiqMasterMain commonResEntity = gson.fromJson(response.getResponse(), TblWeeklyLiqMasterMain.class);
                    insertDataInoLocalDB(commonResEntity);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, response.getMessage());
                }
            } else if (responseObj instanceof TblSubmitWLResModel) {
                TblSubmitWLResModel response = (TblSubmitWLResModel) responseObj;

                if (AppConstants.STATUS_CODE_PRAVAKTA == response.getStatusCode()) {
                    Gson gson = new Gson();
                    TblSubmitWLResModel commonResEntity = gson.fromJson(response.getResponse(), TblSubmitWLResModel.class);
                    Utils.setTblLastSubmittedTime(commonResEntity.getLastUpdatedTime(), EmpMainActivity.this);
                    if (commonResEntity.getMobileIdList() != null) {
                        for (String i : commonResEntity.getMobileIdList()) {
                            TblWeeklyLiqDAO.getInstance().deleteRecordById(Integer.valueOf(i), DBHandler.getWritableDb(EmpMainActivity.this));
                        }
                    }
                    if (commonResEntity.getLiquidationActualsDTOList() != null) {
                        for (TBLWeeklyLiqDTO model : commonResEntity.getLiquidationActualsDTOList()) {
                            TBLWeeklyLiqDTO comboExist = TblWeeklyLiqDAO.getInstance().isCombinationExist(model.getCurrentYear(), model.getSeasonId(), model.getCropId(), model.getHybridId(), DBHandler.getReadableDb(EmpMainActivity.this));
                            if (comboExist != null) {
                                TblWeeklyLiqDAO.getInstance().deleteRecordById(Integer.valueOf(comboExist.getMobileId()), DBHandler.getWritableDb(EmpMainActivity.this));
                            } else {
                                model.setSync(2);
                                TblWeeklyLiqDAO.getInstance().insert(model, DBHandler.getWritableDb(EmpMainActivity.this));
                            }
                        }
                    }
                } else {
                    DialogManager.showToast(EmpMainActivity.this, response.getMessage());
                }
            } else if (responseObj instanceof CropDiagnosisMasterResponse) {
                CropDiagnosisMasterResponse commonResEntity = (CropDiagnosisMasterResponse) responseObj;
                if (AppConstants.STATUS_CODE.equals(commonResEntity.getStatusCode())) {
                    String resJson = Utils.getJWTResponseFC(commonResEntity.getResponse(), EmpMainActivity.this);
                    CropDiagnosisMasterResponse response = new Gson().fromJson(resJson, CropDiagnosisMasterResponse.class);
                    ArrayList<IdServerIdModel> idsList = response.getIdsList();
                    if (idsList != null) {
                        for (IdServerIdModel list : idsList) {
                            CropDiagnosisMasterDataUploadDTO updateDto = new CropDiagnosisMasterDataUploadDTO();
                            updateDto.setServerId(list.getServerId());
                            updateDto.setId(list.getId());
                            updateDto.setStatus(1);
                            CropDiagnosisMasterDataUploadDAO.getInstance().updateRecordById(updateDto, DBHandler.getWritableDb(EmpMainActivity.this));

                            CropDiagnosisMasterDataUploadDTO record = CropDiagnosisMasterDataUploadDAO.getInstance().getRecordByIdSingleRecord(list.getId(), DBHandler.getReadableDb(EmpMainActivity.this));
                            String[] imagePaths = record.getImageUrls().split(",");
                            for (int i = 0; i < imagePaths.length; i++) {
                                // insert data into uploading table
                                UploadImagesDTO dto = new UploadImagesDTO();
                                dto.setImagePath(imagePaths[i]);
                                dto.setServerId(list.getServerId());
                                UpLoadImagesDAO.getInstance().insert(dto, DBHandler.getWritableDb(EmpMainActivity.this));
                            }
//                            CropDiagnosisMasterDataUploadDAO.getInstance().deleteRecordById(list.getId(), DBHandler.getWritableDb(EmpMainActivity.this));
                        }
                        startUploadService();
                    }
//                    DialogManager.showToast(EmpMainActivity.this, commonResEntity.getMessage());
                } else if (AppConstants.SOMETHING_WENT_WRONG.equals(commonResEntity.getStatusCode())) {
                    DialogManager.showToast(EmpMainActivity.this, commonResEntity.getMessage());
                } else {
                    DialogManager.showToast(EmpMainActivity.this, commonResEntity.getMessage());
                }
            } else if (responseObj instanceof FawSightingSubmitRes) {
                FawSightingSubmitRes response = (FawSightingSubmitRes) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == response.getStatusCode()) {
                    String jsonResponse = response.getResponse();
                    FawSightingSubmitRes model = new Gson().fromJson(jsonResponse, FawSightingSubmitRes.class);
                    ArrayList<DataUploadResponse> dataResList = model.getDataUploadResponse();

                    if (dataResList != null && dataResList.size() > 0) {
                        for (DataUploadResponse listDto : dataResList) {

                            if (Utils.isValidStr(listDto.getImageUrls())) {
                                UploadImagesDTO dto = new UploadImagesDTO();
                                dto.setServerId(listDto.getServerIds());
                                dto.setImagePath(listDto.getImageUrls());
                                dto.setModuleType(AppConstants.FAW_SIGHTING);
                                ImagesUploadDAO.getInstance().insert(dto, DBHandler.getWritableDb(thisActivity));
                            }
                            FawSightingReqModel fawDto = new FawSightingReqModel();
                            fawDto.setId(listDto.getIds());
                            fawDto.setIsSync(2);
                            FawSightingDAO.getInstance().update(fawDto, DBHandler.getWritableDb(thisActivity));
                        }
                    }
                    startUploadImageService();
                } else {
                    DialogManager.showToast(EmpMainActivity.this, response.getMessage());
                }
            } /*else if (responseObj instanceof SioAuthenticationRes) {
                SioAuthenticationRes response = (SioAuthenticationRes) responseObj;
                BuildLog.e("SioResponse", response.toString());
                if (response.getResponseCode() == 1) {
                    UserPrefs.saveLoggedInUser(this, response.getResponse());
                    UserPrefs.setUserLogOutStatus(false);

                    Intent gotoSio = new Intent(thisActivity, com.retailerclub.ui.activity.DashboardActivity.class);
                    startActivity(gotoSio);
                } else {
                    DialogManager.showToast(thisActivity, response.getMessage());
                }
            } */ else if (responseObj instanceof GerminationMasterResponseModel) {
                GerminationMasterResponseModel response = (GerminationMasterResponseModel) responseObj;
                if (AppConstants.STATUS_CODE_PRAVAKTA == response.getStatusCode()) {
                    String jsonRes = response.getResponse();
                    GerminationMasterResponseModel resModel = new Gson().fromJson(jsonRes, GerminationMasterResponseModel.class);

                    if (resModel.getPendingAgreement() != null && resModel.getPendingAgreement().size() > 0) {
                        if (resModel.getPendingAgreement().size() == 1) {
                            // navigate to agreement screen
                            Intent gotoAgreement = new Intent(thisActivity, GerminationAgreementActivity.class);
                            gotoAgreement.putExtra(GerminationAgreementActivity.EXTRA_MODEL_DATA_FWD_TO_NEXT_SCREEN, resModel.getPendingAgreement().get(0));
                            startActivityForResult(gotoAgreement, MOVE_TO_GERMINATION_AGREEMENT_SCREEN_REQUEST);
                        } else {
                            //navigate to list screen
                            Intent gotoSubccriptionList = new Intent(thisActivity, GerminationSubscriptionListActivity.class);
                            gotoSubccriptionList.putExtra(GerminationSubscriptionListActivity.EXTRA_LIST_FROM_FARMERASSIST, resModel.getPendingAgreement());
                            startActivityForResult(gotoSubccriptionList, MOVE_TO_GERMINATION_SUBSCRIPTION_LIST_SCREEN_REQUEST);
                        }
                    } else {
                            DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), "No Schemes Are Available", getString(R.string.ok));
                    }
                } else {
                    DialogManager.showToast(thisActivity, response.getMessage());
                }
            } else if (responseObj instanceof CommonResponse) {
                CommonResponse response = (CommonResponse) responseObj;
                if (AppConstants.RESP_CODE_SUCCESS == response.getRespCd()) {
                    logoutUser(EmpMainActivity.this);
                } else {
                    DialogManager.showToast(EmpMainActivity.this, response.getRespMsg());
                }
            }
        }
    }


    private void insertDataInoLocalDB(TblWeeklyLiqMasterMain allList) {
        if (allList != null) {
            if (allList.getSeasonList() != null) {
                WLSeasonMasterDataDAO.getInstance().deleteTableData(DBHandler.getWritableDb(EmpMainActivity.this));
                for (IdNameModel model : allList.getSeasonList()) {
                    WLSeasonMasterDataDAO.getInstance().insert(model, DBHandler.getWritableDb(EmpMainActivity.this));
                }
            }

            if (allList.getCropList() != null) {
                WLCropMasterDataDAO.getInstance().deleteTableData(DBHandler.getWritableDb(EmpMainActivity.this));
                for (IdNameModel model : allList.getCropList()) {
                    WLCropMasterDataDAO.getInstance().insert(model, DBHandler.getWritableDb(EmpMainActivity.this));
                }
            }

            if (allList.getHybridList() != null) {
                WLHybridMasterDataDAO.getInstance().deleteTableData(DBHandler.getWritableDb(EmpMainActivity.this));
                for (RetailHybridIds model : allList.getHybridList()) {
                    WLHybridMasterDataDAO.getInstance().insert(model, DBHandler.getWritableDb(EmpMainActivity.this));
                }
            }
        }
    }

    private void startDownloadService() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            Intent intent = new Intent(EmpMainActivity.this, DownloadFileServiceNewJob.class);
            DownloadFileServiceNewJob.enqueueWork(this, intent);

        } else {
            Intent intent = new Intent(EmpMainActivity.this, DownloadFileService.class);
            startService(intent);

        }
    }

    @Override
    public void onRequestFailure(RetrofitError errorCode, String errorFrom) {
        super.onRequestFailure(errorCode, errorFrom);
    }

    public void showPravaktaOTPPopup(final Context mcontent) {

        mDialog = Utils.getDialog(EmpMainActivity.this, R.layout.emp_popup_otp_mobile_no_btn);
        mDialog.setCancelable(true);
        mDialog.setCanceledOnTouchOutside(true);

        ViewGroup root = mDialog
                .findViewById(R.id.rc_parent_view_for_font);
        tvHeader = mDialog.findViewById(R.id.header_txt);
        mEditText = mDialog.findViewById(R.id.cl_mobile_no);
        mOtpEdittext = mDialog.findViewById(R.id.cl_otp_no);
        msubmitBtn = mDialog.findViewById(R.id.cl_submit_btn);
        mOtpSubmit = mDialog.findViewById(R.id.cl_otp_submit_btn);
        mcancelBtn = mDialog.findViewById(R.id.cancel_btn);
        tvHeader.setVisibility(View.GONE);
        mEditText.setVisibility(View.GONE);
        msubmitBtn.setVisibility(View.GONE);
        mOtpEdittext.setVisibility(View.VISIBLE);
        mOtpSubmit.setVisibility(View.VISIBLE);
        mcancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });

        mOtpSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOtpEdittext.getText().toString().trim().length() < 6) {
                    DialogManager.showToast(EmpMainActivity.this, "Enter valid OTP");
                } else {
                    if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                        APIRequestHandler.getInstance().getPravaktaAssistanceOtpResponse(EmpMainActivity.this, parvaktaAssistanceMobileNo, mOtpEdittext.getText().toString().trim(), Utils.getUserId(EmpMainActivity.this), EmpMainActivity.this);
                    } else {
                        DialogManager.showToast(EmpMainActivity.this, getString(R.string.no_internet));
                    }
                }
            }
        });
        mDialog.show();
    }

    public void showFarmerOTPPopup(final Context mcontent) {

        mDialog = Utils.getDialog(EmpMainActivity.this, R.layout.emp_popup_otp_mobile_no_btn);
        mDialog.setCancelable(true);
        mDialog.setCanceledOnTouchOutside(true);

        ViewGroup root = mDialog.findViewById(R.id.rc_parent_view_for_font);
        tvHeader = mDialog.findViewById(R.id.header_txt);
        mEditText = mDialog.findViewById(R.id.cl_mobile_no);
        mOtpEdittext = mDialog.findViewById(R.id.cl_otp_no);
        msubmitBtn = mDialog.findViewById(R.id.cl_submit_btn);
        mOtpSubmit = mDialog.findViewById(R.id.cl_otp_submit_btn);
        mcancelBtn = mDialog.findViewById(R.id.cancel_btn);
        tvHeader.setVisibility(View.GONE);
        mEditText.setVisibility(View.GONE);
        msubmitBtn.setVisibility(View.GONE);
        mOtpEdittext.setVisibility(View.VISIBLE);
        mOtpSubmit.setVisibility(View.VISIBLE);
        mcancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });

        mOtpSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOtpEdittext.getText().toString().trim().length() < 6) {
                    DialogManager.showToast(EmpMainActivity.this, "Enter valid OTP");
                } else {
                    if (Utils.isNetworkConnection(EmpMainActivity.this)) {
                        APIRequestHandler.getInstance().getFarmerAssistanceOtpResponse(EmpMainActivity.this, farmerAssistanceMobileNo, mOtpEdittext.getText().toString().trim(), Utils.getUserId(EmpMainActivity.this), EmpMainActivity.this);
                    } else {
                        DialogManager.showToast(EmpMainActivity.this, getString(R.string.no_internet));
                    }
                }
            }
        });
        mDialog.show();
    }

    public void openGenuinityCheck() {
        UniqolabelVerifier uscan = new UniqolabelVerifier(thisActivity, R.drawable.uniqolabel_image, "en");
        uscan.setEnv(AppConstants.UNIQO_LABEL_ENVIRONMENT);
        uscan.initiateScanActivity();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        killUniqoReceiver();

        if (UniqolabelVerifier.REQUEST_CODE /*5678*/ == requestCode) { // here 5678 is dummy. TARA
            if (resultCode == 100) {

                String productDeatils = "", pId = "", pName = "", pSku = "", pPrice = "", pDescription = "", pPoints = "", batchNumber = "", pManufacturingDate = "", pExpiryDate = "", androidAr = "", iosAr = "", completeResponse = "";
                try {
                    Bundle bundle = data.getExtras();
                    completeResponse = bundle.getString("uq_result");
                    JSONObject jsonObject = new JSONObject(completeResponse);
                    int status = jsonObject.getInt("status");

                    BuildLog.e(TAG, Utils.isValidStr(completeResponse) ? completeResponse : "Response Not Available");

                    if (status == 1) {

                        int responseCode = jsonObject.getInt("responseCode");
                        String message = jsonObject.getString("message");
                        if (jsonObject.has("productDetails"))
                            productDeatils = jsonObject.getString("productDetails");

                        if (Utils.isValidStr(productDeatils) && !productDeatils.equalsIgnoreCase("null")) {

                            JSONObject pdJson = new JSONObject(productDeatils);
                            if (pdJson.has("product_name"))
                                pName = pdJson.getString("product_name");
                            if (pdJson.has("product_sku"))
                                pSku = pdJson.getString("product_sku");
                            if (pdJson.has("product_price"))
                                pPrice = pdJson.getString("product_price");
                            if (pdJson.has("product_description"))
                                pDescription = pdJson.getString("product_description");

                            if (pdJson.has("android_ar"))
                                androidAr = pdJson.getString("android_ar");

                            if (pdJson.has("ios_ar"))
                                iosAr = pdJson.getString("ios_ar");

                            if (pdJson.has("product_id"))
                                pId = pdJson.getString("product_id");

                            if (pdJson.has("product_specifications")) {
                                JSONArray pdSpecifictaionList = pdJson.getJSONArray("product_specifications");
                                if (pdSpecifictaionList != null && pdSpecifictaionList.length() > 0)
                                    for (int i = 0; i < pdSpecifictaionList.length(); i++) {
                                        JSONObject listObject = (JSONObject) pdSpecifictaionList.get(i);
                                        if (listObject.has("batch_number"))
                                            batchNumber = listObject.getString("batch_number");
                                        else if (listObject.has("mfg_date"))
                                            pManufacturingDate = listObject.getString("mfg_date");
                                        else if (listObject.has("expiry_date"))
                                            pExpiryDate = listObject.getString("expiry_date");
                                        else if (listObject.has("product_points"))
                                            pPoints = listObject.getString("product_points");
                                    }
                            }

                        }
                        String serialNumber = jsonObject.getString("serialNumber");
                        String codeLogID = jsonObject.getString("codeLogId");
                        String msgEn = "", sNo = "";
                        int image_resource_id = 0;

                        switch (responseCode) {
                            case 100: /*Success Authenticity Verified*/
                                msgEn = message;
                                image_resource_id = R.mipmap.ic_right_symbol_green_bg;
                                sNo = "Serial Number : " + serialNumber;
                                BuildLog.e("ChkGenuinity100", message);
                                break;
                            case 101: /*Genuine label Inactive, contact Support to activate*/
                                msgEn = "This is not a genuine DuPont product. Please call DuPont customer care on: 1860-1800-186";
                                image_resource_id = R.mipmap.ic_wrong_symbol_red_bg;
                                BuildLog.e("ChkGenuinity101", message);
                                break;
                            case 102: /*Random 2D code is scanned invalid*/
                                msgEn = "This is not a genuine DuPont product. Please call DuPont customer care on: 1860-1800-186";
                                image_resource_id = R.mipmap.ic_wrong_symbol_red_bg;
                                BuildLog.e("ChkGenuinity102", message);
                                break;
                            case 103: /*Code has been exhausted but count is less than allowed +3*/
                                msgEn = message;
                                image_resource_id = R.mipmap.ic_exclamation_symbol_yellow_bg;
                                BuildLog.e("ChkGenuinity103", message);
                                break;
                            case 104:
                                msgEn = message;
                                image_resource_id = R.mipmap.ic_wrong_symbol_red_bg;
                                BuildLog.e("ChkGenuinity104", message);
                                break;
                            case 105: /*Code has been exhausted but count is more than allowed +3*/
                                msgEn = message;
                                image_resource_id = R.mipmap.ic_wrong_symbol_red_bg;
                                BuildLog.e("ChkGenuinity105", message);
                                break;
                            default: /*Random 2D code is scanned*/
                                msgEn = message;
                                image_resource_id = R.mipmap.ic_wrong_symbol_red_bg;
                                BuildLog.e("ChkGenuinity000", message);
                                break;
                        }
                        showGenuinityCheckPopupResult(getString(R.string.genuinityCheck), msgEn, sNo, image_resource_id, getString(R.string.ok), msgEn, responseCode, message, productDeatils, serialNumber, codeLogID,
                                pId, pName, pSku, pPrice, pDescription, pPoints, batchNumber, pManufacturingDate, pExpiryDate, androidAr, iosAr, completeResponse);
                    } else {
                        DialogManager.showToast(thisActivity, "Something Went Wrong");
                    }
                } catch (NullPointerException e) {
                    e.printStackTrace();
                    DialogManager.showToast(thisActivity, getString(R.string.oops_something));
                } catch (JSONException e) {
                    e.printStackTrace();
                    DialogManager.showToast(thisActivity, getString(R.string.oops_something));
                }
            } else {
                DialogManager.showToast(EmpMainActivity.this, "Scan cancelled");
            }
        } else if (requestCode == GO_TO_REGISTER_PAGE_REQ) {
            if (resultCode == RESULT_OK) {
                Bundle bundleRegis = data.getExtras();
                if (bundleRegis != null && bundleRegis.containsKey(RegistrationScreen.PUT_EXTRA_FARMER_REGISTER_DETAILS)) {
                    RegResEntity farmerRegisterData = (RegResEntity) bundleRegis.getSerializable(RegistrationScreen.PUT_EXTRA_FARMER_REGISTER_DETAILS);
                    fDataCache.setCustomerId(farmerRegisterData.getCustomerId());
                    fDataCache.setMobileNo(farmerRegisterData.getMobileNumber());
                    fDataCache.setShowGermination(farmerRegisterData.isShowGermination());
                    fDataCache.setGerminationSchemeAvailable(farmerRegisterData.isGerminationSchemeAvailable());
                    fDataCache.setAreGerminationClaimsAvailable(farmerRegisterData.isAreGerminationClaimsAvailable());
                    fDataCache.setFarmerPincode(farmerRegisterData.getFarmerPincode());
                }
            } else if (resultCode == RESULT_CANCELED) {
            }
        } else if (requestCode == MOVE_TO_GERMINATION_AGREEMENT_SCREEN_REQUEST /*|| requestCode == MOVE_TO_GERMINATION_SUBSCRIPTION_LIST_SCREEN_REQUEST*/) {
            if (resultCode == RESULT_OK) {
                isFromGermination = true;
                if (Utils.isValidStr(stMobileNo)) {
                 //   callApiGerminationScheme(stMobileNo);
                }
            } else {
                // nothing to do
            }
        } else if (requestCode == MOVE_TO_GERMINATION_SUBSCRIPTION_LIST_SCREEN_REQUEST) {
            Bundle bundle = data.getExtras();
            if (bundle != null) {
                if (bundle.containsKey(GerminationSubscriptionListActivity.IS_GERMINATION_SUBSCRIPTION_COMPLETED)) {
                    boolean b = bundle.getBoolean(GerminationSubscriptionListActivity.IS_GERMINATION_SUBSCRIPTION_COMPLETED);
                    if (b) {
                        isFromGermination = true;
                        if (Utils.isValidStr(stMobileNo)) {
                           // callApiGerminationScheme(stMobileNo);
                        }
                    }
                }
            }
        }

    }

    private void killUniqoReceiver() {
        /*PackageManager pm = this.getPackageManager();
        ComponentName componentName = new ComponentName(this, ConnectivityReceiver.class);
        pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);*/
        BuildLog.e(TAG, "UNIQO BroadCast Receiver Killed");
    }


    private void showGenuinityCheckPopupResult(String title, String msg, String serialNo, int imageSymbol, String btnTxt, String msgEn, int responseCode, String messageSDK, String productDeatils, String serialNumberSDK, String codeLogID, String pId, String pName, String pSku, String pPrice, String pDescription, String pPoints, String batchNumber, String pManufacturingDate, String pExpiryDate, String androidAr, String iosAr, String completeResponse) {
        mDialog = Utils.getDialog(EmpMainActivity.this, R.layout.popup_genuinity_check_sdk_response);
        mDialog.setCancelable(false);
        mDialog.setCanceledOnTouchOutside(false);

        TextView windowTitle = mDialog.findViewById(R.id.popup_window_title);
        ImageView symbol = mDialog.findViewById(R.id.popup_succ_fail_symbol);
        TextView message = mDialog.findViewById(R.id.popup_succ_fail_msg);
        TextView serialNumber = mDialog.findViewById(R.id.popup_serialNumber_text);
        Button okBtn = mDialog.findViewById(R.id.popup_ok_btn);

        windowTitle.setText(title);
        symbol.setImageResource(imageSymbol);
        message.setText(msg);
        serialNumber.setText(serialNo);
        okBtn.setText(btnTxt);

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                callAPI(msgEn, responseCode, messageSDK, productDeatils, serialNumberSDK, codeLogID, pId, pName, pSku, pPrice, pDescription, pPoints, batchNumber, pManufacturingDate, pExpiryDate, androidAr, iosAr, completeResponse);

            }
        });
        mDialog.show();
    }

    private void callAPI(String msgEn, int responseCode, String message, String productDeatils, String serialNumber, String codeLogID, String pId, String pName, String pSku, String pPrice, String pDescription, String pPoints, String batchNumber, String pManufacturingDate, String pExpiryDate, String androidAr, String iosAr, String completeResponse) {
        GenuinityCheckReq req = new GenuinityCheckReq();
        req.setUserMessage(msgEn);
        req.setUserLocalLangMessage("");
        req.setResponseCode(responseCode);
        req.setMessage(message);
//        req.setProductDetails(productDeatils);
        req.setSerialNumber(serialNumber);
        req.setCodeLogID(codeLogID);
        req.setDeviceType(AppConstants.DEVICE_TYPE_ANDROID);
        req.setAppName(AppConstants.USERTYPE_EMP);
        req.setUserId(Utils.getUserId(EmpMainActivity.this));
        req.setUserMobileNumber(Utils.getUserMobile(EmpMainActivity.this));

        req.setProductId(pId);
        req.setProductName(pName);
        req.setProductSKU(pSku);
        req.setProductPrice(pPrice);
        req.setProductDescription(pDescription);
        req.setProductPoints(pPoints);
        req.setProductBatchNo(batchNumber);
        req.setProductManufacturingdate(pManufacturingDate);
        req.setProductExpiryDate(pExpiryDate);
        req.setProductAndroidAR(androidAr);
        req.setProductIosAr(iosAr);
        req.setComplete_response(completeResponse);

        String jwtToken = Utils.getJWTToken(new Gson().toJson(req), EmpMainActivity.this);
        APIRequestHandler.getInstance().submitGenuinityCheck(EmpMainActivity.this, jwtToken, this, false);
    }

    private void startUploadService() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            if (!Utils.isMyServiceRunning(EmpMainActivity.this, "com.pioneer.emp.services.CdMasterUpLoadFileServiceNewJob")) {

                Intent intent = new Intent(this, CdMasterUpLoadFileServiceNewJob.class);
                CdMasterUpLoadFileServiceNewJob.enqueueWork(this, intent);
            }
        } else {
            if (!Utils.isMyServiceRunning(EmpMainActivity.this, "com.pioneer.emp.services.CdMasterUpLoadFileService")) {

                Intent intent = new Intent(this, CdMasterUpLoadFileService.class);
                startService(intent);
            }
        }
    }

    private void startUploadImageService() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            if (!Utils.isMyServiceRunning(EmpMainActivity.this, "com.pioneer.emp.services.ImageUploadFileServiceJob")) {

                Intent intent = new Intent(this, ImageUploadFileServiceJob.class);
                ImageUploadFileServiceJob.enqueueWork(this, intent);
            }
        } else {
            if (!Utils.isMyServiceRunning(EmpMainActivity.this, "com.pioneer.emp.services.ImageUpLoadFileService")) {

                Intent intent = new Intent(this, ImageUpLoadFileService.class);
                startService(intent);
            }
        }
    }

    private void callApiGerminationScheme(String farmerMob) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("mobileNumber", farmerMob);
            jsonObject.put("empMobileNumber", Utils.getUserMobile(thisActivity));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String jwtToken = Utils.getJWTToken(jsonObject.toString(), thisActivity);
        APIRequestHandler.getInstance().getGerminationMaster(thisActivity, jwtToken, this, true);
    }

}
