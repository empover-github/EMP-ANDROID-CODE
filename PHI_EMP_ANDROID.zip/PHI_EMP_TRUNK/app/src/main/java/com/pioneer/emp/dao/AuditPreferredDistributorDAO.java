package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.pioneer.emp.models.AuditPreferredDistributorsDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

public class AuditPreferredDistributorDAO implements DAO {
    private final String TAG = "AuditPreferredDistributorDAO";
    private static AuditPreferredDistributorDAO  auditPreferredDistributorDAO;

    public static AuditPreferredDistributorDAO getInstance() {
        if (auditPreferredDistributorDAO == null) {
            auditPreferredDistributorDAO = new AuditPreferredDistributorDAO();
        }

        return auditPreferredDistributorDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            AuditPreferredDistributorsDTO dto = (AuditPreferredDistributorsDTO) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("name", dto.getName());
            cv.put("company", dto.getCompany());
            cv.put("auditId", dto.getAuditId());

            long rowsEffected = dbObject.insert("PREFERRED_DISTRIBUTOR_AUDIT", null, cv);
            if (rowsEffected > 0)
                return "";
        } catch (SQLException e) {
            return null;
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        AuditPreferredDistributorsDTO dto = (AuditPreferredDistributorsDTO) dtoObject;
        try {
            dbObject.compileStatement("DELETE FROM PREFERRED_DISTRIBUTOR_AUDIT WHERE id = '" + dto.getId() + "'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM PREFERRED_DISTRIBUTOR_AUDIT").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public List<AuditPreferredDistributorsDTO> getRecordsToUpload(SQLiteDatabase dbObject, long auditId) {
        Cursor cursor = null;
        List<AuditPreferredDistributorsDTO> list = new ArrayList<AuditPreferredDistributorsDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM PREFERRED_DISTRIBUTOR_AUDIT WHERE auditId = " + auditId, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                AuditPreferredDistributorsDTO dto;
                do {
                    dto = new AuditPreferredDistributorsDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setAuditId(cursor.getLong(cursor.getColumnIndex("auditId")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setCompany(cursor.getString(cursor.getColumnIndex("company")));

                    list.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return list;
    }

    public boolean deleteById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM PREFERRED_DISTRIBUTOR_AUDIT WHERE auditId = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }


}
