package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.utils.AppConstants;

import java.util.List;

/**
 * Created by rambabu.a on 09-01-2018.
 */

public class CropDiagnosisGridAdapter extends RecyclerView.Adapter<CropDiagnosisGridAdapter.MyHolder>  {
    private Context context;
    private List<String> cropList;
    private OnBookletClickListener listener;

    public CropDiagnosisGridAdapter(Context context, List<String> cropList, OnBookletClickListener listener) {
        this.context = context;
        this.cropList = cropList;
        this.listener = listener;
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_layout, null);
        MyHolder myHolder = new MyHolder(layout);
        return myHolder;
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        String crop = cropList.get(position);
            holder.camImage.setImageResource(R.mipmap.ic_camera_black);
            if(crop.equalsIgnoreCase(AppConstants.RICE)){
                holder.imageView.setImageResource(R.drawable.img_crop_rice);
                holder.textView.setText(AppConstants.RICE);
            }else if(crop.equalsIgnoreCase( AppConstants.MILLET)){
                holder.imageView.setImageResource(R.drawable.img_crop_millet);
                holder.textView.setText(AppConstants.MILLET);
            }else if(crop.equalsIgnoreCase(AppConstants.MUSTARD)){
                holder.imageView.setImageResource(R.drawable.img_crop_mustard);
                holder.textView.setText(AppConstants.MUSTARD);
            }else if(crop.equalsIgnoreCase(AppConstants.CORN)){
                holder.imageView.setImageResource(R.drawable.img_crop_corn);
                holder.textView.setText(AppConstants.CORN);
            }else if(crop.equalsIgnoreCase(AppConstants.SOYABEAN)){
                holder.imageView.setImageResource(R.drawable.img_crop_soyabin);
                holder.textView.setText(AppConstants.SOYABEAN);
            }else if(crop.equalsIgnoreCase(AppConstants.CHILLI)){
                holder.imageView.setImageResource(R.drawable.img_crop_chilli_green);
                holder.textView.setText(AppConstants.CHILLI);
            }else if(crop.equalsIgnoreCase(AppConstants.COTTON)){
                holder.imageView.setImageResource(R.drawable.img_crop_cotton);
                holder.textView.setText(AppConstants.COTTON);
            }


            holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return cropList.size();
    }

    class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView,camImage;
        TextView textView;
        RelativeLayout rlyImageLayout;

        MyHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image1);
            camImage = itemView.findViewById(R.id.camImage1);
           // libImage = itemView.findViewById(R.id.image1Lib);
            textView = itemView.findViewById(R.id.tv_image1);
            rlyImageLayout = itemView.findViewById(R.id.fcdm_image1);

        }

        void bind(final int position) {
            rlyImageLayout.setTag(position);
            rlyImageLayout.setOnClickListener(this);
           // libImage.setTag(position);
            //libImage.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = (int) v.getTag();
            listener.onItemClick(v, position);
        }
    }
}
