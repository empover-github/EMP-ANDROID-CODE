package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.pioneer.emp.R;


import java.util.ArrayList;

/**
 * Created by fatima.t on 20-12-2017.
 */

public class GridAdapter extends BaseAdapter {
    LayoutInflater inflter;
    private Context mContext;
    private ArrayList<String> imageUrl;
    private ArrayList<String> imageId;

    public GridAdapter(Context context, ArrayList<String> imageUrl , ArrayList<String> imageId ) {
        mContext = context;
        this.imageId = imageId;
        this.imageUrl = imageUrl;
        inflter = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        // TO DO Auto-generated method stub
        return imageId.size();
    }

    @Override
    public Object getItem(int position) {
        // TO DO Auto-generated method stub
        return imageId.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TO DO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TO DO Auto-generated method stub
        ViewHolder holder = null;

        if (convertView == null) {
            convertView = inflter.inflate(R.layout.image_list_item, null);
            holder = new ViewHolder();
            holder.imageView = convertView.findViewById(R.id.grid_image);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        Glide.with(mContext)
                .load(imageUrl.get(position))
                .error(R.drawable.image_placeholder)
                .placeholder(R.drawable.image_placeholder)
                .dontAnimate().into(holder.imageView);

        return convertView;
    }

    private class ViewHolder {
        ImageView imageView;
    }


}
