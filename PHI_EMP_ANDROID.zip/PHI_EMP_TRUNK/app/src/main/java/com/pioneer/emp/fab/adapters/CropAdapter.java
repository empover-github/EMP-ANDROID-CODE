package com.pioneer.emp.fab.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.fab.models.CropMasterEntity;

import java.util.ArrayList;

/**
 * Created by fatima.t on 08-05-2017.
 */

public class CropAdapter extends BaseAdapter{
    ArrayList<CropMasterEntity> allCropList;
    LayoutInflater inflter;
    Context context;

    public CropAdapter(/*FABMainActivity mActivity*/ Context context, ArrayList<CropMasterEntity> allCrops) {
        this.context = context;
        inflter = (LayoutInflater.from(context));
        this.allCropList = allCrops;

    }

    @Override
    public int getCount() {
        return allCropList.size();
    }

    @Override
    public Object getItem(int position) {
        return allCropList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


//        View view = convertView;
        convertView =  inflter.inflate(R.layout.emp_fab_custom_spinner_items, null);
        TextView stateText = convertView.findViewById(R.id.spinner_textView);

        stateText.setText(allCropList.get(position).getName());

        /*LayoutInflater mInflater = (LayoutInflater) getContext().getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        view = mInflater.inflate(R.layout.list_view_items, null);*/
        return convertView;
    }
}
