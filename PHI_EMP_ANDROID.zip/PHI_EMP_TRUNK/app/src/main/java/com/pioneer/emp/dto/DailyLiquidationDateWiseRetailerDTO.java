package com.pioneer.emp.dto;

import com.pioneer.parivaar.dto.DTO;

public class DailyLiquidationDateWiseRetailerDTO implements DTO {

  /*  private long pioneerSales;
    private long competitor1Sales;
    private long competitor2Sales;
    private long othersSales;
    private long totalSales;*/


    private double pioneerSales;
    private double competitor1Sales;
    private double competitor2Sales;
    private double othersSales;
    private double totalSales;

    private String geoLocation;
    private String submittedDate;
    private int isSync;
    private long id;
    private long calendarId;
    private String retailerFirmName;
    private String retailerMobileNumber;
    private String  retailerPINCode;
    private String tillDate;
    private String retailerId;




    public void setTotalSales(long totalSales) {
        this.totalSales = totalSales;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public String getSubmittedDate() {
        return submittedDate;
    }

    public void setSubmittedDate(String submittedDate) {
        this.submittedDate = submittedDate;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getCalendarId() {
        return calendarId;
    }

    public void setCalendarId(long calendarId) {
        this.calendarId = calendarId;
    }


    public String getRetailerMobileNumber() {
        return retailerMobileNumber;
    }

    public void setRetailerMobileNumber(String retailerMobileNumber) {
        this.retailerMobileNumber = retailerMobileNumber;
    }

    public String getRetailerPINCode() {
        return retailerPINCode;
    }

    public void setRetailerPINCode(String retailerPINCode) {
        this.retailerPINCode = retailerPINCode;
    }

    public String getTillDate() {
        return tillDate;
    }

    public void setTillDate(String tillDate) {
        this.tillDate = tillDate;
    }

    public String getRetailerFirmName() {
        return retailerFirmName;
    }

    public void setRetailerFirmName(String retailerFirmName) {
        this.retailerFirmName = retailerFirmName;
    }

    public String getRetailerId() {
        return retailerId;
    }

    public void setRetailerId(String retailerId) {
        this.retailerId = retailerId;
    }

    public double getPioneerSales() {
        return pioneerSales;
    }

    public void setPioneerSales(double pioneerSales) {
        this.pioneerSales = pioneerSales;
    }

    public double getCompetitor1Sales() {
        return competitor1Sales;
    }

    public void setCompetitor1Sales(double competitor1Sales) {
        this.competitor1Sales = competitor1Sales;
    }

    public double getCompetitor2Sales() {
        return competitor2Sales;
    }

    public void setCompetitor2Sales(double competitor2Sales) {
        this.competitor2Sales = competitor2Sales;
    }

    public double getOthersSales() {
        return othersSales;
    }

    public void setOthersSales(double othersSales) {
        this.othersSales = othersSales;
    }

    public double getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }
}
