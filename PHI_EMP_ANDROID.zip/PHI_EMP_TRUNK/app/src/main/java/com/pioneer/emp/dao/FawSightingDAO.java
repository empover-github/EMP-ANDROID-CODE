package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.pioneer.emp.dbHandler.DBHandler;

import com.pioneer.emp.fawSighting.FawSightingReqModel;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;


import java.util.ArrayList;
import java.util.List;

public class FawSightingDAO implements DAO {

    private final String TAG = "FawSightingDAO";
    private static FawSightingDAO fawSightingDAO;

    public static FawSightingDAO getInstance() {
        if (fawSightingDAO == null) {
            fawSightingDAO = new FawSightingDAO();
        }

        return fawSightingDAO;
    }


    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        FawSightingReqModel dto = (FawSightingReqModel) dtoObject;
        try {
            ContentValues contentValues = new ContentValues();

            contentValues.put("imageUrl", dto.getImageUrl());
            contentValues.put("diseaseId", dto.getDiseaseId());
            contentValues.put("pincode", dto.getPincode());
            contentValues.put("villageId", dto.getVillageId());
            contentValues.put("plantAge", dto.getPlantAge());
            contentValues.put("severity", dto.getSeverity());
            contentValues.put("latlongValues", dto.getLatlongValues());
            contentValues.put("submittedDate", dto.getSubmittedDate());
            contentValues.put("reportedId", dto.getReportedId());
            contentValues.put("mdrCustomerId", dto.getMdrCustomerId());
            contentValues.put("mdrMobileNumer", dto.getMdrMobileNumer());
            contentValues.put("mdrName", dto.getMdrName());
            contentValues.put("isSync", dto.getIsSync());
            contentValues.put("villageName", dto.getVillageName());
            contentValues.put("surveyNo", dto.getSurveyNo());
            contentValues.put("fieldScientist", dto.getFieldScientist());
            contentValues.put("phoneModel", dto.getPhoneModel());
            contentValues.put("phoneManufacturer", dto.getPhoneManufacturer());
            contentValues.put("phoneProduct", dto.getPhoneProduct());

            long rowAffected = dbObject.insert(DBHandler.TABLE_FAW_SIGHTING, null, contentValues);
            if (rowAffected > 0)
                return "inserted";

        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "inserted";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            FawSightingReqModel dto = (FawSightingReqModel) dtoObject;

            ContentValues contentValues = new ContentValues();

            if (dto.getImageUrl() != null)
                contentValues.put("imageUrl", dto.getImageUrl());

            if (dto.getDiseaseId() != 0)
                contentValues.put("diseaseId", dto.getDiseaseId());

            if (dto.getPincode() != null)
                contentValues.put("pincode", dto.getPincode());

            if (dto.getVillageId() != 0)
                contentValues.put("villageId", dto.getVillageId());

            if (dto.getPlantAge() != null)
                contentValues.put("plantAge", dto.getPlantAge());

            if (dto.getSeverity() != null)
                contentValues.put("severity", dto.getSeverity());

            if (dto.getLatlongValues() != null)
                contentValues.put("latlongValues", dto.getLatlongValues());

            if (dto.getSubmittedDate() != null)
                contentValues.put("submittedDate", dto.getSubmittedDate());

            if (dto.getReportedId() != null)
                contentValues.put("reportedId", dto.getReportedId());

            if (dto.getMdrCustomerId() != null)
                contentValues.put("mdrCustomerId", dto.getMdrCustomerId());

            if (dto.getMdrMobileNumer() != null)
                contentValues.put("mdrMobileNumer", dto.getMdrMobileNumer());

            if (dto.getMdrName() != null)
                contentValues.put("mdrName", dto.getMdrName());

            if (dto.getIsSync() != 0)
                contentValues.put("isSync", dto.getIsSync());

            if (dto.getVillageName() != null)
                contentValues.put("villageName", dto.getVillageName());

            if (dto.getSurveyNo() != null)
                contentValues.put("surveyNo", dto.getSurveyNo());

            if (dto.getFieldScientist() != null)
                contentValues.put("fieldScientist", dto.getFieldScientist());

            if (dto.getPhoneModel() != null)
                contentValues.put("phoneModel", dto.getPhoneModel());

            if (dto.getPhoneManufacturer() != null)
                contentValues.put("phoneManufacturer", dto.getPhoneManufacturer());

            if (dto.getPhoneProduct() != null)
                contentValues.put("phoneProduct", dto.getPhoneProduct());

            dbObject.update(DBHandler.TABLE_FAW_SIGHTING, contentValues, "id=' " + dto.getId() + " ' ", null);
        } catch (SQLException e) {
            BuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;

    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> dtoList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_FAW_SIGHTING, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    FawSightingReqModel dto = new FawSightingReqModel();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setImageUrl(cursor.getString(cursor.getColumnIndex("imageUrl")));
                    dto.setDiseaseId(cursor.getLong(cursor.getColumnIndex("diseaseId")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pinCode")));
                    dto.setVillageId(cursor.getLong(cursor.getColumnIndex("villageId")));
                    dto.setPlantAge(cursor.getString(cursor.getColumnIndex("plantAge")));
                    dto.setSeverity(cursor.getString(cursor.getColumnIndex("severity")));
                    dto.setLatlongValues(cursor.getString(cursor.getColumnIndex("latlongValues")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setReportedId(cursor.getString(cursor.getColumnIndex("reportedId")));
                    dto.setMdrCustomerId(cursor.getString(cursor.getColumnIndex("mdrCustomerId")));
                    dto.setMdrMobileNumer(cursor.getString(cursor.getColumnIndex("mdrMobileNumer")));
                    dto.setMdrName(cursor.getString(cursor.getColumnIndex("mdrName")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));

                    dto.setSurveyNo(cursor.getString(cursor.getColumnIndex("surveyNo")));
                    dto.setFieldScientist(cursor.getString(cursor.getColumnIndex("fieldScientist")));
                    dto.setPhoneModel(cursor.getString(cursor.getColumnIndex("phoneModel")));
                    dto.setPhoneManufacturer(cursor.getString(cursor.getColumnIndex("phoneManufacturer")));
                    dto.setPhoneProduct(cursor.getString(cursor.getColumnIndex("phoneProduct")));

                    dtoList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dtoList;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_FAW_SIGHTING).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public ArrayList<FawSightingReqModel> getRecordsForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        ArrayList<FawSightingReqModel> fawSightingInfo = new ArrayList<>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_FAW_SIGHTING + " WHERE isSync = '1'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                FawSightingReqModel dto;
                do {
                    dto = new FawSightingReqModel();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setImageUrl(cursor.getString(cursor.getColumnIndex("imageUrl")));
                    dto.setDiseaseId(cursor.getLong(cursor.getColumnIndex("diseaseId")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setVillageId(cursor.getLong(cursor.getColumnIndex("villageId")));
                    dto.setPlantAge(cursor.getString(cursor.getColumnIndex("plantAge")));
                    dto.setSeverity(cursor.getString(cursor.getColumnIndex("severity")));
                    dto.setLatlongValues(cursor.getString(cursor.getColumnIndex("latlongValues")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setReportedId(cursor.getString(cursor.getColumnIndex("reportedId")));
                    dto.setMdrCustomerId(cursor.getString(cursor.getColumnIndex("mdrCustomerId")));
                    dto.setMdrMobileNumer(cursor.getString(cursor.getColumnIndex("mdrMobileNumer")));
                    dto.setMdrName(cursor.getString(cursor.getColumnIndex("mdrName")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));

                    dto.setSurveyNo(cursor.getString(cursor.getColumnIndex("surveyNo")));
                    dto.setFieldScientist(cursor.getString(cursor.getColumnIndex("fieldScientist")));
                    dto.setPhoneModel(cursor.getString(cursor.getColumnIndex("phoneModel")));
                    dto.setPhoneManufacturer(cursor.getString(cursor.getColumnIndex("phoneManufacturer")));
                    dto.setPhoneProduct(cursor.getString(cursor.getColumnIndex("phoneProduct")));

                    fawSightingInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return fawSightingInfo;
    }

    public FawSightingReqModel getRecordById(long id, SQLiteDatabase dbObject) {
        FawSightingReqModel dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + DBHandler.TABLE_FAW_SIGHTING + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new FawSightingReqModel();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setImageUrl(cursor.getString(cursor.getColumnIndex("imageUrl")));
                    dto.setDiseaseId(cursor.getLong(cursor.getColumnIndex("diseaseId")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setVillageId(cursor.getLong(cursor.getColumnIndex("villageId")));
                    dto.setPlantAge(cursor.getString(cursor.getColumnIndex("plantAge")));
                    dto.setSeverity(cursor.getString(cursor.getColumnIndex("severity")));
                    dto.setLatlongValues(cursor.getString(cursor.getColumnIndex("latlongValues")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setReportedId(cursor.getString(cursor.getColumnIndex("reportedId")));
                    dto.setMdrCustomerId(cursor.getString(cursor.getColumnIndex("mdrCustomerId")));
                    dto.setMdrMobileNumer(cursor.getString(cursor.getColumnIndex("mdrMobileNumer")));
                    dto.setMdrName(cursor.getString(cursor.getColumnIndex("mdrName")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));

                    dto.setSurveyNo(cursor.getString(cursor.getColumnIndex("surveyNo")));
                    dto.setFieldScientist(cursor.getString(cursor.getColumnIndex("fieldScientist")));
                    dto.setPhoneModel(cursor.getString(cursor.getColumnIndex("phoneModel")));
                    dto.setPhoneManufacturer(cursor.getString(cursor.getColumnIndex("phoneManufacturer")));
                    dto.setPhoneProduct(cursor.getString(cursor.getColumnIndex("phoneProduct")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }

    public boolean deleteRecordByImgUrl(String imgUrl, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("DELETE FROM " + DBHandler.TABLE_FAW_SIGHTING + " where imageUrl='" + imgUrl + "'");
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {
            dbObject.close();
        }
        return false;
    }


}
