package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.R;
import com.pioneer.emp.dto.CouponListDTO;

import java.util.ArrayList;

/**
 * Created by hareesh.a on 7/11/2017.
 */

public class CouponListAdapter extends RecyclerView.Adapter<CouponListAdapter.viewHolder> {
    private Context context;
    private ArrayList<CouponListDTO> couponslistDTOArrayList;
    private final OnBookletClickListener listener;

    public CouponListAdapter(Context context, ArrayList<CouponListDTO> couponslistDTOArrayList, OnBookletClickListener listener) {
        this.context = context;
        this.couponslistDTOArrayList = couponslistDTOArrayList;
        this.listener = listener;
    }

    @Override
    public viewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View messageView = LayoutInflater.from(parent.getContext()).inflate(R.layout.emp_coupon_list_recycle, parent, false);
        return new viewHolder(messageView);
    }

    @Override
    public void onBindViewHolder(viewHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return couponslistDTOArrayList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        EditText couponNumber;
        ImageView information, share;

        public viewHolder(View view) {
            super(view);
            couponNumber = view.findViewById(R.id.cl_coupon_data);
            information = view.findViewById(R.id.cl_coupon_details);
            share = view.findViewById(R.id.cl_coupon_share);
        }

        void bind(final int position) {
            CouponListDTO couponListDTO = couponslistDTOArrayList.get(position);
            if (couponListDTO.getShared()) {
                couponNumber.setText(couponListDTO.getCouponNumber());
                information.setVisibility(View.VISIBLE);
                information.setTag(position);
                information.setOnClickListener(this);
                share.setBackgroundResource(R.drawable.share_disable);
                share.setClickable(false);
                share.setEnabled(false);
            } else {
                couponNumber.setText(couponListDTO.getCouponNumber());
                information.setVisibility(View.INVISIBLE);
                share.setClickable(true);
                share.setEnabled(true);
                share.setBackgroundResource(R.drawable.emp_share);
                share.setTag(position);
                share.setOnClickListener(this);
            }
        }

        @Override
        public void onClick(View v) {
            int position = (int) v.getTag();
            listener.onItemClick(v, position);
        }
    }
}
