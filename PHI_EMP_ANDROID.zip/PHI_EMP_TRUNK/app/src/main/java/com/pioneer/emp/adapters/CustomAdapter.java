package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.parivaar.model.IdNameModel;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<IdNameModel> {

    LayoutInflater flater;

    public CustomAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<IdNameModel> objects) {
        super(context, resource, textViewResourceId, objects);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        return rowview(convertView,position);
    }
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return rowview(convertView,position);
    }

    private View rowview(View convertView , int position){

        IdNameModel name = getItem(position);

        viewHolder holder ;
        View rowview = convertView;
        if (rowview==null) {

            holder = new viewHolder();
            flater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowview =flater.inflate(R.layout.custom_adapter_spinner_textview_align,null, false);

            holder.txtTitle = rowview.findViewById(R.id.textView1);
            rowview.setTag(holder);
        }else{
            holder = (viewHolder) rowview.getTag();
        }
        holder.txtTitle.setText(name.getName());

        return rowview;
    }

    private class viewHolder{
        TextView txtTitle;
    }
}
