package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dto.CropDiagnosisMasterDataUploadDTO;

import java.util.ArrayList;

/**
 * Created by fatima.t on 10-10-2018.
 */

public class CDmasterPendingUploadAdapter extends RecyclerView.Adapter<CDmasterPendingUploadAdapter.MyPlaceHolder> {
    Context context;
    ArrayList<CropDiagnosisMasterDataUploadDTO> subscriptionList;


    public CDmasterPendingUploadAdapter(Context context, ArrayList<CropDiagnosisMasterDataUploadDTO> subscriptionList) {
        this.context = context;
        this.subscriptionList = subscriptionList;
    }

    @Override
    public MyPlaceHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.cd_master_pending_list_item,parent,false);
        return new MyPlaceHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MyPlaceHolder holder, int position) {
        holder.bind(subscriptionList.get(position));
    }

    @Override
    public int getItemCount() {
        return subscriptionList.size();
    }

    public class MyPlaceHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView cropDiseaseTv, pendingTv, timeTv;
        public MyPlaceHolder(View view) {
            super(view);

            cropDiseaseTv = view.findViewById(R.id.cdmp_crop_diseaseNameTv);
            pendingTv = view.findViewById(R.id.cdmp_pendingTv);
            timeTv = view.findViewById(R.id.cdmp_timeTv);
        }

        public void bind(final CropDiagnosisMasterDataUploadDTO model ) {
            String cropDiseaseSt = model.getCropName() + "-" + model.getDiseaseClassificationName();
            cropDiseaseTv.setText(cropDiseaseSt);
            String pendingText = model.getImagePending() + " Image(s) pending to upload" ;
            pendingTv.setText(pendingText);
            timeTv.setText(model.getTransactionTime());
        }

        @Override
        public void onClick(View v) {
            // DO your stuff
//            listener.onItemClick(v, getAdapterPosition());

        }
    }
}
