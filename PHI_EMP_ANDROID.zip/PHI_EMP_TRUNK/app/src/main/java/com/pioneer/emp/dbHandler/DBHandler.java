package com.pioneer.emp.dbHandler;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.pioneer.parivaar.utils.BuildLog;

/**
 * Created by rambabu.a on 29-11-2016.
 */
public class DBHandler extends SQLiteOpenHelper {

    private final String TAG = "DBHandler";
    private static final String DATABASE_NAME = "PRetailer.db";
    public static final int DATABASE_VERSION = 11; // changed from 10-11 as added FAW sighting new columns
    private static Context context;
    private static DBHandler dbHandler;
    public static String TABLE_PENDING_COUPONS = "PendingCoupons";
    public static String TABLE_VOLUME_PLANNER = "VolumePlanner";
    public static String TABLE_CURRENT_YEAR_MEMBERSHIP = "CurrentYearMembership";
    //    public static String TABLE_ALL_YEAR = "AllYear";
    public static String TABLE_YEAR_COMPARISION = "YearComparision";
    public static String TABLE_COUPAN_LOG = "CoupanLog";
    public static String TABLE_PAYBACK = "PayBack";
    public static String TABLE_RETAILER_NOTIFICATION_LOG = "RetailerNotificationLog";
    public static String TABLE_EMP_CROP_ADVISORY_MASTER = "EmpCropAdvisoryMaster";
    public static String TABLE_EMP_CROP_ADVISORY_STAGES = "EmpCropAdvisoryStages";
    public static String TABLE_DISEASE_PRESCRIPTION = "DiseasePrescription";
    public static String TABLE_AGRO_DISEASE_PRODUCT_MAPPING = "AgroDiseaseProductMapping";

    public static String TABLE_TBL_WEEKLY_LIQUIDATION = "TblWeeklyLiquidation";
    public static String TABLE_TBL_WL_SEASON_MASTER = "TblWlSeason";
    public static String TABLE_TBL_WL_CROP_MASTER = "TblWlCrop";
    public static String TABLE_TBL_WL_HYBRID_MASTER = "TblWlHybrid";

    public static String TABLE_FAB_MASTER = "ParivaarFabMaster";
    public static String TABLE_FAB_MASTER_TEMP = "ParivaarFabMasterTemp";

    public static String TABLE_CA_MASTER_TEMP = "ParivaarCropAdvisoryTemp";
    // newly added for FarmServices
    public static String TABLE_MECH_EQUIPMENT_PROVIDER = "EquipmentProvider";

    public static String TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD = "CropDiagnosisMatserDataUpload";
    public static String TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA = "CropDiagnosisMatserData";
    public static String TABLE_DISEASE_NAME_MASTER = "DiseaseNameMaster";
    public static String TABLE_UPLOAD_IMAGES = "UploadImages";
    public static String TABLE_IMAGES_UPLOAD = "ImagesUpload";

    public static String TABLE_CROP = "Crop";
    public static String TABLE_SEASON = "Season";
    public static String TABLE_COMPETITOR = "Competitor";
    public static String TABLE_HYBRID = "Hybrid";
    public static String TABLE_SEASON_LIQUID = "SeasonLiquidation";
    public static String TABLE_CROP_LIQUID = "CropLiquidation";
    public static String TABLE_COMPETITOR_LIQUID = "CompetitorLiquidation";
    public static String TABLE_DAILY_LIQUIDATION_CALENDAR = "DailyLiquidationCalendar";
    public static String TABLE_DAILY_LIQUIDATION_TILL_SALES = "DailyLiquidationTillDateSales";
    public static String TABLE_DAILY_LIQUIDATION_RETAILERS_SALES = "DailyLiquidationTopRetailersSales";
    public static String TABLE_DAILY_LIQUIDATION_SALES_MASTER = "DailyLiquidationSalesMaster";
    public static String TABLE_FS_DIVISION = "FarmerSegmentationDivision";
    public static String TABLE_FS_SCHOOL = "FarmerSegmentationSchool";

    public static String TABLE_DAILY_LIQUIDATION_RETAILER_MASTER = "DailyLiquidationRetailerMaster";
    public static String TABLE_DAILY_LIQUIDATION_TOP_TEN_RETAILER_VOLUME = "DailyLiquidationTopTenRetailersVolume";
    public static String TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES = "DailyLiquidationDateWiseRetailerSale";
    //newly added  for Faw
    public static String TABLE_FAW_SIGHTING = "FawSighting";
    public static String TABLE_DISEASE_MASTER = "DiseaseMaster";
    public static String TABLE_PLANTAGE_MASTER = "PlantageMaster";
    public static String TABLE_VILAGE_MASTER = "VillageMaster";
    public static String TABLE_FAW_SEVERITY_IMAGE_MASTER = "FawSeverityImagesMaster";

    public static DBHandler getInstance(Context context2) {
        if (dbHandler == null) {
            context = context2;
            dbHandler = new DBHandler(context2);
        }
        return dbHandler;
    }

    public static SQLiteDatabase getReadableDb(Context context) {
        return getInstance(context).getReadableDatabase();
    }

    public static SQLiteDatabase getWritableDb(Context context) {
        return getInstance(context).getWritableDatabase();
    }

    public SQLiteDatabase getDBObject(int isWritable) {
        return (isWritable == 1) ? this.getWritableDatabase() : this.getReadableDatabase();
    }

    /**
     * Constructor
     *
     * @param context :Interface to global information about an application
     *                environment.
     */
    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        BuildLog.d("Database operations", "Database is created");
    }

    /**
     * Called when the database is created for the first time. This is where the
     * creation of tables and the initial population of the tables should
     * happen.
     *
     * @param db : The database.
     */

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_PENDING_COUPONS + "(couponCode TEXT, couponDesc TEXT, mode TEXT, sync NUMBER, MobileNo TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_VOLUME_PLANNER + "(ValumePlanerYear NUMBER, VolumePerKG NUMBER, Tire TEXT,ProgramEligibility TEXT, BaseptsPerKG NUMBER, BonusPts NUMBER, CreatedDate TEXT, ModifiedDate TEXT, Status TEXT, TireCode TEXT, TireId NUMBER)");

        db.execSQL("CREATE TABLE " + TABLE_CURRENT_YEAR_MEMBERSHIP + "(Name_Of_The_Firm TEXT,Territory_Name TEXT, Block TEXT, Region_Name TEXT, Zone_Name TEXT, MobileNo NUMBER, Pincode NUMBER, Retailer TEXT, Year NUMBER, PHISales NUMBER, BasePoints NUMBER, MembershipTier TEXT, BonusPoints NUMBER, TotalPoints NUMBER, ModifiedDate TEXT, TBLName TEXT, TireCode TEXT)");

//        db.execSQL("CREATE TABLE "+TABLE_ALL_YEAR+"(Name_Of_The_Firm TEXT,Territory_Name TEXT, Block TEXT, Region_Name TEXT, Zone_Name TEXT, MobileNo NUMBER, Pincode NUMBER, Retailer TEXT, Year NUMBER, PHISales NUMBER, BasePoints NUMBER, MembershipTier TEXT, BonusPoints NUMBER, TotalPoints NUMBER, ModifiedDate TEXT, TBLName TEXT, TireCode TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_COUPAN_LOG + "(Coupon_No TEXT, Remarks TEXT, Transactiondate TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_RETAILER_NOTIFICATION_LOG + "(Id NUMBER, Cust_Id TEXT, MobileNo TEXT, Message TEXT, CreatedDate TEXT, Status TEXT)");
//        db.execSQL("CREATE TABLE "+TABLE_PAYBACK+"(what are columns names, which to store. Confusion)");

        db.execSQL("CREATE TABLE " + TABLE_EMP_CROP_ADVISORY_MASTER + " (id NUMBER, endDate TEXT, startDate TEXT, name TEXT, categoryId TEXT, categoryName TEXT, cropId TEXT, cropName TEXT, hybridId TEXT, hybridName TEXT, seasonId TEXT, seasonName TEXT, stateId TEXT, stateName TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_EMP_CROP_ADVISORY_STAGES + " (idStage NUMBER, cropAdvisoryId NUMBER, message TEXT, noOfDays TEXT, stageName TEXT, messageInLocalLang TEXT, voiceFileName TEXT, voiceFileLocalPath TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_CA_MASTER_TEMP + "(_id integer PRIMARY KEY AUTOINCREMENT, idStage TEXT, category TEXT, url TEXT, type TEXT, tag TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_FAB_MASTER + "(id TEXT, version TEXT, state TEXT, stateId TEXT, crop TEXT, cropId TEXT, hybrid TEXT, hybridId TEXT, season TEXT, seasonId TEXT, f_pdfFile TEXT, f_voiceFile TEXT, f_videoFile TEXT, f_images TEXT, f_message TEXT, f_localLangMessage TEXT, a_pdfFile TEXT, a_voiceFile TEXT, a_videoFile TEXT, a_images TEXT, a_message TEXT, a_localLangMessage TEXT, b_pdfFile TEXT, b_voiceFile TEXT, b_videoFile TEXT, b_images TEXT, b_message TEXT, b_localLangMessage TEXT, f_pdfFile_local TEXT, f_voiceFile_local TEXT, f_videoFile_local TEXT, f_images_local TEXT, f_message_local TEXT, f_localLangMessage_local TEXT, a_pdfFile_local TEXT, a_voiceFile_local TEXT, a_videoFile_local TEXT, a_images_local TEXT, a_message_local TEXT, a_localLangMessage_local TEXT, b_pdfFile_local TEXT, b_voiceFile_local TEXT, b_videoFile_local TEXT, b_images_local TEXT, b_message_local TEXT, b_localLangMessage_local TEXT, description TEXT, f_image_tags TEXT, a_image_tags TEXT, b_image_tags TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_FAB_MASTER_TEMP + "(_id integer PRIMARY KEY AUTOINCREMENT, id TEXT, category TEXT, url TEXT, type TEXT, tag TEXT)");

        // new tables added for Farmservices in db version 2
        db.execSQL("CREATE TABLE " + TABLE_MECH_EQUIPMENT_PROVIDER + "(id integer PRIMARY KEY AUTOINCREMENT,image_url TEXT,equipmentId NUMBER)");
        db.execSQL("CREATE TABLE " + TABLE_DISEASE_PRESCRIPTION + "(id TEXT, diseaseId TEXT, diseaseName TEXT, diseaseBiologicalName TEXT, crop TEXT, diseaseType TEXT, hosts TEXT, inANutshell TEXT, symptoms TEXT, trigger TEXT, preventiveMeasures TEXT, biologicalControl TEXT, chemicalControl TEXT, hazadDescription TEXT, diseaseImageFile TEXT, active TEXT, deleted TEXT, productMapping TEXT, productMappingImage TEXT, createdOn TEXT, updatedOn TEXT, status TEXT, cdi_images_local TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_AGRO_DISEASE_PRODUCT_MAPPING + "(id TEXT, productName TEXT, character TEXT, work TEXT, productUse TEXT, caution TEXT, resultAndEffect TEXT, type TEXT, productImage TEXT, active TEXT, deleted TEXT, createdOn TEXT, updatedOn TEXT, status TEXT, agro_images_local TEXT, cropAndDiseaseNamesForMobile TEXT)");

        // new tables added for Retail Audit in db version 3
        db.execSQL("CREATE TABLE " + TABLE_CROP + "(id NUMBER, name TEXT, seasonId NUMBER);");
        db.execSQL("CREATE TABLE " + TABLE_SEASON + "(id NUMBER, name TEXT);");
        db.execSQL("CREATE TABLE " + TABLE_COMPETITOR + "(id NUMBER, name TEXT);");
        db.execSQL("CREATE TABLE " + TABLE_HYBRID + "(id NUMBER, name TEXT, cropId NUMBER);");

        db.execSQL("CREATE TABLE MASTER_CU(id NUMBER, name TEXT);");
        db.execSQL("CREATE TABLE MASTER_REGION(id NUMBER, name TEXT, cuId NUMBER);");
        db.execSQL("CREATE TABLE MASTER_TERRITORY(id NUMBER, name TEXT, regionId NUMBER);");
        db.execSQL("CREATE TABLE MASTER_BLOCK(name TEXT, territoryName TEXT);");
        db.execSQL("CREATE TABLE MASTER_PINCODE(pinCode NUMBER, blockName TEXT, territoryId NUMBER);");

        db.execSQL("CREATE TABLE RETAIL_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, year NUMBER, mobileNo TEXT, pincode NUMBER, cuId TEXT, " +
                "cuName TEXT, regionId TEXT, regionName TEXT, territoryId TEXT, territoryName TEXT, blockId TEXT, blockName TEXT, retailerId TEXT, retailerName TEXT, " +
                "seasonId TEXT, seasonName TEXT, cropId TEXT, cropName TEXT, totalPHIVolume NUMBER, totalNSCompetitor NUMBER, totalNSPHI NUMBER, highestVillage1 TEXT," +
                "highestVillage2 TEXT, highestVillage3 TEXT, isDistributor TEXT, isSync NUMBER, captureTime TEXT, geoLocation TEXT, localImagePath TEXT);");
        db.execSQL("CREATE TABLE PHIHYBRIDS_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, name TEXT, volume NUMBER, auditId NUMBER);");
        db.execSQL("CREATE TABLE COMPETITOR_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, name TEXT, totalVolume NUMBER, majorHybrid TEXT, auditId NUMBER);");
        db.execSQL("CREATE TABLE DISTRIBUTOR_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, name TEXT, totalSale NUMBER, wholeSale NUMBER, retailSale NUMBER, auditId NUMBER);");
        // namePreferred TEXT, nameMajorCompany TEXT

        //new table creation for Retail audit images in version 4
        db.execSQL("CREATE TABLE UPLOAD_FILE_RETAIL_AUDIT (id INTEGER PRIMARY KEY AUTOINCREMENT,url TEXT,isSync NUMBER,userServerId TEXT)");
        // new table creation for Retail audit prefered
        db.execSQL("CREATE TABLE PREFERRED_DISTRIBUTOR_AUDIT(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,company TEXT, auditId NUMBER)");

        /*// commenting this because it is not need for 2018 year
    	// version 5
	    db.execSQL("CREATE TABLE " + TABLE_TBL_WEEKLY_LIQUIDATION + "(mobileId integer PRIMARY KEY AUTOINCREMENT, territoryId TEXT, territoryName TEXT, currentYear TEXT, seasonId TEXT, seasonName TEXT, cropId TEXT, cropName TEXT, hybridId TEXT, hybridName TEXT, invoiceQuantity TEXT, netReturns TEXT, liquidation TEXT, mobileSubmittedDate TEXT, sync NUMBER)");
	    db.execSQL("CREATE TABLE " + TABLE_TBL_WL_SEASON_MASTER + "(id NUMBER, name TEXT)");
	    db.execSQL("CREATE TABLE " + TABLE_TBL_WL_CROP_MASTER + "(id NUMBER, name TEXT)");
	    db.execSQL("CREATE TABLE " + TABLE_TBL_WL_HYBRID_MASTER + "(id NUMBER, name TEXT, cropId NUMBER)");*/

        // version 7 - CROP DIAGNOSIS MASTER DATA UPLOAD
        db.execSQL("CREATE TABLE " + TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + "(id INTEGER PRIMARY KEY AUTOINCREMENT, cropId NUMBER, cropName TEXT, diseaseClassificationId NUMBER, diseaseClassificationName TEXT, tags TEXT, imageUrls TEXT, latLongValues TEXT, address TEXT, imgTotCount NUMBER,status NUMBER, serverId NUMBER, transactionTime TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_UPLOAD_IMAGES + "(imageId INTEGER PRIMARY KEY AUTOINCREMENT, imagePath TEXT, serverId NUMBER)");
        db.execSQL("CREATE TABLE " + TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA + "(id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_DISEASE_NAME_MASTER + "(id NUMBER, diseaseName TEXT)");
        //newly created
        db.execSQL("CREATE TABLE " + TABLE_SEASON_LIQUID + "(id NUMBER, name TEXT);");
        db.execSQL("CREATE TABLE " + TABLE_CROP_LIQUID + "( id NUMBER,name TEXT, seasonId NUMBER);");
        db.execSQL("CREATE TABLE " + TABLE_COMPETITOR_LIQUID + "(id NUMBER, name TEXT);");

        db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_CALENDAR + "(calendarId NUMBER, year TEXT, seasonName TEXT, cropName TEXT, startDate TEXT, endDate TEXT, competitor1Name TEXT, competitor2Name TEXT, status NUMBER);");
        db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_TILL_SALES + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER, pioneerSales NUMBER, competitor1Sales NUMBER, competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, tillDate TEXT, geoLocation TEXT, submittedDate TEXT, isSync NUMBER);");
        db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER, pioneerSales NUMBER, competitor1Sales NUMBER,competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, isSync NUMBER);");
        db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_SALES_MASTER + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER, pioneerSales NUMBER, competitor1Sales NUMBER, competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, isSync NUMBER);");

        //newly added
        db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_RETAILER_MASTER + "(retailerId TEXT, retailerFirmName TEXT,retailerPINCode TEXT,retailerMobileNumber TEXT);");

        db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_TOP_TEN_RETAILER_VOLUME + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER,retailerId TEXT, pioneerSales NUMBER, competitor1Sales NUMBER,competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, isSync NUMBER, retailerFirmName TEXT, retailerPINCode TEXT, retailerMobileNumber TEXT,tillDate TEXT);");
        db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + "(id integer PRIMARY KEY AUTOINCREMENT, retailerId TEXT,retailerFirmName TEXT,retailerPINCode TEXT,retailerMobileNumber TEXT, pioneerSales NUMBER,competitor1Sales NUMBER,competitor2Sales NUMBER,othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, tillDate TEXT,isSync NUMBER ,calendarId NUMBER);");

        //new added For Faw
        db.execSQL("CREATE TABLE " + TABLE_FAW_SIGHTING + "(id integer PRIMARY KEY AUTOINCREMENT, imageUrl TEXT, diseaseId NUMBER, pincode TEXT, villageId NUMBER, plantAge TEXT, severity TEXT, latlongValues TEXT, submittedDate TEXT, reportedId TEXT, mdrCustomerId TEXT, mdrMobileNumer TEXT, mdrName TEXT, isSync NUMBER, villageName TEXT, surveyNo TEXT, fieldScientist TEXT, phoneModel TEXT, phoneManufacturer TEXT, phoneProduct TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_DISEASE_MASTER + "(id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_PLANTAGE_MASTER + "(id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_VILAGE_MASTER + "(id NUMBER, name TEXT,pincode TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_IMAGES_UPLOAD + "(imageId INTEGER PRIMARY KEY AUTOINCREMENT, imagePath TEXT, serverId NUMBER, moduleType TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_FAW_SEVERITY_IMAGE_MASTER + "(priority TEXT, fawImageUrl TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        switch (oldVersion) {
            case 1:
                db.execSQL("Drop Table IF EXISTS CounterShare");
                db.execSQL("Drop Table IF EXISTS AllYear");
                db.execSQL("CREATE TABLE " + TABLE_MECH_EQUIPMENT_PROVIDER + "(id integer PRIMARY KEY AUTOINCREMENT,image_url TEXT,equipmentId NUMBER)");
                db.execSQL("CREATE TABLE " + TABLE_DISEASE_PRESCRIPTION + "(id TEXT, diseaseId TEXT, diseaseName TEXT, diseaseBiologicalName TEXT, crop TEXT, diseaseType TEXT, hosts TEXT, inANutshell TEXT, symptoms TEXT, trigger TEXT, preventiveMeasures TEXT, biologicalControl TEXT, chemicalControl TEXT, hazadDescription TEXT, diseaseImageFile TEXT, active TEXT, deleted TEXT, productMapping TEXT, productMappingImage TEXT, createdOn TEXT, updatedOn TEXT, status TEXT, cdi_images_local TEXT)");
                db.execSQL("CREATE TABLE " + TABLE_AGRO_DISEASE_PRODUCT_MAPPING + "(id TEXT, productName TEXT, character TEXT, work TEXT, productUse TEXT, caution TEXT, resultAndEffect TEXT, type TEXT, productImage TEXT, active TEXT, deleted TEXT, createdOn TEXT, updatedOn TEXT, status TEXT, agro_images_local TEXT, cropAndDiseaseNamesForMobile TEXT)");

            case 2:
                db.execSQL("CREATE TABLE " + TABLE_CROP + "(id NUMBER, name TEXT);");
                db.execSQL("CREATE TABLE " + TABLE_SEASON + "(id NUMBER, name TEXT);");
                db.execSQL("CREATE TABLE " + TABLE_COMPETITOR + "(id NUMBER, name TEXT);");
                db.execSQL("CREATE TABLE " + TABLE_HYBRID + "(id NUMBER, name TEXT, cropId NUMBER);");

                db.execSQL("CREATE TABLE MASTER_CU(id NUMBER, name TEXT);");
                db.execSQL("CREATE TABLE MASTER_REGION(id NUMBER, name TEXT, cuId NUMBER);");
                db.execSQL("CREATE TABLE MASTER_TERRITORY(id NUMBER, name TEXT, regionId NUMBER);");
                db.execSQL("CREATE TABLE MASTER_BLOCK(name TEXT, territoryName TEXT);");
                db.execSQL("CREATE TABLE MASTER_PINCODE(pinCode NUMBER, blockName TEXT, territoryId NUMBER);");

                db.execSQL("CREATE TABLE RETAIL_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, year NUMBER, mobileNo TEXT, pincode NUMBER, cuId TEXT, " +
                        "cuName TEXT, regionId TEXT, regionName TEXT, territoryId TEXT, territoryName TEXT, blockId TEXT, blockName TEXT, retailerId TEXT, retailerName TEXT, " +
                        "seasonId TEXT, seasonName TEXT, cropId TEXT, cropName TEXT, totalPHIVolume NUMBER, totalNSCompetitor NUMBER, totalNSPHI NUMBER, highestVillage1 TEXT," +
                        "highestVillage2 TEXT, highestVillage3 TEXT, isDistributor TEXT, isSync NUMBER, captureTime TEXT, geoLocation TEXT);");
                db.execSQL("CREATE TABLE PHIHYBRIDS_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, name TEXT, volume NUMBER, auditId NUMBER);");
                db.execSQL("CREATE TABLE COMPETITOR_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, name TEXT, totalVolume NUMBER, majorHybrid TEXT, auditId NUMBER);");
                db.execSQL("CREATE TABLE DISTRIBUTOR_AUDIT(id integer PRIMARY KEY AUTOINCREMENT, name TEXT, totalSale NUMBER, wholeSale NUMBER, retailSale NUMBER, auditId NUMBER);");
            case 3:
                db.execSQL("ALTER TABLE RETAIL_AUDIT ADD COLUMN localImagePath TEXT");
                db.execSQL("CREATE TABLE UPLOAD_FILE_RETAIL_AUDIT (id INTEGER PRIMARY KEY AUTOINCREMENT,url TEXT,isSync NUMBER,userServerId TEXT)");
            /*case 4:
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_TBL_WEEKLY_LIQUIDATION + "(mobileId integer PRIMARY KEY AUTOINCREMENT, territoryId TEXT, territoryName TEXT, currentYear TEXT, seasonId TEXT, seasonName TEXT, cropId TEXT, cropName TEXT, hybridId TEXT, hybridName TEXT, invoiceQuantity TEXT, netReturns TEXT, liquidation TEXT, mobileSubmittedDate TEXT, sync NUMBER)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_TBL_WL_SEASON_MASTER + "(id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_TBL_WL_CROP_MASTER + "(id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_TBL_WL_HYBRID_MASTER + "(id NUMBER, name TEXT, cropId NUMBER)");*/
            case 4:
                db.execSQL("CREATE TABLE PREFERRED_DISTRIBUTOR_AUDIT(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,company TEXT, auditId NUMBER)");
            case 5:
                db.execSQL("ALTER TABLE " + TABLE_CROP + " ADD COLUMN seasonId NUMBER");
            case 6:
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_CROP_DIAGNOSIS_MASTER_UPLOAD + "(id INTEGER PRIMARY KEY AUTOINCREMENT, cropId NUMBER, cropName TEXT, diseaseClassificationId NUMBER, diseaseClassificationName TEXT, tags TEXT, imageUrls TEXT, latLongValues TEXT, address TEXT, imgTotCount NUMBER, status NUMBER, serverId NUMBER, transactionTime TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_UPLOAD_IMAGES + "(imageId INTEGER PRIMARY KEY AUTOINCREMENT, imagePath TEXT, serverId NUMBER)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA + "(id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_DISEASE_NAME_MASTER + "(id NUMBER, diseaseName TEXT)");
            case 7:
                db.execSQL("CREATE TABLE " + TABLE_SEASON_LIQUID + "(id NUMBER, name TEXT);");
                db.execSQL("CREATE TABLE " + TABLE_CROP_LIQUID + "( id NUMBER,name TEXT, seasonId NUMBER);");
                db.execSQL("CREATE TABLE " + TABLE_COMPETITOR_LIQUID + "(id NUMBER, name TEXT);");

                db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_CALENDAR + "(calendarId NUMBER, year TEXT, seasonName TEXT, cropName TEXT, startDate TEXT, endDate TEXT, competitor1Name TEXT, competitor2Name TEXT, status NUMBER);");
                db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_TILL_SALES + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER, pioneerSales NUMBER, competitor1Sales NUMBER, competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, tillDate TEXT, geoLocation TEXT, submittedDate TEXT, isSync NUMBER);");
                db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER, pioneerSales NUMBER, competitor1Sales NUMBER,competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, isSync NUMBER);");
                db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_SALES_MASTER + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER, pioneerSales NUMBER, competitor1Sales NUMBER, competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, isSync NUMBER);");
            case 8:
                db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_RETAILER_MASTER + "(retailerId TEXT, retailerFirmName TEXT,retailerPINCode TEXT,retailerMobileNumber TEXT);");
                db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_TOP_TEN_RETAILER_VOLUME + "(id integer PRIMARY KEY AUTOINCREMENT, calendarId NUMBER,retailerId TEXT, pioneerSales NUMBER, competitor1Sales NUMBER,competitor2Sales NUMBER, othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, isSync NUMBER, retailerFirmName TEXT, retailerPINCode TEXT, retailerMobileNumber TEXT,tillDate TEXT);");
                db.execSQL("CREATE TABLE " + TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + "(id integer PRIMARY KEY AUTOINCREMENT, retailerId TEXT,retailerFirmName TEXT,retailerPINCode TEXT,retailerMobileNumber TEXT, pioneerSales NUMBER,competitor1Sales NUMBER,competitor2Sales NUMBER,othersSales NUMBER, totalSales NUMBER, geoLocation TEXT, submittedDate TEXT, tillDate TEXT,isSync NUMBER ,calendarId NUMBER);");
            case 9:
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_FAW_SIGHTING + "(id integer PRIMARY KEY AUTOINCREMENT, imageUrl TEXT, diseaseId NUMBER, pincode TEXT, villageId NUMBER, plantAge TEXT, severity TEXT, latlongValues TEXT, submittedDate TEXT, reportedId TEXT, mdrCustomerId TEXT, mdrMobileNumer TEXT, mdrName TEXT, isSync NUMBER,villageName TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_DISEASE_MASTER + "(id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_PLANTAGE_MASTER + "(id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_VILAGE_MASTER + "(id NUMBER, name TEXT,pincode TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_IMAGES_UPLOAD + "(imageId INTEGER PRIMARY KEY AUTOINCREMENT, imagePath TEXT, serverId NUMBER, moduleType TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_FAW_SEVERITY_IMAGE_MASTER + "(priority TEXT, fawImageUrl TEXT)");
            case 10:
                db.execSQL("ALTER TABLE " + TABLE_FAW_SIGHTING + " ADD COLUMN surveyNo TEXT");
                db.execSQL("ALTER TABLE " + TABLE_FAW_SIGHTING + " ADD COLUMN fieldScientist TEXT");
                db.execSQL("ALTER TABLE " + TABLE_FAW_SIGHTING + " ADD COLUMN phoneModel TEXT");
                db.execSQL("ALTER TABLE " + TABLE_FAW_SIGHTING + " ADD COLUMN phoneManufacturer TEXT");
                db.execSQL("ALTER TABLE " + TABLE_FAW_SIGHTING + " ADD COLUMN phoneProduct TEXT");

        }
    }
}

