package com.pioneer.emp.dto;

import com.pioneer.parivaar.dto.DTO;

import java.io.Serializable;

/**
 * Created by fatima.t on 11-04-2018.
 */
public class MdrEvaluationReportDTO implements DTO, Serializable {
    private String name;
    private String pendingCount;
    private String evaluatedCount;
    private String averageScore;

    private String mdrEmployeeId;
    private String nineBoxScore;
    private String status;
    private long id;

    public MdrEvaluationReportDTO(String name, String pendingCount, String evaluatedCount, String averageScore,String mdrEmployeeId, String nineBoxScore, String status) {
        this.name = name;
        this.pendingCount = pendingCount;
        this.evaluatedCount = evaluatedCount;
        this.averageScore= averageScore;
        this.mdrEmployeeId = mdrEmployeeId;
        this.nineBoxScore = nineBoxScore;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPendingCount() {
        return pendingCount;
    }

    public void setPendingCount(String pendingCount) {
        this.pendingCount = pendingCount;
    }

    public String getEvaluatedCount() {
        return evaluatedCount;
    }

    public void setEvaluatedCount(String evaluatedCount) {
        this.evaluatedCount = evaluatedCount;
    }

    public String getAverageScore() {
        return averageScore;
    }

    public void setAverageScore(String averageScore) {
        this.averageScore = averageScore;
    }

    public String getMdrEmployeeId() {
        return mdrEmployeeId;
    }

    public void setMdrEmployeeId(String mdrEmployeeId) {
        this.mdrEmployeeId = mdrEmployeeId;
    }

    public String getNineBoxScore() {
        return nineBoxScore;
    }

    public void setNineBoxScore(String nineBoxScore) {
        this.nineBoxScore = nineBoxScore;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
