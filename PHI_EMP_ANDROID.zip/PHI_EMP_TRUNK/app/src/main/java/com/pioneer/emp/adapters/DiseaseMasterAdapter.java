package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.parivaar.model.DiseaseMasterModel;
import com.pioneer.parivaar.model.IdNameModel;

import java.util.ArrayList;

/**
 * Created by fatima.t on 08-05-2017.
 */

public class DiseaseMasterAdapter extends BaseAdapter{
    ArrayList<DiseaseMasterModel> list;
    LayoutInflater inflter;
    Context context;

    public DiseaseMasterAdapter(Context context, ArrayList<DiseaseMasterModel> allCrops) {
        this.context = context;
        inflter = (LayoutInflater.from(context));
        this.list = allCrops;

    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        
//        View view = convertView;
        convertView =  inflter.inflate(R.layout.emp_fab_custom_spinner_items, null);
        TextView stateText = convertView.findViewById(R.id.spinner_textView);

        stateText.setText(list.get(position).getDiseaseName());
        stateText.setTag(list.get(position).getId());
        return convertView;
    }
}
