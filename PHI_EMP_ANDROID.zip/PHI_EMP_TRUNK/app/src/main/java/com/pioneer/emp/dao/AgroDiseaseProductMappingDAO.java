package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.AgroDiseaseProductMappingDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

import static com.pioneer.emp.dbHandler.DBHandler.TABLE_AGRO_DISEASE_PRODUCT_MAPPING;


/**
 * Created by hareesh.a on 12/18/2017.
 */

public class AgroDiseaseProductMappingDAO implements DAO {
    private final String TAG = "AgroDisease";
    private static AgroDiseaseProductMappingDAO agroDiseaseProductMappingDAO;

    public static AgroDiseaseProductMappingDAO getInstance() {
        if (agroDiseaseProductMappingDAO == null) {
            agroDiseaseProductMappingDAO = new AgroDiseaseProductMappingDAO();
        }
        return agroDiseaseProductMappingDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            AgroDiseaseProductMappingDTO dto = (AgroDiseaseProductMappingDTO) dtoObject;

            ContentValues cv = new ContentValues();

            if (dto.getProductName() == null) {
                cv.put("productName", "");
            } else {
                cv.put("productName", dto.getProductName());
            }
            if (dto.getCharacter() == null) {
                cv.put("character", "");
            } else {
                cv.put("character", dto.getCharacter());
            }
            if (dto.getWork() == null) {
                cv.put("work", "");
            } else {
                cv.put("work", dto.getWork());
            }
            if (dto.getProductUse() == null) {
                cv.put("productUse", "");
            } else {
                cv.put("productUse", dto.getProductUse());
            }
            if (dto.getCaution() == null) {
                cv.put("caution", "");
            } else {
                cv.put("caution", dto.getCaution());
            }
            if (dto.getResultAndEffect() == null) {
                cv.put("resultAndEffect", "");
            } else {
                cv.put("resultAndEffect", dto.getResultAndEffect());
            }
            if (dto.getType() == null) {
                cv.put("type", "");
            } else {
                cv.put("type", dto.getType());
            }
            if (dto.getProductImage() == null) {
                cv.put("productImage", "");
            } else {
                cv.put("productImage", dto.getProductImage());
            }
            if (dto.getActive() == null) {
                cv.put("active", "");
            } else {
                cv.put("active", dto.getActive());
            }
            if (dto.getDeleted() == null) {
                cv.put("deleted", "");
            } else {
                cv.put("deleted", dto.getDeleted());
            }
            if (dto.getCreatedOn() == null) {
                cv.put("createdOn", "");
            } else {
                cv.put("createdOn", dto.getCreatedOn());
            }
            if (dto.getUpdatedOn() == null) {
                cv.put("updatedOn", "");
            } else {
                cv.put("updatedOn", dto.getUpdatedOn());
            }
            if (dto.getId() == 0) {
                cv.put("id", "");
            } else {
                cv.put("id", dto.getId());
            }
            if (dto.getStatus() == null) {
                cv.put("status", "");
            } else {
                cv.put("status", dto.getStatus());
            }
            if (dto.getAgro_images_local() == null) {
                cv.put("agro_images_local", "");
            } else {
                cv.put("agro_images_local", dto.getAgro_images_local());
            }

            if (dto.getCropAndDiseaseNamesForMobile() == null){
                cv.put("cropAndDiseaseNamesForMobile", "");
            } else {
                cv.put("cropAndDiseaseNamesForMobile", dto.getCropAndDiseaseNamesForMobile());
            }

            long rowsEffected = dbObject.insert(TABLE_AGRO_DISEASE_PRODUCT_MAPPING, null, cv);
            if (rowsEffected > 0) {
                return "";
            }
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public boolean deleteRecordById(long id, SQLiteDatabase dbObject) {
        try {
            int rowsEffected = dbObject.delete(TABLE_AGRO_DISEASE_PRODUCT_MAPPING, "id = '" + id + "'", null);
            return rowsEffected > 0;
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  " + DBHandler.TABLE_AGRO_DISEASE_PRODUCT_MAPPING).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public AgroDiseaseProductMappingDTO getSelectedRecordById(String id, SQLiteDatabase dbObject) {
        AgroDiseaseProductMappingDTO dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_AGRO_DISEASE_PRODUCT_MAPPING + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new AgroDiseaseProductMappingDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setProductName(cursor.getString(cursor.getColumnIndex("productName")));
                    dto.setCharacter(cursor.getString(cursor.getColumnIndex("character")));
                    dto.setWork(cursor.getString(cursor.getColumnIndex("work")));
                    dto.setProductUse(cursor.getString(cursor.getColumnIndex("productUse")));
                    dto.setCaution(cursor.getString(cursor.getColumnIndex("caution")));
                    dto.setResultAndEffect(cursor.getString(cursor.getColumnIndex("resultAndEffect")));
                    dto.setType(cursor.getString(cursor.getColumnIndex("type")));
                    dto.setProductImage(cursor.getString(cursor.getColumnIndex("productImage")));
                    dto.setActive(cursor.getString(cursor.getColumnIndex("active")));
                    dto.setDeleted(cursor.getString(cursor.getColumnIndex("deleted")));
                    dto.setCreatedOn(cursor.getString(cursor.getColumnIndex("createdOn")));
                    dto.setUpdatedOn(cursor.getString(cursor.getColumnIndex("updatedOn")));
                    dto.setStatus(cursor.getString(cursor.getColumnIndex("status")));
                    dto.setAgro_images_local(cursor.getString(cursor.getColumnIndex("agro_images_local")));
                    dto.setCropAndDiseaseNamesForMobile(cursor.getString(cursor.getColumnIndex("cropAndDiseaseNamesForMobile")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }

    public AgroDiseaseProductMappingDTO getRecordById(long id, SQLiteDatabase dbObject) {
        AgroDiseaseProductMappingDTO dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_AGRO_DISEASE_PRODUCT_MAPPING + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new AgroDiseaseProductMappingDTO();

                    dto.setProductName(cursor.getString(cursor.getColumnIndex("productName")));
                    dto.setCharacter(cursor.getString(cursor.getColumnIndex("character")));
                    dto.setWork(cursor.getString(cursor.getColumnIndex("work")));
                    dto.setProductUse(cursor.getString(cursor.getColumnIndex("productUse")));
                    dto.setCaution(cursor.getString(cursor.getColumnIndex("caution")));
                    dto.setResultAndEffect(cursor.getString(cursor.getColumnIndex("resultAndEffect")));
                    dto.setType(cursor.getString(cursor.getColumnIndex("type")));
                    dto.setProductImage(cursor.getString(cursor.getColumnIndex("productImage")));
                    dto.setActive(cursor.getString(cursor.getColumnIndex("active")));
                    dto.setDeleted(cursor.getString(cursor.getColumnIndex("deleted")));
                    dto.setCreatedOn(cursor.getString(cursor.getColumnIndex("createdOn")));
                    dto.setUpdatedOn(cursor.getString(cursor.getColumnIndex("updatedOn")));
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setStatus(cursor.getString(cursor.getColumnIndex("status")));
                    dto.setAgro_images_local(cursor.getString(cursor.getColumnIndex("agro_images_local")));
                    dto.setCropAndDiseaseNamesForMobile(cursor.getString(cursor.getColumnIndex("cropAndDiseaseNamesForMobile")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }

    public boolean updateRecordById(DTO mainDTO, SQLiteDatabase dbObject) {
        AgroDiseaseProductMappingDTO dto = null;
        try {
            dto = (AgroDiseaseProductMappingDTO) mainDTO;
            ContentValues cv = new ContentValues();


            cv.put("productName", dto.getProductName());
            cv.put("character", dto.getCharacter());
            cv.put("work", dto.getWork());
            cv.put("productUse", dto.getProductUse());
            cv.put("caution", dto.getCaution());
            cv.put("resultAndEffect", dto.getResultAndEffect());
            cv.put("type", dto.getType());
            cv.put("productImage", dto.getProductImage());
            cv.put("active", dto.getActive());
            cv.put("deleted", dto.getDeleted());
            cv.put("createdOn", dto.getCreatedOn());
            cv.put("updatedOn", dto.getUpdatedOn());
            cv.put("id", dto.getId());
            cv.put("status", dto.getStatus());
            cv.put("cropAndDiseaseNamesForMobile", dto.getCropAndDiseaseNamesForMobile());

            if (dto.getAgro_images_local() != null)
                cv.put("agro_images_local", dto.getAgro_images_local());

            dbObject.update(DBHandler.TABLE_AGRO_DISEASE_PRODUCT_MAPPING, cv, "id = '" + dto.getId() + "'", null);
            return true;
        } catch (Exception e) {
            BuildLog.d(TAG, "updateRecordById: ");
        } finally {
            dbObject.close();
        }
        return false;
    }

    public List<AgroDiseaseProductMappingDTO> getAllRecords(SQLiteDatabase dbObject) {
        List<AgroDiseaseProductMappingDTO> fabmasterInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from "+TABLE_AGRO_DISEASE_PRODUCT_MAPPING,null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    AgroDiseaseProductMappingDTO dto = new AgroDiseaseProductMappingDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setProductName(cursor.getString(cursor.getColumnIndex("productName")));
                    dto.setCharacter(cursor.getString(cursor.getColumnIndex("character")));
                    dto.setWork(cursor.getString(cursor.getColumnIndex("work")));
                    dto.setProductUse(cursor.getString(cursor.getColumnIndex("productUse")));
                    dto.setCaution(cursor.getString(cursor.getColumnIndex("caution")));
                    dto.setResultAndEffect(cursor.getString(cursor.getColumnIndex("resultAndEffect")));
                    dto.setType(cursor.getString(cursor.getColumnIndex("type")));
                    dto.setProductImage(cursor.getString(cursor.getColumnIndex("productImage")));
                    dto.setActive(cursor.getString(cursor.getColumnIndex("active")));
                    dto.setDeleted(cursor.getString(cursor.getColumnIndex("deleted")));
                    dto.setCreatedOn(cursor.getString(cursor.getColumnIndex("createdOn")));
                    dto.setUpdatedOn(cursor.getString(cursor.getColumnIndex("updatedOn")));
                    dto.setStatus(cursor.getString(cursor.getColumnIndex("status")));
                    dto.setAgro_images_local(cursor.getString(cursor.getColumnIndex("agro_images_local")));
                    dto.setCropAndDiseaseNamesForMobile(cursor.getString(cursor.getColumnIndex("cropAndDiseaseNamesForMobile")));

                    fabmasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return fabmasterInfo;
    }

    public String getLocalImageURLById(String id, SQLiteDatabase dbObject) {
        String dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select agro_images_local from " + TABLE_AGRO_DISEASE_PRODUCT_MAPPING + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = cursor.getString(cursor.getColumnIndex("agro_images_local"));
                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }
}
