package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.emp.listeners.OnItemClickListener;
import com.pioneer.emp.models.NavDrawerItem;

import java.util.ArrayList;

/**
 * Created by rambabu.a on 06-04-2017.
 */

public class NavDrawerAdapter extends ExpandableRecyclerAdapter<NavDrawerItem> {
    Context mContext;
    public ArrayList<NavDrawerItem> allContactsList = new ArrayList<NavDrawerItem>();
    private OnItemClickListener listener;

    public NavDrawerAdapter(Context context, ArrayList<NavDrawerItem> acq_list, OnItemClickListener listener) {

        super(context);
        this.mContext = context;
        this.allContactsList = acq_list;
        setItems(acq_list);
        this.listener = listener;
    }

    private class HeaderViewHolder extends ExpandableRecyclerAdapter.HeaderViewHolder {
        TextView mCategoryTextview;
        ImageView mAssociateDropDownArrow;
        RelativeLayout parentLayout;

        HeaderViewHolder(View view) {
            super(view, view.findViewById(R.id.headerArrow), view.findViewById(R.id.headerTitle), true, listener);
            mCategoryTextview = view.findViewById(R.id.headerTitle);
            mAssociateDropDownArrow = view.findViewById(R.id.headerArrow);
            parentLayout = view.findViewById(R.id.parent_layout);
            setMode(MODE_ACCORDION);

        }

        void bind(final int position, final OnItemClickListener listener) {
            super.bind(position);
            mCategoryTextview.setText(visibleItems.get(position).getTitle());
            /*if(visibleItems.get(position).getTitle().equals("Products") || visibleItems.get(position).getTitle().equals("Crop Advisory")){
                mAssociateDropDownArrow.setVisibility(View.VISIBLE);
            }else*/{
                mAssociateDropDownArrow.setVisibility(View.GONE);
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String title = ((TextView)itemView.findViewById(R.id.headerTitle)).getText().toString().trim();
                    NavDrawerItem navDrawerItem = new NavDrawerItem();
                    navDrawerItem.setTitle(title);
                    listener.onItemClick(itemView, navDrawerItem);
                }
            });

        }
    }

    public class PersonViewHolder extends ExpandableRecyclerAdapter.ViewHolder {
        TextView mUser_name;
        RelativeLayout mParent_layout;

        public PersonViewHolder(View view) {
            super(view);

            mUser_name = view.findViewById(R.id.sub_item_txt);
            mParent_layout = view.findViewById(R.id.parent_layout);

        }

        public void bind(final int position, final OnItemClickListener listener) {
            NavDrawerItem entity = visibleItems.get(position);
            mUser_name.setText(entity.getTitle());
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(itemView, visibleItems.get(position));
                }
            });
        }
    }

    @Override
    public void onBindViewHolder(ExpandableRecyclerAdapter.ViewHolder viewHolder, final int position) {

        switch (getItemViewType(position)) {
            case AppConstants.LIST_ITEM_HEADER:
                ((HeaderViewHolder) viewHolder).bind(position, listener);
                break;
            case AppConstants.LIST_ITEM_PERSON:
            default:
                ((PersonViewHolder) viewHolder).bind(position, listener);
                break;
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case AppConstants.LIST_ITEM_HEADER:
                return new HeaderViewHolder(inflate(R.layout.drawer_row_header, parent));
            case AppConstants.LIST_ITEM_PERSON:
            default:
                return new PersonViewHolder(inflate(R.layout.drawer_row_body, parent));
        }
    }
}
