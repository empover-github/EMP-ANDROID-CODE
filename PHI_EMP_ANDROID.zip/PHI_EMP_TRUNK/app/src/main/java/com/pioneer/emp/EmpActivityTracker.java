package com.pioneer.emp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import okhttp3.internal.Util;

/**
 * Created by hareesh.a on 5/15/2018.
 */

public class EmpActivityTracker extends BaseActivity implements View.OnClickListener {

    private Toolbar toolbar;
    private TextView txtHeader;
    private ImageView navBackBtn;
    private ImageView imgActivityPlotting, imgDemandGeneration, imgAgronomy, imgDipstick;
    private EmpActivityTracker thisActivity;
    public static final String INTENT_TYPE_ACTIVITY_PLOTTING = "activityPlotting";
    //newly added after buildversion
    private LinearLayout toolsLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_activity_tracker);
        thisActivity = this;
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // for testing purpose changing my user ID
//        Utils.setUserId("484", thisActivity);

        /*EmpTest*/
        txtHeader = findViewById(R.id.hedder_text);
        txtHeader.setText(getString(R.string.emp_activity_tracker));
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);
        intializationViews();
    }

    private void intializationViews() {
        imgActivityPlotting = findViewById(R.id.img_activity_plotting);
        imgDemandGeneration = findViewById(R.id.img_demand_generation);
        imgAgronomy = findViewById(R.id.img_agronomy);
        imgDipstick = findViewById(R.id.img_dipstick);
        toolsLayout = findViewById(R.id.rbl_tools_layout);

        if (AppConstants.DES_TBL.equalsIgnoreCase(Utils.getDesignationName(EmpActivityTracker.this))) {
            imgDipstick.setVisibility(View.VISIBLE);
            toolsLayout.setVisibility(View.VISIBLE);

        } else {
            imgDipstick.setVisibility(View.GONE);
            toolsLayout.setVisibility(View.GONE);

        }

        imgActivityPlotting.setOnClickListener(this);
        imgDemandGeneration.setOnClickListener(this);
        imgAgronomy.setOnClickListener(this);
        imgDipstick.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgBacknav:
                finish();
                break;
            case R.id.img_activity_plotting:
                if (Utils.isNetworkConnection(thisActivity)) {
                    Intent activityPlottingIntent = new Intent(thisActivity, ActivityPlottingMap.class);
                    activityPlottingIntent.putExtra(FilterMdrDgDashboardActivity.INTENT_TYPE, INTENT_TYPE_ACTIVITY_PLOTTING);
                    startActivity(activityPlottingIntent);
                } else {
                    DialogManager.showToast(thisActivity, getString(R.string.internetRequired));
                    return;
                }
                break;
            case R.id.img_demand_generation:
                if (Utils.isNetworkConnection(thisActivity)) {
                    Intent demandGenerationIntent = new Intent(thisActivity, MdrDGDashboardActivity.class);
                    startActivity(demandGenerationIntent);
                } else {
                    DialogManager.showToast(thisActivity, getString(R.string.internetRequired));
                    return;
                }
                break;
            case R.id.img_agronomy:
                break;
            case R.id.img_dipstick:
                Intent dipstickIntent = new Intent(thisActivity, MdrDipstickEmpActivity.class);
                startActivity(dipstickIntent);
                break;

        }
    }
}
