package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.dto.CouponBookletDTO;
import com.pioneer.emp.dto.CouponListDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.R;

import java.util.ArrayList;

/**
 * Created by hareesh.a on 7/11/2017.
 */

public class CouponBookletAdapter extends RecyclerView.Adapter<CouponBookletAdapter.MYHolder> {
    Context context;
    ArrayList<CouponBookletDTO> couponsDTOArrayList;
    ArrayList<CouponListDTO> couponListDTOArrayList;
    private final OnBookletClickListener listener;

    public CouponBookletAdapter(Context context, ArrayList<CouponBookletDTO> couponsDTOArrayList, OnBookletClickListener listener) {
        this.context = context;
        this.couponsDTOArrayList = couponsDTOArrayList;
        this.listener = listener;
    }

    @Override
    public MYHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.emp_coupon_booklet_recycle_message,parent,false);
        return new MYHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MYHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return couponsDTOArrayList.size();
    }

    public class MYHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView crop_details,valid_till, coupon_booklet, no_of_shared;
        LinearLayout message_click;

        public MYHolder(View view) {
            super(view);

            crop_details = view.findViewById(R.id.cba_crop);
            valid_till = view.findViewById(R.id.valid_till_TV);
            coupon_booklet = view.findViewById(R.id.coupon_booklet_TV);
            no_of_shared = view.findViewById(R.id.no_shared_TV);
            message_click = view.findViewById(R.id.cba_message_click);

        }

        public void bind(final int position) {
            CouponBookletDTO couponBookletDTO = couponsDTOArrayList.get(position);
            crop_details.setText(couponBookletDTO.getCrop() +" " + "-" + " "+ couponBookletDTO.getSeason() + " " + "-" + " " + couponBookletDTO.getYear());
            valid_till.setText(couponBookletDTO.getValidTill());
            coupon_booklet.setText(String.valueOf(couponBookletDTO.getCouponsInBooklet()));
            no_of_shared.setText(String.valueOf(couponBookletDTO.getCouponsShared()));
            if(couponBookletDTO.getCouponList() !=null && !couponBookletDTO.getCouponList().isEmpty()){
            couponListDTOArrayList = couponBookletDTO.getCouponList();
                CouponListDTO dto = couponListDTOArrayList.get(0);
            }
            message_click.setOnClickListener(this);
            message_click.setTag(position);
        }

        @Override
        public void onClick(View v) {
            int position = (int) v.getTag();
            listener.onItemClick(v, position);
        }
    }

}
