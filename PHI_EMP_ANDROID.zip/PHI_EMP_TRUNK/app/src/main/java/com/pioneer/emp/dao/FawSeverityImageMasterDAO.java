package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.SeverityImageModel;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

public class FawSeverityImageMasterDAO implements DAO {
    private final String TAG = "FawSeverityImageMaster";
    private static FawSeverityImageMasterDAO fawSeverityImageMasterDAO ;

    public static FawSeverityImageMasterDAO getInstance() {
        if (fawSeverityImageMasterDAO == null) {
            fawSeverityImageMasterDAO = new FawSeverityImageMasterDAO();
        }
        return fawSeverityImageMasterDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            SeverityImageModel dto = (SeverityImageModel) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("priority", dto.getPriority());
            cv.put("fawImageUrl", dto.getFawImageUrl());

            long rowsEffected = dbObject.insert(DBHandler.TABLE_FAW_SEVERITY_IMAGE_MASTER, null, cv);
            if (rowsEffected > 0)
                return "";
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> severityData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_FAW_SEVERITY_IMAGE_MASTER, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SeverityImageModel dto = new SeverityImageModel();
                    dto.setPriority(cursor.getString(cursor.getColumnIndex("priority")));
                    dto.setFawImageUrl(cursor.getString(cursor.getColumnIndex("fawImageUrl")));

                    severityData.add(dto);
                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return severityData;
    }

    public ArrayList<SeverityImageModel> getAllRecords(SQLiteDatabase dbObject) {
        ArrayList<SeverityImageModel> severityData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_FAW_SEVERITY_IMAGE_MASTER, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SeverityImageModel dto = new SeverityImageModel();
                    dto.setPriority(cursor.getString(cursor.getColumnIndex("priority")));
                    dto.setFawImageUrl(cursor.getString(cursor.getColumnIndex("fawImageUrl")));

                    severityData.add(dto);
                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return severityData;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_FAW_SEVERITY_IMAGE_MASTER).execute();
            return true;
        } catch (Exception ignore) {

        } finally {
            dbObject.close();
        }
        return false;

    }
    public int isDataAvailable(/*DTO dtoObject,*/SQLiteDatabase dbObject) {

        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM "+DBHandler.TABLE_FAW_SEVERITY_IMAGE_MASTER, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
            return 0;
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return 0;
    }
}
