package com.pioneer.emp.dto;


import com.pioneer.parivaar.dto.DTO;

import java.io.Serializable;

/**
 * Created by fatima.t on 11-04-2018.
 */

public class TBLWeeklyLiqDTO implements DTO,Serializable {
    private String mobileId;
    private String territoryId;
    private String territoryName;
    private String currentYear;
    private String seasonId;
    private String seasonName;
    private String cropId;
    private String cropName;
    private String hybridId;
    private String hybridName;
    private String invoiceQuantity;
    private String netReturns;
    private String liquidation;
    private String mobileSubmittedDate;
    private int sync;

    private String mobileNumber; // this is added for RBM approval
    private long serverId; // this is added for RBM approval

    public String getMobileId() {
        return mobileId;
    }

    public void setMobileId(String mobileId) {
        this.mobileId = mobileId;
    }

    public String getTerritoryId() {
        return territoryId;
    }

    public void setTerritoryId(String territoryId) {
        this.territoryId = territoryId;
    }

    public String getTerritoryName() {
        return territoryName;
    }

    public void setTerritoryName(String territoryName) {
        this.territoryName = territoryName;
    }

    public String getCurrentYear() {
        return currentYear;
    }

    public void setCurrentYear(String currentYear) {
        this.currentYear = currentYear;
    }

    public String getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(String seasonId) {
        this.seasonId = seasonId;
    }

    public String getSeasonName() {
        return seasonName;
    }

    public void setSeasonName(String seasonName) {
        this.seasonName = seasonName;
    }

    public String getCropId() {
        return cropId;
    }

    public void setCropId(String cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getHybridId() {
        return hybridId;
    }

    public void setHybridId(String hybridId) {
        this.hybridId = hybridId;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getInvoiceQuantity() {
        return invoiceQuantity;
    }

    public void setInvoiceQuantity(String invoiceQuantity) {
        this.invoiceQuantity = invoiceQuantity;
    }

    public String getNetReturns() {
        return netReturns;
    }

    public void setNetReturns(String netReturns) {
        this.netReturns = netReturns;
    }

    public String getLiquidation() {
        return liquidation;
    }

    public void setLiquidation(String liquidation) {
        this.liquidation = liquidation;
    }

    public String getMobileSubmittedDate() {
        return mobileSubmittedDate;
    }

    public void setMobileSubmittedDate(String mobileSubmittedDate) {
        this.mobileSubmittedDate = mobileSubmittedDate;
    }

    public int getSync() {
        return sync;
    }

    public void setSync(int sync) {
        this.sync = sync;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public long getServerId() {
        return serverId;
    }

    public void setServerId(long serverId) {
        this.serverId = serverId;
    }
}
