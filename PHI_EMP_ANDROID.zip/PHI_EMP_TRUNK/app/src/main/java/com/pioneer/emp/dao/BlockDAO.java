package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.BlockMobileData;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by swamy on 10-03-2018.
 */

public class BlockDAO implements DAO {

    private final String TAG = "BlockDAO";
    private static BlockDAO blockDAO;

    public static BlockDAO getInstance() {
        if (blockDAO == null) {
            blockDAO = new BlockDAO();
        }

        return blockDAO;
    }

    @Override
    public String insert(DTO dtoMain, SQLiteDatabase dbObject) {
        BlockMobileData dto = (BlockMobileData) dtoMain;
        try {
            ContentValues cValues = new ContentValues();
            cValues.put("name", dto.getName());
            cValues.put("territoryName", dto.getTerritoryName());
            dbObject.insert("MASTER_BLOCK", null, cValues);
            return "";
        } catch (SQLException e) {
            BuildLog.e(TAG + "insert()", e.getMessage());
            return null;

        } finally {
            dbObject.close();
        }
    }

    public String insertList(List<BlockMobileData> blocksMobileData, SQLiteDatabase dbObject) {
        try {
        for(BlockMobileData dto : blocksMobileData) {
            ContentValues cValues = new ContentValues();
            cValues.put("name", dto.getName());
            cValues.put("territoryName", dto.getTerritoryName());
            dbObject.insert("MASTER_BLOCK", null, cValues);
        }
            return "";
        } catch (SQLException e) {
            BuildLog.e(TAG + "insert()", e.getMessage());
            return null;
        } finally {
            dbObject.close();
        }
    }

    public void insertOrUpdate(Context context, DTO dtoMain, SQLiteDatabase dbObject) {
        BlockMobileData dto = (BlockMobileData) dtoMain;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT name FROM MASTER_BLOCK where name='" + dto.getName() + "'", null);
            if (cursor.getCount() > 0) {
                update(dto, DBHandler.getWritableDb(context));
            } else {
                insert(dto, DBHandler.getWritableDb(context));
            }
        } catch (SQLiteException e) {
//            dbObject.close();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
    }

    @Override
    public boolean update(DTO dtoMain, SQLiteDatabase dbObject) {
        try {
            BlockMobileData dto = (BlockMobileData) dtoMain;
            ContentValues cValues = new ContentValues();

            if (dto.getName() != null)
                cValues.put("name", dto.getName());

            if (dto.getTerritoryName() != null)
                cValues.put("territoryName", dto.getTerritoryName());
            else
                cValues.putNull("territoryName");

            dbObject.update("MASTER_BLOCK", cValues, "name = '" + dto.getName() + "'", null);

        } catch (SQLException e) {
            BuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoMain, SQLiteDatabase dbObject) {
        BlockMobileData dto = (BlockMobileData) dtoMain;
        try {
            dbObject.compileStatement("DELETE FROM MASTER_BLOCK WHERE name = '" + dto.getName() + "'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public ArrayList getRecordsByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {

        if (columnValue == null || columnValue.isEmpty())
            return null;
        ArrayList<BlockMobileData> info = new ArrayList<>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "name";

            String sql = "SELECT * FROM MASTER_BLOCK where " + columnName + "='" + columnValue + "'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                BlockMobileData dto;
                do {
                    dto = new BlockMobileData();
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setTerritoryName(cursor.getString(cursor.getColumnIndex("territoryName")));

                    info.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return info;
    }

    public BlockMobileData getRecordsByName(String name, SQLiteDatabase dbObject) {
        BlockMobileData dto = null;

        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_BLOCK where name='" + name + "'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new BlockMobileData();
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setTerritoryName(cursor.getString(cursor.getColumnIndex("territoryName")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return dto;
    }


    public List<String> getRecordsByListOfName(String name, SQLiteDatabase dbObject) {
        List<String> list = new ArrayList<>();
        BlockMobileData dto = null;

        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_BLOCK where territoryName='" + name + "'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new BlockMobileData();
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));

                    list.add(dto.getName());
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return list;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM MASTER_BLOCK").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
}
