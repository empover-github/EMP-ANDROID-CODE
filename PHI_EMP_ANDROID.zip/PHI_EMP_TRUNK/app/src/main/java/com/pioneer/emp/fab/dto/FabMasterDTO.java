package com.pioneer.emp.fab.dto;

import com.pioneer.emp.models.CommonResponseEntity;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.emp.fab.models.FabMasterModel;

import java.io.Serializable;

/**
 * Created by fatima.t on 29-06-2017.
 */

public class FabMasterDTO extends /*CommonResEntity implements DTO,Serializable*/  CommonResponseEntity implements DTO,Serializable{

    /*private FabMasterModel response;
    public FabMasterModel getResponse() {
    return response;
}

    public void setResponse(FabMasterModel response) {
        this.response = response;
    }*/


    private FabMasterModel mainresponse;

    public FabMasterModel getMainresponse() {
        return mainresponse;
    }

    public void setMainresponse(FabMasterModel mainresponse) {
        this.mainresponse = mainresponse;
    }

    /*private long id;
    private String version;
    private String state;
    private String stateId;
    private String crop;
    private String cropId;
    private String hybrid;
    private String hybridId;
    private String season;
    private String seasonId;

    private String description;

    private String f_pdfFile;
    private String f_voiceFile;
    private String f_videoFile;
    private String f_images;
    private String f_message;
    private String f_localLangMessage;

    private String a_pdfFile;
    private String a_voiceFile;
    private String a_videoFile;
    private String a_images;
    private String a_message;
    private String a_localLangMessage;

    private String b_pdfFile;
    private String b_voiceFile;
    private String b_videoFile;
    private String b_images;
    private String b_message;
    private String b_localLangMessage;

    private String f_pdfFile_local;
    private String f_voiceFile_local;
    private String f_videoFile_local;
    private String f_images_local;
    private String f_message_local;
    private String f_localLangMessage_local;

    private String a_pdfFile_local;
    private String a_voiceFile_local;
    private String a_videoFile_local;
    private String a_images_local;
    private String a_message_local;
    private String a_localLangMessage_local;

    private String b_pdfFile_local;
    private String b_voiceFile_local;
    private String b_videoFile_local;
    private String b_images_local;
    private String b_message_local;
    private String b_localLangMessage_local;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getCropId() {
        return cropId;
    }

    public void setCropId(String cropId) {
        this.cropId = cropId;
    }

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public String getHybridId() {
        return hybridId;
    }

    public void setHybridId(String hybridId) {
        this.hybridId = hybridId;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public String getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(String seasonId) {
        this.seasonId = seasonId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getF_pdfFile() {
        return f_pdfFile;
    }

    public void setF_pdfFile(String f_pdfFile) {
        this.f_pdfFile = f_pdfFile;
    }

    public String getF_voiceFile() {
        return f_voiceFile;
    }

    public void setF_voiceFile(String f_voiceFile) {
        this.f_voiceFile = f_voiceFile;
    }

    public String getF_videoFile() {
        return f_videoFile;
    }

    public void setF_videoFile(String f_videoFile) {
        this.f_videoFile = f_videoFile;
    }

    public String getF_images() {
        return f_images;
    }

    public void setF_images(String f_images) {
        this.f_images = f_images;
    }

    public String getF_message() {
        return f_message;
    }

    public void setF_message(String f_message) {
        this.f_message = f_message;
    }

    public String getF_localLangMessage() {
        return f_localLangMessage;
    }

    public void setF_localLangMessage(String f_localLangMessage) {
        this.f_localLangMessage = f_localLangMessage;
    }

    public String getA_pdfFile() {
        return a_pdfFile;
    }

    public void setA_pdfFile(String a_pdfFile) {
        this.a_pdfFile = a_pdfFile;
    }

    public String getA_voiceFile() {
        return a_voiceFile;
    }

    public void setA_voiceFile(String a_voiceFile) {
        this.a_voiceFile = a_voiceFile;
    }

    public String getA_videoFile() {
        return a_videoFile;
    }

    public void setA_videoFile(String a_videoFile) {
        this.a_videoFile = a_videoFile;
    }

    public String getA_images() {
        return a_images;
    }

    public void setA_images(String a_images) {
        this.a_images = a_images;
    }

    public String getA_message() {
        return a_message;
    }

    public void setA_message(String a_message) {
        this.a_message = a_message;
    }

    public String getA_localLangMessage() {
        return a_localLangMessage;
    }

    public void setA_localLangMessage(String a_localLangMessage) {
        this.a_localLangMessage = a_localLangMessage;
    }

    public String getB_pdfFile() {
        return b_pdfFile;
    }

    public void setB_pdfFile(String b_pdfFile) {
        this.b_pdfFile = b_pdfFile;
    }

    public String getB_voiceFile() {
        return b_voiceFile;
    }

    public void setB_voiceFile(String b_voiceFile) {
        this.b_voiceFile = b_voiceFile;
    }

    public String getB_videoFile() {
        return b_videoFile;
    }

    public void setB_videoFile(String b_videoFile) {
        this.b_videoFile = b_videoFile;
    }

    public String getB_images() {
        return b_images;
    }

    public void setB_images(String b_images) {
        this.b_images = b_images;
    }

    public String getB_message() {
        return b_message;
    }

    public void setB_message(String b_message) {
        this.b_message = b_message;
    }

    public String getB_localLangMessage() {
        return b_localLangMessage;
    }

    public void setB_localLangMessage(String b_localLangMessage) {
        this.b_localLangMessage = b_localLangMessage;
    }

    public String getF_pdfFile_local() {
        return f_pdfFile_local;
    }

    public void setF_pdfFile_local(String f_pdfFile_local) {
        this.f_pdfFile_local = f_pdfFile_local;
    }

    public String getF_voiceFile_local() {
        return f_voiceFile_local;
    }

    public void setF_voiceFile_local(String f_voiceFile_local) {
        this.f_voiceFile_local = f_voiceFile_local;
    }

    public String getF_videoFile_local() {
        return f_videoFile_local;
    }

    public void setF_videoFile_local(String f_videoFile_local) {
        this.f_videoFile_local = f_videoFile_local;
    }

    public String getF_images_local() {
        return f_images_local;
    }

    public void setF_images_local(String f_images_local) {
        this.f_images_local = f_images_local;
    }

    public String getF_message_local() {
        return f_message_local;
    }

    public void setF_message_local(String f_message_local) {
        this.f_message_local = f_message_local;
    }

    public String getF_localLangMessage_local() {
        return f_localLangMessage_local;
    }

    public void setF_localLangMessage_local(String f_localLangMessage_local) {
        this.f_localLangMessage_local = f_localLangMessage_local;
    }

    public String getA_pdfFile_local() {
        return a_pdfFile_local;
    }

    public void setA_pdfFile_local(String a_pdfFile_local) {
        this.a_pdfFile_local = a_pdfFile_local;
    }

    public String getA_voiceFile_local() {
        return a_voiceFile_local;
    }

    public void setA_voiceFile_local(String a_voiceFile_local) {
        this.a_voiceFile_local = a_voiceFile_local;
    }

    public String getA_videoFile_local() {
        return a_videoFile_local;
    }

    public void setA_videoFile_local(String a_videoFile_local) {
        this.a_videoFile_local = a_videoFile_local;
    }

    public String getA_images_local() {
        return a_images_local;
    }

    public void setA_images_local(String a_images_local) {
        this.a_images_local = a_images_local;
    }

    public String getA_message_local() {
        return a_message_local;
    }

    public void setA_message_local(String a_message_local) {
        this.a_message_local = a_message_local;
    }

    public String getA_localLangMessage_local() {
        return a_localLangMessage_local;
    }

    public void setA_localLangMessage_local(String a_localLangMessage_local) {
        this.a_localLangMessage_local = a_localLangMessage_local;
    }

    public String getB_pdfFile_local() {
        return b_pdfFile_local;
    }

    public void setB_pdfFile_local(String b_pdfFile_local) {
        this.b_pdfFile_local = b_pdfFile_local;
    }

    public String getB_voiceFile_local() {
        return b_voiceFile_local;
    }

    public void setB_voiceFile_local(String b_voiceFile_local) {
        this.b_voiceFile_local = b_voiceFile_local;
    }

    public String getB_videoFile_local() {
        return b_videoFile_local;
    }

    public void setB_videoFile_local(String b_videoFile_local) {
        this.b_videoFile_local = b_videoFile_local;
    }

    public String getB_images_local() {
        return b_images_local;
    }

    public void setB_images_local(String b_images_local) {
        this.b_images_local = b_images_local;
    }

    public String getB_message_local() {
        return b_message_local;
    }

    public void setB_message_local(String b_message_local) {
        this.b_message_local = b_message_local;
    }

    public String getB_localLangMessage_local() {
        return b_localLangMessage_local;
    }

    public void setB_localLangMessage_local(String b_localLangMessage_local) {
        this.b_localLangMessage_local = b_localLangMessage_local;
    }*/


}
