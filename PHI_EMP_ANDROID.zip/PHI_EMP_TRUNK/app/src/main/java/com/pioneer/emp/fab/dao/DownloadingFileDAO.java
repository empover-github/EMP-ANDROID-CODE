package com.pioneer.emp.fab.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.parivaar.dao.DAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.emp.fab.dto.DownloadFileDTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

import static com.pioneer.emp.dbHandler.DBHandler.TABLE_FAB_MASTER_TEMP;

/**
 * Created by hareesh.a on 5/9/2017.
 */

public class DownloadingFileDAO implements DAO {
    private final String TAG = "DownloadingFile";
    private static DownloadingFileDAO downloadingFileDAO;

    public static DownloadingFileDAO getInstance() {
        if (downloadingFileDAO == null) {
            downloadingFileDAO = new DownloadingFileDAO();
        }
        return downloadingFileDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DownloadFileDTO notificationDTO = (DownloadFileDTO) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("id", notificationDTO.getId());
            cv.put("category", notificationDTO.getCategory());
            cv.put("url", notificationDTO.getUrl());
            cv.put("type", notificationDTO.getType());
            cv.put("tag", notificationDTO.getTag());
            long rowsEffected = dbObject.insert(TABLE_FAB_MASTER_TEMP, null, cv);
            if (rowsEffected > 0){
            }
            return "";
        } catch (SQLException e) {
            BuildLog.i(TAG + "insert()", e.getMessage());
            return "";
        } finally {
            dbObject.close();
        }
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public List<DownloadFileDTO> getRecordsForList(SQLiteDatabase dbObject) {
        ArrayList<DownloadFileDTO> categories = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from "+TABLE_FAB_MASTER_TEMP ,null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DownloadFileDTO dto = new DownloadFileDTO();
                    dto.set_id(cursor.getLong(0));
                    dto.setId(cursor.getLong(1));
                    dto.setCategory(cursor.getString(2));
                    dto.setUrl(cursor.getString(3));
                    dto.setType(cursor.getString(4));
                    dto.setTag(cursor.getString(5));
                    categories.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return categories;
    }

    public boolean deleteRecordById(long id, SQLiteDatabase dbObject) {
        try {
            int rowsEffected = dbObject.delete(TABLE_FAB_MASTER_TEMP, "_id = '"+id+"'", null);
            return rowsEffected > 0;
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {

        return false;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  "+ DBHandler.TABLE_FAB_MASTER_TEMP).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

}