package com.pioneer.emp.fab.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.fab.models.StateCodeEntity;

import java.util.ArrayList;

/**
 * Created by fatima.t on 08-05-2017.
 */

public class StatesAdapter extends BaseAdapter{
    ArrayList<StateCodeEntity> allStatesList;
    LayoutInflater inflter;
    Context context;

    public StatesAdapter(/*MainActivity mActivity*/Context context, ArrayList<StateCodeEntity> allStates) {
        this.context = context;
        inflter = (LayoutInflater.from(context));
        this.allStatesList = allStates;

    }

    @Override
    public int getCount() {
        return allStatesList.size();
    }

    @Override
    public Object getItem(int position) {
        return allStatesList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


//        View view = convertView;
        convertView =  inflter.inflate(R.layout.emp_fab_custom_spinner_items, null);
        TextView stateText = convertView.findViewById(R.id.spinner_textView);

        stateText.setText(allStatesList.get(position).getName());

        /*LayoutInflater mInflater = (LayoutInflater) getContext().getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        view = mInflater.inflate(R.layout.list_view_items, null);*/
        return convertView;
    }
}
