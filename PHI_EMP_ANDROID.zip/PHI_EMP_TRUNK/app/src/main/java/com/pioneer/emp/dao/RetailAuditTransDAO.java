package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.RetailAuditTransDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yakaswamy.g on 4/24/2018.
 */

public class RetailAuditTransDAO implements DAO {

    private final String TAG = "RetailAuditTransDAO";
    private static RetailAuditTransDAO retailAuditTransDAO;

    public static RetailAuditTransDAO getInstance() {
        if (retailAuditTransDAO == null) {
            retailAuditTransDAO = new RetailAuditTransDAO();
        }

        return retailAuditTransDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            RetailAuditTransDTO dto = (RetailAuditTransDTO) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("localImagePath", dto.getLocalImagePath());
            cv.put("isSync", dto.getIsSync());
            cv.put("isDistributor", dto.getIsDistributor());
            cv.put("captureTime", dto.getCaptureTime());
            cv.put("retailerName", dto.getRetailerName());
            cv.put("territoryId", dto.getTerritoryId());
            cv.put("totalNSPHI", dto.getTotalNSPHI());
            cv.put("territoryName", dto.getTerritoryName());
            cv.put("geoLocation", dto.getGeoLocation());
            cv.put("seasonId", dto.getSeasonId());
            cv.put("cropName", dto.getCropName());
            cv.put("year", dto.getYear());
            cv.put("regionId", dto.getRegionId());
            cv.put("totalNSCompetitor", dto.getTotalNSCompetitor());
            cv.put("retailerId", dto.getRetailerId());
            cv.put("seasonName", dto.getSeasonName());
            cv.put("cropId", dto.getCropId());
            cv.put("blockName", dto.getBlockName());
            cv.put("regionName", dto.getRegionName());
            cv.put("highestVillage1", dto.getHighestVillage1());
            cv.put("highestVillage3", dto.getHighestVillage3());
            cv.put("highestVillage2", dto.getHighestVillage2());
            cv.put("pincode", dto.getPincode());
            cv.put("blockId", dto.getBlockId());
            cv.put("cuName", dto.getCuName());
            cv.put("cuId", dto.getCuId());
            cv.put("mobileNo", dto.getMobileNo());
            cv.put("totalPHIVolume", dto.getTotalPHIVolume());

            long rowsEffected = dbObject.insert("RETAIL_AUDIT", null, cv);
            if (rowsEffected > 0)
                return "";
        } catch (SQLException e) {
            return null;
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        RetailAuditTransDTO dto = (RetailAuditTransDTO) dtoObject;
        try {
            dbObject.compileStatement("DELETE FROM RETAIL_AUDIT WHERE id = '" + dto.getId() + "'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM RETAIL_AUDIT").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public List<RetailAuditTransDTO> getRecordsToUpload(SQLiteDatabase dbObject, Context context) {
        Cursor cursor = null;
        List<RetailAuditTransDTO> list = new ArrayList<RetailAuditTransDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM RETAIL_AUDIT WHERE isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                RetailAuditTransDTO dto;
                do {
                    dto = new RetailAuditTransDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setIsDistributor(cursor.getString(cursor.getColumnIndex("isDistributor")));
                    dto.setCaptureTime(cursor.getString(cursor.getColumnIndex("captureTime")));
                    dto.setRetailerName(cursor.getString(cursor.getColumnIndex("retailerName")));
                    dto.setTerritoryId(cursor.getString(cursor.getColumnIndex("territoryId")));
                    dto.setTotalNSPHI(cursor.getLong(cursor.getColumnIndex("totalNSPHI")));
                    dto.setTerritoryName(cursor.getString(cursor.getColumnIndex("territoryName")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSeasonId(cursor.getString(cursor.getColumnIndex("seasonId")));
                    dto.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    dto.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                    dto.setRegionId(cursor.getString(cursor.getColumnIndex("regionId")));
                    dto.setTotalNSCompetitor(cursor.getLong(cursor.getColumnIndex("totalNSCompetitor")));
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setSeasonName(cursor.getString(cursor.getColumnIndex("seasonName")));
                    dto.setCropId(cursor.getString(cursor.getColumnIndex("cropId")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setRegionName(cursor.getString(cursor.getColumnIndex("regionName")));
                    dto.setHighestVillage1(cursor.getString(cursor.getColumnIndex("highestVillage1")));
                    dto.setHighestVillage3(cursor.getString(cursor.getColumnIndex("highestVillage3")));
                    dto.setHighestVillage2(cursor.getString(cursor.getColumnIndex("highestVillage2")));
                    dto.setPincode(cursor.getLong(cursor.getColumnIndex("pincode")));
                    dto.setBlockId(cursor.getString(cursor.getColumnIndex("blockId")));
                    dto.setCuName(cursor.getString(cursor.getColumnIndex("cuName")));
                    dto.setCuId(cursor.getString(cursor.getColumnIndex("cuId")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setTotalPHIVolume(cursor.getLong(cursor.getColumnIndex("totalPHIVolume")));

                    dto.setPHIHybrids(AuditPHIHybridDAO.getInstance().getRecordsToUpload(DBHandler.getReadableDb(context), dto.getId()));
                    dto.setCompetitors(AuditCompetitorDAO.getInstance().getRecordsToUpload(DBHandler.getReadableDb(context), dto.getId()));
                    dto.setDistributorDetails(AuditDistributorDAO.getInstance().getRecordsToUpload(DBHandler.getReadableDb(context), dto.getId()));
                    //newlya added
                    dto.setPreferredDistributorDetails(AuditPreferredDistributorDAO.getInstance().getRecordsToUpload(DBHandler.getReadableDb(context),dto.getId()));

                    list.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return list;
    }


    public long getId(SQLiteDatabase dbObject, Context context) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT MAX(id) FROM RETAIL_AUDIT", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0);
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return -1;
    }

    public boolean deleteById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM RETAIL_AUDIT WHERE id = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    public boolean isAuditExist(String year, String retMobileNo, long seasonId, long cropId, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        List<RetailAuditTransDTO> list = new ArrayList<RetailAuditTransDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT id FROM RETAIL_AUDIT WHERE year = '" + year + "' AND mobileNo = '" + retMobileNo + "' AND seasonId = '" + seasonId + "' AND cropId = '" + cropId + "'", null);
            return cursor.getCount() > 0;
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
            dbObject.close();
        }
        return false;
    }

    public RetailAuditTransDTO getRecordsById(String id, SQLiteDatabase dbObject, Context context) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM RETAIL_AUDIT WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                RetailAuditTransDTO dto = new RetailAuditTransDTO();
                dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                return dto;
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }


}
