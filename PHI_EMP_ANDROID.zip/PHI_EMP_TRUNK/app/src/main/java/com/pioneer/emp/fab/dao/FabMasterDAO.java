package com.pioneer.emp.fab.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.parivaar.dao.DAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.emp.fab.models.CropMasterEntity;
import com.pioneer.emp.fab.models.FabMasterModel;
import com.pioneer.emp.fab.models.HybridMasterEntity;
import com.pioneer.emp.fab.models.SeasonMasterEntity;
import com.pioneer.emp.fab.models.StateCodeEntity;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

import static com.pioneer.emp.dbHandler.DBHandler.TABLE_FAB_MASTER;

/**
 * Created by fatima.t on 29-06-2017.
 */

public class FabMasterDAO implements DAO {

    private final String TAG = "FabMasterDao";
    private static FabMasterDAO fabMasterData;

    public static FabMasterDAO getInstance() {
        if ( fabMasterData == null) {
            fabMasterData = new FabMasterDAO();
        }
        return fabMasterData;
    }
    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
//            FabMasterDTO fabMasterDTO = (FabMasterDTO) dtoObject;
            FabMasterModel fabMasterDTO = (FabMasterModel) dtoObject;
            ContentValues cv = new ContentValues();

            cv.put("id", fabMasterDTO.getId());
            cv.put("version", fabMasterDTO.getVersion());
            cv.put("state", fabMasterDTO.getState());
            cv.put("stateId", fabMasterDTO.getStateId());
            cv.put("crop", fabMasterDTO.getCrop());
            cv.put("cropId", fabMasterDTO.getCropId());
            cv.put("hybrid", fabMasterDTO.getHybrid());
            cv.put("hybridId", fabMasterDTO.getHybridId());
            cv.put("season", fabMasterDTO.getSeason());
            cv.put("seasonId", fabMasterDTO.getSeasonId());

            cv.put("f_pdfFile", fabMasterDTO.getF_pdfFile());
            cv.put("f_voiceFile", fabMasterDTO.getF_voiceFile());
            cv.put("f_videoFile", fabMasterDTO.getF_videoFile());
            cv.put("f_images", fabMasterDTO.getF_images());
            cv.put("f_message", fabMasterDTO.getF_message());
            cv.put("f_localLangMessage", fabMasterDTO.getF_localLangMessage());

            cv.put("a_pdfFile", fabMasterDTO.getA_pdfFile());
            cv.put("a_voiceFile", fabMasterDTO.getA_voiceFile());
            cv.put("a_videoFile", fabMasterDTO.getA_videoFile());
            cv.put("a_images", fabMasterDTO.getA_images());
            cv.put("a_message",fabMasterDTO.getA_message());
            cv.put("a_localLangMessage", fabMasterDTO.getA_localLangMessage());

            cv.put("b_pdfFile", fabMasterDTO.getB_pdfFile());
            cv.put("b_voiceFile", fabMasterDTO.getB_voiceFile());
            cv.put("b_videoFile", fabMasterDTO.getB_videoFile());
            cv.put("b_images", fabMasterDTO.getB_images());
            cv.put("b_message",fabMasterDTO.getB_message());
            cv.put("b_localLangMessage", fabMasterDTO.getB_localLangMessage());

            cv.put("f_pdfFile_local", fabMasterDTO.getF_pdfFile_local());
            cv.put("f_voiceFile_local", fabMasterDTO.getF_voiceFile_local());
            cv.put("f_videoFile_local", fabMasterDTO.getF_videoFile_local());
            cv.put("f_images_local", fabMasterDTO.getF_images_local());
            cv.put("f_message_local", fabMasterDTO.getF_message_local());
            cv.put("f_localLangMessage_local", fabMasterDTO.getF_localLangMessage_local());

            cv.put("a_pdfFile_local", fabMasterDTO.getA_pdfFile_local());
            cv.put("a_voiceFile_local", fabMasterDTO.getA_voiceFile_local());
            cv.put("a_videoFile_local", fabMasterDTO.getA_videoFile_local());
            cv.put("a_images_local", fabMasterDTO.getA_images_local());
            cv.put("a_message_local",fabMasterDTO.getA_message_local());
            cv.put("a_localLangMessage_local", fabMasterDTO.getA_localLangMessage_local());

            cv.put("b_pdfFile_local", fabMasterDTO.getB_pdfFile_local());
            cv.put("b_voiceFile_local", fabMasterDTO.getB_voiceFile_local());
            cv.put("b_videoFile_local", fabMasterDTO.getB_videoFile_local());
            cv.put("b_images_local", fabMasterDTO.getB_images_local());
            cv.put("b_message_local",fabMasterDTO.getB_message_local());
            cv.put("b_localLangMessage_local", fabMasterDTO.getB_localLangMessage_local());

            cv.put("description", fabMasterDTO.getDescription());

            cv.put("f_image_tags", fabMasterDTO.getF_image_tags());
            cv.put("a_image_tags", fabMasterDTO.getA_image_tags());
            cv.put("b_image_tags", fabMasterDTO.getB_image_tags());

            long rowsEffected = dbObject.insert(TABLE_FAB_MASTER, null, cv);
            if (rowsEffected > 0){
            }
            return "";
        } catch (SQLException e) {
            BuildLog.i(TAG + "insert()", e.getMessage());
            return "";
        } finally {
            dbObject.close();
        }
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> fabmasterInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from "+TABLE_FAB_MASTER,null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
//                    FabMasterDTO dto = new FabMasterDTO();
                    FabMasterModel dto = new FabMasterModel();

                    dto.setId(cursor.getInt(0));
                    dto.setVersion(cursor.getString(1));
                    dto.setState(cursor.getString(2));
                    dto.setStateId(cursor.getString(3));
                    dto.setCrop(cursor.getString(4));
                    dto.setCropId(cursor.getString(5));
                    dto.setHybrid(cursor.getString(6));
                    dto.setHybridId(cursor.getString(7));
                    dto.setSeason(cursor.getString(8));
                    dto.setSeasonId(cursor.getString(9));

                    dto.setF_pdfFile(cursor.getString(10));
                    dto.setF_voiceFile(cursor.getString(11));
                    dto.setF_videoFile(cursor.getString(12));
                    dto.setF_images(cursor.getString(13));
                    dto.setF_message(cursor.getString(14));
                    dto.setF_localLangMessage(cursor.getString(15));

                    dto.setA_pdfFile(cursor.getString(16));
                    dto.setA_voiceFile(cursor.getString(17));
                    dto.setA_videoFile(cursor.getString(18));
                    dto.setA_images(cursor.getString(19));
                    dto.setA_message(cursor.getString(20));
                    dto.setA_localLangMessage(cursor.getString(21));

                    dto.setB_pdfFile(cursor.getString(22));
                    dto.setB_voiceFile(cursor.getString(23));
                    dto.setB_videoFile(cursor.getString(24));
                    dto.setB_images(cursor.getString(25));
                    dto.setB_message(cursor.getString(26));
                    dto.setB_localLangMessage(cursor.getString(27));

                    dto.setF_pdfFile_local(cursor.getString(28));
                    dto.setF_voiceFile_local(cursor.getString(29));
                    dto.setF_videoFile_local(cursor.getString(30));
                    dto.setF_images_local(cursor.getString(31));
                    dto.setF_message_local(cursor.getString(32));
                    dto.setF_localLangMessage_local(cursor.getString(33));

                    dto.setA_pdfFile_local(cursor.getString(34));
                    dto.setA_voiceFile_local(cursor.getString(35));
                    dto.setA_videoFile_local(cursor.getString(36));
                    dto.setA_images_local(cursor.getString(37));
                    dto.setA_message_local(cursor.getString(38));
                    dto.setA_localLangMessage_local(cursor.getString(39));

                    dto.setB_pdfFile_local(cursor.getString(40));
                    dto.setB_voiceFile_local(cursor.getString(41));
                    dto.setB_videoFile_local(cursor.getString(42));
                    dto.setB_images_local(cursor.getString(43));
                    dto.setB_message_local(cursor.getString(44));
                    dto.setB_localLangMessage_local(cursor.getString(45));

                    dto.setDescription(cursor.getString(46));

                    dto.setF_image_tags(cursor.getString(47));
                    dto.setA_image_tags(cursor.getString(48));
                    dto.setB_image_tags(cursor.getString(49));

                    fabmasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return fabmasterInfo;
    }

    public List<StateCodeEntity> getState(SQLiteDatabase dbObject) {
        List<StateCodeEntity> fabmasterInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select distinct stateId, state from "+TABLE_FAB_MASTER,null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    StateCodeEntity dto = new StateCodeEntity();

                    dto.setId(cursor.getString(0));
                    dto.setName(cursor.getString(1));

                    fabmasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return fabmasterInfo;
    }

    public List<CropMasterEntity> getCrops(SQLiteDatabase dbObject) {
        List<CropMasterEntity> fabmasterInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select distinct cropId, crop ,stateId from "+TABLE_FAB_MASTER,null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropMasterEntity dto = new CropMasterEntity();

                    dto.setId(cursor.getString(0));
                    dto.setName(cursor.getString(1));
                    dto.setStateId(cursor.getString(2));

                    fabmasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return fabmasterInfo;
    }

    public List<HybridMasterEntity> getHybrids(/*String cropId,*/ SQLiteDatabase dbObject) {
        List<HybridMasterEntity> fabmasterInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select distinct hybridId, hybrid, cropId from "+TABLE_FAB_MASTER /*+" WHERE cropId = '"+cropId+"'"*/,null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    HybridMasterEntity dto = new HybridMasterEntity();

                    dto.setId(cursor.getString(0));
                    dto.setName(cursor.getString(1));
                    dto.setCropId(cursor.getString(2));

                    fabmasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return fabmasterInfo;
    }

    public List<SeasonMasterEntity> getSeasons(/*String cropId, String hybridId,*/ SQLiteDatabase dbObject) {
        List<SeasonMasterEntity> fabmasterInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select distinct seasonId, season, cropId, hybridId from "+TABLE_FAB_MASTER /*+" WHERE cropId = '"+cropId+"' AND hybridId = '"+hybridId+"'"*/,null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SeasonMasterEntity dto = new SeasonMasterEntity();

                    dto.setId(cursor.getString(0));
                    dto.setName(cursor.getString(1));
                    dto.setCropId(cursor.getString(2));
                    dto.setHybridId(cursor.getString(3));

                    fabmasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return fabmasterInfo;
    }


//    public FabMasterDTO getSelectedRecord(String cropId, String hybridId, String seasonId, SQLiteDatabase dbObject) {
    public FabMasterModel getSelectedRecord(String cropId, String hybridId, String seasonId, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from "+TABLE_FAB_MASTER + " WHERE cropId = '"+cropId+"' AND hybridId = '"+hybridId+"' AND seasonId = '"+seasonId+"'",null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
//                    FabMasterDTO dto = new FabMasterDTO();
                    FabMasterModel dto = new FabMasterModel();

                    dto.setId(cursor.getInt(0));
                    dto.setVersion(cursor.getString(1));
                    dto.setState(cursor.getString(2));
                    dto.setStateId(cursor.getString(3));
                    dto.setCrop(cursor.getString(4));
                    dto.setCropId(cursor.getString(5));
                    dto.setHybrid(cursor.getString(6));
                    dto.setHybridId(cursor.getString(7));
                    dto.setSeason(cursor.getString(8));
                    dto.setSeasonId(cursor.getString(9));

                    dto.setF_pdfFile(cursor.getString(10));
                    dto.setF_voiceFile(cursor.getString(11));
                    dto.setF_videoFile(cursor.getString(12));
                    dto.setF_images(cursor.getString(13));
                    dto.setF_message(cursor.getString(14));
                    dto.setF_localLangMessage(cursor.getString(15));

                    dto.setA_pdfFile(cursor.getString(16));
                    dto.setA_voiceFile(cursor.getString(17));
                    dto.setA_videoFile(cursor.getString(18));
                    dto.setA_images(cursor.getString(19));
                    dto.setA_message(cursor.getString(20));
                    dto.setA_localLangMessage(cursor.getString(21));

                    dto.setB_pdfFile(cursor.getString(22));
                    dto.setB_voiceFile(cursor.getString(23));
                    dto.setB_videoFile(cursor.getString(24));
                    dto.setB_images(cursor.getString(25));
                    dto.setB_message(cursor.getString(26));
                    dto.setB_localLangMessage(cursor.getString(27));

                    dto.setF_pdfFile_local(cursor.getString(28));
                    dto.setF_voiceFile_local(cursor.getString(29));
                    dto.setF_videoFile_local(cursor.getString(30));
                    dto.setF_images_local(cursor.getString(31));
                    dto.setF_message_local(cursor.getString(32));
                    dto.setF_localLangMessage_local(cursor.getString(33));

                    dto.setA_pdfFile_local(cursor.getString(34));
                    dto.setA_voiceFile_local(cursor.getString(35));
                    dto.setA_videoFile_local(cursor.getString(36));
                    dto.setA_images_local(cursor.getString(37));
                    dto.setA_message_local(cursor.getString(38));
                    dto.setA_localLangMessage_local(cursor.getString(39));

                    dto.setB_pdfFile_local(cursor.getString(40));
                    dto.setB_voiceFile_local(cursor.getString(41));
                    dto.setB_videoFile_local(cursor.getString(42));
                    dto.setB_images_local(cursor.getString(43));
                    dto.setB_message_local(cursor.getString(44));
                    dto.setB_localLangMessage_local(cursor.getString(45));
                    dto.setDescription(cursor.getString(46));

                    dto.setDescription(cursor.getString(46));

                    dto.setF_image_tags(cursor.getString(47));
                    dto.setA_image_tags(cursor.getString(48));
                    dto.setB_image_tags(cursor.getString(49));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }


//    public FabMasterDTO getRecordById(long id, SQLiteDatabase dbObject) {
    public FabMasterModel getRecordById(long id, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from "+TABLE_FAB_MASTER + " WHERE id = '"+id+"'",null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
//                    FabMasterDTO dto = new FabMasterDTO();
                    FabMasterModel dto = new FabMasterModel();

                    dto.setId(cursor.getInt(0));
                    dto.setVersion(cursor.getString(1));
                    dto.setState(cursor.getString(2));
                    dto.setStateId(cursor.getString(3));
                    dto.setCrop(cursor.getString(4));
                    dto.setCropId(cursor.getString(5));
                    dto.setHybrid(cursor.getString(6));
                    dto.setHybridId(cursor.getString(7));
                    dto.setSeason(cursor.getString(8));
                    dto.setSeasonId(cursor.getString(9));

                    dto.setF_pdfFile(cursor.getString(10));
                    dto.setF_voiceFile(cursor.getString(11));
                    dto.setF_videoFile(cursor.getString(12));
                    dto.setF_images(cursor.getString(13));
                    dto.setF_message(cursor.getString(14));
                    dto.setF_localLangMessage(cursor.getString(15));

                    dto.setA_pdfFile(cursor.getString(16));
                    dto.setA_voiceFile(cursor.getString(17));
                    dto.setA_videoFile(cursor.getString(18));
                    dto.setA_images(cursor.getString(19));
                    dto.setA_message(cursor.getString(20));
                    dto.setA_localLangMessage(cursor.getString(21));

                    dto.setB_pdfFile(cursor.getString(22));
                    dto.setB_voiceFile(cursor.getString(23));
                    dto.setB_videoFile(cursor.getString(24));
                    dto.setB_images(cursor.getString(25));
                    dto.setB_message(cursor.getString(26));
                    dto.setB_localLangMessage(cursor.getString(27));

                    dto.setF_pdfFile_local(cursor.getString(28));
                    dto.setF_voiceFile_local(cursor.getString(29));
                    dto.setF_videoFile_local(cursor.getString(30));
                    dto.setF_images_local(cursor.getString(31));
                    dto.setF_message_local(cursor.getString(32));
                    dto.setF_localLangMessage_local(cursor.getString(33));

                    dto.setA_pdfFile_local(cursor.getString(34));
                    dto.setA_voiceFile_local(cursor.getString(35));
                    dto.setA_videoFile_local(cursor.getString(36));
                    dto.setA_images_local(cursor.getString(37));
                    dto.setA_message_local(cursor.getString(38));
                    dto.setA_localLangMessage_local(cursor.getString(39));

                    dto.setB_pdfFile_local(cursor.getString(40));
                    dto.setB_voiceFile_local(cursor.getString(41));
                    dto.setB_videoFile_local(cursor.getString(42));
                    dto.setB_images_local(cursor.getString(43));
                    dto.setB_message_local(cursor.getString(44));
                    dto.setB_localLangMessage_local(cursor.getString(45));
                    dto.setDescription(cursor.getString(46));

                    dto.setF_image_tags(cursor.getString(47));
                    dto.setA_image_tags(cursor.getString(48));
                    dto.setB_image_tags(cursor.getString(49));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }

//    public FabMasterDTO getSelectedRecordById(String id, SQLiteDatabase dbObject) {
    public FabMasterModel getSelectedRecordById(String id, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from "+TABLE_FAB_MASTER+ " WHERE id = '"+id+"'",null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
//                    FabMasterDTO dto = new FabMasterDTO();
                    FabMasterModel dto = new FabMasterModel();
                    dto.setVersion(cursor.getString(1));
                    dto.setState(cursor.getString(2));
                    dto.setStateId(cursor.getString(3));
                    dto.setCrop(cursor.getString(4));
                    dto.setCropId(cursor.getString(5));
                    dto.setHybrid(cursor.getString(6));
                    dto.setHybridId(cursor.getString(7));
                    dto.setSeason(cursor.getString(8));
                    dto.setSeasonId(cursor.getString(9));

                    dto.setF_pdfFile(cursor.getString(10));
                    dto.setF_voiceFile(cursor.getString(11));
                    dto.setF_videoFile(cursor.getString(12));
                    dto.setF_images(cursor.getString(13));
                    dto.setF_message(cursor.getString(14));
                    dto.setF_localLangMessage(cursor.getString(15));

                    dto.setA_pdfFile(cursor.getString(16));
                    dto.setA_voiceFile(cursor.getString(17));
                    dto.setA_videoFile(cursor.getString(18));
                    dto.setA_images(cursor.getString(19));
                    dto.setA_message(cursor.getString(20));
                    dto.setA_localLangMessage(cursor.getString(21));

                    dto.setB_pdfFile(cursor.getString(22));
                    dto.setB_voiceFile(cursor.getString(23));
                    dto.setB_videoFile(cursor.getString(24));
                    dto.setB_images(cursor.getString(25));
                    dto.setB_message(cursor.getString(26));
                    dto.setB_localLangMessage(cursor.getString(27));

                    dto.setF_pdfFile_local(cursor.getString(28));
                    dto.setF_voiceFile_local(cursor.getString(29));
                    dto.setF_videoFile_local(cursor.getString(30));
                    dto.setF_images_local(cursor.getString(31));
                    dto.setF_message_local(cursor.getString(32));
                    dto.setF_localLangMessage_local(cursor.getString(33));

                    dto.setA_pdfFile_local(cursor.getString(34));
                    dto.setA_voiceFile_local(cursor.getString(35));
                    dto.setA_videoFile_local(cursor.getString(36));
                    dto.setA_images_local(cursor.getString(37));
                    dto.setA_message_local(cursor.getString(38));
                    dto.setA_localLangMessage_local(cursor.getString(39));

                    dto.setB_pdfFile_local(cursor.getString(40));
                    dto.setB_voiceFile_local(cursor.getString(41));
                    dto.setB_videoFile_local(cursor.getString(42));
                    dto.setB_images_local(cursor.getString(43));
                    dto.setB_message_local(cursor.getString(44));
                    dto.setB_localLangMessage_local(cursor.getString(45));

                    dto.setDescription(cursor.getString(46));

                    dto.setF_image_tags(cursor.getString(47));
                    dto.setA_image_tags(cursor.getString(48));
                    dto.setB_image_tags(cursor.getString(49));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }


    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  "+ DBHandler.TABLE_FAB_MASTER).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public boolean updateRecordById(DTO mainDTO, SQLiteDatabase dbObject) {
        try {
//            FabMasterDTO fabMasterDTO = (FabMasterDTO) mainDTO;
            FabMasterModel fabMasterDTO = (FabMasterModel) mainDTO;
            ContentValues cv = new ContentValues();

            cv.put("version", fabMasterDTO.getVersion());
            cv.put("state", fabMasterDTO.getState());
            cv.put("stateId", fabMasterDTO.getStateId());
            cv.put("crop", fabMasterDTO.getCrop());
            cv.put("cropId", fabMasterDTO.getCropId());
            cv.put("hybrid", fabMasterDTO.getHybrid());
            cv.put("hybridId", fabMasterDTO.getHybridId());
            cv.put("season", fabMasterDTO.getSeason());
            cv.put("seasonId", fabMasterDTO.getSeasonId());

            cv.put("f_pdfFile", fabMasterDTO.getF_pdfFile());
            cv.put("f_voiceFile", fabMasterDTO.getF_voiceFile());
            cv.put("f_videoFile", fabMasterDTO.getF_videoFile());
            cv.put("f_images", fabMasterDTO.getF_images());
            cv.put("f_message", fabMasterDTO.getF_message());
            cv.put("f_localLangMessage", fabMasterDTO.getF_localLangMessage());

            cv.put("a_pdfFile", fabMasterDTO.getA_pdfFile());
            cv.put("a_voiceFile", fabMasterDTO.getA_voiceFile());
            cv.put("a_videoFile", fabMasterDTO.getA_videoFile());
            cv.put("a_images", fabMasterDTO.getA_images());
            cv.put("a_message",fabMasterDTO.getA_message());
            cv.put("a_localLangMessage", fabMasterDTO.getA_localLangMessage());

            cv.put("b_pdfFile", fabMasterDTO.getB_pdfFile());
            cv.put("b_voiceFile", fabMasterDTO.getB_voiceFile());
            cv.put("b_videoFile", fabMasterDTO.getB_videoFile());
            cv.put("b_images", fabMasterDTO.getB_images());
            cv.put("b_message",fabMasterDTO.getB_message());
            cv.put("b_localLangMessage", fabMasterDTO.getB_localLangMessage());

            if(fabMasterDTO.getF_pdfFile_local() != null)
                cv.put("f_pdfFile_local", fabMasterDTO.getF_pdfFile_local());
            if(fabMasterDTO.getF_voiceFile_local() != null)
                cv.put("f_voiceFile_local", fabMasterDTO.getF_voiceFile_local());
            if(fabMasterDTO.getF_videoFile_local() != null)
                cv.put("f_videoFile_local", fabMasterDTO.getF_videoFile_local());
            if(fabMasterDTO.getF_images_local() != null)
                cv.put("f_images_local", fabMasterDTO.getF_images_local());
            if(fabMasterDTO.getF_message_local() != null)
                cv.put("f_message_local", fabMasterDTO.getF_message_local());
            if(fabMasterDTO.getF_localLangMessage_local() != null)
                cv.put("f_localLangMessage_local", fabMasterDTO.getF_localLangMessage_local());

            if(fabMasterDTO.getA_pdfFile_local() != null)
                cv.put("a_pdfFile_local", fabMasterDTO.getA_pdfFile_local());
            if(fabMasterDTO.getA_voiceFile_local() != null)
                cv.put("a_voiceFile_local", fabMasterDTO.getA_voiceFile_local());
            if(fabMasterDTO.getA_videoFile_local() != null)
                cv.put("a_videoFile_local", fabMasterDTO.getA_videoFile_local());
            if(fabMasterDTO.getA_images_local() != null)
                cv.put("a_images_local", fabMasterDTO.getA_images_local());
            if(fabMasterDTO.getA_message_local() != null)
                cv.put("a_message_local",fabMasterDTO.getA_message_local());
            if(fabMasterDTO.getA_localLangMessage_local() != null)
                cv.put("a_localLangMessage_local", fabMasterDTO.getA_localLangMessage_local());


            if(fabMasterDTO.getB_pdfFile_local() != null)
                cv.put("b_pdfFile_local", fabMasterDTO.getB_pdfFile_local());
            if(fabMasterDTO.getB_voiceFile_local() != null)
                cv.put("b_voiceFile_local", fabMasterDTO.getB_voiceFile_local());
            if(fabMasterDTO.getB_videoFile_local() != null)
                cv.put("b_videoFile_local", fabMasterDTO.getB_videoFile_local());
            if(fabMasterDTO.getB_images_local() != null)
                cv.put("b_images_local", fabMasterDTO.getB_images_local());
            if(fabMasterDTO.getB_message_local() != null)
                cv.put("b_message_local",fabMasterDTO.getB_message_local());
            if(fabMasterDTO.getB_localLangMessage_local() != null)
                cv.put("b_localLangMessage_local", fabMasterDTO.getB_localLangMessage_local());

            cv.put("description", fabMasterDTO.getDescription());

            cv.put("f_image_tags", fabMasterDTO.getF_image_tags());
            cv.put("a_image_tags", fabMasterDTO.getA_image_tags());
            cv.put("b_image_tags", fabMasterDTO.getB_image_tags());

            dbObject.update(DBHandler.TABLE_FAB_MASTER, cv, "id = '"+fabMasterDTO.getId()+"'", null);
            return true;
        } catch (Exception e) {
            BuildLog.d(TAG, "updateRecordById: ");
        } finally {
            dbObject.close();
        }
        return false;
    }

    public int isDataAvailable(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT id FROM "+DBHandler.TABLE_FAB_MASTER, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
            return 0;
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return 0;
    }


    public String getVersionNumberOfCombo(String cropId, String hybridId, String seasonId, SQLiteDatabase dbObject){
        Cursor cursor = null;
        try{
            cursor = dbObject.rawQuery("SELECT version FROM "+TABLE_FAB_MASTER+ " WHERE cropId = '"+cropId+"' AND hybridId = '"+hybridId+"' AND seasonId = '"+seasonId+"'",null);
            if ( cursor.getCount() > 0){
                cursor.moveToFirst();
                return cursor.getString(0);
            }
        } catch (Exception e){
            BuildLog.e(TAG, e.getMessage());
            return "";
        } finally {
            if (cursor!=null && !cursor.isClosed()){
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }

    public boolean isDataExist(long id, SQLiteDatabase dbObject){
        Cursor cursor = null;
        try{
            cursor = dbObject.rawQuery("SELECT * FROM "+TABLE_FAB_MASTER + " WHERE id = '"+id+"'",null);
            return cursor.getCount() > 0;
        } catch (Exception e){
            BuildLog.e(TAG, e.getMessage());
            return false;
        } finally {
            if (cursor!=null && !cursor.isClosed()){
                cursor.close();
            }
            dbObject.close();
        }
    }

    public String isCombinationExist(String cropId, String hybridId, String seasonId, String stateId, SQLiteDatabase dbObject){
        Cursor cursor = null;
        try{
            cursor = dbObject.rawQuery("SELECT * FROM "+TABLE_FAB_MASTER+ " WHERE cropId = '"+cropId+"' AND hybridId = '"+hybridId+"' AND seasonId = '"+seasonId+"' AND stateId = '"+stateId+"'",null);
            if ( cursor.getCount() > 0){
                cursor.moveToFirst();
                return cursor.getString(0);
            }
        } catch (Exception e){
            BuildLog.e(TAG, e.getMessage());
            return "";
        } finally {
            if (cursor!=null && !cursor.isClosed()){
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }


}
