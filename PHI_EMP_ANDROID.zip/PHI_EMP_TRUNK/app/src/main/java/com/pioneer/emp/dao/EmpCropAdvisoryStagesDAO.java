package com.pioneer.emp.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.CropAdvisoryStagesModel;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fatima on 31-07-2017.
 */
public class EmpCropAdvisoryStagesDAO implements DAO {

    private final String TAG = "EmpCropAdvisoryStages";
    private static EmpCropAdvisoryStagesDAO EmpCropAdvisoryStages;

    public static EmpCropAdvisoryStagesDAO getInstance() {
        if ( EmpCropAdvisoryStages == null) {
            EmpCropAdvisoryStages = new EmpCropAdvisoryStagesDAO();
        }
        return EmpCropAdvisoryStages;
    }

    @SuppressLint("LongLogTag")
    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            CropAdvisoryStagesModel dto = (CropAdvisoryStagesModel) dtoObject;
            ContentValues cValues = new ContentValues();
            cValues.put("idStage", dto.getId());
            cValues.put("cropAdvisoryId",dto.getCropAdvisoryId());
            cValues.put("message",dto.getMessage());
            cValues.put("noOfDays",dto.getNoOfDays());
            cValues.put("stageName",dto.getStageName());
            cValues.put("messageInLocalLang",dto.getMessageInLocaLang());
            cValues.put("voiceFileName", dto.getVoiceFileName());
            cValues.put("voiceFileLocalPath", dto.getVoiceFileLocalPath());

            long rowsEffected = dbObject.insert(DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES, null, cValues);
            if(rowsEffected >0)
                return "";
            } catch (SQLException e) {
            BuildLog.i(TAG + "insert()", e.getMessage());
                return "";
            } finally {
                dbObject.close();
            }
        return  "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try{
            
        }catch (SQLException e){

        } finally {
            dbObject.close();
        }
        return false;
    }

    @SuppressLint("LongLogTag")
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        CropAdvisoryStagesModel dto = (CropAdvisoryStagesModel) dtoObject;
        try {

            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES + " WHERE cropAdvisoryId  = '" + dto.getCropAdvisoryId() + "'").execute();

//            dbObject.compileStatement("DELETE FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES).execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    @SuppressLint("LongLogTag")
    public boolean deleteByCategory(DTO dtoObject, SQLiteDatabase dbObject) {
        CropAdvisoryStagesModel dto = (CropAdvisoryStagesModel) dtoObject;
        try {
            dbObject.compileStatement("DELETE FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES +" WHERE cropAdvisoryId = '"+dto.getCropAdvisoryId()+"' ").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
            List<DTO> couponData = new ArrayList<>();
            Cursor cursor = null;
            try {
                cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES, null);
                    if (cursor.getCount() > 0) {
                    cursor.moveToFirst();
                    do {
                        CropAdvisoryStagesModel dto = new CropAdvisoryStagesModel();
                        dto.setId(cursor.getLong(0));
                        dto.setCropAdvisoryId(cursor.getLong(1));
                        dto.setMessage(cursor.getString(2));
                        dto.setNoOfDays(cursor.getString(3));
                        dto.setStageName(cursor.getString(4));
                        dto.setMessageInLocaLang(cursor.getString(5));
                        dto.setVoiceFileName(cursor.getString(6));
                        dto.setVoiceFileLocalPath(cursor.getString(7));

                     /*   dto.setId(cursor.getLong(0));
                        dto.setName(cursor.getString(1));*/
                        couponData.add(dto);
                    } while (cursor.moveToNext());
                }
            } catch (Exception e) {
                BuildLog.e(TAG, e.getMessage());
            } finally {
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
                dbObject.close();
            }
            return couponData;
    }


    public CropAdvisoryStagesModel getRecordById(long idStage, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES + " WHERE idStage = '"+idStage+"'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropAdvisoryStagesModel dto = new CropAdvisoryStagesModel();
                    dto.setId(cursor.getLong(0));
                    dto.setCropAdvisoryId(cursor.getLong(1));
                    dto.setMessage(cursor.getString(2));
                    dto.setNoOfDays(cursor.getString(3));
                    dto.setStageName(cursor.getString(4));
                    dto.setMessageInLocaLang(cursor.getString(5));
                    dto.setVoiceFileName(cursor.getString(6));
                    dto.setVoiceFileLocalPath(cursor.getString(7));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  "+DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    /**
     * It will return number of coupons available for upload, if there are no coupons available in local to sync it will return 0
     * @param dbObject
     * @return number of records available to sync
     */
    public int isDataAvailable(DTO dtoObject,SQLiteDatabase dbObject) {
        CropAdvisoryStagesModel dto = (CropAdvisoryStagesModel) dtoObject;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(idStage) FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
            return 0;
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return 0;
    }


    public ArrayList<CropAdvisoryStagesModel> getRecordsByCropAdvisoryId(long cropAdvisoryId, SQLiteDatabase dbObject) {
        ArrayList<CropAdvisoryStagesModel> couponData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES+" WHERE cropAdvisoryId = '"+cropAdvisoryId+"' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropAdvisoryStagesModel dto = new CropAdvisoryStagesModel();
                    dto.setId(cursor.getLong(0));
                    dto.setCropAdvisoryId(cursor.getLong(1));
                    dto.setMessage(cursor.getString(2));
                    dto.setNoOfDays(cursor.getString(3));
                    dto.setStageName(cursor.getString(4));
                    dto.setMessageInLocaLang(cursor.getString(5));
                    dto.setVoiceFileName(cursor.getString(6));
                    dto.setVoiceFileLocalPath(cursor.getString(7));

                     /*   dto.setId(cursor.getLong(0));
                        dto.setName(cursor.getString(1));*/
                    couponData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return couponData;
    }

    public boolean updateRecordById(DTO mainDTO, SQLiteDatabase dbObject){
        try {

            CropAdvisoryStagesModel dto = (CropAdvisoryStagesModel) mainDTO;
            ContentValues cValues = new ContentValues();

            cValues.put("idStage", dto.getId());
            cValues.put("cropAdvisoryId",dto.getCropAdvisoryId());
            cValues.put("message",dto.getMessage());
            cValues.put("noOfDays",dto.getNoOfDays());
            cValues.put("stageName",dto.getStageName());
            cValues.put("messageInLocalLang",dto.getMessageInLocaLang());
            cValues.put("voiceFileName", dto.getVoiceFileName());

            if(dto.getVoiceFileLocalPath() != null)
                cValues.put("voiceFileLocalPath", dto.getVoiceFileLocalPath());

            dbObject.update(DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES, cValues, "idStage = '"+dto.getId()+"'", null);
            return true;
        }catch (Exception e) {
            BuildLog.d(TAG, "updateRecordById: ");
        } finally {
            dbObject.close();
        }
        return false;
    }

    @SuppressLint("LongLogTag")
    public boolean deleteByCropAdvisoryId(long cropAdvisoryId, SQLiteDatabase dbObject) {
        try {

            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_EMP_CROP_ADVISORY_STAGES + " WHERE cropAdvisoryId  = '" + cropAdvisoryId + "'").execute();

            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }
}
