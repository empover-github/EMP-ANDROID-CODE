package com.pioneer.emp.cropDiagnostic;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.pioneer.emp.R;
import com.pioneer.emp.dao.AgroDiseaseProductMappingDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.AgroDiseaseProductMappingDTO;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit.RetrofitError;

/**
 * Created by rambabu.a on 17-01-2018.
 */

public class CDProductDetailsActivity  extends BaseActivity implements View.OnClickListener{
    private Toolbar toolbar;
    private TextView txtHeader;
    private ImageView navBackBtn;

    private LinearLayout linearLayoutImage,linearLayout1, linearLayout2, linearLayout3, linearLayout4, linearLayout5, linearLayout6;
    private TextView headerTextImage,headerText1,headerText2,headerText3,headerText4,headerText5,headerText6;
    private TextView detailText1,detailText2,detailText3,detailText4,detailText5, noDataAvailableTaxt;
    private ListView relatedHazardsListView;
    private CheckedTextView checkedTextViewImage,checkedTextView1,checkedTextView2,checkedTextView3,checkedTextView4,checkedTextView5,checkedTextView6;
    private ImageView packingImage;
    private ScrollView scrollView;

    private AgroDiseaseProductMappingDTO dto;

    private ArrayAdapter<String> hazardsAdapter;
    private ArrayList<String> hazardsList = new ArrayList<>();
    private ArrayList<String> deseasID = new ArrayList<>();

    public static final String EXTRA_PRODUCT_MAPPING_ID = "productMappingId";
    public static final String RELATED_PRODUCT_MAPPING_ID = "productMappingId";
    static String productId = "", productName = "";
    CDProductDetailsActivity thisActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cd_product_details);

        // ActionBar Related components
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        thisActivity=this;
        txtHeader = findViewById(R.id.header_text);
        txtHeader.setText(getString(R.string.agroProducts));
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);

        initilizeViews();

        if (AppConstants.DiseasesAdapter.equals(Utils.getCDAdapter(CDProductDetailsActivity.this))){

            Intent i = getIntent();
            productId = i.getStringExtra(RELATED_PRODUCT_MAPPING_ID);

            if (Utils.isNetworkConnection(CDProductDetailsActivity.this)){
                JSONObject jsonObject=new JSONObject();
                try {
                    jsonObject.put("productId",productId);
                }catch (JSONException e){
                    e.getMessage();
                }
                String jwsToken=Utils.getJWTToken(jsonObject.toString(),CDProductDetailsActivity.this);
                APIRequestHandler.getInstance().getCDDiseaseDetectedRelatedProduct(thisActivity,jwsToken, true);
            }else{

                if (Utils.isValidStr(productId))
                    dto = AgroDiseaseProductMappingDAO.getInstance().getSelectedRecordById(productId, DBHandler.getReadableDb(CDProductDetailsActivity.this));

                if (dto!=null)
                    setData(dto);

            }

            Utils.setCDAdapter(AppConstants.DiseasesAdapter,CDProductDetailsActivity.this);

        } else {
            Intent i = getIntent();
            productId = i.getStringExtra(EXTRA_PRODUCT_MAPPING_ID);

            // make DB call here mapping with above productId
            if (Utils.isValidStr(productId))
                dto = AgroDiseaseProductMappingDAO.getInstance().getSelectedRecordById(productId, DBHandler.getReadableDb(CDProductDetailsActivity.this));

            if (dto!=null)
                setData(dto);
        }
    }

    private void initilizeViews() {
        linearLayoutImage = findViewById(R.id.ll_image);
        linearLayout1 = findViewById(R.id.ll1);
        linearLayout2 = findViewById(R.id.ll2);
        linearLayout3 = findViewById(R.id.ll3);
        linearLayout4 = findViewById(R.id.ll4);
        linearLayout5 = findViewById(R.id.ll5);
        linearLayout6 = findViewById(R.id.ll6);

        headerTextImage = findViewById(R.id.headerTxtImage);
        headerText1 = findViewById(R.id.headerTxt1);
        headerText2 = findViewById(R.id.headerTxt2);
        headerText3 = findViewById(R.id.headerTxt3);
        headerText4 = findViewById(R.id.headerTxt4);
        headerText5 = findViewById(R.id.headerTxt5);
        headerText6 = findViewById(R.id.headerTxt6);

        packingImage = findViewById(R.id.cdd_img);
        detailText1 = findViewById(R.id.detailTxt1);
        detailText2 = findViewById(R.id.detailTxt2);
        detailText3 = findViewById(R.id.detailTxt3);
        detailText4 = findViewById(R.id.detailTxt4);
        detailText5 = findViewById(R.id.detailTxt5);
        relatedHazardsListView = findViewById(R.id.cdpd_related_hazards_list);
        noDataAvailableTaxt = findViewById(R.id.cdpd_noDataAvailableTxt);
        scrollView = findViewById(R.id.cdpd_scroll_view);

        checkedTextViewImage = findViewById(R.id.checkedTextViewImage);
        checkedTextView1 = findViewById(R.id.checkedTextView1);
        checkedTextView2 = findViewById(R.id.checkedTextView2);
        checkedTextView3 = findViewById(R.id.checkedTextView3);
        checkedTextView4 = findViewById(R.id.checkedTextView4);
        checkedTextView5 = findViewById(R.id.checkedTextView5);
        checkedTextView6 = findViewById(R.id.checkedTextView6);


       /* checkedTextViewImage.setOnClickListener(this);
        checkedTextView1.setOnClickListener(this);
        checkedTextView2.setOnClickListener(this);
        checkedTextView3.setOnClickListener(this);
        checkedTextView4.setOnClickListener(this);
        checkedTextView5.setOnClickListener(this);
        checkedTextView6.setOnClickListener(this);*/

        linearLayoutImage.setOnClickListener(this);
        packingImage.setOnClickListener(this); // added for zoom purpose
        linearLayout1.setOnClickListener(this);
        linearLayout2.setOnClickListener(this);
        linearLayout3.setOnClickListener(this);
        linearLayout4.setOnClickListener(this);
        linearLayout5.setOnClickListener(this);
        linearLayout6.setOnClickListener(this);

        hazardsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, hazardsList);
        relatedHazardsListView.setAdapter(hazardsAdapter);
        getListViewSize(relatedHazardsListView); // to set layout of scrollview, which shows all the items of listview

        // First Hide all layouts then depends on data available made it visible
        linearLayoutImage.setVisibility(View.GONE);
        linearLayout1.setVisibility(View.GONE);
        linearLayout2.setVisibility(View.GONE);
        linearLayout3.setVisibility(View.GONE);
        linearLayout4.setVisibility(View.GONE);
        linearLayout5.setVisibility(View.GONE);
        linearLayout6.setVisibility(View.GONE);
    }

    private void setData(AgroDiseaseProductMappingDTO dto) {

        if (dto != null){
            noDataAvailableTaxt.setVisibility(View.GONE);
            scrollView.setVisibility(View.VISIBLE);
            if (Utils.isValidStr(dto.getProductName())){
                txtHeader.setText(dto.getProductName());
            }

            if (Utils.isValidStr(dto.getProductImage()) && Utils.isNetworkConnection(CDProductDetailsActivity.this)){
                linearLayoutImage.setVisibility(View.VISIBLE);
                packingImage.setVisibility(View.VISIBLE);
                Glide.with(CDProductDetailsActivity.this)
                        .load(dto.getProductImage())
                        .error(R.drawable.image_placeholder)
                        .placeholder(R.drawable.image_placeholder)
                        .dontAnimate().into(packingImage);
                checkedTextViewImage.setChecked(true);
                packingImage.setVisibility(View.VISIBLE);
                checkedTextViewImage.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
            }else if (Utils.isValidStr(dto.getAgro_images_local())){
                linearLayoutImage.setVisibility(View.VISIBLE);
                packingImage.setVisibility(View.VISIBLE);
                Glide.with(CDProductDetailsActivity.this)
                        .load(dto.getAgro_images_local())
                        .error(R.drawable.image_placeholder)
                        .placeholder(R.drawable.image_placeholder)
                        .dontAnimate().into(packingImage);
                checkedTextViewImage.setChecked(true);
                packingImage.setVisibility(View.VISIBLE);
                checkedTextViewImage.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
            } else {
                linearLayoutImage.setVisibility(View.GONE);
            }
            /*if (Utils.isValidStr(dto.getAgro_images_local())){
                linearLayoutImage.setVisibility(View.VISIBLE);
                packingImage.setVisibility(View.VISIBLE);
                Glide.with(CDProductDetailsActivity.this)
                        .load(dto.getAgro_images_local())
                        .error(R.drawable.image_placeholder)
                        .placeholder(R.drawable.image_placeholder)
                        .dontAnimate().into(packingImage);
                checkedTextViewImage.setChecked(true);
                packingImage.setVisibility(View.VISIBLE);
                checkedTextViewImage.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
            } else if (Utils.isValidStr(dto.getProductImage()) && Utils.isNetworkConnection(CDProductDetailsActivity.this)){
                linearLayoutImage.setVisibility(View.VISIBLE);
                packingImage.setVisibility(View.VISIBLE);
                Glide.with(CDProductDetailsActivity.this)
                        .load(dto.getProductImage())
                        .error(R.drawable.image_placeholder)
                        .placeholder(R.drawable.image_placeholder)
                        .dontAnimate().into(packingImage);
                checkedTextViewImage.setChecked(true);
                packingImage.setVisibility(View.VISIBLE);
                checkedTextViewImage.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
            } else {
                linearLayoutImage.setVisibility(View.GONE);
            }*/

            if (Utils.isValidStr(dto.getCharacter())){
                detailText1.setText(dto.getCharacter());
                linearLayout1.setVisibility(View.VISIBLE);
            } else {
                detailText1.setText("");
                linearLayout1.setVisibility(View.GONE);
            }

            if (Utils.isValidStr(dto.getWork())){
                detailText2.setText(dto.getWork());
                linearLayout2.setVisibility(View.VISIBLE);
            } else {
                detailText2.setText("");
                linearLayout2.setVisibility(View.GONE);
            }

            if (Utils.isValidStr(dto.getProductUse())){
                detailText3.setText(dto.getProductUse());
                linearLayout3.setVisibility(View.VISIBLE);
            } else {
                detailText3.setText("");
                linearLayout3.setVisibility(View.GONE);
            }

            if (Utils.isValidStr(dto.getCaution())){
                detailText4.setText(dto.getCaution());
                linearLayout4.setVisibility(View.VISIBLE);
            } else {
                detailText4.setText("");
                linearLayout4.setVisibility(View.GONE);
            }

            if (Utils.isValidStr(dto.getResultAndEffect())){
                detailText5.setText(dto.getResultAndEffect());
                linearLayout5.setVisibility(View.VISIBLE);
            } else {
                detailText5.setText("");
                linearLayout5.setVisibility(View.GONE);
            }

           /* if (Utils.isValidStr(dto.getCropAndDiseaseNamesForMobile())){
                linearLayout6.setVisibility(View.VISIBLE);
                List<String> tempList = Arrays.asList(dto.getCropAndDiseaseNamesForMobile()*//*.replace(" ","")*//*.split(","));
                hazardsList.clear();
                hazardsList.addAll(tempList);
                hazardsAdapter.notifyDataSetChanged();
                getListViewSize(relatedHazardsListView); // to set layout of scrollview, which shows all the items of listview
            } else {
                hazardsList.clear();
                hazardsAdapter.notifyDataSetChanged();
                getListViewSize(relatedHazardsListView); // to set layout of scrollview, which shows all the items of listview
                linearLayout6.setVisibility(View.GONE);
            }*/


            if (Utils.isValidStr(dto.getCropAndDiseaseNamesForMobile())){

                if (AppConstants.DiseasesAdapter.equals(Utils.getCDAdapter(CDProductDetailsActivity.this))){
                    linearLayout6.setVisibility(View.VISIBLE);
                    List<String> tempList = Arrays.asList(dto.getCropAndDiseaseNamesForMobile()/*.replace(" ","")*/.split(","));
                    List<String> did = Arrays.asList(dto.getDiseaseId().split(","));
                    hazardsList.clear();
                    deseasID.clear();
                    hazardsList.addAll(tempList);
                    deseasID.addAll(did);
                    hazardsAdapter.notifyDataSetChanged();
                    getListViewSize(relatedHazardsListView); // to set layout of scrollview, which shows all the items of listview
                }else{
                    linearLayout6.setVisibility(View.VISIBLE);
                    List<String> tempList = Arrays.asList(dto.getCropAndDiseaseNamesForMobile()/*.replace(" ","")*/.split(","));
                    hazardsList.clear();
                    hazardsList.addAll(tempList);
                    hazardsAdapter.notifyDataSetChanged();
                    getListViewSize(relatedHazardsListView); // to set layout of scrollview, which shows all the items of listview
                }

            } else {
                hazardsList.clear();
                deseasID.clear();
                hazardsAdapter.notifyDataSetChanged();
                getListViewSize(relatedHazardsListView); // to set layout of scrollview, which shows all the items of listview
                linearLayout6.setVisibility(View.GONE);
            }


            relatedHazardsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                    DialogManager.showToast(CDProductDetailsActivity.this, "Clicked on :" +hazardsList.get(i));
                    String[] clickedItem = hazardsList.get(i).split("-");
                    String diseaseName = clickedItem[2];
                    char firstChar = diseaseName.charAt(0);
                    char empty = ' ';
                    if (firstChar == empty)
                        diseaseName = diseaseName.substring(1);

                    if (AppConstants.DiseasesAdapter.equals(Utils.getCDAdapter(CDProductDetailsActivity.this))){
                        if (Utils.isNetworkConnection(CDProductDetailsActivity.this)){
                            String did=deseasID.get(i);
                            Intent intent=new Intent(CDProductDetailsActivity.this, CDHazardDetailsActivity.class);
                            intent.putExtra(CDHazardDetailsActivity.EXTRA_DISEASE_ID, did);
                            startActivity(intent);

                        }else{
                            DialogManager.showToast(CDProductDetailsActivity.this, getString(R.string.no_internet));
                        }

                    }else {
                        Utils.setCDAdapter("",CDProductDetailsActivity.this);
                        Intent gotoCDHazardsDA = new Intent(CDProductDetailsActivity.this, CDHazardDetailsActivity.class);
                        gotoCDHazardsDA.putExtra(CDHazardDetailsActivity.EXTRA_CROP_NAME, clickedItem[0].trim());
                        gotoCDHazardsDA.putExtra(CDHazardDetailsActivity.EXTRA_CATEGORY, clickedItem[1].trim());
                        gotoCDHazardsDA.putExtra(CDHazardDetailsActivity.EXTRA_DISEASE_NAME, diseaseName);
                        startActivity(gotoCDHazardsDA);
                    }
                }
            });

        } else {
            noDataAvailableTaxt.setVisibility(View.VISIBLE);
            scrollView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imgBacknav:
                onBackPressed();
                break;
//            case R.id.checkedTextViewImage:
            case R.id.ll_image:
                if (!checkedTextViewImage.isChecked()){
                    checkedTextViewImage.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    checkedTextViewImage.setChecked(true);
                    packingImage.setVisibility(View.VISIBLE);
                } else {
                    checkedTextViewImage.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    checkedTextViewImage.setChecked(false);
                    packingImage.setVisibility(View.GONE);
                }
                break;
            case R.id.cdd_img:
                if (Utils.isValidStr(dto.getAgro_images_local())){
                    ImageViewer(CDProductDetailsActivity.this,dto.getAgro_images_local());
                } else if (Utils.isValidStr(dto.getProductImage()) && Utils.isNetworkConnection(CDProductDetailsActivity.this)) {
                    ImageViewer(CDProductDetailsActivity.this,dto.getProductImage());
                }
                break;
//            case R.id.checkedTextView1:
            case R.id.ll1:
                if (!checkedTextView1.isChecked()){
                    checkedTextView1.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    detailText1.setVisibility(View.VISIBLE);
                    checkedTextView1.setChecked(true);
                } else {
                    checkedTextView1.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    detailText1.setVisibility(View.GONE);
                    checkedTextView1.setChecked(false);
                }
                break;
//            case R.id.checkedTextView2:
            case R.id.ll2:
                if (!checkedTextView2.isChecked()){
                    checkedTextView2.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    detailText2.setVisibility(View.VISIBLE);
                    checkedTextView2.setChecked(true);
                } else {
                    checkedTextView2.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    detailText2.setVisibility(View.GONE);
                    checkedTextView2.setChecked(false);
                }
                break;
//            case R.id.checkedTextView3:
            case R.id.ll3:
                if (!checkedTextView3.isChecked()){
                    checkedTextView3.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    detailText3.setVisibility(View.VISIBLE);
                    checkedTextView3.setChecked(true);
                } else {
                    checkedTextView3.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    detailText3.setVisibility(View.GONE);
                    checkedTextView3.setChecked(false);
                }
                break;
//            case R.id.checkedTextView4:
            case R.id.ll4:
                if (!checkedTextView4.isChecked()){
                    checkedTextView4.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    detailText4.setVisibility(View.VISIBLE);
                    checkedTextView4.setChecked(true);
                } else {
                    checkedTextView4.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    detailText4.setVisibility(View.GONE);
                    checkedTextView4.setChecked(false);
                }
                break;
//            case R.id.checkedTextView5:
            case R.id.ll5:
                if (!checkedTextView5.isChecked()){
                    checkedTextView5.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    detailText5.setVisibility(View.VISIBLE);
                    checkedTextView5.setChecked(true);
                } else {
                    checkedTextView5.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    detailText5.setVisibility(View.GONE);
                    checkedTextView5.setChecked(false);
                }
                break;
//            case R.id.checkedTextView6:
            case R.id.ll6:
                if (!checkedTextView6.isChecked()){
                    checkedTextView6.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    relatedHazardsListView.setVisibility(View.VISIBLE);
                    checkedTextView6.setChecked(true);
                } else {
                    checkedTextView6.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    relatedHazardsListView.setVisibility(View.GONE);
                    checkedTextView6.setChecked(false);
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    /**** Method for Setting the Height of the ListView dynamically.
     **** Hack to fix the issue of not showing all the items of the ListView
     **** when placed inside a ScrollView  ****/
    public void getListViewSize(ListView myListView) {
        ListAdapter myListAdapter = myListView.getAdapter();
        if (myListAdapter == null) {
            //do nothing return null
            return;
        }
        //set listAdapter in loop for getting final size
        int totalHeight = 0;
        for (int size = 0; size < myListAdapter.getCount(); size++) {
            View listItem = myListAdapter.getView(size, null, myListView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        //setting listview item in adapter
        ViewGroup.LayoutParams params = myListView.getLayoutParams();
        params.height = totalHeight + (myListView.getDividerHeight() * (myListAdapter.getCount() - 1));
        myListView.setLayoutParams(params);
        // print height of adapter on log
        BuildLog.i("height of listItem:", String.valueOf(totalHeight));
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);

        if (responseObj instanceof DiseaseResponseModel){
            DiseaseResponseModel agroDiseaseProductMappingDTO=(DiseaseResponseModel)responseObj;
            if (AppConstants.STATUS_CODE.equals(String.valueOf(agroDiseaseProductMappingDTO.getStatusCode()))){
                String diseaseResInfo=agroDiseaseProductMappingDTO.getResponse();
                dto=new Gson().fromJson(diseaseResInfo,AgroDiseaseProductMappingDTO.class);
                setData(dto);
            }
        }
        else{
            noDataAvailableTaxt.setVisibility(View.VISIBLE);
            scrollView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRequestFailure(RetrofitError errorCode, String errorFrom) {
        super.onRequestFailure(errorCode, errorFrom);
    }

}
