package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pioneer.emp.R;
import com.pioneer.emp.customviews.RoundedCornersTransfGlide;
import com.pioneer.emp.dto.AgroDiseaseProductMappingDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;

/**
 * Created by rambabu.a on 17-01-2018.
 */

public class CDAllProductsAdapter extends RecyclerView.Adapter<CDAllProductsAdapter.MyCDAllProdHolder> {
    Context context;
    ArrayList<AgroDiseaseProductMappingDTO> diseasesList;
    private OnBookletClickListener listener;


    public CDAllProductsAdapter(Context context, ArrayList<AgroDiseaseProductMappingDTO> couponslistDTOArrayList, OnBookletClickListener listener) {
        this.context = context;
        this.diseasesList = couponslistDTOArrayList;
        this.listener = listener;
    }

    @Override
    public MyCDAllProdHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.disease_recycle_item,parent,false);
        return new MyCDAllProdHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MyCDAllProdHolder holder, int position) {
        holder.bind(diseasesList.get(position));
    }

    @Override
    public int getItemCount() {
        return diseasesList.size();
    }


    public class MyCDAllProdHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView diseaseName, diseaseDesc, diseasePercentage;
        LinearLayout diseasePercentLayout;
        ImageView diseaseImage;
        RelativeLayout diseaseItem;
        public MyCDAllProdHolder(View view) {
            super(view);

            diseaseName = view.findViewById(R.id.diseaseName);
            diseaseDesc = view.findViewById(R.id.diseaseDescription); // not required
            diseasePercentage = view.findViewById(R.id.diseasePercentage); // not required
            diseaseImage = view.findViewById(R.id.diseaseImg);
            diseaseItem = view.findViewById(R.id.diseaseItem); // parent layout
            diseasePercentLayout = view.findViewById(R.id.diseasePercentageLayout); // not required
            diseaseItem.setOnClickListener(this);
        }

        public void bind(final AgroDiseaseProductMappingDTO diseaseModel ) {
            diseaseName.setText(diseaseModel.getProductName());
            diseaseDesc.setVisibility(View.GONE);
            diseasePercentLayout.setVisibility(View.GONE);

            diseaseItem.setTag((int) diseaseModel.getId());

            if (Utils.isValidStr(diseaseModel.getAgro_images_local())){
                Glide.with(context)
                        .load(diseaseModel.getAgro_images_local())
                        .error(R.drawable.image_placeholder).transform(new RoundedCornersTransfGlide(context, AppConstants.IMAGE_CORNER_RADIOS, AppConstants.IMAGE_MARGIN))
                        .placeholder(R.drawable.image_placeholder)
                        .dontAnimate().into(diseaseImage);
            } else if (Utils.isNetworkConnection(context) && Utils.isValidStr(diseaseModel.getProductImage())){
                Glide.with(context)
                        .load(diseaseModel.getProductImage())
                        .error(R.drawable.image_placeholder).transform(new RoundedCornersTransfGlide(context, AppConstants.IMAGE_CORNER_RADIOS, AppConstants.IMAGE_MARGIN))
                        .placeholder(R.drawable.image_placeholder)
                        .dontAnimate().into(diseaseImage);
            }

        }

        @Override
        public void onClick(View v) {
            // DO your stuff
            int position = (int) v.getTag();
            listener.onItemClick(v, position);

        }
    }
}
