package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.PinCodeMobileData;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by swamy on 10-03-2018.
 */

public class PinCodeDAO implements DAO {

    private final String TAG = "PinCodeDAO";
    private static PinCodeDAO pinCodeDAO;

    public static PinCodeDAO getInstance() {
        if (pinCodeDAO == null) {
            pinCodeDAO = new PinCodeDAO();
        }

        return pinCodeDAO;
    }

    @Override
    public String insert(DTO dtoMain, SQLiteDatabase dbObject) {
        PinCodeMobileData dto = (PinCodeMobileData) dtoMain;
        try {
            ContentValues cValues = new ContentValues();
            cValues.put("pinCode", dto.getPinCode());
            cValues.put("blockName", dto.getBlockName());
            cValues.put("territoryId", dto.getTerritoryId());
            dbObject.insert("MASTER_PINCODE", null, cValues);
            return "";
        } catch (SQLException e) {
            BuildLog.e(TAG + "insert()", e.getMessage());
            return null;

        } finally {
            dbObject.close();
        }
    }

    public String insertList(List<PinCodeMobileData> pincodesMasterList , SQLiteDatabase dbObject) {
        try {
            for(PinCodeMobileData dto : pincodesMasterList) {
                ContentValues cValues = new ContentValues();
                cValues.put("pinCode", dto.getPinCode());
                cValues.put("blockName", dto.getBlockName());
                cValues.put("territoryId", dto.getTerritoryId());
                dbObject.insert("MASTER_PINCODE", null, cValues);
            }
            return "";
        } catch (SQLException e) {
            BuildLog.e(TAG + "insert()", e.getMessage());
            return null;

        } finally {
            dbObject.close();
        }
    }

    public void insertOrUpdate(Context context, DTO dtoMain, SQLiteDatabase dbObject) {
        PinCodeMobileData dto = (PinCodeMobileData) dtoMain;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT pinCode FROM MASTER_PINCODE where pinCode='" + dto.getPinCode() + "'", null);
            if (cursor.getCount() > 0) {
                update(dto, DBHandler.getWritableDb(context));
            } else {
                insert(dto, DBHandler.getWritableDb(context));
            }
        } catch (SQLiteException e) {
//            dbObject.close();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
    }

    @Override
    public boolean update(DTO dtoMain, SQLiteDatabase dbObject) {
        try {
            PinCodeMobileData dto = (PinCodeMobileData) dtoMain;
            ContentValues cValues = new ContentValues();

            if (dto.getPinCode() != 0)
                cValues.put("pinCode", dto.getPinCode());

            if (dto.getBlockName() != null)
                cValues.put("blockName", dto.getBlockName());
            else
                cValues.putNull("blockName");

            if (dto.getTerritoryId() != 0)
                cValues.put("territoryId", dto.getTerritoryId());

            dbObject.update("MASTER_PINCODE", cValues, "pinCode = '" + dto.getPinCode() + "'", null);

        } catch (SQLException e) {
            BuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoMain, SQLiteDatabase dbObject) {
        PinCodeMobileData dto = (PinCodeMobileData) dtoMain;
        try {
            dbObject.compileStatement("DELETE FROM MASTER_PINCODE WHERE pinCode = '" + dto.getPinCode() + "'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        }finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public ArrayList getRecordsByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {

        if (columnValue == null || columnValue.isEmpty())
            return null;
        ArrayList<PinCodeMobileData> info = new ArrayList<>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "pinCode";

            String sql = "SELECT * FROM MASTER_PINCODE where " + columnName + "='" + columnValue + "'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                PinCodeMobileData dto;
                do {
                    dto = new PinCodeMobileData();
                    dto.setPinCode(cursor.getLong(cursor.getColumnIndex("pinCode")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setTerritoryId(cursor.getLong(cursor.getColumnIndex("territoryId")));

                    info.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return info;
    }

    public PinCodeMobileData getRecordsByPINCode(long pinCode, SQLiteDatabase dbObject) {
        PinCodeMobileData dto = null;

        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_PINCODE where pinCode='" + pinCode + "'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                dto = new PinCodeMobileData();
                dto.setPinCode(cursor.getLong(cursor.getColumnIndex("pinCode")));
                dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                dto.setTerritoryId(cursor.getLong(cursor.getColumnIndex("territoryId")));
                return dto;
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return dto;
    }

    public PinCodeMobileData getRecordsByBlockName(String blockName, SQLiteDatabase dbObject) {
        PinCodeMobileData dto = null;

        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_PINCODE where blockName='" + blockName + "'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new PinCodeMobileData();
                    dto.setPinCode(cursor.getLong(cursor.getColumnIndex("pinCode")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setTerritoryId(cursor.getLong(cursor.getColumnIndex("territoryId")));
                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return dto;
    }
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM MASTER_PINCODE").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
}
