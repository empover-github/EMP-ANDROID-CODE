package com.pioneer.emp.dto;

import com.pioneer.parivaar.dto.DTO;

import java.io.Serializable;

/**
 * Created by hareesh.a on 12/18/2017.
 */

public class DiseasePrescriptionDTO implements Serializable,DTO {

    private String diseaseId;

    private String diseaseName;

    private String diseaseBiologicalName;

    private String crop;

    private String diseaseType;

    private String hosts;

    private String inANutshell;

    private String symptoms;

    private String trigger;

    private String preventiveMeasures;

    private String biologicalControl;

    private String chemicalControl;

    private String hazadDescription;

    private String diseaseImageFile;

    private String active;

    private String deleted;

    private String productMapping;

    private String createdOn;

    private String updatedOn;

    private long id;

    private String status;

    private String cdi_images_local;
    
    private String productMappingImage;

    private String response;
    private String message;
    private String statusCode;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getDiseaseId() {
        return diseaseId;
    }

    public void setDiseaseId(String diseaseId) {
        this.diseaseId = diseaseId;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public String getDiseaseBiologicalName() {
        return diseaseBiologicalName;
    }

    public void setDiseaseBiologicalName(String diseaseBiologicalName) {
        this.diseaseBiologicalName = diseaseBiologicalName;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getDiseaseType() {
        return diseaseType;
    }

    public void setDiseaseType(String diseaseType) {
        this.diseaseType = diseaseType;
    }

    public String getHosts() {
        return hosts;
    }

    public void setHosts(String hosts) {
        this.hosts = hosts;
    }

    public String getInANutshell() {
        return inANutshell;
    }

    public void setInANutshell(String inANutshell) {
        this.inANutshell = inANutshell;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getTrigger() {
        return trigger;
    }

    public void setTrigger(String trigger) {
        this.trigger = trigger;
    }

    public String getPreventiveMeasures() {
        return preventiveMeasures;
    }

    public void setPreventiveMeasures(String preventiveMeasures) {
        this.preventiveMeasures = preventiveMeasures;
    }

    public String getBiologicalControl() {
        return biologicalControl;
    }

    public void setBiologicalControl(String biologicalControl) {
        this.biologicalControl = biologicalControl;
    }

    public String getChemicalControl() {
        return chemicalControl;
    }

    public void setChemicalControl(String chemicalControl) {
        this.chemicalControl = chemicalControl;
    }

    public String getHazadDescription() {
        return hazadDescription;
    }

    public void setHazadDescription(String hazadDescription) {
        this.hazadDescription = hazadDescription;
    }

    public String getDiseaseImageFile() {
        return diseaseImageFile;
    }

    public void setDiseaseImageFile(String diseaseImageFile) {
        this.diseaseImageFile = diseaseImageFile;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getProductMapping() {
        return productMapping;
    }

    public void setProductMapping(String productMapping) {
        this.productMapping = productMapping;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(String updatedOn) {
        this.updatedOn = updatedOn;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCdi_images_local() {
        return cdi_images_local;
    }

    public void setCdi_images_local(String cdi_images_local) {
        this.cdi_images_local = cdi_images_local;
    }
    
     public String getProductMappingImage() {
        return productMappingImage;
    }

    public void setProductMappingImage(String productMappingImage) {
        this.productMappingImage = productMappingImage;
    }
}
