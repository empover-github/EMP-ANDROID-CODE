package com.pioneer.emp.cropAdvisory;

import com.pioneer.emp.models.CommonResponseEntity;

/**
 * Created by fatima.t on 09-05-2017.
 */

public class CropAdvisorySubscriptionReq extends CommonResponseEntity {
    private String customerId;
    private String category;
    private String state;
    private String crop;
    private String hybrid;
    private String season;
    private String sowingDate;
    private String acressowed;
    private String mobileNumber;
    private String pincode;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public String getSowingDate() {
        return sowingDate;
    }

    public void setSowingDate(String sowingDate) {
        this.sowingDate = sowingDate;
    }

    public String getAcressowed() {
        return acressowed;
    }

    public void setAcressowed(String acressowed) {
        this.acressowed = acressowed;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}
