package com.pioneer.emp.cropDiagnostic;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.pioneer.emp.R;
import com.pioneer.emp.models.CommonResEntity;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.listeners.DialogMangerCallback;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.ProfileImageSelectionUtil;
import com.pioneer.parivaar.utils.Utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import retrofit.RetrofitError;
import retrofit.mime.TypedFile;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class CropDiagnosisHintActivity extends BaseActivity implements View.OnClickListener {

    public static final String EXTRA_CROP = "crop";
    private Bitmap imageBitmap;
    private String crop;
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    File myDir;
    TypedFile imageTypedFile;
    private String latLongValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_diagnosis_hint);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setTitle(getString(R.string.how_to_capture_photo));
        TextView txtHeader = findViewById(R.id.header_text);
        txtHeader.setText(getString(R.string.how_to_capture_photo));

        Bundle bundle = getIntent().getExtras();
        if (bundle != null && bundle.containsKey(EXTRA_CROP))
            crop = bundle.getString(EXTRA_CROP);

        Button cdBtnOk = findViewById(R.id.cdBtnOk);
        cdBtnOk.setOnClickListener(this);

        if (checkLocPermission())
            if (Utils.checkPlayServices(CropDiagnosisHintActivity.this)) {
                buildGoogleApiClient();
            }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (checkLocPermission()) {
            getCurrentLocation(false, CropDiagnosisHintActivity.this);
        }

    }

    @Override
    public void refresh() {
        onLocationReceived(geoLocation);
    }

    public void onLocationReceived(String location) {
        latLongValues = location;

    }

    private boolean checkLocPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return ActivityCompat.checkSelfPermission(CropDiagnosisHintActivity.this, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return true;
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.cdBtnOk) {
            File newfile = createFile();  // CDTARA
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkPermission()) {
//                    ProfileImageSelectionUtil.showOption(null, CropDiagnosisHintActivity.this);
                    ProfileImageSelectionUtil.showOptionOpenCamera(null, CropDiagnosisHintActivity.this, newfile);  // CDTARA
                }
            } else {
//                ProfileImageSelectionUtil.showOption(null, CropDiagnosisHintActivity.this);
                ProfileImageSelectionUtil.showOptionOpenCamera(null, CropDiagnosisHintActivity.this, newfile);  // CDTARA
            }
        }
    }

    private File createFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        myDir = new File(root + File.separator + "CropDiagnosis");
        if (!myDir.exists())
            myDir.mkdirs();

        File newfile = new File(myDir, "IMG_" + System.currentTimeMillis() + ".JPG");
        try {
            newfile.createNewFile();
        } catch (IOException e) {
        }
        return newfile;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void uploadImg() {

        byte[] bytes;
        ByteArrayOutputStream bitBytes = new ByteArrayOutputStream();
        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bitBytes);
        bytes = bitBytes.toByteArray();
        String encodedString = Base64.encodeToString(bytes, Base64.DEFAULT);
        CropDiagnosticReq cropDiagnosticReq = new CropDiagnosticReq();
        cropDiagnosticReq.setCustomerId(Utils.getUserId(CropDiagnosisHintActivity.this));
//        cropDiagnosticReq.setUploadImageByteString(encodedString); // removed to upload multipart image
        cropDiagnosticReq.setCrop(crop);
        if (Utils.isValidStr(latLongValues))
            cropDiagnosticReq.setCoordinatePoints(latLongValues);
        APIRequestHandler.getInstance().cropDiagnosisRequest(cropDiagnosticReq, this, imageTypedFile, this, true);


    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null) {
            if (responseObj instanceof CommonResEntity) {
                CommonResEntity commonResEntity = (CommonResEntity) responseObj;
                if (AppConstants.STATUS_CODE.equals(commonResEntity.getStatusCode())) {
                    String resJson = Utils.getJWTResponseFC(commonResEntity.getResponse(), CropDiagnosisHintActivity.this);
                    CropDiseaseResponse response = new Gson().fromJson(resJson, CropDiseaseResponse.class);
                    if (response != null && response.getCropDiagnosisResponseDTO() != null && !response.getCropDiagnosisResponseDTO().isEmpty()) {
                        long feedBackId = response.getId();
                        long diseaseId = response.getCropDiagnosisResponseDTO().get(0).getDiseaseId();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(CropDiagnosticActivity.EXTRA_RESPONSE, response.getCropDiagnosisResponseDTO());
                        bundle.putLong(CropDiagnosticActivity.EXTRA_FEEDBACK_ID, feedBackId);
                        bundle.putLong(CropDiagnosticActivity.EXTRA_DISEASE_ID, diseaseId);
                        Intent intent = new Intent(CropDiagnosisHintActivity.this, CropDiagnosticActivity.class);
                        intent.putExtras(bundle);
                        finish();
                        startActivity(intent);
                    } else {
                        DialogManager.showToast(CropDiagnosisHintActivity.this, getString(R.string.disease_iden_toast));
                        DialogManager.showToast(CropDiagnosisHintActivity.this, commonResEntity.getMessage());
                    }
                } else {
                    DialogManager.showToast(CropDiagnosisHintActivity.this, commonResEntity.getMessage());
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        if (resultCode == RESULT_OK) {
            try {
                if (requestCode == ProfileImageSelectionUtil.OPENCAMERA) {
                    if (resultCode == RESULT_OK) {
                        // successfully captured the image
                    /* // when passing only captureIntent true without URI then working fine
                    Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
                    SaveImage(thumbnail);
                    if (thumbnail != null) {
                        imageBitmap = thumbnail;
                        uploadOpenCameraImage();
                    } else {

                    }*/

                        // Below code works perfectly without changing width&height of the image
                        // Below code works when passing uri from ImageSaver.java line number 1138s
                        Uri uriStr = (Uri) data.getExtras().get("data");
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uriStr);
                        if (bitmap != null) {
                            imageBitmap = bitmap;
                            imageTypedFile = new TypedFile("multipart/form-data", new File(uriStr.toString().substring(7)));
                            BuildLog.e("CropDiagnosticHintActivity: ", "OpenCamera: " + uriStr.toString().substring(7));
                            uploadImg();
                        } else {

                        }

                    } else if (resultCode == RESULT_CANCELED) {
                        // user cancelled Image capture
                        Toast.makeText(getApplicationContext(), getString(R.string.user_cancelled_image_capture), Toast.LENGTH_SHORT).show();
                    } else {
                        // failed to capture image
                        Toast.makeText(getApplicationContext(), getString(R.string.failed_to_capture_image), Toast.LENGTH_SHORT).show();
                    }
                } else if (requestCode == ProfileImageSelectionUtil.GALLERY) {
                    // did not made any changes even though camera(above if condition) using URI.
                    Bitmap image = ProfileImageSelectionUtil.getImage(data, this);
                    Uri selectedImage = data.getData();
                    image = ProfileImageSelectionUtil.getCorrectOrientationImage(this,
                            selectedImage, image);
                    if (image != null) {
                        imageBitmap = image;
                        imageTypedFile = new TypedFile("multipart/form-data", new File(ProfileImageSelectionUtil.getRealPathFromURI(selectedImage, CropDiagnosisHintActivity.this)));
                        BuildLog.e("CropDiagnosticHintActivity: ", "Gallery: " + ProfileImageSelectionUtil.getRealPathFromURI(selectedImage, CropDiagnosisHintActivity.this));
                        uploadImg();
                    } else {

                    }
                } else if (requestCode == ProfileImageSelectionUtil.CAMERA) {
                    Bitmap image = ProfileImageSelectionUtil.getImage(data, this);
                    Uri selectedImage = data.getData();
                    if (image != null) {
                        if (ProfileImageSelectionUtil.isUriTrue) {
                            image = ProfileImageSelectionUtil.getCorrectOrientationImage(this, data.getData(), image);
                        } else {
                            image = ProfileImageSelectionUtil.getCorrectOrientationImage(this, image);
                        }

                        imageBitmap = image;
                        imageTypedFile = new TypedFile("multipart/form-data", new File(ProfileImageSelectionUtil.getRealPathFromURI(selectedImage, CropDiagnosisHintActivity.this)));
                        BuildLog.e("CropDiagnosticHintActivity: ", "Camera: " + ProfileImageSelectionUtil.getRealPathFromURI(selectedImage, CropDiagnosisHintActivity.this));
                        uploadImg();

                    } else {
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        /*try {
            if (requestCode == ProfileImageSelectionUtil.CAMERA
                    || requestCode == ProfileImageSelectionUtil.GALLERY) {
                if (resultCode == RESULT_OK) {
                    Bitmap image = ProfileImageSelectionUtil.getImage(data,
                            this);

                    if (image != null) {
                        if (requestCode == ProfileImageSelectionUtil.CAMERA) {
                            if (ProfileImageSelectionUtil.isUriTrue) {
                                image = ProfileImageSelectionUtil
                                        .getCorrectOrientationImage(this,
                                                data.getData(), image);
                            } else {
                                image = ProfileImageSelectionUtil
                                        .getCorrectOrientationImage(this, image);
                            }
                        } else {
                            Uri selectedImage = data.getData();

                            image = ProfileImageSelectionUtil
                                    .getCorrectOrientationImage(this,
                                            selectedImage, image);
                        }

                        if (image != null) {
                            imageBitmap = image;
                            uploadImg();
                            //this statement to store image
//                            mProfile_image_path = storeImage(image, "profile" + "-");

//                            mCropUri = Uri.fromFile(new File(mProfile_image_path));
//                            mCapturedUri = Uri.fromFile(new File(mProfile_image_path));
//                            new Crop(mCropUri).output(mCapturedUri).asSquare().start(this);

                            //Dummy do needful
                        }

                    } else {
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(CropDiagnosisHintActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(CropDiagnosisHintActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(CropDiagnosisHintActivity.this, Manifest.permission.CAMERA) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(CropDiagnosisHintActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(CropDiagnosisHintActivity.this, new DialogMangerCallback() {
                    @Override
                    public void onOkClick(View v) {
                        ActivityCompat.requestPermissions(CropDiagnosisHintActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Need Camera and storage permissions", "This app needs camera permission to demonize the crop.", getString(R.string.grant), getString(R.string.cancel));

               /* AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                builder.setTitle("Need Camera Permission");
                builder.setMessage("This app needs camera permission to scan barcode.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(mActivity, new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        //finish();
                    }
                });
                builder.show();*/
            } else {
                // No explanation needed, we can request the permission.
                if (Utils.isFirstTime(CropDiagnosisHintActivity.this)) {
                    Utils.setFirstTime(false, CropDiagnosisHintActivity.this);
                    ActivityCompat.requestPermissions(CropDiagnosisHintActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    //requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);

                    // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                    // app-defined int constant. The callback method gets the
                    // result of the request.
                } else {
                    ActivityCompat.requestPermissions(CropDiagnosisHintActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION_DENAIL);
                    //requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }

        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            ProfileImageSelectionUtil.showOptionOpenCamera(null, CropDiagnosisHintActivity.this, newfile);/*ProfileImageSelectionUtil.showOption(null, CropDiagnosisHintActivity.this);*/  // CDTARA
                        else
                            checkPermission();
                    } else {
//                        ProfileImageSelectionUtil.showOption(null, CropDiagnosisHintActivity.this);
                        ProfileImageSelectionUtil.showOptionOpenCamera(null, CropDiagnosisHintActivity.this, newfile); // CDTARA
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
            case REQUEST_CAMERA_PERMISSION_DENAIL: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            ProfileImageSelectionUtil.showOptionOpenCamera(null, CropDiagnosisHintActivity.this, newfile);/*ProfileImageSelectionUtil.showOption(null, CropDiagnosisHintActivity.this);*/ // CDTARA
                        else
                            showDialogToOpenSetting();
                    } else {
                        ProfileImageSelectionUtil.showOptionOpenCamera(null, CropDiagnosisHintActivity.this, newfile);/*ProfileImageSelectionUtil.showOption(null, CropDiagnosisHintActivity.this);*/  // CDTARA
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    showDialogToOpenSetting();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
//                showDialogToOpenSetting();
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private void showDialogToOpenSetting() {
        AlertDialog.Builder builder = new AlertDialog.Builder(CropDiagnosisHintActivity.this);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(CropDiagnosisHintActivity.this, CropDiagnosisHintActivity.this.getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {

        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", CropDiagnosisHintActivity.this.getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        finish();
    }

}
