package com.pioneer.emp.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.DailyLiquidationRetailersSalesDTO;
import com.pioneer.emp.models.DailyLiquidationTillDateSalesDTO;
import com.pioneer.emp.models.DailyLiquidationTransDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class DailyLiquidationRetailersSalesDAO implements DAO {
    private final String TAG = "DailyLiquidationRetailersSalesDAO";
    private static DailyLiquidationRetailersSalesDAO dailyLiquidationRetailersSalesDAO;

    public static DailyLiquidationRetailersSalesDAO getInstance() {
        if (dailyLiquidationRetailersSalesDAO == null) {
            dailyLiquidationRetailersSalesDAO = new DailyLiquidationRetailersSalesDAO();
        }

        return dailyLiquidationRetailersSalesDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        DailyLiquidationRetailersSalesDTO dto = (DailyLiquidationRetailersSalesDTO) dtoObject;
        try {
            ContentValues contentValues = new ContentValues();

            contentValues.put("pioneerSales", dto.getPioneerSales());
            contentValues.put("competitor1Sales", dto.getCompetitor1Sales());
            contentValues.put("competitor2Sales", dto.getCompetitor2Sales());
            contentValues.put("othersSales", dto.getOthersSales());
            contentValues.put("totalSales", dto.getTotalSales());
            contentValues.put("geoLocation", dto.getGeoLocation());
            contentValues.put("submittedDate", dto.getSubmittedDate());
            contentValues.put("isSync", dto.getIsSync());
            contentValues.put("calendarId", dto.getCalendarId());

            long rowAffected = dbObject.insert(DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES, null, contentValues);
            if (rowAffected > 0)
                return "inserted";
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "inserted";
    }

    @SuppressLint("LongLogTag")
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DailyLiquidationRetailersSalesDTO dto = (DailyLiquidationRetailersSalesDTO) dtoObject;
            ContentValues contentValues = new ContentValues();
            if (dto.getPioneerSales() != 0)
                contentValues.put("pioneerSales", dto.getPioneerSales());

            if (dto.getCompetitor1Sales() != 0)
                contentValues.put("competitor1Sales", dto.getCompetitor1Sales());

            if (dto.getCompetitor2Sales() != 0)
                contentValues.put("competitor2Sales", dto.getCompetitor2Sales());

            if (dto.getOthersSales() != 0)
                contentValues.put("othersSales", dto.getOthersSales());

            if (dto.getTotalSales() != 0)
                contentValues.put("totalSales", dto.getTotalSales());

            if (dto.getGeoLocation() != null)
                contentValues.put("geoLocation", dto.getGeoLocation());

            if (dto.getSubmittedDate() != null)
                contentValues.put("submittedDate", dto.getSubmittedDate());

            if (dto.getIsSync() != 0)
                contentValues.put("isSync", dto.getIsSync());

            if (dto.getCalendarId() != 0)
                contentValues.put("calendarId", dto.getCalendarId());

            int rowsEffected = dbObject.update(DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES, contentValues, "id='" + dto.getId() + "' ", null);
            if (rowsEffected > 0)
                return true;
        } catch (SQLException e) {
            Log.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @SuppressLint("LongLogTag")
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> dailyLiquidationInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DailyLiquidationRetailersSalesDTO dto = new DailyLiquidationRetailersSalesDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dailyLiquidationInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return dailyLiquidationInfo;
    }


    public DailyLiquidationRetailersSalesDTO getRecordsForUploadByCalendarId(long calendarId, SQLiteDatabase dbObject,Context context) {
        Cursor cursor = null;
        DailyLiquidationRetailersSalesDTO dto = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "' and isSync = '1'", null);
            // cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    dto = new DailyLiquidationRetailersSalesDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dto.setTop10RetailersWiseSales(DailyLiquidationTopTenRetailersVolumeDAO.getInstance().getRecordsForUploadByCalendarId(calendarId,DBHandler.getReadableDb(context)));


                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }
    public DailyLiquidationRetailersSalesDTO getRecordsForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        DailyLiquidationRetailersSalesDTO dto = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE  isSync = '1'", null);
            // cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    dto = new DailyLiquidationRetailersSalesDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }
    public boolean isRetailerExist(long calendarId, SQLiteDatabase readableDb) {
        Cursor cursor = null;
        List<DailyLiquidationRetailersSalesDTO> list = new ArrayList<DailyLiquidationRetailersSalesDTO>();
        try {
            cursor = readableDb.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'", null);
            return cursor.getCount() > 0;
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
            readableDb.close();
        }
        return false;
    }
    public DailyLiquidationRetailersSalesDTO getRecordsForUpload(long calendarId, SQLiteDatabase dbObject,Context context) {
        Cursor cursor = null;
        DailyLiquidationRetailersSalesDTO dto = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'", null);
            // cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    dto = new DailyLiquidationRetailersSalesDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dto.setTop10RetailersWiseSales(DailyLiquidationTopTenRetailersVolumeDAO.getInstance().getRecordsForUploadByCalendarId(calendarId,DBHandler.getReadableDb(context)));


                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dto;
    }

    public boolean isDataAvailableForUpLoad(SQLiteDatabase readableDb) {
        Cursor cursor = null;
        List<DailyLiquidationRetailersSalesDTO> list = new ArrayList<DailyLiquidationRetailersSalesDTO>();
        try {
            cursor = readableDb.rawQuery("SELECT count(id) FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES + " WHERE isSync = '1'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
            readableDb.close();
        }
        return false;
    }
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_RETAILERS_SALES).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
}
