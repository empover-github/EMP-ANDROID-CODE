package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.RegionMobileData;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by swamy on 10-03-2018.
 */

public class RegionDAO implements DAO {

    private final String TAG = "RegionDAO";
    private static RegionDAO regionDAO;

    public static RegionDAO getInstance() {
        if (regionDAO == null) {
            regionDAO = new RegionDAO();
        }

        return regionDAO;
    }

    @Override
    public String insert(DTO dtoMain, SQLiteDatabase dbObject) {
        RegionMobileData dto = (RegionMobileData) dtoMain;
        try {
            ContentValues cValues = new ContentValues();
            cValues.put("id", dto.getId());
            cValues.put("name", dto.getName());
            cValues.put(" cuId", dto.getCuId ());
            dbObject.insert("MASTER_REGION", null, cValues);
            return "";
        }catch(SQLException e) {
            BuildLog.e(TAG + "insert()", e.getMessage());
            return null;
        } finally {
            dbObject.close();
        }
    }

    public void insertOrUpdate(DTO dtoMain, SQLiteDatabase dbObject) {
        RegionMobileData dto = (RegionMobileData) dtoMain;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT id FROM MASTER_REGION where id='"+dto.getId()+"'", null);
            if (cursor.getCount() > 0) {
                update(dto, dbObject);
            }else{
                insert(dto, dbObject);
            }
        }catch (SQLiteException e){
            dbObject.close();
        }finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
    }

    @Override
    public boolean update(DTO dtoMain, SQLiteDatabase dbObject) {
        try {
            RegionMobileData dto = (RegionMobileData) dtoMain;
            ContentValues cValues = new ContentValues();

            if (dto.getId() != 0)
                cValues.put("id", dto.getId());

            if (dto.getName() != null)
                cValues.put("name", dto.getName ());
            else
                cValues.putNull("name");

            if (dto.getCuId () != 0)
                cValues.put("cuId", dto.getCuId ());
            else
                cValues.putNull(" cuId");

            dbObject.update("MASTER_REGION", cValues, "id = '"+dto.getId()+"'", null);

        } catch (SQLException e) {
            BuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoMain, SQLiteDatabase dbObject) {
        RegionMobileData dto = (RegionMobileData) dtoMain;
        try {
            dbObject.compileStatement("DELETE FROM MASTER_REGION WHERE id = '"+dto.getId()+"'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        }finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public ArrayList getRecordsByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {

        if(columnValue == null || columnValue.isEmpty())
            return null;
        ArrayList<RegionMobileData> info = new ArrayList<>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            String sql = "SELECT * FROM MASTER_REGION where "+columnName+"='"+columnValue+"'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                RegionMobileData dto;
                do {
                    dto = new RegionMobileData();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setCuId(cursor.getLong(cursor.getColumnIndex("cuId")));

                    info.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return info;
    }

    public  RegionMobileData getRecordsById(long id, SQLiteDatabase dbObject) {
        RegionMobileData dto = null;

        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_REGION where id='"+id+"'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new RegionMobileData();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setCuId(cursor.getLong(cursor.getColumnIndex("cuId")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return dto;
    }

    public  List<RegionMobileData> getRecordsByCUId(long id, SQLiteDatabase dbObject) {
        List<RegionMobileData> list = new ArrayList<>();
        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_REGION where cuId='"+id+"'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    RegionMobileData dto = new RegionMobileData();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setCuId(cursor.getLong(cursor.getColumnIndex("cuId")));

                    list.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return list;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM MASTER_REGION").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
}
