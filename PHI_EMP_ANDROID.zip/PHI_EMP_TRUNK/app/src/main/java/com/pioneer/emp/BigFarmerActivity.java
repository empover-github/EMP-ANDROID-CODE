package com.pioneer.emp;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.Toolbar;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.pioneer.emp.dto.BigFarmerDTO;
import com.pioneer.emp.models.CommonResEntity;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.listeners.DialogMangerCallback;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.ProfileImageSelectionUtil;
import com.pioneer.parivaar.utils.Utils;
import com.soundcloud.android.crop.Crop;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit.RetrofitError;
import retrofit.mime.TypedFile;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static com.pioneer.parivaar.utils.ProfileImageSelectionUtil.openCameraApp;

/**
 * Created by hareesh.a on 2/22/2018.
 */

public class BigFarmerActivity extends BaseActivity implements View.OnClickListener {
    private static final int CROP_PIC = 1020;
    private Toolbar toolbar;
    private TextView txtHeader;
    private ImageView navBackBtn;
    private EditText edtFarmerName, edtMobileNo, edtVillageName, edtPincode, edtBlockName, edtDistrictName, edtTotalPreviousYear, edtTotalPresentYear,
            edtPHIPreviousYear, edtPHIPresentYear, edtTargetPreviousYear, edtTargetPresentYear, edtTargetHybrid;
    private TextView tvPreviousYear, tvPresentYear, tvTargetHydrid;
    private Spinner spnCrop, spnBlockType, spnVillageType;
    private Button btnSubmit;
    private Calendar calendar;
    private int presentYear, previousYear;
    private BigFarmerActivity bigFarmerActivity;
    private CheckBox chcCorn, chcRice, chcMillet, chcMustard;
    private LinearLayout lnrClear, lnrPlus;
    private StringBuilder builder = null;
    private List<String> listTraget;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private File myDir;
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    private static final int REQUEST_CODE_FOR_IMAGE_CROPPING = 65;
    private Bitmap imageBitmap;
    private TypedFile imageTypedFile;
    private Uri uriStr;
    private String imagePath;
    private ImageView imgCapture, profileImage;

    private ExecutorService mExecutor;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bigfarmeractivity);
        bigFarmerActivity = this;
        if (checkLocPermission())
            if (Utils.checkPlayServices(bigFarmerActivity)) {
                buildGoogleApiClient();
            }
        initializationView();
    }

    private void initializationView() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtHeader = findViewById(R.id.hedder_text);
        txtHeader.setText(getString(R.string.bigFarmer));
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);

        calendar = Calendar.getInstance();
        presentYear = calendar.get(Calendar.YEAR);
        previousYear = calendar.get(Calendar.YEAR) - 1;


        edtFarmerName = findViewById(R.id.edt_farmer_name);
        edtMobileNo = findViewById(R.id.edt_mobile_no);
        edtVillageName = findViewById(R.id.edt_village_name);
        edtPincode = findViewById(R.id.edt_pincode);
        edtBlockName = findViewById(R.id.edt_block_name);
        edtDistrictName = findViewById(R.id.edt_district_name);
        edtTotalPreviousYear = findViewById(R.id.edt_total_previous_year);
        edtTotalPresentYear = findViewById(R.id.edt_total_present_year);
        edtPHIPreviousYear = findViewById(R.id.edt_phi_previous_year);
        edtPHIPresentYear = findViewById(R.id.edt_phi_present_year);
        edtTargetPreviousYear = findViewById(R.id.edt_target_previous_year);
        edtTargetPresentYear = findViewById(R.id.edt_target_present_year);
        edtTargetHybrid = findViewById(R.id.edt_target_hybrid);
        profileImage = findViewById(R.id.bf_profile_image);

        tvPreviousYear = findViewById(R.id.txt_previous_year);
        tvPresentYear = findViewById(R.id.txt_present_year);
        tvTargetHydrid = findViewById(R.id.txt_target_hybrid);

        tvPreviousYear.setText(tvPreviousYear.getText().toString().replace("$1", String.valueOf(previousYear)));
        tvPresentYear.setText(tvPresentYear.getText().toString().replace("$1", String.valueOf(presentYear)));

        spnBlockType = findViewById(R.id.block_type_spinner);
        spnVillageType = findViewById(R.id.village_type_spinner);

        chcCorn = findViewById(R.id.chc_corn);
        chcRice = findViewById(R.id.chc_rice);
        chcMillet = findViewById(R.id.chc_millet);
        chcMustard = findViewById(R.id.chc_mustard);

        lnrClear = findViewById(R.id.layout_clear);
        lnrPlus = findViewById(R.id.layout_plus);
        imgCapture = findViewById(R.id.bf_profile_capture);

        btnSubmit = findViewById(R.id.big_farmer_submit);
        profileImage.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);
        lnrClear.setOnClickListener(this);
        lnrPlus.setOnClickListener(this);
        imgCapture.setOnClickListener(this);

        if (Utils.getText(edtTargetHybrid) != null && Utils.getText(edtTargetHybrid).isEmpty()) {
            lnrClear.setVisibility(View.GONE);
        }

        edtMobileNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edtMobileNo.length() == 1 && edtMobileNo.getText().toString().trim().equalsIgnoreCase("0")) {
                    edtMobileNo.setText("");
                }
            }
        });
        edtPincode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edtPincode.length() == 1 && edtPincode.getText().toString().trim().equalsIgnoreCase("0")) {
                    edtPincode.setText("");
                }
            }
        });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgBacknav:
                onBackPressed();
                break;
            case R.id.big_farmer_submit:
                String validation = validationField();
                if (validation == null) {
                    if (Utils.isNetworkConnection(bigFarmerActivity)) {
                        if (geoLocation == null) {
                            if (checkLocPermission()) {
                                DialogManager.showToast(BigFarmerActivity.this, getString(R.string.latlong_not_received));
                                getCurrentLocation(bigFarmerActivity);
                            }
                        } else {
                            BigFarmerDTO bigFarmerDTO = new BigFarmerDTO();
                            bigFarmerDTO.setFarmerName(Utils.getText(edtFarmerName));
                            bigFarmerDTO.setMobileNo(Utils.getText(edtMobileNo));
                            bigFarmerDTO.setVillageName(Utils.getText(edtVillageName));
                            bigFarmerDTO.setPincode(Utils.getText(edtPincode));
                            bigFarmerDTO.setFarmerPhoto(imagePath);
                            bigFarmerDTO.setBlockName(Utils.getText(edtBlockName));
                            bigFarmerDTO.setDistrictName(Utils.getText(edtDistrictName));
                            bigFarmerDTO.setPreviousYear(String.valueOf(previousYear));
                            bigFarmerDTO.setCurrentYear(String.valueOf(presentYear));
                            bigFarmerDTO.setTotalPreviousAcres(Utils.getText(edtTotalPreviousYear));
                            bigFarmerDTO.setTotalPresentAcres(Utils.getText(edtTotalPresentYear));
                            bigFarmerDTO.setPhiPreviousAcres(Utils.getText(edtPHIPreviousYear));
                            bigFarmerDTO.setPhiPresentAcres(Utils.getText(edtPHIPresentYear));
                            bigFarmerDTO.setTargetPreviousAcres(Utils.getText(edtTargetPreviousYear));
                            bigFarmerDTO.setTargetPresentAcres(Utils.getText(edtTargetPresentYear));
                            bigFarmerDTO.setRice(chcRice.isChecked());
                            bigFarmerDTO.setCorn(chcCorn.isChecked());
                            bigFarmerDTO.setMillet(chcMillet.isChecked());
                            bigFarmerDTO.setMustard(chcMustard.isChecked());
                            bigFarmerDTO.setTargetHybrid(Utils.getText(edtTargetHybrid));
                            bigFarmerDTO.setBlockType(spnBlockType.getSelectedItem().toString());
                            bigFarmerDTO.setVillageType(spnVillageType.getSelectedItem().toString());
                            bigFarmerDTO.setGeoLocation(geoLocation);
                            bigFarmerDTO.setEmployeeId(Utils.getUserId(BigFarmerActivity.this));
                            bigFarmerDTO.setEmployeeMobileNumber(Utils.getUserMobile(BigFarmerActivity.this));
                            getBigFarmer(bigFarmerDTO);
                        }
                    } else {
                        DialogManager.showToast(bigFarmerActivity, getString(R.string.checkNetwork));
                    }
                } else {
                    DialogManager.showSingleBtnPopup(bigFarmerActivity, null, getString(R.string.alert), validation, getString(R.string.ok));
                }
                break;
            case R.id.layout_clear:
                edtTargetHybrid.setText("");
                lnrClear.setVisibility(View.INVISIBLE);
                builder = null;
                break;
            case R.id.layout_plus:
                listTraget = new ArrayList<String>(Arrays.asList(edtTargetHybrid.getText().toString().split(",")));
                if (listTraget.size() > 4) {
                    DialogManager.showSingleBtnPopup(bigFarmerActivity, null, getString(R.string.alert), getString(R.string.total_hybrid), getString(R.string.ok));
                } else {
                    showOTPPopup(bigFarmerActivity);
                }
                break;
            case R.id.bf_profile_image:
            case R.id.bf_profile_capture:
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        //Location Permission already granted
                        cameraPermission();
                    } else {
                        //Request Location Permission
                        checkLocationPermission();
                    }
                } else {
                    cameraPermission();
                }
                break;
        }
    }

    private void getBigFarmer(BigFarmerDTO bigFarmerDTO) {
        Gson gson = new Gson();
        String data = gson.toJson(bigFarmerDTO);
//        String jwtToken = Utils.getJWTToken(data,bigFarmerActivity);
        APIRequestHandler.getInstance().getBigFamerDetails(bigFarmerActivity, data, imageTypedFile, this, true);
    }

    @Override
    public void onStart() {

        super.onStart();
        if (geoLocation == null) {
            if (checkLocPermission())
                getCurrentLocation(bigFarmerActivity);

        }

    }


    @Override
    public void refresh() {

        onLocationReceived(geoLocation);
    }

    public void onLocationReceived(String location) {
        if (location != null && !location.isEmpty()) {
            String lat = location.split(",")[0];
            String lon = location.split(",")[1];
            //  sendLoctionValues(lat, lon);

        }

    }

    private String validationField() {

        if (imageTypedFile == null)
            return getString(R.string.farmer_ph);
        if (Utils.getText(edtFarmerName).isEmpty())
            return getString(R.string.farm_name);
        if (Utils.getText(edtMobileNo).isEmpty() || edtMobileNo.getText().toString().length() < 10)
            return getString(R.string.mob_no);
        if (Utils.getText(edtVillageName).isEmpty())
            return getString(R.string.vill_name);
        if (Utils.getText(edtPincode).isEmpty() || edtPincode.getText().toString().length() < 6)
            return getString(R.string.pincode_data);
        if (Utils.getText(edtBlockName).isEmpty())
            return getString(R.string.blo_name);
        if (Utils.getText(edtDistrictName).isEmpty())
            return getString(R.string.dist_name);
        if (Utils.getText(edtTotalPreviousYear).isEmpty())
            return getString(R.string.tot_pre_yr);
        if (Utils.getText(edtTotalPresentYear).isEmpty())
            return getString(R.string.tot_pres_year);
        if (Utils.getText(edtPHIPreviousYear).isEmpty())
            return getString(R.string.phi_pre_year);
        if (Utils.getText(edtPHIPresentYear).isEmpty())
            return getString(R.string.phi_pres_year);
        if (Integer.valueOf(Utils.getText(edtPHIPreviousYear)) > Integer.valueOf(Utils.getText(edtTotalPreviousYear)))
            return getString(R.string.tot_phi);
        if (Integer.valueOf(Utils.getText(edtPHIPresentYear)) > Integer.valueOf(Utils.getText(edtTotalPresentYear)))
            return getString(R.string.tot_phi_pres);
        if (Utils.getText(edtTargetPreviousYear).isEmpty())
            return getString(R.string.tar_pre_year);
        if (Utils.getText(edtTargetPresentYear).isEmpty())
            return getString(R.string.tar_pres_year);
        if (Integer.valueOf(Utils.getText(edtTargetPreviousYear)) > Integer.valueOf(Utils.getText(edtTotalPreviousYear)))
            return getString(R.string.tot_tar);
        if (Integer.valueOf(Utils.getText(edtTargetPresentYear)) > Integer.valueOf(Utils.getText(edtTotalPresentYear)))
            return getString(R.string.tot_tar_pres);
        if (!chcCorn.isChecked() && !chcRice.isChecked() && !chcMillet.isChecked() && !chcMustard.isChecked())
            return getString(R.string.check_crop);
        if (Utils.getText(edtTargetHybrid).isEmpty())
            return getString(R.string.tar_hybrid);
        if (spnBlockType.getSelectedItemPosition() == 0)
            return getString(R.string.blck_type);
        if (spnVillageType.getSelectedItemPosition() == 0)
            return getString(R.string.vill_type);

        return null;
    }

    public void showOTPPopup(final Context mContext) {

        final Button mokBtn, mcancelBtn;
        final TextView mTextView;
        final EditText mEditText;

        final Dialog mDialog = Utils.getDialog(mContext, R.layout.big_farmer_popup_btn);
        mDialog.setCancelable(true);
        mDialog.setCanceledOnTouchOutside(true);
        ViewGroup root = mDialog
                .findViewById(R.id.rc_parent_view_for_font);

        mTextView = mDialog.findViewById(R.id.tv_question);
        mEditText = mDialog.findViewById(R.id.edt_comment_no);
        mokBtn = mDialog.findViewById(R.id.btn_ok);
        mcancelBtn = mDialog.findViewById(R.id.cancel_btn);
        mTextView.setText(tvTargetHydrid.getText().toString());
        mcancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mokBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (Utils.getText(mEditText).isEmpty()) {
                    DialogManager.showToast(mContext, getString(R.string.min_char));
                } else {
                    if (builder == null) {
                        builder = new StringBuilder();
                    } else {
                        builder.append(",");
                    }
                    builder.append(mEditText.getText().toString().trim());
                    edtTargetHybrid.setText(builder);
                    lnrClear.setVisibility(View.VISIBLE);
                    mDialog.dismiss();
                }
            }
        });
        mDialog.show();

    }

    private void cameraPermission() {
        File newfile = createFile();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkPermission()) {
                if (!Utils.isValidStr(imagePath)) {
                    openCameraApp(bigFarmerActivity, newfile);
                } else {
                    showOptionOpenCameraforBigFramer(null, bigFarmerActivity, newfile);
                }
            }
        } else {
            if (!Utils.isValidStr(imagePath)) {
                openCameraApp(bigFarmerActivity, newfile);
            } else {
                showOptionOpenCameraforBigFramer(null, bigFarmerActivity, newfile);
            }
        }
    }

    private File createFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        myDir = new File(root + File.separator + "BigFarmerImage");
        if (!myDir.exists())
            myDir.mkdirs();

        File newfile = new File(myDir, "IMG_" + System.currentTimeMillis() + ".JPG");
        try {
            newfile.createNewFile();
        } catch (IOException e) {
        }
        return newfile;
    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(bigFarmerActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(bigFarmerActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(bigFarmerActivity, Manifest.permission.CAMERA) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(bigFarmerActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(bigFarmerActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick(View v) {
                        ActivityCompat.requestPermissions(bigFarmerActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));

            } else {
                // No explanation needed, we can request the permission.
                if (Utils.isFirstTimeCamera(bigFarmerActivity)) {

                    DialogManager.showConformPopup(bigFarmerActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            Utils.setFirstTimeCamera(false, bigFarmerActivity);
                            ActivityCompat.requestPermissions(bigFarmerActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));


                } else {
                    ActivityCompat.requestPermissions(bigFarmerActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }

        return false;
    }

    private boolean checkLocPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return ActivityCompat.checkSelfPermission(bigFarmerActivity, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return true;
        }
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(bigFarmerActivity,
                                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            openCameraApp(bigFarmerActivity, newfile);
                        else
                            checkPermission();
                    } else {
                        openCameraApp(bigFarmerActivity, newfile);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
            break;
            case REQUEST_CAMERA_PERMISSION_DENAIL: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            openCameraApp(bigFarmerActivity, newfile);
                        else
                            showDialogToOpenSetting();
                    } else {
                        openCameraApp(bigFarmerActivity, newfile);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    showDialogToOpenSetting();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }

            break;
            // other 'case' lines to check for other
            // permissions this app might request
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(bigFarmerActivity,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient != null) {
                            mGoogleApiClient.connect();
                        } else {
                            buildGoogleApiClient();
                            mGoogleApiClient.connect();
                        }
                    }
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(bigFarmerActivity, "permission denied", Toast.LENGTH_LONG).show();
                }
            }
            break;

        }
    }

    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(bigFarmerActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(bigFarmerActivity, bigFarmerActivity.getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {

        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", packageName, null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ProfileImageSelectionUtil.OPENCAMERA) {
            if (resultCode == RESULT_OK) {
                try {/*
//                    uriStr = (Uri) data.getExtras().get("data");
                    Uri uriStrTremp = (Uri) data.getExtras().get("data");  // if we captured new pic but not cropped, thn showing old pic in imageView but when we click on see full photo thn new pic is shown. thats why created local variable

                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uriStrTremp);

                    if (bitmap != null) {
                        String imagePath = storeImage(bitmap, "profile" + "_");
                        Uri mCapturedUri = Uri.fromFile(new File(imagePath));
//                        mCropUri = Uri.fromFile(new File(imagePath));
//                        Uri mCapturedUri = Uri.fromFile(new File(imagePath));

//                        new Crop(mCapturedUri).output(uriStr).asSquare().start(this);  // removed by TARA
                        Intent gotoCropImage = new Intent(bigFarmerActivity, CropMyImageActivity.class);
                        gotoCropImage.setData(uriStrTremp);
                        startActivityForResult(gotoCropImage, REQUEST_CODE_FOR_IMAGE_CROPPING);
                    }*/

                    mExecutor = Executors.newSingleThreadExecutor();
                    Uri myUri = (Uri) data.getExtras().get("data");
                    uriStr = myUri;
                    mExecutor.submit(new LoadScaledImageTask(this, myUri, profileImage, calcImageSize()));
                    imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                    imagePath = myUri.toString();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (resultCode == RESULT_CANCELED) {
                // user cancelled Image capture
                DialogManager.showToast(BigFarmerActivity.this, getString(R.string.user_cancelled_image_capture));
            } else {
                // failed to capture image
                DialogManager.showToast(BigFarmerActivity.this, getString(R.string.failed_to_capture_image));
            }
        } else if (requestCode == Crop.REQUEST_CROP
                && resultCode == RESULT_OK) {

            try {
                // get the returned data
                Bundle extras = data.getExtras();
                // get the cropped bitmap
                Uri thePic = extras.getParcelable(MediaStore.EXTRA_OUTPUT);

                if (thePic == null)
                    return;
                profileImage.setImageBitmap(null);

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), thePic);

                profileImage.setImageBitmap(bitmap);

                imageTypedFile = new TypedFile("multipart/form-data", new File(thePic.toString().substring(7)));

                imagePath = thePic.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (requestCode == REQUEST_CODE_FOR_IMAGE_CROPPING) {
            if (resultCode == RESULT_OK) {
                mExecutor = Executors.newSingleThreadExecutor();
                Uri myUri = data.getData();
                uriStr = myUri;
                mExecutor.submit(new LoadScaledImageTask(this, myUri, profileImage, calcImageSize()));
                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                imagePath = myUri.toString();
            } else if (resultCode == RESULT_CANCELED) {

                DialogManager.showToast(BigFarmerActivity.this, getString(R.string.user_cancelled_image_cropping));
            }
        }
    }

    private String storeImage(Bitmap image, String fileName) {
        File pictureFile = getOutputMediaFile(fileName);
        if (pictureFile == null) {
            // Log.d(TAG,
            // "Error creating media file, check storage permissions: ");//
            // e.getMessage());
            return "";
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.JPEG, 80, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            // Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            // Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
        System.out.println("Path:" + pictureFile.getAbsolutePath());
        return pictureFile.getAbsolutePath();
    }

    /**
     * Create a File for saving an image or video
     */
    private File getOutputMediaFile(String fileName) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(
                Environment.getExternalStorageDirectory() + "/Android/data/"
                        + this.getPackageName() + "/Files");

        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }
        // Create a media file name

        File mediaFile;
        String mImageName = "Pioneer_" + fileName + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator
                + mImageName);
        return mediaFile;
    }

    private void showOptionOpenCameraforBigFramer(String title, final Activity context, final File newfile) {
        final Dialog mDialog;
        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.big_farmer_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mFromGallery, mViewPhoto;
        Button mCancel;
        TextView mTitile = mDialog.findViewById(R.id.alertTitle);
        if (Utils.isValidStr(title))
            mTitile.setText(title);
        mFromCamera = mDialog.findViewById(R.id.from_camera);
        mFromGallery = mDialog.findViewById(R.id.from_galery);
        mViewPhoto = mDialog.findViewById(R.id.view_image);
        mCancel = mDialog.findViewById(R.id.cancel);

        /*
        if (profileImage.getDrawable() != null) {
                    if (uriStr != null) {
                        ImageViewer(bigFarmerActivity, uriStr.toString());
                    }
                }
         */

        mFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                openCameraApp(context, newfile);
            }
        });
        mFromGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                profileImage.setImageResource(R.mipmap.img_profile_avatar);
                uriStr = null;
                imagePath = null;
                imageTypedFile = null;
            }
        });

        mViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                if (profileImage.getDrawable() != null) {
                    if (uriStr != null) {
                        ImageViewer(bigFarmerActivity, uriStr.toString());
                    }
                }
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }

    protected void getCurrentLocation(final Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (mGoogleApiClient != null) {
                if (mGoogleApiClient.isConnected()) {
                    mGoogleApiClient.disconnect();
                }
                mGoogleApiClient.connect();
            }
//            showProgressDialog();
            CountDownTimer start = new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

                @Override
                public void onTick(long millisUntilFinished) {
                    if (geoLocation != null) {
                        hideProgressDialog();
                        this.cancel();
                    }/* else {
                        DialogManager.showToast(BigFarmerActivity.this, getString(R.string.latlong_not_received));
                    }*/
                }

                @Override
                public void onFinish() {
                    hideProgressDialog();
                    // Toast.makeText(context, AppConstants.FAILD_LOCATION_MSG, Toast.LENGTH_SHORT).show();
                    //checkForLocation = false;
                    this.cancel();
                }
            }.start();
        } else {
//            geoLocation = "";
            DialogManager.showSingleBtnPopup(bigFarmerActivity, null, getString(R.string.alert), getString(R.string.gps), getString(R.string.ok));
        }
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null && responseObj instanceof CommonResEntity) {
            CommonResEntity resEntity = (CommonResEntity) responseObj;
            if (AppConstants.STATUS_CODE.equals(resEntity.getStatusCode())) {
                DialogManager.showSingleBtnPopup(BigFarmerActivity.this, new DialogMangerCallback() {
                    @Override
                    public void onOkClick(View v) {
                        finish();
                    }

                    @Override
                    public void onCancelClick(View view) {

                    }
                }, getString(R.string.alert), getString(R.string.bigFarmerSucess), getString(R.string.ok));
            } else {
                DialogManager.showToast(BigFarmerActivity.this, resEntity.getMessage());
            }
        }
    }

    // from 898 - 939 , related to cropping image funcationality
    public static class LoadScaledImageTask implements Runnable {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        Context context;
        Uri uri;
        ImageView imageView;
        int width;

        public LoadScaledImageTask(Context context, Uri uri, ImageView imageView, int width) {
            this.context = context;
            this.uri = uri;
            this.imageView = imageView;
            this.width = width;
        }

        @Override
        public void run() {
            final int exifRotation = com.isseiaoki.simplecropview.util.Utils.getExifOrientation(context, uri);
            int maxSize = com.isseiaoki.simplecropview.util.Utils.getMaxSize();
            int requestSize = Math.min(width, maxSize);
            try {
                final Bitmap sampledBitmap = com.isseiaoki.simplecropview.util.Utils.decodeSampledBitmapFromUri(context, uri, requestSize);
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        imageView.setImageMatrix(com.isseiaoki.simplecropview.util.Utils.getMatrixFromExifOrientation(exifRotation));
                        imageView.setImageBitmap(sampledBitmap);
                    }
                });
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private int calcImageSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        Display display = getWindowManager().getDefaultDisplay();
        display.getMetrics(metrics);
        return Math.min(Math.max(metrics.widthPixels, metrics.heightPixels), 2048);
    }

    @Override
    public void onBackPressed() {
        if (isDataAvailable()) {
            DialogManager.showConformPopup(BigFarmerActivity.this, new DialogMangerCallback() {
                @Override
                public void onOkClick(View v) {
                    finish();
                }

                @Override
                public void onCancelClick(View view) {

                }
            }, getString(R.string.alert), getString(R.string.are_u_sure_want_exit), getString(R.string.yes), getString(R.string.no));
        } else {
            finish();
        }
    }

    private boolean isDataAvailable() {
        if (Utils.isValidStr(edtFarmerName.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtMobileNo.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtVillageName.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtPincode.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtBlockName.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtDistrictName.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtTotalPreviousYear.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtTotalPresentYear.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtPHIPreviousYear.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtPHIPresentYear.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtTargetPreviousYear.getText().toString().trim()))
            return true;
        else if (Utils.isValidStr(edtTargetPresentYear.getText().toString().trim()))
            return true;
        else if (chcCorn.isChecked() || chcRice.isChecked() || chcMillet.isChecked() || chcMustard.isChecked())
            return true;
        else if (Utils.isValidStr(edtTargetHybrid.getText().toString().trim()))
            return true;
        else if (spnBlockType.getSelectedItemPosition() > 0)
            return true;
        else if (spnVillageType.getSelectedItemPosition() > 0)
            return true;

        return false;
    }
}
