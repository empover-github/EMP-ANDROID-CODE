package com.pioneer.emp.fab;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

import com.pioneer.emp.R;
import com.pioneer.parivaar.activities.BaseActivity;


/**
 * Created by hareesh.a on 7/19/2017.
 */

public class AudioPalyer extends BaseActivity implements View.OnClickListener {
    static MediaPlayer mp;
    String mySongs;
    SeekBar sb;
    Button btFF, btFB, btPv, btNxt;
    ImageView btPlay;
    // int position;
    Uri u;
    Thread updateSeekBar;
    int totalDuration;
    int currentDuration = 0;
    private boolean isDestroyed;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.emp_activity_audio_player);

        btPlay = findViewById(R.id.btPlay);
        btFF = findViewById(R.id.btFF);
        btFB = findViewById(R.id.btFB);
        btPv = findViewById(R.id.btPv);
        btNxt = findViewById(R.id.btNxt);
        sb = findViewById(R.id.seekBar);
        updateSeekBar = new Thread() {
            @Override
            public void run() {
                // super.run();
                totalDuration = mp.getDuration();
                while (currentDuration < totalDuration) {
                    try {
                        sleep(500);
                        if(isDestroyed)
                            break;
                        currentDuration = mp.getCurrentPosition();
                        sb.setProgress(currentDuration);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }
        };

        btPlay.setOnClickListener(this);
        btFF.setOnClickListener(this);
        btFB.setOnClickListener(this);
        btPv.setOnClickListener(this);
        btNxt.setOnClickListener(this);

        if (mp != null) {
            mp.stop();
            mp.release();
        }
        Intent i = getIntent();
        mySongs = i.getStringExtra("audioPath");
        /*Bundle b = i.getExtras();
        mySongs = (ArrayList) b.getParcelableArrayList("audio*//*");*/
        //  position = b.getInt("pos", 0);
        if (mySongs!=null && !mySongs.isEmpty())
        u = Uri.parse(mySongs.toString());
        try{
            mp = MediaPlayer.create(getApplicationContext(), u);
            if (mp==null){
                Toast.makeText(getApplicationContext(),"Could not play audio",Toast.LENGTH_LONG).show();
            }else{
                mp.start();
                sb.setMax(mp.getDuration());
                updateSeekBar.start();
            }
        }catch (Exception e){
            e.printStackTrace();

            onBackPressed();
        }


        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mp.seekTo(seekBar.getProgress());
            }
        });
    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btPlay:
                if (mp!= null && mp.isPlaying()) {
                    btPlay.setImageResource(R.mipmap.ic_play_button);
                    mp.pause();
                } else {
                    mp.start();
                    btPlay.setImageResource(R.mipmap.ic_pause_button);
                }
                break;

            /*case R.id.btFF:
                mp.seekTo(mp.getCurrentPosition() + 5000);
                break;*/
/*
            case R.id.btFB:
                mp.seekTo(mp.getCurrentPosition() - 5000);
                break;*/
/*
            case R.id.btNxt:
                mp.stop();
                mp.release();
                position = (position + 1) % mySongs.size();
                u = Uri.parse(mySongs.get(position).toString());
                mp = MediaPlayer.create(getApplicationContext(), u);
                mp.start();
                sb.setMax(mp.getDuration());
                break;*/
/*
            case R.id.btPv:
                mp.stop();
                mp.release();
                position = (position - 1 < 0) ? mySongs.size() - 1 : position - 1;
               *//* if(position-1 < 0){
                    position = mySongs.size() - 1;
                }else{
                    position = position - 1;
                }*//*
                u = Uri.parse(mySongs.get(position).toString());
                mp = MediaPlayer.create(getApplicationContext(), u);
                mp.start();
                sb.setMax(mp.getDuration());
                break;*/


        }
    }

    private void releaseMediaPlayer() {
        if (mp != null) {
            if (mp.isPlaying())
                mp.stop();
            mp.release();
            mp = null;
        }
    }

    @Override
    public void onBackPressed() {
        isDestroyed = true;
        releaseMediaPlayer();
        stopThread();
        super.onBackPressed();
        AudioPalyer.this.finish();
    }

    private synchronized void stopThread() {
        if (updateSeekBar != null) {
            updateSeekBar.interrupt();

        }
    }
}
