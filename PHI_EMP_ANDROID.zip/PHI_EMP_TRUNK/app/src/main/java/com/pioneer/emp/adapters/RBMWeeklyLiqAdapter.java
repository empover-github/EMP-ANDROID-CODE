package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dto.TBLWeeklyLiqDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;

/**
 * Created by fatima.t on 11-04-2018.
 */

public class RBMWeeklyLiqAdapter extends RecyclerView.Adapter<RBMWeeklyLiqAdapter.RbmWeeklyLiqHolder> {
    Context context;
    ArrayList<TBLWeeklyLiqDTO> arrayList;
    private OnBookletClickListener listener;

    public RBMWeeklyLiqAdapter(Context context, ArrayList<TBLWeeklyLiqDTO> profilesList, OnBookletClickListener listener) {
        this.context = context;
        this.arrayList = profilesList;
        this.listener = listener;
    }

    @Override
    public RbmWeeklyLiqHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.weekly_liquidation_rbm_list_item,parent,false);
        return new RbmWeeklyLiqHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(RbmWeeklyLiqHolder holder, int position) {
        holder.bind(arrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class RbmWeeklyLiqHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvHeader, tvInvoicedQuantity, tvNetReturns, tvLiquidation, tvLastSubmitDate, tvTerritory;
        LinearLayout mainLayout, territoryLL;
        public RbmWeeklyLiqHolder(View view) {
            super(view);

            mainLayout = view.findViewById(R.id.rbm_li_mainLayout);
            tvHeader = view.findViewById(R.id.rbm_li_headerTv);
            tvInvoicedQuantity = view.findViewById(R.id.rbm_li_invoiceQuanTv);
            tvNetReturns = view.findViewById(R.id.rbm_li_netReturnsTv);
            tvLiquidation = view.findViewById(R.id.rbm_li_liquidationTv);
            tvLastSubmitDate = view.findViewById(R.id.rbm_li_lastSubDateTv);
            territoryLL = view.findViewById(R.id.rbm_li_territoryLL);
            tvTerritory = view.findViewById(R.id.rbm_li_territoryTv);
            territoryLL.setVisibility(View.VISIBLE);
            mainLayout.setOnClickListener(this);

        }

        public void bind(final TBLWeeklyLiqDTO listModel ) {
            String headet_st = listModel.getCurrentYear() +" - "+ listModel.getSeasonName() +" - " +listModel.getCropName() +" - " +listModel.getHybridName();
            tvHeader.setText(headet_st);
            tvInvoicedQuantity.setText(listModel.getInvoiceQuantity());
            tvNetReturns.setText(listModel.getNetReturns());
            tvLiquidation.setText(listModel.getLiquidation());
            tvLastSubmitDate.setText(Utils.convertDateTimeFromSSStoSS(listModel.getMobileSubmittedDate()));
            tvTerritory.setText(listModel.getTerritoryName());
            mainLayout.setTag(listModel);
        }

        @Override
        public void onClick(View v) {
            listener.onItemClick(v, getAdapterPosition());
        }
    }
}
