package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.parivaar.model.BlockMobileData;

import java.util.List;

/**
 * Created by Hareesh.A on 08-05-2017.
 */

public class BlockMobileNoAdapter extends BaseAdapter {
    List<BlockMobileData> cuMobileData;
    Context context;

    public BlockMobileNoAdapter(Context context, List<BlockMobileData> data) {
        this.cuMobileData = data;
        this.context = context;
    }

    @Override
    public int getCount() {
        return cuMobileData.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.spinner_textview_align, null);
        }
        TextView textView = convertView.findViewById(R.id.textView1);
        BlockMobileData id = cuMobileData.get(position);
        textView.setText(id.getName());

        return convertView;
    }


    @Override
    public View getDropDownView(int position, View convertView,
                                ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.spinner_textview_align, null);
        }

        TextView textView = convertView.findViewById(R.id.textView1);
        BlockMobileData id = cuMobileData.get(position);
        textView.setText(id.getName());

        return convertView;

    }
}
