package com.pioneer.emp.cropAdvisory;

import com.pioneer.emp.fab.models.CropMasterEntity;
import com.pioneer.emp.fab.models.HybridMasterEntity;
import com.pioneer.emp.fab.models.SeasonMasterEntity;
import com.pioneer.emp.fab.models.StateCodeEntity;
import com.pioneer.emp.models.CategoryMasterEntity;
import com.pioneer.emp.models.CommonResponseEntity;

import java.io.Serializable;
import java.util.List;

/**
 * Created by sathish.s on 5/2/2017.
 */

public class CropAdvisoryModel extends CommonResponseEntity implements Serializable  {
    private List<StateCodeEntity> stateCodeMaster;
    private List<CategoryMasterEntity> categoryMaster;
    private List<SeasonMasterEntity> seasonMaster; // season
    private List<CropMasterEntity> cropMaster;
    private List<HybridMasterEntity> hybridMaster;


    public List<StateCodeEntity> getStateCodeMaster() {
        return stateCodeMaster;
    }

    public void setStateCodeMaster(List<StateCodeEntity> stateCodeMaster) {
        this.stateCodeMaster = stateCodeMaster;
    }

    public List<CategoryMasterEntity> getCategoryMaster() {
        return categoryMaster;
    }

    public void setCategoryMaster(List<CategoryMasterEntity> categoryMaster) {
        this.categoryMaster = categoryMaster;
    }

    public List<SeasonMasterEntity> getSeasonMaster() {
        return seasonMaster;
    }

    public void setSeasonMaster(List<SeasonMasterEntity> seasonMaster) {
        this.seasonMaster = seasonMaster;
    }

    public List<CropMasterEntity> getCropMaster() {
        return cropMaster;
    }

    public void setCropMaster(List<CropMasterEntity> cropMaster) {
        this.cropMaster = cropMaster;
    }

    public List<HybridMasterEntity> getHybridMaster() {
        return hybridMaster;
    }

    public void setHybridMaster(List<HybridMasterEntity> hybridMaster) {
        this.hybridMaster = hybridMaster;
    }
}
