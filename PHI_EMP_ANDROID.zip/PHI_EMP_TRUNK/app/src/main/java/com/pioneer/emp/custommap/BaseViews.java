package com.pioneer.emp.custommap;

/**
 * Created by fatima.t on 09-01-2018
 */


import androidx.annotation.NonNull;
import android.view.View;

import butterknife.ButterKnife;

/**
 * A base class for consolidated view holding in fragment, custom views, or view groups.<br>
 *
 * This is not intended to cater to the needs of specific use-cases, and is therefore not a suitable
 * place to add methods that may solve one problem for your subclass, but have limited or no
 * application elsewhere.  Before adding any method here, make sure it satisfies the below stipulations:
 * <br>
 *     <pre>
 *         1.  It solves some problem that every subclass also has.
 *         2.  It is not better solved by composing that functionality into a decoupled component
 *         3.  It does not introduce cognitive overhead disproportionate to its utility.
 *     </pre>
 *     <br>
 */
public class BaseViews {

    private View mRoot;

    protected BaseViews(@NonNull View root) {
        mRoot = root;
        ButterKnife.bind(this, root);
    }

    public View getRootView() {
        return mRoot;
    }

    /**
     * clears fields annotated with {@link Bind @Bind} to {@code null}.
     * <p>
     * This should only be used in the {@code onDestroyView} method of a fragment.
     */
    public void clear() {
//        ButterKnife.un  (mRoot);
        mRoot = null;
    }
}
