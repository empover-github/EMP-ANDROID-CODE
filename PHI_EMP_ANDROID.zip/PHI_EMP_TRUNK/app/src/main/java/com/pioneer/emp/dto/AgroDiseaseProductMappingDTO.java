package com.pioneer.emp.dto;

import com.pioneer.parivaar.dto.DTO;

/**
 * Created by hareesh.a on 12/18/2017.
 */

public class AgroDiseaseProductMappingDTO implements DTO {


    private String productName;

    private String character;

    private String work;

    private String productUse;

    private String caution;

    private String resultAndEffect;

    private String type;

    private String productImage;

    private String active;

    private String deleted;

    private String createdOn;

    private String updatedOn;

    private long id;

    private String status;

    private String diseaseId;

    private String agro_images_local;
    private String cropAndDiseaseNamesForMobile;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCharacter() {
        return character;
    }

    public void setCharacter(String character) {
        this.character = character;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getProductUse() {
        return productUse;
    }

    public void setProductUse(String productUse) {
        this.productUse = productUse;
    }

    public String getCaution() {
        return caution;
    }

    public void setCaution(String caution) {
        this.caution = caution;
    }

    public String getResultAndEffect() {
        return resultAndEffect;
    }

    public void setResultAndEffect(String resultAndEffect) {
        this.resultAndEffect = resultAndEffect;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(String updatedOn) {
        this.updatedOn = updatedOn;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAgro_images_local() {
        return agro_images_local;
    }

    public void setAgro_images_local(String agro_images_local) {
        this.agro_images_local = agro_images_local;
    }

    public String getCropAndDiseaseNamesForMobile() {
        return cropAndDiseaseNamesForMobile;
    }

    public void setCropAndDiseaseNamesForMobile(String cropAndDiseaseNamesForMobile) {
        this.cropAndDiseaseNamesForMobile = cropAndDiseaseNamesForMobile;
    }

    public String getDiseaseId() {
        return diseaseId;
    }

    public void setDiseaseId(String diseaseId) {
        this.diseaseId = diseaseId;
    }
}
