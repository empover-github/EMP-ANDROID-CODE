package com.pioneer.emp.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.models.CropAdvisoryStagesModel;
import com.pioneer.emp.models.SelectedCropAdvisoryModelMain;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fatima on 31-07-2017.
 */
public class EmpCropAdvisoryMasterDAO implements DAO {

    private final String TAG = "EmpCropAdvisoryMaster";
    private static EmpCropAdvisoryMasterDAO EmpCropAdvisoryMaster;

    public static EmpCropAdvisoryMasterDAO getInstance() {
        if ( EmpCropAdvisoryMaster == null) {
            EmpCropAdvisoryMaster = new EmpCropAdvisoryMasterDAO();
        }
        return EmpCropAdvisoryMaster;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        return null;
    }

    @SuppressLint("LongLogTag")
    public String insertt(Context context, DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            SelectedCropAdvisoryModelMain dto = (SelectedCropAdvisoryModelMain) dtoObject;
            ContentValues cValues = new ContentValues();
            cValues.put("id", dto.getId());
            cValues.put("endDate",dto.getEndDate());
            cValues.put("startDate",dto.getStartDate());
            cValues.put("name",dto.getName());
            cValues.put("categoryId",dto.getCategoryId());
            cValues.put("categoryName",dto.getCategoryName());
            cValues.put("cropId", dto.getCropId());
            cValues.put("cropName", dto.getCropName());
            cValues.put("hybridId",dto.getHybridId());
            cValues.put("hybridName", dto.getHybridName());
            cValues.put("seasonId", dto.getSeasonId());
            cValues.put("seasonName", dto.getSeasonName());
            cValues.put("stateId", dto.getStateId());
            cValues.put("stateName", dto.getStateName());
            

            long rowsEffected = dbObject.insert(DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER, null, cValues);
            if(rowsEffected >0) {
                List<CropAdvisoryStagesModel> msgList = dto.getMessageList();
                if (msgList != null && !msgList.isEmpty()) {
                    EmpCropAdvisoryStagesDAO.getInstance().deleteByCategory(msgList.get(0), DBHandler.getWritableDb(context));
                    for (CropAdvisoryStagesModel model : msgList) {
                        /*String downloadFileUrl = model.getVoiceFileName();
                        if (Utils.isValidStr(downloadFileUrl))*/

                        EmpCropAdvisoryStagesDAO.getInstance().insert(model, DBHandler.getWritableDb(context));
                    }
                }


                return "";
            }
            } catch (SQLException e) {
            BuildLog.i(TAG + "insert()", e.getMessage());
                return "";
            } finally {
                dbObject.close();
            }
        return  "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try{
            
        }catch (SQLException e){

        } finally {
            dbObject.close();
        }
        return false;
    }

    @SuppressLint("LongLogTag")
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        SelectedCropAdvisoryModelMain dto = (SelectedCropAdvisoryModelMain) dtoObject;
        try {

            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER + " WHERE id  = '" + dto.getId() + "'").execute();
//            dbObject.compileStatement("DELETE FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER).execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
            List<DTO> couponData = new ArrayList<>();
            Cursor cursor = null;
            try {
                cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER, null);
                    if (cursor.getCount() > 0) {
                    cursor.moveToFirst();
                    do {
                        SelectedCropAdvisoryModelMain dto = new SelectedCropAdvisoryModelMain();
                        dto.setId(cursor.getLong(0));
                        dto.setEndDate(cursor.getString(1));
                        dto.setStartDate(cursor.getString(2));
                        dto.setName(cursor.getString(3));
                        dto.setCategoryId(cursor.getString(4));
                        dto.setCategoryName(cursor.getString(5));
                        dto.setCropId(cursor.getString(6));
                        dto.setCropName(cursor.getString(7));
                        dto.setHybridId(cursor.getString(8));
                        dto.setHybridName(cursor.getString(9));
                        dto.setSeasonId(cursor.getString(10));
                        dto.setSeasonName(cursor.getString(11));
                        dto.setStateId(cursor.getString(12));
                        dto.setStateName(cursor.getString(13));
                     /*   dto.setId(cursor.getLong(0));
                        dto.setName(cursor.getString(1));*/
                        couponData.add(dto);
                    } while (cursor.moveToNext());
                }
            } catch (Exception e) {
                BuildLog.e(TAG, e.getMessage());
            } finally {
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
                dbObject.close();
            }
            return couponData;
    }

    public List<SelectedCropAdvisoryModelMain> getStoredRecords(SQLiteDatabase dbObject) {
            List<SelectedCropAdvisoryModelMain> couponData = new ArrayList<>();
            Cursor cursor = null;
            try {
                cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER, null);
                    if (cursor.getCount() > 0) {
                    cursor.moveToFirst();
                    do {
                        SelectedCropAdvisoryModelMain dto = new SelectedCropAdvisoryModelMain();
                        dto.setId(cursor.getLong(0));
                        dto.setEndDate(cursor.getString(1));
                        dto.setStartDate(cursor.getString(2));
                        dto.setName(cursor.getString(3));
                        dto.setCategoryId(cursor.getString(4));
                        dto.setCategoryName(cursor.getString(5));
                        dto.setCropId(cursor.getString(6));
                        dto.setCropName(cursor.getString(7));
                        dto.setHybridId(cursor.getString(8));
                        dto.setHybridName(cursor.getString(9));
                        dto.setSeasonId(cursor.getString(10));
                        dto.setSeasonName(cursor.getString(11));
                        dto.setStateId(cursor.getString(12));
                        dto.setStateName(cursor.getString(13));
                     /*   dto.setId(cursor.getLong(0));
                        dto.setName(cursor.getString(1));*/
                        couponData.add(dto);
                    } while (cursor.moveToNext());
                }
            } catch (Exception e) {
                BuildLog.e(TAG, e.getMessage());
            } finally {
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
                dbObject.close();
            }
            return couponData;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  "+DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    /**
     * It will return number of coupons available for upload, if there are no coupons available in local to sync it will return 0
     * @param dbObject
     * @return number of records available to sync
     */
    public int isDataAvailable(/*DTO dtoObject,*/SQLiteDatabase dbObject) {
//        SelectedCropAdvisoryModelMain dto = (SelectedCropAdvisoryModelMain) dtoObject;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
            return 0;
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return 0;
    }

    public boolean isDataExist(long id, SQLiteDatabase dbObject){
        Cursor cursor = null;
        try{
            cursor = dbObject.rawQuery("SELECT * FROM "+DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER + " WHERE id = '"+id+"'",null);
            return cursor.getCount() > 0;
        } catch (Exception e){
            BuildLog.e(TAG, e.getMessage());
            return false;
        } finally {
            if (cursor!=null && !cursor.isClosed()){
                cursor.close();
            }
            dbObject.close();
        }
    }

    public SelectedCropAdvisoryModelMain getSelectedRecordById(long id, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from "+DBHandler.TABLE_EMP_CROP_ADVISORY_MASTER+ " WHERE id = '"+id+"'",null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SelectedCropAdvisoryModelMain dto = new SelectedCropAdvisoryModelMain();

                    dto.setId(cursor.getLong(0));
                    dto.setEndDate(cursor.getString(1));
                    dto.setStartDate(cursor.getString(2));
                    dto.setName(cursor.getString(3));
                    dto.setCategoryId(cursor.getString(4));
                    dto.setCategoryName(cursor.getString(5));
                    dto.setCropId(cursor.getString(6));
                    dto.setCropName(cursor.getString(7));
                    dto.setHybridId(cursor.getString(8));
                    dto.setHybridName(cursor.getString(9));
                    dto.setSeasonId(cursor.getString(10));
                    dto.setSeasonName(cursor.getString(11));
                    dto.setStateId(cursor.getString(12));
                    dto.setStateName(cursor.getString(13));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return null;
    }



}
