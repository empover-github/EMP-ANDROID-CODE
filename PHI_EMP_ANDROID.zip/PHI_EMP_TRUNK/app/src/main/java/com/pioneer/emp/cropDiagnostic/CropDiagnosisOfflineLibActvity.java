package com.pioneer.emp.cropDiagnostic;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.fragments.CropDiagnosisCategoryFragment;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.fragments.BaseFragment;

import java.util.ArrayList;

/**
 * Created by rambabu.a on 17-01-2018.
 */

public class CropDiagnosisOfflineLibActvity extends BaseActivity implements View.OnClickListener {
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TextView txtHeader;
    private ImageView navBackBtn;
    private PagerAdapter pageAdapter;
    //    private BaseFragment cdPestFrag, cdWeedFrag, cdDiseaseFrag;
    private BaseFragment currFragment;

    public static final String EXTRA_CROP_NAME = "cropName";
    private String cropNameExtra;

    private Button libraryAllProductsBtn;

    private ArrayList<CropDiseaseModel> diseaseList = new ArrayList<>();
    private ArrayList<CropDiseaseModel> pestList = new ArrayList<>();
    private ArrayList<CropDiseaseModel> weedList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_diagnosis_offline_lib);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtHeader = findViewById(R.id.header_text);
//        txtHeader.setText(getString(R.string.title_diagnosis));
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);

        cropNameExtra = getIntent().getStringExtra(EXTRA_CROP_NAME);
        txtHeader.setText(cropNameExtra);

        libraryAllProductsBtn = findViewById(R.id.library_all_products);
        libraryAllProductsBtn.setOnClickListener(this);

        initializeViews();

    }

    private void initializeViews() {
        tabLayout = findViewById(R.id.orderlistTabs);
        viewPager = findViewById(R.id.orderListViewPager);
        pageAdapter = new PagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pageAdapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setupWithViewPager(viewPager);
        // set the divider between tabs
        /*View root = tabLayout.getChildAt(0);
        if (root instanceof LinearLayout) {
            ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(getResources().getColor(R.color.white));
            drawable.setSize(3, 1);
            ((LinearLayout) root).setDividerPadding(0);
            ((LinearLayout) root).setDividerDrawable(drawable);
        }*/

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                currFragment.refresh();
                /*switch (position) {
                    case 0:
                        if(cdPestFrag != null)
                            cdPestFrag.refresh();
                        break;

                    case 1:
                        if(cdWeedFrag != null)
                            cdWeedFrag.refresh();
                        break;

                    case 2:
                        if(cdDiseaseFrag != null)
                            cdDiseaseFrag.refresh();
                        break;
                }*/
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgBacknav:
                onBackPressed();
                break;
            case R.id.library_all_products:
                Intent gotoAllProducts = new Intent(CropDiagnosisOfflineLibActvity.this, CDAllProductsActivity.class);
                startActivity(gotoAllProducts);
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public class PagerAdapter extends FragmentStatePagerAdapter {
        private String tabTitles[] = getResources().getStringArray(R.array.prescriptionTabs);
        private String tabTitlesTags[] = getResources().getStringArray(R.array.prescriptionTabsTags);

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            Bundle setArgs = new Bundle();
            setArgs.putString(CropDiagnosisCategoryFragment.EXTRA_CROPNAME, cropNameExtra);
            currFragment = new CropDiagnosisCategoryFragment();
            setArgs.putString(CropDiagnosisCategoryFragment.EXTRA_CATEGORY, tabTitlesTags[position]);
//            setArgs.putString(CropDiagnosisCategoryFragment.EXTRA_CATEGORY, tabTitles[position]);
            currFragment.setArguments(setArgs);

            /*switch (position) {
                case 0:
                    setArgs.putString(CropDiagnosisCategoryFragment.EXTRA_CATEGORY, AppConstants.CD_PEST);
//                    setArgs.putSerializable(CropDiagnosisCategoryFragment.EXTRA_PEST_LIST, pestList);
                    cdPestFrag.setArguments(setArgs);
                    return cdPestFrag;
                case 1:
                    setArgs.putString(CropDiagnosisCategoryFragment.EXTRA_CATEGORY, AppConstants.CD_WEED);
//                    setArgs.putSerializable(CropDiagnosisCategoryFragment.EXTRA_WEED_LIST, weedList);
                    cdWeedFrag.setArguments(setArgs);
                    return cdWeedFrag;
                case 2:
                    setArgs.putString(CropDiagnosisCategoryFragment.EXTRA_CATEGORY, AppConstants.CD_DISEASE);
//                    setArgs.putSerializable(CropDiagnosisCategoryFragment.EXTRA_DISEASE_LIST, diseaseList);
                    cdDiseaseFrag.setArguments(setArgs);
                    return cdDiseaseFrag;
                default:
                    return null;
            }*/
            return currFragment;
        }

        @Override
        public int getCount() {
            return tabTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return tabTitles[position];
        }
    }
}
