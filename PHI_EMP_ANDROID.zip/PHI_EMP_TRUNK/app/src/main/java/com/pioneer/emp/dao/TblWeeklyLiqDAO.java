package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import com.pioneer.emp.dto.TBLWeeklyLiqDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;

import static com.pioneer.emp.dbHandler.DBHandler.TABLE_TBL_WEEKLY_LIQUIDATION;

/**
 * Created by fatima.t on 11-04-2018.
 */

public class TblWeeklyLiqDAO implements DAO {
    private final String TAG = "Disease";
    private static TblWeeklyLiqDAO diseasePrescription;

    public static TblWeeklyLiqDAO getInstance() {
        if (diseasePrescription == null) {
            diseasePrescription = new TblWeeklyLiqDAO();
        }
        return diseasePrescription;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            TBLWeeklyLiqDTO dto = (TBLWeeklyLiqDTO) dtoObject;
            ContentValues values = new ContentValues();
                    /*id integer PRIMARY KEY AUTOINCREMENT,
                    territoryId TEXT,
                    territoryName TEXT,
                    year TEXT,
                    seasonId TEXT,
                    seasonName TEXT,
                    cropId TEXT,
                    cropName TEXT,
                    hybridId TEXT,
                    hybridName TEXT,
                    invoicedQuantity TEXT,
                    netReturns TEXT,
                    liquidation TEXT,
                    lastSubmittedDate TEXT
                    */
            values.put("territoryId", dto.getTerritoryId());
            values.put("territoryName", dto.getTerritoryName());
            values.put("currentYear", dto.getCurrentYear());
            values.put("seasonId", dto.getSeasonId());
            values.put("seasonName", dto.getSeasonName());
            values.put("cropId", dto.getCropId());
            values.put("cropName", dto.getCropName());
            values.put("hybridId", dto.getHybridId());
            values.put("hybridName", dto.getHybridName());
            values.put("invoiceQuantity", dto.getInvoiceQuantity());
            values.put("netReturns", dto.getNetReturns());
            values.put("liquidation", dto.getLiquidation());
            values.put("mobileSubmittedDate", dto.getMobileSubmittedDate());
            values.put("sync", dto.getSync());

            long rowsEffected = dbObject.insert(TABLE_TBL_WEEKLY_LIQUIDATION, null, values);
            if (rowsEffected > 0)
                return "inserted";

        } catch (SQLException e) {
            BuildLog.i(TAG + "insert()", e.getMessage());
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            TBLWeeklyLiqDTO dto = (TBLWeeklyLiqDTO) dtoObject;
            ContentValues cValues = new ContentValues();

            if (Utils.isValidStr(dto.getTerritoryId()))
                cValues.put("territoryId", dto.getTerritoryId());
            if (Utils.isValidStr(dto.getTerritoryName()))
                cValues.put("territoryName", dto.getTerritoryName());
            if (Utils.isValidStr(dto.getCurrentYear()))
                cValues.put("currentYear", dto.getCurrentYear());
            if (Utils.isValidStr(dto.getSeasonId()))
                cValues.put("seasonId", dto.getSeasonId());
            if (Utils.isValidStr(dto.getSeasonName()))
                cValues.put("seasonName", dto.getSeasonName());
            if (Utils.isValidStr(dto.getCropId()))
                cValues.put("cropId", dto.getCropId());
            if (Utils.isValidStr(dto.getCropName()))
                cValues.put("cropName", dto.getCropName());
            if (Utils.isValidStr(dto.getHybridId()))
                cValues.put("hybridId", dto.getHybridId());
            if (Utils.isValidStr(dto.getHybridName()))
                cValues.put("hybridName", dto.getHybridName());
            if (Utils.isValidStr(dto.getInvoiceQuantity()))
                cValues.put("invoiceQuantity", dto.getInvoiceQuantity());
            if (Utils.isValidStr(dto.getNetReturns()))
                cValues.put("netReturns", dto.getNetReturns());
            if (Utils.isValidStr(dto.getLiquidation()))
                cValues.put("liquidation", dto.getLiquidation());
            if (Utils.isValidStr(dto.getMobileSubmittedDate()))
                cValues.put("mobileSubmittedDate", dto.getMobileSubmittedDate());
            cValues.put("sync", dto.getSync());
            dbObject.update(TABLE_TBL_WEEKLY_LIQUIDATION, cValues, "mobileId = ?", new String[]{dto.getMobileId()});
        } catch (SQLException e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public ArrayList<DTO> getRecords(SQLiteDatabase dbObject) {
        ArrayList<DTO> couponData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + TABLE_TBL_WEEKLY_LIQUIDATION, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    TBLWeeklyLiqDTO dto = new TBLWeeklyLiqDTO();

                    dto.setMobileId(String.valueOf(cursor.getInt(0)));
                    dto.setTerritoryId(cursor.getString(1));
                    dto.setTerritoryName(cursor.getString(2));
                    dto.setCurrentYear(cursor.getString(3));
                    dto.setSeasonId(cursor.getString(4));
                    dto.setSeasonName(cursor.getString(5));
                    dto.setCropId(cursor.getString(6));
                    dto.setCropName(cursor.getString(7));
                    dto.setHybridId(cursor.getString(8));
                    dto.setHybridName(cursor.getString(9));
                    dto.setInvoiceQuantity(cursor.getString(10));
                    dto.setNetReturns(cursor.getString(11));
                    dto.setLiquidation(cursor.getString(12));
                    dto.setMobileSubmittedDate(cursor.getString(13));
                    dto.setSync(cursor.getInt(14));

                    couponData.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return couponData;
    }

    public boolean deleteRecordById(int id, SQLiteDatabase dbObject) {
        try {
            int rowsEffected = dbObject.delete(TABLE_TBL_WEEKLY_LIQUIDATION, "mobileId = '" + id + "'", null);
            return rowsEffected > 0;
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  " + TABLE_TBL_WEEKLY_LIQUIDATION).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public TBLWeeklyLiqDTO getRecordById(long id, SQLiteDatabase dbObject) {
        TBLWeeklyLiqDTO response = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_TBL_WEEKLY_LIQUIDATION + " WHERE mobileId = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    response = new TBLWeeklyLiqDTO();

                    response.setMobileId(cursor.getString(cursor.getColumnIndex("mobileId")));
                    response.setTerritoryId(cursor.getString(cursor.getColumnIndex("territoryId")));
                    response.setTerritoryName(cursor.getString(cursor.getColumnIndex("territoryName")));
                    response.setCurrentYear(cursor.getString(cursor.getColumnIndex("currentYear")));
                    response.setSeasonId(cursor.getString(cursor.getColumnIndex("seasonId")));
                    response.setSeasonName(cursor.getString(cursor.getColumnIndex("seasonName")));
                    response.setCropId(cursor.getString(cursor.getColumnIndex("cropId")));
                    response.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    response.setHybridId(cursor.getString(cursor.getColumnIndex("hybridId")));
                    response.setHybridName(cursor.getString(cursor.getColumnIndex("hybridName")));
                    response.setInvoiceQuantity(cursor.getString(cursor.getColumnIndex("invoiceQuantity")));
                    response.setNetReturns(cursor.getString(cursor.getColumnIndex("netReturns")));
                    response.setLiquidation(cursor.getString(cursor.getColumnIndex("liquidation")));
                    response.setMobileSubmittedDate(cursor.getString(cursor.getColumnIndex("mobileSubmittedDate")));
                    response.setSync(cursor.getInt(cursor.getColumnIndex("sync")));

                    return response;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return response;
    }

    public boolean updateRecordById(DTO mainDTO, SQLiteDatabase dbObject) {
        TBLWeeklyLiqDTO dto = null;
        try {
            dto = (TBLWeeklyLiqDTO) mainDTO;
            ContentValues values = new ContentValues();

            values.put("mobileId", dto.getMobileId());
            values.put("territoryId", dto.getTerritoryId());
            values.put("territoryName", dto.getTerritoryName());
            values.put("currentYear", dto.getCurrentYear());
            values.put("seasonId", dto.getSeasonId());
            values.put("seasonName", dto.getSeasonName());
            values.put("cropId", dto.getCropId());
            values.put("cropName", dto.getCropName());
            values.put("hybridId", dto.getHybridId());
            values.put("hybridName", dto.getHybridName());
            values.put("invoiceQuantity", dto.getInvoiceQuantity());
            values.put("netReturns", dto.getNetReturns());
            values.put("liquidation", dto.getLiquidation());
            values.put("mobileSubmittedDate", dto.getMobileSubmittedDate());
            values.put("sync", dto.getSync());

            dbObject.update(TABLE_TBL_WEEKLY_LIQUIDATION, values, "mobileId = '" + dto.getMobileId() + "'", null);
            return true;
        } catch (Exception e) {
            BuildLog.d(TAG, "updateRecordById: ");
        } finally {
            dbObject.close();
        }
        return false;
    }

    public boolean isDataExists(String id, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select count(*) from " + TABLE_TBL_WEEKLY_LIQUIDATION + " WHERE mobileId = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0) > 0;
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }

    public TBLWeeklyLiqDTO getLastRecord(SQLiteDatabase dbObject){
        TBLWeeklyLiqDTO response = null;
        Cursor cursor = null;
        try {
            // whether it is uploaded or pending record?
            cursor = dbObject.rawQuery("Select * from " + TABLE_TBL_WEEKLY_LIQUIDATION + " ORDER BY id DESC LIMIT 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    response = new TBLWeeklyLiqDTO();

                    response.setMobileId(cursor.getString(cursor.getColumnIndex("mobileId")));
                    response.setTerritoryId(cursor.getString(cursor.getColumnIndex("territoryId")));
                    response.setTerritoryName(cursor.getString(cursor.getColumnIndex("territoryName")));
                    response.setCurrentYear(cursor.getString(cursor.getColumnIndex("currentYear")));
                    response.setSeasonId(cursor.getString(cursor.getColumnIndex("seasonId")));
                    response.setSeasonName(cursor.getString(cursor.getColumnIndex("seasonName")));
                    response.setCropId(cursor.getString(cursor.getColumnIndex("cropId")));
                    response.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    response.setHybridId(cursor.getString(cursor.getColumnIndex("hybridId")));
                    response.setHybridName(cursor.getString(cursor.getColumnIndex("hybridName")));
                    response.setInvoiceQuantity(cursor.getString(cursor.getColumnIndex("invoiceQuantity")));
                    response.setNetReturns(cursor.getString(cursor.getColumnIndex("netReturns")));
                    response.setLiquidation(cursor.getString(cursor.getColumnIndex("liquidation")));
                    response.setMobileSubmittedDate(cursor.getString(cursor.getColumnIndex("mobileSubmittedDate")));
                    response.setSync(cursor.getInt(cursor.getColumnIndex("sync")));

                    return response;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return response;
    }

    public ArrayList<DTO> getPendingRecords(SQLiteDatabase dbObject) {
        ArrayList<DTO> couponData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + TABLE_TBL_WEEKLY_LIQUIDATION+ " WHERE sync = '1' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    TBLWeeklyLiqDTO dto = new TBLWeeklyLiqDTO();

                    dto.setMobileId(String.valueOf(cursor.getInt(0)));
                    dto.setTerritoryId(cursor.getString(1));
                    dto.setTerritoryName(cursor.getString(2));
                    dto.setCurrentYear(cursor.getString(3));
                    dto.setSeasonId(cursor.getString(4));
                    dto.setSeasonName(cursor.getString(5));
                    dto.setCropId(cursor.getString(6));
                    dto.setCropName(cursor.getString(7));
                    dto.setHybridId(cursor.getString(8));
                    dto.setHybridName(cursor.getString(9));
                    dto.setInvoiceQuantity(cursor.getString(10));
                    dto.setNetReturns(cursor.getString(11));
                    dto.setLiquidation(cursor.getString(12));
                    dto.setMobileSubmittedDate(cursor.getString(13));
                    dto.setSync(cursor.getInt(14));

                    couponData.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return couponData;
    }


    public ArrayList<TBLWeeklyLiqDTO> getAllRecords(SQLiteDatabase dbObject) {
        ArrayList<TBLWeeklyLiqDTO> couponData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + TABLE_TBL_WEEKLY_LIQUIDATION + " WHERE sync = '1' ORDER BY mobileSubmittedDate DESC ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    TBLWeeklyLiqDTO dto = new TBLWeeklyLiqDTO();

                    dto.setMobileId(String.valueOf(cursor.getInt(0)));
                    dto.setTerritoryId(cursor.getString(1));
                    dto.setTerritoryName(cursor.getString(2));
                    dto.setCurrentYear(cursor.getString(3));
                    dto.setSeasonId(cursor.getString(4));
                    dto.setSeasonName(cursor.getString(5));
                    dto.setCropId(cursor.getString(6));
                    dto.setCropName(cursor.getString(7));
                    dto.setHybridId(cursor.getString(8));
                    dto.setHybridName(cursor.getString(9));
                    dto.setInvoiceQuantity(cursor.getString(10));
                    dto.setNetReturns(cursor.getString(11));
                    dto.setLiquidation(cursor.getString(12));
                    dto.setMobileSubmittedDate(cursor.getString(13));
                    dto.setSync(cursor.getInt(14));

                    couponData.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return couponData;
    }

    public TBLWeeklyLiqDTO getLatestRecordOfCombo(String year_st, String season_id, String crop_id, String hybrid_id, SQLiteDatabase dbObject) {
        TBLWeeklyLiqDTO response = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + TABLE_TBL_WEEKLY_LIQUIDATION + "  WHERE currentYear = '"+year_st+"' AND seasonId = '"+season_id+"' AND cropId = '"+crop_id+"' AND hybridId = '"+hybrid_id+"' ORDER BY mobileId DESC LIMIT 1 ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    response = new TBLWeeklyLiqDTO();

                    response.setMobileId(cursor.getString(cursor.getColumnIndex("mobileId")));
                    response.setTerritoryId(cursor.getString(cursor.getColumnIndex("territoryId")));
                    response.setTerritoryName(cursor.getString(cursor.getColumnIndex("territoryName")));
                    response.setCurrentYear(cursor.getString(cursor.getColumnIndex("currentYear")));
                    response.setSeasonId(cursor.getString(cursor.getColumnIndex("seasonId")));
                    response.setSeasonName(cursor.getString(cursor.getColumnIndex("seasonName")));
                    response.setCropId(cursor.getString(cursor.getColumnIndex("cropId")));
                    response.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    response.setHybridId(cursor.getString(cursor.getColumnIndex("hybridId")));
                    response.setHybridName(cursor.getString(cursor.getColumnIndex("hybridName")));
                    response.setInvoiceQuantity(cursor.getString(cursor.getColumnIndex("invoiceQuantity")));
                    response.setNetReturns(cursor.getString(cursor.getColumnIndex("netReturns")));
                    response.setLiquidation(cursor.getString(cursor.getColumnIndex("liquidation")));
                    response.setMobileSubmittedDate(cursor.getString(cursor.getColumnIndex("mobileSubmittedDate")));
                    response.setSync(cursor.getInt(cursor.getColumnIndex("sync")));

                    return response;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return response;
    }


    public TBLWeeklyLiqDTO isCombinationExist(String year_st, String season_id, String crop_id, String hybrid_id, SQLiteDatabase dbObject){
        TBLWeeklyLiqDTO response = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM "+TABLE_TBL_WEEKLY_LIQUIDATION+ " WHERE currentYear = '"+year_st+"' AND seasonId = '"+season_id+"' AND cropId = '"+crop_id+"' AND hybridId = '"+hybrid_id+"'",null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    response = new TBLWeeklyLiqDTO();

                    response.setMobileId(cursor.getString(cursor.getColumnIndex("mobileId")));
                    response.setTerritoryId(cursor.getString(cursor.getColumnIndex("territoryId")));
                    response.setTerritoryName(cursor.getString(cursor.getColumnIndex("territoryName")));
                    response.setCurrentYear(cursor.getString(cursor.getColumnIndex("currentYear")));
                    response.setSeasonId(cursor.getString(cursor.getColumnIndex("seasonId")));
                    response.setSeasonName(cursor.getString(cursor.getColumnIndex("seasonName")));
                    response.setCropId(cursor.getString(cursor.getColumnIndex("cropId")));
                    response.setCropName(cursor.getString(cursor.getColumnIndex("cropName")));
                    response.setHybridId(cursor.getString(cursor.getColumnIndex("hybridId")));
                    response.setHybridName(cursor.getString(cursor.getColumnIndex("hybridName")));
                    response.setInvoiceQuantity(cursor.getString(cursor.getColumnIndex("invoiceQuantity")));
                    response.setNetReturns(cursor.getString(cursor.getColumnIndex("netReturns")));
                    response.setLiquidation(cursor.getString(cursor.getColumnIndex("liquidation")));
                    response.setMobileSubmittedDate(cursor.getString(cursor.getColumnIndex("mobileSubmittedDate")));
                    response.setSync(cursor.getInt(cursor.getColumnIndex("sync")));

                    return response;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return response;
    }
}
