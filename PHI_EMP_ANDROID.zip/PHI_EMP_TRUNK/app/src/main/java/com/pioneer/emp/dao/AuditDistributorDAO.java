package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.pioneer.emp.models.AuditDistributorsDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yakaswamy.g on 4/24/2018.
 */

public class AuditDistributorDAO implements DAO {
    private final String TAG = "AuditDistributorDAO";
    private static AuditDistributorDAO auditDistributorDAO;

    public static AuditDistributorDAO getInstance() {
        if (auditDistributorDAO == null) {
            auditDistributorDAO = new AuditDistributorDAO();
        }

        return auditDistributorDAO;
    }
    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try{
        AuditDistributorsDTO dto = (AuditDistributorsDTO) dtoObject;
        ContentValues cv = new ContentValues();
        cv.put("name",dto.getName());
        cv.put("totalSale",dto.getTotalSale());
        cv.put("wholeSale",dto.getWholeSale());
        cv.put("retailSale",dto.getRetailSale());
        cv.put("auditId",dto.getAuditId());
       /* cv.put("namePreferred",dto.getNamePreferred());
        cv.put("nameMajorCompany",dto.getNameMajorCompany());*/

        long rowsEffected = dbObject.insert("DISTRIBUTOR_AUDIT", null, cv);
        if (rowsEffected > 0)
            return "";
        } catch (SQLException e) {
            return null;
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        AuditDistributorsDTO dto = (AuditDistributorsDTO) dtoObject;
        try {
            dbObject.compileStatement("DELETE FROM DISTRIBUTOR_AUDIT WHERE id = '"+dto.getId()+"'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        }finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM DISTRIBUTOR_AUDIT").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    public List<AuditDistributorsDTO> getRecordsToUpload(SQLiteDatabase dbObject, long auditId) {
        Cursor cursor = null;
        List<AuditDistributorsDTO> list = new ArrayList<AuditDistributorsDTO>();
        try{
            cursor = dbObject.rawQuery("SELECT * FROM DISTRIBUTOR_AUDIT WHERE auditId = "+auditId, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                AuditDistributorsDTO dto;
                do {
                    dto = new AuditDistributorsDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setAuditId(cursor.getLong(cursor.getColumnIndex("auditId")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setTotalSale(cursor.getLong(cursor.getColumnIndex("totalSale")));
                    dto.setWholeSale(cursor.getLong(cursor.getColumnIndex("wholeSale")));
                    dto.setRetailSale(cursor.getLong(cursor.getColumnIndex("retailSale")));
                   /* dto.setNamePreferred(cursor.getString(cursor.getColumnIndex("namePreferred")));
                    dto.setNameMajorCompany(cursor.getString(cursor.getColumnIndex("nameMajorCompany")));*/

                    list.add(dto);
                } while (cursor.moveToNext());
            }
        }catch (SQLiteException e){
            e.printStackTrace();
        }finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return list;
    }

    public boolean deleteById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM DISTRIBUTOR_AUDIT WHERE auditId = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        } finally {
            dbObject.close();
        }
        return false;
    }
}
