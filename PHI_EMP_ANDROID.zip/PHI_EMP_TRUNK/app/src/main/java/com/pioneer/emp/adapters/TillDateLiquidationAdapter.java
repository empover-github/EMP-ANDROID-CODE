package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.models.DailyLiquidationTillDateSalesDTO;
import com.pioneer.parivaar.utils.Utils;

import java.util.List;

public class TillDateLiquidationAdapter extends RecyclerView.Adapter<TillDateLiquidationAdapter.TillDateLiquidation> {
    private List<DailyLiquidationTillDateSalesDTO> tillDateSalesDTO;
    private Context context;


    public TillDateLiquidationAdapter(Context context, List<DailyLiquidationTillDateSalesDTO> dto) {
        this.tillDateSalesDTO = dto;
        this.context = context;

    }


    @Override
    public TillDateLiquidation onCreateViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.till_data_list, parent, false);
        TillDateLiquidation myHolder = new TillDateLiquidation(layout);
        return myHolder;
    }

    @Override
    public void onBindViewHolder(TillDateLiquidationAdapter.TillDateLiquidation holder, int position) {
        holder.bind(tillDateSalesDTO.get(position), position);
    }

    @Override
    public int getItemCount() {
        return tillDateSalesDTO.size();
    }

    public class TillDateLiquidation extends RecyclerView.ViewHolder {

        TextView tvTillDate, tvPioneer, tvCompe1, tvCompe2, tvOthers;
        LinearLayout mainLayout;
        View dailyItemView;

        TillDateLiquidation(View itemView) {
            super(itemView);

            tvTillDate = itemView.findViewById(R.id.daily_liq_tv_date_till);
            tvPioneer = itemView.findViewById(R.id.daily_liq_tv_date_pion);
            tvCompe1 = itemView.findViewById(R.id.daily_liq_tv_date_comp1);
            tvCompe2 = itemView.findViewById(R.id.daily_liq_tv_date_comp2);
            tvOthers = itemView.findViewById(R.id.daily_liq_tv_date_others);
            mainLayout = itemView.findViewById(R.id.mainlayout_till_date);
            dailyItemView = itemView.findViewById(R.id.daily_item_view);


        }

        void bind(final DailyLiquidationTillDateSalesDTO dto, int position) {
            if (dto != null) {
                if (dto.getTillDate() != null) {

                    tvTillDate.setText(Utils.formatDateToUser(dto.getTillDate()));
                }
                //newly added for decimal
                if (String.valueOf(dto.getPioneerSales()).contains(".0")) {
                    tvPioneer.setText(String.valueOf(Math.round(dto.getPioneerSales() * 100 / 100)));
                } else {
                    tvPioneer.setText(String.valueOf(dto.getPioneerSales()));
                }
                if (String.valueOf(dto.getCompetitor1Sales()).contains(".0")) {
                    tvCompe1.setText(String.valueOf(Math.round(dto.getCompetitor1Sales() * 100 / 100)));
                } else {
                    tvCompe1.setText(String.valueOf(dto.getCompetitor1Sales()));
                }

                if (String.valueOf(dto.getCompetitor2Sales()).contains(".0")) {
                    tvCompe2.setText(String.valueOf(Math.round(dto.getCompetitor2Sales() * 100 / 100)));
                } else {
                    tvCompe2.setText(String.valueOf(dto.getCompetitor2Sales()));
                }

                if (String.valueOf(dto.getOthersSales()).contains(".0")) {
                    tvOthers.setText(String.valueOf(Math.round(dto.getOthersSales() * 100 / 100)));
                } else {
                    tvOthers.setText(String.valueOf(dto.getOthersSales()));
                }


                if (position == tillDateSalesDTO.size() - 1)
                    dailyItemView.setVisibility(View.GONE);

            }


            mainLayout.setTag(dto);
        }


    }
}