package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.IdNameModel;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fatima.t on 1/10/2018.
 */

public class CropDiagnosisCropMasterDAO implements DAO {
    private final String TAG = "CropDiagnosisCropMasterDAO";
    private static CropDiagnosisCropMasterDAO cropMaster;

    public static CropDiagnosisCropMasterDAO getInstance() {
        if (cropMaster == null) {
            cropMaster = new CropDiagnosisCropMasterDAO();
        }
        return cropMaster;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            IdNameModel dto = (IdNameModel) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("id", dto.getId());
            cv.put("name", dto.getName());

            long rowsEffected = dbObject.insert(DBHandler.TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA, null, cv);
            if (rowsEffected > 0)
                return "";
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> cropData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    IdNameModel dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return cropData;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
    public List<DTO> getRecordById(long id, SQLiteDatabase dbObject) {
        List<DTO> cropData = new ArrayList<>();
        IdNameModel dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + DBHandler.TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA + " WHERE id = '" + id + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return cropData;
    }

    public ArrayList<IdNameModel> getALLRecords(SQLiteDatabase dbObject) {
        ArrayList<IdNameModel> cropData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_CROPDIAGNOSIS_CROP_MASTER_DATA, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    IdNameModel dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    cropData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return cropData;
    }

}
