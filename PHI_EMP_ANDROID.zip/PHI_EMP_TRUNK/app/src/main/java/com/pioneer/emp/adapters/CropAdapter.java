package com.pioneer.emp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.parivaar.model.IdNameModel;

import java.util.List;

/**
 * Created by Hareesh.A on 08-05-2017.
 */

public class CropAdapter extends BaseAdapter {
    List<IdNameModel> cuMobileData;
    Context context;

    public CropAdapter(Context context, List<IdNameModel> data) {
        this.cuMobileData = data;
        this.context = context;
    }

    @Override
    public int getCount() {
        return cuMobileData.size();
    }

    @Override
    public Object getItem(int position) {
        return cuMobileData.get(position);
    }


    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
          //  convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, null);
            convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, parent,false);
        }
        TextView textView = convertView.findViewById(R.id.textView1);
        IdNameModel id = cuMobileData.get(position);
        textView.setText(id.getName());


        return convertView;
    }


    @Override
    public View getDropDownView(int position, View convertView,
                                ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, null);
        }

        TextView textView = convertView.findViewById(R.id.textView1);
        IdNameModel id = cuMobileData.get(position);
        textView.setText(id.getName());

        return convertView;

    }
}
