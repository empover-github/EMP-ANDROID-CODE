package com.pioneer.emp.cropDiagnostic;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.pioneer.emp.R;
import com.pioneer.emp.dao.AgroDiseaseProductMappingDAO;
import com.pioneer.emp.dao.DiseasePrescriptionDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.DiseasePrescriptionDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit.RetrofitError;

//import com.pioneer.emp.adapters.GridAdapter;

/**
 * Created by rambabu.a on 17-01-2018.
 */

public class CDHazardDetailsActivity extends BaseActivity implements View.OnClickListener, OnBookletClickListener {
    private Toolbar toolbar;
    private TextView txtHeader;
    private ImageView navBackBtn;

    private TextView noDataAvailableText;
    private ScrollView scrollView;

    private ImageView hazardTypeImage;
    private TextView diseaseNameText, diseaseBioNameText, diseaseCategoryText, diseaseHostsText;
    private LinearLayout nutShellLL, hazardDesLL, symptomsLL, triggerLL, preventiveMeasureLL, bioControlLL, chemControlLL;
    private CheckedTextView nutShellCTV, hazardDesCTV, symptomsCTV, triggerCTV,preventiveMeasureCTV, bioControlCTV, chemControlCTV;
    private LinearLayout inANutShellTxtLL, preventiveMeasureTxtLL;
    private TextView hazardDesText, symptomsText, triggerText, bioControlText, chemControlText;
//    private GridView gridView;
    private RecyclerView recyclerview;
    private RelativeLayout relatedProRL;

    public static final String EXTRA_CROP_NAME = "cropName";
    public static final String EXTRA_CATEGORY = "category";
    public static final String EXTRA_SUB_CATEGORY = "subCategory";
    public static final String EXTRA_DISEASE_ID = "diseaseId";
    public static final String EXTRA_DISEASE_NAME= "diseaseName";
    private DiseasePrescriptionDTO model;
    private String productMappingId;

    private String cropName;
    private String category;
    private String subCategory;

//    private GridAdapter gridAdapter;
    private CDHDHorizontalRecycleAdapter recycleAdapter;
    private GridLayoutManager equipmentGridlayout;
    private ArrayList<String> productImageUrlList = new ArrayList<>();
    private ArrayList<String> productImageIdsList = new ArrayList<>();
    String diseaseId,reqId;
    CropDiseaseModel dto;
    CDHazardDetailsActivity thisActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cd_hazard_details);

        // ActionBar Related components
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        thisActivity=this;
        txtHeader = findViewById(R.id.header_text); // after this set Title to toolBar
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);
        model=new DiseasePrescriptionDTO();
        initializeViews();

        if (AppConstants.DiseasesAdapter.equals(Utils.getCDAdapter(CDHazardDetailsActivity.this))){

            Intent i = getIntent();
            if (i!=null){

                diseaseId = i.getStringExtra(EXTRA_DISEASE_ID);
                reqId="0";
                if ("".equals(diseaseId) || diseaseId==null || diseaseId.equals("")){
                    dto = (CropDiseaseModel) i.getSerializableExtra("disease");
                    diseaseId=String.valueOf(dto.getDiseaseId());
                    reqId=dto.getDiseaseRequestId();
                }
            }


            if (Utils.isNetworkConnection(CDHazardDetailsActivity.this)){
                JSONObject jsonObject=new JSONObject();
                try {
                    jsonObject.put("diseaseId",diseaseId);
                    jsonObject.put("diseaseRequestId",reqId);
                }catch (JSONException e){
                    e.getMessage();
                }catch (Exception e){
                    e.printStackTrace();
                }
                String jwsToken=Utils.getJWTToken(jsonObject.toString(),CDHazardDetailsActivity.this);
                APIRequestHandler.getInstance().getCDDiseaseDetectedDetails(thisActivity,jwsToken,true);
            }

            Utils.setCDAdapter(AppConstants.DiseasesAdapter,CDHazardDetailsActivity.this);

        }else {
            getIntentData();
        }
    }

    private void getIntentData() {
        Intent getExtravalues = getIntent();
        cropName = getExtravalues.getStringExtra(EXTRA_CROP_NAME);
        category = getExtravalues.getStringExtra(EXTRA_CATEGORY);
        subCategory = getExtravalues.getStringExtra(EXTRA_SUB_CATEGORY);
        String st_diseaseId = getExtravalues.getStringExtra(EXTRA_DISEASE_ID);
        String st_diseaseName = getExtravalues.getStringExtra(EXTRA_DISEASE_NAME);

        if (Utils.isValidStr(st_diseaseId)) {
            long diseaseId = Long.parseLong(st_diseaseId);
//            model = DiseasePrescriptionDAO.getInstance().getSelectedRecordByDiseaseId(cropName, category, diseaseId, DBHandler.getReadableDb(CDHazardDetailsActivity.this));
            model = DiseasePrescriptionDAO.getInstance().getSelectedRecordByDiseaseId(cropName, subCategory, diseaseId, DBHandler.getReadableDb(CDHazardDetailsActivity.this)); // new Added
        } else if(Utils.isValidStr(st_diseaseName)) {
            model = DiseasePrescriptionDAO.getInstance().getSelectedRecordByDiseaseName(cropName,category, st_diseaseName, DBHandler.getReadableDb(CDHazardDetailsActivity.this));
        }

        setData(model);
    }

    private void initializeViews() {

        noDataAvailableText = findViewById(R.id.cdhd_noDataAvailableTxt);
        scrollView = findViewById(R.id.cdhd_scrollView);

        hazardTypeImage = findViewById(R.id.cdhd_imageview);
        diseaseNameText = findViewById(R.id.cdhd_diseaseNameTxt);
        diseaseBioNameText = findViewById(R.id.cdhd_diseaseBioNameTxt);
        diseaseCategoryText = findViewById(R.id.cdhd_diseaseCategoryTxt);
        diseaseHostsText = findViewById(R.id.cdhd_diseaseHostsTxt);

        nutShellLL = findViewById(R.id.cdhd_nutshellLL);
        hazardDesLL = findViewById(R.id.cdhd_hazardDesLL);
        symptomsLL = findViewById(R.id.cdhd_symptomsLL);
        triggerLL = findViewById(R.id.cdhd_triggerLL);
        preventiveMeasureLL = findViewById(R.id.cdhd_preventiveMeasureLL);
        bioControlLL = findViewById(R.id.cdhd_biocControlLL);
        chemControlLL = findViewById(R.id.cdhd_chemicalControlLL);

        nutShellCTV = findViewById(R.id.cdhd_nsCheckedView);
        hazardDesCTV = findViewById(R.id.cdhd_hdCheckdView);
        symptomsCTV = findViewById(R.id.cdhd_symCheckedView);
        triggerCTV = findViewById(R.id.cdhd_trigCheckedView);
        preventiveMeasureCTV = findViewById(R.id.cdhd_pmCheckedView);
        bioControlCTV = findViewById(R.id.cdhd_bcCheckedView);
        chemControlCTV = findViewById(R.id.cdhd_ccCheckedView);

        inANutShellTxtLL = findViewById(R.id.cdhd_ns_detailsLL);
        preventiveMeasureTxtLL = findViewById(R.id.cdhd_pm_detailsLL);
        hazardDesText = findViewById(R.id.cdhd_hdDetailsTxt);
        symptomsText = findViewById(R.id.cdhd_symDetailsTxt);
        triggerText = findViewById(R.id.cdhd_trigDetailsTxt);
        bioControlText = findViewById(R.id.cdhd_bcDetailsTxt);
        chemControlText = findViewById(R.id.cdhd_ccDetailsTxt);

        relatedProRL = findViewById(R.id.cdhd_related_prodRL);
        recyclerview = findViewById(R.id.cdhd_rp_recycle_list);

        /*RecyclerView.LayoutManager horizontalLayoutManagaer = new LinearLayoutManager(CDHazardDetailsActivity.this, LinearLayoutManager.HORIZONTAL, false);
        recyclerview.setLayoutManager(horizontalLayoutManagaer);*/
        equipmentGridlayout = new GridLayoutManager(CDHazardDetailsActivity.this, 3);
        recyclerview.setHasFixedSize(true);
        recyclerview.setLayoutManager(equipmentGridlayout);
        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.margin7);
        recyclerview.addItemDecoration(new SpacesItemDecoration(spacingInPixels));
        recycleAdapter = new CDHDHorizontalRecycleAdapter(this, productImageIdsList, productImageUrlList, this);
        recyclerview.setAdapter(recycleAdapter);
        /*gridView = (GridView) findViewById(R.id.cdhd_gridView);
        gridAdapter = new GridAdapter(CDHazardDetailsActivity.this, productImageUrlList, productImageIdsList);
        gridView.setAdapter(gridAdapter);*/

        /*// checkedTextview listener
        nutShellCTV.setOnClickListener(this);
        hazardDesCTV.setOnClickListener(this);
        symptomsCTV.setOnClickListener(this);
        triggerCTV.setOnClickListener(this);
        preventiveMeasureCTV.setOnClickListener(this);
        bioControlCTV.setOnClickListener(this);
        chemControlCTV.setOnClickListener(this);*/

        // full layout listener
        hazardTypeImage.setOnClickListener(this);
        nutShellLL.setOnClickListener(this);
        hazardDesLL.setOnClickListener(this);
        symptomsLL.setOnClickListener(this);
        triggerLL.setOnClickListener(this);
        preventiveMeasureLL.setOnClickListener(this);
        bioControlLL.setOnClickListener(this);
        chemControlLL.setOnClickListener(this);

        nutShellLL.setVisibility(View.GONE);
        hazardDesLL.setVisibility(View.GONE);
        symptomsLL.setVisibility(View.GONE);
        triggerLL.setVisibility(View.GONE);
        preventiveMeasureLL.setVisibility(View.GONE);
        bioControlLL.setVisibility(View.GONE);
        chemControlLL.setVisibility(View.GONE);
    }

    private void setData(DiseasePrescriptionDTO model) {

        if (model != null){
            noDataAvailableText.setVisibility(View.GONE);
            scrollView.setVisibility(View.VISIBLE);

//            txtHeader.setText((cropName +"-" +category +"-" +model.getDiseaseName()));
            if (cropName!=null){
                txtHeader.setText((cropName +"-" +model.getDiseaseType() +"-" +model.getDiseaseName())); // changed for Multilanguage
            }else{
                txtHeader.setText((model.getCrop() +"-" +model.getDiseaseType() +"-" +model.getDiseaseName())); // changed for Multilanguage
            }

            if (Utils.isValidStr(model.getCdi_images_local()) || Utils.isValidStr(model.getDiseaseImageFile())) {
                hazardTypeImage.setVisibility(View.VISIBLE);
                if (Utils.isValidStr(model.getCdi_images_local())) {
                    Glide.with(CDHazardDetailsActivity.this)
                            .load(model.getCdi_images_local())
                            .error(R.drawable.image_placeholder)
                            .placeholder(R.drawable.image_placeholder)
                            .dontAnimate().into(hazardTypeImage);
                } else if (Utils.isNetworkConnection(CDHazardDetailsActivity.this) && Utils.isValidStr(model.getDiseaseImageFile())) {
                    Glide.with(CDHazardDetailsActivity.this)
                            .load(model.getDiseaseImageFile())
                            .error(R.drawable.image_placeholder)
                            .placeholder(R.drawable.image_placeholder)
                            .dontAnimate().into(hazardTypeImage);
                }
            } else {
                hazardTypeImage.setVisibility(View.GONE);
            }

            diseaseNameText.setText(model.getDiseaseName());
            diseaseBioNameText.setText(model.getDiseaseBiologicalName());
            diseaseCategoryText.setText(model.getDiseaseType());

            if (Utils.isValidStr(model.getHosts())) {
                diseaseHostsText.setVisibility(View.VISIBLE);
                diseaseHostsText.setText(("Hosts:" + model.getHosts()));
            } else {
                diseaseHostsText.setVisibility(View.GONE);
                diseaseHostsText.setText("");
            }

            if (Utils.isValidStr(model.getInANutshell())){
                nutShellLL.setVisibility(View.VISIBLE);
                inANutShellTxtLL.removeAllViews();
                String[] nutShellTextList = model.getInANutshell().replace("\r","").replace("\n", "").split("\\.");
                for (int i=0; i<nutShellTextList.length; i++){
                    TextView textView = new TextView(CDHazardDetailsActivity.this);
                    textView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    textView.setText((nutShellTextList[i]+"."));
                    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_leaf);
                    Drawable icon = new TopGravityDrawable(getResources(), bitmap);
                    textView.setCompoundDrawablesWithIntrinsicBounds(icon, null, null, null);
                    textView.setCompoundDrawablePadding(10);
                    inANutShellTxtLL.addView(textView);
                }
            } else {
                inANutShellTxtLL.removeAllViews();
                nutShellLL.setVisibility(View.GONE);
            }

            if (Utils.isValidStr(model.getHazadDescription())){
                hazardDesLL.setVisibility(View.VISIBLE);
                hazardDesText.setText(model.getHazadDescription());
            } else {
                hazardDesLL.setVisibility(View.GONE);
                hazardDesText.setText("");
            }

            if (Utils.isValidStr(model.getSymptoms())){
                symptomsLL.setVisibility(View.VISIBLE);
                symptomsText.setText(model.getSymptoms());
            } else {
                symptomsLL.setVisibility(View.GONE);
                symptomsText.setText("");
            }

            if (Utils.isValidStr(model.getTrigger())){
                triggerLL.setVisibility(View.VISIBLE);
                triggerText.setText(model.getTrigger());
            } else {
                triggerLL.setVisibility(View.GONE);
                triggerText.setText("");
            }

            if (Utils.isValidStr(model.getPreventiveMeasures())){
                preventiveMeasureLL.setVisibility(View.VISIBLE);
                preventiveMeasureTxtLL.removeAllViews(); // set the dynamic views here
                String[] pmTextList = model.getPreventiveMeasures().replace("\r","").replace("\n", "").split("\\.");
                for (int i=0; i<pmTextList.length; i++){
                    TextView textView = new TextView(CDHazardDetailsActivity.this);
                    textView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    textView.setText((pmTextList[i]+"."));
                    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_leaf);
                    Drawable icon = new TopGravityDrawable(getResources(), bitmap);
                    textView.setCompoundDrawablesWithIntrinsicBounds(icon, null, null, null);
                    textView.setCompoundDrawablePadding(10);
                    preventiveMeasureTxtLL.addView(textView);
                }
            } else {
                preventiveMeasureTxtLL.removeAllViews();
                preventiveMeasureLL.setVisibility(View.GONE);
            }
            if (Utils.isValidStr(model.getBiologicalControl())){
                bioControlLL.setVisibility(View.VISIBLE);
                bioControlText.setText(model.getBiologicalControl());
            } else {
                bioControlLL.setVisibility(View.GONE);
                bioControlText.setText("");
            }

            if (Utils.isValidStr(model.getChemicalControl())){
                chemControlLL.setVisibility(View.VISIBLE);
                chemControlText.setText(model.getChemicalControl());
            } else {
                chemControlLL.setVisibility(View.GONE);
                chemControlText.setText("");
            }

            // here check for network connection and mapping urls / mapping offline urls
            if (Utils.isNetworkConnection(CDHazardDetailsActivity.this) && Utils.isValidStr(model.getProductMapping()) && Utils.isValidStr(model.getProductMappingImage())) {
                List<String> tempIdList = Arrays.asList(model.getProductMapping().replace(" ","").split(","));
                productImageIdsList.clear();
                productImageIdsList.addAll(tempIdList);
                List<String> tempUrlList = Arrays.asList(model.getProductMappingImage().replace(" ","").split(","));
                productImageUrlList.clear();
                productImageUrlList.addAll(tempUrlList);
            } else  if (Utils.isValidStr(model.getProductMapping())){
                List<String> tempProdIdList = Arrays.asList(model.getProductMapping().replace(" ","").split(","));
                productImageIdsList.clear();
                productImageIdsList.addAll(tempProdIdList);
                productImageUrlList.clear();
                for (String singleImage : tempProdIdList){
                    String localImageUrl = AgroDiseaseProductMappingDAO.getInstance().getLocalImageURLById(singleImage, DBHandler.getReadableDb(CDHazardDetailsActivity.this));
                    if (Utils.isValidStr(localImageUrl))
                        productImageUrlList.add(localImageUrl);
                    else
                        productImageUrlList.add("No Url Found"); // If this is not added then wrong mapping to imageID & ImageURL occurs
                }
            }


            if (productImageIdsList != null && !productImageIdsList.isEmpty() && productImageUrlList != null && !productImageUrlList.isEmpty()){
                relatedProRL.setVisibility(View.VISIBLE);
                recycleAdapter.notifyDataSetChanged();
//                gridAdapter.notifyDataSetChanged();
            } else {
                relatedProRL.setVisibility(View.GONE);
                productImageUrlList.clear();
                productImageIdsList.clear();
                recycleAdapter.notifyDataSetChanged();
//                gridAdapter.notifyDataSetChanged();
            }

        } else {
            noDataAvailableText.setVisibility(View.VISIBLE);
            scrollView.setVisibility(View.GONE);
            if (Utils.isValidStr(subCategory))
                txtHeader.setText(cropName +"-" +subCategory);
            else
                txtHeader.setText(cropName +"-" +category);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imgBacknav:
                onBackPressed();
                break;
            case R.id.cdhd_imageview:
               /* if (Utils.isValidStr(model.getCdi_images_local())){
                    ImageViewer(CDHazardDetailsActivity.this, model.getCdi_images_local());
                } else if (Utils.isNetworkConnection(CDHazardDetailsActivity.this) && Utils.isValidStr(model.getDiseaseImageFile())) {
                    ImageViewer(CDHazardDetailsActivity.this, model.getDiseaseImageFile());
                }*/

                if (AppConstants.DiseasesAdapter.equals(Utils.getCDAdapter(CDHazardDetailsActivity.this))){
                    if (Utils.isNetworkConnection(CDHazardDetailsActivity.this)) {


                        ImageViewer(CDHazardDetailsActivity.this, model.getDiseaseImageFile());
                    }
                    else {
                       DialogManager.showToast(CDHazardDetailsActivity.this,getResources().getString(R.string.no_internet));
                    }
                }else{
                    if (Utils.isValidStr(model.getCdi_images_local())){
                        ImageViewer(CDHazardDetailsActivity.this, model.getCdi_images_local());
                    }

                    else if (Utils.isNetworkConnection(CDHazardDetailsActivity.this) && Utils.isValidStr(model.getDiseaseImageFile())) {
                        ImageViewer(CDHazardDetailsActivity.this, model.getDiseaseImageFile());
                    }
                }
                break;
//            case R.id.cdhd_nsCheckedView:
            case R.id.cdhd_nutshellLL:
                if (!nutShellCTV.isChecked()){
                    nutShellCTV.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    inANutShellTxtLL.setVisibility(View.VISIBLE);
                    nutShellCTV.setChecked(true);
                } else {
                    nutShellCTV.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    inANutShellTxtLL.setVisibility(View.GONE);
                    nutShellCTV.setChecked(false);
                }
                break;
//            case R.id.cdhd_hdCheckdView:
            case R.id.cdhd_hazardDesLL:
                if (!hazardDesCTV.isChecked()){
                    hazardDesCTV.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    hazardDesText.setVisibility(View.VISIBLE);
                    hazardDesCTV.setChecked(true);
                } else {
                    hazardDesCTV.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    hazardDesText.setVisibility(View.GONE);
                    hazardDesCTV.setChecked(false);
                }
                break;
//            case R.id.cdhd_symCheckedView:
            case R.id.cdhd_symptomsLL:
                if (!symptomsCTV.isChecked()){
                    symptomsCTV.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    symptomsText.setVisibility(View.VISIBLE);
                    symptomsCTV.setChecked(true);
                } else {
                    symptomsCTV.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    symptomsText.setVisibility(View.GONE);
                    symptomsCTV.setChecked(false);
                }
                break;
//            case R.id.cdhd_trigCheckedView:
            case R.id.cdhd_triggerLL:
                if (!triggerCTV.isChecked()){
                    triggerCTV.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    triggerText.setVisibility(View.VISIBLE);
                    triggerCTV.setChecked(true);
                } else {
                    triggerCTV.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    triggerText.setVisibility(View.GONE);
                    triggerCTV.setChecked(false);
                }
                break;
//            case R.id.cdhd_pmCheckedView:
            case R.id.cdhd_preventiveMeasureLL:
                if (!preventiveMeasureCTV.isChecked()){
                    preventiveMeasureCTV.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    preventiveMeasureTxtLL.setVisibility(View.VISIBLE);
                    preventiveMeasureCTV.setChecked(true);
                } else {
                    preventiveMeasureCTV.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    preventiveMeasureTxtLL.setVisibility(View.GONE);
                    preventiveMeasureCTV.setChecked(false);
                }
                break;
//            case R.id.cdhd_bcCheckedView:
            case R.id.cdhd_biocControlLL:
                if (!bioControlCTV.isChecked()){
                    bioControlCTV.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    bioControlText.setVisibility(View.VISIBLE);
                    bioControlCTV.setChecked(true);
                } else {
                    bioControlCTV.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    bioControlText.setVisibility(View.GONE);
                    bioControlCTV.setChecked(false);
                }
                break;
//            case R.id.cdhd_ccCheckedView:
            case R.id.cdhd_chemicalControlLL:
                if (!chemControlCTV.isChecked()){
                    chemControlCTV.setCheckMarkDrawable(R.mipmap.ic_list_open_black);
                    chemControlText.setVisibility(View.VISIBLE);
                    chemControlCTV.setChecked(true);
                } else {
                    chemControlCTV.setCheckMarkDrawable(R.mipmap.ic_list_close_black);
                    chemControlText.setVisibility(View.GONE);
                    chemControlCTV.setChecked(false);
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        productMappingId = productImageIdsList.get(position);


        if (AppConstants.DiseasesAdapter.equals(Utils.getCDAdapter(CDHazardDetailsActivity.this))){

            if (Utils.isNetworkConnection(CDHazardDetailsActivity.this)){
                Intent intent = new Intent(CDHazardDetailsActivity.this, CDProductDetailsActivity.class);
                intent.putExtra(CDProductDetailsActivity.RELATED_PRODUCT_MAPPING_ID, productMappingId);
                startActivity(intent);
            }else{
                DialogManager.showToast(CDHazardDetailsActivity.this, getString(R.string.no_internet));
            }
        }else{
            Intent intent = new Intent(CDHazardDetailsActivity.this, CDProductDetailsActivity.class);
            intent.putExtra(CDProductDetailsActivity.EXTRA_PRODUCT_MAPPING_ID, productMappingId);
            startActivity(intent);
        }
    }

    public class TopGravityDrawable extends BitmapDrawable {
        public TopGravityDrawable(Resources res, Bitmap bitmap) {
            super(res, bitmap);
        }
        @Override
        public void draw(Canvas canvas) {
            int halfCanvas = canvas.getHeight() / 2;
            int halfDrawable = getIntrinsicHeight() / 2;
            canvas.save();
            canvas.translate(0, -halfCanvas + halfDrawable);
            super.draw(canvas);
            canvas.restore();
        }
    }

    public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
        private int space;

        public SpacesItemDecoration(int space) {
            this.space = space;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view,
                                   RecyclerView parent, RecyclerView.State state) {
            outRect.left = space;
            outRect.right = space;
            outRect.bottom = space;

            // Add top margin only for the first item to avoid double space between items
            if (parent.getChildLayoutPosition(view) == 0) {
                outRect.top = space;
            } else {
                outRect.top = space;
            }
        }
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        super.onRequestSuccess(responseObj);
        if (responseObj instanceof DiseaseResponseModel){
            DiseaseResponseModel cdDiseasePrescriptionDTO=(DiseaseResponseModel)responseObj;
            if (AppConstants.STATUS_CODE.equals(String.valueOf(cdDiseasePrescriptionDTO.getStatusCode()))){
               // String diseaseResInfo=Utils.getJWTResponse(cdDiseasePrescriptionDTO.getResponse(),CDHazardDetailsActivity.this);
                String diseaseResInfo=cdDiseasePrescriptionDTO.getResponse();
                model=new Gson().fromJson(diseaseResInfo,DiseasePrescriptionDTO.class);
                setData(model);
            } else {
                noDataAvailableText.setVisibility(View.VISIBLE);
                scrollView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onRequestFailure(RetrofitError errorCode, String errorFrom) {
        super.onRequestFailure(errorCode, errorFrom);
    }
}
