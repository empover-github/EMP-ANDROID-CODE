package com.pioneer.emp.custommap;

import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;

import com.google.android.gms.maps.model.LatLng;
import com.pioneer.parivaar.utils.BuildLog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Fatima on 09-01-2018.
 */
public class GeocodeHelper extends AsyncTask<Object,Void,Address> {
    String TAG = this.getClass().getSimpleName();
    IGeocodeHandler iHandler;
    private boolean isFetchedAddress = false;
    private Timer timer = new Timer();
    private final long timerDelay = 2000;
    private LatLng addressLatlng ;
    List<Address> formattedAddress = null;

    @Override
    protected Address doInBackground(Object... objects) {
        Address address = null;
        try {
            Geocoder geocoder = (Geocoder) objects[0];
            LatLng latlng = (LatLng) objects[1];
            addressLatlng = new LatLng(latlng.latitude,latlng.longitude);
            IGeocodeHandler iHandler = (IGeocodeHandler) objects[2];
            this.iHandler = iHandler;

            List<Address> addresses = null;
            if (latlng != null && geocoder != null) {
                startTimer();

                addresses = geocoder.getFromLocation(latlng.latitude, latlng.longitude, 2);
                if(addresses != null && addresses.size() > 0 ){
                    isFetchedAddress = true;
                    address = addresses.get(0);
                }
            }
        }catch(Exception e){
            BuildLog.d(TAG, "Exception in GeocodeHelper : "+ e );
        }
        return address;
    }

    private void startTimer(){
        timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                shouldCallApi();
            }
        };
        timer.schedule(timerTask,timerDelay);
    }


    private void shouldCallApi(){
        BuildLog.e(TAG,"xxx shouldCallApi xxx");
        if(isFetchedAddress){
            BuildLog.e(TAG,"xxx shouldCallApi Calling xxx");
            try {
                URL url = new URL("http://maps.googleapis.com/maps/api/geocode/json?latlng="+addressLatlng.latitude+","+addressLatlng.longitude+"&sensor=true");
                // making connection
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                // Reading data's from url
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output;
                String out="";
                System.out.println("Output from Server .... \n");
                while ((output = br.readLine()) != null) {
                    //System.out.println(output);
                    out+=output;
                }

                 //Converting Json formatted string into JSON object
                JSONObject json = new JSONObject(out);
                JSONArray results=json.getJSONArray("results");
                JSONObject rec = results.getJSONObject(0);
//                JSONArray address_components=rec.getJSONArray("address_components");
//                for(int i=0;i<address_components.length();i++){
//                    JSONObject rec1 = address_components.getJSONObject(i);
//                    JSONArray types=rec1.getJSONArray("types");
//                }
                String formatted_address = rec.getString("formatted_address");
                BuildLog.w(TAG,"formatted_address————–"+formatted_address);
                conn.disconnect();
            } catch (MalformedURLException e) {
                // TO DO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TO DO Auto-generated catch block
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onPostExecute(Address address) {
        if(address != null){
            iHandler.onGeocodeSuccess(address);
        }else {
            iHandler.onGeocodeError(StringUtils.ERR_NO_RESULT);
        }
    }

}
