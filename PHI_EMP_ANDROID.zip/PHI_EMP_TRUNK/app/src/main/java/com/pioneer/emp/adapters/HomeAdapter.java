package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pioneer.emp.R;
import com.pioneer.emp.fragments.HomeFragment;

import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.IconItems;


import java.util.ArrayList;


/**
 * Created by rambabu.a on 26-03-2018.
 */

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.MyHolder> {
    private Context context;
    private ArrayList<IconItems> imageArray;
    private OnBookletClickListener listener;

    public HomeAdapter(Context context, ArrayList<IconItems> imageArray, HomeFragment listener) {
        this.context = context;
        this.imageArray = imageArray;
        this.listener = listener;

    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_grid_layout, null);
        MyHolder myHolder = new MyHolder(layout);
        return myHolder;

    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        Glide.with(context)
                .load(imageArray.get(position).getIcon())
                .error(R.drawable.image_placeholder)
                .placeholder(R.drawable.image_placeholder)
                .dontAnimate().into(holder.imageView);


        holder.bind(imageArray.get(position));
    }

    @Override
    public int getItemCount() {
        return imageArray.size();
    }

    class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        TextView textView;
        RelativeLayout rlyImageLayout;
        LinearLayout vmItemOverly;

        MyHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.grid_image);
//            textView = (TextView) itemView.findViewById(R.id.grid_text);
            rlyImageLayout = itemView.findViewById(R.id.layoutimage);
//            vmItemOverly = (LinearLayout) itemView.findViewById(R.id.eqptListItemOverly);

        }

        void bind(final IconItems iconItems) {
//            EquipmentVehicleDetailsDTO vehicleDetailsDTO = equipmentVehicleDetailsDTO.get(position);
            rlyImageLayout.setTag(iconItems);
            rlyImageLayout.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

           // int position = (int) v.getTag();
            listener.onItemClick(v, getAdapterPosition());
        }
    }

}
