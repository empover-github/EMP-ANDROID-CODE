package com.pioneer.emp;

import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.pioneer.emp.adapters.CDmasterPendingUploadAdapter;
import com.pioneer.emp.dao.CropDiagnosisMasterDataUploadDAO;
import com.pioneer.emp.dao.UpLoadImagesDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.CropDiagnosisMasterDataUploadDTO;
import com.pioneer.emp.dto.UploadImagesDTO;
import com.pioneer.parivaar.activities.BaseActivity;

import java.util.ArrayList;
import java.util.List;

public class CDMasterUploadPending extends BaseActivity implements View.OnClickListener{
    private CDMasterUploadPending thisActivity;
    private Toolbar toolbar;
    private TextView txtHeader;
    private ImageView navBackBtn;

    RecyclerView recyclerView;
    private CDmasterPendingUploadAdapter adapter;
    private TextView noDataAvailable;

    private ArrayList<CropDiagnosisMasterDataUploadDTO> pendingList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activty_cd_mastr_upload_pending);
        thisActivity = this;

        // ActionBar Related components
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        txtHeader = findViewById(R.id.header_text);
        txtHeader.setText(getString(R.string.cd_master_pending_upload));
        navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        navBackBtn.setOnClickListener(this);

        ArrayList<CropDiagnosisMasterDataUploadDTO> uploadingList = CropDiagnosisMasterDataUploadDAO.getInstance().getRecordsAll(DBHandler.getReadableDb(thisActivity));
        if (uploadingList.size() > 0){
            for (CropDiagnosisMasterDataUploadDTO list : uploadingList) {
                CropDiagnosisMasterDataUploadDTO dto = new CropDiagnosisMasterDataUploadDTO();
                dto.setCropName(list.getCropName());
                dto.setDiseaseClassificationName(list.getDiseaseClassificationName());
                dto.setTransactionTime(list.getTransactionTime());
                if (list.getStatus() == 0){
                    // add item directly
                    CropDiagnosisMasterDataUploadDTO record = CropDiagnosisMasterDataUploadDAO.getInstance().getRecordByIdSingleRecord(list.getId(), DBHandler.getReadableDb(thisActivity));
                    String[] uploadFilesList = record.getImageUrls().split(",");
                    dto.setImagePending(String.valueOf(uploadFilesList.length));
                } else {
                    List<UploadImagesDTO> uploadFilesList = UpLoadImagesDAO.getInstance().getRecordsOfserverId(list.getServerId(), DBHandler.getReadableDb(this), this);
                    //  check pending image upload is there or not
                    if (uploadFilesList.size() > 0){
                        dto.setImagePending(String.valueOf(uploadFilesList.size()));
                    }
                }
                pendingList.add(dto);
            }
        }

        noDataAvailable = findViewById(R.id.cdmdp_nodataAvailable);


        recyclerView = findViewById(R.id.recycler_view_pending_list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setAutoMeasureEnabled(true);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new CDmasterPendingUploadAdapter(thisActivity, pendingList);
        recyclerView.setAdapter(adapter);

        if (pendingList.size() > 0){
            // show list
            noDataAvailable.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            // show no Data available
            noDataAvailable.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imgBacknav:
                onBackPressed();
                break;
        }
    }
}
