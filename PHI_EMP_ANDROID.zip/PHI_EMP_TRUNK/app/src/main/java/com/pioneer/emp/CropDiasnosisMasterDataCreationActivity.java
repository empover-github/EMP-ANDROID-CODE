package com.pioneer.emp;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.pioneer.emp.adapters.IdNameModelAdapter;
import com.pioneer.emp.adapters.MultipleImagesAddRemoveAdapter;
import com.pioneer.emp.dao.CropDiagnosisCropMasterDAO;
import com.pioneer.emp.dao.CropDiagnosisMasterDataUploadDAO;
import com.pioneer.emp.dao.DiseaseMasterDataDAO;
import com.pioneer.emp.dao.UpLoadImagesDAO;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.CropDiagnosisMasterDataUploadDTO;
import com.pioneer.emp.dto.UploadImagesDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.CDMasterDataDownloadResponse;
import com.pioneer.emp.models.CropDiagnosisMasterDataUploadReuqest;
import com.pioneer.emp.models.CropDiagnosisMasterResponse;
import com.pioneer.emp.models.IdServerIdModel;
import com.pioneer.emp.services.CdMasterUpLoadFileServiceNewJob;
import com.pioneer.emp.services.CdMasterUpLoadFileService;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.apiInterfaces.APIRequestHandler;
import com.pioneer.parivaar.apiInterfaces.CommonInterface;
import com.pioneer.parivaar.listeners.DialogMangerCallback;
import com.pioneer.parivaar.model.DiseaseMasterModel;
import com.pioneer.parivaar.model.IdNameModel;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.ProfileImageSelectionUtil;
import com.pioneer.parivaar.utils.SearchActivity;
import com.pioneer.parivaar.utils.Utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import retrofit.RetrofitError;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class CropDiasnosisMasterDataCreationActivity extends BaseActivity implements View.OnClickListener, OnBookletClickListener, CommonInterface, AdapterView.OnItemSelectedListener {
    private CropDiasnosisMasterDataCreationActivity thisActivity;

    private Button submitBtn;
    private Spinner cropSpn, diseaseCalssifiSpn;
    private EditText tagEt, diseaseClassifictaionEt;
    private TextView addImageTv;
    private RecyclerView recyclerView;

    private MultipleImagesAddRemoveAdapter listAdapter;
    private ArrayList<String> list = new ArrayList<>();

    private Bitmap imageBitmap = null;
    private String imgPath = null;
    String CapturedImagePath;

    private IdNameModelAdapter cropAdapter;
    private ArrayList<IdNameModel> cropList = new ArrayList<>();
    private ArrayList<DiseaseMasterModel> diseaseList = new ArrayList<>();
    private ArrayList<IdNameModel> diseaseListIdNameModel = new ArrayList<>();
    private int selectedCropPosition;
    private long selectedDiseaseId = -1;


    public static final int REQUEST_CODE_FOR_SEARCH_ACTIVITY = 2000;
    private String latLongValues;
    private boolean checkLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cd_master_data_creation);
        thisActivity = this;
        checkLocation = true;

        if (Utils.isNetworkConnection(thisActivity))
            APIRequestHandler.getInstance().cropDiagnosisMasterDataDownload("", thisActivity, this, false);

        // ActionBar Related components
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView txtHeader = findViewById(R.id.header_text);
        ImageView navBackBtn = findViewById(R.id.imgBacknav);
        navBackBtn.setVisibility(View.VISIBLE);
        txtHeader.setText(getString(R.string.cropProtectionTool));
        navBackBtn.setOnClickListener(this);

        initializeViews();

        if (checkLocPermission()) {
            if (Utils.checkPlayServices(thisActivity)) {
                buildGoogleApiClient();
            }
        }
    }

    private void initializeViews() {
        submitBtn = findViewById(R.id.cdmdc_btnSubmit);
        cropSpn = findViewById(R.id.cdmdc_spnCrop);
//        diseaseCalssifiSpn = findViewById(R.id.cdmdc_spnDiseaseClasifi);
        diseaseClassifictaionEt = findViewById(R.id.cdmdc_etDiseaseClasifi);
        tagEt = findViewById(R.id.cdmdc_etTag);
        addImageTv = findViewById(R.id.cdmdc_addImageTv);
        recyclerView = findViewById(R.id.cdmdc_recyclerview);

        GridLayoutManager equipmentGridlayout = new GridLayoutManager(thisActivity, 4);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(equipmentGridlayout);
//        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.margin3);
//        recyclerView.addItemDecoration(new GridviewSpaceItemDecoration(spacingInPixels));
        listAdapter = new MultipleImagesAddRemoveAdapter(thisActivity, list, this);
        recyclerView.setAdapter(listAdapter);

        cropAdapter = new IdNameModelAdapter(thisActivity, cropList);
        cropSpn.setAdapter(cropAdapter);

        diseaseClassifictaionEt.setText(getString(R.string.select));
        diseaseClassifictaionEt.setTag(-1);

        setMasterData();

        diseaseClassifictaionEt.setOnClickListener(this);
        addImageTv.setOnClickListener(this);
        submitBtn.setOnClickListener(this);
        cropSpn.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgBacknav:
                onBackPressed();
                break;
            case R.id.cdmdc_etDiseaseClasifi:
                if (diseaseListIdNameModel.size() > 1) {
                    Intent gotoSearch = new Intent(thisActivity, SearchActivity.class);
                    gotoSearch.putExtra(SearchActivity.EXTRA_LIST, diseaseListIdNameModel);
                    gotoSearch.putExtra(SearchActivity.INTENT_TYPE, getString(R.string.disease_classification));
                    startActivityForResult(gotoSearch, REQUEST_CODE_FOR_SEARCH_ACTIVITY);
                } else {
                    DialogManager.showToast(thisActivity, "Disease name list does not exist");
                }
                break;
            case R.id.cdmdc_btnSubmit:
                // insert data into table
                if (checkValidations()) {
                    if (checkLocation) {
                        if (latLongValues != null && latLongValues.length() > 0) {
                            proceedFurther();
                        } else {
                            DialogManager.showToast(thisActivity, getString(R.string.latlong_not_received));
                            getMyCurrentLocation(thisActivity);
                        }
                    } else {
                        proceedFurther();
                    }
                }
                break;
            case R.id.cdmdc_addImageTv:
                if (android.os.Build.VERSION.SDK_INT >= 23) {
                    checkPermissions();
                } else {
                    openCam();
                }
                break;
        }

    }

    private void proceedFurther() {

        CropDiagnosisMasterDataUploadDTO dto = new CropDiagnosisMasterDataUploadDTO();

        Address myAdd = getLatlongAddress(latLongValues, thisActivity);

        dto.setCropId(cropList.get(selectedCropPosition).getId());
        dto.setCropName(cropList.get(selectedCropPosition).getName());
        dto.setDiseaseClassificationId(selectedDiseaseId);
        dto.setDiseaseClassificationName(diseaseClassifictaionEt.getText().toString());
        dto.setTags(tagEt.getText().toString());
        String imagePaths = getImagesPathFromList();
        dto.setImageUrls(imagePaths);
        dto.setLatLongValues(latLongValues);

        if (myAdd != null){
            dto.setAddress(myAdd.getAddressLine(0));
        }
        dto.setImgTotCount(list.size());
        dto.setTransactionTime(Utils.getCurrentTimeAndDate(thisActivity));

        CropDiagnosisMasterDataUploadDAO.getInstance().insert(dto, DBHandler.getWritableDb(thisActivity));

        if (Utils.isNetworkConnection(thisActivity)){
            callDataTransactionApi();
        } else {
            DialogManager.showSingleBtnPopup(thisActivity, new DialogMangerCallback() {
                @Override
                public void onOkClick(View v) {
                    clearFileds();
                }
                @Override
                public void onCancelClick(View view) {

                }
            }, getString(R.string.alert), getString(R.string.dat_captured_connect_to_server), getString(R.string.ok));
        }
    }

    private void callDataTransactionApi() {
            ArrayList<CropDiagnosisMasterDataUploadDTO> uploadingList = CropDiagnosisMasterDataUploadDAO.getInstance().getALLRecords(DBHandler.getReadableDb(thisActivity));
            if (uploadingList.size() > 0) {
                CropDiagnosisMasterDataUploadReuqest request = new CropDiagnosisMasterDataUploadReuqest();
                request.setCropDiseaseMasterList(uploadingList);
                String jwtToken = Utils.getJWTTokenFC(new Gson().toJson(request), thisActivity);
                APIRequestHandler.getInstance().cropDiagnosisMasterDataUpload(jwtToken, thisActivity, this, true);
            }
    }

    private void clearFileds() {
        cropSpn.setSelection(0);
        diseaseClassifictaionEt.setText(getString(R.string.select));
        tagEt.setText("");
        list.clear();
        listAdapter.notifyDataSetChanged();
    }

    private String getImagesPathFromList() {
        StringBuilder imgsTagsBuilder = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i == list.size() - 1)
                imgsTagsBuilder.append(list.get(i));
            else
                imgsTagsBuilder.append(list.get(i)).append(",");

        }
        return imgsTagsBuilder.toString();
    }

    private void openCam() {
        if (list.size() < 10) {
            File f = createFile();
//        ProfileImageSelectionUtil.showOptionOpenCamera(null, thisActivity, f);
            if(f != null)
                ProfileImageSelectionUtil.openCameraApp(thisActivity, f);
            else
                DialogManager.showToast(thisActivity, "There is a technical issue in creating new file, please close and open app");
        } else {
            DialogManager.showToast(thisActivity, "Only 10 images can be added for single disease master");
        }
    }

    @Override
    public void onBackPressed() {
        if (isDataAvailable()) {
            DialogManager.showConformPopup(thisActivity, new DialogMangerCallback() {
                @Override
                public void onOkClick(View v) {
                    finish();
                }

                @Override
                public void onCancelClick(View view) {

                }
            }, getString(R.string.alert), getString(R.string.go_back_msg), getString(R.string.yes), getString(R.string.no));
        } else {
            finish();
        }
    }

    private File createFile() {
        // create folder inside the applictaion folder for storing images
        String dirPath = getFilesDir().getAbsolutePath();//Environment.getExternalStorageDirectory().toString();
        dirPath = dirPath + File.separator + "Files" + File.separator + "CropDiagnosisMasterImages";
        File destination = new File(dirPath);
        // have the object build the directory structure, if needed.
        if (!destination.exists()) {
            destination.mkdirs();
        }
        String st_timeStampForImage = Utils.getUserId(thisActivity) + "_" + Utils.getDeviceId(thisActivity) + "_" + System.currentTimeMillis();
        File f = new File(destination, st_timeStampForImage + ".jpg");
        try {
            if (f.createNewFile())
                return f;
            else return null;
        } catch (IOException ignore) {
        }
        return null;
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(thisActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(thisActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            openCam();
        } else {
            startActivityForResult(new Intent(thisActivity, Permissions.class), Permissions.PERMISSIONS_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            /*if (requestCode == ProfileImageSelectionUtil.CAMERA
                    || requestCode == ProfileImageSelectionUtil.GALLERY) {
                if (resultCode == RESULT_OK) {
                    Bitmap image = ProfileImageSelectionUtil.getImage(data,
                            this);

                    if (image != null) {
                        if (requestCode == ProfileImageSelectionUtil.CAMERA) {
                            if (ProfileImageSelectionUtil.isUriTrue) {
                                image = ProfileImageSelectionUtil
                                        .getCorrectOrientationImage(this,
                                                data.getData(), image);
                            } else {
                                image = ProfileImageSelectionUtil
                                        .getCorrectOrientationImage(this, image);
                            }
                        } else {
                            Uri selectedImage = data.getData();

                            image = ProfileImageSelectionUtil
                                    .getCorrectOrientationImage(this,
                                            selectedImage, image);
                        }

                        if (image != null) {
                            imageBitmap = image;
                            try {
                                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                                imageBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
                                FileOutputStream fo;
                                File f = createFile();
                                try {
                                    fo = new FileOutputStream(f);
                                    fo.write(bytes.toByteArray());
                                    MediaScannerConnection.scanFile(this,
                                            new String[]{f.getPath()},
                                            new String[]{"image/jpeg"}, null);
                                    fo.close();
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                imgPath = f.getAbsolutePath();
                                CapturedImagePath = null;
                                CapturedImagePath = imgPath;
                                multipleImages.add(imgPath);
                                listAdapter.notifyDataSetChanged();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                    } else {
                    }
                }
            } else*/
            if (requestCode == ProfileImageSelectionUtil.OPENCAMERA) {
                if (resultCode == RESULT_OK) {
                    Uri uriStr = (Uri) data.getExtras().get("data");
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uriStr);
                    if (bitmap != null) {
                        setImgPathCorrect(bitmap, uriStr);
                    }
                } else if (resultCode == RESULT_CANCELED) {
                    Toast.makeText(getApplicationContext(), "User cancelled image capture", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Sorry! Failed to capture image", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == Permissions.PERMISSIONS_REQUEST) {
                if (resultCode == RESULT_OK)
                    openCam();
                else
                    finish(); // need to test this specially
            } else if (requestCode == REQUEST_CODE_FOR_SEARCH_ACTIVITY) {
                if (resultCode == RESULT_OK) {
                    IdNameModel dto = (IdNameModel) data.getExtras().getSerializable(SearchActivity.RESULT_DATA);
                    diseaseClassifictaionEt.setText(dto.getName());
                    diseaseClassifictaionEt.setTag(dto.getId());
                    selectedDiseaseId = dto.getId();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setImgPathCorrect(Bitmap image, Uri uriStr) {
        if (image != null) {
            imageBitmap = image;
            imgPath = uriStr.toString().substring(7);
            CapturedImagePath = null;
            CapturedImagePath = imgPath;
            list.add(imgPath);
            listAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        switch (view.getId()) {
//            case R.id.list_imageView:
            case R.id.img_list_parent:
                String imagePath = (String) view.getTag();
                ImageViewer(thisActivity, imagePath);
                break;
            case R.id.list_cancel_btn:
                String imagePathToDelete = (String) view.getTag();
                list.remove(imagePathToDelete);
                listAdapter.notifyDataSetChanged();
                // delete image here form list and update recycler view
                break;
        }
    }

    private boolean checkValidations() {

        if (cropSpn.getSelectedItemPosition() == 0) {
            DialogManager.showToast(thisActivity, getString(R.string.crp));
            return false;
        } else if (getString(R.string.select).equalsIgnoreCase(diseaseClassifictaionEt.getText().toString())) {
            DialogManager.showToast(thisActivity, getString(R.string.disease_classification_error));
            return false;
        } else if (list.size() == 0) {
            DialogManager.showToast(thisActivity, getString(R.string.add_image_error));
            return false;
        }

        /*if (!Utils.isValidStr(latLongValues)){
            checkForLocation = false;
            getMyCurrentLocation(thisActivity);
            DialogManager.showToast(thisActivity, getString(R.string.gps));
            return false;
        }*/
        return true;
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null) {
            if (responseObj instanceof CropDiagnosisMasterResponse) {
                CropDiagnosisMasterResponse commonResEntity = (CropDiagnosisMasterResponse) responseObj;
                if (AppConstants.STATUS_CODE.equals(commonResEntity.getStatusCode())) {
                    String resJson = Utils.getJWTResponseFC(commonResEntity.getResponse(), thisActivity);
                    CropDiagnosisMasterResponse response = new Gson().fromJson(resJson, CropDiagnosisMasterResponse.class);
                    ArrayList<IdServerIdModel> idsList = response.getIdsList();
                    if (idsList != null) {
                        for (IdServerIdModel list : idsList) {
                            CropDiagnosisMasterDataUploadDTO updateDto = new CropDiagnosisMasterDataUploadDTO();
                            updateDto.setServerId(list.getServerId());
                            updateDto.setId(list.getId());
                            updateDto.setStatus(1);
                            CropDiagnosisMasterDataUploadDAO.getInstance().updateRecordById(updateDto, DBHandler.getWritableDb(thisActivity));
                            CropDiagnosisMasterDataUploadDTO record = CropDiagnosisMasterDataUploadDAO.getInstance().getRecordByIdSingleRecord(list.getId(), DBHandler.getReadableDb(thisActivity));
                            String[] imagePaths = record.getImageUrls().split(",");
                            for (String imagePath : imagePaths) {
                                // insert data into uploading table
                                UploadImagesDTO dto = new UploadImagesDTO();
                                dto.setImagePath(imagePath);
                                dto.setServerId(list.getServerId());
                                UpLoadImagesDAO.getInstance().insert(dto, DBHandler.getWritableDb(thisActivity));
                            }
                        }
                        startUploadService();
                    }

                    clearFileds();
                    DialogManager.showSingleBtnPopup(thisActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick(View v) {
                            finish();
                        }
                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.alert), getString(R.string.dat_captured_send_to_server), getString(R.string.ok));
                } else if (AppConstants.SOMETHING_WENT_WRONG.equals(commonResEntity.getStatusCode())) {
                    DialogManager.showToast(thisActivity, commonResEntity.getMessage());
                } else {
                    DialogManager.showToast(thisActivity, commonResEntity.getMessage());
                }
            } else if (responseObj instanceof CDMasterDataDownloadResponse) {
                CDMasterDataDownloadResponse response = (CDMasterDataDownloadResponse) responseObj;
                if (AppConstants.STATUS_CODE.equals(response.getStatusCode())) {
                    String resJson = Utils.getJWTResponseFC(response.getResponse(), thisActivity);
                    CDMasterDataDownloadResponse responseMain = new Gson().fromJson(resJson, CDMasterDataDownloadResponse.class);
                    if (responseMain.getCropsList() != null && responseMain.getCropsList().size() > 0) {
                        CropDiagnosisCropMasterDAO.getInstance().deleteTableData(DBHandler.getWritableDb(thisActivity));
                        for (IdNameModel model : responseMain.getCropsList())
                            CropDiagnosisCropMasterDAO.getInstance().insert(model, DBHandler.getWritableDb(thisActivity));
                    }
                    if (responseMain.getDiseaseClassification() != null && responseMain.getDiseaseClassification().size() > 0) {
                        DiseaseMasterDataDAO.getInstance().deleteTableData(DBHandler.getWritableDb(thisActivity));
                        for (DiseaseMasterModel disModel : responseMain.getDiseaseClassification())
                            DiseaseMasterDataDAO.getInstance().insert(disModel, DBHandler.getWritableDb(thisActivity));
                    }
                    setMasterData();

                } else {
                    DialogManager.showToast(thisActivity, response.getMessage());
                }
            }
        }
    }

    @Override
    public void onRequestFailure(RetrofitError errorCode, String errorFrom) {
//        super.onRequestFailure(errorCode, errorFrom);
        DialogManager.showSingleBtnPopup(thisActivity, new DialogMangerCallback() {
            @Override
            public void onOkClick(View v) {
                clearFileds();
                finish();
            }
            @Override
            public void onCancelClick(View view) {

            }
        }, getString(R.string.alert), getString(R.string.dat_captured_connect_to_server), getString(R.string.ok));
    }

    private void startUploadService() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            if (!Utils.isMyServiceRunning(thisActivity, "com.pioneer.emp.services.CdMasterUpLoadFileServiceNewJob")) {


                Intent intent = new Intent(this, CdMasterUpLoadFileServiceNewJob.class);
                CdMasterUpLoadFileServiceNewJob.enqueueWork(this, intent);
            }
        }
        else {
            if (!Utils.isMyServiceRunning(thisActivity, "com.pioneer.emp.services.CdMasterUpLoadFileService")) {
                Intent intent = new Intent(this, CdMasterUpLoadFileService.class);
                startService(intent);
            }
        }
    }

    private void setMasterData() {
        cropList.clear();
        cropList.add(new IdNameModel(-1, getString(R.string.select)));
        cropList.addAll(CropDiagnosisCropMasterDAO.getInstance().getALLRecords(DBHandler.getReadableDb(thisActivity)));
        cropAdapter.notifyDataSetChanged();

        diseaseList.clear();
        diseaseList.addAll(DiseaseMasterDataDAO.getInstance().getALLRecords(DBHandler.getReadableDb(thisActivity)));
        for (DiseaseMasterModel list : diseaseList) {
            IdNameModel model = new IdNameModel();
            model.setId(list.getId());
            model.setName(list.getDiseaseName());
            diseaseListIdNameModel.add(model);
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.cdmdc_spnCrop:
                diseaseClassifictaionEt.setText(getString(R.string.select));
                diseaseClassifictaionEt.setTag(-1);
                selectedDiseaseId = -1;
                selectedCropPosition = position;
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private boolean isDataAvailable() {

        if (cropSpn.getSelectedItemPosition() > 0)
            return true;
        if (!getString(R.string.select).equalsIgnoreCase(diseaseClassifictaionEt.getText().toString().trim()))
            return true;
        if (Utils.isValidStr(tagEt.getText().toString().trim()))
            return true;
        return list.size() > 0;

    }

    private boolean checkLocPermission() {

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return ActivityCompat.checkSelfPermission(thisActivity, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return true;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        geoLocation = null;
        if (geoLocation == null) {
            if (checkLocPermission())
                getMyCurrentLocation(thisActivity);
            else
                showDialogToOpenSetting();
        }

    }

    protected void getMyCurrentLocation(final Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (mGoogleApiClient != null) {
                if (mGoogleApiClient.isConnected()) {
                    mGoogleApiClient.disconnect();
                }
                mGoogleApiClient.connect();
            }
           new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

                @Override
                public void onTick(long millisUntilFinished) {
                    if (geoLocation != null) {
                        latLongValues = geoLocation;
                        hideProgressDialog();

                        this.cancel();
                    }
                }

                @Override
                public void onFinish() {
                    hideProgressDialog();
                    checkForLocation = false;
                    DialogManager.showToast(thisActivity, "Got the location, now tap on submit");
                    this.cancel();
                }
            }.start();
        } else {
            DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.gps), getString(R.string.ok));
        }
    }

    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(thisActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied location permission with never show option\nPlease enable permissions manually, tap on permissions then enable the location permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(thisActivity, getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {
        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_upload, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.action_upload:
                Intent gotopendingList = new Intent(thisActivity, CDMasterUploadPending.class);
                startActivity(gotopendingList);
                break;
        }
        return false;
    }
}
