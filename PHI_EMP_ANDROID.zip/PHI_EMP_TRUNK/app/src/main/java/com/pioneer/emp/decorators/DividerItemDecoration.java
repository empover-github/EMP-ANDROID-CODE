package com.pioneer.emp.decorators;

import android.graphics.Rect;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * Created by Swamy on 12/09/16.
 */
public class DividerItemDecoration extends RecyclerView.ItemDecoration {
    private final int mVerticalSpaceHeight;
    public DividerItemDecoration(int mVerticalSpaceHeight){
        this.mVerticalSpaceHeight = mVerticalSpaceHeight;
    }
    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        outRect.bottom = mVerticalSpaceHeight;

        //super.getItemOffsets(outRect, view, parent, state);
    }
}
