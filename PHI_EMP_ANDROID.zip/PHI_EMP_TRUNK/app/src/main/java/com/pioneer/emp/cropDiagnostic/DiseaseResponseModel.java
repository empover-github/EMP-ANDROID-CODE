package com.pioneer.emp.cropDiagnostic;

import com.pioneer.emp.dto.AgroDiseaseProductMappingDTO;
import com.pioneer.emp.dto.DiseasePrescriptionDTO;
import com.pioneer.emp.models.CommonResponseEntity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by hareesh.a on 12/18/2017.
 */

public class DiseaseResponseModel extends CommonResponseEntity implements Serializable {

    private ArrayList<DiseasePrescriptionDTO> diseasePrescriptions;
    private ArrayList<AgroDiseaseProductMappingDTO> agroProductMasters;
    private String lastSyncedOn;

    public ArrayList<DiseasePrescriptionDTO> getDiseasePrescriptions() {
        return diseasePrescriptions;
    }

    public void setDiseasePrescriptions(ArrayList<DiseasePrescriptionDTO> diseasePrescriptions) {
        this.diseasePrescriptions = diseasePrescriptions;
    }

    public ArrayList<AgroDiseaseProductMappingDTO> getAgroProductMasters() {
        return agroProductMasters;
    }

    public void setAgroProductMasters(ArrayList<AgroDiseaseProductMappingDTO> agroProductMasters) {
        this.agroProductMasters = agroProductMasters;
    }

    public String getLastSyncedOn() {
        return lastSyncedOn;
    }

    public void setLastSyncedOn(String lastSyncedOn) {
        this.lastSyncedOn = lastSyncedOn;
    }
}
