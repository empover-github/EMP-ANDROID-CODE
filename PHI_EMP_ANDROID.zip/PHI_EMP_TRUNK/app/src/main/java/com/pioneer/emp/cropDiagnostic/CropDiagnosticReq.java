package com.pioneer.emp.cropDiagnostic;

/**
 * Created by Yakaswamy.g on 8/14/2017.
 */

public class CropDiagnosticReq {
    private String uploadImageByteString;
    private String crop;
    private String customerId;
    private String deviceId;
    private String mobileNumber;
    private String customerType;
    private String coordinatePoints;
    private String deviceType;

    public String getCoordinatePoints() {
        return coordinatePoints;
    }

    public void setCoordinatePoints(String coordinatePoints) {
        this.coordinatePoints = coordinatePoints;
    }

    public String getUploadImageByteString() {
        return uploadImageByteString;
    }

    public void setUploadImageByteString(String uploadImageByteString) {
        this.uploadImageByteString = uploadImageByteString;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }
}
