package com.pioneer.emp.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.parivaar.activities.BaseActivity;
import com.pioneer.parivaar.model.IdNameModel;

import java.util.ArrayList;

/**
 * Created by Yakaswamy.g on 5/1/2018.
 */

public class SpinnerCustomAdapter extends ArrayAdapter<String> {

    private Activity activity;
    private ArrayList data;
    public Resources res;
    IdNameModel tempValues = null;
    LayoutInflater inflater;

    public SpinnerCustomAdapter(BaseActivity activitySpinner, int textViewResourceId, ArrayList objects, Resources resLocal) {
        super(activitySpinner, textViewResourceId, objects);

        activity = activitySpinner;
        data = objects;
        res = resLocal;

        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    public View getCustomView(int position, View convertView, ViewGroup parent) {
        View row = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, parent, false);
        tempValues = null;
        tempValues = (IdNameModel) data.get(position);
        TextView label = row.findViewById(R.id.textView1);
        label.setText(tempValues.getName());
        return row;
    }
}
