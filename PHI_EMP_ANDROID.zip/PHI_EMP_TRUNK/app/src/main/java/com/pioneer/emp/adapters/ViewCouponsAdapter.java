package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pioneer.emp.dto.ViewCouponsDTO;
import com.pioneer.emp.R;

import java.util.ArrayList;

/**
 * Created by hareesh.a on 7/12/2017.
 */

public class ViewCouponsAdapter extends RecyclerView.Adapter<ViewCouponsAdapter.MHolder> {
    Context context;
    ArrayList<ViewCouponsDTO> viewCouponsDTOArrayList;

    public ViewCouponsAdapter(Context context, ArrayList<ViewCouponsDTO> viewCouponsDTOArrayList) {
        this.context = context;
        this.viewCouponsDTOArrayList = viewCouponsDTOArrayList;
    }

    @Override
    public MHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.emp_view_coupons_list_recycle, parent, false);
        return new MHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MHolder holder, int position) {
        holder.bind(viewCouponsDTOArrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return viewCouponsDTOArrayList.size();
    }


    public class MHolder extends RecyclerView.ViewHolder {
        TextView coupon_crop, couponNo,valid_till;

        public MHolder(View view) {
            super(view);

            coupon_crop = view.findViewById(R.id.vc_coupon_crop);
            couponNo = view.findViewById(R.id.vc_coupon_no);
            valid_till = view.findViewById(R.id.vc_valid_till);
        }

        public void bind(final ViewCouponsDTO viewCouponsDTO) {

            coupon_crop.setText(viewCouponsDTO.getCrop() + " " + "-" + " " + viewCouponsDTO.getSeason() + " " + "-" + " " + viewCouponsDTO.getYear());
            couponNo.setText(viewCouponsDTO.getCouponNumber());
            valid_till.setText(viewCouponsDTO.getValidTill());
        }


    }
}
