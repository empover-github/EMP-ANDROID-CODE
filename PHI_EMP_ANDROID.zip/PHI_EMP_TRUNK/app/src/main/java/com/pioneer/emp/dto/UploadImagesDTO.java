package com.pioneer.emp.dto;

import com.pioneer.parivaar.dto.DTO;

import java.io.Serializable;

public class UploadImagesDTO implements DTO, Serializable{
    private long imageId;
    private String imagePath;
    private long serverId;
    private String moduleType;

    public long getImageId() {
        return imageId;
    }

    public void setImageId(long imageId) {
        this.imageId = imageId;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public long getServerId() {
        return serverId;
    }

    public void setServerId(long serverId) {
        this.serverId = serverId;
    }

    public String getModuleType() {
        return moduleType;
    }

    public void setModuleType(String moduleType) {
        this.moduleType = moduleType;
    }
}
