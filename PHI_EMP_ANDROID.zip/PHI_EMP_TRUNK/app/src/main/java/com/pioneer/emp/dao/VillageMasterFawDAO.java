package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.VillageFawModel;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

public class VillageMasterFawDAO implements DAO {
    private final String TAG = "VillageMasterFaw";
    private static VillageMasterFawDAO villageMasterFawDAO;

    public static VillageMasterFawDAO getInstance() {
        if (villageMasterFawDAO == null) {
            villageMasterFawDAO = new VillageMasterFawDAO();
        }
        return villageMasterFawDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            VillageFawModel dto = (VillageFawModel) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("id", dto.getId());
            cv.put("name", dto.getName());
            cv.put("pincode", dto.getPincode());

            long rowsEffected = dbObject.insert(DBHandler.TABLE_VILAGE_MASTER, null, cv);
            if (rowsEffected > 0)
                return "";
        } catch (SQLException e) {
            e.printStackTrace();
            BuildLog.e(TAG, "insert" + e.getMessage());
            return "";
        } finally {
            dbObject.close();
        }
        return "";
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> villageData = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_VILAGE_MASTER, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    VillageFawModel dto = new VillageFawModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));

                    villageData.add(dto);
                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return villageData;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_VILAGE_MASTER).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }

        return false;
    }

    public ArrayList<VillageFawModel> getRecordByPinCode(String pincode, SQLiteDatabase dbObject) {
        ArrayList<VillageFawModel> villageData = new ArrayList<>();
        VillageFawModel dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("Select * from " + DBHandler.TABLE_VILAGE_MASTER + " WHERE pincode = '" + pincode + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new VillageFawModel();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    villageData.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return villageData;
    }
    public int isDataAvailable(SQLiteDatabase dbObject) {

        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM "+DBHandler.TABLE_VILAGE_MASTER, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            BuildLog.e(TAG, e.getMessage());
            return 0;
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return 0;
    }
}
