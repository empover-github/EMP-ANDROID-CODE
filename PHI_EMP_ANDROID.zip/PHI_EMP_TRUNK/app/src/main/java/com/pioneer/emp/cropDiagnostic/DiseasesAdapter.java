package com.pioneer.emp.cropDiagnostic;

import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pioneer.emp.R;
import com.pioneer.emp.customviews.RoundedCornersTransfGlide;
import com.pioneer.parivaar.utils.AppConstants;
import com.pioneer.parivaar.utils.DialogManager;
import com.pioneer.parivaar.utils.Utils;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Created by hareesh.a on 5/5/2017.
 */

public class DiseasesAdapter extends RecyclerView.Adapter<DiseasesAdapter.MyNotifiHolder> {
    private String crop;
    private Context context;
    private ArrayList<CropDiseaseModel> diseasesList;

    public DiseasesAdapter(Context context, ArrayList<CropDiseaseModel> categoryDTOArrayList, String crop) {
        this.context = context;
        this.diseasesList = categoryDTOArrayList;
        this.crop = crop;
    }

    @Override
    public MyNotifiHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.disease_recycle_item,parent,false);
        return new MyNotifiHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MyNotifiHolder holder, int position) {
        holder.bind(diseasesList.get(position));
    }

    @Override
    public int getItemCount() {
        return diseasesList.size();
    }

    public class MyNotifiHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView diseaseName, diseaseDesc, diseasePercentage;
        LinearLayout diseasePercentLayout;
        ImageView diseaseImage;
        RelativeLayout diseaseItem;
        public MyNotifiHolder(View view) {
            super(view);

            diseaseName = view.findViewById(R.id.diseaseName);
            diseaseDesc = view.findViewById(R.id.diseaseDescription);
            diseasePercentage = view.findViewById(R.id.diseasePercentage);
            diseaseImage = view.findViewById(R.id.diseaseImg);
            diseaseItem = view.findViewById(R.id.diseaseItem);
            diseasePercentLayout = view.findViewById(R.id.diseasePercentageLayout);
            diseaseItem.setOnClickListener(this);
        }

        public void bind(final CropDiseaseModel diseaseModel ) {
            diseaseName.setText(diseaseModel.getDiseaseName());
            diseaseDesc.setText(diseaseModel.getDiseaseScientificName());
            if(diseaseModel.getProbability() >  0){
                diseasePercentage.setText((new DecimalFormat("##").format(Float.valueOf(diseaseModel.getProbability() * 100)))+"%");
                diseasePercentLayout.setVisibility(View.VISIBLE);
            } else {
                diseasePercentLayout.setVisibility(View.GONE);
            }
            diseaseItem.setTag(diseaseModel);
            Glide.with(context)
                    .load(AppConstants.CD_BASE_URL+diseaseModel.getImagePath())
                    .error(R.mipmap.image_not_exist).transform(new RoundedCornersTransfGlide(context, AppConstants.IMAGE_CORNER_RADIOS, AppConstants.IMAGE_MARGIN))
                    .placeholder(R.mipmap.image_placeholder)
                    .dontAnimate().into(diseaseImage);
        }

        @Override
        public void onClick(View v) {
            Utils.setCDAdapter(AppConstants.DiseasesAdapter,context);
            CropDiseaseModel dto = (CropDiseaseModel) v.getTag();
            if (Utils.isNetworkConnection(context)){
                Intent intent=new Intent(context, CDHazardDetailsActivity.class);
                intent.putExtra("disease",dto);
                context.startActivity(intent);
            }else{
                DialogManager.showToast(context, context.getString(R.string.no_internet));
            }
        }
    }

}
