package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.models.DailyLiquidationDownloadDTO;
import com.pioneer.parivaar.utils.Utils;

import java.util.ArrayList;


public class DailyLiquidationAdapter extends RecyclerView.Adapter<DailyLiquidationAdapter.DailyLiquidation> {
    private Context context;
    private ArrayList<DailyLiquidationDownloadDTO> liquidationDailyList;
    private OnBookletClickListener listener;

    public DailyLiquidationAdapter(Context mContext, ArrayList<DailyLiquidationDownloadDTO> dailyDetails, OnBookletClickListener mListener) {
        this.context = mContext;
        this.liquidationDailyList = dailyDetails;
        this.listener = mListener;

    }


    @Override
    public DailyLiquidation onCreateViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.daily_liquidation_list_item, parent, false);
        DailyLiquidation myHolder = new DailyLiquidation(layout);
        return myHolder;

    }

    @Override
    public void onBindViewHolder(DailyLiquidationAdapter.DailyLiquidation holder, int position) {

        holder.bind(liquidationDailyList.get(position), position);

    }

    @Override
    public int getItemCount() {
        return liquidationDailyList.size();
    }

    public class DailyLiquidation extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvSeasonName, tvDate;
        LinearLayout mainLayout;

        DailyLiquidation(View itemView) {
            super(itemView);

            tvSeasonName = itemView.findViewById(R.id.list_tv_season);
            tvDate = itemView.findViewById(R.id.list_tv_date);
            mainLayout = itemView.findViewById(R.id.mainlayout_liquidation);
            mainLayout.setOnClickListener(this);

        }

        void bind(final DailyLiquidationDownloadDTO liquidationDailyDetails, int position) {
            if (liquidationDailyDetails != null) {
                String seasonName = liquidationDailyDetails.getYear() + " - " + liquidationDailyDetails.getSeasonName() + " - " + liquidationDailyDetails.getCropName();
                tvSeasonName.setText(seasonName);
                String date = Utils.formatDateToUser(liquidationDailyDetails.getStartDate()) + " to " + Utils.formatDateToUser(liquidationDailyDetails.getEndDate());

                tvDate.setText("Season Window: " + date);

            }

            if (position % 2 == 1) {
                mainLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.liquidation_yellow));
            } else {
                mainLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.liquidation_blue));
            }
            if (liquidationDailyDetails.isStatus()) {
            } else {
                mainLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.status_inactive));
            }
            mainLayout.setTag(liquidationDailyDetails);
        }

        @Override
        public void onClick(View v) {
            // int position = (int) v.getTag();
            listener.onItemClick(v, getAdapterPosition());
        }

    }

}
