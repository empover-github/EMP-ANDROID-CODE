package com.pioneer.emp.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.dto.MdrEvaluationReportDTO;
import com.pioneer.emp.listeners.OnBookletClickListener;
import com.pioneer.emp.mdrEvaluation.MdrReportsActivity;

import java.util.ArrayList;

/**
 * Created by fatima.t on 08-11-2018.
 */

public class MdrEvaluationReportAdapter extends RecyclerView.Adapter<MdrEvaluationReportAdapter.MdrEvaluationHolder> {
    Context context;
    ArrayList<MdrEvaluationReportDTO> arrayList;
    private OnBookletClickListener listener;

    public MdrEvaluationReportAdapter(Context context, ArrayList<MdrEvaluationReportDTO> profilesList, OnBookletClickListener listener) {
        this.context = context;
        this.arrayList = profilesList;
        this.listener = listener;
    }

    @Override
    public MdrEvaluationHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.mdr_evaluation_report_list_item,parent,false);
        return new MdrEvaluationHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MdrEvaluationHolder holder, int position) {
        holder.bind(arrayList.get(position), position);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class MdrEvaluationHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvArea, tvPendingCount, tvEvaluatedCount, tvAverageScore;
        View tvView;
        public MdrEvaluationHolder(View view) {
            super(view);
            tvArea = (TextView) view.findViewById(R.id.mdrr_li_area);
            tvPendingCount = (TextView) view.findViewById(R.id.mdrr_li_pendingCount);
            tvEvaluatedCount = (TextView) view.findViewById(R.id.mdrr_li_evaluatedCount);
            tvAverageScore = (TextView) view.findViewById(R.id.mdrr_li_averageScore);
            tvView = view.findViewById(R.id.mdrr_bottom_tv_line);

            tvAverageScore.setOnClickListener(this);
            tvArea.setOnClickListener(this);

        }

        public void bind(final MdrEvaluationReportDTO listModel, int position) {

            if (MdrReportsActivity.isTerritorySelected){

                switch (listModel.getNineBoxScore()) {
                    case "1":
                    case "2":
                    case "3":
                        tvEvaluatedCount.setTextColor(context.getResources().getColor(R.color.white));
                        tvEvaluatedCount.setBackgroundColor(context.getResources().getColor(R.color.red));
                        break;
                    case "4":
                    case "5":
                    case "6":
                        tvEvaluatedCount.setTextColor(context.getResources().getColor(R.color.black));
                        tvEvaluatedCount.setBackgroundColor(context.getResources().getColor(R.color.yellow));
                        break;
                    case "7":
                    case "8":
                    case "9":
                        tvEvaluatedCount.setTextColor(context.getResources().getColor(R.color.white));
                        tvEvaluatedCount.setBackgroundColor(context.getResources().getColor(R.color.app_color));
                        break;
                    default:
                        tvEvaluatedCount.setTextColor(context.getResources().getColor(R.color.black));
                        tvEvaluatedCount.setBackgroundColor(context.getResources().getColor(R.color.white));
                        break;
                }

                tvArea.setText(listModel.getMdrEmployeeId());
                tvPendingCount.setText(listModel.getName());
                tvEvaluatedCount.setText(listModel.getNineBoxScore());
                tvAverageScore.setText(listModel.getStatus());
            } else {

                switch (listModel.getAverageScore()) {
                    case "1":
                    case "2":
                    case "3":
                        tvAverageScore.setTextColor(context.getResources().getColor(R.color.white));
                        tvAverageScore.setBackgroundColor(context.getResources().getColor(R.color.red));
                        break;
                    case "4":
                    case "5":
                    case "6":
                        tvAverageScore.setTextColor(context.getResources().getColor(R.color.black));
                        tvAverageScore.setBackgroundColor(context.getResources().getColor(R.color.yellow));
                        break;
                    case "7":
                    case "8":
                    case "9":
                        tvAverageScore.setTextColor(context.getResources().getColor(R.color.white));
                        tvAverageScore.setBackgroundColor(context.getResources().getColor(R.color.app_color));
                        break;
                    default:
                        tvAverageScore.setTextColor(context.getResources().getColor(R.color.black));
                        tvAverageScore.setBackgroundColor(context.getResources().getColor(R.color.white));
                        break;
                }
               // tvArea.setText(listModel.getName());
                SpannableString content = new SpannableString(listModel.getName());
                content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
                tvArea.setText(content);

                tvPendingCount.setText(listModel.getPendingCount());
                tvEvaluatedCount.setText(listModel.getEvaluatedCount());
                tvAverageScore.setText(listModel.getAverageScore());
                tvAverageScore.setTag(listModel);
                tvArea.setTag(listModel);
            }

            // Common
            if (position == arrayList.size()-1) {
                tvView.setVisibility(View.GONE);
            }
            else {
                tvView.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onClick(View v) {
            listener.onItemClick(v, getAdapterPosition());
        }
    }
}
