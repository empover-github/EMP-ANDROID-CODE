package com.pioneer.emp.fab.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.fab.models.HybridMasterEntity;

import java.util.ArrayList;

/**
 * Created by fatima.t on 08-05-2017.
 */

public class HybridAdapter extends BaseAdapter{
    ArrayList<HybridMasterEntity> allHybridList;
    LayoutInflater inflter;
    Context context;

    public HybridAdapter(/*FABMainActivity mActivity*/ Context context, ArrayList<HybridMasterEntity> allHybrids) {
        this.context = context;
        inflter = (LayoutInflater.from(context));
        this.allHybridList = allHybrids;

    }

    @Override
    public int getCount() {
        return allHybridList.size();
    }

    @Override
    public Object getItem(int position) {
        return allHybridList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        convertView =  inflter.inflate(R.layout.emp_fab_custom_spinner_items, null);
        TextView stateText = convertView.findViewById(R.id.spinner_textView);

        if (allHybridList.size() <= 0){
            stateText.setText(" No Hybrids for Above Selected Crop");
        }
        else {
            stateText.setText(allHybridList.get(position).getName());
        }
        return convertView;
    }
}
