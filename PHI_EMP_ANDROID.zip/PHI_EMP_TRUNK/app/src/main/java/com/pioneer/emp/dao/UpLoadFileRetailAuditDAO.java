package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import com.activitytrack.utility.ATBuildLog;
import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.UpLoadRetailAuditFileDTO;
import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rambabu.a on 09-03-2018.
 */

public class UpLoadFileRetailAuditDAO implements DAO {
    private final String TAG = "RetailAuditActivity";

    private static UpLoadFileRetailAuditDAO upLoadFileRetailAuditDAO;

    public static UpLoadFileRetailAuditDAO getInstance() {
        if (upLoadFileRetailAuditDAO == null) {
            upLoadFileRetailAuditDAO = new UpLoadFileRetailAuditDAO();
        }
        return upLoadFileRetailAuditDAO;
    }


    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {


        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        try
        {
            UpLoadRetailAuditFileDTO dto = (UpLoadRetailAuditFileDTO) dtoObject;
            dbObject.execSQL("delete from UPLOAD_FILE_RETAIL_AUDIT where userServerId='"+dto.getServerId()+"'");
            return true;
        }catch(Exception e)
        {
            ATBuildLog.e(TAG +"delete",e.getMessage());
        }finally
        {
            dbObject.close();

        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public boolean deleteDataById(long id, SQLiteDatabase dbObject) {
        try
        {
            dbObject.execSQL("delete from UPLOAD_FILE_RETAIL_AUDIT where id='"+id+"'");
            return true;
        }catch(Exception e)
        {
            ATBuildLog.e(TAG +"delete",e.getMessage());
        }finally
        {
            dbObject.close();

        }
        return false;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try
        {
            UpLoadRetailAuditFileDTO dto = (UpLoadRetailAuditFileDTO) dtoObject;

            /*id
            url
            userType
            userMobileId
            userServerId*/

            ContentValues cValues = new ContentValues();
//            cValues.put("id", dto.getId());
            cValues.put("url", dto.getImageUrlPath());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("userServerId", dto.getServerId());

            dbObject.insert("UPLOAD_FILE_RETAIL_AUDIT", null, cValues);
            return "";
        } catch (SQLException e)
        {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return "";
        } finally
        {
            dbObject.close();
        }
    }

    public List<UpLoadRetailAuditFileDTO> getRecordsToUpload(SQLiteDatabase dbObject, Context context) {
        Cursor cursor = null;
        List<UpLoadRetailAuditFileDTO> list = new ArrayList<UpLoadRetailAuditFileDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM UPLOAD_FILE_RETAIL_AUDIT WHERE isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                UpLoadRetailAuditFileDTO dto;
                do {
                    dto = new UpLoadRetailAuditFileDTO();
                    dto.setImageUrlPath(cursor.getString(cursor.getColumnIndex("url")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setServerId(cursor.getLong(cursor.getColumnIndex("userServerId")));
                    list.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return list;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM UPLOAD_FILE_RETAIL_AUDIT").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }
}
