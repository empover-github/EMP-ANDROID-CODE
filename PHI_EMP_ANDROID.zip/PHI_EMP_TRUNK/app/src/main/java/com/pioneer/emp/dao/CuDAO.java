package com.pioneer.emp.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;
import com.pioneer.parivaar.model.IdNameModel;
import com.pioneer.parivaar.utils.BuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by swamy on 10-03-2018.
 */

public class CuDAO implements DAO {

    private final String TAG = "CuDAO";
    private static CuDAO CuDAO;

    public static CuDAO getInstance() {
        if (CuDAO == null) {
            CuDAO = new CuDAO();
        }

        return CuDAO;
    }

    @Override
    public String insert(DTO dtoMain, SQLiteDatabase dbObject) {
        IdNameModel dto = (IdNameModel) dtoMain;
        try {
            ContentValues cValues = new ContentValues();
            cValues.put("id", dto.getId());
            cValues.put("name", dto.getName());
            dbObject.insert("MASTER_CU", null, cValues);
            return "";
        }catch(SQLException e) {
            BuildLog.e(TAG + "insert()", e.getMessage());
            return null;
        } finally {
            dbObject.close();
        }
    }

    public void insertOrUpdate(DTO dtoMain, SQLiteDatabase dbObject) {
        IdNameModel dto = (IdNameModel) dtoMain;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT id FROM MASTER_CU where id='"+dto.getId()+"'", null);
            if (cursor.getCount() > 0) {
                update(dto, dbObject);
            }else{
                insert(dto, dbObject);
            }
        }catch (SQLiteException e){
            dbObject.close();
        }finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
    }

    @Override
    public boolean update(DTO dtoMain, SQLiteDatabase dbObject) {
        try {
            IdNameModel dto = (IdNameModel) dtoMain;
            ContentValues cValues = new ContentValues();

            if (dto.getId() != 0)
                cValues.put("id", dto.getId());

            if (dto.getName() != null)
                cValues.put("name", dto.getName ());
            else
                cValues.putNull("name");

            dbObject.update("MASTER_CU", cValues, "id = '"+dto.getId()+"'", null);

        } catch (SQLException e) {
            BuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoMain, SQLiteDatabase dbObject) {
        IdNameModel dto = (IdNameModel) dtoMain;
        try {
            dbObject.compileStatement("DELETE FROM MASTER_CU WHERE id = '"+dto.getId()+"'").execute();
            return true;
        } catch (Exception e) {
            BuildLog.e(TAG + "delete()", e.getMessage());
        }finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }

    public ArrayList getRecordsByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {

        if(columnValue == null || columnValue.isEmpty())
            return null;
        ArrayList<IdNameModel> info = new ArrayList<>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            String sql = "SELECT * FROM MASTER_CU where "+columnName+"='"+columnValue+"'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                IdNameModel dto;
                do {
                    dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));

                    info.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return info;
    }

    public  IdNameModel getRecordsById(long id, SQLiteDatabase dbObject) {
        IdNameModel dto = null;

        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_CU where id='"+id+"'";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));

                    return dto;
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return dto;
    }

    public  List<IdNameModel> getAllRecords(SQLiteDatabase dbObject) {
        List<IdNameModel> list = new ArrayList<>();
        Cursor cursor = null;
        try {
            String sql = "SELECT * FROM MASTER_CU";

            cursor = dbObject.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    IdNameModel dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));

                    list.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();

        }

        return list;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM MASTER_CU").execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

}
