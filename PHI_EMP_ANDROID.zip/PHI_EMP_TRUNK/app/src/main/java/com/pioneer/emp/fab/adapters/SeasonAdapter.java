package com.pioneer.emp.fab.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.pioneer.emp.R;
import com.pioneer.emp.fab.models.SeasonMasterEntity;

import java.util.ArrayList;

/**
 * Created by fatima.t on 08-05-2017.
 */

public class SeasonAdapter extends BaseAdapter{
    ArrayList<SeasonMasterEntity> allSeasonList;
    LayoutInflater inflter;
    Context context;

    public SeasonAdapter(/*FABMainActivity mActivity*/ Context context, ArrayList<SeasonMasterEntity> allSeasons) {
        this.context = context;
        inflter = (LayoutInflater.from(context));
        this.allSeasonList = allSeasons;

    }

    @Override
    public int getCount() {
        return allSeasonList.size();
    }

    @Override
    public Object getItem(int position) {
        return allSeasonList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


//        View view = convertView;
        convertView =  inflter.inflate(R.layout.emp_fab_custom_spinner_items, null);
        TextView stateText = convertView.findViewById(R.id.spinner_textView);

        stateText.setText(allSeasonList.get(position).getName());

        /*LayoutInflater mInflater = (LayoutInflater) getContext().getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        view = mInflater.inflate(R.layout.list_view_items, null);*/
        return convertView;
    }
}
