package com.pioneer.emp.custommap;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.FrameLayout;

/**
 * Created by Fatima on 09-01-2018.
 */
public class CustomMapWrapperLayout extends FrameLayout {

    public interface OnDragListener {
        void onDrag(MotionEvent motionEvent);
    }
    public interface OnMapActionDown {
        void onMapDown(MotionEvent motionEvent);
    }
    public interface OnMapActionUp {
        void onMapUp(MotionEvent motionEvent);
    }


    private OnDragListener mOnDragListener;
    private OnMapActionDown mOnMapActionDownListener;
    private OnMapActionUp mOnMapActionUpListener;



    public CustomMapWrapperLayout(Context context) {
        super(context);
    }
    private int counter = 0;
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int action = ev.getAction() & MotionEvent.ACTION_MASK;
        if (mOnDragListener != null && action == MotionEvent.ACTION_MOVE){
//        if (mOnDragListener != null && ev.getAction() == MotionEvent.ACTION_MOVE ) {
            counter++;
            if(counter > 10)
                mOnDragListener.onDrag(ev);
        }
        if (mOnMapActionDownListener != null && ev.getAction()== MotionEvent.ACTION_DOWN) {
            mOnMapActionDownListener.onMapDown(ev);
            counter = 0;
        }
        if (mOnMapActionUpListener != null && ev.getAction()== MotionEvent.ACTION_UP) {
            if(counter > 10)
                mOnMapActionUpListener.onMapUp(ev);
            counter = 0;
        }

        return super.dispatchTouchEvent(ev);
    }

    public void setOnDragListener(OnDragListener mOnDragListener) {
        this.mOnDragListener = mOnDragListener;
    }

    public void setmOnMapActionUpListener(OnMapActionUp mOnMapActionUpListener) {
        this.mOnMapActionUpListener = mOnMapActionUpListener;
    }
    public void setmOnMapActionDownListener(OnMapActionDown mOnMapActionDownListener) {
        this.mOnMapActionDownListener = mOnMapActionDownListener;
    }

}