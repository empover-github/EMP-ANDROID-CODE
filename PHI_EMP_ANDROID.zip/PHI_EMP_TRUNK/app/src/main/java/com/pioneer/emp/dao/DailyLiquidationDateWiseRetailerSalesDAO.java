package com.pioneer.emp.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.pioneer.emp.dbHandler.DBHandler;
import com.pioneer.emp.dto.DailyLiquidationDateWiseRetailerDTO;

import com.pioneer.parivaar.dao.DAO;
import com.pioneer.parivaar.dto.DTO;

import java.util.ArrayList;
import java.util.List;

public class DailyLiquidationDateWiseRetailerSalesDAO implements DAO {
    private final String TAG = "DailyLiquidationDateWiseRetailerSalesDAO";
    private static DailyLiquidationDateWiseRetailerSalesDAO dailyLiquidationDateWiseRetailerSalesDAO;

    public static DailyLiquidationDateWiseRetailerSalesDAO getInstance() {
        if (dailyLiquidationDateWiseRetailerSalesDAO == null) {
            dailyLiquidationDateWiseRetailerSalesDAO = new DailyLiquidationDateWiseRetailerSalesDAO();
        }

        return dailyLiquidationDateWiseRetailerSalesDAO;
    }

    @Override
    public String insert(DTO dtoObject, SQLiteDatabase dbObject) {
        DailyLiquidationDateWiseRetailerDTO dto = (DailyLiquidationDateWiseRetailerDTO) dtoObject;
        try {
            ContentValues contentValues = new ContentValues();

            contentValues.put("retailerId", dto.getRetailerId());
            contentValues.put("retailerFirmName", dto.getRetailerFirmName());
            contentValues.put("retailerPINCode", dto.getRetailerPINCode());
            contentValues.put("retailerMobileNumber", dto.getRetailerMobileNumber());
            contentValues.put("pioneerSales", dto.getPioneerSales());
            contentValues.put("competitor1Sales", dto.getCompetitor1Sales());
            contentValues.put("competitor2Sales", dto.getCompetitor2Sales());
            contentValues.put("othersSales", dto.getOthersSales());
            contentValues.put("totalSales", dto.getTotalSales());
            contentValues.put("geoLocation", dto.getGeoLocation());
            contentValues.put("submittedDate", dto.getSubmittedDate());
            contentValues.put("tillDate", dto.getTillDate());
            contentValues.put("isSync", dto.getIsSync());
            contentValues.put("calendarId", dto.getCalendarId());

            long rowAffected = dbObject.insert(DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES, null, contentValues);
            if (rowAffected > 0)
                return "inserted";
        } catch (SQLException e) {
            return "";
        } finally {
            dbObject.close();
        }
        return "inserted";
    }

    @SuppressLint("LongLogTag")
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DailyLiquidationDateWiseRetailerDTO dto = (DailyLiquidationDateWiseRetailerDTO) dtoObject;

            ContentValues contentValues = new ContentValues();
            if (dto.getRetailerId() != null)
                contentValues.put("retailerId", dto.getRetailerId());

            if (dto.getRetailerFirmName() != null)
                contentValues.put("retailerFirmName", dto.getRetailerFirmName());

            if (dto.getRetailerPINCode() != null)
                contentValues.put("retailerPINCode", dto.getRetailerPINCode());

            if (dto.getRetailerMobileNumber() != null)
                contentValues.put("retailerMobileNumber", dto.getRetailerMobileNumber());

          //  if (dto.getPioneerSales() != 0)
                contentValues.put("pioneerSales", dto.getPioneerSales());

          //  if (dto.getCompetitor1Sales() != 0)
                contentValues.put("competitor1Sales", dto.getCompetitor1Sales());

         //   if (dto.getCompetitor2Sales() != 0)
                contentValues.put("competitor2Sales", dto.getCompetitor2Sales());

         //   if (dto.getOthersSales() != 0)
                contentValues.put("othersSales", dto.getOthersSales());

       //     if (dto.getTotalSales() != 0)
                contentValues.put("totalSales", dto.getTotalSales());

            if (dto.getGeoLocation() != null)
                contentValues.put("geoLocation", dto.getGeoLocation());

            if (dto.getSubmittedDate() != null)
                contentValues.put("submittedDate", dto.getSubmittedDate());

            if (dto.getTillDate() != null)
                contentValues.put("tillDate", dto.getTillDate());

            if (dto.getIsSync() != 0)
                contentValues.put("isSync", dto.getIsSync());

            if (dto.getCalendarId() != 0)
                contentValues.put("calendarId", dto.getCalendarId());


            int rowsEffected = dbObject.update(DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES, contentValues, "id='" + dto.getId() + "' ", null);
            if (rowsEffected > 0)
                return true;
        } catch (SQLException e) {
            Log.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @SuppressLint("LongLogTag")
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> dailyLiquidationInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES, null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DailyLiquidationDateWiseRetailerDTO dto = new DailyLiquidationDateWiseRetailerDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setRetailerFirmName(cursor.getString(cursor.getColumnIndex("retailerFirmName")));
                    dto.setRetailerPINCode(cursor.getString(cursor.getColumnIndex("retailerPINCode")));
                    dto.setRetailerMobileNumber(cursor.getString(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setTillDate(cursor.getString(cursor.getColumnIndex("tillDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dailyLiquidationInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return dailyLiquidationInfo;
    }

    public List<DailyLiquidationDateWiseRetailerDTO> getRecordByCalendarId(long calendarId, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        List<DailyLiquidationDateWiseRetailerDTO> dailyLiquidationInfo = new ArrayList<DailyLiquidationDateWiseRetailerDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                DailyLiquidationDateWiseRetailerDTO dto;
                do {
                    dto = new DailyLiquidationDateWiseRetailerDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setRetailerFirmName(cursor.getString(cursor.getColumnIndex("retailerFirmName")));
                    dto.setRetailerPINCode(cursor.getString(cursor.getColumnIndex("retailerPINCode")));
                    dto.setRetailerMobileNumber(cursor.getString(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setTillDate(cursor.getString(cursor.getColumnIndex("tillDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dailyLiquidationInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dailyLiquidationInfo;
    }


    public List<DailyLiquidationDateWiseRetailerDTO> getRecordsForUploadByCalendarId(long calendarId, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        List<DailyLiquidationDateWiseRetailerDTO> dailyLiquidationInfo = new ArrayList<DailyLiquidationDateWiseRetailerDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "' and isSync = '1'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                DailyLiquidationDateWiseRetailerDTO dto;
                do {
                    dto = new DailyLiquidationDateWiseRetailerDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setRetailerFirmName(cursor.getString(cursor.getColumnIndex("retailerFirmName")));
                    dto.setRetailerPINCode(cursor.getString(cursor.getColumnIndex("retailerPINCode")));
                    dto.setRetailerMobileNumber(cursor.getString(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setTillDate(cursor.getString(cursor.getColumnIndex("tillDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dailyLiquidationInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dailyLiquidationInfo;
    }

    public List<DailyLiquidationDateWiseRetailerDTO> getRecordsForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        List<DailyLiquidationDateWiseRetailerDTO> dailyLiquidationInfo = new ArrayList<DailyLiquidationDateWiseRetailerDTO>();
        try {
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + " WHERE isSync = '1'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                DailyLiquidationDateWiseRetailerDTO dto;
                do {
                    dto = new DailyLiquidationDateWiseRetailerDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setRetailerFirmName(cursor.getString(cursor.getColumnIndex("retailerFirmName")));
                    dto.setRetailerPINCode(cursor.getString(cursor.getColumnIndex("retailerPINCode")));
                    dto.setRetailerMobileNumber(cursor.getString(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setTillDate(cursor.getString(cursor.getColumnIndex("tillDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dailyLiquidationInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dailyLiquidationInfo;
    }

    public boolean isDataAvailableForUpLoad(SQLiteDatabase readableDb) {
        Cursor cursor = null;
        List<DailyLiquidationDateWiseRetailerDTO> list = new ArrayList<DailyLiquidationDateWiseRetailerDTO>();
        try {
            cursor = readableDb.rawQuery("SELECT count(id) FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + " WHERE isSync = '1'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
            readableDb.close();
        }
        return false;
    }

    public List<DailyLiquidationDateWiseRetailerDTO> getRecordsByDate(long calendarId, String date, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        List<DailyLiquidationDateWiseRetailerDTO> dailyLiquidationInfo = new ArrayList<DailyLiquidationDateWiseRetailerDTO>();
        try {
            //cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_TILL_SALES + "WHERE calendarId = '" + calendarId + "' AND isSync = '" + 1 + "' AND tillDate = '" + date + "'", null);
            cursor = dbObject.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'  AND tillDate = '" + date + "'", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                DailyLiquidationDateWiseRetailerDTO dto;
                do {
                    dto = new DailyLiquidationDateWiseRetailerDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setRetailerId(cursor.getString(cursor.getColumnIndex("retailerId")));
                    dto.setRetailerFirmName(cursor.getString(cursor.getColumnIndex("retailerFirmName")));
                    dto.setRetailerPINCode(cursor.getString(cursor.getColumnIndex("retailerPINCode")));
                    dto.setRetailerMobileNumber(cursor.getString(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setPioneerSales(cursor.getDouble(cursor.getColumnIndex("pioneerSales")));
                    dto.setCompetitor1Sales(cursor.getDouble(cursor.getColumnIndex("competitor1Sales")));
                    dto.setCompetitor2Sales(cursor.getDouble(cursor.getColumnIndex("competitor2Sales")));
                    dto.setOthersSales(cursor.getDouble(cursor.getColumnIndex("othersSales")));
                    dto.setTotalSales(cursor.getDouble(cursor.getColumnIndex("totalSales")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setSubmittedDate(cursor.getString(cursor.getColumnIndex("submittedDate")));
                    dto.setTillDate(cursor.getString(cursor.getColumnIndex("tillDate")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setCalendarId(cursor.getLong(cursor.getColumnIndex("calendarId")));

                    dailyLiquidationInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }
        return dailyLiquidationInfo;
    }

    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES).execute();
            return true;
        } catch (Exception e) {

        } finally {
            dbObject.close();
        }
        return false;
    }

    //newly added
    public boolean isDailyLiquidationDateWiseExist(long calendarId, String date, String retailerId, SQLiteDatabase readableDb) {
        Cursor cursor = null;
        List<DailyLiquidationDateWiseRetailerDTO> list = new ArrayList<DailyLiquidationDateWiseRetailerDTO>();
        try {
            cursor = readableDb.rawQuery("SELECT * FROM " + DBHandler.TABLE_DAILY_LIQUIDATION_DATE_WISE_RETAILERS_SALES + " WHERE calendarId = '" + calendarId + "'  AND tillDate = '" + date + "' AND retailerId ='" + retailerId + "' ", null);
            ;
            return cursor.getCount() > 0;
            /*if (cursor.getCount() > 0)
                return true;
            else
                return false;*/
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
            readableDb.close();
        }
        return false;
    }
}
