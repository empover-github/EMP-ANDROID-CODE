package com.activitytrack.asyncttasks;

import java.io.InputStream;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.activitytrack.activity.R;
import com.activitytrack.database.DBHandler;
import com.activitytrack.transdtos.TransMainDTO;
import com.activitytrack.transdtos.UploadDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.google.gson.Gson;

public class UploadAsync extends AsyncTask<String, Void, String> {

	String jsonData;
	Context context;
	ProgressDialog dlg;

	public UploadAsync(String data) {
		jsonData = data;
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		dlg = new ProgressDialog(context);
		dlg.setCanceledOnTouchOutside(false);
		dlg.setCancelable(false);
		dlg.setMessage(context.getResources().getString(
				R.string.progress_pleaseWait));
		dlg.show();
	}

	@Override
	protected String doInBackground(String... params) {
		HttpClient httpClient = null;
		try {
			HttpParams httpParams = new BasicHttpParams();
			int connectionTimeout = MyConstants.CONNECTION_TIME_LIMIT;
			int socketTimeout = MyConstants.CONNECTION_TIME_LIMIT;
			HttpConnectionParams.setConnectionTimeout(httpParams,
					connectionTimeout);
			HttpConnectionParams.setSoTimeout(httpParams, socketTimeout);
			httpClient = new DefaultHttpClient(httpParams);

			HttpPost httpPost = new HttpPost(params[0]);
			ATBuildLog.i("url", "url :" + params[0]);

			// httpPost.addHeader("Content-Type",
			// "multipart/mixed;boundary=xxBOUNDARYxx");
			ATBuildLog.i("LoginAsync", "request data :" + jsonData);

			
			 StringEntity stringEntity = new StringEntity(jsonData);
			 httpPost.setEntity(stringEntity);
			 

			/*MultipartEntity entity = new MultipartEntity();
			entity.addPart("jsonData", new StringBody(jsonData));
			for (String string : imageNamesList) {
				File mypath = new File(string);
				if (mypath != null) {
					entity.addPart("file", new FileBody(mypath));
				}
			}
			httpPost.setEntity(entity);*/
			ATBuildLog.i("url", "url :" + httpPost.getURI());
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity httpEntity = response.getEntity();
			InputStream instream = httpEntity.getContent();
			String responseStr = Utility.convertStreamToString(instream);
			return responseStr;
		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			if (httpClient != null)
				httpClient.getConnectionManager().shutdown();
		}

		return null;
	}

	@Override
	protected void onPostExecute(String result) {
		if (result != null && !result.isEmpty()) {
			if (!Utility.isJSONValid(result)) {
				if (dlg != null) {
					dlg.dismiss();
				}
				Utility.showAlert(context, "", "It is not a valid Json");
			} else {

				if (!result.isEmpty()) {
					int resPCode = 0;
					try {
						JSONObject jsonObject = new JSONObject(result);
						resPCode = jsonObject.getInt("code");
					} catch (JSONException e) {
						e.printStackTrace();
					}

					if (resPCode == 100) {
						Utility.setLastUploadDate(Utility.getCurrentDateAndTime(),context);
						Gson gson = new Gson();
						UploadDTO uploadobj = gson.fromJson(jsonData, UploadDTO.class);
						TransMainDTO uploadDto = uploadobj.getData();

						/*List<GrowerRegistrationUploadDTO> grList = uploadDto.getGrowerRegistration();
						if (grList != null && grList.size() > 0) {
							for (GrowerRegistrationUploadDTO growerRegistrationUploadDTO : grList) {
								growerRegistrationUploadDTO.setIsSync(0);
								boolean test = GrowerRegistrationDAO.getInstance().updateForUpload(
												growerRegistrationUploadDTO,
												DBHandler.getInstance(
														context)
														.getDBObject(1));
							}
						}

						
						if (isDataPending()) {
							dataUpload.setImageResource(R.drawable.dataupload_icon_active);
						} else {
							dataUpload.setImageResource(R.drawable.dataupload_icon);
						}*/
						if (dlg != null) {
							dlg.dismiss();
						}
						Utility.showAlert(context, "", "Successfully Uploaded");
					} else if (resPCode == 101) {
						if (dlg != null) {
							dlg.dismiss();
						}
						Utility.showAlert(context, "", MyConstants.RES101MSG);
					} else if (resPCode == 102) {
						if (dlg != null) {
							dlg.dismiss();
						}
						Utility.showAlert(context, "", MyConstants.RES102MSG);
					} else if (resPCode == 103) {
						if (dlg != null) {
							dlg.dismiss();
						}
						Utility.showAlert(context, "", MyConstants.RES103MSG);
					} else if (resPCode == 104) {
						if (dlg != null) {
							dlg.dismiss();
						}
						Utility.showAlert(context, "", MyConstants.RES104MSG);
					}
				} else {
					if (dlg != null) {
						dlg.dismiss();
					}
					Utility.showAlert(context, "", "Network Problem please Contact Admin");
				}
			}
		} else {
			if (dlg != null) {
				dlg.dismiss();
			}
			Utility.showAlert(context, "", "Network Problem please Contact Admin");
		}

	}

}
