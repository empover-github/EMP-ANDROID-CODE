package com.activitytrack.daos;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.YieldCalculatorDTO;
import com.activitytrack.utility.ATBuildLog;

public class YieldCalculatorDAO  implements DAO
{

	
	private final String TAG="YieldCalc";
	private static YieldCalculatorDAO yieldCalculatorDAO; 
	 
	public static YieldCalculatorDAO getInstance()
    {
        if (yieldCalculatorDAO == null)
        {
        	yieldCalculatorDAO = new YieldCalculatorDAO();
        }
        
        return yieldCalculatorDAO;
    }

    /**
     * delete the Data
     */

	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}

	
	  /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */

	
	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			
			{
		
		List<DTO> yieldCalculatorInfo=new ArrayList<DTO>();
		Cursor cursor=null; 
		try
		{
		if(!(columnName != null && columnName.length() > 0))	
		
			columnName="id";
		
		 cursor = dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR  where "+columnName+"='"+columnValue+"' ", null);
		 if(cursor.getCount()>0)
		 {
			 cursor.moveToFirst();
			 do
			 {
				 
				 /* YIELD_CALCULATOR
			 
			      id
			      length
			      breadth
			      yield
			      moisture
		          location
      			  isSync
		          competitorName
                  competitorHybrid
                  area
                  yieldHarvested
                  yieldMoisture
                  activity
   			      activityId
   
			     */
			 YieldCalculatorDTO dto =new YieldCalculatorDTO();
			 
			 dto.setId(cursor.getLong(0));
			 dto.setLength(cursor.getFloat(1));
			 dto.setBreadth(cursor.getFloat(2));
			 dto.setYield(cursor.getFloat(3));
			 dto.setMoisture(cursor.getFloat(4));
			 dto.setLocation(cursor.getString(5));
             dto.setIsSync(cursor.getInt(6));
             dto.setCompetitorName(cursor.getString(7));
             dto.setCompetitorHybrid(cursor.getString(8));
             dto.setArea(cursor.getFloat(9));
             dto.setYieldHarvested(cursor.getFloat(10));
             dto.setYieldMoisture(cursor.getFloat(11));
             dto.setActivity(cursor.getString(12));
             dto.setActivityId(cursor.getLong(13));
             
             
             yieldCalculatorInfo.add(dto);
             
			 }while(cursor.moveToNext());
		 }
		 
		}catch (Exception e) 
		 {
			 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
		}finally
		{
			if(cursor!= null && cursor.isClosed())
			{
				cursor.close();
			}
			
		   dbObject.close();
		}
          return yieldCalculatorInfo;
		 
			 
		
		 
		 
	}
	
	
	public List<DTO> getRecordInfoById(String activity, long activityId, SQLiteDatabase dbObject) 
	{
		List<DTO> yieldCalculatorInfo=new ArrayList<DTO>();
		Cursor cursor=null; 
		try
		{
		 cursor = dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR  where activity = '"+activity+"' and activityId = '"+activityId+"' ", null);
		 if(cursor.getCount()>0)
		 {
			 cursor.moveToFirst();
			 do
			 {
				 
				 /* YIELD_CALCULATOR
			 
			      id
			      length
			      breadth
			      yield
			      moisture
		          location
      			  isSync
		          competitorName
                  competitorHybrid
                  area
                  yieldHarvested
                  yieldMoisture
                  activity
   			      activityId
   
			     */
			 YieldCalculatorDTO dto =new YieldCalculatorDTO();
			 
			 dto.setId(cursor.getLong(0));
			 dto.setLength(cursor.getFloat(1));
			 dto.setBreadth(cursor.getFloat(2));
			 dto.setYield(cursor.getFloat(3));
			 dto.setMoisture(cursor.getFloat(4));
			 dto.setLocation(cursor.getString(5));
             dto.setIsSync(cursor.getInt(6));
             dto.setCompetitorName(cursor.getString(7));
             dto.setCompetitorHybrid(cursor.getString(8));
             dto.setArea(cursor.getFloat(9));
             dto.setYieldHarvested(cursor.getFloat(10));
             dto.setYieldMoisture(cursor.getFloat(11));
             dto.setActivity(cursor.getString(12));
             dto.setActivityId(cursor.getLong(13));
             
             
             yieldCalculatorInfo.add(dto);
             
			 }while(cursor.moveToNext());
		 }
		 
		}catch (Exception e) 
		 {
			 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
		}finally
		{
			if(cursor!= null && cursor.isClosed())
			{
				cursor.close();
			}
			
		   dbObject.close();
		}
		
        return yieldCalculatorInfo;  
	}

	 /**
     * Gets all the records from the database
     *
      * @param dbObject
      *            : Exposes methods to manage a SQLite database Object
      */

	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)
	
	
	{
		List<DTO> yieldCalculatorInfo=new ArrayList<DTO>();
		Cursor cursor=null; 
		try
		{
			cursor=dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR",null);
			 if(cursor.getCount()>0)
			 {
				 cursor.moveToFirst();
				 do
				 { 
				
					 
			  YieldCalculatorDTO dto =new YieldCalculatorDTO();
				 
				 
			  	 dto.setId(cursor.getLong(0));
				 dto.setLength(cursor.getFloat(1));
				 dto.setBreadth(cursor.getFloat(2));
				 dto.setYield(cursor.getFloat(3));
				 dto.setMoisture(cursor.getFloat(4));
				 dto.setLocation(cursor.getString(5));
	             dto.setIsSync(cursor.getInt(6));
	             dto.setCompetitorName(cursor.getString(7));
	             dto.setCompetitorHybrid(cursor.getString(8));
	             dto.setArea(cursor.getFloat(9));
	             dto.setYieldHarvested(cursor.getFloat(10));
	             dto.setYieldMoisture(cursor.getFloat(11));
	             dto.setActivity(cursor.getString(12));
	             dto.setActivityId(cursor.getLong(13));
	             
	             yieldCalculatorInfo.add(dto);
				
				 }while(cursor.moveToNext());
			 }
			 
			}catch (Exception e) 
			 {
				 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
			}finally
			{
				if(cursor!= null && cursor.isClosed())
				{
					cursor.close();
				}
				
			   dbObject.close();
			}
	          return yieldCalculatorInfo;
			 
		 
		 
	}
	
	public List<YieldCalculatorDTO> getRecordsForUpload(String activity, long activityId, SQLiteDatabase dbObject) 
	{
		List<YieldCalculatorDTO> yieldCalculatorInfo=new ArrayList<YieldCalculatorDTO>();
		Cursor cursor=null; 
		try
		{
		 cursor = dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR  where activity = '"+activity+"' and activityId = '"+activityId+"' ", null);
		 if(cursor.getCount()>0)
		 {
			 cursor.moveToFirst();
			 do
			 {
				 
				 /* YIELD_CALCULATOR
			 
			      id
			      length
			      breadth
			      yield
			      moisture
		          location
      			  isSync
		          competitorName
                  competitorHybrid
                  area
                  yieldHarvested
                  yieldMoisture
                  activity
   			      activityId
   
			     */
			 YieldCalculatorDTO dto =new YieldCalculatorDTO();
			 
			 dto.setId(cursor.getLong(0));
			 dto.setLength(cursor.getFloat(1));
			 dto.setBreadth(cursor.getFloat(2));
			 dto.setYield(cursor.getFloat(3));
			 dto.setMoisture(cursor.getFloat(4));
			 dto.setLocation(cursor.getString(5));
             dto.setIsSync(cursor.getInt(6));
             dto.setCompetitorName(cursor.getString(7));
             dto.setCompetitorHybrid(cursor.getString(8));
             dto.setArea(cursor.getFloat(9));
             dto.setYieldHarvested(cursor.getFloat(10));
             dto.setYieldMoisture(cursor.getFloat(11));
             dto.setActivity(cursor.getString(12));
             dto.setActivityId(cursor.getLong(13));
             
             
             yieldCalculatorInfo.add(dto);
             
			 }while(cursor.moveToNext());
		 }
		 
		}catch (Exception e) 
		 {
			 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
		}finally
		{
			if(cursor!= null && cursor.isClosed())
			{
				cursor.close();
			}
			
		   dbObject.close();
		}
		
        return yieldCalculatorInfo;  
	}
	    	
    
    
	  /**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
	
	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		try
		{
			YieldCalculatorDTO dto=(YieldCalculatorDTO) dtoObject;
			
			ContentValues cValues=new ContentValues();
			
			
			  
		    /* YIELD_CALCULATOR
		      id
		      length
		      breadth
		      yield
		      moisture 
		      location
              isSync
		      competitorName
              competitorHybrid
              area
              yieldHarvested
              yieldMoisture
   			  activity
   			  activityId
		     
		     */
		 
			 cValues.put("length",dto.getLength());
			 cValues.put("breadth",dto.getBreadth());
			 cValues.put("yield",dto.getYield());
			 cValues.put("moisture",dto.getMoisture());
			 cValues.put("location", dto.getLocation());
	         cValues.put("isSync", dto.getIsSync());
	         cValues.put("competitorName",dto.getCompetitorName());
			cValues.put("competitorHybrid",dto.getCompetitorHybrid());
			cValues.put("area",dto.getArea());
			cValues.put("yieldHarvested",dto.getYieldHarvested());
			cValues.put("yieldMoisture",dto.getYieldMoisture());
			cValues.put("activity",dto.getActivity());
			cValues.put("activityId",dto.getActivityId());
	         
		dbObject.insert("YIELD_CALCULATOR", null, cValues);
		
		return true;
		
		}catch(SQLException e)
		{

			ATBuildLog.e(TAG +"insert()",e.getMessage());
				return false;
				
			
		}finally{
			 dbObject.close();
		 }
		 
	}

	/**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
  
	
	
	
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	
	{
		try{
			YieldCalculatorDTO dto=new YieldCalculatorDTO();
			ContentValues cValues=new ContentValues();
			
			 
			if(dto.getLength()!=0)
				 cValues.put("length",dto.getLength());
				
			if(dto.getYield()!=0) 
			cValues.put("breadth",dto.getBreadth());
			
			if(dto.getMoisture()!=0)
				 cValues.put("moisture",dto.getMoisture());
			 
			if(dto.getLocation() != null)
	        		cValues.put("location", dto.getLocation());
	        	
	            cValues.put("isSync", dto.getIsSync());
	           
	            if(dto.getCompetitorName()!=null)
	            	cValues.put(" competitorName",dto.getCompetitorName());
	            
	            if(dto.getCompetitorHybrid()!=null)
	            	cValues.put("competitorHybrid",dto.getCompetitorHybrid());
	            
	            if(dto.getArea()!=0)
	            	cValues.put("area",dto.getArea());
	            
	            if(dto.getYieldHarvested()!=0)
	            	cValues.put(" yieldHarvested",dto.getYieldHarvested());
	            
	            if(dto.getYieldMoisture()!=0)
	             cValues.put("yieldMoisture",dto.getYieldMoisture());
	            
	            if(dto.getActivity() != null)
	            	cValues.put("activity",dto.getActivity());
				
	             
	            
	            dbObject.update("YIELD_CALCULATOR", cValues, "ActivityId='" +dto.getActivityId()+"' ", null);
	            
		           
	            return true;
	             
	}catch(SQLException e)
	 {
		 ATBuildLog.e(TAG + "update()",e.getMessage());
		 e.printStackTrace();
	 } catch (Exception e)
	 {
		 e.printStackTrace();
	 }finally
	 {
		 dbObject.close();
	 }
	return false;
}
	 /**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM  YIELD_CALCULATOR").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

	
    public boolean deleteTableDataById(String activity, long activityId,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM YIELD_CALCULATOR where activity = '"+activity+"' and activityId = '"+activityId+"'").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataByActivityId(String activityId,String activity,SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("DELETE FROM YIELD_CALCULATOR  where   activityId = '"+activityId+"' and activity = '"+activity+"'");
			return true;
		}catch(Exception e)
		{
			ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally
		
		{
		
		dbObject.close();
		
		}
		return false;
	}  
	


}
