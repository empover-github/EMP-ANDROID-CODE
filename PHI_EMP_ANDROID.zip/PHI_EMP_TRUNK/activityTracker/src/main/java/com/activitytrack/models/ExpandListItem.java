package com.activitytrack.models;

public class ExpandListItem {
    public int ItemType;

    public int getItemType() {
        return ItemType;
    }

    public void setItemType(int itemType) {
        ItemType = itemType;
    }
}
