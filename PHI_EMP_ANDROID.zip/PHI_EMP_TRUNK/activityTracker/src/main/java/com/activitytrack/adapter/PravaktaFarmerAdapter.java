package com.activitytrack.adapter;


import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.dtos.PravaktaFarmerDTO;
import com.bumptech.glide.Glide;


import java.util.ArrayList;
import java.util.List;

/**
 * Created by rambabu.a on 07-03-2018.
 */

public class PravaktaFarmerAdapter extends BaseAdapter {

    private List<PravaktaFarmerDTO> pravaktaFarmerDTOs = new ArrayList<>();
    private Context context;
    private static LayoutInflater inflater = null;


    public PravaktaFarmerAdapter(Context context, List<PravaktaFarmerDTO> pravaktaFarmerDTOs) {
        this.pravaktaFarmerDTOs = pravaktaFarmerDTOs;
        this.context = context;
        inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return pravaktaFarmerDTOs.size();
    }

    @Override
    public Object getItem(int position) {

        return pravaktaFarmerDTOs.get(position);
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.farmer_data_list, null);
            holder = new ViewHolder();
            holder.photoImg = (ImageView) convertView.findViewById(R.id.list_farmer_image);
            holder.tvFarmerName = (TextView) convertView.findViewById(R.id.ph_farmer_name);
            holder.tvCrop = (TextView) convertView.findViewById(R.id.ph_farmer_crop);
            holder.tvHybird = (TextView) convertView.findViewById(R.id.ph_farmer_hybrid);
            holder.tvFarmerMob = (TextView) convertView.findViewById(R.id.ph_mobile_no);


            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        PravaktaFarmerDTO dto = (PravaktaFarmerDTO) getItem(position);
        if (dto != null ) {
            if(dto.getImageUrlPath()!=null && !dto.getImageUrlPath().isEmpty()){
                Glide.with(context).load(dto.getImageUrlPath()).placeholder(R.drawable.loadinggg).error(R.drawable.image_not_exist).into(holder.photoImg);
            }else
                Glide.with(context).load(R.drawable.img_profile_avatar).placeholder(R.drawable.loadinggg).error(R.drawable.image_not_exist).into(holder.photoImg);

            holder.tvFarmerName.setText(dto.getFarmerName());
            holder.tvFarmerMob.setText(dto.getFarmerMobileNo());

            if (dto.getRice())
                holder.tvCrop.setText("Rice");

            if (dto.getCorn())
                holder.tvCrop.setText("Corn");

            if (dto.getMillet())
                holder.tvCrop.setText("Millet");

            if (dto.getMustard())
                holder.tvCrop.setText("Mustard");

            if (dto.getTargetHybridFarm() != null)
                holder.tvHybird.setText("" + dto.getTargetHybridFarm());

        }

        return convertView;
    }

    public static class ViewHolder {
        ImageView photoImg;
        TextView tvFarmerName, tvFarmerMob, tvCrop, tvHybird;

    }
}
