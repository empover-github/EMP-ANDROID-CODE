package com.activitytrack.dtos;

public class FarmerEntryDTO implements DTO
{

	private long mobileId;
	private String location;
	private int isSync;
	
	private String farmerName;
	private long  mobileNumber; 
	private Float acres;
	private String date;
	private String activity;
	private long activityId;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Float getAcres() {
		return acres;
	}
	public void setAcres(Float acres) {
		this.acres = acres;
	}
	public long getId() {
		return mobileId;
	}
	public void setId(long id) {
		this.mobileId = id;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getIsSync() {
		return isSync;
	}
	public void setIsSync(int isSync) {
		this.isSync = isSync;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public long getActivityId() {
		return activityId;
	}
	public void setActivityId(long activityId) {
		this.activityId = activityId;
	}

}
