package com.activitytrack.dtos;


/**
 * Created by fatima.t on 04-12-2018.
 */

public class SegmentationPincodeDTO implements DTO{
    private Long pinCode;
    private String blockName;
    private String districtName;

    public Long getPinCode() {
        return pinCode;
    }

    public void setPinCode(Long pinCode) {
        this.pinCode = pinCode;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }
}
