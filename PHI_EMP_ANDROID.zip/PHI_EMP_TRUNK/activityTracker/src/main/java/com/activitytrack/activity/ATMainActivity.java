package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.TextView;

import com.activitytrack.daos.AgronomyActivityDAO;
import com.activitytrack.daos.AgronomySummaryDAO;
import com.activitytrack.daos.DemandSummaryDAO;
import com.activitytrack.daos.DipstickDAO;
import com.activitytrack.daos.FSMasterDivisionDAO;
import com.activitytrack.daos.FarmerEntryDAO;
import com.activitytrack.daos.LiquidationTrackingDAO;
import com.activitytrack.daos.MdrFarmerDAO;
import com.activitytrack.daos.MdrProfileDAO;
import com.activitytrack.daos.NewMdrSurveyDAO;
import com.activitytrack.daos.OSAActivityDAO;
import com.activitytrack.daos.PDAActivityDAO;
import com.activitytrack.daos.PSAActivityDAO;
import com.activitytrack.daos.RetailerInfoDAO;
import com.activitytrack.daos.SegmentationCropDAO;
import com.activitytrack.daos.SegmentationGrainHybridDAO;
import com.activitytrack.daos.SegmentationGrainServicesDAO;
import com.activitytrack.daos.FarmerSegmentationDAO;
import com.activitytrack.daos.SegmentationRiceHybridDAO;
import com.activitytrack.daos.SegmentationRiceServicesDAO;
import com.activitytrack.daos.SegmentationSchoolDAO;
import com.activitytrack.daos.SegmentationSeasonDAO;
import com.activitytrack.daos.SegmentationSilageHybridDAO;
import com.activitytrack.daos.SegmentationSilageServicesDAO;
import com.activitytrack.daos.SegmentationYearDAO;
import com.activitytrack.daos.ThreeIDAO;
import com.activitytrack.daos.VillageProfileDAO;
import com.activitytrack.daos.YieldCalculatorCropsDAO;
import com.activitytrack.daos.YieldCalculatorDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.interfaces.BackButtonPressesCallback;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdaos.DipstickMasterDAO;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.OtherCropMasterDAO;
import com.activitytrack.masterdaos.RetailerMasterDAO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdaos.SeasonMasterDAO;
import com.activitytrack.masterdaos.SegmentMasterDAO;
import com.activitytrack.masterdaos.TargetAgronomyDAO;
import com.activitytrack.masterdaos.TargetDemandOSADAO;
import com.activitytrack.masterdaos.TargetDemandPDADAO;
import com.activitytrack.masterdaos.TargetDemandPSADAO;
import com.activitytrack.masterdaos.Top3HybridsDAO;
import com.activitytrack.services.ATUpLoadFileService;
import com.activitytrack.services.ATUpLoadFileServiceNewJob;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.HashMap;
import java.util.List;
import java.util.Stack;

@SuppressWarnings("ResourceType")
public class ATMainActivity extends AppCompatActivity implements BackButtonPressesCallback, FragmentDrawer.FragmentDrawerListener {
    // used to store app title
    private CharSequence mTitle;
    private TextView mTitleTextView;

    /* A HashMap of stacks, where we use tab identifier as keys.. */
    private static HashMap<String, Stack<BaseFragment>> mStacks;
    private String mCurrentTab;
    public Menu menu;
    private FragmentDrawer drawerFragment;
    private ActionBar actionBar;
    public static String versionCode;
    private DrawerLayout drawerLayout;
    BaseFragment fragment = null;
    private String loginId, mobileNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_at2);

        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar_at);
        mToolbar.setNavigationIcon(R.drawable.ic_drawer);

        /*mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });*/

        setSupportActionBar(mToolbar);

        mTitleTextView = (TextView) findViewById(R.id.header_text_at);

        actionBar = getSupportActionBar();
//        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#efefef")));
        actionBar.setDisplayShowTitleEnabled(false);
//        actionBar.setTitle("ACTIVITY TRACKER");
//        actionBar.setIcon(new ColorDrawable(Color.TRANSPARENT));
//        centerActionBarTitle();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        mStacks = new HashMap<String, Stack<BaseFragment>>();
        mStacks.put(MyConstants.TAB_HOME, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_NONE, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_PROFILE, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_YIELD_CALCULATOR, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_DATASYNC, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_3I, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_DIPSTICK, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_ABOUT, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_LIQUIDATION, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_CHANGE_PWD, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_QRCODE, new Stack<BaseFragment>());
        // newly added by rams
        mStacks.put(MyConstants.TAB_PRAVAKTA_HA_GAIN, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_GERMINATION_VERIFICATION, new Stack<BaseFragment>());
        //newly added by rams
        mStacks.put(MyConstants.TAB_DASHBOARD, new Stack<BaseFragment>());
        mStacks.put(MyConstants.TAB_SALIGE_FARMER, new Stack<BaseFragment>());

        mTitle = getTitle();

        drawerFragment = (FragmentDrawer) getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawerFragment.setUp(R.id.fragment_navigation_drawer, drawerLayout, mToolbar);
        drawerFragment.setDrawerListener(this);

        // enabling action bar app icon and behaving it as toggle button
        // getActionBar().setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        /*mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                R.drawable.ic_drawer, // nav
                // menu
                // toggle
                // icon
                R.string.drawer_open, // nav drawer open - description for
                // accessibility
                R.string.drawer_close // nav drawer close - description for
                // accessibility
        ) {
            public void onDrawerClosed(View view) {
                actionBar.setTitle(mTitle);
                // calling onPrepareOptionsMenu() to show action bar icons
                invalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                actionBar.setTitle(mTitle);
                // calling onPrepareOptionsMenu() to hide action bar icons
                invalidateOptionsMenu();
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);*/

        if (savedInstanceState == null) {
            // on first time display view for first nav item
            displayView(1);
        }

        Utility.setMenuStatus(1, ATMainActivity.this);

        if (Utility.getCurrentTheme(ATMainActivity.this).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(ATMainActivity.this).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }

//        Mint.initAndStartSession(ATMainActivity.this, "e29f869b");
//        Mint.enableLogging(true);
//        Mint.setLogging(400, "ActivityManager: D *:S");

        //GpsData data = new GpsData(ATMainActivity.this);
        getIntentData();

        if (Utility.networkAvailability(ATMainActivity.this)) {
            startUpLoadService();
        }
       // loadTESTFragment();
    }
    private void loadTESTFragment()
    {
        BaseFragment tile = new TestFragment();
        //*BaseFragment home2 = new DemandGenFragment();*//*
        pushFragments(MyConstants.TAB_HOME, tile, false, true);

    }

    private void getIntentData() {
        Bundle bundle = getIntent().getExtras();
        loginId = bundle.getString("loginId");
        mobileNumber = bundle.getString("mobileNumber");
        versionCode = bundle.getString("versionNo");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        this.menu = menu;
        inflater.inflate(R.menu.main, menu);

        menu.findItem(R.id.action_home).setVisible(false);
        menu.findItem(R.id.action_refresh).setVisible(false);
        menu.findItem(R.id.action_clear).setVisible(false);
        if (MyConstants.TAB_HOME.equals(mCurrentTab)) {
            if (mStacks.get(mCurrentTab).size() > 1) {
                menu.findItem(R.id.action_home).setVisible(true);
            }
        } else {
            menu.findItem(R.id.action_home).setVisible(true);
            if (MyConstants.TAB_QRCODE.equals(mCurrentTab)) {
                menu.findItem(R.id.action_refresh).setVisible(true);
            } else if (MyConstants.TAB_PROFILE.equals(mCurrentTab)) {
                menu.findItem(R.id.action_clear).setVisible(true);
            } else if (MyConstants.TAB_SALIGE_FARMER.equals(mCurrentTab)) {
                menu.findItem(R.id.action_clear).setVisible(true);
            }
        }
        return super.onCreateOptionsMenu(menu);
    }

    private void startUpLoadService() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O){

            if (!Utility.isMyServiceRunning(ATMainActivity.this, "com.activitytrack.services.ATUpLoadFileServiceNewJob")) {
                Intent intent = new Intent(ATMainActivity.this, ATUpLoadFileServiceNewJob.class);
                ATUpLoadFileServiceNewJob.enqueueWork(this,intent);
            }
        }else{

            if (!Utility.isMyServiceRunning(ATMainActivity.this, "com.activitytrack.services.ATUpLoadFileService")) {
                Intent intent = new Intent(ATMainActivity.this, ATUpLoadFileService.class);
                startService(intent);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (drawerFragment.mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        // Handle action bar actions click
        int i = item.getItemId();
        if (i == R.id.action_home) {
            int stackSize = mStacks.get(mCurrentTab).size();
            BaseFragment fragment = mStacks.get(mCurrentTab).get(stackSize - 1);
            fragment.onBackPressed(1000);
            BaseFragment baseFragment = mStacks.get(mCurrentTab).get(0);
            baseFragment.onOptionsItemSelected(item);
        } else if (i == R.id.action_refresh) {//sync found
            BaseFragment baseFragment = mStacks.get(mCurrentTab).get(0);
            baseFragment.onOptionsItemSelected(item);
        } else if (i == R.id.action_clear) {
            BaseFragment baseFragment = mStacks.get(mCurrentTab).get(0);
            baseFragment.onOptionsItemSelected(item);
        }

        invalidateOptionsMenu();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // if nav drawer is opened, hide the action items
        // boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerList);
        // menu.findItem(R.id.action_settings).setVisible(!drawerOpen);
        return super.onPrepareOptionsMenu(menu);
    }

    private void centerActionBarTitle() {
        int titleId = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            titleId = getResources().getIdentifier("action_bar_title", "id", "android");
        } else {
            // This is the id is from your app's generated R class when
            // ActionBarActivity is used for SupportActionBar
            titleId = R.id.action_home;
        }

        // Final check for non-zero invalid id
        if (titleId > 0) {
            TextView titleTextView = (TextView) findViewById(titleId);
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            // Fetch layout parameters of titleTextView
            // (LinearLayout.LayoutParams : Info from HierarchyViewer)
            LinearLayout.LayoutParams txvPars = (LayoutParams) titleTextView.getLayoutParams();
            txvPars.gravity = Gravity.CENTER_HORIZONTAL;
            txvPars.width = metrics.widthPixels;
            titleTextView.setLayoutParams(txvPars);
            titleTextView.setGravity(Gravity.CENTER);
            titleTextView.setTextColor(Color.parseColor("#427730"));
            titleTextView.setTextSize(20);
            titleTextView.setTypeface(null, Typeface.BOLD);

        }
    }

    @Override
    public void onDrawerItemSelected(View view, int position) {
        displayView(position);
    }

    /**
     * Slide menu item click listener
     */
    private class SlideMenuClickListener implements
            ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {
            // display view for selected nav drawer item
            displayView(position);
        }
    }

    public void displayView(int position) {

        switch (position) {
            //   case 1000:
            case 0:
                int stackSize = mStacks.get(mCurrentTab).size();
                BaseFragment fragment = mStacks.get(mCurrentTab).get(stackSize - 1);
                fragment.onBackPressed(position);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            case 1:
                mCurrentTab = MyConstants.TAB_HOME;
                System.out.println("before" + mStacks.get(mCurrentTab).size());
                mStacks.get(MyConstants.TAB_HOME).clear();
                BaseFragment tile = new ATHomeFragment();
                //*BaseFragment home2 = new DemandGenFragment();*//*
                pushFragments(MyConstants.TAB_HOME, tile, false, true);
                System.out.println("after" + mStacks.get(mCurrentTab).size());
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle("ACTIVITY TRACKER");
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 2:
                fragment = null;
                mCurrentTab = MyConstants.TAB_DASHBOARD;
                mStacks.get(mCurrentTab).clear();
                //System.out.println("before" + mStacks.get(mCurrentTab).size());
                mStacks.get(MyConstants.TAB_DASHBOARD).clear();
                BaseFragment home2 = new DemandGenFragment();
                pushFragments(MyConstants.TAB_DASHBOARD, home2, false, true);
                System.out.println("after" + mStacks.get(mCurrentTab).size());
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 3:
                mCurrentTab = MyConstants.TAB_PROFILE;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new MDRProfileFragmentNew(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            case 4:
                mCurrentTab = MyConstants.TAB_PRAVAKTA_HA_GAIN;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new PravaktaHrGainFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            case 5:
                mCurrentTab = MyConstants.TAB_DIPSTICK;
                mStacks.get(mCurrentTab).clear();
//                pushFragments(mCurrentTab, new DipstickFragment(), false, true); // removed by TARA
                pushFragments(mCurrentTab, new DipsticDashboardFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 6:

                mCurrentTab = MyConstants.TAB_QRCODE;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new GenerateCodeFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 7:
                mCurrentTab = MyConstants.TAB_YIELD_CALCULATOR;
                mStacks.get(mCurrentTab).clear();
                BaseFragment ycFragment = new YieldCalculatorCropsFragment();
                Bundle ycBundle = new Bundle();
                ycBundle.putString("activity", "");
                ycFragment.setArguments(ycBundle);
                pushFragments(mCurrentTab, ycFragment, false, true);
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);

                break;
            case 8:
                mCurrentTab = MyConstants.TAB_DATASYNC;
                mStacks.get(mCurrentTab).clear();
                pushFragments(MyConstants.TAB_DATASYNC, new DataSyncFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(position, true);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            case 9:

                if (Utility.getCurrentTheme(ATMainActivity.this).equals(MyConstants.THEME_DARK)) {
                    setTheme(R.style.AppThemeLite);
                    Utility.setCurrentTheme(MyConstants.THEME_LIGHT, ATMainActivity.this);
                } else if (Utility.getCurrentTheme(ATMainActivity.this).equals(MyConstants.THEME_LIGHT)) {
                    setTheme(R.style.AppThemeAT);
                    Utility.setCurrentTheme(MyConstants.THEME_DARK, ATMainActivity.this);
                }

                mCurrentTab = MyConstants.TAB_HOME;
                mStacks.get(mCurrentTab).clear();
                BaseFragment home = new ATHomeFragment();
                pushFragments(mCurrentTab, home, false, true);
//                drawerFragment.mDrawerList.setItemChecked(position, false);
//                drawerFragment.mDrawerList.setSelection(position);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            case 10:
                mCurrentTab = MyConstants.TAB_SALIGE_FARMER;
                mStacks.get(mCurrentTab).clear();
                BaseFragment saligaFarmer = new FarmerSegmentationFragment();
                Bundle bundle = new Bundle();
                bundle.putString("loginId", loginId);
                bundle.putString("mobileNumber", mobileNumber);
                bundle.putString("versionNo", versionCode);
                saligaFarmer.setArguments(bundle);
                pushFragments(mCurrentTab, saligaFarmer, false, true);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            case 11:
//                drawerFragment.mDrawerList.setItemChecked(position, false);
                logoutAlertDialog();
                break;
            default:
              /* int stackSize = mStacks.get(mCurrentTab).size();
                BaseFragment fragment = mStacks.get(mCurrentTab).get(stackSize - 1);
                fragment.onBackPressed(position);
                drawerFragment.closeDrawer(Gravity.LEFT);*/
                break;
        }

    }

    public void pushFragments(String tag, BaseFragment fragment,
                              boolean shouldAnimate, boolean shouldAdd) {
        if (shouldAdd)
            mStacks.get(tag).push(fragment);
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        /*
         * if(shouldAnimate) ft.setCustomAnimations(R.anim.slide_in_right,
         * R.anim.slide_out_left);
         */
        ft.replace(R.id.frame_container, fragment);

        ft.commit();

        invalidateOptionsMenu();

    }

    public void popFragments() {
        /*
         * Select the second last fragment in current tab's stack.. which will
         * be shown after the fragment transaction given below
         */
        Fragment fragment = mStacks.get(mCurrentTab).elementAt(
                mStacks.get(mCurrentTab).size() - 2);

        /* pop current fragment from stack.. */
        mStacks.get(mCurrentTab).pop();

        /*
         * We have the target fragment in hand.. Just show it.. Show a standard
         * navigation animation
         */
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        // ft.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right);
        ft.replace(R.id.frame_container, fragment);
        ft.commit();
    }

    public void dashboardPopFragments() {
        /*
         * Select the second last fragment in current tab's stack.. which will
         * be shown after the fragment transaction given below
         */
        Fragment fragment = mStacks.get(mCurrentTab).elementAt(
                mStacks.get(mCurrentTab).size() - 1);

        /* pop current fragment from stack.. */
        mStacks.get(mCurrentTab).pop();

        /*
         * We have the target fragment in hand.. Just show it.. Show a standard
         * navigation animation
         */
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        // ft.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right);
        ft.replace(R.id.frame_container, fragment);
        ft.commit();
    }

    @Override
    public void onBackPressed() {
        if (mStacks.get(mCurrentTab) != null && !mStacks.get(mCurrentTab).isEmpty()) {
            if (drawerFragment.isDrawerOpen(Gravity.LEFT)) {
                drawerFragment.closeDrawer(Gravity.LEFT);
            }

            /*
             * top fragment in current tab doesn't handles back press,
             * we can do our thing, which is
             *
             * if current tab has only one fragment in stack, ie first
             * fragment is showing for this tab. finish the activity
             * else pop to previous fragment in stack for the same tab
             */
            if (mStacks.get(mCurrentTab).size() == 1) {
                if (mCurrentTab.equals(MyConstants.TAB_HOME)) {
                    alertDialog();
                } else {
                    int stackSize = mStacks.get(mCurrentTab).size();
                    BaseFragment fragment = mStacks.get(mCurrentTab).get(stackSize - 1);
                    fragment.onBackPressed(100);
//							if(fragment.onBackPressed())
//								displayView(10);
                }
                /*
                 * if (trackingButtonTextStatus.equals("STOP TRACKING"))
                 * { } else {
                 */
                // super.onBackPressed(); // or call finish..
                // alertDialog();
                // }
            } else {
                int stackSize = mStacks.get(mCurrentTab).size();
                BaseFragment fragment = mStacks.get(mCurrentTab).get(stackSize - 1);
//						if(fragment.onBackPressed())
//							popFragments();
                fragment.onBackPressed(200);
            }
        } else {
            // do nothing.. fragment already handled back button press.
        }
    }

    @Override
    public void setTitle(CharSequence title) {
        mTitle = title;
        mTitleTextView.setText(mTitle);
    }

    /**
     * When using the ActionBarDrawerToggle, you must call it during
     * onPostCreate() and onConfigurationChanged()...
     */

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        drawerFragment.mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        drawerFragment.onConfigurationChanged(newConfig);
    }

    private void alertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Alert");
        builder.setMessage(getResources().getString(R.string.exit1))
                .setCancelable(false)
                .setPositiveButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                })
                .setNegativeButton(getResources().getString(R.string.yes),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                finish();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void logoutAlertDialog() {
        alertDialog();
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("Alert");
//        builder.setCancelable(false);
//        String message = "";
//        if(Utility.isDataPending(ATMainActivity.this)){
//            message = "Upload data pending, please upload before logging out";
//            builder.setNegativeButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int id) {
//                    onBackPressedCallBack(4);
//                }
//            });
//        }else{
//            message = "Targets & User Data will be lost and will have to be downloaded again, do you want to log out";
//            builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int id) {
//                    dialog.cancel();
//                }
//            });
//            builder.setPositiveButton(getResources().getString(R.string.yes),
//                    new DialogInterface.OnClickListener() {
//                        public void onClick(DialogInterface dialog, int id) {
//                            logoutUser();
//                        }
//                    });
//        }
//
//        builder.setMessage(message);
//
//        AlertDialog alert = builder.create();
//        alert.show();
    }

    private void logoutUser() {
        deleteAllMasterData();
        deleteAllTransData();
        //Navigate to login
        Intent intent = new Intent(ATMainActivity.this, ATLoginActivity.class);
        finish();
        startActivity(intent);
    }

    private void deleteAllMasterData() {
        CropMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        DipstickMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        HybridMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        OtherCropMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        MdrMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        RetailerMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SeasonCalendarDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SeasonMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        TargetAgronomyDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        TargetDemandOSADAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        TargetDemandPDADAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        TargetDemandPSADAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        Top3HybridsDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationSeasonDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationCropDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationYearDAO.getInstance().deleteTableData(com.activitytrack.database.DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        //Newly Added FS
        FSMasterDivisionDAO.getInstance().deleteTableData(com.activitytrack.database.DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationSchoolDAO.getInstance().deleteTableData(com.activitytrack.database.DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationGrainHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationSilageHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationGrainServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationSilageServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
       //newly added
        SegmentationRiceHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        SegmentationRiceServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));

    }

    private void deleteAllTransData() {
        AgronomyActivityDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        LiquidationTrackingDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        MdrProfileDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        VillageProfileDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1)); // TARA
        ThreeIDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        PDAActivityDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        OSAActivityDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        PSAActivityDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        DipstickDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        RetailerInfoDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        AgronomySummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        DemandSummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        FarmerEntryDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        MdrFarmerDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        YieldCalculatorCropsDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        YieldCalculatorDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        FarmerSegmentationDAO.getInstance().deleteTableData(DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
    }

    private void deleteLastThreeDaysData() {
        List<Long> pdaIdsList = PDAActivityDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        if (pdaIdsList != null && pdaIdsList.size() > 0) {
            for (long id : pdaIdsList) {
                PDAActivityDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                RetailerInfoDAO.getInstance().deleteDataByActivityId(String.valueOf(id), MyConstants.ACTIVITY_PDA, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                FarmerEntryDAO.getInstance().deleteDataByActivityId(String.valueOf(id), MyConstants.ACTIVITY_PDA, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                YieldCalculatorCropsDAO.getInstance().deleteDataByActivityId(String.valueOf(id), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
            }
        }

        List<Long> osaIdsList = OSAActivityDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        if (osaIdsList != null && osaIdsList.size() > 0) {
            for (long id : osaIdsList) {
                OSAActivityDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                RetailerInfoDAO.getInstance().deleteDataByActivityId(String.valueOf(id), MyConstants.ACTIVITY_OSA, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                FarmerEntryDAO.getInstance().deleteDataByActivityId(String.valueOf(id), MyConstants.ACTIVITY_OSA, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
            }
        }

        List<Long> psaIdsList = PSAActivityDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        if (psaIdsList != null && psaIdsList.size() > 0) {
            for (long id : psaIdsList) {
                PSAActivityDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                RetailerInfoDAO.getInstance().deleteDataByActivityId(String.valueOf(id), MyConstants.ACTIVITY_PSA, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                FarmerEntryDAO.getInstance().deleteDataByActivityId(String.valueOf(id), MyConstants.ACTIVITY_PSA, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
            }
        }
        //OSAActivityDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
        //PSAActivityDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));

        List<Long> mdrprofileIdsList = MdrProfileDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        if (mdrprofileIdsList != null && mdrprofileIdsList.size() > 0) {
            for (long id : mdrprofileIdsList) {
                MdrProfileDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                MdrFarmerDAO.getInstance().deleteDataById(String.valueOf(id), MyConstants.ACTIVITY_MDR, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
            }
        }


        //TARA
        List<Long> villageProfileIdsList = VillageProfileDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        if (villageProfileIdsList != null && villageProfileIdsList.size() > 0) {
            for (long id : villageProfileIdsList) {
                VillageProfileDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                MdrFarmerDAO.getInstance().deleteDataById(String.valueOf(id), MyConstants.ACTIVITY_MDR, DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
                // TARA
                NewMdrSurveyDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
            }
        }

        AgronomyActivityDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
        ThreeIDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));

        DipstickDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATMainActivity.this).getDBObject(1));
    }

    @Override
    public void onBackPressedCallBack(int callbcakCode) {
        switch (callbcakCode) {
            case 100:
                if (mStacks.get(mCurrentTab).size() == 1) {
                    displayView(1);
                }
                break;

            case 200:
                popFragments();
                break;

            case 0:
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, false);
                //mDrawerLayout.closeDrawer(mDrawerList);
                break;

            case 1:
                mCurrentTab = MyConstants.TAB_PROFILE;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new MDRProfileFragmentNew(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
                // drawerFragment.mDrawerList.setSelection(-1);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 2:
                mCurrentTab = MyConstants.TAB_YIELD_CALCULATOR;
                mStacks.get(mCurrentTab).clear();
                BaseFragment ycFragment = new YieldCalculatorCropsFragment();
                Bundle ycBundle = new Bundle();
                ycBundle.putString("activity", "");
                ycFragment.setArguments(ycBundle);
                pushFragments(mCurrentTab, ycFragment, false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
                // drawerFragment.mDrawerList.setSelection(-1);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
		/*case 3:
			mCurrentTab = MyConstants.TAB_3I;
			mStacks.get(mCurrentTab).clear();
			BaseFragment grfrag = new ThreeIFragment();
			Bundle bundle = new Bundle();
			grfrag.setArguments(bundle);
			pushFragments(mCurrentTab, grfrag, false, true);
			mDrawerList.setItemChecked(callbcakCode, true);
			mDrawerList.setSelection(callbcakCode);
			setTitle(MyConstants.APP_NAME);
			drawerFragment.closeDrawer(Gravity.LEFT);
			break;*/

            case 3:
                mCurrentTab = MyConstants.TAB_DIPSTICK;
                mStacks.get(mCurrentTab).clear();
//                pushFragments(mCurrentTab, new DipstickFragment(), false, true); // removed by TARA
                pushFragments(mCurrentTab, new DipsticDashboardFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 15:
                mCurrentTab = MyConstants.TAB_LIQUIDATION;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new LiquidationFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 4:
                mCurrentTab = MyConstants.TAB_DATASYNC;
                mStacks.get(mCurrentTab).clear();
                pushFragments(MyConstants.TAB_DATASYNC, new DataSyncFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

//            case 5:
//                mCurrentTab = MyConstants.TAB_ABOUT;
//                mStacks.get(mCurrentTab).clear();
//                pushFragments(MyConstants.TAB_ABOUT, new AboutFragment(), false,
//                        true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
//                setTitle(MyConstants.APP_NAME);
//                drawerFragment.closeDrawer(Gravity.LEFT);
//                break;

            case 5:
                if (Utility.getCurrentTheme(ATMainActivity.this).equals(MyConstants.THEME_DARK)) {
                    setTheme(R.style.AppThemeLite);
                    Utility.setCurrentTheme(MyConstants.THEME_LIGHT, ATMainActivity.this);
                } else if (Utility.getCurrentTheme(ATMainActivity.this).equals(MyConstants.THEME_LIGHT)) {
                    setTheme(R.style.AppThemeAT);
                    Utility.setCurrentTheme(MyConstants.THEME_DARK, ATMainActivity.this);
                }

                mCurrentTab = MyConstants.TAB_HOME;
                mStacks.get(mCurrentTab).clear();
                BaseFragment home = new ATHomeFragment();
                pushFragments(mCurrentTab, home, false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, false);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

           /* case 7:
                mCurrentTab = MyConstants.TAB_CHANGE_PWD;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new ChangePasswordFragment(), false, true);
                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;*/

            case 6:
                mCurrentTab = MyConstants.TAB_QRCODE;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new GenerateCodeFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            // newly added for pravaktahr again
            case 7:
                mCurrentTab = MyConstants.TAB_PRAVAKTA_HA_GAIN;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new PravaktaHrGainFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            /*case 8:  //Commented due to removal of germination verification
                mCurrentTab = MyConstants.TAB_GERMINATION_VERIFICATION;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new GerminationVerificationFragment(), false, true);
                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, false);
//                logoutAlertDialog();
                break;*/

            case 8:
                mCurrentTab = MyConstants.TAB_SALIGE_FARMER;
                mStacks.get(mCurrentTab).clear();
                pushFragments(mCurrentTab, new FarmerSegmentationFragment(), false, true);
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;

            case 9:
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, false);
                logoutAlertDialog();

                break;


            case 1000:
                mCurrentTab = MyConstants.TAB_HOME;
                System.out.println("before" + mStacks.get(mCurrentTab).size());
                mStacks.get(MyConstants.TAB_HOME).clear();
                //BaseFragment home2 = new DemandGenFragment();
                BaseFragment home2 = new ATHomeFragment();
                pushFragments(MyConstants.TAB_HOME, home2, false, true);
                System.out.println("after" + mStacks.get(mCurrentTab).size());
//                drawerFragment.mDrawerList.setItemChecked(callbcakCode, true);
//                drawerFragment.mDrawerList.setSelection(callbcakCode);
                setTitle(MyConstants.APP_NAME);
                drawerFragment.closeDrawer(Gravity.LEFT);
                break;
            default:
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

/*	this functionality is to find the GPS strength
 * BroadcastReceiver br2 = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			Log.i("broadcost", "calleddddddddd");

			if (intent.getAction().equals("LOCATION2")) {
				if (intent != null) {
					String inView = intent.getExtras().getString("inView");
					String inUse = intent.getExtras().getString("inUse");
					String accuracy = intent.getExtras().getString("accuracy");

					Toast.makeText(ATMainActivity.this, "inView : "+inView+" inUse : "+inUse+" Accuracy : "+accuracy, Toast.LENGTH_SHORT).show();
				}
			}

		}

	};*/

    @Override
    protected void onResume() {
        super.onResume();

		/*this functionality is to find the GPS strength
		 * IntentFilter filter2 = new IntentFilter();
		filter2.addAction("LOCATION2");
		registerReceiver(br2, filter2);*/
    }

    @Override
    protected void onDestroy() {
        //this functionality is to find the GPS strength
        //unregisterReceiver(br2);
        super.onDestroy();
    }
}