package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class GerminationListDAO implements DAO {

    private final String TAG = "germinationList";
    private static GerminationListDAO germinationListDAO;

    public static GerminationListDAO getInstance() {
        if (germinationListDAO == null) {
            germinationListDAO = new GerminationListDAO();
        }
        return germinationListDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM GERMINATION_VERIFICATION where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    GerminationverificationListDTO dto = new GerminationverificationListDTO();

                    dto.setGerminationClaimTransactionId(cursor.getLong(0));
                    dto.setYear(cursor.getLong(1));
                    dto.setSeasonName(cursor.getString(2));
                    dto.setCropName(cursor.getString(3));
                    dto.setName(cursor.getString(4));
                    dto.setFarmerMobileNumber(cursor.getString(5));
                    dto.setPincode(cursor.getString(6));
                    dto.setGerminationFailedAcres(cursor.getDouble(7));
                    dto.setTotalSowedAcres(cursor.getDouble(8));
                    dto.setDateOfSowing(cursor.getString(9));
                    dto.setStatus(cursor.getString(10));
                    dto.setSync(cursor.getLong(11));
                    dto.setRemarks(cursor.getString(12));
                    dto.setGeoLocation(cursor.getString(13));
                    dto.setMdrVerifiedDate(cursor.getString(14));

                    pdaActivityInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }


    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM GERMINATION_VERIFICATION ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    GerminationverificationListDTO dto = new GerminationverificationListDTO();

                    dto.setGerminationClaimTransactionId(cursor.getLong(0));
                    dto.setYear(cursor.getLong(1));
                    dto.setSeasonName(cursor.getString(2));
                    dto.setCropName(cursor.getString(3));
                    dto.setName(cursor.getString(4));
                    dto.setFarmerMobileNumber(cursor.getString(5));
                    dto.setPincode(cursor.getString(6));
                    dto.setGerminationFailedAcres(cursor.getDouble(7));
                    dto.setTotalSowedAcres(cursor.getDouble(8));
                    dto.setDateOfSowing(cursor.getString(9));
                    dto.setStatus(cursor.getString(10));
                    dto.setSync(cursor.getLong(11));
                    dto.setRemarks(cursor.getString(12));
                    dto.setGeoLocation(cursor.getString(13));
                    dto.setMdrVerifiedDate(cursor.getString(14));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override

    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {

        try
        {
            GerminationverificationListDTO dto=(GerminationverificationListDTO) dtoObject;

            ContentValues cValues=new ContentValues();

            cValues.put("germinationClaimTransactionId", dto.getGerminationClaimTransactionId());
            cValues.put("year", dto.getYear());
            cValues.put("seasonName", dto.getSeasonName());
            cValues.put("cropName", dto.getCropName());
            cValues.put("name", dto.getName());
            cValues.put("farmerMobileNumber", dto.getFarmerMobileNumber());
            cValues.put("pincode", dto.getPincode());
            cValues.put("germinationFailedAcres", dto.getGerminationFailedAcres());
            cValues.put("totalSowedAcres", dto.getTotalSowedAcres());
            cValues.put("dateOfSowing", dto.getDateOfSowing());
            cValues.put("status", dto.getStatus());
            cValues.put("sync", dto.getSync());
            cValues.put("remarks", dto.getRemarks());
            cValues.put("geoLocation", dto.getGeoLocation());
            cValues.put("mdrVerifiedDate", dto.getMdrVerifiedDate());

            dbObject.insert("GERMINATION_VERIFICATION", null, cValues);

            return true;

        }catch(SQLException e)
        {

            ATBuildLog.e(TAG +"insert()",e.getMessage());
            return false;


        }finally{
            dbObject.close();
        }

    }


    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            GerminationverificationListDTO dto = (GerminationverificationListDTO) dtoObject;
            /*germinationClaimTransactionId NUMBER,
            year NUMBER,
            seasonName TEXT,
            cropName TEXT,
            name TEXT,
            farmerMobileNumber TEXT,
            pincode TEXT,
            germinationFailedAcres NUMBER,
            totalSowedAcres NUMBER,
            dateOfSowing TEXT,
            status TEXT,
            sync NUMBER,
            remarks TEXT,
            geoLocation TEXT,
            mdrVerifiedDate TEXT*/
            ContentValues cValues = new ContentValues();

            cValues.put("germinationClaimTransactionId", dto.getGerminationClaimTransactionId());
            cValues.put("year", dto.getYear());
            cValues.put("seasonName", dto.getSeasonName());
            cValues.put("cropName", dto.getCropName());
            cValues.put("name", dto.getName());
            cValues.put("farmerMobileNumber", dto.getFarmerMobileNumber());
            cValues.put("pincode", dto.getPincode());
            cValues.put("germinationFailedAcres", dto.getGerminationFailedAcres());
            cValues.put("totalSowedAcres", dto.getTotalSowedAcres());
            cValues.put("dateOfSowing", dto.getDateOfSowing());
            cValues.put("status", dto.getStatus());
            cValues.put("sync", dto.getSync());
            cValues.put("remarks", dto.getRemarks());
            cValues.put("geoLocation", dto.getGeoLocation());
            cValues.put("mdrVerifiedDate", dto.getMdrVerifiedDate());


            long insertedRow = dbObject.insert("GERMINATION_VERIFICATION", null, cValues);
            if (insertedRow > 0) {
                Cursor cursor = dbObject.rawQuery("SELECT MAX(id) FROM  GERMINATION_VERIFICATION", null);
                if (cursor.getCount() > 0) {

                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            GerminationverificationListDTO dto = (GerminationverificationListDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getGerminationClaimTransactionId() != 0)
                cValues.put("germinationClaimTransactionId", dto.getGerminationClaimTransactionId());

            if (dto.getYear() != 0)
                cValues.put("year", dto.getYear());

            if (dto.getSeasonName() != null)
                cValues.put("seasonName", dto.getSeasonName());

            if (dto.getCropName() != null)
                cValues.put("cropName", dto.getCropName());

            if (dto.getName() != null)
                cValues.put("name", dto.getName());

            if (dto.getFarmerMobileNumber() != null)
                cValues.put("farmerMobileNumber", dto.getFarmerMobileNumber());

            if (dto.getPincode() != null)
                cValues.put("pincode", dto.getPincode());

            if (dto.getGerminationFailedAcres() != 0)
                cValues.put("germinationFailedAcres", dto.getGerminationFailedAcres());

            if (dto.getTotalSowedAcres() != 0)
                cValues.put("totalSowedAcres", dto.getTotalSowedAcres());

            if (dto.getDateOfSowing() != null)
                cValues.put("dateOfSowing", dto.getDateOfSowing());

            if (dto.getStatus() != null)
                cValues.put("status", dto.getStatus());

            if (dto.getSync() != 0)
                cValues.put("sync", dto.getSync());

            if (dto.getRemarks() != null)
                cValues.put("remarks", dto.getRemarks());

            if (dto.getGeoLocation() != null)
                cValues.put("geoLocation", dto.getGeoLocation());

            if (dto.getMdrVerifiedDate() != null)
                cValues.put("mdrVerifiedDate", dto.getMdrVerifiedDate());

            dbObject.update("GERMINATION_VERIFICATION", cValues, " germinationClaimTransactionId='" + dto.getGerminationClaimTransactionId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }



    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM GERMINATION_VERIFICATION").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from GERMINATION_VERIFICATION where germinationClaimTransactionId='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }


    public boolean deleteTableDataById(long id,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM GERMINATION_VERIFICATION where germinationClaimTransactionId = '"+id+"'").execute();
            return true;
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public List<GerminationverificationListDTO> getAllRecords(SQLiteDatabase dbObject) {
        List<GerminationverificationListDTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM GERMINATION_VERIFICATION where sync = 0", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    GerminationverificationListDTO dto = new GerminationverificationListDTO();

                    dto.setGerminationClaimTransactionId(cursor.getLong(0));
                    dto.setYear(cursor.getLong(1));
                    dto.setSeasonName(cursor.getString(2));
                    dto.setCropName(cursor.getString(3));
                    dto.setName(cursor.getString(4));
                    dto.setFarmerMobileNumber(cursor.getString(5));
                    dto.setPincode(cursor.getString(6));
                    dto.setGerminationFailedAcres(cursor.getDouble(7));
                    dto.setTotalSowedAcres(cursor.getDouble(8));
                    dto.setDateOfSowing(cursor.getString(9));
                    dto.setStatus(cursor.getString(10));
                    dto.setSync(cursor.getLong(11));
                    dto.setRemarks(cursor.getString(12));
                    dto.setGeoLocation(cursor.getString(13));
                    dto.setMdrVerifiedDate(cursor.getString(14));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }


    public List<GerminationverificationListDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<GerminationverificationListDTO> pdaActivityInfo = new ArrayList<GerminationverificationListDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM GERMINATION_VERIFICATION where sync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    GerminationverificationListDTO dto = new GerminationverificationListDTO();

                    dto.setGerminationClaimTransactionId(cursor.getLong(0));
                    dto.setYear(cursor.getLong(1));
                    dto.setSeasonName(cursor.getString(2));
                    dto.setCropName(cursor.getString(3));
                    dto.setName(cursor.getString(4));
                    dto.setFarmerMobileNumber(cursor.getString(5));
                    dto.setPincode(cursor.getString(6));
                    dto.setGerminationFailedAcres(cursor.getDouble(7));
                    dto.setTotalSowedAcres(cursor.getDouble(8));
                    dto.setDateOfSowing(cursor.getString(9));
                    dto.setStatus(cursor.getString(10));
                    dto.setSync(cursor.getLong(11));
                    dto.setRemarks(cursor.getString(12));
                    dto.setGeoLocation(cursor.getString(13));
                    dto.setMdrVerifiedDate(cursor.getString(14));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(germinationClaimTransactionId) FROM GERMINATION_VERIFICATION where sync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }
}
