package com.activitytrack.transdtos;

import com.activitytrack.dtos.FarmerEntryDTO;
import com.activitytrack.dtos.PravaktaFarmerDTO;
import com.activitytrack.dtos.RetailerInfoDTO;
import com.activitytrack.dtos.YieldCalculatorCropsDTO;

import java.util.List;

public class ActivitiesTransDTO {

	private long mobileId;
	private String category;
	private long cropId;
	private long hybridId;
	private int numberOfFarmers;
	private int numberOfRetailers;
	private String competitorHybrid1;
	private float hybridYield;
	private float competitorYield;
	private String villages;
	private String location;
	private long seasonId;
	private String date;
	private List<FarmerEntryDTO> farmers;
	private List<RetailerInfoDTO> retailers;
	private List<YieldCalculatorCropsDTO> yieldCalculators;
	private long seasonCalendarId;
	private long regionId;
	private Float acresExposed;
	private String farmerBarCodeDetails;
	private String farmerAttendanceDetails;
	private String pincode;
	// newly added
	private List<PravaktaFarmerDTO> pravaktaFarmers;
	private String pravaktaName;
	private String mobileNo;
	private String villageName;
	private String imageUrlPath;
	private String blockName;
	private String districtName;
	private String previousYear;
	private String currentYear;
	private String totalPreviousAcres;
	private String totalPresentAcres;
	private String phiPreviousAcres;
	private String phiPresentAcres;
	private String targetPreviousAcres;
	private String targetPresentAcres;
	private Boolean rice;
	private Boolean corn;
	private Boolean millet;
	private Boolean mustard;
	private String targetHybrid;
	private String blockType;
	private String villageType;
	//newly added
	private String isTBLParticipated;
	private int numberOfPravaktas;

	//newly added for faw
	private String isFAWDone;
	
	public long getId() {
		return mobileId;
	}
	public void setId(long mobileId) {
		this.mobileId = mobileId;
	}
	
	public String getActivityType() {
		return category;
	}
	public void setActivityType(String activityType) {
		this.category = activityType;
	}
	public long getCropId() {
		return cropId;
	}
	public void setCropId(long cropId) {
		this.cropId = cropId;
	}
	public long getHybridId() {
		return hybridId;
	}
	public void setHybridId(long hybridId) {
		this.hybridId = hybridId;
	}
	public int getNumberOfFarmers() {
		return numberOfFarmers;
	}
	public void setNumberOfFarmers(int numberOfFarmers) {
		this.numberOfFarmers = numberOfFarmers;
	}
	public int getNumberOfRetailers() {
		return numberOfRetailers;
	}
	public void setNumberOfRetailers(int numberOfRetailers) {
		this.numberOfRetailers = numberOfRetailers;
	}
	public String getCompetitorHybrid1() {
		return competitorHybrid1;
	}
	public void setCompetitorHybrid1(String competitorHybrid1) {
		this.competitorHybrid1 = competitorHybrid1;
	}
	public float getHybridYield() {
		return hybridYield;
	}
	public void setHybridYield(float hybridYield) {
		this.hybridYield = hybridYield;
	}
	public float getCompetitorYield() {
		return competitorYield;
	}
	public void setCompetitorYield(float competitorYield) {
		this.competitorYield = competitorYield;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public long getSeasonId() {
		return seasonId;
	}
	public void setSeasonId(long seasonId) {
		this.seasonId = seasonId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<FarmerEntryDTO> getFarmers() {
		return farmers;
	}
	public void setFarmers(List<FarmerEntryDTO> farmers) {
		this.farmers = farmers;
	}
	public long getRegionId() {
		return regionId;
	}
	public void setRegionId(long regionId) {
		this.regionId = regionId;
	}
	public List<RetailerInfoDTO> getRetailers() {
		return retailers;
	}
	public void setRetailers(List<RetailerInfoDTO> retailers) {
		this.retailers = retailers;
	}
	public List<YieldCalculatorCropsDTO> getYieldCalculators() {
		return yieldCalculators;
	}
	public long getSeasonCalendarId() {
		return seasonCalendarId;
	}
	public void setSeasonCalendarId(long seasonCalendarId) {
		this.seasonCalendarId = seasonCalendarId;
	}
	public void setYieldCalculators(List<YieldCalculatorCropsDTO> yieldCalculators) {
		this.yieldCalculators = yieldCalculators;
	}

	public Float getAcresExposed() {
		return acresExposed;
	}

	public void setAcresExposed(Float acresExposed) {
		this.acresExposed = acresExposed;
	}

	public String getFarmerBarCodeDetails() {
		return farmerBarCodeDetails;
	}

	public void setFarmerBarCodeDetails(String farmerBarCodeDetails) {
		this.farmerBarCodeDetails = farmerBarCodeDetails;
	}

	public String getFarmerAttendanceDetails() {
		return farmerAttendanceDetails;
	}

	public void setFarmerAttendanceDetails(String farmerAttendanceDetails) {
		this.farmerAttendanceDetails = farmerAttendanceDetails;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public List<PravaktaFarmerDTO> getPravaktaFarmers() {
		return pravaktaFarmers;
	}

	public void setPravaktaFarmers(List<PravaktaFarmerDTO> pravaktaFarmers) {
		this.pravaktaFarmers = pravaktaFarmers;
	}



	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getVillageName() {
		return villageName;
	}

	public void setVillageName(String villageName) {
		this.villageName = villageName;
	}


	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getPreviousYear() {
		return previousYear;
	}

	public void setPreviousYear(String previousYear) {
		this.previousYear = previousYear;
	}

	public String getCurrentYear() {
		return currentYear;
	}

	public void setCurrentYear(String currentYear) {
		this.currentYear = currentYear;
	}

	public String getTotalPreviousAcres() {
		return totalPreviousAcres;
	}

	public void setTotalPreviousAcres(String totalPreviousAcres) {
		this.totalPreviousAcres = totalPreviousAcres;
	}

	public String getTotalPresentAcres() {
		return totalPresentAcres;
	}

	public void setTotalPresentAcres(String totalPresentAcres) {
		this.totalPresentAcres = totalPresentAcres;
	}

	public String getPhiPreviousAcres() {
		return phiPreviousAcres;
	}

	public void setPhiPreviousAcres(String phiPreviousAcres) {
		this.phiPreviousAcres = phiPreviousAcres;
	}

	public String getPhiPresentAcres() {
		return phiPresentAcres;
	}

	public void setPhiPresentAcres(String phiPresentAcres) {
		this.phiPresentAcres = phiPresentAcres;
	}

	public String getTargetPreviousAcres() {
		return targetPreviousAcres;
	}

	public void setTargetPreviousAcres(String targetPreviousAcres) {
		this.targetPreviousAcres = targetPreviousAcres;
	}

	public String getTargetPresentAcres() {
		return targetPresentAcres;
	}

	public void setTargetPresentAcres(String targetPresentAcres) {
		this.targetPresentAcres = targetPresentAcres;
	}

	public Boolean getRice() {
		return rice;
	}

	public void setRice(Boolean rice) {
		this.rice = rice;
	}

	public Boolean getCorn() {
		return corn;
	}

	public void setCorn(Boolean corn) {
		this.corn = corn;
	}

	public Boolean getMillet() {
		return millet;
	}

	public void setMillet(Boolean millet) {
		this.millet = millet;
	}

	public Boolean getMustard() {
		return mustard;
	}

	public void setMustard(Boolean mustard) {
		this.mustard = mustard;
	}

	public String getTargetHybrid() {
		return targetHybrid;
	}

	public void setTargetHybrid(String targetHybrid) {
		this.targetHybrid = targetHybrid;
	}

	public String getBlockType() {
		return blockType;
	}

	public void setBlockType(String blockType) {
		this.blockType = blockType;
	}

	public String getVillageType() {
		return villageType;
	}

	public void setVillageType(String villageType) {
		this.villageType = villageType;
	}

	public String getPravaktaName() {
		return pravaktaName;
	}

	public void setPravaktaName(String pravaktaName) {
		this.pravaktaName = pravaktaName;
	}

	public String getImageUrlPath() {
		return imageUrlPath;
	}

	public void setImageUrlPath(String imageUrlPath) {
		this.imageUrlPath = imageUrlPath;
	}

	public String getIsTBLParticipated() {
		return isTBLParticipated;
	}

	public void setIsTBLParticipated(String isTBLParticipated) {
		this.isTBLParticipated = isTBLParticipated;
	}

	public int getNumberOfPravaktas() {
		return numberOfPravaktas;
	}

	public void setNumberOfPravaktas(int numberOfPravaktas) {
		this.numberOfPravaktas = numberOfPravaktas;
	}

	public String getIsFAWDone() {
		return isFAWDone;
	}

	public void setIsFAWDone(String isFAWDone) {
		this.isFAWDone = isFAWDone;
	}
}
