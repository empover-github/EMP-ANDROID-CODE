package com.activitytrack.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.daos.ThreeIDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.ThreeIDTO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

public class ThreeIFragment extends BaseFragment {

private View view;

private TextView tvRetailerMobileNo;
private EditText edtRetailerMobileNo;

private TextView tvRetailerFirmName;
private EditText edtRetaileFirmName;

private Spinner spn3iPhaseNo;

private TextView tv3iPhaseNo;

private LinearLayout mainLayout;

private Button btnSubmit;

List<String> spinnerData=new ArrayList<String>();

@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.three_i_fragment, container, false);
		
		/*if(location == null)
			getCurrentLocation("initial");*/
		
		spn3iPhaseNo=(Spinner)view.findViewById(R.id.three_3iPhaseNo);
		
		tvRetailerMobileNo=(TextView)view.findViewById(R.id.three_retailerMobileNo_l);
		tvRetailerFirmName=(TextView)view.findViewById(R.id.three_retailerFirmName_l);
		
		edtRetailerMobileNo=(EditText)view.findViewById(R.id.three_retailerMobileNo);
		edtRetaileFirmName=(EditText)view.findViewById(R.id.three_retailerFirmName);
	
		tv3iPhaseNo=(TextView)view.findViewById(R.id.three_3iPhaseNo_l);
		
		mainLayout=(LinearLayout)view.findViewById(R.id.three_3i_bg_layout);
		
		btnSubmit=(Button)view.findViewById(R.id.three_submit);
		
		spinnerData.add("Select");
		spinnerData.add("1");
		spinnerData.add("2");
		spinnerData.add("3");
		
		
		setChange();
		
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, spinnerData);
		 
		 		 
		 spn3iPhaseNo.setAdapter(adapter);
	      
	     
		 spn3iPhaseNo.setOnItemSelectedListener(new OnItemSelectedListener() 
		 {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				 if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT))
				 {
					 ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
				 }else{
					 ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
				 }
					 
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				 
				
			}
			 
			 
			 
		} );
		 {
			 
		 }
		 btnSubmit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) 
			{
				String Validation=  validationFields();
				if(Validation.trim().length()==0)
				{
					if(checkForLocation){
					  if(location != null && location.length() > 0) {
				 		showAlertToSave();
					  }
					  else{
						  getCurrentLocation(mActivity);
					  }  
					}else{
						showAlertToSave();
					}
				}else{
					Utility.showAlert(mActivity, "",Validation);
				}
			}
		});
		
		return view;
		
		
		
	}

	private String validationFields() 
	{
		
		if(edtRetailerMobileNo.getText().toString().trim().length()==0)
			return  getResources().getString(R.string.retmobno);
		
		if(edtRetailerMobileNo.getText().toString().trim().length() <= 9)
		{
			edtRetailerMobileNo.setError(getResources().getString(R.string.validmobilenum));
			return getResources().getString(R.string.validmobilenum);
		}
		if(edtRetaileFirmName.getText().toString().trim().length()==0)
			return getResources().getString(R.string.retfirmemp) ;
		
		if(spn3iPhaseNo.getSelectedItemPosition() ==0)
			return  getResources().getString(R.string.threei);
		
		return "";
	}
	
	private void showAlertToSave() 
	{
		 AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		 builder.setMessage(getResources().getString(R.string.saveData));
		 builder.setPositiveButton(getResources().getString(R.string.yes),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
				saveData();
			}
			
			
		}); 
		 builder.setNegativeButton(getResources().getString(R.string.no),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
			}
		});
		 
	builder.create().show();
	
	}
		
	
	
	
	private void saveData()
	{
		 ThreeIDTO dto=new ThreeIDTO();
	     
		 dto.setRetailerMobileNo(Long.valueOf(edtRetailerMobileNo.getText().toString().trim()));
	     dto.setRetailersFirmName(edtRetaileFirmName.getText().toString().trim());
	     dto.setThreeIPhaseNo(Integer.valueOf(spinnerData.get(spn3iPhaseNo.getSelectedItemPosition())));
	     dto.setDate(Utility.getCurrentDateAndTime());
	     dto.setLocation(location);
	     dto.setIsSync(1);
	
	     long regionId=MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
	       if(regionId!=0)
		    dto.setRegionId(regionId);	
	     
	       boolean inserted=ThreeIDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getDBObject(1));
		  if(inserted)
		  {
			  Utility.showAlert(mActivity, null, MyConstants.SUC_MSG);
			  checkForLocation = true;
			  location = null;
			  clearFields();
		  }
	
	}
	

		
	private void clearFields() 
	{
		 edtRetailerMobileNo.setText("");
		 edtRetaileFirmName.setText("");
		 spn3iPhaseNo.setSelection(0);
	}

	private void setChange(){
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			tvRetailerMobileNo.setTextColor(Color.WHITE);
			tvRetailerFirmName.setTextColor(Color.WHITE);
			tv3iPhaseNo.setTextColor(Color.WHITE);
			spn3iPhaseNo.setBackgroundResource(R.drawable.spinner_bg_img);
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
			
		}else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
			tv3iPhaseNo.setTextColor(Color.BLACK);
			tvRetailerMobileNo.setTextColor(Color.BLACK);
			tvRetailerFirmName.setTextColor(Color.BLACK);
			spn3iPhaseNo.setBackgroundResource(R.drawable.spinner_bg_img_light);
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
		}

	}	
		


 	/*private void getCurrentLocation2(final String status) {
		try {
			LocationManager lm = (LocationManager) mActivity.getSystemService(Context.LOCATION_SERVICE);
			if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
			LocationResult locationResult = new LocationResult(){
				@Override
				public void gotLocation(Location loc) {
					if (loc != null) {
						String currentLocation = loc.getLatitude() + "," + loc.getLongitude();
						System.out.println(" Current Location = " + currentLocation);
						location = currentLocation;
					}
					
					if(status.equals(MyConstants.SUBMIT)){
						hideProgressDialog();
						saveData();
					}
				}
			};
			CurrentLocation cLocation = new CurrentLocation();
			cLocation.getLocation(mActivity, locationResult);
			}else{
				if(status.equals(getResources().getString(R.string.submit))){
					hideProgressDialog();
					Utility.showAlertToOpenGPS(mActivity);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/
		
		@Override
		public boolean onBackPressed(int callbackCode) {
			if(isDataAvailable()){
				showAlertToExitScreen(callbackCode);
			}else{
				mActivity.onBackPressedCallBack(callbackCode);
			}
			return true;
		}
		
		private void showAlertToExitScreen(final int callbackCode){
			AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
			builder.setMessage(getResources().getString(R.string.formExitMsg));
			builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					mActivity.onBackPressedCallBack(callbackCode);
				}
			});
			
			builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					
				}
			});
			
			builder.create().show();
		}
		
		private boolean isDataAvailable() 
		{
			if(edtRetailerMobileNo.getText().toString().trim().length() > 0)
				return true;
			
			if(edtRetailerMobileNo.getText().toString().trim().length() > 0)
				return true;
			
			if(spn3iPhaseNo.getSelectedItemPosition() > 0)
				return true;
			
			return false;
		}
		
	    @Override
		public void onStart() {
			super.onStart();
			if (mGoogleApiClient != null) {
				if(! mGoogleApiClient.isConnected())
					mGoogleApiClient.connect();
	        }
		}
	
	@Override
		public void onStop() {
			super.onStop();
			if (mGoogleApiClient != null) {
				if(mGoogleApiClient.isConnected())
					mGoogleApiClient.disconnect();
	        }
		}
	
	@Override
		public void onDestroy() {
			location = null;
			super.onDestroy();
		}
	
}
