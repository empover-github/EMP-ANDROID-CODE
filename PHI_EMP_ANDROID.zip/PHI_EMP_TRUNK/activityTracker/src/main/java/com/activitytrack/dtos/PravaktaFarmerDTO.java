package com.activitytrack.dtos;

import java.io.Serializable;

/**
 * Created by rambabu.a on 06-03-2018.
 */

public class PravaktaFarmerDTO implements DTO,Serializable {
    private long mobileId;
    private String imageUrlPath;
    private String pdaAttendPre;
    private String pdaAttendCurr;
    private String pionUserPre;
    private String pionUserCurr;
    private String previousYear;
    private String currentYear;
    private String totalPreviousAcresFarm;
    private String totalPresentAcresFarm;
    private String phiPreviousAcresFarm;
    private String phiPresentAcresFarm;
    private String targetPreviousAcresFarm;
    private String targetPresentAcresFarm;
    private boolean rice;
    private boolean corn;
    private boolean millet;
    private boolean mustard;
    private String targetHybridFarm;
    private long activityId;
    private String farmerName;
    private String farmerMobileNo;


    public String getPdaAttendPre() {
        return pdaAttendPre;
    }

    public void setPdaAttendPre(String pdaAttendPre) {
        this.pdaAttendPre = pdaAttendPre;
    }

    public String getPdaAttendCurr() {
        return pdaAttendCurr;
    }

    public void setPdaAttendCurr(String pdaAttendCurr) {
        this.pdaAttendCurr = pdaAttendCurr;
    }

    public String getPionUserPre() {
        return pionUserPre;
    }

    public void setPionUserPre(String pionUserPre) {
        this.pionUserPre = pionUserPre;
    }

    public String getPionUserCurr() {
        return pionUserCurr;
    }

    public void setPionUserCurr(String pionUserCurr) {
        this.pionUserCurr = pionUserCurr;
    }

    public String getTotalPreviousAcresFarm() {
        return totalPreviousAcresFarm;
    }

    public void setTotalPreviousAcresFarm(String totalPreviousAcresFarm) {
        this.totalPreviousAcresFarm = totalPreviousAcresFarm;
    }

    public String getTotalPresentAcresFarm() {
        return totalPresentAcresFarm;
    }

    public void setTotalPresentAcresFarm(String totalPresentAcresFarm) {
        this.totalPresentAcresFarm = totalPresentAcresFarm;
    }

    public String getPhiPreviousAcresFarm() {
        return phiPreviousAcresFarm;
    }

    public void setPhiPreviousAcresFarm(String phiPreviousAcresFarm) {
        this.phiPreviousAcresFarm = phiPreviousAcresFarm;
    }

    public String getPhiPresentAcresFarm() {
        return phiPresentAcresFarm;
    }

    public void setPhiPresentAcresFarm(String phiPresentAcresFarm) {
        this.phiPresentAcresFarm = phiPresentAcresFarm;
    }

    public String getTargetPreviousAcresFarm() {
        return targetPreviousAcresFarm;
    }

    public void setTargetPreviousAcresFarm(String targetPreviousAcresFarm) {
        this.targetPreviousAcresFarm = targetPreviousAcresFarm;
    }

    public String getTargetPresentAcresFarm() {
        return targetPresentAcresFarm;
    }

    public void setTargetPresentAcresFarm(String targetPresentAcresFarm) {
        this.targetPresentAcresFarm = targetPresentAcresFarm;
    }





    public String getTargetHybridFarm() {
        return targetHybridFarm;
    }

    public void setTargetHybridFarm(String targetHybridFarm) {
        this.targetHybridFarm = targetHybridFarm;
    }

    public long getActivityId() {
        return activityId;
    }

    public void setActivityId(long activityId) {
        this.activityId = activityId;
    }



    public long getId() {
        return mobileId;
    }

    public void setId(long mobileid) {

        this.mobileId = mobileid;
    }

    public String getPreviousYear() {
        return previousYear;
    }

    public void setPreviousYear(String previousYear) {
        this.previousYear = previousYear;
    }

    public String getCurrentYear() {
        return currentYear;
    }

    public void setCurrentYear(String currentYear) {
        this.currentYear = currentYear;
    }

    public boolean getRice() {
        return rice;
    }

    public void setRice(boolean rice) {
        this.rice = rice;
    }

    public boolean getCorn() {
        return corn;
    }

    public void setCorn(boolean corn) {
        this.corn = corn;
    }

    public boolean getMillet() {
        return millet;
    }

    public void setMillet(boolean millet) {
        this.millet = millet;
    }

    public boolean getMustard() {
        return mustard;
    }

    public void setMustard(boolean mustard) {
        this.mustard = mustard;
    }

    public String getImageUrlPath() {
        return imageUrlPath;
    }

    public void setImageUrlPath(String imageUrlPath) {
        this.imageUrlPath = imageUrlPath;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getFarmerMobileNo() {
        return farmerMobileNo;
    }

    public void setFarmerMobileNo(String farmerMobileNo) {
        this.farmerMobileNo = farmerMobileNo;
    }
}

