package com.activitytrack.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.activitytrack.adapter.UploadedVillageListAdapter;
import com.activitytrack.daos.UploadedVillageListDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.UploadedVillageListDTO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.masterdtos.UploadedVillageListRefreshRes;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by fatima.t on 01-05-2018.
 */

public class UploadedVillagesListActivity extends BaseActivity /*implements OnListItemClickListener*/ {
    private RecyclerView recyclerView;
    private TextView noDataTxt;
    private ActionBar actionBar;
    private UploadedVillagesListActivity thisActivity;
    private UploadedVillageListAdapter listAdapter;
    private List<UploadedVillageListDTO> profileDataList;
    private ArrayList<UploadedVillageListDTO> originalList = new ArrayList<>();
    private EditText edtSearch;
    private ImageView imgClear, imgSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Utility.getCurrentTheme(UploadedVillagesListActivity.this).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(UploadedVillagesListActivity.this).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uploaded_villages_list);
        thisActivity = this;

        actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setTitle(getString(R.string.show_uploaded_village_list));


        /*String jsonDataStr = loadJSONFromAsset(thisActivity);
        try
        {
            JSONObject jsonobject = new JSONObject(jsonDataStr);
            JSONArray jarray = (JSONArray) jsonobject.getJSONArray("data");
            profileDataList = new ArrayList<>();
            profileDataList.add(new UploadedVillageListDTO("S.No","VillageName","Season","Crop","UploadedDate"));
            for(int i=0;i<jarray.length();i++)
            {
                JSONObject jb =(JSONObject) jarray.get(i);
                long id_st = jb.getLong("id");
                String villageName_st = jb.getString("villageName");
                String season_st = jb.getString("season");
                String crop_st = jb.getString("crop");
                String uploadedDate_st = jb.getString("uploadedDate");

                profileDataList.add(new UploadedVillageListDTO(id_st, villageName_st, season_st,crop_st, uploadedDate_st));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        prepareList();

        /*profileDataList = new ArrayList<>();
        UploadedVillageListDTO headers = new UploadedVillageListDTO();
        headers.setSno("S.No");
        headers.setVillageName("Village Name");
        headers.setCrop("Crop");
        headers.setSeason("Season");
        headers.setUploadedDate("Uploaded Date");
        profileDataList.add(headers);
        profileDataList.addAll(UploadedVillageListDAO.getInstance().getRecordsUploaded(DBHandler.getInstance(thisActivity).getDBObject(0)));
*/
        edtSearch = (EditText) findViewById(R.id.edt_search);
        imgClear = (ImageView) findViewById(R.id.img_clear);
        imgSearch = (ImageView) findViewById(R.id.img_search);
        recyclerView = (RecyclerView) findViewById(R.id.uvl_recycler_view);
        noDataTxt = (TextView) findViewById(R.id.uvl_no_data_txt);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setAutoMeasureEnabled(true);
        recyclerView.setLayoutManager(layoutManager);
        listAdapter = new UploadedVillageListAdapter(UploadedVillagesListActivity.this, profileDataList/*, this*/);
        recyclerView.setAdapter(listAdapter);
        showHideViews();


        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                profileDataList.clear();
                if (s.toString().isEmpty()) {
                    profileDataList.addAll(originalList);
                } else {
                    for (UploadedVillageListDTO dto : originalList) {
                        if (Pattern.compile(Pattern.quote(edtSearch.getText().toString().trim()), Pattern.CASE_INSENSITIVE).matcher(dto.getVillageName()).find()) {
                            profileDataList.add(dto);
                        }
                    }
                }
                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setFocusableInTouchMode(true);
                edtSearch.setFocusable(true);
                edtSearch.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(edtSearch, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        imgClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setText("");
            }
        });
        imgSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setFocusableInTouchMode(true);
                edtSearch.setFocusable(true);
                edtSearch.requestFocus();
                InputMethodManager imm1 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm1.showSoftInput(edtSearch, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }

    private void prepareList() {
        profileDataList = new ArrayList<>();
        originalList.clear();
        profileDataList.clear(); // new Added
     /*   UploadedVillageListDTO headers = new UploadedVillageListDTO();
        headers.setSno("S.No");
        headers.setVillageName("Village Name");
        headers.setCrop("Crop");
        headers.setSeason("Season");
        headers.setUploadedDate("Uploaded Date");
        profileDataList.add(headers);*/
        originalList.addAll(UploadedVillageListDAO.getInstance().getRecordsUploaded(DBHandler.getInstance(thisActivity).getDBObject(0)));
        profileDataList.addAll(originalList);

    }

    private void showHideViews() {
        if (profileDataList.size() > 0) {
            noDataTxt.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            noDataTxt.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
    }

    /*@Override
    public void onItemLongClick(View view, int position) {

    }
    @Override
    public void onItemClick(View view, int position) {

        int i = view.getId();
        UploadedVillageListDTO dto = (UploadedVillageListDTO) view.getTag();
        final long id = dto.getId();
        // do your stuff with DTO
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        } else if (item.getItemId() == R.id.action_refresh) {
            if (Utility.networkAvailability(thisActivity)) {
                // call API and save Data in local DB
                JSONObject jsonObject = new JSONObject();
                try {
                    List<DTO> userDtoList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(thisActivity).getDBObject(0));
                    if (userDtoList != null && userDtoList.size() > 0) {
                        MdrMasterDTO loginDTO = (MdrMasterDTO) userDtoList.get(0);
                        jsonObject.put("loginId", loginDTO.getLoginId());
                        jsonObject.put("versionNo", ATMainActivity.versionCode);

                        DownloadAsync async = new DownloadAsync(jsonObject.toString(), thisActivity);
                        async.execute(MyConstants.AppURL + MyConstants.UPLOADED_VILLAGE_PROFILE_REFRESH);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                DialogManager.showToast(thisActivity, getString(R.string.checkNetwork));
            }
        }
        return super.onOptionsItemSelected(item);
    }

    public String loadJSONFromAsset(Context context) {
        String json = null;
        try {
            InputStream is = context.getAssets().open("datatext.txt");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_refresh, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public class DownloadAsync extends AsyncTask<String, Void, String> {
        String jsonData;
        Context context;
        ProgressDialog dlg;

        public DownloadAsync(String inputJSON, Context context) {
            jsonData = inputJSON;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dlg = new ProgressDialog(context);
            dlg.setCanceledOnTouchOutside(false);
            dlg.setCancelable(false);
            dlg.setMessage(context.getResources().getString(R.string.progress_pleaseWait));
            dlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpClient = null;
            try {
                HttpParams httpParams = new BasicHttpParams();
                int connectionTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                int socketTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                HttpConnectionParams.setConnectionTimeout(httpParams, connectionTimeout);
                HttpConnectionParams.setSoTimeout(httpParams, socketTimeout);
                httpClient = new DefaultHttpClient(httpParams);
                HttpPost httpPost = new HttpPost(params[0]);
                ATBuildLog.i("LoginAsync", "request data :" + jsonData);
                StringEntity stringEntity = new StringEntity(jsonData);
                httpPost.setEntity(stringEntity);
                HttpResponse response = httpClient.execute(httpPost);
                HttpEntity httpEntity = response.getEntity();
                InputStream instream = httpEntity.getContent();
                return Utility.convertStreamToString(instream);
            } catch (Exception exception) {
                exception.printStackTrace();
            } finally {
                if (httpClient != null)
                    httpClient.getConnectionManager().shutdown();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && !result.isEmpty()) {
                if (!Utility.isJSONValid(result)) {
                    Utility.showAlert(context, "", getResources().getString(R.string.ntjson));
                } else {

                    try {

                        System.out.println("master Data : " + result);

                        Gson gson = new Gson();
                        UploadedVillageListRefreshRes obj = gson.fromJson(result, UploadedVillageListRefreshRes.class);

                        if (obj.getCode() == 100) {
                            //setting data download req

                            List<UploadedVillageListDTO> uploadedVillageList =obj.getVillageProfileUploadedData();
                            if(uploadedVillageList!=null){
                                UploadedVillageListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for(UploadedVillageListDTO uploadedVillageDTO : uploadedVillageList){
                                    UploadedVillageListDAO.getInstance().insertActivity(uploadedVillageDTO,DBHandler.getInstance(context).getDBObject(1));
                                }

                                Utility.setNoOfProfilesUploadedByMdr("" + uploadedVillageList.size(), context);
                            }

                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            prepareList();
                            listAdapter = new UploadedVillageListAdapter(UploadedVillagesListActivity.this, profileDataList/*, this*/);
                            recyclerView.setAdapter(listAdapter);
                          //  listAdapter.notifyDataSetChanged();
                            showHideViews();

                        } else if (obj.getCode() == 101) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES101MSG);
                        } else if (obj.getCode() == 102) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES102MSG);
                        } else if (obj.getCode() == 103) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES103MSG);
                        } else if (obj.getCode() == 104) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES104MSG);
                        } else if (obj.getCode() == 302) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", "This user is registered with other device\nyou cannot download from this device");
                        }

                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            } else {
                Utility.showAlert(context, "", getResources().getString(R.string.networkProblem));
            }

            if (dlg != null) {
                dlg.dismiss();
            }
        }

    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
//        super.onBackPressed();
    }
}
