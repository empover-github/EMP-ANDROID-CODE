package com.activitytrack.utility;


import com.activitytrack.activity.BuildConfig;

public class MyConstants {

    public static final String TAB_HOME = "home";
    public static final String TAB_NONE = "none";
    public static final String TAB_PROFILE = "profile";
    public static final String TAB_YIELD_CALCULATOR = "yieldcalculator";
    public static final String TAB_DATASYNC = "datasync";
    public static final String TAB_3I = "3i";
    public static final String TAB_DIPSTICK = "dipstick";
    public static final String TAB_ABOUT = "about";
    public static final String TAB_LOGOUT = "logout";
    public static final String TAB_LIQUIDATION = "liquidation";
    public static final String TAB_CHANGE_PWD = "password";
    public static final String YES = "YES";
    public static final String NO = "NO";
    public static String ObservationImageName = "";
    public static final String APP_NAME = "ACTIVITY TRACKER";
    public static final String TAB_SURVEY = "startSurvey";
    public static final String TAB_DASHBOARD = "dashboards";
    public static final String TAB_SALIGE_FARMER = "farmerSegmention";

    public static final String RES100MSG = "success";
    public static final String RES101MSG = "not a valid user";
    public static final String RES102MSG = "season not active";
    public static final String RES103MSG = "Field not registered";
    public static final String RES104MSG = "Failure";
    public static final String RES201MSG = "OTP Invalid or Expired";
    public static final String RES202MSG = "OTP Expired";
    public static final String RES203MSG = "Mobile no not available";
    //new
    public static final String RES301MSG = "Old password doesn't match";
    public static final String RES302MSG = "Device mismatch";

    //demand generation activity names
    public static final String ACTIVITY_PDA = "pda";
    public static final String ACTIVITY_OSA = "osa";
    public static final String ACTIVITY_PSA = "psa";
    public static final String ACTIVITY_AGR = "agr";
    public static final String ACTIVITY_MDR = "mdr";

    //demand generation activity id's
    public static final int ACTIVITY_PDA_ID = 1;
    public static final int ACTIVITY_PSA_ID = 2;
    public static final int ACTIVITY_OSA_ID = 3;
    public static final int ACTIVITY_AGR_ID = 4;

    //crop name
    public static final String CROP_CORN = "corn";
    public static final String CROP_RICE = "rice";
    public static final String CROP_MILLET = "millet";
    public static final String CROP_MUSTARD = "mustard";

    //crop id's
    public static final int CROP_CORN_ID = 1;
    public static final int CROP_RICE_ID = 2;
    public static final int CROP_MILLET_ID = 3;
    public static final int CROP_MUSTARD_ID = 4;

    public static final String THEME_LIGHT = "lite";
    public static final String THEME_DARK = "dark";


    public static String AppURL = BuildConfig.AppURL;


    public static int DAYS_TO_DELETE_DATA = 3;
    //NEW
    public static final String SENDOTP_URL = "datasync/sendOTP";
    public static final String SENDOTP_VALIDATAOTP = "datasync/validateOTP";
    //public static final String MDR_TRANSACTION="datasync/mdrTransaction";
    public static final String MDR_TRANSACTION = "datasync/uploadATTransactionDataForEmp";
    public static final String MASTER_DATA = "datasync/downloadATMasterDataForEmp";// this one
    public static final String FORGOT_PASSWORD = "/datasync/forgotPassword";
    public static final String CHANGE_PASSWORD = "/datasync/changePassword";
    public static final String UPLOADED_VILLAGE_PROFILE_REFRESH = "datasync/getVillageProfileDataOfMDRInPHISalesEmpApp";

    public static final int POPULATION_CONST = 4047;
    public static final String PIONEER = "PIONEER";
    public static final String OTHER = "OTHER";
    public static final String SUBMIT = "Submit";

    public static final String GOT_LOCATION_MSG = "Got the location, now tap on submit";
    public static final String SUC_MSG = "Successfully Saved";

    public static final int CONNECTION_TIME_LIMIT = 2 * 60 * 1000;
    public static final String DEVICE_TYPE_ANDROID = "Android";
    public static final int UPDATE_CONNECTION_TIME_LIMIT = 3 * 1000;
    public static final int UPDATE_SOCKET_TIME_LIMIT = 3 * 1000;
    public static final String URL_VERSION_UPDATE = "datasync/checkForAppUpdate";

    public static final String UPDATE_AVAILBALE = "Update Available";
    public static final String PHASE_SU = "SU";


    public static final String PRIVACY_POLICY_WEB_URL = "http://www.privacy.DuPont.com";

    public static final String SHARED_PREFERENCE = "ActivityTracker";
    public static final String PUBLISH_ID = "u9oa4r6y/pRSbtJmeEZl6w==";
    /*** Publisher Id ***/
    public static final String APPLICATION_ID_INCEN = "GP2vI3npi9OAw6cxsMtfQJdbmlDeWo";
    /*** With incentization **/
    public static final String TAB_QRCODE = "attendancecode";
    public static final String TAB_PRAVAKTA_HA_GAIN = "pravaktahagain";
    public static final String TAB_GERMINATION_VERIFICATION = "germinationVerification";
    public static final String ACTIVITY_PRAVAKTA = "pravakta";
    public static final String VILLAGE_PROFILE_IMAGE_TYPE = "VillageProfileFarmer";
    public static final String FARMER_SEGMENTATION_IMAGE_TYPE = "FarmerSegmentation";
    public static final String MASTER_DATA_EMP_DIPSTICK = "datasync/downloadATMasterDataForTBL";
    public static final String UPLOAD_MDR_TRANSACTION = "datasync/uploadATTransactionDataForTBL";
    public static final String FARMER_SEGMENTATION__RICE_IMAGE_TYPE = "FarmerSegmentationRice";
    public static final String NESTLE_IMAGE_TYPE = "FarmerSegmentationSchool";

    public static final int NAV_ITEM_HEADER = 1000;

    //newly added
    public static final String RICE = "Rice";
    public static final String FARMER_SEGMENTATION = "Farmer Segmentation";
    public static final String FAW = "FAW Awareness";

    // kiran newly Added
    public static final String SPRING = "SPRING";
    public static final String CORN = "Corn";

    public static final String SelectHybrid1 = "Select Hybrid1";
    public static final String SelectHybrid2 = "Select Hybrid2";
    public static final String SelectHybrid3 = "Select Hybrid3";
    public static final String SelectHybrid4 = "Select Hybrid4";

    public static final String SelectSilageHybrid1 = "Select Silage Hybrid1";
    public static final String SelectSilageHybrid2 = "Select Silage Hybrid2";
    public static final String SelectSilageHybrid3 = "Select Silage Hybrid3";
    public static final String SelectSilageHybrid4 = "Select Silage Hybrid4";

    public static final String CompetitorHybrid1 = "Competitor Hybrid1";
    public static final String CompetitorHybrid2 = "Competitor Hybrid2";
    public static final String CompetitorHybrid3 = "Competitor Hybrid3";
    public static final String CompetitorHybrid4 = "Competitor Hybrid4";

}
