package com.activitytrack.activity;

import android.app.IntentService;
import android.content.Intent;


/**
 * Created by rambabu.a on 09-03-2018.
 */

public class UpLoadFileServicePravakta extends IntentService {

    public UpLoadFileServicePravakta(String name) {
        super(name);
    }

    public UpLoadFileServicePravakta() {
        super("UpLoad Service");
    }
    @Override
    protected void onHandleIntent( Intent intent) {

    }
}
