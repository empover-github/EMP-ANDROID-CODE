package com.activitytrack.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.models.IdNameModel;

import java.util.List;

/**
 * Created by Hareesh.A on 08-05-2017.
 */

public class CropAdapter extends BaseAdapter {
    List<IdNameModel> cuMobileData;
    Context context;

    public CropAdapter(Context context, List<IdNameModel> data) {
        this.cuMobileData = data;
        this.context = context;
    }

    @Override
    public int getCount() {
        return
                cuMobileData.size();
    }

    @Override
    public Object getItem(int position) {
        return cuMobileData.get(position);
    }



    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_at, null);
        }
        TextView textView = (TextView) convertView.findViewById(R.id.textView1);
        IdNameModel id = cuMobileData.get(position);
        textView.setText(id.getName());

        return convertView;
    }



    @Override
    public View getDropDownView(int position, View convertView,
                                ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_adapter_spinner_textview_align, null);
        }

        TextView textView = (TextView) convertView.findViewById(R.id.textView1);
        IdNameModel id = cuMobileData.get(position);
        textView.setText(id.getName());

        return convertView;

    }
}
