package com.activitytrack.dtos;

public class FarmerSegmentationNestleResponse implements DTO {
    private int code;
    private boolean success;
    private FarmerSegmentationNestleResponseDTO farmerSegmentationDairyDevResponse;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public FarmerSegmentationNestleResponseDTO getFarmerSegmentationDairyDevResponse() {
        return farmerSegmentationDairyDevResponse;
    }

    public void setFarmerSegmentationDairyDevResponse(FarmerSegmentationNestleResponseDTO farmerSegmentationDairyDevResponse) {
        this.farmerSegmentationDairyDevResponse = farmerSegmentationDairyDevResponse;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
