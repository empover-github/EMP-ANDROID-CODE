package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.adapter.PravaktaFarmerAdapter;
import com.activitytrack.daos.PravaktaFarmerDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.PravaktaFarmerDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rambabu.a on 01-03-2018.
 */

public class PravaktaFarmerActivity extends AppCompatActivity {
    private ImageView imageAddFarmer;
    private Bundle bundle;
    private long activityId;
    private List<PravaktaFarmerDTO> farmerDataList = new ArrayList<>();
    private PravaktaFarmerAdapter pravaktaFarmerAdapter;
    private ListView farmerDataListView;
    private String activity;
    private ActionBar actionBar;
    private static final int REQUEST_CODE = 100;
    private TextView mTitleTextView;
    private Button btnDone;
    private PravaktaFarmerActivity pravaktaFarmerActivity;
    private String farmerName;
    private List<String> cropTarget;
    private LinearLayout layoutDoneBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pravakat_farmer_layout);

        if (Utility.getCurrentTheme(PravaktaFarmerActivity.this).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(PravaktaFarmerActivity.this).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }

        pravaktaFarmerActivity = this;
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar_at);
        setSupportActionBar(mToolbar);
        mTitleTextView = (TextView) findViewById(R.id.header_text_at);
        mTitleTextView.setText("" + getResources().getString(R.string.farmer_entry));
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        imageAddFarmer = (ImageView) findViewById(R.id.ph_farmer_addBtn);
        farmerDataListView = (ListView) findViewById(R.id.listview_farmer);
        layoutDoneBtn = (LinearLayout) findViewById(R.id.layout_but_done);
        btnDone = (Button) findViewById(R.id.ph_farmer_submit);
        bundle = getIntent().getExtras();
        if (bundle != null) {
            activityId = bundle.getLong("activityId");
            activity = bundle.getString("activity");

        }

        farmerDataList = PravaktaFarmerDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(PravaktaFarmerActivity.this).getDBObject(0));
        if (farmerDataList.size() == 0) {
            Intent farmerIntent = new Intent(pravaktaFarmerActivity, PravaktaFarmerDataActivity.class);
            bundle.putLong("activityId", activityId);
            farmerIntent.putExtras(bundle);
            startActivityForResult(farmerIntent, REQUEST_CODE);
        } else {
            pravaktaFarmerAdapter = new PravaktaFarmerAdapter(PravaktaFarmerActivity.this, farmerDataList);
            farmerDataListView.setAdapter(pravaktaFarmerAdapter);
        }


        imageAddFarmer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                List<DTO> avalibleRecordsList = PravaktaFarmerDAO.getInstance().getRecordInfoByValue("activityId", "" + activityId, DBHandler.getInstance(PravaktaFarmerActivity.this).getDBObject(0));

                if (avalibleRecordsList != null) {
                    if (avalibleRecordsList != null && avalibleRecordsList.size() < 25) {
                        Intent farmerDataIntent = new Intent(PravaktaFarmerActivity.this, PravaktaFarmerDataActivity.class);
                        bundle.putLong("activityId", activityId);
                        farmerDataIntent.putExtras(bundle);
                        startActivityForResult(farmerDataIntent, REQUEST_CODE);
                    } else {
                        Utility.showAlert(PravaktaFarmerActivity.this, "", getResources().getString(R.string.al25far));
                    }
                }

            }
        });
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (farmerDataList.size() > 0) {
//                    layoutDoneBtn.setVisibility(View.VISIBLE);
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putLong("activityId", activityId);
                    intent.putExtras(bundle);
                    setResult(RESULT_OK, intent);
                    finish();


                }
            }
        });
        farmerDataListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                /*PravaktaFarmerDTO pravaktaFarmerDTO = (PravaktaFarmerDTO) farmerDataList.get(position);
                if (pravaktaFarmerDTO != null) {
                    farmerName = pravaktaFarmerDTO.getFarmerName();
                }
                showAlertToDeltedData(farmerName);*/

            }
        });
    }

    private void setResult(){
        setResult(RESULT_OK);
        finish();
    }

    private void showAlertToDeltedData(String data) {
        AlertDialog.Builder builder = new AlertDialog.Builder(PravaktaFarmerActivity.this);
        builder.setMessage("Do you want Delete " + data + " farmer data");
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                // deledted
                Toast.makeText(PravaktaFarmerActivity.this, "ur Clicked Deledted item", Toast.LENGTH_LONG).show();
                //saveData();
            }


        });

        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                farmerDataList.clear();
                List<PravaktaFarmerDTO> updatedFarmerData = PravaktaFarmerDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(PravaktaFarmerActivity.this).getDBObject(0));
                if (updatedFarmerData.size() == 0) {
                    onBackPressed();
                } else {
                    farmerDataList.addAll(updatedFarmerData);
                    pravaktaFarmerAdapter = new PravaktaFarmerAdapter(PravaktaFarmerActivity.this, farmerDataList);
                    farmerDataListView.setAdapter(pravaktaFarmerAdapter);

                }
            }
            if (resultCode == RESULT_CANCELED) {

            }
        }


        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onRestart() {
        super.onRestart();


    }


    @Override
    protected void onStart() {
        super.onStart();


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        setResult();
//        super.onBackPressed();


    }
}
