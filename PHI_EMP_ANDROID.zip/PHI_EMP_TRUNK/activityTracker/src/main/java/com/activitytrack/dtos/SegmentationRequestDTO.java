package com.activitytrack.dtos;

/**
 * Created by fatima.t on 04-12-2018.
 */

public class SegmentationRequestDTO implements DTO {
    private long id;
    private String year;
    private long season;
    private long crop;
    private String mobileNo;
    private String pincode;
    private String farmerName;
    private String district;
    private String village;
    private String block;
    private float totalPlanAc;
    private float planGrainAc;
    private float plansilageAc;
    private float phiGrainAc;
    private float phiSilageAc;
    private String grainHybrid1;
    private String grainHybrid2;
    private String grainHybrid3;
    private String grainHybrid4;
    private float grainHybridValue1;
    private float grainHybridValue2;
    private float grainHybridValue3;
    private float grainHybridValue4;
    private String silageHybrid1;
    private String silageHybrid2;
    private String silageHybrid3;
    private String silageHybrid4;
    private float silageHybridValue1;
    private float silageHybridValue2;
    private float silageHybridValue3;
    private float silageHybridValue4;
    private String geoLocation;
    private String grainServices;
    private String silageServices;
    private String localImagePath;
    private String isTBL;
    private String date;
    private int isSync;
    private long  mobileId ;
    private String grainCompetitorHybrid1;
    private double grainCompetitorHybridValue1;
    private String grainCompetitorHybrid2;
    private double grainCompetitorHybridValue2;
    private String grainCompetitorHybrid3;
    private double grainCompetitorHybridValue3;
    private String grainCompetitorHybrid4;
    private double grainCompetitorHybridValue4;
    private String grainCompetitorHybrid5;
    private double grainCompetitorHybridValue5;

    private String silageCompetitorHybrid1;
    private double silageCompetitorHybridValue1;
    private String silageCompetitorHybrid2;
    private double silageCompetitorHybridValue2;
    private String silageCompetitorHybrid3;
    private double silageCompetitorHybridValue3;
    private String silageCompetitorHybrid4;
    private double silageCompetitorHybridValue4;
    private String silageCompetitorHybrid5;
    private double silageCompetitorHybridValue5;

    //newly added
    private float hybridAc;
    private String typeOfIrrigation;

    //hybird rice matyrity
    private float maturity124Ac;
    private float maturity134Ac;
    private float maturity135Ac;
    //pioneer hybird
    private String riceHybrid1;
    private String riceHybrid2;
    private String riceHybrid3;
    private String riceHybrid4;
    private float riceHybridValue1;
    private float riceHybridValue2;
    private float riceHybridValue3;
    private float riceHybridValue4;

    private String riceServices;

    //competitor hybird plan
    private String riceCompetitorHybrid1;
    private double riceCompetitorHybridValue1;
    private String riceCompetitorHybrid2;
    private double riceCompetitorHybridValue2;
    private String riceCompetitorHybrid3;
    private double riceCompetitorHybridValue3;
    private String riceCompetitorHybrid4;
    private double riceCompetitorHybridValue4;
    private String directSowingRice;

    // feedBack spring_corn_1899
    private String visitedCornHybrid; // this is specially for 1899
    private String visitedCornHybridLike; // if yes what you like
    private String rateHybrid;
    private String shiftNextYrAcres;  // how much you increase hybrid acres sowing in next year

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public long getSeason() {
        return season;
    }

    public void setSeason(long season) {
        this.season = season;
    }

    public long getCrop() {
        return crop;
    }

    public void setCrop(long crop) {
        this.crop = crop;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public float getTotalPlanAc() {
        return totalPlanAc;
    }

    public void setTotalPlanAc(float totalPlanAc) {
        this.totalPlanAc = totalPlanAc;
    }

    public float getPlanGrainAc() {
        return planGrainAc;
    }

    public void setPlanGrainAc(float planGrainAc) {
        this.planGrainAc = planGrainAc;
    }

    public float getPlansilageAc() {
        return plansilageAc;
    }

    public void setPlansilageAc(float plansilageAc) {
        this.plansilageAc = plansilageAc;
    }

    public float getPhiGrainAc() {
        return phiGrainAc;
    }

    public void setPhiGrainAc(float phiGrainAc) {
        this.phiGrainAc = phiGrainAc;
    }

    public float getPhiSilageAc() {
        return phiSilageAc;
    }

    public void setPhiSilageAc(float phiSilageAc) {
        this.phiSilageAc = phiSilageAc;
    }

    public String getGrainHybrid1() {
        return grainHybrid1;
    }

    public void setGrainHybrid1(String grainHybrid1) {
        this.grainHybrid1 = grainHybrid1;
    }

    public String getGrainHybrid2() {
        return grainHybrid2;
    }

    public void setGrainHybrid2(String grainHybrid2) {
        this.grainHybrid2 = grainHybrid2;
    }

    public String getGrainHybrid3() {
        return grainHybrid3;
    }

    public void setGrainHybrid3(String grainHybrid3) {
        this.grainHybrid3 = grainHybrid3;
    }

    public String getGrainHybrid4() {
        return grainHybrid4;
    }

    public void setGrainHybrid4(String grainHybrid4) {
        this.grainHybrid4 = grainHybrid4;
    }

    public float getGrainHybridValue1() {
        return grainHybridValue1;
    }

    public void setGrainHybridValue1(float grainHybridValue1) {
        this.grainHybridValue1 = grainHybridValue1;
    }

    public float getGrainHybridValue2() {
        return grainHybridValue2;
    }

    public void setGrainHybridValue2(float grainHybridValue2) {
        this.grainHybridValue2 = grainHybridValue2;
    }

    public float getGrainHybridValue3() {
        return grainHybridValue3;
    }

    public void setGrainHybridValue3(float grainHybridValue3) {
        this.grainHybridValue3 = grainHybridValue3;
    }

    public float getGrainHybridValue4() {
        return grainHybridValue4;
    }

    public void setGrainHybridValue4(float grainHybridValue4) {
        this.grainHybridValue4 = grainHybridValue4;
    }

    public String getSilageHybrid1() {
        return silageHybrid1;
    }

    public void setSilageHybrid1(String silageHybrid1) {
        this.silageHybrid1 = silageHybrid1;
    }

    public String getSilageHybrid2() {
        return silageHybrid2;
    }

    public void setSilageHybrid2(String silageHybrid2) {
        this.silageHybrid2 = silageHybrid2;
    }

    public String getSilageHybrid3() {
        return silageHybrid3;
    }

    public void setSilageHybrid3(String silageHybrid3) {
        this.silageHybrid3 = silageHybrid3;
    }

    public String getSilageHybrid4() {
        return silageHybrid4;
    }

    public void setSilageHybrid4(String silageHybrid4) {
        this.silageHybrid4 = silageHybrid4;
    }

    public float getSilageHybridValue1() {
        return silageHybridValue1;
    }

    public void setSilageHybridValue1(float silageHybridValue1) {
        this.silageHybridValue1 = silageHybridValue1;
    }

    public float getSilageHybridValue2() {
        return silageHybridValue2;
    }

    public void setSilageHybridValue2(float silageHybridValue2) {
        this.silageHybridValue2 = silageHybridValue2;
    }

    public float getSilageHybridValue3() {
        return silageHybridValue3;
    }

    public void setSilageHybridValue3(float silageHybridValue3) {
        this.silageHybridValue3 = silageHybridValue3;
    }

    public float getSilageHybridValue4() {
        return silageHybridValue4;
    }

    public void setSilageHybridValue4(float silageHybridValue4) {
        this.silageHybridValue4 = silageHybridValue4;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public String getGrainServices() {
        return grainServices;
    }

    public void setGrainServices(String grainServices) {
        this.grainServices = grainServices;
    }

    public String getSilageServices() {
        return silageServices;
    }

    public void setSilageServices(String silageServices) {
        this.silageServices = silageServices;
    }

    public String getLocalImagePath() {
        return localImagePath;
    }

    public void setLocalImagePath(String localImagePath) {
        this.localImagePath = localImagePath;
    }

    public String getIsTBL() {
        return isTBL;
    }

    public void setIsTBL(String isTBL) {
        this.isTBL = isTBL;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public long getMobileId() {
        return mobileId;
    }

    public void setMobileId(long mobileId) {
        this.mobileId = mobileId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getGrainCompetitorHybrid1() {
        return grainCompetitorHybrid1;
    }

    public void setGrainCompetitorHybrid1(String grainCompetitorHybrid1) {
        this.grainCompetitorHybrid1 = grainCompetitorHybrid1;
    }

    public double getGrainCompetitorHybridValue1() {
        return grainCompetitorHybridValue1;
    }

    public void setGrainCompetitorHybridValue1(double grainCompetitorHybridValue1) {
        this.grainCompetitorHybridValue1 = grainCompetitorHybridValue1;
    }

    public String getGrainCompetitorHybrid2() {
        return grainCompetitorHybrid2;
    }

    public void setGrainCompetitorHybrid2(String grainCompetitorHybrid2) {
        this.grainCompetitorHybrid2 = grainCompetitorHybrid2;
    }

    public double getGrainCompetitorHybridValue2() {
        return grainCompetitorHybridValue2;
    }

    public void setGrainCompetitorHybridValue2(double grainCompetitorHybridValue2) {
        this.grainCompetitorHybridValue2 = grainCompetitorHybridValue2;
    }

    public String getGrainCompetitorHybrid3() {
        return grainCompetitorHybrid3;
    }

    public void setGrainCompetitorHybrid3(String grainCompetitorHybrid3) {
        this.grainCompetitorHybrid3 = grainCompetitorHybrid3;
    }

    public double getGrainCompetitorHybridValue3() {
        return grainCompetitorHybridValue3;
    }

    public void setGrainCompetitorHybridValue3(double grainCompetitorHybridValue3) {
        this.grainCompetitorHybridValue3 = grainCompetitorHybridValue3;
    }

    public String getGrainCompetitorHybrid4() {
        return grainCompetitorHybrid4;
    }

    public void setGrainCompetitorHybrid4(String grainCompetitorHybrid4) {
        this.grainCompetitorHybrid4 = grainCompetitorHybrid4;
    }

    public double getGrainCompetitorHybridValue4() {
        return grainCompetitorHybridValue4;
    }

    public void setGrainCompetitorHybridValue4(double grainCompetitorHybridValue4) {
        this.grainCompetitorHybridValue4 = grainCompetitorHybridValue4;
    }

    public String getSilageCompetitorHybrid1() {
        return silageCompetitorHybrid1;
    }

    public void setSilageCompetitorHybrid1(String silageCompetitorHybrid1) {
        this.silageCompetitorHybrid1 = silageCompetitorHybrid1;
    }

    public double getSilageCompetitorHybridValue1() {
        return silageCompetitorHybridValue1;
    }

    public void setSilageCompetitorHybridValue1(double silageCompetitorHybridValue1) {
        this.silageCompetitorHybridValue1 = silageCompetitorHybridValue1;
    }

    public String getSilageCompetitorHybrid2() {
        return silageCompetitorHybrid2;
    }

    public void setSilageCompetitorHybrid2(String silageCompetitorHybrid2) {
        this.silageCompetitorHybrid2 = silageCompetitorHybrid2;
    }

    public double getSilageCompetitorHybridValue2() {
        return silageCompetitorHybridValue2;
    }

    public void setSilageCompetitorHybridValue2(double silageCompetitorHybridValue2) {
        this.silageCompetitorHybridValue2 = silageCompetitorHybridValue2;
    }

    public String getSilageCompetitorHybrid3() {
        return silageCompetitorHybrid3;
    }

    public void setSilageCompetitorHybrid3(String silageCompetitorHybrid3) {
        this.silageCompetitorHybrid3 = silageCompetitorHybrid3;
    }

    public double getSilageCompetitorHybridValue3() {
        return silageCompetitorHybridValue3;
    }

    public void setSilageCompetitorHybridValue3(double silageCompetitorHybridValue3) {
        this.silageCompetitorHybridValue3 = silageCompetitorHybridValue3;
    }

    public String getSilageCompetitorHybrid4() {
        return silageCompetitorHybrid4;
    }

    public void setSilageCompetitorHybrid4(String silageCompetitorHybrid4) {
        this.silageCompetitorHybrid4 = silageCompetitorHybrid4;
    }

    public double getSilageCompetitorHybridValue4() {
        return silageCompetitorHybridValue4;
    }

    public void setSilageCompetitorHybridValue4(double silageCompetitorHybridValue4) {
        this.silageCompetitorHybridValue4 = silageCompetitorHybridValue4;
    }

    public float getHybridAc() {
        return hybridAc;
    }

    public void setHybridAc(float hybridAc) {
        this.hybridAc = hybridAc;
    }

    public String getTypeOfIrrigation() {
        return typeOfIrrigation;
    }

    public void setTypeOfIrrigation(String typeOfIrrigation) {
        this.typeOfIrrigation = typeOfIrrigation;
    }

    public float getMaturity124Ac() {
        return maturity124Ac;
    }

    public void setMaturity124Ac(float maturity124Ac) {
        this.maturity124Ac = maturity124Ac;
    }

    public float getMaturity134Ac() {
        return maturity134Ac;
    }

    public void setMaturity134Ac(float maturity134Ac) {
        this.maturity134Ac = maturity134Ac;
    }

    public float getMaturity135Ac() {
        return maturity135Ac;
    }

    public void setMaturity135Ac(float maturity135Ac) {
        this.maturity135Ac = maturity135Ac;
    }

    public String getRiceHybrid1() {
        return riceHybrid1;
    }

    public void setRiceHybrid1(String riceHybrid1) {
        this.riceHybrid1 = riceHybrid1;
    }

    public String getRiceHybrid2() {
        return riceHybrid2;
    }

    public void setRiceHybrid2(String riceHybrid2) {
        this.riceHybrid2 = riceHybrid2;
    }

    public String getRiceHybrid3() {
        return riceHybrid3;
    }

    public void setRiceHybrid3(String riceHybrid3) {
        this.riceHybrid3 = riceHybrid3;
    }

    public String getRiceHybrid4() {
        return riceHybrid4;
    }

    public void setRiceHybrid4(String riceHybrid4) {
        this.riceHybrid4 = riceHybrid4;
    }

    public float getRiceHybridValue1() {
        return riceHybridValue1;
    }

    public void setRiceHybridValue1(float riceHybridValue1) {
        this.riceHybridValue1 = riceHybridValue1;
    }

    public float getRiceHybridValue2() {
        return riceHybridValue2;
    }

    public void setRiceHybridValue2(float riceHybridValue2) {
        this.riceHybridValue2 = riceHybridValue2;
    }

    public float getRiceHybridValue3() {
        return riceHybridValue3;
    }

    public void setRiceHybridValue3(float riceHybridValue3) {
        this.riceHybridValue3 = riceHybridValue3;
    }

    public float getRiceHybridValue4() {
        return riceHybridValue4;
    }

    public void setRiceHybridValue4(float riceHybridValue4) {
        this.riceHybridValue4 = riceHybridValue4;
    }

    public String getRiceServices() {
        return riceServices;
    }

    public void setRiceServices(String riceServices) {
        this.riceServices = riceServices;
    }

    public String getRiceCompetitorHybrid1() {
        return riceCompetitorHybrid1;
    }

    public void setRiceCompetitorHybrid1(String riceCompetitorHybrid1) {
        this.riceCompetitorHybrid1 = riceCompetitorHybrid1;
    }

    public double getRiceCompetitorHybridValue1() {
        return riceCompetitorHybridValue1;
    }

    public void setRiceCompetitorHybridValue1(double riceCompetitorHybridValue1) {
        this.riceCompetitorHybridValue1 = riceCompetitorHybridValue1;
    }

    public String getRiceCompetitorHybrid2() {
        return riceCompetitorHybrid2;
    }

    public void setRiceCompetitorHybrid2(String riceCompetitorHybrid2) {
        this.riceCompetitorHybrid2 = riceCompetitorHybrid2;
    }

    public double getRiceCompetitorHybridValue2() {
        return riceCompetitorHybridValue2;
    }

    public void setRiceCompetitorHybridValue2(double riceCompetitorHybridValue2) {
        this.riceCompetitorHybridValue2 = riceCompetitorHybridValue2;
    }

    public String getRiceCompetitorHybrid3() {
        return riceCompetitorHybrid3;
    }

    public void setRiceCompetitorHybrid3(String riceCompetitorHybrid3) {
        this.riceCompetitorHybrid3 = riceCompetitorHybrid3;
    }

    public double getRiceCompetitorHybridValue3() {
        return riceCompetitorHybridValue3;
    }

    public void setRiceCompetitorHybridValue3(double riceCompetitorHybridValue3) {
        this.riceCompetitorHybridValue3 = riceCompetitorHybridValue3;
    }

    public String getRiceCompetitorHybrid4() {
        return riceCompetitorHybrid4;
    }

    public void setRiceCompetitorHybrid4(String riceCompetitorHybrid4) {
        this.riceCompetitorHybrid4 = riceCompetitorHybrid4;
    }

    public double getRiceCompetitorHybridValue4() {
        return riceCompetitorHybridValue4;
    }

    public void setRiceCompetitorHybridValue4(double riceCompetitorHybridValue4) {
        this.riceCompetitorHybridValue4 = riceCompetitorHybridValue4;
    }

    public String getDirectSowingRice() {
        return directSowingRice;
    }

    public void setDirectSowingRice(String directSowingRice) {
        this.directSowingRice = directSowingRice;
    }

    public String getVisitedCornHybrid() {
        return visitedCornHybrid;
    }

    public void setVisitedCornHybrid(String visitedCornHybrid) {
        this.visitedCornHybrid = visitedCornHybrid;
    }

    public String getVisitedCornHybridLike() {
        return visitedCornHybridLike;
    }

    public void setVisitedCornHybridLike(String visitedCornHybridLike) {
        this.visitedCornHybridLike = visitedCornHybridLike;
    }

    public String getRateHybrid() {
        return rateHybrid;
    }

    public void setRateHybrid(String rateHybrid) {
        this.rateHybrid = rateHybrid;
    }

    public String getShiftNextYrAcres() {
        return shiftNextYrAcres;
    }

    public void setShiftNextYrAcres(String shiftNextYrAcres) {
        this.shiftNextYrAcres = shiftNextYrAcres;
    }

    public String getGrainCompetitorHybrid5() {
        return grainCompetitorHybrid5;
    }

    public void setGrainCompetitorHybrid5(String grainCompetitorHybrid5) {
        this.grainCompetitorHybrid5 = grainCompetitorHybrid5;
    }

    public double getGrainCompetitorHybridValue5() {
        return grainCompetitorHybridValue5;
    }

    public void setGrainCompetitorHybridValue5(double grainCompetitorHybridValue5) {
        this.grainCompetitorHybridValue5 = grainCompetitorHybridValue5;
    }

    public String getSilageCompetitorHybrid5() {
        return silageCompetitorHybrid5;
    }

    public void setSilageCompetitorHybrid5(String silageCompetitorHybrid5) {
        this.silageCompetitorHybrid5 = silageCompetitorHybrid5;
    }

    public double getSilageCompetitorHybridValue5() {
        return silageCompetitorHybridValue5;
    }

    public void setSilageCompetitorHybridValue5(double silageCompetitorHybridValue5) {
        this.silageCompetitorHybridValue5 = silageCompetitorHybridValue5;
    }
}
