package com.activitytrack.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.CompoundButtonCompat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.customviews.ExpandableHeightGridView;
import com.activitytrack.daos.DemandSummaryDAO;
import com.activitytrack.daos.FarmerEntryDAO;
import com.activitytrack.daos.PDAActivityDAO;
import com.activitytrack.daos.RetailerInfoDAO;
import com.activitytrack.daos.YieldCalculatorCropsDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.DemandSummaryDTO;
import com.activitytrack.dtos.PDAActivityDTO;
import com.activitytrack.dtos.YieldCalculatorCropsDTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdtos.HybridMasterDTO;
import com.activitytrack.masterdtos.SeasonCalendarDTO;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.FragmentIntentIntegrator;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.CAMERA;

public class PDAFragment extends BaseFragment {

    private View view;

    private RelativeLayout osaLayout;
    private RelativeLayout psaLayout;
    private ImageView pdaIcon;
    private View pdaBottomIcon;
    private TextView pdaText;
    private LinearLayout yieldCalcuator;
    private LinearLayout addFarmers;
    private LinearLayout addRetailer;
    private View bottomDevider;
    private LinearLayout layoutPHyb;
    private LinearLayout layoutOHyb;

    private TextView tvNumberOfFarmers;
    private TextView tvAcresExposed;
    private TextView tvNumberofRetailers;
    private TextView tvCompetitorHybrid1;
    private TextView tv30r77Yield;
    private TextView tvCompetitorYield1;
    private TextView tvPincode;
    //newly added
    private TextView tvIsTblParticipated;
    //newly added for faw
    private TextView tvFaw;

    private EditText edtNumberOfFarmers;
    private EditText edtAcresExposed;
    private EditText edtNumberofRetailers;
    private EditText edtCompetitorHybrid1;
    private EditText edt30r77Yield;
    private EditText edtCompetitorYield1;
    private EditText edtPincode;

    private Button btnSubmit;
    private Button btnCouponButton;
    private LinearLayout mainLayout;
    private Spinner spnActivityType;
    private Spinner spnCropType;
    private Spinner spnHybridType;

    private ImageView addVillage;
    private ExpandableHeightGridView villagesGridView;
    private List<String> villagesList = new ArrayList<String>();

    private List<String> hybridNamesList = new ArrayList<String>();
    private List<DTO> hybridIdDTOList = new ArrayList<DTO>();
    private long hybridId;

    private List<String> cropNameList = new ArrayList<String>();
    private List<DTO> seasonDTOList = new ArrayList<DTO>();
    private long cropId;

    private String[] activitiesArray;

    private VillagesGridAdapter villagesGridAdapter;
    private TextView tvVillagesInvolved;

    private Dialog addVillageDialog;

    private long activityId;
    private TextView tvAddFarmersCount;
    private TextView tvAddRetailerCount;
    private TextView tvAddAttendanceCount;

    private LinearLayout addFarmersCount;
    private LinearLayout addRetailerCount;
    private RelativeLayout addAttendanceCount;

    private long seasonId;

    //public String currentLocation;
    private static final int REQUEST_CAMERA_PERMISSION = 100;

    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    private int scanCounter = 1;
    //	private StringBuilder farmerBarCodeBuilder;
    private String farmerBarCodeBuilder = null;
    private boolean isFinalScan;

    /* private String customerId,deviceId;
     private long mobileNo;*/
    // newly added
    private RadioGroup radioGroisTblParticipated;
    private RadioButton radioButisTblParticipatedYes, radioButisTblParticipatedNo;

    //newly added
    private TextView tvNumberOfPravaktas;
    private EditText edtNumberOfPravaktas;
    //newly added for faw
   // private RadioGroup radioGroFaw;
   // private RadioButton radioButFawYes, radioButFawNo;
    private CheckBox pda_faw_cb;
    private LinearLayout layoutFaw;
    private String cropName, hybridName;
    String val;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        cropId = bundle.getInt("cropId");

       /* List<DTO> userDtoList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if (userDtoList != null && userDtoList.size() > 0) {
            MdrMasterDTO loginDTO = (MdrMasterDTO) userDtoList.get(0);
            customerId = loginDTO.getLoginId();
            mobileNo = loginDTO.getMobileNo();
        }
        deviceId = Utility.getDeviceId(mActivity);*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.pda_fragment, container, false);

        osaLayout = (RelativeLayout) view.findViewById(R.id.activity_osa_layout);
        psaLayout = (RelativeLayout) view.findViewById(R.id.activity_psa_layout);
        pdaIcon = (ImageView) view.findViewById(R.id.activity_pda);
        pdaBottomIcon = view.findViewById(R.id.activity_pda_bottom);
        pdaText = (TextView) view.findViewById(R.id.activity_pdaText);

        pdaIcon.setImageResource(R.drawable.pda_top_menu_icon_f);
        pdaBottomIcon.setVisibility(View.VISIBLE);
        pdaText.setTextColor(getResources().getColor(R.color.tab_activeText_color));

        osaLayout.setOnClickListener(new OSATabListener());
        psaLayout.setOnClickListener(new PSATabListener());

        yieldCalcuator = (LinearLayout) view.findViewById(R.id.pda_yieldCalc);
        addFarmers = (LinearLayout) view.findViewById(R.id.pda_addFarmers);
        addRetailer = (LinearLayout) view.findViewById(R.id.pda_addRetailer);
        bottomDevider = view.findViewById(R.id.pda_bottomTab_devider);

        tvNumberOfFarmers = (TextView) view.findViewById(R.id.pda_numberOfFarmers_l);
        tvAcresExposed = (TextView) view.findViewById(R.id.pda_acresExposed_l);
        tvNumberofRetailers = (TextView) view.findViewById(R.id.pda_numberOfRetailers_l);
        tvCompetitorHybrid1 = (TextView) view.findViewById(R.id.pda_competitorHybrid1_l);
        tv30r77Yield = (TextView) view.findViewById(R.id.pda_30R77Yield_l);
        tvCompetitorYield1 = (TextView) view.findViewById(R.id.pda_competitorYeild_l);
        tvPincode = (TextView) view.findViewById(R.id.pda_pincode_l);
        btnCouponButton = (Button) view.findViewById(R.id.pda_couponButton);
        edtAcresExposed = (EditText) view.findViewById(R.id.pda_acresExposed);
//        edtAcresExposed.setFilters(new InputFilter[]{Utility.getDecimal()});

        edtNumberOfFarmers = (EditText) view.findViewById(R.id.pda_numberOfFarmers);
        edtNumberofRetailers = (EditText) view.findViewById(R.id.pda_numberOfRetailers);
        edtCompetitorHybrid1 = (EditText) view.findViewById(R.id.pda_competitorHybrid1);
        edt30r77Yield = (EditText) view.findViewById(R.id.pda_30R77Yield);
        edtCompetitorYield1 = (EditText) view.findViewById(R.id.pda_competitorYeild);
        edtPincode = (EditText) view.findViewById(R.id.pda_pincode);

        addVillage = (ImageView) view.findViewById(R.id.pda_addVillageBtn);
        villagesGridView = (ExpandableHeightGridView) view.findViewById(R.id.pda_villages_gridView);
        villagesGridView.setExpanded(true);

        spnActivityType = (Spinner) view.findViewById(R.id.pda_activityType);
        spnCropType = (Spinner) view.findViewById(R.id.pda_cropType);
        spnHybridType = (Spinner) view.findViewById(R.id.pda_hybridType);

        tvVillagesInvolved = (TextView) view.findViewById(R.id.pda_villages_involved);

        tvAddFarmersCount = (TextView) view.findViewById(R.id.pda_addFarmersCir);
        tvAddRetailerCount = (TextView) view.findViewById(R.id.pda_addRetailerCir);
        tvAddAttendanceCount = (TextView) view.findViewById(R.id.pda_attendance_count);

        addFarmersCount = (LinearLayout) view.findViewById(R.id.pda_circle_addFarmers_l);
        addRetailerCount = (LinearLayout) view.findViewById(R.id.pda_circle_addRetailer_l);
        addAttendanceCount = (RelativeLayout) view.findViewById(R.id.pda_attendance_count_l);

        layoutPHyb = (LinearLayout) view.findViewById(R.id.pda_pioneer_hybrid);
        layoutOHyb = (LinearLayout) view.findViewById(R.id.pda_competitor_hybrid);


        //newly added
        tvIsTblParticipated = (TextView) view.findViewById(R.id.pda_isTbl_l);
        radioGroisTblParticipated = (RadioGroup) view.findViewById(R.id.pda_isTbl_radio);
        radioButisTblParticipatedYes = (RadioButton) view.findViewById(R.id.pda_isTbl_radio_yes);
        radioButisTblParticipatedNo = (RadioButton) view.findViewById(R.id.pda_isTbl_radio_no);

        //newly added for Faw

        tvFaw = (TextView) view.findViewById(R.id.pda_isFaw_l);
        pda_faw_cb=(CheckBox)view.findViewById(R.id.pda_faw_cb);
        layoutFaw = (LinearLayout) view.findViewById(R.id.layout_pda_faw);

        btnSubmit = (Button) view.findViewById(R.id.pda_submit);

        if (villagesList != null && villagesList.size() > 0) {
            villagesGridAdapter = new VillagesGridAdapter(villagesList, mActivity);
            villagesGridView.setAdapter(villagesGridAdapter);
            villagesGridAdapter.notifyDataSetChanged();
        }

        activitiesArray = getResources().getStringArray(R.array.pda_spn1_items);

        ArrayAdapter<String> activitiesAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, activitiesArray);
        spnActivityType.setAdapter(activitiesAdapter);

        tvNumberOfPravaktas = (TextView) view.findViewById(R.id.pda_numberOfPravakta_l);
        edtNumberOfPravaktas = (EditText) view.findViewById(R.id.pda_numberOfPravakta);

        spnActivityType.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                if (position == 1) {
                    yieldCalcuator.setVisibility(View.VISIBLE);
                    bottomDevider.setVisibility(View.VISIBLE);
                    layoutPHyb.setVisibility(View.GONE);
                    layoutOHyb.setVisibility(View.GONE);

                    activityId = Utility.getActivityId(mActivity);
                    if (activityId == 0) {
                        btnSubmit.setEnabled(false);
                    } else {
                        List<DTO> pdaDTOList = PDAActivityDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));

                        if (pdaDTOList != null && pdaDTOList.size() > 0) {
                            //PDAActivityDTO pdaDto = (PDAActivityDTO) pdaDTOList.get(0);

                            //get retailer size same as farmer(above)
                            List<DTO> yieldCalList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                            if (yieldCalList != null && yieldCalList.size() > 0) {
                                //populate the calculated values
                                for (DTO mainDTO : yieldCalList) {
                                    YieldCalculatorCropsDTO dto = (YieldCalculatorCropsDTO) mainDTO;
                                    if (dto.getYieldFor().equals(MyConstants.PIONEER)) {
                                        edt30r77Yield.setText(String.valueOf(dto.getPerAcreYield()));
                                        layoutPHyb.setVisibility(View.VISIBLE);
                                    }
                                    if (dto.getYieldFor().equals(MyConstants.OTHER)) {
                                        edtCompetitorYield1.setText(String.valueOf(dto.getPerAcreYield()));
                                        layoutOHyb.setVisibility(View.VISIBLE);
                                    }
                                }
                                List<DTO> farmersList = FarmerEntryDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                                if (farmersList != null && farmersList.size() > 0) {
                                    btnSubmit.setEnabled(true);
                                }
                            } else {
                                //set empty to textView
                                edt30r77Yield.setText("");
                                edtCompetitorYield1.setText("");
                                layoutPHyb.setVisibility(View.GONE);
                                layoutOHyb.setVisibility(View.GONE);
                                btnSubmit.setEnabled(false);
                            }
                        } else {
                            btnSubmit.setEnabled(false);
                        }
                    }
                } else {
                    yieldCalcuator.setVisibility(View.GONE);
                    bottomDevider.setVisibility(View.GONE);
                    layoutPHyb.setVisibility(View.GONE);
                    layoutOHyb.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mainLayout = (LinearLayout) view.findViewById(R.id.pda_bg_laylout);

        seasonDTOList = SeasonCalendarDAO.getInstance().getRecordInfoByValue("activityId", "" + MyConstants.ACTIVITY_PDA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
        if (seasonDTOList != null && seasonDTOList.size() > 0) {
            cropNameList.clear();
            for (DTO dto : seasonDTOList) {
                if (cropNameList.size() == 0) {
                    cropNameList.add(getResources().getString(R.string.select_crop));
                }
                SeasonCalendarDTO seasonCalendarDTO = (SeasonCalendarDTO) dto;
                cropNameList.add(seasonCalendarDTO.getCropName());
                seasonId = seasonCalendarDTO.getSeasonId();
            }
        }

        ArrayAdapter<String> cropAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, cropNameList);
        spnCropType.setAdapter(cropAdapter);

        if (cropId != 0)
            for (int i = 0; i < seasonDTOList.size(); i++) {
                SeasonCalendarDTO dto = (SeasonCalendarDTO) seasonDTOList.get(i);
                if (cropId == dto.getCropId())
                    spnCropType.setSelection(i + 1);
            }

        spnCropType.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View view,
                                       int position, long id) {
                 /*  String  seasonEndDate = SeasonMasterDAO.getInstance().getSeasonEndDate(cropId,MyConstants.ACTIVITY_PDA_ID,DBHandler.getInstance(mActivity).getDBObject(0));
                    boolean res = Utility.isSeasonExpire(seasonEndDate,Utility.getCurrentformatedDate());
					 if(res)
					 {
						 Utility.showAlert(mActivity, "", getResources().getString(R.string.seasonExp));
					     return;
					 } */


                if (position > 0) {
                    SeasonCalendarDTO cropMasterDTO = (SeasonCalendarDTO) seasonDTOList.get(position - 1);
                    cropId = cropMasterDTO.getCropId();
                    hybridSpinnerPopulation(cropId);
                    //newly added for FAW
                    cropName = cropMasterDTO.getCropName();
                } else {
                    spnHybridType.setAdapter(null);
                    cropId = 0;
                }

                if (cropId > 0) {
                    String seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(cropId, MyConstants.ACTIVITY_PDA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
                    boolean res = Utility.isSeasonExpire(seasonEndDate, Utility.getCurrentformatedDate());
                    if (res) {
                        Utility.showAlert(mActivity, "", getResources().getString(R.string.seacal) + "PDA" + " of crop " + (Utility.getCropNameById((int) cropId)) + " is over");
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        setChange();

        activityId = Utility.getActivityId(mActivity);
        if (activityId == 0) {
            btnSubmit.setEnabled(false);
        } else {

            List<DTO> pdaDTOList = PDAActivityDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));

            if (pdaDTOList != null && pdaDTOList.size() > 0) {
                //PDAActivityDTO pdaDto = (PDAActivityDTO) pdaDTOList.get(0);
                //if(pdaDto.getActivityType() == null){
                List<DTO> farmersList = FarmerEntryDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                if (farmersList != null && farmersList.size() > 0) {
                    //set list size to textView
                    tvAddFarmersCount.setText(String.valueOf(farmersList.size()));
                    addFarmersCount.setVisibility(View.VISIBLE);
                } else {
                    //set empty to textView
                    tvAddFarmersCount.setText("");
                    addFarmersCount.setVisibility(View.INVISIBLE);
                }

                //get retailer size same as farmer(above)
                List<DTO> retailersList = RetailerInfoDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                if (retailersList != null && retailersList.size() > 0) {
                    //set list size to textView
                    tvAddRetailerCount.setText(String.valueOf(retailersList.size()));
                    addRetailerCount.setVisibility(View.VISIBLE);
                } else {
                    //set empty to textView
                    tvAddRetailerCount.setText("");
                    addRetailerCount.setVisibility(View.INVISIBLE);
                }

                if (farmersList.size() >= 1 && retailersList.size() >= 0) {
                    if (spnActivityType.getSelectedItemPosition() == 1) {
                        List<DTO> yieldCalcList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                        if (yieldCalcList != null && yieldCalcList.size() > 0) {
                            btnSubmit.setEnabled(true);
                        } else {
                            btnSubmit.setEnabled(false);
                        }
                    } else {
                        btnSubmit.setEnabled(true);
                    }

                }

                PDAActivityDTO dto = (PDAActivityDTO) pdaDTOList.get(0);
                //Dummy
                String barcodes = dto.getFarmerAttendanceDetails();
                if (barcodes != null && !barcodes.isEmpty() && barcodes.split(",").length > 0) {
                    tvAddAttendanceCount.setText(String.valueOf(barcodes.split(",").length));
                    addAttendanceCount.setVisibility(View.VISIBLE);
                } else {
                    tvAddAttendanceCount.setText("");
                    addAttendanceCount.setVisibility(View.INVISIBLE);
                }

//	        	}else{
//	        		btnSubmit.setEnabled(false);
//	        		activityId = 0;
//	        		Utility.setActivityId(0, mActivity);
                //}
            } else {
                btnSubmit.setEnabled(false);
                activityId = 0;
                Utility.setActivityId(0, mActivity);
            }
        }
        osaLayout.setOnClickListener(new OSATabListener());
        psaLayout.setOnClickListener(new PSATabListener());

        btnCouponButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    if (activityId == 0) {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        activityId = PDAActivityDAO.getInstance().insertActivity(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                        }
                    } else {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        pdaDto.setId(activityId);
                        PDAActivityDAO.getInstance().update(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    }
                } else {
                    Utility.showAlert(mActivity, "", validation);
                    return;
                }

                if (activityId > 0) {
                    if (android.os.Build.VERSION.SDK_INT >= 23) {
                        if (checkPermission()) {
                            scanQRCode(false);
                        }
                    } else {
                        scanQRCode(false);
                    }
                }
            }
        });

        btnSubmit.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    if (hybridId != 0) {
                        if (checkForLocation) {
                            if (location != null && location.length() > 0) {
                                attendanceCheck();
                            } else {
                                getCurrentLocation(mActivity);
                            }
                        } else {
                            attendanceCheck();
                        }
                    } else {
                        Utility.showAlert(mActivity, "Alert", getResources().getString(R.string.hybrids));
                    }

                } else {
                    Utility.showAlert(mActivity, "", validation);
                }
            }
        });

        yieldCalcuator.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        activityId = PDAActivityDAO.getInstance().insertActivity(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);

                        }
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        pdaDto.setId(activityId);
                        PDAActivityDAO.getInstance().update(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }

                if (activityId > 0) {
                    BaseFragment fragment = new YieldCalculatorCropsFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("activity", MyConstants.ACTIVITY_PDA);
                    bundle.putLong("activityId", activityId);
                    bundle.putLong("cropId", cropId);

                    //dummy data
                    bundle.putString("cmptName", "empover");

                    bundle.putString("cmptHybrid", edtCompetitorHybrid1.getText().toString().trim());

                    fragment.setArguments(bundle);
                    mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
                }
            }
        });


        addFarmers.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        activityId = PDAActivityDAO.getInstance().insertActivity(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                            /*DemandSummaryDTO summaryDTO = new DemandSummaryDTO();
                            summaryDTO.setActivity(MyConstants.ACTIVITY_PDA);
							summaryDTO.setActivityId(activityId);
							summaryDTO.setDate(Utility.getCurrentDateFrm());
							summaryDTO.setFarmers(pdaDto.getNumberOfFarmers());
							summaryDTO.setRetailers(pdaDto.getNumberOfRetailers());
							summaryDTO.setCropId(pdaDto.getCropId());
							summaryDTO.setHybridId(pdaDto.getHybridId());
							summaryDTO.setSeasonId(pdaDto.getSeasonId());
							
							DemandSummaryDAO.getInstance().insert(summaryDTO, DBHandler.getInstance(mActivity).getDBObject(1));*/
                        }
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        pdaDto.setId(activityId);
                        PDAActivityDAO.getInstance().update(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }

                if (activityId > 0) {
                    BaseFragment fragment = new FarmerEntryFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("activity", MyConstants.ACTIVITY_PDA);
                    bundle.putLong("activityId", activityId);
                    fragment.setArguments(bundle);
                    mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
                }
            }
        });


        addRetailer.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        activityId = PDAActivityDAO.getInstance().insertActivity(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                            /*DemandSummaryDTO summaryDTO = new DemandSummaryDTO();
                            summaryDTO.setActivity(MyConstants.ACTIVITY_PDA);
							summaryDTO.setActivityId(activityId);
							summaryDTO.setDate(Utility.getCurrentDateFrm());
							summaryDTO.setFarmers(pdaDto.getNumberOfFarmers());
							summaryDTO.setRetailers(pdaDto.getNumberOfRetailers());
							summaryDTO.setCropId(pdaDto.getCropId());
							summaryDTO.setHybridId(pdaDto.getHybridId());
							summaryDTO.setSeasonId(pdaDto.getSeasonId());
							
							DemandSummaryDAO.getInstance().insert(summaryDTO, DBHandler.getInstance(mActivity).getDBObject(1));*/
                        }
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PDAActivityDTO pdaDto = getDataObject();
                        pdaDto.setIsSync(0);
                        pdaDto.setId(activityId);
                        PDAActivityDAO.getInstance().update(pdaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }

                if (activityId > 0) {

                    BaseFragment fragment = new RetailerInfoFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("activity", MyConstants.ACTIVITY_PDA);
                    bundle.putLong("activityId", activityId);
                    fragment.setArguments(bundle);
                    mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
                }
            }
        });

        addVillage.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                showDialogToAddVillage2();

            }
        });

        return view;
    }

    private void hybridSpinnerPopulation(long cropId) {
        hybridIdDTOList = HybridMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(mActivity).getDBObject(0));

        if (hybridIdDTOList != null && hybridIdDTOList.size() > 0) {
            hybridNamesList.clear();
            for (DTO dto : hybridIdDTOList) {
                if (hybridNamesList.size() == 0) {
                    hybridNamesList.add(getResources().getString(R.string.select_hybrid));
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                hybridNamesList.add(hybridMasterDTO.getHybridName());
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.noHybrid));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    mActivity.popFragments();
                }
            });

            builder.create().show();
        }

        ArrayAdapter<String> hybridIdAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, hybridNamesList);

        spnHybridType.setAdapter(hybridIdAdapter);
        // spnHybridType.setSelection(Utility.getHybridType(mActivity)!=0?Utility.getHybridType(mActivity):0);
        spnHybridType.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position > 0) {
                    HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) hybridIdDTOList.get(position - 1);
                    hybridId = hybridMasterDTO.getId();

                    tv30r77Yield.setText((hybridMasterDTO.getHybridName() + " Yield(Qtl/Acer)"));
                    //newly added for hybirdName
                    hybridName = hybridMasterDTO.getHybridName();
                    //newly added for faw
                    if (cropId == (MyConstants.CROP_CORN_ID) && cropName.equalsIgnoreCase(MyConstants.CROP_CORN)) {
                        if (!hybridName.equalsIgnoreCase(MyConstants.FAW)) {
                            layoutFaw.setVisibility(View.VISIBLE);
                        } else {
                            layoutFaw.setVisibility(View.GONE);
                            if (pda_faw_cb.isChecked()){
                                pda_faw_cb.setChecked(false);
                            }
                        }

                    }

                } else {
                    tv30r77Yield.setText("Yield(Qtl/Acer)");
                    populate();
                    //newly added for faw
                    layoutFaw.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private String validateFields() {
        if (spnActivityType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.activity);

        if (spnCropType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.crop);

        if (spnHybridType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.hybrid);

        if (edtNumberOfFarmers.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.nofarmemp);

        if (edtAcresExposed.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.acresexpozer);
        //newly added
        if (edtNumberOfPravaktas.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.nopravemp);


       /* if (edtNumberOfPravaktas.getText().toString().trim().length() < 0)
            return "Number of pravaktas Number should not be zero";*/

        if (edtNumberofRetailers.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.noretemp);

        if (edtCompetitorHybrid1.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.comhybemp);

        if (edtPincode.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.pincode);

        if (edtPincode.getText().toString().trim().length() < 6) {
            return getResources().getString(R.string.zeropincode);
        }

        //newly added
        if (radioGroisTblParticipated.getCheckedRadioButtonId() == -1) {
            return getResources().getString(R.string.isTblEmpty);
        }

		/*if(edt30r77Yield.getText().toString().trim().length() == 0)
            return  getResources().getString(R.string.hybyiemp);
		
		if(edtCompetitorYield1.getText().toString().trim().length() == 0)
			return  getResources().getString(R.string.comyiemp);*/
        /*if(edtCouponScan1.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.couponUpload) ;*/

        return "";
    }


    private void attendanceCheck() {
        if (farmerBarCodeBuilder != null && !farmerBarCodeBuilder.isEmpty()) {
            showAlertToSave();
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setMessage(getResources().getString(R.string.scan_QR_confirmation));
            builder.setPositiveButton(getResources().getString(R.string.scan), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    scanQRCode(true);
                }
            });
            builder.setNegativeButton(getResources().getString(R.string.save), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    saveData();
                }
            });
            builder.create().show();
        }
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveData();
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void saveData() {
        PDAActivityDTO dto = getDataObject();

        long seasonCalId = SeasonCalendarDAO.getInstance().getSeasonCalId(MyConstants.ACTIVITY_PDA_ID, cropId, DBHandler.getInstance(mActivity).getDBObject(0));
        dto.setSeasonCalendarId(seasonCalId);
        String seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(cropId, MyConstants.ACTIVITY_PDA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
        boolean res = Utility.isSeasonExpire(seasonEndDate, Utility.getCurrentformatedDate());
        if (res) {
            Utility.showAlert(mActivity, "", getResources().getString(R.string.seasonExp));
            return;
        }

        long regionId = MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
        if (regionId != 0)
            dto.setRegionId(regionId);

        boolean updateAck = PDAActivityDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
        if (updateAck) {
            Utility.setActivityId(0, mActivity);
            DemandSummaryDTO summaryDTO = new DemandSummaryDTO();
            //summaryDTO.setActivity(MyConstants.ACTIVITY_PDA);
            summaryDTO.setActivityId(MyConstants.ACTIVITY_PDA_ID);
            summaryDTO.setSampleCount(1);
            summaryDTO.setHybridId(dto.getHybridId());
            summaryDTO.setCropId(dto.getCropId());
            summaryDTO.setSeasonCalendarId(dto.getSeasonCalendarId());
            summaryDTO.setSeasonId(dto.getSeasonId());
            summaryDTO.setRetailerCount(dto.getNumberOfRetailers());
            summaryDTO.setFarmerCount(dto.getNumberOfFarmers());
            summaryDTO.setIsSync(1);
            DemandSummaryDAO.getInstance().insert(summaryDTO, DBHandler.getInstance(mActivity).getDBObject(1));
            btnSubmit.setEnabled(false);
            Utility.showAlert(mActivity, null, MyConstants.SUC_MSG);
            clearFields();
            activityId = 0;
        }

    }

    private PDAActivityDTO getDataObject() {
        PDAActivityDTO dto = new PDAActivityDTO();
        dto.setActivityType(activitiesArray[spnActivityType.getSelectedItemPosition()]);
        dto.setCropId(cropId);
        dto.setHybridId(hybridId);
        dto.setNumberOfFarmers(Integer.valueOf(edtNumberOfFarmers.getText().toString().trim()));
        dto.setAcresExposed(Float.valueOf(edtAcresExposed.getText().toString().trim()));
        //newly added
        dto.setNumberOfPravaktas(Integer.valueOf(edtNumberOfPravaktas.getText().toString().trim()));
        dto.setNumberOfRetailers(Integer.valueOf(edtNumberofRetailers.getText().toString().trim()));
        dto.setCompetitorHybrid1(edtCompetitorHybrid1.getText().toString().trim());
        if (edt30r77Yield.getText().toString().length() > 0)
            dto.setHybridAcres(Float.valueOf(edt30r77Yield.getText().toString()));
        if (edtCompetitorYield1.getText().toString().length() > 0)
            dto.setCompetitorYield(Float.valueOf(edtCompetitorYield1.getText().toString().trim()));
       /* if (farmerBarCodeBuilder != null)
            dto.setFarmerBarCodeDetails(farmerBarCodeBuilder.toString());*/
        if (farmerBarCodeBuilder != null)
            dto.setFarmerAttendanceDetails(farmerBarCodeBuilder);
        dto.setVillagesInvolved(getVillages());
        dto.setDate(Utility.getCurrentDateAndTime());
        dto.setLocation(location);
        dto.setId(activityId);
        dto.setIsSync(1);
        dto.setSeasonId(seasonId);
        dto.setPincode(edtPincode.getText().toString().trim());
        //new added
        dto.setIsTBLParticipated(radioButtonText(radioGroisTblParticipated));

        //newly added for Faw
        if (layoutFaw.getVisibility() == View.VISIBLE) {
            if (pda_faw_cb.isChecked()){
                dto.setIsFAWDone(getResources().getString(R.string.YES));
            }else{
                dto.setIsFAWDone(getResources().getString(R.string.NO));
            }
        }else{
            dto.setIsFAWDone("");
        }


        return dto;
    }

    // newly added
    private String radioButtonText(RadioGroup group) {
        if (group != null) {
            int id = group.getCheckedRadioButtonId();
            RadioButton btn = (RadioButton) group.findViewById(id);
            String selection = (String) btn.getText();
            if (selection != null && !selection.isEmpty())
                return (selection);
            else return "";
        }
        return "";
    }

    private void setChange() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            tvNumberOfFarmers.setTextColor(Color.WHITE);
            tvAcresExposed.setTextColor(Color.WHITE);
            tvNumberofRetailers.setTextColor(Color.WHITE);
            tv30r77Yield.setTextColor(Color.WHITE);
            tvCompetitorHybrid1.setTextColor(Color.WHITE);
            tvCompetitorYield1.setTextColor(Color.WHITE);
            tvPincode.setTextColor(Color.WHITE);
            tvVillagesInvolved.setTextColor(Color.WHITE);

            //newly added
            tvIsTblParticipated.setTextColor(Color.WHITE);
            tvNumberOfPravaktas.setTextColor(Color.WHITE);
            //newly added for faw
            tvFaw.setTextColor(Color.WHITE);

            // newly added
            radioButisTblParticipatedYes.setTextColor(Color.WHITE);
            radioButisTblParticipatedNo.setTextColor(Color.WHITE);
            // newly added for faw
            pda_faw_cb.setTextColor(Color.WHITE);


            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedYes, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedNo, ColorStateList.valueOf(Color.WHITE));
                //newly added for Faw
                CompoundButtonCompat.setButtonTintList(pda_faw_cb, ColorStateList.valueOf(Color.WHITE));

            } else {
                radioButisTblParticipatedYes.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButisTblParticipatedNo.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                //newly added for faw
                pda_faw_cb.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
            }

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            tvNumberOfFarmers.setTextColor(Color.BLACK);
            tvAcresExposed.setTextColor(Color.BLACK);
            tvNumberofRetailers.setTextColor(Color.BLACK);
            tv30r77Yield.setTextColor(Color.BLACK);
            tvCompetitorHybrid1.setTextColor(Color.BLACK);
            tvCompetitorYield1.setTextColor(Color.BLACK);
            tvPincode.setTextColor(Color.BLACK);
            tvVillagesInvolved.setTextColor(Color.BLACK);

            //newly added
            tvIsTblParticipated.setTextColor(Color.BLACK);
            tvNumberOfPravaktas.setTextColor(Color.BLACK);
            //newly added for faw
            tvFaw.setTextColor(Color.BLACK);

            // newly added
            radioButisTblParticipatedYes.setTextColor(Color.BLACK);
            radioButisTblParticipatedNo.setTextColor(Color.BLACK);

            //newly added for Faw
            pda_faw_cb.setTextColor(Color.BLACK);

            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedYes, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedNo, ColorStateList.valueOf(Color.BLACK));

                //newly added for Faw
                CompoundButtonCompat.setButtonTintList(pda_faw_cb, ColorStateList.valueOf(Color.BLACK));
            } else {
                radioButisTblParticipatedYes.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButisTblParticipatedNo.setButtonTintList(ColorStateList.valueOf(Color.BLACK));

                //newly added for Faw
                pda_faw_cb.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
            }

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }

    }

    private void clearFields() {
        spnActivityType.setSelection(0);
        spnCropType.setSelection(0);
        spnHybridType.setSelection(0);
        edtNumberOfFarmers.setText("");
        tvAddAttendanceCount.setText("");
        edtAcresExposed.setText("");
        edtNumberofRetailers.setText("");
        edtCompetitorHybrid1.setText("");
        edtPincode.setText("");
        edt30r77Yield.setText("");
        edtCompetitorYield1.setText("");
        //newlya dded
        radioGroisTblParticipated.clearCheck();
        edtNumberOfPravaktas.setText("");
        addFarmersCount.setVisibility(View.INVISIBLE);
        addRetailerCount.setVisibility(View.INVISIBLE);
        addAttendanceCount.setVisibility(View.INVISIBLE);

        //newly addd for faw
        //Kiran Comment
        //radioGroFaw.clearCheck();

        pda_faw_cb.setChecked(false);

        villagesList.clear();
        //villagesGridView.setAdapter(null);
        if (villagesList != null && villagesList.size() > 0) {
            villagesGridAdapter = new VillagesGridAdapter(villagesList, mActivity);
            villagesGridView.setAdapter(villagesGridAdapter);
            villagesGridAdapter.notifyDataSetChanged();
        } else {
            villagesGridView.setAdapter(null);
        }

        checkForLocation = true;
        location = null;
        farmerBarCodeBuilder = null;
    }

    private void showDialogToAddVillage2() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        LayoutInflater inflater = (LayoutInflater)
                mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.add_village_dialog, null);

        builder.setView(layout);
        addVillageDialog = builder.create();
        addVillageDialog.setCancelable(false);
        addVillageDialog.show();

        Button save = (Button) addVillageDialog.findViewById(R.id.pda_dialog_save);
        Button cancel = (Button) addVillageDialog.findViewById(R.id.pda_dialog_cancel);
        final EditText edtVillageName = (EditText) addVillageDialog.findViewById(R.id.pda_dialog_villageName);

        save.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (edtVillageName.getText().toString().trim().length() > 0) {
                    villagesList.add(edtVillageName.getText().toString().trim());
                    if (villagesList != null && villagesList.size() > 0) {
                        villagesGridAdapter = new VillagesGridAdapter(villagesList, mActivity);
                        villagesGridView.setAdapter(villagesGridAdapter);
                        villagesGridAdapter.notifyDataSetChanged();
                    }
                    addVillageDialog.dismiss();
                } else {
                    Utility.showAlert(mActivity, "", getResources().getString(R.string.villname));
                }
            }
        });

        cancel.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                addVillageDialog.dismiss();
            }
        });
    }

    private class VillagesGridAdapter extends BaseAdapter {
        private List<String> list;
        private Context context;

        VillagesGridAdapter(List<String> list, Context context) {
            this.list = list;
            this.context = context;
        }

        @Override
        public int getCount() {

            return list.size();
        }

        @Override
        public Object getItem(int position) {

            return list.get(position);
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View gridItemView;

            if (convertView == null) {
                gridItemView = new View(context);
                // get layout from villages_grid_item.xml
                gridItemView = inflater.inflate(R.layout.villages_grid_item, null);

                // set value into textview
                TextView textView = (TextView) gridItemView.findViewById(R.id.pda_grid_villageName);

                ImageView closeImageView = (ImageView) gridItemView.findViewById(R.id.pda_grid_closeBtn);

                if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
                    closeImageView.setImageResource(R.drawable.village_name_close_btn);
                    textView.setTextColor(Color.WHITE);
                } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                    closeImageView.setImageResource(R.drawable.village_name_close_btn_lite);
                    textView.setTextColor(Color.BLACK);
                }

                textView.setText(list.get(position));

                closeImageView.setTag(position);

                closeImageView.setOnClickListener(new VillageCloseBtnLstn());

            } else {
                gridItemView = (View) convertView;
            }

            return gridItemView;
        }
    }

    private class VillageCloseBtnLstn implements OnClickListener {

        @Override
        public void onClick(View v) {
            int position = (Integer) v.getTag();
            villagesList.remove(position);
            if (villagesList != null && villagesList.size() > 0) {
                villagesGridAdapter = new VillagesGridAdapter(villagesList, mActivity);
                villagesGridView.setAdapter(villagesGridAdapter);
                villagesGridAdapter.notifyDataSetChanged();
            } else {
                villagesGridView.setAdapter(null);
            }
        }
    }

    private String getVillages() {
        String villages = "";
        if (villagesList != null && villagesList.size() > 0) {
            for (String village : villagesList) {

                villages += (villages.isEmpty() ? village : "," + village);
            }
        }

        return villages;
    }

    private class OSATabListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            if (activityId != 0) {
                showAlertToExitOSA();
            } else if (isDataAvailable()) {
                showAlertToExitOSA();
            } else {
                mActivity.popFragments();
                BaseFragment fragment = new OSAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }
        }

    }

    private class PSATabListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            if (activityId != 0) {
                showAlertToExitPSA();
            } else if (isDataAvailable()) {
                showAlertToExitPSA();
            } else {
                mActivity.popFragments();
                BaseFragment fragment = new PSAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }

        }
    }

    private void showAlertToExitOSA() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setTitle(getResources().getString(R.string.alert));
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activityId > 0)
                    clearLinkedData(activityId);
                mActivity.popFragments();
                BaseFragment fragment = new OSAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void showAlertToExitPSA() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setTitle(getResources().getString(R.string.exit));
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activityId > 0)
                    clearLinkedData(activityId);
                mActivity.popFragments();
                BaseFragment fragment = new PSAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void clearLinkedData(long activityId) {
        RetailerInfoDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
        FarmerEntryDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
        PDAActivityDAO.getInstance().deleteTableDataById(activityId, DBHandler.getInstance(mActivity).getDBObject(1));
        Utility.setActivityId(0, mActivity);

    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        if (isDataAvailable()) {
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }
        return true;
    }

    private void showAlertToExitScreen(final int callbackCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activityId > 0) {
                    RetailerInfoDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                    FarmerEntryDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                    YieldCalculatorCropsDAO.getInstance().deleteTableDataById(activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                    PDAActivityDAO.getInstance().deleteTableDataById(activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                    Utility.setActivityId(0, mActivity);
                }

                mActivity.onBackPressedCallBack(callbackCode);
            }
        });

        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    private boolean isDataAvailable() {
        if (activityId > 0) {
            List<DTO> farmersList = FarmerEntryDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (farmersList != null && farmersList.size() > 0) {
                return true;
            }

            List<DTO> retailersList = RetailerInfoDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PDA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (retailersList != null && retailersList.size() > 0) {
                return true;
            }

            List<DTO> yieldCalcList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (yieldCalcList != null && yieldCalcList.size() > 0) {
                return true;
            }

        }

        if (spnActivityType.getSelectedItemPosition() > 0)
            return true;

        if (spnHybridType.getSelectedItemPosition() > 0)
            return true;

        if (edtNumberOfFarmers.getText().toString().trim().length() > 0)
            return true;

        if (edtAcresExposed.getText().toString().trim().length() > 0)
            return true;
        //newly added
        if (edtNumberOfPravaktas.getText().toString().trim().length() > 0)
            return true;


        if (edtNumberofRetailers.getText().toString().trim().length() > 0)
            return true;

        if (edtCompetitorHybrid1.getText().toString().trim().length() > 0)
            return true;

        if (edt30r77Yield.getText().toString().trim().length() > 0)
            return true;

        if (edtCompetitorYield1.getText().toString().trim().length() > 0)
            return true;

        if (edtPincode.getText().toString().trim().length() > 0)
            return true;

        //newly added
        if (radioButisTblParticipatedYes.isChecked())
            return true;
        if (radioButisTblParticipatedNo.isChecked())
            return true;

		/*if(edtCouponScan1.getText().toString().trim().length() > 0)
            return true;*/
        return false;
    }

    private void populate() {
        if (activityId != 0) {
            List<DTO> dtoList = PDAActivityDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (dtoList != null && dtoList.size() > 0) {
                PDAActivityDTO dto = (PDAActivityDTO) dtoList.get(0);
                if (hybridIdDTOList != null && hybridIdDTOList.size() > 0) {
                    for (int i = 0; i < hybridIdDTOList.size(); i++) {
                        HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) hybridIdDTOList.get(i);
                        if (dto.getHybridId() == hybridMasterDTO.getId()) {
                            spnHybridType.setSelection(i + 1);
                            hybridId = hybridMasterDTO.getId();
                            tv30r77Yield.setText((hybridMasterDTO.getHybridName() + " Yield(Qtl/Acer)"));
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            if (!mGoogleApiClient.isConnected())
                mGoogleApiClient.connect();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mGoogleApiClient != null) {
            if (mGoogleApiClient.isConnected())
                mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onDestroy() {
        checkForLocation = true;
        location = null;
        super.onDestroy();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                DialogManager.showToast(mActivity, "Scan cancelled");
            } else {
                String scanResult = result.getContents();
                processCoupon(scanResult);
                if (isFinalScan)
                    saveData();
            }
        }
        /*if(resultCode == Activity.RESULT_OK)
        {
            String result = data.getStringExtra("SCAN_RESULT");
            currentScannedCouponCode = result.substring(0, result.indexOf('/'));
            processCoupon(scanCounter, AppConstants.COUPON_TYPE_SCANNED);
        }*/
    }

    private void processCoupon(String couponCode) {
        //Using StringBuilder getting string and spliting with coma

		/*if(farmerBarCodeBuilder != null && farmerBarCodeBuilder.toString().contains(couponCode))
            return;
		if(farmerBarCodeBuilder != null) {
			farmerBarCodeBuilder.append(",").append(couponCode);

		} else {
			farmerBarCodeBuilder = new StringBuilder();
			farmerBarCodeBuilder.append(couponCode);
		}
		String barcodes = farmerBarCodeBuilder.toString();
		if (barcodes != null && !barcodes.isEmpty() && barcodes.split(",").length > 0) {
			tvAddAttendanceCount.setText(String.valueOf(barcodes.split(",").length));
			addAttendanceCount.setVisibility(View.VISIBLE);
		} else{
			tvAddAttendanceCount.setText("");
			addAttendanceCount.setVisibility(View.INVISIBLE);
		}*/

// Reading the QRCode Request code and doing validation for QRCODE format

        /* String specialCharacters=" !#$%&'()*+,-./:;<=>?@[]^_`{|}~0123456789";
        String name="3_ saroj@";
        String str2[]=name.split("");

        for (int i=0;i<str2.length;i++)
        {
            if (specialCharacters.contains(str2[i]))
            {
                System.out.println("true");
                //break;
            }
            else
                System.out.println("false");
        }*/

        if (farmerBarCodeBuilder != null && farmerBarCodeBuilder.contains(couponCode))
            return;

        String specialCharacters = "_";
        String str2[] = couponCode.split("");
        int couponloop = 0;

        for (String aStr2 : str2) {
            if (specialCharacters.equals(aStr2)) {
                //System.out.println("true");
                couponloop++;
            }
        }

        if (couponloop == 3) {
            farmerBarCodeBuilder = couponCode;
        } else {
            DialogManager.showToast(mActivity, "Invalid QRcode");
        }

        /*if(couponCode.contains( "_" )){
            int var = 0;
            for (int i = 0; i <couponCode.length() ; i++) {

            }
            farmerBarCodeBuilder = couponCode;
        }else {
            DialogManager.showToast(mActivity,"Coupon is invalid");
        }*/

        if (farmerBarCodeBuilder != null && !farmerBarCodeBuilder.isEmpty()) {
            tvAddAttendanceCount.setText("1");
            addAttendanceCount.setVisibility(View.VISIBLE);
        } else {
            tvAddAttendanceCount.setText("");
            addAttendanceCount.setVisibility(View.INVISIBLE);
        }

    }

    /**
     * @fun showMoreScanDialog
     * @brief Method to show dialog to select the option for scanning more ot not
     */
    private void showMoreScanDialog(String st_currentCoupanScanCode) {

        DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
            @Override
            public void onOkClick() {
                scanQRCode(false);
            }

            @Override
            public void onCancelClick(View view) {

            }
        }, getString(R.string.moreScanHeader), getString(R.string.scanned_code) + " " + st_currentCoupanScanCode, getString(R.string.scan_more), getString(R.string.no));
        /*AlertDialog.Builder scanResultDialog = new AlertDialog.Builder(getContext());
        scanResultDialog.setTitle(R.string.moreScanHeader);
        scanResultDialog.setMessage(getString(R.string.scanned_code)+" "+st_currentCoupanScanCode);
        scanResultDialog.setPositiveButton(R.string.scan_more, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
//                        new IntentIntegrator(BarCodeScanner.this).initiateScan();
                scanQRCode();

            }
        });
        scanResultDialog.setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        scanResultDialog.show();*/
    }

    private void scanQRCode(boolean isFinalScan) {
        //	Log.d(TAG, "inside scanQRCode()");

        //mIntent = new Intent(mContext, QRScannerActivity.class);
//        mIntent = new Intent("com.google.zxing.client.android.SCAN");
//        startActivityForResult(mIntent, requestCode);

//		Log.d(TAG, "Exitting scanQRcode()");
        this.isFinalScan = isFinalScan;
        FragmentIntentIntegrator integrator = new FragmentIntentIntegrator(this);
        integrator.setPrompt("Scan a barcode");
        integrator.setCameraId(0);  // Use a specific camera of the device
        integrator.setOrientationLocked(true);
        integrator.setBeepEnabled(true);
        integrator.setCaptureActivity(ATCaptureActivityPortrait.class);
        integrator.initiateScan();

    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(mActivity.getApplicationContext(), CAMERA) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, CAMERA)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(mActivity, new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Need Camera Permission", "This app needs camera permission to scan barcode.", getString(R.string.grant), getString(R.string.cancel));

               /* AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                builder.setTitle("Need Camera Permission");
                builder.setMessage("This app needs camera permission to scan barcode.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(mActivity, new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        //finish();
                    }
                });
                builder.show();*/

            } else {

                // No explanation needed, we can request the permission.
                if (Utility.isFirstTime(mActivity)) {
                    Utility.setFirstTime(false, mActivity);
                    requestPermissions(new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);

                    // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                    // app-defined int constant. The callback method gets the
                    // result of the request.
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        requestPermissions(new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION_DENAIL);
                    }
                }
            }
        } else {
            return true;
        }

        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    scanQRCode(false);
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
            case REQUEST_CAMERA_PERMISSION_DENAIL: {
                showDialogToOpenSetting();
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private void showDialogToOpenSetting() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(mActivity, mActivity.getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {
        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", mActivity.getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        mActivity.finish();
    }

}
