package com.activitytrack.dtos;


public class AgronomyActivityDTO implements DTO {

    private long mobileId;
    private String location;
    private int isSync;
    private long cropId;
    private long hybridId;
    private String nameOfFarmer;
    private long mobileNoOfFarmer;
    private String plotType;
    private String competitorHybrid1;
    private String competitorHybrid2;
    private String date;
    private String category;
    private String samplingObjective;
    private long seasonId;
    private long seasonCalendarId;
    private String uploadedDate;
    private long regionId;
    private String pincode;
    private String dateOfSowing;
    private double acresSowed;

    public long getId() {
        return mobileId;
    }

    public void setId(long id) {
        this.mobileId = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public String getNameOfFarmer() {
        return nameOfFarmer;
    }

    public void setNameOfFarmer(String nameOfFarmer) {
        this.nameOfFarmer = nameOfFarmer;
    }

    public long getMobileNoOfFarmer() {
        return mobileNoOfFarmer;
    }

    public void setMobileNoOfFarmer(long mobileNoOfFarmer) {
        this.mobileNoOfFarmer = mobileNoOfFarmer;
    }

    public String getPlotType() {
        return plotType;
    }

    public void setPlotType(String plotType) {
        this.plotType = plotType;
    }

    public String getCompetitorHybrid1() {
        return competitorHybrid1;
    }

    public void setCompetitorHybrid1(String competitorHybrid1) {
        this.competitorHybrid1 = competitorHybrid1;
    }

    public String getCompetitorHybrid2() {
        return competitorHybrid2;
    }

    public void setCompetitorHybrid2(String competitorHybrid2) {
        this.competitorHybrid2 = competitorHybrid2;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public long getHybridId() {
        return hybridId;
    }

    public void setHybridId(long hybridId) {
        this.hybridId = hybridId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSamplingObjective() {
        return samplingObjective;
    }

    public void setSamplingObjective(String samplingObjective) {
        this.samplingObjective = samplingObjective;
    }

    public long getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(long seasonId) {
        this.seasonId = seasonId;
    }

    public long getSeasonCalendarId() {
        return seasonCalendarId;
    }

    public long getRegionId() {
        return regionId;
    }

    public void setRegionId(long regionId) {
        this.regionId = regionId;
    }

    public String getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(String uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public void setSeasonCalendarId(long seasonCalendarId) {
        this.seasonCalendarId = seasonCalendarId;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getDateOfSowing() {
        return dateOfSowing;
    }

    public void setDateOfSowing(String dateOfSowing) {
        this.dateOfSowing = dateOfSowing;
    }

    public double getAcresSowed() {
        return acresSowed;
    }

    public void setAcresSowed(double acresSowed) {
        this.acresSowed = acresSowed;
    }
}

     
 
