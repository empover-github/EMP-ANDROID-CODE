package com.activitytrack.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.graph.MyValueFormatter;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdaos.DipstickMasterDAO;
import com.activitytrack.masterdaos.SeasonMasterDAO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.masterdtos.SeasonMasterDTO;
import com.activitytrack.models.DipstickDashboardCounts;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ValueFormatter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

/**
 * Created by fatima.t on 24-04-2018.
 */

public class DipsticDashboardFragment extends BaseFragment /*implements AdapterView.OnItemSelectedListener*/ {
    private View view, xmlView1, xmlView2;
    private RelativeLayout mainLayout;
    private ScrollView dataAvailable;
    private Spinner yearSpn, seasonSpn;
    private TextView piTv, fuTv, noOfFarmersTv, piNoOfFarmersTv, fuNoOfFarmersTv, totalAcresTv, piTotalAcresTv, fuTotalAcresTv, totalHybridAcresTv, piTotalHybridAcresTv, fuTotalHybridAcresTv, totalPionHybridAcresTv, piTotalPionHybridAcresTv, fuTotalPionHybridAcresTv, sampleIssuedTv, sampleNotIssuedTv;
    private BarChart issuedBarChart, notIssuedBarChart;
    private ImageView addBtnImg;

    private List<DTO> seasonDTOList;
    private List<String> seasonNameList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.dipstic_dashboard_fragment, container, false);

        initializeViews();
        setTheme();

        return view;
    }

    private void initializeViews() {
        mainLayout = (RelativeLayout) view.findViewById(R.id.ddf_mainRL);
        dataAvailable = (ScrollView) view.findViewById(R.id.ddf_data_scrollview);
        yearSpn = (Spinner) view.findViewById(R.id.ddf_year_spn);
        seasonSpn = (Spinner) view.findViewById(R.id.ddf_season_spn);
        piTv = (TextView) view.findViewById(R.id.ddf_piTv);
        fuTv = (TextView) view.findViewById(R.id.ddf_fuTv);
        noOfFarmersTv = (TextView) view.findViewById(R.id.ddf_noOfFarmersTv);
        piNoOfFarmersTv = (TextView) view.findViewById(R.id.ddf_noOffarmPiTv);
        fuNoOfFarmersTv = (TextView) view.findViewById(R.id.ddf_noOffarmFuTv);
        totalAcresTv = (TextView) view.findViewById(R.id.ddf_totalAcresTv);
        piTotalAcresTv = (TextView) view.findViewById(R.id.ddf_totalAcresPiTv);
        fuTotalAcresTv = (TextView) view.findViewById(R.id.ddf_totalAcresFuTv);
        totalHybridAcresTv = (TextView) view.findViewById(R.id.ddf_totalHybridAcresTv);
        piTotalHybridAcresTv = (TextView) view.findViewById(R.id.ddf_totalHybridAcresPiTv);
        fuTotalHybridAcresTv = (TextView) view.findViewById(R.id.ddf_totalHybridAcresFuTv);
        totalPionHybridAcresTv = (TextView) view.findViewById(R.id.ddf_totalPioneerHybridAcresTv);
        piTotalPionHybridAcresTv = (TextView) view.findViewById(R.id.ddf_totalPioneerHybridAcresPiTv);
        fuTotalPionHybridAcresTv = (TextView) view.findViewById(R.id.ddf_totalPioneerHybridAcresFuTv);
        sampleIssuedTv = (TextView) view.findViewById(R.id.ddf_sampleIssuedTv);
        sampleNotIssuedTv = (TextView) view.findViewById(R.id.ddf_sampleNotIssuedTv);
        issuedBarChart = (BarChart) view.findViewById(R.id.ddf_sampleIssuedbarChart);
        notIssuedBarChart = (BarChart) view.findViewById(R.id.ddf_sampleNotIssuedbarChart);
        addBtnImg = (ImageView) view.findViewById(R.id.ddf_addBtn);
        xmlView1 = (View) view.findViewById(R.id.ddf_chart1_view);
        xmlView2 = (View) view.findViewById(R.id.ddf_chart2_view);


        addBtnImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // do your stuff
                BaseFragment fragment = new DipstickFragment();
                mActivity.pushFragments(MyConstants.TAB_DIPSTICK, fragment, false, true);
            }
        });

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        ArrayList<String> yearList = new ArrayList<>();
        yearList.add(String.valueOf(year));
        yearList.add(String.valueOf(year - 1));

        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, yearList);
        yearSpn.setAdapter(yearAdapter);

        seasonDTOList = SeasonMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if (seasonDTOList != null && seasonDTOList.size() > 0) {
            seasonNameList.clear();
            for (DTO dto : seasonDTOList) {
                if (seasonNameList.size() == 0) {
                    seasonNameList.add("Select Season");
                }
                SeasonMasterDTO cropMasterDTO = (SeasonMasterDTO) dto;
                seasonNameList.add(cropMasterDTO.getName());
            }
        }
        ArrayAdapter<String> seasonAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, seasonNameList);
        seasonSpn.setAdapter(seasonAdapter);

        setSampleIssuedBarChart();
        setSampleNotIssuedBarChart();
        dataAvailable.setVisibility(View.GONE);

       /* yearSpn.setOnItemSelectedListener(this);
        seasonSpn.setOnItemSelectedListener(this);*/

        yearSpn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                seasonSpn.setSelection(0);
                /*if (position > 0) {
                    seasonSpn.setSelection(0);
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }
                } else if (parent.getChildAt(0) != null) {
                    seasonSpn.setSelection(0);
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }
                }*/
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        seasonSpn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    /*if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }*/
                    DTO mainDTO = seasonDTOList.get(position - 1);
                    SeasonMasterDTO dto = (SeasonMasterDTO) mainDTO;
                    long seasonId = dto.getId();
                    setData(seasonId);
                } else if (parent.getChildAt(0) != null) {
                    /*if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }*/
                    dataAvailable.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

       /* yearSpn.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                seasonSpn.setSelection(0);
                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        seasonSpn.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position > 0) {
                    DTO mainDTO = seasonDTOList.get(position - 1);
                    SeasonMasterDTO dto = (SeasonMasterDTO) mainDTO;
                    long seasonId = dto.getId();
                    setData(seasonId);
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }
                } else {
                    dataAvailable.setVisibility(View.GONE);
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/


    }

    private void setTheme() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            piTv.setTextColor(Color.WHITE);
            fuTv.setTextColor(Color.WHITE);
            noOfFarmersTv.setTextColor(Color.WHITE);
            piNoOfFarmersTv.setTextColor(Color.WHITE);
            fuNoOfFarmersTv.setTextColor(Color.WHITE);
            totalAcresTv.setTextColor(Color.WHITE);
            piTotalAcresTv.setTextColor(Color.WHITE);
            fuTotalAcresTv.setTextColor(Color.WHITE);
            totalHybridAcresTv.setTextColor(Color.WHITE);
            piTotalHybridAcresTv.setTextColor(Color.WHITE);
            fuTotalHybridAcresTv.setTextColor(Color.WHITE);
            totalPionHybridAcresTv.setTextColor(Color.WHITE);
            piTotalPionHybridAcresTv.setTextColor(Color.WHITE);
            fuTotalPionHybridAcresTv.setTextColor(Color.WHITE);
            sampleIssuedTv.setTextColor(Color.WHITE);
            sampleNotIssuedTv.setTextColor(Color.WHITE);

            piTv.setBackgroundResource(R.drawable.edittext_bg_brown_white_outline);
            fuTv.setBackgroundResource(R.drawable.edittext_bg_green_white_outline);
            noOfFarmersTv.setBackgroundResource(R.drawable.edittext_bg_blue_white_outline);
            piNoOfFarmersTv.setBackgroundResource(R.drawable.textview_bg_white_outline);
            fuNoOfFarmersTv.setBackgroundResource(R.drawable.textview_bg_white_outline);
            totalAcresTv.setBackgroundResource(R.drawable.edittext_bg_blue_white_outline);
            piTotalAcresTv.setBackgroundResource(R.drawable.textview_bg_white_outline);
            fuTotalAcresTv.setBackgroundResource(R.drawable.textview_bg_white_outline);
            totalHybridAcresTv.setBackgroundResource(R.drawable.edittext_bg_blue_white_outline);
            piTotalHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_white_outline);
            fuTotalHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_white_outline);
            totalPionHybridAcresTv.setBackgroundResource(R.drawable.edittext_bg_blue_white_outline);
            piTotalPionHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_white_outline);
            fuTotalPionHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_white_outline);

//            xmlView1.setBackgroundColor(Color.WHITE);
//            xmlView2.setBackgroundColor(Color.WHITE);
//            yearSpn.setBackgroundResource(R.drawable.spinner_bg_img);
//            seasonSpn.setBackgroundResource(R.drawable.spinner_bg_img);
            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            piTv.setTextColor(Color.WHITE);
            fuTv.setTextColor(Color.WHITE);
            noOfFarmersTv.setTextColor(Color.WHITE);
            piNoOfFarmersTv.setTextColor(Color.BLACK);
            fuNoOfFarmersTv.setTextColor(Color.BLACK);
            totalAcresTv.setTextColor(Color.WHITE);
            piTotalAcresTv.setTextColor(Color.BLACK);
            fuTotalAcresTv.setTextColor(Color.BLACK);
            totalHybridAcresTv.setTextColor(Color.WHITE);
            piTotalHybridAcresTv.setTextColor(Color.BLACK);
            fuTotalHybridAcresTv.setTextColor(Color.BLACK);
            totalPionHybridAcresTv.setTextColor(Color.WHITE);
            piTotalPionHybridAcresTv.setTextColor(Color.BLACK);
            fuTotalPionHybridAcresTv.setTextColor(Color.BLACK);
            sampleIssuedTv.setTextColor(Color.BLACK);
            sampleNotIssuedTv.setTextColor(Color.BLACK);

            piTv.setBackgroundResource(R.drawable.edittext_bg_brown_black_outline);
            fuTv.setBackgroundResource(R.drawable.edittext_bg_green_black_outline);
            noOfFarmersTv.setBackgroundResource(R.drawable.edittext_bg_blue_black_outline);
            piNoOfFarmersTv.setBackgroundResource(R.drawable.textview_bg_black_outline);
            fuNoOfFarmersTv.setBackgroundResource(R.drawable.textview_bg_black_outline);
            totalAcresTv.setBackgroundResource(R.drawable.edittext_bg_blue_black_outline);
            piTotalAcresTv.setBackgroundResource(R.drawable.textview_bg_black_outline);
            fuTotalAcresTv.setBackgroundResource(R.drawable.textview_bg_black_outline);
            totalHybridAcresTv.setBackgroundResource(R.drawable.edittext_bg_blue_black_outline);
            piTotalHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_black_outline);
            fuTotalHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_black_outline);
            totalPionHybridAcresTv.setBackgroundResource(R.drawable.edittext_bg_blue_black_outline);
            piTotalPionHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_black_outline);
            fuTotalPionHybridAcresTv.setBackgroundResource(R.drawable.textview_bg_black_outline);

//            xmlView1.setBackgroundColor(Color.BLACK);
//            xmlView2.setBackgroundColor(Color.BLACK);

//            yearSpn.setBackgroundResource(R.drawable.spinner_bg_img_light);
//            seasonSpn.setBackgroundResource(R.drawable.spinner_bg_img_light);
            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }
    }

    private void setSampleIssuedBarChart() {

        issuedBarChart.setDrawBarShadow(false);
        issuedBarChart.setDrawValueAboveBar(true);
        issuedBarChart.setDescription("");
        issuedBarChart.setMaxVisibleValueCount(60);
        issuedBarChart.setPinchZoom(true);
        issuedBarChart.setDrawGridBackground(false);
        issuedBarChart.getLegend().setEnabled(false);

        XAxis xAxis = issuedBarChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setSpaceBetweenLabels(2);

        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            xAxis.setTextColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            xAxis.setTextColor(Color.BLACK);
        }
        ValueFormatter custom = new MyValueFormatter();

        YAxis leftAxis = issuedBarChart.getAxisLeft();
        leftAxis.setDrawGridLines(false);
        leftAxis.setLabelCount(4);
        leftAxis.setValueFormatter(custom);
        leftAxis.setPosition(YAxis.YAxisLabelPosition.OUTSIDE_CHART);
        leftAxis.setSpaceTop(15f);

        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            leftAxis.setTextColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            leftAxis.setTextColor(Color.BLACK);
        }

        YAxis rightAxis = issuedBarChart.getAxisRight();
        rightAxis.setEnabled(false);
        rightAxis.setDrawGridLines(false);

        Legend l = issuedBarChart.getLegend();
        l.setPosition(Legend.LegendPosition.BELOW_CHART_LEFT);
        l.setForm(Legend.LegendForm.SQUARE);
        l.setFormSize(9f);
        l.setTextSize(11f);
        l.setXEntrySpace(4f);
    }

    private void setSampleNotIssuedBarChart() {

        notIssuedBarChart.setDrawBarShadow(false);
        notIssuedBarChart.setDrawValueAboveBar(true);
        notIssuedBarChart.setDescription("");
        notIssuedBarChart.setMaxVisibleValueCount(60);
        notIssuedBarChart.setPinchZoom(true);
        notIssuedBarChart.setDrawGridBackground(false);
        notIssuedBarChart.getLegend().setEnabled(false);

        XAxis xAxis = notIssuedBarChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setSpaceBetweenLabels(2);

        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            xAxis.setTextColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            xAxis.setTextColor(Color.BLACK);
        }
        ValueFormatter custom = new MyValueFormatter();

        YAxis leftAxis = notIssuedBarChart.getAxisLeft();
        leftAxis.setDrawGridLines(false);
        leftAxis.setLabelCount(4);
        leftAxis.setValueFormatter(custom);
        leftAxis.setPosition(YAxis.YAxisLabelPosition.OUTSIDE_CHART);
        leftAxis.setSpaceTop(15f);

        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            leftAxis.setTextColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            leftAxis.setTextColor(Color.BLACK);
        }

        YAxis rightAxis = notIssuedBarChart.getAxisRight();
        rightAxis.setEnabled(false);
        rightAxis.setDrawGridLines(false);

        Legend l = notIssuedBarChart.getLegend();
        l.setPosition(Legend.LegendPosition.BELOW_CHART_LEFT);
        l.setForm(Legend.LegendForm.SQUARE);
        l.setFormSize(9f);
        l.setTextSize(11f);
        l.setXEntrySpace(4f);
    }

    public void setDataToIssuedBarChart(LinkedHashMap<String, Integer> graphDataMap, LinkedHashMap<String, Integer> graphDataMap2) {

        Set<String> keys1 = graphDataMap.keySet();
        ATBuildLog.e("DipsticDashboard", "setOne" + keys1);

        List<String> xVals1 = new ArrayList<String>();
        List<Integer> valuesList1 = new ArrayList<>();
        for (String key : keys1) {
            xVals1.add(key);
            valuesList1.add(graphDataMap.get(key));
        }
        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();

        for (int i = 0; i < valuesList1.size(); i++) {
            yVals1.add(new BarEntry(valuesList1.get(i), i));
        }

        BarDataSet set1 = new BarDataSet(yVals1, "DataSet1");
        set1.setBarSpacePercent(35f);

        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            set1.setValueTextColor(Color.WHITE);
            set1.setColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            set1.setColor(Color.rgb(195, 195, 195));
            set1.setValueTextColor(Color.BLACK);
        }

        Set<String> keys2 = graphDataMap2.keySet();
        ATBuildLog.e("DipsticDashboard", "setTwo" + keys2);

//        List<String> xVals2 = new ArrayList<String>();
        List<Integer> valuesList2 = new ArrayList<>();

        for (String key : keys2) {
//            xVals2.add(key);  // not using at all
            valuesList2.add(graphDataMap2.get(key));
        }

        ArrayList<BarEntry> yVals2 = new ArrayList<BarEntry>();

        for (int i = 0; i < valuesList2.size(); i++) {
            yVals2.add(new BarEntry(valuesList2.get(i), i));
        }

        BarDataSet set2 = new BarDataSet(yVals2, "DataSet2");

        set2.setBarSpacePercent(35f);
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            set2.setValueTextColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            set2.setValueTextColor(Color.BLACK);
        }

        set2.setColor(Color.rgb(66, 119, 48));

        ArrayList<BarDataSet> dataSets = new ArrayList<BarDataSet>();
        dataSets.add(set1);
        dataSets.add(set2);

        BarData data = new BarData(xVals1, dataSets);
        data.setValueTextSize(10f);
        issuedBarChart.setData(data);

    }

    public void setDataToNotIssuedBarChart(LinkedHashMap<String, Integer> graphDataMap, LinkedHashMap<String, Integer> graphDataMap2) {

        Set<String> keys1 = graphDataMap.keySet();
        ATBuildLog.e("DipsticDashboard", "setOne" + keys1);

        List<String> xVals1 = new ArrayList<String>();
        List<Integer> valuesList1 = new ArrayList<>();
        for (String key : keys1) {
            xVals1.add(key);
            valuesList1.add(graphDataMap.get(key));
        }
        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();

        for (int i = 0; i < valuesList1.size(); i++) {
            yVals1.add(new BarEntry(valuesList1.get(i), i));
        }

        BarDataSet set1 = new BarDataSet(yVals1, "DataSet1");
        set1.setBarSpacePercent(35f);

        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            set1.setValueTextColor(Color.WHITE);
            set1.setColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            set1.setColor(Color.rgb(195, 195, 195));
            set1.setValueTextColor(Color.BLACK);
        }

        Set<String> keys2 = graphDataMap2.keySet();
        ATBuildLog.e("DipsticDashboard", "setTwo" + keys2);

//        List<String> xVals2 = new ArrayList<String>();
        List<Integer> valuesList2 = new ArrayList<>();

        for (String key : keys2) {
//            xVals2.add(key);  // not using at all
            valuesList2.add(graphDataMap2.get(key));
        }

        ArrayList<BarEntry> yVals2 = new ArrayList<BarEntry>();

        for (int i = 0; i < valuesList2.size(); i++) {
            yVals2.add(new BarEntry(valuesList2.get(i), i));
        }

        BarDataSet set2 = new BarDataSet(yVals2, "DataSet2");

        set2.setBarSpacePercent(35f);
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            set2.setValueTextColor(Color.WHITE);
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            set2.setValueTextColor(Color.BLACK);
        }

        set2.setColor(Color.rgb(66, 119, 48));

        ArrayList<BarDataSet> dataSets = new ArrayList<BarDataSet>();
        dataSets.add(set1);
        dataSets.add(set2);

        BarData data = new BarData(xVals1, dataSets);
        data.setValueTextSize(10f);
        notIssuedBarChart.setData(data);

    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        mActivity.onBackPressedCallBack(callbackCode);
        return true;
    }

    /*@Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int i = parent.getId();

        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
        } else {
            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
        }

        if (i == R.id.ddf_year_spn) {
            seasonSpn.setSelection(0);
        } else if (i == R.id.ddf_season_spn) {
            if (position > 0) {
                DTO mainDTO = seasonDTOList.get(position - 1);
                SeasonMasterDTO dto = (SeasonMasterDTO) mainDTO;
                long seasonId = dto.getId();
                setData(seasonId);
            } else {
                dataAvailable.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }*/

    private void setData(long seasonId) {
        DipstickDashboardCounts modelPI = DipstickMasterDAO.getInstance().getDipstickDashboardCounts("PI", yearSpn.getSelectedItem().toString(), seasonId, DBHandler.getInstance(mActivity).getDBObject(0));
        DipstickDashboardCounts modelFU = DipstickMasterDAO.getInstance().getDipstickDashboardCounts("FU", yearSpn.getSelectedItem().toString(), seasonId, DBHandler.getInstance(mActivity).getDBObject(0));

        issuedBarChart.clear();
        notIssuedBarChart.clear();
        if (modelPI != null || modelFU != null) {
            dataAvailable.setVisibility(View.VISIBLE);

            piNoOfFarmersTv.setText("" + modelPI.getNoOfFarmers());
            piTotalAcresTv.setText("" + modelPI.getTotalNoOfAcres());
            piTotalHybridAcresTv.setText("" + modelPI.getTotalNoOfHybridAcres());
            piTotalPionHybridAcresTv.setText("" + modelPI.getTotalPioneerHybridAcres());

            fuNoOfFarmersTv.setText("" + modelFU.getNoOfFarmers());
            fuTotalAcresTv.setText("" + modelFU.getTotalNoOfAcres());
            fuTotalHybridAcresTv.setText("" + modelFU.getTotalNoOfHybridAcres());
            fuTotalPionHybridAcresTv.setText("" + modelFU.getTotalPioneerHybridAcres());

            getDataForSampleIssued(seasonId);
            getDataForSamleNotIssued(seasonId);

        }
    }

    private void getDataForSampleIssued(long seasonId) {
        List<DTO> cropDTOList = CropMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        List<Integer> piList = null;
        List<Integer> fuList = null;
        LinkedHashMap<String, Integer> issuedDataSet1 = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> issuedDataSet2 = new LinkedHashMap<>();
        for (DTO dto : cropDTOList) {
            CropMasterDTO cropMasterDTO = (CropMasterDTO) dto;
            piList = DipstickMasterDAO.getInstance().getIssuedList(yearSpn.getSelectedItem().toString(), seasonId, cropMasterDTO.getId(), 1, "PI", DBHandler.getInstance(mActivity).getDBObject(0));
            fuList = DipstickMasterDAO.getInstance().getIssuedList(yearSpn.getSelectedItem().toString(), seasonId, cropMasterDTO.getId(), 1, "FU", DBHandler.getInstance(mActivity).getDBObject(0));
            if (piList != null || fuList != null) {
                issuedDataSet1.put(cropMasterDTO.getName(), piList.get(0));
                issuedDataSet2.put(cropMasterDTO.getName(), fuList.get(0));
            }

        }

        if (issuedDataSet1 != null || issuedDataSet2 != null)
            setDataToIssuedBarChart(issuedDataSet1, issuedDataSet2);
    }

    private void getDataForSamleNotIssued(long seasonId) {
        List<DTO> cropDTOList = CropMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        List<Integer> piList = null;
        List<Integer> fuList = null;
        LinkedHashMap<String, Integer> notIssuedDataSet1 = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> notIssuedDataSet2 = new LinkedHashMap<>();
        for (DTO dto : cropDTOList) {
            CropMasterDTO cropMasterDTO = (CropMasterDTO) dto;
            piList = DipstickMasterDAO.getInstance().getIssuedList(yearSpn.getSelectedItem().toString(), seasonId, cropMasterDTO.getId(), 0, "PI", DBHandler.getInstance(mActivity).getDBObject(0));
            fuList = DipstickMasterDAO.getInstance().getIssuedList(yearSpn.getSelectedItem().toString(), seasonId, cropMasterDTO.getId(), 0, "FU", DBHandler.getInstance(mActivity).getDBObject(0));
            if (piList != null || fuList != null) {
                notIssuedDataSet1.put(cropMasterDTO.getName(), piList.get(0));
                notIssuedDataSet2.put(cropMasterDTO.getName(), fuList.get(0));
            }

        }

        if (notIssuedDataSet1 != null || notIssuedDataSet2 != null)
            setDataToNotIssuedBarChart(notIssuedDataSet1, notIssuedDataSet2);
    }
}
