package com.activitytrack.dtos;

import com.activitytrack.utility.Utility;


public class DipstickDTO implements DTO {
    private long id;
    private String phase;
    private int year;
    private Long seasonId;
    private Long cropId;
    private boolean wasSampleIssuedLastSeason;
    private Long sampleHybridId;
    private String farmerName;
    private String farmerMobileNo;
    private Float cropArea, hybridCropArea, otherCropArea, pioneerHybrid1Area, pioneerHybrid2Area, pioneerHybrid3Area, pioneerHybrid4Area, competitorHybrid1Area, competitorHybrid2Area, competitorHybrid3Area, competitorHybrid4Area, competitorHybrid5Area, f2Acreages, seedSettingIssue;
    private String date;
    private long regionId = -1;
    private String geoLocation;
    private int isSync = -1;
    private String uploadedDate;
    private String pioneerHybrid1;
    private String pioneerHybrid2;
    private String pioneerHybrid3;
    private String pioneerHybrid4;
    private String competitorHybrid1Name;
    private String competitorHybrid2Name;
    private String competitorHybrid3Name;
    private String competitorHybrid4Name;
    private String competitorHybrid5Name;
    private Long otherCrop1;
    private Long otherCrop2;
    private double otherCropArea1;
    private double otherCropArea2;
    private String userType;
    //newly added
    private Float pioneerHybrid1SeedSettingIssue;
    private Float pioneerHybrid2SeedSettingIssue;
    private Float pioneerHybrid3SeedSettingIssue;
    private Float pioneerHybrid4SeedSettingIssue;

    private Float competitorHybrid1SeedSettingIssue;
    private Float competitorHybrid2SeedSettingIssue;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getActivityType() {
        return phase;
    }

    public void setActivityType(String activityType) {
        this.phase = activityType;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Long getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(Long seasonId) {
        this.seasonId = seasonId;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public boolean getIsSampleIssued() {
        return wasSampleIssuedLastSeason;
    }

    public void setIsSampleIssued(boolean isSampleIssued) {
        this.wasSampleIssuedLastSeason = isSampleIssued;
    }

    public Long getHybridId() {
        return sampleHybridId;
    }

    public void setHybridId(Long hybridId) {
        this.sampleHybridId = hybridId;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getFarmerNumber() {
        return farmerMobileNo;
    }

    public void setFarmerNumber(String farmerNumber) {
        this.farmerMobileNo = farmerNumber;
    }

    public Float getCropAcres() {
        return cropArea;
    }

    public void setCropAcres(Object cropAcres) {
        this.cropArea = Utility.getFloat(cropAcres);
    }

    public Float getHybridCropAcres() {
        return hybridCropArea;
    }

    public void setHybridCropAcres(Object hybridCropAcres) {
        this.hybridCropArea = Utility.getFloat(hybridCropAcres);
    }

    public Float getOtherCropAcres() {
        return otherCropArea;
    }

    public void setOtherCropAcres(Object otherCropAcres) {
        this.otherCropArea = Utility.getFloat(otherCropAcres);
    }

    public Float getPioneerHyb1() {
        return pioneerHybrid1Area;
    }

    public void setPioneerHyb1(Object pioneerHyb1) {
        this.pioneerHybrid1Area = Utility.getFloat(pioneerHyb1);
    }

    public Float getPioneerHyb2() {
        return pioneerHybrid2Area;
    }

    public void setPioneerHyb2(Object pioneerHyb2) {
        this.pioneerHybrid2Area = Utility.getFloat(pioneerHyb2);
    }

    public Float getPioneerHyb3() {
        return pioneerHybrid3Area;
    }

    public void setPioneerHyb3(Object pioneerHyb3) {
        this.pioneerHybrid3Area = Utility.getFloat(pioneerHyb3);
    }

    public Float getPioneerHyb4() {
        return pioneerHybrid4Area;
    }

    public void setPioneerHyb4(Object pioneerHyb4) {
        this.pioneerHybrid4Area = Utility.getFloat(pioneerHyb4);
    }

    public Float getCompetitorHybrid1() {
        return competitorHybrid1Area;
    }

    public void setCompetitorHybrid1(Object competitorHybrid1) {
        this.competitorHybrid1Area = Utility.getFloat(competitorHybrid1);
    }

    public Float getCompetitorHybrid2() {
        return competitorHybrid2Area;
    }

    public void setCompetitorHybrid2(Object competitorHybrid2) {
        this.competitorHybrid2Area = Utility.getFloat(competitorHybrid2);
    }

    public Float getCompetitorHybrid3() {
        return competitorHybrid3Area;
    }

    public void setCompetitorHybrid3(Object competitorHybrid3) {
        this.competitorHybrid3Area = Utility.getFloat(competitorHybrid3);
    }

    public Float getCompetitorHybrid4() {
        return competitorHybrid4Area;
    }

    public void setCompetitorHybrid4(Object competitorHybrid4) {
        this.competitorHybrid4Area = Utility.getFloat(competitorHybrid4);
    }

    public Float getCompetitorHybrid5() {
        return competitorHybrid5Area;
    }

    public void setCompetitorHybrid5(Object competitorHybrid5) {
        this.competitorHybrid5Area = Utility.getFloat(competitorHybrid5);
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public long getRegionId() {
        return regionId;
    }

    public void setRegionId(long regionId) {
        this.regionId = regionId;
    }

    public String getLocation() {
        return geoLocation;
    }

    public void setLocation(String location) {
        this.geoLocation = location;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public String getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(String uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public String getPioneerHyb1Name() {
        return pioneerHybrid1;
    }

    public void setPioneerHyb1Name(String pioneerHyb1Name) {
        this.pioneerHybrid1 = pioneerHyb1Name;
    }

    public String getPioneerHyb2Name() {
        return pioneerHybrid2;
    }

    public void setPioneerHyb2Name(String pioneerHyb2Name) {
        this.pioneerHybrid2 = pioneerHyb2Name;
    }

    public String getPioneerHyb3Name() {
        return pioneerHybrid3;
    }

    public void setPioneerHyb3Name(String pioneerHyb3Name) {
        this.pioneerHybrid3 = pioneerHyb3Name;
    }

    public String getPioneerHyb4Name() {
        return pioneerHybrid4;
    }

    public void setPioneerHyb4Name(String pioneerHyb4Name) {
        this.pioneerHybrid4 = pioneerHyb4Name;
    }

    public String getCompetitorHybrid1Name() {
        return competitorHybrid1Name;
    }

    public void setCompetitorHybrid1Name(String competitorHybrid1Name) {
        this.competitorHybrid1Name = competitorHybrid1Name;
    }

    public String getCompetitorHybrid2Name() {
        return competitorHybrid2Name;
    }

    public void setCompetitorHybrid2Name(String competitorHybrid2Name) {
        this.competitorHybrid2Name = competitorHybrid2Name;
    }

    public String getCompetitorHybrid3Name() {
        return competitorHybrid3Name;
    }

    public void setCompetitorHybrid3Name(String competitorHybrid3Name) {
        this.competitorHybrid3Name = competitorHybrid3Name;
    }

    public String getCompetitorHybrid4Name() {
        return competitorHybrid4Name;
    }

    public void setCompetitorHybrid4Name(String competitorHybrid4Name) {
        this.competitorHybrid4Name = competitorHybrid4Name;
    }

    public String getCompetitorHybrid5Name() {
        return competitorHybrid5Name;
    }

    public void setCompetitorHybrid5Name(String competitorHybrid5Name) {
        this.competitorHybrid5Name = competitorHybrid5Name;
    }

    public Long getOtherCrop1() {
        return otherCrop1;
    }

    public void setOtherCrop1(Long otherCrop1) {
        this.otherCrop1 = otherCrop1;
    }

    public Long getOtherCrop2() {
        return otherCrop2;
    }

    public void setOtherCrop2(Long otherCrop2) {
        this.otherCrop2 = otherCrop2;
    }

    public double getOtherCropArea1() {
        return otherCropArea1;
    }

    public void setOtherCropArea1(double otherCropArea1) {
        this.otherCropArea1 = otherCropArea1;
    }

    public double getOtherCropArea2() {
        return otherCropArea2;
    }

    public void setOtherCropArea2(double otherCropArea2) {
        this.otherCropArea2 = otherCropArea2;
    }

    public Float getF2Acreages() {
        return f2Acreages;
    }

    public void setF2Acreages(Object f2Acreages) {
        this.f2Acreages = Utility.getFloat(f2Acreages);
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Float getSeedSettingIssue() {
        return seedSettingIssue;
    }

    public void setSeedSettingIssue(Object seedSettingIssue) {
        this.seedSettingIssue = Utility.getFloat(seedSettingIssue);
    }

    public Float getSeedSettingIssue1() {
        return pioneerHybrid1SeedSettingIssue;
    }

    public void setSeedSettingIssue1(Object seedSettingIssue1) {
        this.pioneerHybrid1SeedSettingIssue = Utility.getFloat(seedSettingIssue1);
    }

    public Float getSeedSettingIssue2() {
        return pioneerHybrid2SeedSettingIssue;
    }

    public void setSeedSettingIssue2(Object seedSettingIssue2) {
        this.pioneerHybrid2SeedSettingIssue = Utility.getFloat(seedSettingIssue2);
    }

    public Float getSeedSettingIssue3() {
        return pioneerHybrid3SeedSettingIssue;
    }

    public void setSeedSettingIssue3(Object seedSettingIssue3) {
        this.pioneerHybrid3SeedSettingIssue = Utility.getFloat(seedSettingIssue3);
    }

    public Float getSeedSettingIssue4() {
        return pioneerHybrid4SeedSettingIssue;
    }

    public void setSeedSettingIssue4(Object seedSettingIssue4) {
        this.pioneerHybrid4SeedSettingIssue = Utility.getFloat(seedSettingIssue4);
    }

    public Float getCompetitorHybrid1SeedSettingIssue() {
        return competitorHybrid1SeedSettingIssue;
    }

    public void setCompetitorHybrid1SeedSettingIssue(Object competitorHybrid1SeedSettingIssue) {
        this.competitorHybrid1SeedSettingIssue = Utility.getFloat(competitorHybrid1SeedSettingIssue);
    }

    public Float getCompetitorHybrid2SeedSettingIssue() {
        return competitorHybrid2SeedSettingIssue;
    }

    public void setCompetitorHybrid2SeedSettingIssue(Object competitorHybrid2SeedSettingIssue) {
        this.competitorHybrid2SeedSettingIssue = Utility.getFloat(competitorHybrid2SeedSettingIssue);
    }
}