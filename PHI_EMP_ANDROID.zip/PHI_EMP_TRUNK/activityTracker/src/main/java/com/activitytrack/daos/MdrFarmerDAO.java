package com.activitytrack.daos;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.MdrFarmerDTO;
import com.activitytrack.utility.ATBuildLog;

public class MdrFarmerDAO  implements DAO
{
	private final String TAG = "MdrFarmer";
    private static MdrFarmerDAO mdrFarmerDAO;

    public static MdrFarmerDAO getInstance()
    {
        if (mdrFarmerDAO == null)
        {
        	mdrFarmerDAO = new MdrFarmerDAO();
        }
        
        return mdrFarmerDAO ;
    }

    /**
     * delete the Data
     */
    
    @Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}
    
    
    
    /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
    
	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			{
		 List<DTO> mdrFarmerInfo = new ArrayList<DTO>();
	        Cursor cursor = null;
	        try
	        {
	        	if(!(columnName != null && columnName.length() > 0))
	        		columnName = "id";
	        	
	            cursor = dbObject.rawQuery("SELECT * FROM   MDR_FARMER where "+columnName+"='"+columnValue+"' ", null);
	            if (cursor.getCount() > 0)
	            {
	                cursor.moveToFirst();
	                do
	                {
	                	 /* MDR_FARMER
	                    	id
	                	  	farmerName
	                	  	mobileNumber 
	                	  	acres
	                    	majorCrop
	                   		majorCropAcres
	                    	secondCrop
	                    	secondCropAcres
	                	  	activityId
	                   */
	                	MdrFarmerDTO dto = new MdrFarmerDTO();
	                	
	                	dto.setId(cursor.getLong(0));
	                    dto.setFarmerName(cursor.getString(1));
	                    dto.setMobileNumber(cursor.getLong(2));
	                    dto.setAcres(cursor.getFloat(3));
	                    dto.setMajorCrop(cursor.getString(4));
	                    dto.setMajorCropAcres(cursor.getFloat(5));
	                    dto.setSecondCrop(cursor.getString(6));
	                    dto.setSecondCropAcres(cursor.getFloat(7));
	                    dto.setActivityId(cursor.getLong(8));
	                    
	                   mdrFarmerInfo.add(dto);
	                } while (cursor.moveToNext());
	            }
	        } catch (Exception e)
	        {
				ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	        } finally
	        {
	            if (cursor != null && !cursor.isClosed())
	            {
	                cursor.close();
	            }
	            dbObject.close();
	        }

	        return mdrFarmerInfo;
	    }
	    
	public List<DTO> getRecordInfoById(long activityId, SQLiteDatabase dbObject) { 
		
		List<DTO> mdrFarmerInfo = new ArrayList<DTO>();
		Cursor cursor = null;
		try
		{
		
		cursor = dbObject.rawQuery("SELECT * FROM  MDR_FARMER   where activityId = '"+activityId+"' ", null);
		if (cursor.getCount() > 0)
		{
		cursor.moveToFirst();
		
		do
		{
			 /* MDR_FARMER
        	id
    	  	farmerName
    	  	mobileNumber 
    	  	acres
        	majorCrop
       		majorCropAcres
        	secondCrop
        	secondCropAcres
    	  	activityId
       */
    	MdrFarmerDTO dto = new MdrFarmerDTO();
    	
    	dto.setId(cursor.getLong(0));
        dto.setFarmerName(cursor.getString(1));
        dto.setMobileNumber(cursor.getLong(2));
        dto.setAcres(cursor.getFloat(3));
        dto.setMajorCrop(cursor.getString(4));
        dto.setMajorCropAcres(cursor.getFloat(5));
        dto.setSecondCrop(cursor.getString(6));
        dto.setSecondCropAcres(cursor.getFloat(7));
        dto.setActivityId(cursor.getLong(8));
           
        
        mdrFarmerInfo.add(dto);
		
		} while (cursor.moveToNext());
		}
		} catch (Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		} finally
		{
		if (cursor != null && !cursor.isClosed())
		{
		cursor.close();
		}
		dbObject.close();
		}
		
		return mdrFarmerInfo;
		}
	   
	 /**
     * Gets all the records from the database
     *
      * @param dbObject
      *            : Exposes methods to manage a SQLite database Object
      */
	                	
	                	
	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)
	{
		 List<DTO> mdrFarmerInfo = new ArrayList<DTO>();
	        Cursor cursor = null;
	        try
	        {
	            cursor = dbObject.rawQuery("SELECT * FROM MDR_FARMER", null);
	            if (cursor.getCount() > 0)
	            {
	                cursor.moveToFirst();
	                do
	                {
	               
                     MdrFarmerDTO dto = new MdrFarmerDTO();
	                	
	                	dto.setId(cursor.getLong(0));
	                    dto.setFarmerName(cursor.getString(1));
	                    dto.setMobileNumber(cursor.getLong(2));
	                    dto.setAcres(cursor.getFloat(3));
	                    dto.setMajorCrop(cursor.getString(4));
	                    dto.setMajorCropAcres(cursor.getFloat(5));
	                    dto.setSecondCrop(cursor.getString(6));
	                    dto.setSecondCropAcres(cursor.getFloat(7));
	                    dto.setActivityId(cursor.getLong(8));
	                    
	                    
	                    mdrFarmerInfo.add(dto);

	                } while (cursor.moveToNext());
	            } 
	        } catch (Exception e)
	        {
				ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	        } finally
	        {
	            if (cursor != null && !cursor.isClosed())
	            {
	                cursor.close();
	            }
	            dbObject.close();
	        }

	        return mdrFarmerInfo;
	    }
	      
	              
		 
	 
          	 
	 /**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
	
   
    
	
	
	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		 try
	        {            
	        	MdrFarmerDTO dto = (MdrFarmerDTO) dtoObject;

	            ContentValues cValues = new ContentValues();
		 
	            /* MDR_FARMER
            	id
        	  	farmerName
        	  	mobileNumber 
        	  	acres
            	majorCrop
           		majorCropAcres
            	secondCrop
            	secondCropAcres
        	  	activityId
           */
	            cValues.put("farmerName",dto.getFarmerName());
				cValues.put("mobileNumber",dto.getMobileNumber());
				cValues.put("acres",dto.getAcres());
				cValues.put("majorCrop",dto.getMajorCrop());
				cValues.put("majorCropAcres",dto.getMajorCropAcres());
				cValues.put("secondCrop",dto.getSecondCrop());
				cValues.put("secondCropAcres",dto.getSecondCropAcres());
				cValues.put("activityId",dto.getActivityId());

	            dbObject.insert("MDR_FARMER", null, cValues);
	            return true;
	        } catch (SQLException e)
	        {
				ATBuildLog.e(TAG + "insert()", e.getMessage());
	            return false;
	        } finally
	        {
	            dbObject.close();
	        }

	    }
	            
	  
   	
	 /**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		try
        {            
        	MdrFarmerDTO dto = (MdrFarmerDTO) dtoObject;

            ContentValues cValues = new ContentValues();

			if(dto.getFarmerName()!=null)
			cValues.put("farmerName",dto.getFarmerName());
			
			if(dto.getMobileNumber()!=0)
				cValues.put("mobileNumber",dto.getMobileNumber());
			
			if(dto.getAcres()!=0)
				cValues.put("acres",dto.getAcres());
			
			if(dto.getMajorCrop()!=null)
				cValues.put("majorCrop",dto.getMajorCrop());
			
			if(dto.getMajorCropAcres()!=0)
				cValues.put("majorCropAcres",dto.getMajorCropAcres());
			
			if(dto.getSecondCrop()!=null)
			cValues.put("secondCrop",dto.getSecondCrop());
			
			if(dto.getSecondCropAcres()!=0)
			cValues.put("secondCropAcres",dto.getSecondCropAcres());
				
			 if(dto.getActivityId() != 0)
	            	cValues.put("activityId",dto.getActivityId());
			
			 
			 dbObject.update("MDR_FARMER", cValues, "id='" +dto.getId()+"' ", null);
	           
	            return true;
	        } catch (SQLException e)
	        {
				ATBuildLog.e(TAG + "update()", e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        } finally
	        {
	            dbObject.close();
	        }
	        return false;
	    }

	/**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM MDR_FARMER").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public List<MdrFarmerDTO> getRecordsForUpload(long activityId, SQLiteDatabase dbObject) {
		
		List<MdrFarmerDTO> farmerEntryInfo = new ArrayList<MdrFarmerDTO>();
		Cursor cursor = null;
		try
		{
		
		cursor = dbObject.rawQuery("SELECT * FROM  MDR_FARMER where activityId = '"+activityId+"' ", null);
		if (cursor.getCount() > 0)
		{
		cursor.moveToFirst();
		
		do
		{
			 /* MDR_FARMER
        	id
    	  	farmerName
    	  	mobileNumber 
    	  	acres
        	majorCrop
       		majorCropAcres
        	secondCrop
        	secondCropAcres
    	  	activityId
       */
		
		MdrFarmerDTO dto = new MdrFarmerDTO();
		
		dto.setId(cursor.getLong(0));
        dto.setFarmerName(cursor.getString(1));
        dto.setMobileNumber(cursor.getLong(2));
        dto.setAcres(cursor.getFloat(3));
        dto.setMajorCrop(cursor.getString(4));
        dto.setMajorCropAcres(cursor.getFloat(5));
        dto.setSecondCrop(cursor.getString(6));
        dto.setSecondCropAcres(cursor.getFloat(7));
        dto.setActivityId(cursor.getLong(8));
		
		
		farmerEntryInfo.add(dto);
		
		} while (cursor.moveToNext());
		}
		} catch (Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		} finally
		{
		if (cursor != null && !cursor.isClosed())
		{
		cursor.close();
		}
		dbObject.close();
		}
		
		return farmerEntryInfo;
	}

    public boolean deleteTableDataById(long activityId,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM MDR_FARMER  where activityId = '"+activityId+"'").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }
	
    public boolean deleteDataById(String activityId,String id,SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("DELETE FROM FARMER_ENTRY where   activityId = '"+activityId+"' and id = '"+id+"'");
			return true;
		}catch(Exception e)
		{
			ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally
		
		{
		
		dbObject.close();
		
		}
		return false;
	}  
	

}
