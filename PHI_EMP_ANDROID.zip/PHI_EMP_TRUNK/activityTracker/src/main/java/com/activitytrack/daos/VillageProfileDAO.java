package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.MdrFarmerDTO;
import com.activitytrack.dtos.MdrSurveyDTO;
import com.activitytrack.dtos.NewMdrSurveyDTO;
import com.activitytrack.dtos.VillageProfileDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class VillageProfileDAO implements DAO {

    private final String TAG = "VillageProfile";
    private static VillageProfileDAO villageProfileDAO;

    public static VillageProfileDAO getInstance() {
        if (villageProfileDAO == null) {
            villageProfileDAO = new VillageProfileDAO();
        }

        return villageProfileDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM VILLAGE_PROFILE where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    VillageProfileDTO dto = new VillageProfileDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setPinCode(cursor.getString(2));
                    dto.setBlockName(cursor.getString(3));
                    dto.setCropId(cursor.getLong(4));
                    dto.setCropName(cursor.getString(5));
                    dto.setSegment(cursor.getLong(6));
                    dto.setSegmentName(cursor.getString(7));
                    dto.setDate(cursor.getString(8));
                    dto.setLocation(cursor.getString(9));
                    dto.setRegionId(cursor.getLong(10));
                    dto.setIsSync(cursor.getInt(11));
                    dto.setUploadedDate(cursor.getString(12));
                    dto.setIsPDAVillage(cursor.getString(13));
                    dto.setRetailerMobileNumber(cursor.getString(14));

                    pdaActivityInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }


    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM VILLAGE_PROFILE ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    VillageProfileDTO dto = new VillageProfileDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setPinCode(cursor.getString(2));
                    dto.setBlockName(cursor.getString(3));
                    dto.setCropId(cursor.getLong(4));
                    dto.setCropName(cursor.getString(5));
                    dto.setSegment(cursor.getLong(6));
                    dto.setSegmentName(cursor.getString(7));
                    dto.setDate(cursor.getString(8));
                    dto.setLocation(cursor.getString(9));
                    dto.setRegionId(cursor.getLong(10));
                    dto.setIsSync(cursor.getInt(11));
                    dto.setUploadedDate(cursor.getString(12));
                    dto.setIsPDAVillage(cursor.getString(13));
                    dto.setRetailerMobileNumber(cursor.getString(14));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }


    public List<VillageProfileDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<VillageProfileDTO> pdaActivityInfo = new ArrayList<VillageProfileDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM VILLAGE_PROFILE where isSync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    VillageProfileDTO dto = new VillageProfileDTO();

                    /*// TARA
                    List<MdrSurveyDTO> surveys = MdrSurveyDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setSurveys(surveys);*/

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setPinCode(cursor.getString(2));
                    dto.setBlockName(cursor.getString(3));
                    dto.setCropId(cursor.getLong(4));
                    dto.setCropName(cursor.getString(5));
                    dto.setSegment(cursor.getLong(6));
                    dto.setSegmentName(cursor.getString(7));
                    dto.setDate(cursor.getString(8));
                    dto.setLocation(cursor.getString(9));
                    dto.setRegionId(cursor.getLong(10));
                    dto.setIsSync(cursor.getInt(11));
                    dto.setUploadedDate(cursor.getString(12));
                    dto.setIsPDAVillage(cursor.getString(13));
                    dto.setRetailerMobileNumber(cursor.getString(14));

                    List<MdrFarmerDTO> farmers = MdrFarmerDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setFarmers(farmers);

                    dbObject = DBHandler.getInstance(context).getDBObject(0);
                    List<MdrSurveyDTO> surveys = MdrSurveyDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setSurveys(surveys);

                    dbObject = DBHandler.getInstance(context).getDBObject(0);
                    List<NewMdrSurveyDTO> surveysNew = NewMdrSurveyDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setSurveysNew(surveysNew);

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override

    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;

    }


    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {


        try {
            VillageProfileDTO dto = (VillageProfileDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            cValues.put("villageName", dto.getVillageName());
            cValues.put("pinCode", dto.getPinCode());
            cValues.put("blockName", dto.getBlockName());
            cValues.put("cropId", dto.getCropId());
            cValues.put("cropName", dto.getCropName());
            cValues.put("segment", dto.getSegment());
            cValues.put("segmentName", dto.getSegmentName());
            cValues.put("date", dto.getDate());
            cValues.put("location", dto.getLocation());
            cValues.put("regionId", dto.getRegionId());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("uploadedDate", dto.getUploadedDate());
            cValues.put("isPDAVillage", dto.getIsPDAVillage());
            cValues.put("retailerMobileNumber", dto.getRetailerMobileNumber());

            long insertedRow = dbObject.insert("VILLAGE_PROFILE", null, cValues);
            if (insertedRow > 0) {
                Cursor cursor = dbObject.rawQuery("SELECT MAX(id) FROM  VILLAGE_PROFILE", null);
                if (cursor.getCount() > 0) {

                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            VillageProfileDTO dto = (VillageProfileDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getVillageName() != null)
                cValues.put("villageName", dto.getVillageName());

            if (dto.getPinCode() != null)
                cValues.put("pinCode", dto.getPinCode());

            if (dto.getBlockName() != null)
                cValues.put("blockName", dto.getBlockName());

            if (dto.getCropId() != 0)
                cValues.put("cropId", dto.getCropId());

            if (dto.getCropName() != null)
                cValues.put("cropName", dto.getCropName());

            if (dto.getSegment() != 0)
                cValues.put("segment", dto.getSegment());

            if (dto.getSegmentName() != null)
                cValues.put("segmentName", dto.getSegmentName());

            if (dto.getDate() != null)
                cValues.put("date", dto.getDate());


            if (dto.getLocation() != null)
                cValues.put("location", dto.getLocation());

            if (dto.getRegionId() != 0)
                cValues.put("regionId", dto.getRegionId());

            cValues.put("isSync", dto.getIsSync());

            if (dto.getUploadedDate() != null)
                cValues.put("uploadedDate", dto.getUploadedDate());

            if (dto.getIsPDAVillage() != null)
                cValues.put("isPDAVillage", dto.getIsPDAVillage());

            if (dto.getRetailerMobileNumber() != null)
                cValues.put("retailerMobileNumber", dto.getRetailerMobileNumber());

            dbObject.update("VILLAGE_PROFILE", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }


    public List<Long> getIdsByDate(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<Long> idsList = new ArrayList<Long>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "uploadedDate";

            cursor = dbObject.rawQuery("SELECT id FROM VILLAGE_PROFILE  where " + columnName + " < '" + columnValue + "' and isSync = '0' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    idsList.add(cursor.getLong(0));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return idsList;
    }


    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM VILLAGE_PROFILE").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from VILLAGE_PROFILE where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean deleteDataByDate(String date, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from  VILLAGE_PROFILE where uploadedDate < '" + date + "' and isSync = '0'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM VILLAGE_PROFILE where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }


    public List<VillageProfileDTO> getPendingRecords(Context context, SQLiteDatabase dbObject) {
        List<VillageProfileDTO> pdaActivityInfo = new ArrayList<VillageProfileDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM VILLAGE_PROFILE where isSync = -1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    VillageProfileDTO dto = new VillageProfileDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setPinCode(cursor.getString(2));
                    dto.setBlockName(cursor.getString(3));
                    dto.setCropId(cursor.getLong(4));
                    dto.setCropName(cursor.getString(5));
                    dto.setSegment(cursor.getLong(6));
                    dto.setSegmentName(cursor.getString(7));
                    dto.setDate(cursor.getString(8));
                    dto.setLocation(cursor.getString(9));
                    dto.setRegionId(cursor.getLong(10));
                    dto.setIsSync(cursor.getInt(11));
                    dto.setUploadedDate(cursor.getString(12));
                    dto.setIsPDAVillage(cursor.getString(13));
                    dto.setRetailerMobileNumber(cursor.getString(14));

                    List<MdrFarmerDTO> farmers = MdrFarmerDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setFarmers(farmers);

                    dbObject = DBHandler.getInstance(context).getDBObject(0);
                    List<MdrSurveyDTO> surveys = MdrSurveyDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setSurveys(surveys);

                    dbObject = DBHandler.getInstance(context).getDBObject(0);
                    List<NewMdrSurveyDTO> surveysNew = NewMdrSurveyDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setSurveysNew(surveysNew);

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    public boolean deleteTableDataById(long activityId, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM VILLAGE_PROFILE where id = '" + activityId + "'").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }
}
