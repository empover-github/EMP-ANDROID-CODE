package com.activitytrack.activity;

import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.daos.YieldCalculatorDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.YieldCalculatorDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

public class YieldCalculatorFragment extends BaseFragment {

private View view;
	
	private TextView tvLength;
	private TextView tvBreadth;
	private TextView tvYield;
	private TextView tvMoisture;

    private EditText edtLength;
	private EditText edtBreadth;
	private EditText edtYield;
	private EditText edtMoisture;
	
	private Button btnCalculate;
	
	private LinearLayout mainLayout;
	
	private TextView  tvArea;
	private TextView tvHarvestedYield;
	private TextView tvYieldC;
	
	private Float Area;
	private float HarvestedYield;
	private Float YieldC;
	private Float Length;
	private Float Breadth;
	private Float Yield;
	private Float Moisture;
	private LinearLayout cmptrNameLayout;
	private LinearLayout cmptrHybridLayout;
	private EditText edtCmptrName;
	private EditText edtCmptrHybrid;
	private Button btnSubmit;
	
	private String cmptName;
	private String cmptHybrid;
	
	private TextView tvCmptrName;
	private TextView tvCmptrHybrid;
	
	private String activity;
	private long activityId;
	private LinearLayout calcuateResultLayout;
	
	private boolean isSaved ;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.yield_calculator_fragment, container, false);
		
		edtLength=(EditText)view.findViewById(R.id.yc_length);
		edtBreadth=(EditText)view.findViewById(R.id.yc_breadth);
		edtYield=(EditText)view.findViewById(R.id.yc_yield);
		edtMoisture=(EditText)view.findViewById(R.id.yc_moisture);
		
		tvLength=(TextView)view.findViewById(R.id.yc_length_l);
		tvBreadth=(TextView)view.findViewById(R.id.yc_breadth_l);
		tvYield=(TextView)view.findViewById(R.id.yc_yield_l);
		tvMoisture=(TextView)view.findViewById(R.id.yc_moisture_l);
		
		tvArea=(TextView)view.findViewById(R.id.yc_area);
		tvHarvestedYield=(TextView)view.findViewById(R.id.yc_harvestedYield);
		tvYieldC=(TextView)view.findViewById(R.id.yc_yieldC);
		
		mainLayout=(LinearLayout)view.findViewById(R.id.yc_bg_layout);
		
		btnCalculate=(Button)view.findViewById(R.id.yc_calculate);
		
		cmptrNameLayout = (LinearLayout) view.findViewById(R.id.yc_competitorNameLayout);
		cmptrHybridLayout = (LinearLayout) view.findViewById(R.id.yc_competitorHybridLayout);
		
		edtCmptrName = (EditText) view.findViewById(R.id.yc_competitorName);
		edtCmptrHybrid = (EditText) view.findViewById(R.id.yc_competitorHybrid);
		btnSubmit = (Button) view.findViewById(R.id.yc_submit);
		
		tvCmptrHybrid=(TextView)view.findViewById(R.id.yc_competitorHybrid_l);
		tvCmptrName=(TextView)view.findViewById(R.id.yc_competitorName_l);
		calcuateResultLayout=(LinearLayout)view.findViewById(R.id.yc_calculatate_circle_l);
		setChange();
		
		Bundle bundle = getArguments();
		activity = bundle.getString("activity");
		if(activity.equals(MyConstants.ACTIVITY_PDA)){
			//btnSubmit.setVisibility(View.VISIBLE);
			activityId = bundle.getLong("activityId");
			cmptName = bundle.getString("cmptName");
			cmptHybrid = bundle.getString("cmptHybrid");
			if(cmptName != null && cmptName.length() > 0){
				edtCmptrName.setText(cmptName);
				//cmptrNameLayout.setVisibility(View.VISIBLE);
			}else{
				//cmptrNameLayout.setVisibility(View.GONE);
				//cmptrNameLayout.setVisibility(View.VISIBLE);
			}
			
			if(cmptHybrid != null && cmptHybrid.length() > 0){
				edtCmptrHybrid.setText(cmptHybrid);
				cmptrHybridLayout.setVisibility(View.VISIBLE);
			}else{
				//cmptrHybridLayout.setVisibility(View.GONE);
				cmptrHybridLayout.setVisibility(View.VISIBLE);
			}
			
			List<DTO> yList = YieldCalculatorDAO.getInstance().getRecordInfoByValue("activityId", ""+activityId, DBHandler.getInstance(mActivity).getDBObject(0));
			
			if(yList != null && yList.size() > 0){
				populate((YieldCalculatorDTO)yList.get(0));
			}
			
		}
		
		btnCalculate.setOnClickListener(new OnClickListener() 
		
		{
			
			@Override
			public void onClick(View v) 
			{
				
				String validation = validateFields();
				if(validation.trim().length() == 0)
				{
					calcuate();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
			}

			

			private void calcuate() 
			{
				 
			Length=Float.parseFloat(edtLength.getText().toString().trim());
			Breadth=Float.parseFloat(edtBreadth.getText().toString().trim());
			Area=Length*Breadth;
			tvArea.setText(""+Utility.round(Area, 2));
			
			Yield=Float.parseFloat(edtYield.getText().toString().trim());
			HarvestedYield= (float)((Yield/100)/(Area*0.000247));
			tvHarvestedYield.setText(""+Utility.round(HarvestedYield, 2));
			
			Moisture=Float.parseFloat(edtMoisture.getText().toString().trim());
			YieldC=(float)((HarvestedYield*(100-(Moisture-12))/100));
			tvYieldC.setText(""+Utility.round(YieldC, 2));
			
			calcuateResultLayout.setVisibility(View.VISIBLE);
		
			if(activity.equals(MyConstants.ACTIVITY_PDA)){
				btnSubmit.setVisibility(View.VISIBLE);
			}
			
			}
		
		
		
		});
		
		btnSubmit.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
			 
		
			String validation=validateFields1();
			if(validation.trim().length()==0)
			{
		
				showAlertToSave();
				
			}else{
				Utility.showAlert(mActivity, "",validation);
			}
			}

			private String validateFields1() {
				 
					
					
			if(tvArea.getText().toString().trim().length()==0)
			 return  getResources().getString(R.string.calarea);
				
			if(tvHarvestedYield.getText().toString().trim().length()==0)	
				return  getResources().getString(R.string.calhar);
			   
			if(tvYieldC.getText().toString().trim().length()==0)
				  return getResources().getString(R.string.calyield);
			  
					return "";
				}
			 
			 
		});
		
		return view;
	}

	 

	private String validateFields(){
		if(edtLength.getText().toString().trim().length() == 0)
			return getResources().getString(R.string.lennoemp);
		
		if(edtBreadth.getText().toString().trim().length() == 0)
			return  getResources().getString(R.string.brenoemp);
		
		if(edtYield.getText().toString().trim().length() == 0)
			return  getResources().getString(R.string.yieldnoemp);
		
		if(edtMoisture.getText().toString().trim().length() == 0)
			return   getResources().getString(R.string.moisnoemp) ;
		
		float moisture=Float.valueOf(edtMoisture.getText().toString().trim());
		
		if(!(moisture >= 0 && moisture <= 100))
			return  getResources().getString(R.string.mois0);
		

		return"";
	}
	
	 private void showAlertToSave() 
	{
	 
		AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.saveData));
		builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
				saveData();
			}
		});
	
	builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int which) {
			 
			
		}
	});
	builder.create().show();
	}

	private void saveData()
	{
	boolean dataStoreAck = false;	
	YieldCalculatorDTO dto=new  YieldCalculatorDTO();
	
	dto.setLength(Float.valueOf(edtLength.getText().toString().trim()));
	dto.setBreadth(Float.valueOf(edtBreadth.getText().toString().trim()));
	dto.setYield(Float.valueOf(edtYield.getText().toString().trim()));
	dto.setMoisture(Float.valueOf(edtMoisture.getText().toString().trim()));
	dto.setArea(Float.valueOf(tvArea.getText().toString().trim()));
	dto.setYieldHarvested (Float.valueOf(tvHarvestedYield.getText().toString().trim()));
	dto.setYieldMoisture(Float.valueOf(tvYieldC.getText().toString().trim()));
	dto.setActivityId(activityId);
	dto.setActivity(activity);
	dto.setCompetitorHybrid(cmptHybrid);
	dto.setCompetitorName(cmptName);
	
	List<DTO> yList = YieldCalculatorDAO.getInstance().getRecordInfoById(activity, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
	
	if(yList != null && yList.size() > 0){
		dataStoreAck = YieldCalculatorDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
		isSaved = true;
	}else{
		dataStoreAck = YieldCalculatorDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getDBObject(1));
		isSaved = true;

	}
	
	
	if(dataStoreAck){
		Toast.makeText(mActivity, "Successfully inserted", Toast.LENGTH_SHORT).show();
		mActivity.popFragments();
	}
}
 
private void clearFields() 
{
	edtLength.setText("");
	edtBreadth.setText("");
	edtMoisture.setText("");
	edtYield.setText("");
    tvArea.setText("");
    tvHarvestedYield.setText("");
    tvYieldC.setText("");
	
}


private void setChange(){
	if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
		tvLength.setTextColor(Color.WHITE);
		tvBreadth.setTextColor(Color.WHITE);
		tvYield.setTextColor(Color.WHITE);
		tvMoisture.setTextColor(Color.WHITE);
		tvCmptrName.setTextColor(Color.WHITE);
		tvCmptrHybrid.setTextColor(Color.WHITE);
		mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
		
	}else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
		tvLength.setTextColor(Color.BLACK);
		tvBreadth.setTextColor(Color.BLACK);
		tvYield.setTextColor(Color.BLACK);
		tvMoisture.setTextColor(Color.BLACK);
		tvCmptrName.setTextColor(Color.BLACK);
		tvCmptrHybrid.setTextColor(Color.BLACK);
		mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
	}

   }

	private void populate(YieldCalculatorDTO dto){
		edtBreadth.setText(String.valueOf(dto.getBreadth()));
		edtLength.setText(String.valueOf(dto.getLength()));
		edtMoisture.setText(String.valueOf(dto.getMoisture()));
		edtYield.setText(String.valueOf(dto.getYield()));
		tvArea.setText(String.valueOf(dto.getArea()));
		tvHarvestedYield.setText(String.valueOf(dto.getYieldHarvested()));
		tvYieldC.setText(String.valueOf(dto.getYieldMoisture()));
		calcuateResultLayout.setVisibility(View.VISIBLE);
		btnSubmit.setVisibility(View.VISIBLE);
	}




	@Override
	public boolean onBackPressed(int callbackCode) {
		if(activity.equals(MyConstants.ACTIVITY_PDA))
		{
			if(callbackCode != 200){
			if(isDataAvailable()){
				showAlertToExitScreen(callbackCode);
			}else{
				mActivity.onBackPressedCallBack(callbackCode);
			  }
			}else if(callbackCode == 200 && !isSaved){
				if(isDataAvailable()){
					showAlertToExitScreen(callbackCode);
				}else{
					mActivity.onBackPressedCallBack(callbackCode);
				  }
			}else{
				mActivity.onBackPressedCallBack(callbackCode);
			  }
		}else
		{
			mActivity.onBackPressedCallBack(callbackCode);
		}
		return true;
	}
	
	private void showAlertToExitScreen(final int callbackCode){
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.formExitMsg));
		builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mActivity.onBackPressedCallBack(callbackCode);
			}
		});
		
		builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
			}
		});
		
		builder.create().show();
	}
	
	private boolean isDataAvailable() 
	{
		if(edtLength.getText().toString().trim().length() > 0)
			return true;
		
		if(edtBreadth.getText().toString().trim().length() > 0)
			return true;
		
		if(edtYield.getText().toString().trim().length() > 0)
			return true;
		
		if(edtMoisture.getText().toString().trim().length() > 0)
			return true;
	 
		return false;
	}

		
}
