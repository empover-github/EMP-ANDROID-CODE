package com.activitytrack.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.activitytrack.utility.ATBuildLog;

public class DBHandler extends SQLiteOpenHelper {

    private final String TAG = "DBHandler";
    private static final String DATABASE_NAME = "activitytrack.db";
    public static final int DATABASE_VERSION = 20;//changing dbversion from 19 to 20 for adding AGRONOMY_ACTIVITY Crop Advisory columns
    private static DBHandler dbHandler;
    //private static Context context;

    /**
     * Instance of the database handler
     *
     * @param context2 :Interface to global information about an application
     *                 environment.
     * @return
     */
    public static DBHandler getInstance(Context context2) {
        if (dbHandler == null) {
            //context = context2;
//        	DATABASE_VERSION = Utility.getDBVersion(context2);
            dbHandler = new DBHandler(context2);

        }
        return dbHandler;
    }

    /**
     * Gets the Database Object
     *
     * @param isWrtitable :whether readable or writable.
     * @return
     */
    public SQLiteDatabase getDBObject(int isWrtitable) {
        return (isWrtitable == 1) ? this.getWritableDatabase() : this.getReadableDatabase();
    }

    /**
     * Constructor
     *
     * @param context :Interface to global information about an application
     *                environment.
     */
    private DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    /**
     * Called when the database is created for the first time. This is where the
     * creation of tables and the initial population of the tables should
     * happen.
     *
     * @param db : The database.
     */

    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE CROP_MASTER(id NUMBER ,name TEXT)");

        db.execSQL("CREATE TABLE HYBRID_MASTER(id NUMBER ,hybridName TEXT, cropId NUMBER)");

        db.execSQL("CREATE TABLE SEGMENT_MASTER(id NUMBER ,segmentName TEXT, cropId NUMBER)");

        db.execSQL("CREATE TABLE MDR_MASTER(id NUMBER ,name TEXT, empId TEXT,loginId TEXT, password TEXT,mobileNo NUMBER, regionId NUMBER)");

        db.execSQL("CREATE TABLE RETAILER_MASTER(id NUMBER ,name TEXT,mobileNo NUMBER, pinCode NUMBER)");

        db.execSQL("CREATE TABLE TARGET_AGRONOMY(id NUMBER , seasonId  NUMBER , cropId  NUMBER, hybridId  NUMBER,  targetSample NUMBER, date TEXT )");

        db.execSQL("CREATE TABLE TARGET_DEMAND_PDA(id NUMBER , seasonId  NUMBER , cropId  NUMBER, hybridId  NUMBER,  targetActivity  NUMBER, targetFarmer NUMBER,date TEXT)");

        db.execSQL("CREATE TABLE TARGET_DEMAND_OSA(id NUMBER , seasonId  NUMBER , cropId  NUMBER, hybridId  NUMBER,  targetActivity  NUMBER, targetFarmer NUMBER,date TEXT)");

        db.execSQL("CREATE TABLE TARGET_DEMAND_PSA(id NUMBER , seasonId  NUMBER , cropId  NUMBER, hybridId  NUMBER,  targetActivity  NUMBER, targetFarmer NUMBER,date TEXT)");

        db.execSQL("CREATE TABLE THREE_I(id INTEGER PRIMARY KEY AUTOINCREMENT,retailerMobileNo NUMBER,retailersFirmName TEXT,threeIPhaseNo NUMBER,date TEXT,location TEXT, isSync NUMBER,uploadedDate TEXT,regionId NUMBER)");

        db.execSQL("CREATE TABLE FARMER_ENTRY(id INTEGER PRIMARY KEY AUTOINCREMENT,farmerName TEXT,mobileNumber NUMBER,acres NUMBER ,date TEXT,location TEXT, isSync NUMBER, activity TEXT, activityId NUMBER)");

        db.execSQL("CREATE TABLE RETAILER_INFO(id INTEGER PRIMARY KEY AUTOINCREMENT,retailerName TEXT,mobileNumber NUMBER, altMobileNumber NUMBER , date TEXT,location TEXT, isSync NUMBER,activity TEXT, activityId NUMBER)");

        db.execSQL("CREATE TABLE LIQUIDATION_TRACKING(id INTEGER PRIMARY KEY AUTOINCREMENT,crop TEXT, salesDate TEXT, retailerName TEXT, retailerMobileNo NUMBER, pinCode NUMBER, season NUMBER ,pioneerSales NUMBER, competitor1Sales NUMBER, competitor2Sales NUMBER, otherSales NUMBER,location TEXT, isSync NUMBER)");

        db.execSQL("CREATE TABLE MDR_PROFILE(id INTEGER PRIMARY KEY AUTOINCREMENT, villageName TEXT,cropId NUMBER,  totalCropArea NUMBER,pioneerShare NUMBER,  majorCompetitorName1 TEXT, itsShare1 NUMBER,  majorCompetitorName2 TEXT, itsShare2 NUMBER, date TEXT,location TEXT, isSync NUMBER,uploadedDate TEXT,regionId NUMBER, numberOfFarmers NUMBER,  pinCode TEXT, blockName TEXT, segment NUMBER, cropHa TEXT, phiHa TEXT, majorPHIHybrid1 NUMBER, majorPHIHybrid2 NUMBER, majorCompetitionHybrid1 TEXT, majorCompetitionHybrid2 TEXT)");

        db.execSQL("CREATE TABLE PDA_ACTIVITY(id INTEGER PRIMARY KEY AUTOINCREMENT, activityType TEXT, cropId NUMBER, hybridId NUMBER, numberOfFarmers NUMBER , numberOfRetailers NUMBER, competitorHybrid1 TEXT, hybridAcres REAR, competitorYield REAL, villagesInvolved TEXT, location TEXT, isSync NUMBER,seasonId NUMBER,date TEXT,seasonCalendarId NUMBER,uploadedDate TEXT,regionId NUMBER,acresExposed TEXT, farmerBarCodeDetails TEXT, farmerAttendanceDetails TEXT, pincode TEXT,isTBLParticipated TEXT, numberOfPravaktas NUMBER, isFAWDone TEXT)");

        db.execSQL("CREATE TABLE OSA_ACTIVITY(id INTEGER PRIMARY KEY AUTOINCREMENT, activityType TEXT, cropId NUMBER, hybridId NUMBER, numberOfFarmers NUMBER , numberOfRetailers NUMBER, competitorHybrid1 TEXT, hybridAcres REAR, competitorYield REAL, location TEXT, isSync NUMBER,seasonId NUMBER,date TEXT, seasonCalendarId NUMBER,uploadedDate TEXT,regionId NUMBER,farmerBarCodeDetails TEXT, farmerAttendanceDetails TEXT, pincode TEXT, isTBLParticipated TEXT, numberOfPravaktas NUMBER,isFAWDone TEXT)");

        db.execSQL("CREATE TABLE PSA_ACTIVITY(id INTEGER PRIMARY KEY AUTOINCREMENT, activityType TEXT, cropId NUMBER, hybridId NUMBER, numberOfFarmers NUMBER , numberOfRetailers NUMBER, competitorHybrid1 TEXT, hybridAcres REAR, competitorYield REAL, location TEXT, isSync NUMBER,seasonId NUMBER,date TEXT, seasonCalendarId NUMBER,uploadedDate TEXT,regionId NUMBER,farmerBarCodeDetails TEXT, farmerAttendanceDetails TEXT, pincode TEXT, isTBLParticipated TEXT, numberOfPravaktas NUMBER,isFAWDone TEXT)");

        db.execSQL("CREATE TABLE AGRONOMY_ACTIVITY(id INTEGER PRIMARY KEY AUTOINCREMENT,  category  TEXT, cropId NUMBER,  hybridId NUMBER, samplingObjective  TEXT, nameOfFarmer TEXT, mobileNoOfFarmer NUMBER, plotType TEXT, competitorHybrid1 TEXT,  competitorHybrid2 TEXT , location TEXT, date TEXT,isSync NUMBER, seasonId NUMBER, seasonCalendarId NUMBER,uploadedDate TEXT,regionId NUMBER,pincode TEXT, dateOfSowing TEXT, acresSowed NUMBER)");

        db.execSQL("CREATE TABLE YIELD_CALCULATOR(id INTEGER PRIMARY KEY AUTOINCREMENT,yieldFor TEXT,length NUMBER, breadth NUMBER,  rowSpacing NUMBER, rowsHarvested  NUMBER, harvestedPlants NUMBER, population NUMBER, totalCobWeight NUMBER, shellingPercentage NUMBER, totalGrainWeight NUMBER, moisturePercentage NUMBER, hillsPerSQM NUMBER, totalEarheadWeight NUMBER, totalDryGrainWeight NEMBER, perAcreYield NUMBER, yieldGain NUMBER, perYieldGain NUMBER, activityId NUMBER, cropId NEMBER)");

        db.execSQL("CREATE TABLE SEASON_MASTER(id NUMBER, name TEXT, cropId NUMBER, activityId NUMBER, seasonStartDate TEXT, seasonEndDate TEXT, conductesYear TEXT, cropName TEXT, activityName TEXT,seasonCalendarId NUMBER)");

        db.execSQL("CREATE TABLE DEMAND_SUMMARY (id INTEGER PRIMARY KEY AUTOINCREMENT,activityId NUMBER,sampleCount NUMBER,hybridId NUMBER,cropId NUMBER,seasonCalendarId NUMBER,seasonId NUMBER,retailerCount NUMBER,farmerCount NUMBER,isSync NUMBER)");

        db.execSQL("CREATE TABLE AGRONOMY_SUMMARY (id INTEGER PRIMARY KEY AUTOINCREMENT,sampleCount NUMBER,date TEXT,cropId NUMBER, hybridId NUMBER, seasonId NUMBER,seasonCalendarId NUMBER)");

        db.execSQL("CREATE TABLE TOP3_HYBRIDS(id NUMBER , seasonId NUMBER, activityId NUMBER,cropId NUMBER,hybridId NUMBER, hybridName TEXT)");

        db.execSQL("CREATE TABLE MDR_FARMER(id INTEGER PRIMARY KEY AUTOINCREMENT,farmerName TEXT,mobileNumber NUMBER,acres NUMBER , majorCrop TEXT,majorCropAcres NUMBER,secondCrop TEXT, secondCropAcres NUMBER,activityId NUMBER)");

        db.execSQL("CREATE TABLE DIPSTICK(id INTEGER PRIMARY KEY AUTOINCREMENT, activityType TEXT, year NUMBER, seasonId NUMBER, cropId NUMBER,  isSampleIssued NUMBER, hybridId NUMBER, farmerName TEXT, farmerNumber TEXT, cropAcres REAL, hybridCropAcres REAL, otherCropAcres REAL,"
                + "pioneerHyb1 REAL, pioneerHyb2 REAL, competitorHybrid1 REAL, competitorHybrid2 REAL, competitorHybrid3 REAL, competitorHybrid4 REAL, competitorHybrid5 REAL, date TEXT DEFAULT (datetime('now','localtime')), regionId NUMBER, location TEXT, isSync NUMBER, uploadedDate TEXT, pioneerHyb1Name TEXT, pioneerHyb2Name TEXT, competitorHybrid1Name TEXT, competitorHybrid2Name TEXT, competitorHybrid3Name TEXT, competitorHybrid4Name TEXT, competitorHybrid5Name TEXT, otherCrop1 NUMBER, otherCrop2 NUMBER, otherCropArea1 NUMBER,  otherCropArea2 NUMBER, userType TEXT, f2Acreages REAL, seedSettingIssue REAL, pioneerHyb3Name TEXT, pioneerHyb4Name TEXT, pioneerHyb3 REAL, pioneerHyb4 REAL,seedSettingIssue1 REAL,seedSettingIssue2 REAL,seedSettingIssue3 REAL,seedSettingIssue4 REAL,competitorHybrid1SeedSettingIssue REAL, competitorHybrid2SeedSettingIssue REAL )");

        db.execSQL("CREATE TABLE DIPSTICK_MASTER(id INTEGER, activityType TEXT, year NUMBER, seasonId NUMBER, cropId NUMBER,  isSampleIssued NUMBER, hybridId NUMBER, farmerName TEXT, farmerNumber TEXT, cropAcres REAL, hybridCropAcres REAL, otherCropAcres REAL,"
                + "pioneerHyb1 REAL, pioneerHyb2 REAL, competitorHybrid1 REAL, competitorHybrid2 REAL, competitorHybrid3 REAL, competitorHybrid4 REAL, competitorHybrid5 REAL, date TEXT, regionId NUMBER, location TEXT, isSync NUMBER, uploadedDate TEXT, pioneerHyb1Name TEXT, pioneerHyb2Name TEXT, competitorHybrid1Name TEXT, competitorHybrid2Name TEXT, competitorHybrid3Name TEXT, competitorHybrid4Name TEXT, competitorHybrid5Name TEXT, otherCrop1 NUMBER, otherCrop2 NUMBER, otherCropArea1 NUMBER,  otherCropArea2 NUMBER,userType TEXT, f2Acreages REAL, seedSettingIssue REAL,  pioneerHyb3Name TEXT, pioneerHyb4Name TEXT, pioneerHyb3 REAL, pioneerHyb4 REAL, seedSettingIssue1 REAL,seedSettingIssue2 REAL,seedSettingIssue3 REAL,seedSettingIssue4 REAL,competitorHybrid1SeedSettingIssue REAL, competitorHybrid2SeedSettingIssue REAL)");

        db.execSQL("CREATE TABLE SEASONS(id NUMBER ,name TEXT)");

        // newly added in version 7
        db.execSQL("CREATE TABLE PRAVAKTA_HA_AGAIN(id INTEGER PRIMARY KEY AUTOINCREMENT, pravaktaName TEXT, mobileNo TEXT, villageName TEXT, pincode TEXT, imageUrlPath TEXT, blockName TEXT, districtName TEXT, previousYear TEXT, currentYear TEXT, totalPreviousAcres TEXT, totalPresentAcres TEXT, phiPreviousAcres TEXT, phiPresentAcres TEXT, targetPreviousAcres TEXT, targetPresentAcres TEXT, rice TEXT, corn TEXT, millet TEXT, mustard TEXT, targetHybrid TEXT, blockType TEXT, villageType TEXT, isSync NUMBER, location TEXT)");
        db.execSQL("CREATE TABLE PRAVAKTA_FARMER(id INTEGER PRIMARY KEY AUTOINCREMENT, imageUrlPath TEXT, pdaAttendPre TEXT, pdaAttendCurr TEXT, pionUserPre TEXT, pionUserCurr TEXT, previousYear TEXT, currentYear TEXT, totalPreviousAcresFarm TEXT, totalPresentAcresFarm TEXT, phiPreviousAcresFarm TEXT, phiPresentAcresFarm TEXT, targetPreviousAcresFarm TEXT, targetPresentAcresFarm TEXT, rice TEXT, corn TEXT, millet TEXT, mustard TEXT, targetHybridFarm TEXT, activityId NUMBER, farmerName TEXT, farmerMobileNo TEXT)");
        db.execSQL("CREATE TABLE UPLOAD_FILE_PRAVAKTA (id INTEGER PRIMARY KEY AUTOINCREMENT,url TEXT,userType TEXT,userMobileId TEXT,userServerId TEXT)");

        // new version 8
//        db.execSQL("CREATE TABLE VILLAGE_PROFILE (id INTEGER PRIMARY KEY AUTOINCREMENT, villageName TEXT, pinCode TEXT, blockName TEXT, cropId NUMBER, cropName TEXT, segment NUMBER, segmentName TEXT, date TEXT, location TEXT, regionId NUMBER, isSync NUMBER, uploadedDate TEXT)");
        db.execSQL("CREATE TABLE ADD_MDR_SURVEY (id INTEGER PRIMARY KEY AUTOINCREMENT, localImagePath TEXT, latlong TEXT, farmerName TEXT, mobileNo TEXT, noOfFamilies NUMBER, totalLand NUMBER, majorCropOneName TEXT, hybridAcresOne NUMBER, majorCropTwoName TEXT, hybridAcresTwo NUMBER, cropAcreageFor TEXT, segmentDetails TEXT, pioneerAcres NUMBER, pioneerHybridOneId NUMBER, pioneerHybridOneName TEXT, pioneerHybridTwoId NUMBER, pioneerHybridTwoName TEXT, majorCompetitorOne TEXT, majorCompetitorOneAcres NUMBER, majorCompetitorTwo TEXT, majorCompetitorTwoAcres NUMBER, activityId NUMBER)");

        // new version 9
        db.execSQL("CREATE TABLE OTHER_CROP_MASTER(id NUMBER ,name TEXT, cropId NUMBER)");
        db.execSQL("CREATE TABLE UPLOADED_VILLAGE_LIST (id NUMBER, villageName TEXT, season TEXT, crop TEXT, uploadedDate TEXT)");

        //database version 10 updated VILLAGE_PROFILE table
        db.execSQL("CREATE TABLE VILLAGE_PROFILE (id INTEGER PRIMARY KEY AUTOINCREMENT, villageName TEXT, pinCode TEXT, blockName TEXT, cropId NUMBER, cropName TEXT, segment NUMBER, segmentName TEXT, date TEXT, location TEXT, regionId NUMBER, isSync NUMBER, uploadedDate TEXT,isPDAVillage TEXT,retailerMobileNumber TEXT )");

        //New Survey Details

        db.execSQL("CREATE TABLE ADD_MDR_NEW_SURVEY (id INTEGER PRIMARY KEY AUTOINCREMENT, localImagePath TEXT,  geoLocation TEXT, farmerName TEXT, mobileNo TEXT, noOfFamilies NUMBER, totalLand NUMBER, majorCompany1 NUMBER, majorCompany1Acreage NUMBER, majorCompany2 NUMBER, majorCompany2Acreage NUMBER, majorCompany3 NUMBER, majorCompany3Acreage NUMBER, majorCompany4 NUMBER, majorCompany4Acreage NUMBER, majorCompany5 NUMBER, majorCompany5Acreage NUMBER, otherCompanyAcreage NUMBER, segmentTypeUpland NUMBER, segmentTypeMidland NUMBER, segmentTypeMidLowland NUMBER, segmentTypeFineRice NUMBER, segmentTypeLowland NUMBER, pioneerHybridType1Acres NUMBER, pioneerHybridType2Acres NUMBER, pioneerHybridType3Acres NUMBER, pioneerHybrid1 NUMBER, pioneerHybrid1Acres NUMBER, pioneerHybrid2 NUMBER, pioneerHybrid2Acres NUMBER, date TEXT, activityId NUMBER, totalResearchAcres NUMBER, majorResearchCompanyName NUMBER)");
        db.execSQL("CREATE TABLE COMPANY_MASTER (id NUMBER, name TEXT, cropId NUMBER)");

        //Added in version 12
        db.execSQL("CREATE TABLE RESEARCH_COMPANY_MASTER (id NUMBER, name TEXT, cropId NUMBER)");

        //Added in version 13
        db.execSQL("CREATE TABLE GERMINATION_VERIFICATION (germinationClaimTransactionId NUMBER,year NUMBER, seasonName TEXT, cropName TEXT, name TEXT, farmerMobileNumber TEXT, pincode TEXT, germinationFailedAcres NUMBER,totalSowedAcres NUMBER, dateOfSowing TEXT, status TEXT, sync NUMBER, remarks TEXT, geoLocation TEXT, mdrVerifiedDate TEXT)");


        // Added in version 16
        db.execSQL("CREATE TABLE SEGMENTATION_SEASON (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_YEARS (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_CROP (id NUMBER, name TEXT, seasonId TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_GRAIN_HYBRID (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_SILAGE_HYBRID (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_GRAIN_SERVICES (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_SILAGE_SERVICES (id NUMBER, name TEXT)");
//        db.execSQL("CREATE TABLE SEGMENTATION_REQUEST (id INTEGER PRIMARY KEY AUTOINCREMENT, year TEXT, season NUMBER, crop NUMBER, mobileNo TEXT, pincode TEXT, farmerName TEXT, district TEXT, village TEXT, block TEXT, totalPlanAc NUMBER, planGrainAc NUMBER, plansilageAc NUMBER, phiGrainAc NUMBER, phiSilageAc NUMBER, grainHybrid1 TEXT, grainHybrid2 TEXT, grainHybrid3 TEXT, grainHybrid4 TEXT, grainHybridValue1 NUMBER, grainHybridValue2 NUMBER, grainHybridValue3 NUMBER, grainHybridValue4 NUMBER, silageHybrid1 TEXT, silageHybrid2 TEXT, silageHybrid3 TEXT, silageHybrid4 TEXT, silageHybridValue1 NUMBER, silageHybridValue2 NUMBER, silageHybridValue3 NUMBER, silageHybridValue4 NUMBER, geoLocation TEXT, timeStamp TEXT, grainServices TEXT, silageServices TEXT, isTBL TEXT, localImagePath TEXT, isSync NUMBER, grainCompetitorHybrid1 TEXT, grainCompetitorHybrid2 TEXT, grainCompetitorHybrid3 TEXT, grainCompetitorHybrid4 TEXT, grainCompetitorHybridValue1 NUMBER, grainCompetitorHybridValue2 NUMBER, grainCompetitorHybridValue3 NUMBER, grainCompetitorHybridValue4 NUMBER, silageCompetitorHybrid1 TEXT, silageCompetitorHybrid2 TEXT, silageCompetitorHybrid3 TEXT, silageCompetitorHybrid4 TEXT, silageCompetitorHybridValue1 NUMBER, silageCompetitorHybridValue2 NUMBER, silageCompetitorHybridValue3 NUMBER, silageCompetitorHybridValue4 NUMBER)");
        db.execSQL("CREATE TABLE SEGMENTATION_REQUEST (id INTEGER PRIMARY KEY AUTOINCREMENT, year TEXT, season NUMBER, crop NUMBER, mobileNo TEXT, pincode TEXT, farmerName TEXT, district TEXT, village TEXT, block TEXT, totalPlanAc NUMBER, planGrainAc NUMBER, plansilageAc NUMBER, phiGrainAc NUMBER, phiSilageAc NUMBER, grainHybrid1 TEXT, grainHybrid2 TEXT, grainHybrid3 TEXT, grainHybrid4 TEXT, grainHybridValue1 NUMBER, grainHybridValue2 NUMBER, grainHybridValue3 NUMBER, grainHybridValue4 NUMBER, silageHybrid1 TEXT, silageHybrid2 TEXT, silageHybrid3 TEXT, silageHybrid4 TEXT, silageHybridValue1 NUMBER, silageHybridValue2 NUMBER, silageHybridValue3 NUMBER, silageHybridValue4 NUMBER, geoLocation TEXT, timeStamp TEXT, grainServices TEXT, silageServices TEXT, isTBL TEXT, localImagePath TEXT, isSync NUMBER, grainCompetitorHybrid1 TEXT, grainCompetitorHybrid2 TEXT, grainCompetitorHybrid3 TEXT, grainCompetitorHybrid4 TEXT, grainCompetitorHybridValue1 NUMBER, grainCompetitorHybridValue2 NUMBER, grainCompetitorHybridValue3 NUMBER, grainCompetitorHybridValue4 NUMBER, silageCompetitorHybrid1 TEXT, silageCompetitorHybrid2 TEXT, silageCompetitorHybrid3 TEXT, silageCompetitorHybrid4 TEXT, silageCompetitorHybridValue1 NUMBER, silageCompetitorHybridValue2 NUMBER, silageCompetitorHybridValue3 NUMBER, silageCompetitorHybridValue4 NUMBER, visitedCornHybrid TEXT, visitedCornHybridLike TEXT, rateHybrid TEXT, shiftNextYrAcres TEXT, grainCompetitorHybrid5 TEXT, grainCompetitorHybridValue5 NUMBER, silageCompetitorHybrid5 TEXT, silageCompetitorHybridValue5 NUMBER)");

        //Added in version 17
        db.execSQL("CREATE TABLE SEGMENTATION_RICE_HYBRID (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_RICE_SERVICES (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE SEGMENTATION_RICE_REQUEST(id INTEGER PRIMARY KEY AUTOINCREMENT,year TEXT, season NUMBER, crop NUMBER, mobileNo TEXT, pincode TEXT,farmerName TEXT, district TEXT, village TEXT, block TEXT, totalPlanAc NUMBER, hybridAc NUMBER, typeOfIrrigation TEXT, maturity124Ac NUMBER, maturity134Ac NUMBER, maturity135Ac NUMBER, riceHybrid1 TEXT,riceHybrid2 TEXT, riceHybrid3 TEXT, riceHybrid4 TEXT, riceHybridValue1 NUMBER,riceHybridValue2 NUMBER,riceHybridValue3 NUMBER,riceHybridValue4 NUMBER,riceServices TEXT, riceCompetitorHybrid1 TEXT, riceCompetitorHybrid2 TEXT, riceCompetitorHybrid3 TEXT, riceCompetitorHybrid4 TEXT,riceCompetitorHybridValue1 NUMBER,riceCompetitorHybridValue2 NUMBER,riceCompetitorHybridValue3 NUMBER,riceCompetitorHybridValue4 NUMBER,directSowingRice TEXT,localImagePath TEXT,isTBL TEXT,timeStamp TEXT,isSync NUMBER,geoLocation TEXT)");

        //Added in version 17
        //Newly Created
        db.execSQL("CREATE TABLE TABLE_FS_DIVISION (id NUMBER, name TEXT)");
        db.execSQL("CREATE TABLE TABLE_FS_SCHOOL (id NUMBER, name TEXT,devCenterId NUMBER)");
        db.execSQL("CREATE TABLE FARMER_SCHOOL_SILAGE (id INTEGER PRIMARY KEY AUTOINCREMENT, year TEXT, mobileNo TEXT, pincode TEXT, farmerName TEXT, " +
                "district TEXT, village TEXT, block TEXT, geoLocation TEXT, localImagePath TEXT, timeStamp TEXT," +
                " isSync NUMBER, devCenterId NUMBER, schoolId NUMBER, totalNoOfCattles NUMBER, " +
                "avgMilkYield NUMBER, silageFeeding TEXT, growingOrProcuring TEXT, silageAcres NUMBER," +
                "currHyb1Name TEXT, currHyb1Value TEXT, currHyb2Name TEXT, currHyb2Value TEXT, currHyb3Name TEXT," +
                " currHyb3Value TEXT, currHyb4Name TEXT, currHyb4Value TEXT, currHyb5Name TEXT, currHyb5Value TEXT, " +
                "trainingPlant TEXT, trainingGrow TEXT, trainingHarvest TEXT, trainingStore TEXT, trainingFeed TEXT)");
        //FARMER_SCHOOL_SILAGE
    }


    /**
     * Called when the database needs to be upgraded.
     *
     * @param db         : The database.
     * @param oldVersion : The old database version.
     * @param newVersion : The new database version.
     */
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        ATBuildLog.d(TAG, "PS:: onUpgrade called oldVersion\t" + oldVersion + "   newVersion\t" + newVersion);
        switch (oldVersion) {
            case 1: {

                db.execSQL("CREATE TABLE DIPSTICK(id INTEGER PRIMARY KEY AUTOINCREMENT, activityType TEXT, year NUMBER, seasonId NUMBER, cropId NUMBER,  isSampleIssued NUMBER, hybridId NUMBER, farmerName TEXT, farmerNumber TEXT, cropAcres REAL, hybridCropAcres REAL, otherCropAcres REAL,"
                        + "pioneerHyb1 REAL, pioneerHyb2 REAL, competitorHybrid1 REAL, competitorHybrid2 REAL, competitorHybrid3 REAL, competitorHybrid4 REAL, competitorHybrid5 REAL, date TEXT DEFAULT (datetime('now','localtime')), regionId NUMBER, location TEXT, isSync NUMBER, uploadedDate TEXT, pioneerHyb1Name TEXT, pioneerHyb2Name TEXT)");

                db.execSQL("CREATE TABLE DIPSTICK_MASTER(id INTEGER, activityType TEXT, year NUMBER, seasonId NUMBER, cropId NUMBER,  isSampleIssued NUMBER, hybridId NUMBER, farmerName TEXT, farmerNumber TEXT, cropAcres REAL, hybridCropAcres REAL, otherCropAcres REAL,"
                        + "pioneerHyb1 REAL, pioneerHyb2 REAL, competitorHybrid1 REAL, competitorHybrid2 REAL, competitorHybrid3 REAL, competitorHybrid4 REAL, competitorHybrid5 REAL, date TEXT, regionId NUMBER, location TEXT, isSync NUMBER, uploadedDate TEXT, pioneerHyb1Name TEXT, pioneerHyb2Name TEXT)");

                db.execSQL("CREATE TABLE SEASONS(id NUMBER ,name TEXT)");

            }
            case 2: {
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN numberOfFarmers NUMBER");
            }
            case 3: {
                db.execSQL("CREATE TABLE SEGMENT_MASTER(id NUMBER ,segmentName TEXT, cropId NUMBER)");

                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN pinCode TEXT");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN blockName TEXT");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN segment NUMBER");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN cropHa TEXT");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN phiHa TEXT");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN majorPHIHybrid1 NUMBER");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN majorPHIHybrid2 NUMBER");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN majorCompetitionHybrid1 TEXT");
                db.execSQL("ALTER TABLE MDR_PROFILE ADD COLUMN majorCompetitionHybrid2 TEXT");
            }
            case 4: {
                db.execSQL("ALTER TABLE PDA_ACTIVITY ADD COLUMN acresExposed TEXT");

                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN competitorHybrid1Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN competitorHybrid2Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN competitorHybrid3Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN competitorHybrid4Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN competitorHybrid5Name TEXT");

                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN competitorHybrid1Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN competitorHybrid2Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN competitorHybrid3Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN competitorHybrid4Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN competitorHybrid5Name TEXT");

                db.execSQL("ALTER TABLE PDA_ACTIVITY ADD COLUMN farmerBarCodeDetails TEXT ");
                db.execSQL("ALTER TABLE OSA_ACTIVITY ADD COLUMN farmerBarCodeDetails TEXT ");
                db.execSQL("ALTER TABLE PSA_ACTIVITY ADD COLUMN farmerBarCodeDetails TEXT ");
            }
            case 5: {
                db.execSQL("ALTER TABLE PDA_ACTIVITY ADD COLUMN farmerAttendanceDetails TEXT ");
                db.execSQL("ALTER TABLE OSA_ACTIVITY ADD COLUMN farmerAttendanceDetails TEXT ");
                db.execSQL("ALTER TABLE PSA_ACTIVITY ADD COLUMN farmerAttendanceDetails TEXT ");
                db.execSQL("ALTER TABLE AGRONOMY_ACTIVITY ADD COLUMN pincode TEXT ");
                db.execSQL("ALTER TABLE PDA_ACTIVITY ADD COLUMN pincode TEXT ");
                db.execSQL("ALTER TABLE OSA_ACTIVITY ADD COLUMN pincode TEXT ");
                db.execSQL("ALTER TABLE PSA_ACTIVITY ADD COLUMN pincode TEXT ");
            }
            case 6: {
                db.execSQL("CREATE TABLE IF NOT EXISTS PRAVAKTA_HA_AGAIN(id INTEGER PRIMARY KEY AUTOINCREMENT, pravaktaName TEXT, mobileNo TEXT, villageName TEXT, pincode TEXT, imageUrlPath TEXT, blockName TEXT, districtName TEXT, previousYear TEXT, currentYear TEXT, totalPreviousAcres TEXT, totalPresentAcres TEXT, phiPreviousAcres TEXT, phiPresentAcres TEXT, targetPreviousAcres TEXT, targetPresentAcres TEXT, rice TEXT, corn TEXT, millet TEXT, mustard TEXT, targetHybrid TEXT, blockType TEXT, villageType TEXT, isSync NUMBER, location TEXT)");

                db.execSQL("CREATE TABLE IF NOT EXISTS PRAVAKTA_FARMER(id INTEGER PRIMARY KEY AUTOINCREMENT, imageUrlPath TEXT, pdaAttendPre TEXT, pdaAttendCurr TEXT, pionUserPre TEXT, pionUserCurr TEXT, previousYear TEXT, currentYear TEXT, totalPreviousAcresFarm TEXT, totalPresentAcresFarm TEXT, phiPreviousAcresFarm TEXT, phiPresentAcresFarm TEXT, targetPreviousAcresFarm TEXT, targetPresentAcresFarm TEXT, rice TEXT, corn TEXT, millet TEXT, mustard TEXT, targetHybridFarm TEXT, activityId NUMBER, farmerName TEXT, farmerMobileNo TEXT)");

                db.execSQL("CREATE TABLE IF NOT EXISTS UPLOAD_FILE_PRAVAKTA (id INTEGER PRIMARY KEY AUTOINCREMENT,url TEXT,userType TEXT,userMobileId TEXT,userServerId TEXT)");

            }
            case 7: {
                db.execSQL("CREATE TABLE IF NOT EXISTS VILLAGE_PROFILE (id INTEGER PRIMARY KEY AUTOINCREMENT, villageName TEXT, pinCode TEXT, blockName TEXT, cropId NUMBER, cropName TEXT, segment NUMBER, segmentName TEXT, date TEXT, location TEXT, regionId NUMBER, isSync NUMBER, uploadedDate TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS ADD_MDR_SURVEY (id INTEGER PRIMARY KEY AUTOINCREMENT, localImagePath TEXT, latlong TEXT, farmerName TEXT, mobileNo TEXT, noOfFamilies NUMBER, totalLand NUMBER, majorCropOneName TEXT, hybridAcresOne NUMBER, majorCropTwoName TEXT, hybridAcresTwo NUMBER, cropAcreageFor TEXT, segmentDetails TEXT, pioneerAcres NUMBER, pioneerHybridOneId NUMBER, pioneerHybridOneName TEXT, pioneerHybridTwoId NUMBER, pioneerHybridTwoName TEXT, majorCompetitorOne TEXT, majorCompetitorOneAcres NUMBER, majorCompetitorTwo TEXT, majorCompetitorTwoAcres NUMBER, activityId NUMBER)");
            }
            case 8: {
                db.execSQL("CREATE TABLE IF NOT EXISTS OTHER_CROP_MASTER(id NUMBER ,name TEXT, cropId NUMBER)");
                db.execSQL("CREATE TABLE IF NOT EXISTS UPLOADED_VILLAGE_LIST (id NUMBER, villageName TEXT, season TEXT, crop TEXT, uploadedDate TEXT)");

                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN otherCrop1 NUMBER ");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN otherCrop2 NUMBER ");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN  otherCropArea1 NUMBER ");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN  otherCropArea2 NUMBER ");

                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN otherCrop1 NUMBER ");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN otherCrop2 NUMBER ");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN  otherCropArea1 NUMBER ");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN  otherCropArea2 NUMBER ");
            }
            case 9: {
                db.execSQL("ALTER TABLE VILLAGE_PROFILE ADD COLUMN  isPDAVillage TEXT");
                db.execSQL("ALTER TABLE VILLAGE_PROFILE ADD COLUMN  retailerMobileNumber TEXT");
            }
            case 10: {
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN  userType TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN  f2Acreages REAL");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN  userType TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN  f2Acreages REAL");
                db.execSQL("CREATE TABLE  IF NOT EXISTS ADD_MDR_NEW_SURVEY (id INTEGER PRIMARY KEY AUTOINCREMENT, localImagePath TEXT,  geoLocation TEXT, farmerName TEXT, mobileNo TEXT, noOfFamilies NUMBER, totalLand NUMBER, majorCompany1 NUMBER, majorCompany1Acreage NUMBER, majorCompany2 NUMBER, majorCompany2Acreage NUMBER, majorCompany3 NUMBER, majorCompany3Acreage NUMBER, majorCompany4 NUMBER, majorCompany4Acreage NUMBER, majorCompany5 NUMBER, majorCompany5Acreage NUMBER, otherCompanyAcreage NUMBER, segmentTypeUpland NUMBER, segmentTypeMidland NUMBER, segmentTypeMidLowland NUMBER, segmentTypeFineRice NUMBER, segmentTypeLowland NUMBER, pioneerHybridType1Acres NUMBER, pioneerHybridType2Acres NUMBER, pioneerHybridType3Acres NUMBER, pioneerHybrid1 NUMBER, pioneerHybrid1Acres NUMBER, pioneerHybrid2 NUMBER, pioneerHybrid2Acres NUMBER, date TEXT, activityId NUMBER)");
                db.execSQL("CREATE TABLE  IF NOT EXISTS COMPANY_MASTER (id NUMBER, name TEXT, cropId NUMBER)");

            }
            case 11: {
                db.execSQL("ALTER TABLE ADD_MDR_NEW_SURVEY ADD COLUMN  totalResearchAcres NUMBER");
                db.execSQL("ALTER TABLE ADD_MDR_NEW_SURVEY ADD COLUMN  majorResearchCompanyName NUMBER");
                db.execSQL("CREATE TABLE IF NOT EXISTS RESEARCH_COMPANY_MASTER (id NUMBER, name TEXT, cropId NUMBER)");
            }

            case 12: {
                db.execSQL("CREATE TABLE IF NOT EXISTS GERMINATION_VERIFICATION (germinationClaimTransactionId NUMBER,year NUMBER, seasonName TEXT, cropName TEXT, name TEXT, farmerMobileNumber TEXT, pincode TEXT, germinationFailedAcres NUMBER,totalSowedAcres NUMBER, dateOfSowing TEXT, status TEXT, sync NUMBER, remarks TEXT, geoLocation TEXT, mdrVerifiedDate TEXT)");
            }
            case 13: {
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN seedSettingIssue TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN pioneerHyb3Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN pioneerHyb4Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN pioneerHyb3 REAL");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN pioneerHyb4 REAL");

                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN seedSettingIssue TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN pioneerHyb3Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN pioneerHyb4Name TEXT");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN pioneerHyb3 REAL");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN pioneerHyb4 REAL");
            }
            case 14: {
                db.execSQL("ALTER TABLE PDA_ACTIVITY ADD COLUMN isTBLParticipated TEXT");
                db.execSQL("ALTER TABLE OSA_ACTIVITY ADD COLUMN isTBLParticipated TEXT");
                db.execSQL("ALTER TABLE PSA_ACTIVITY ADD COLUMN isTBLParticipated TEXT");

                db.execSQL("ALTER TABLE PDA_ACTIVITY ADD COLUMN numberOfPravaktas NUMBER");
                db.execSQL("ALTER TABLE OSA_ACTIVITY ADD COLUMN numberOfPravaktas NUMBER");
                db.execSQL("ALTER TABLE PSA_ACTIVITY ADD COLUMN numberOfPravaktas NUMBER");

                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN seedSettingIssue1 REAL");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN seedSettingIssue2 REAL");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN seedSettingIssue3 REAL");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN seedSettingIssue4 REAL");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN competitorHybrid1SeedSettingIssue REAL");
                db.execSQL("ALTER TABLE DIPSTICK ADD COLUMN competitorHybrid2SeedSettingIssue REAL");

                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN seedSettingIssue1 REAL");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN seedSettingIssue2 REAL");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN seedSettingIssue3 REAL");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN seedSettingIssue4 REAL");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN competitorHybrid1SeedSettingIssue REAL");
                db.execSQL("ALTER TABLE DIPSTICK_MASTER ADD COLUMN competitorHybrid2SeedSettingIssue REAL");
            }

            case 15: {
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_SEASON (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_CROP (id NUMBER, name TEXT, seasonId TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_YEARS (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_GRAIN_HYBRID (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_SILAGE_HYBRID (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_GRAIN_SERVICES (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_SILAGE_SERVICES (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS SEGMENTATION_REQUEST (id INTEGER PRIMARY KEY AUTOINCREMENT, year TEXT, season NUMBER, crop NUMBER, mobileNo TEXT, pincode TEXT, farmerName TEXT, district TEXT, village TEXT, block TEXT, totalPlanAc NUMBER, planGrainAc NUMBER, plansilageAc NUMBER, phiGrainAc NUMBER, phiSilageAc NUMBER, grainHybrid1 TEXT, grainHybrid2 TEXT, grainHybrid3 TEXT, grainHybrid4 TEXT, grainHybridValue1 NUMBER, grainHybridValue2 NUMBER, grainHybridValue3 NUMBER, grainHybridValue4 NUMBER, silageHybrid1 TEXT, silageHybrid2 TEXT, silageHybrid3 TEXT, silageHybrid4 TEXT, silageHybridValue1 NUMBER, silageHybridValue2 NUMBER, silageHybridValue3 NUMBER, silageHybridValue4 NUMBER, geoLocation TEXT, timeStamp TEXT, grainServices TEXT, silageServices TEXT, isTBL TEXT, localImagePath TEXT, isSync NUMBER, grainCompetitorHybrid1 TEXT, grainCompetitorHybrid2 TEXT, grainCompetitorHybrid3 TEXT, grainCompetitorHybrid4 TEXT, grainCompetitorHybridValue1 NUMBER, grainCompetitorHybridValue2 NUMBER, grainCompetitorHybridValue3 NUMBER, grainCompetitorHybridValue4 NUMBER, silageCompetitorHybrid1 TEXT, silageCompetitorHybrid2 TEXT, silageCompetitorHybrid3 TEXT, silageCompetitorHybrid4 TEXT, silageCompetitorHybridValue1 NUMBER, silageCompetitorHybridValue2 NUMBER, silageCompetitorHybridValue3 NUMBER, silageCompetitorHybridValue4 NUMBER)");

            }
            case 16: {
                //Added in version 17
                db.execSQL("CREATE TABLE SEGMENTATION_RICE_HYBRID (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE SEGMENTATION_RICE_SERVICES (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE SEGMENTATION_RICE_REQUEST(id INTEGER PRIMARY KEY AUTOINCREMENT,year TEXT, season NUMBER, crop NUMBER, mobileNo TEXT, pincode TEXT,farmerName TEXT, district TEXT, village TEXT, block TEXT, totalPlanAc NUMBER, hybridAc NUMBER, typeOfIrrigation TEXT, maturity124Ac NUMBER, maturity134Ac NUMBER, maturity135Ac NUMBER, riceHybrid1 TEXT,riceHybrid2 TEXT, riceHybrid3 TEXT, riceHybrid4 TEXT, riceHybridValue1 NUMBER,riceHybridValue2 NUMBER,riceHybridValue3 NUMBER,riceHybridValue4 NUMBER,riceServices TEXT, riceCompetitorHybrid1 TEXT, riceCompetitorHybrid2 TEXT, riceCompetitorHybrid3 TEXT, riceCompetitorHybrid4 TEXT,riceCompetitorHybridValue1 NUMBER,riceCompetitorHybridValue2 NUMBER,riceCompetitorHybridValue3 NUMBER,riceCompetitorHybridValue4 NUMBER,directSowingRice TEXT,localImagePath TEXT,isTBL TEXT,timeStamp TEXT,isSync NUMBER,geoLocation TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS TABLE_FS_DIVISION (id NUMBER, name TEXT)");
                db.execSQL("CREATE TABLE IF NOT EXISTS TABLE_FS_SCHOOL (id NUMBER, name TEXT,devCenterId NUMBER)");
                db.execSQL("CREATE TABLE IF NOT EXISTS FARMER_SCHOOL_SILAGE (id INTEGER PRIMARY KEY AUTOINCREMENT, year TEXT, mobileNo TEXT, pincode TEXT, farmerName TEXT, " +
                        "district TEXT, village TEXT, block TEXT, geoLocation TEXT, localImagePath TEXT, timeStamp TEXT," +
                        " isSync NUMBER, devCenterId NUMBER, schoolId NUMBER, totalNoOfCattles NUMBER, " +
                        "avgMilkYield NUMBER, silageFeeding TEXT, growingOrProcuring TEXT, silageAcres NUMBER," +
                        "currHyb1Name TEXT, currHyb1Value TEXT, currHyb2Name TEXT, currHyb2Value TEXT, currHyb3Name TEXT," +
                        " currHyb3Value TEXT, currHyb4Name TEXT, currHyb4Value TEXT, currHyb5Name TEXT, currHyb5Value TEXT, " +
                        "trainingPlant TEXT, trainingGrow TEXT, trainingHarvest TEXT, trainingStore TEXT, trainingFeed TEXT)");
            }
            case 17: {
                db.execSQL("ALTER TABLE PDA_ACTIVITY ADD COLUMN isFAWDone TEXT");
                db.execSQL("ALTER TABLE OSA_ACTIVITY ADD COLUMN isFAWDone TEXT");
                db.execSQL("ALTER TABLE PSA_ACTIVITY ADD COLUMN isFAWDone TEXT");
            }
            case 18: {
                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN visitedCornHybrid TEXT");
                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN visitedCornHybridLike TEXT");
                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN rateHybrid TEXT");
                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN shiftNextYrAcres TEXT");

                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN grainCompetitorHybrid5 TEXT");
                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN grainCompetitorHybridValue5 NUMBER");
                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN silageCompetitorHybrid5 TEXT");
                db.execSQL("ALTER TABLE SEGMENTATION_REQUEST ADD COLUMN silageCompetitorHybridValue5 NUMBER");

            }
            case 19: {
                db.execSQL("ALTER TABLE AGRONOMY_ACTIVITY ADD COLUMN dateOfSowing TEXT");
                db.execSQL("ALTER TABLE AGRONOMY_ACTIVITY ADD COLUMN acresSowed NUMBER");
            }
        }
    }
}
