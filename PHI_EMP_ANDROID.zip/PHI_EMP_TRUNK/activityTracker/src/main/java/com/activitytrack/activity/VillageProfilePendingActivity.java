package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.activitytrack.adapter.PendingVillageProfileAdapter;
import com.activitytrack.daos.MdrFarmerDAO;
import com.activitytrack.daos.NewMdrSurveyDAO;
import com.activitytrack.daos.VillageProfileDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.VillageProfileDTO;
import com.activitytrack.listeners.OnListItemClickListener;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.List;

/**
 * Created by fatima.t on 04-04-2018.
 */

public class VillageProfilePendingActivity extends AppCompatActivity implements OnListItemClickListener, View.OnClickListener {
    public static final String EXTRA_PENDING_SIZE = "DataSize";
    private RecyclerView recyclerView;
    private TextView noDataTxt;
    private ActionBar actionBar;
    private VillageProfilePendingActivity thisActivity;
    private PendingVillageProfileAdapter listAdapter;

    private List<VillageProfileDTO> profileDataList;
    private Button addnewVillageBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Utility.getCurrentTheme(VillageProfilePendingActivity.this).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(VillageProfilePendingActivity.this).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_villageprofiles_list);
         thisActivity = this;

        actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        profileDataList = VillageProfileDAO.getInstance().getPendingRecords(thisActivity, DBHandler.getInstance(thisActivity).getDBObject(0));
        setToolbarTitle();

        recyclerView = (RecyclerView) findViewById(R.id.pvp_recycler_view);
        noDataTxt = (TextView) findViewById(R.id.pvp_no_data_txt);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setAutoMeasureEnabled(true);
        recyclerView.setLayoutManager(layoutManager);
        listAdapter = new PendingVillageProfileAdapter(VillageProfilePendingActivity.this, profileDataList, this);
        recyclerView.setAdapter(listAdapter);

        addnewVillageBtn = (Button) findViewById(R.id.pvp_addVillageBtn);
        addnewVillageBtn.setOnClickListener(this);

        showHideViews();
    }

    private void setToolbarTitle(){
        String title;
        if(profileDataList.size() > 0) {
            title = profileDataList.size() > 1 ? getString(R.string.pending_villageProfiles) : getString(R.string.pending_village_profile);
            title += " - " + profileDataList.size();
        }else
            title = getString(R.string.pending_village_profile);

        actionBar.setTitle(title);
    }

    private void showHideViews() {
        if (profileDataList.size() > 0 && profileDataList != null){
            noDataTxt.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            noDataTxt.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {

        int i = view.getId();
        VillageProfileDTO dto = (VillageProfileDTO) view.getTag();
        final long id = dto.getId();
        final Intent mIntent = new Intent();
        if (i == R.id.pvp_list_deleteBtn) {
            // This Id item to be deleted from DB
            showAlertToDeleteConfirm(id, dto.getVillageName());

        } else if ( i == R.id.pvp_list_editBtn){
            // this id item to be edited.
            mIntent.putExtra(MDRProfileFragment.ACTIVITY_ID_VP_LIST_ACTIVITY, ""+id);
            setResult(RESULT_OK, mIntent);
            finish();
        }
    }

    private void updateList() {
        profileDataList.clear();
        profileDataList.addAll(VillageProfileDAO.getInstance().getPendingRecords(thisActivity, DBHandler.getInstance(thisActivity).getDBObject(0)));
        listAdapter.notifyDataSetChanged();
        showHideViews();
        setToolbarTitle();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra(EXTRA_PENDING_SIZE, profileDataList.size());
        setResult(RESULT_OK, intent);
        finish();
    }

    private void showAlertToDeleteConfirm(final long id, String villageName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(thisActivity);
        String msg = "This will delete the complete village data of village : <b>"+villageName+"</b>, including survey and farmer data<br>Are you sure you want to delete ?";
        builder.setMessage(Html.fromHtml(msg));
        builder.setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                VillageProfileDAO.getInstance().deleteTableDataById(id, DBHandler.getInstance(thisActivity).getDBObject(1));
                MdrFarmerDAO.getInstance().deleteTableDataById(id, DBHandler.getInstance(thisActivity).getDBObject(1));
                NewMdrSurveyDAO.getInstance().deleteTableDataById(id, DBHandler.getInstance(thisActivity).getDBObject(1));
                updateList();
            }
        });

        builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.pvp_addVillageBtn) {
            onBackPressed();
        }
    }
}
