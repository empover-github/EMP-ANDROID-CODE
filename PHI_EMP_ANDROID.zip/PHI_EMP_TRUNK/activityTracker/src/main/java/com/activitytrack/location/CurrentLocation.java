package com.activitytrack.location;
import java.util.TimerTask;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.CountDownTimer;

public class CurrentLocation {
//	Timer timerLastKnow;
	CountDownTimer timerLastKnow;
	LocationManager lm;
	LocationResult locationResult;
	boolean gps_enabled=false;
	//boolean network_enabled=false;
	
	private Context context;
	
	private int LOCATION_TIMEOUT = 30000;

	public boolean getLocation(Context context, LocationResult result)
	{
		this.context = context;
		this.locationResult=result;
		if(lm==null)
			lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

		try{

			gps_enabled=lm.isProviderEnabled(LocationManager.GPS_PROVIDER);

		}
		catch(Exception ex){
			System.out.println("GPS Exception");
		}

		

		if(!gps_enabled)
			return false;
		
		if(gps_enabled)
			lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListenerGps);
		
		

		try {
//			timerLastKnow=new Timer();
//			timerLastKnow.schedule(new GetLastLocation(), LOCATION_TIMEOUT);
			
			timerLastKnow = new CountDownTimer(LOCATION_TIMEOUT, 1000) {

			     public void onTick(long millisUntilFinished) {
			         
			     }

			     public void onFinish() {
			    	 try {
							lm.removeUpdates(locationListenerGps);
							System.out.println("Location from LastKnownLocation");

							Location gps_loc=null;
							if(gps_enabled)
								gps_loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
							
							 //if(gps_loc!=null){
								locationResult.gotLocation(gps_loc);
								System.out.println("IF GPS present "+gps_loc);
							//}
						
							if(timerLastKnow != null )
							timerLastKnow.cancel();
						} catch (Exception e) {
							e.printStackTrace();
						}
			     }
			  }.start();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return true;
	}

	LocationListener locationListenerGps = new LocationListener() {
		public void onLocationChanged(Location location) {
			if(timerLastKnow != null )
				timerLastKnow.cancel();
			System.out.println("Location From GPS");
			lm.removeUpdates(locationListenerGps);
			locationResult.gotLocation(location);
			
		}
		public void onProviderDisabled(String provider) {}
		public void onProviderEnabled(String provider) {}
		public void onStatusChanged(String provider, int status, Bundle extras) {}
	};

	/*LocationListener locationListenerNetwork = new LocationListener() {
		public void onLocationChanged(Location location) {
			System.out.println("Location from Network");
			if(timerLastKnow != null )
			timerLastKnow.cancel();
			lm.removeUpdates(locationListenerGps);
			locationResult.gotLocation(location);
			
		}
		public void onProviderDisabled(String provider) {}
		public void onProviderEnabled(String provider) {}
		public void onStatusChanged(String provider, int status, Bundle extras) {}
	};*/

	class GetLastLocation extends TimerTask implements Runnable {
		@Override
		public void run() {
			try {
				lm.removeUpdates(locationListenerGps);
				System.out.println("Location from LastKnownLocation");

				Location gps_loc=null;
				if(gps_enabled)
					gps_loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
				
				 //if(gps_loc!=null){
					locationResult.gotLocation(gps_loc);
					System.out.println("IF GPS present "+gps_loc);
				//}
			
					/*((Activity)context).runOnUiThread(new Runnable() {
						  public void run() {
						    Toast.makeText(((Activity)context), "GetLastLocation", Toast.LENGTH_SHORT).show();
						  }
						});*/
					
				if(timerLastKnow != null )
				timerLastKnow.cancel();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static abstract class LocationResult{
		public abstract void gotLocation(Location location);
	}

	/*public void cancelTimer() {
		if(timerLastKnow != null )
		{
		timerLastKnow.cancel();
		}
		timerLastKnow = null;
		lm.removeUpdates(locationListenerGps);
		}*/
}