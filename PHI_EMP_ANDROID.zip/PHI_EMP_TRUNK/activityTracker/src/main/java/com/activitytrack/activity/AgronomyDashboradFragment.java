package com.activitytrack.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.activitytrack.daos.AgronomySummaryDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdaos.TargetAgronomyDAO;
import com.activitytrack.masterdaos.Top3HybridsDAO;
import com.activitytrack.masterdtos.SeasonCalendarDTO;
import com.activitytrack.masterdtos.Top3HybridsDTO;
import com.activitytrack.meterlib.SpeedometerGauge;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.Legend.LegendForm;
import com.github.mikephil.charting.components.Legend.LegendPosition;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.XAxis.XAxisPosition;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.components.YAxis.YAxisLabelPosition;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ValueFormatter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public class AgronomyDashboradFragment extends BaseFragment {

	private ImageView btnPlus;

	private RelativeLayout demandLayout;
	private ImageView agronomyImg;
	private TextView agronomyText;
	private View agronomyBottom;
	
	private int selectedCrop;
	
	private SpeedometerGauge speedometer;
	
	private LinearLayout cropCornLayout;
	private LinearLayout cropRiceLayout;
	private LinearLayout cropMilletLayout;
	private LinearLayout cropMustardLayout;
	
	private ImageView cropCornImg;
	private ImageView cropRiceImg;
	private ImageView cropMilletImg;
	private ImageView cropMustardImg;
	private TextView cropCornTxt;
	private TextView cropRiceTxt;
	private TextView cropMilletTxt;
	private TextView cropMustardTxt;
	
	private LinearLayout mainLayout;
	protected BarChart mBarChart;
	
	private TextView tvLegendTotalTarget;
	private TextView tvLegendTillDate;
	private TextView tvLegendTargetTillDate;
	private ImageView imgLegendTotalTarget;
	private TextView tvTotalTarget;
	private TextView tvTillDateAchieve;
	private TextView tvTargetTillDate;
	
	private int totalTarget;
	private int targetAchieved;
	private long seasonId;
	private long seasonCalId;
	
	private List<Long> hybridIdsList = new ArrayList<Long>();
	private List<String> hybridNamesList = new ArrayList<String>();
	
	private LinkedHashMap<String, Integer> activityTargetMap = new LinkedHashMap<String, Integer>();
	private LinkedHashMap<String, Integer> activityAchievedMap = new LinkedHashMap<String, Integer>();
	
	private List<Long> cropsList = new ArrayList<Long>();
	
	private View view;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.agronomy_dashboard_fragment, container, false);
		
		// tab ids references
		demandLayout = (RelativeLayout) view.findViewById(R.id.db_demand_layout);
		agronomyImg = (ImageView) view.findViewById(R.id.db_agronomyImg);
		agronomyText = (TextView) view.findViewById(R.id.db_agronomyText);
		agronomyBottom = view.findViewById(R.id.db_agronomyBottom);
		btnPlus = (ImageView) view.findViewById(R.id.ag_addBtn);
		
		agronomyImg.setImageResource(R.drawable.agronamy_icon_f);
		agronomyText.setTextColor(getResources().getColor(R.color.tab_activeText_color));
		agronomyBottom.setVisibility(View.VISIBLE);
		
		speedometer=(SpeedometerGauge) view.findViewById(R.id.ag_progressmeter);

		// crops image references
		cropCornLayout = (LinearLayout) view.findViewById(R.id.ag_cropCorn_layout);
		cropRiceLayout = (LinearLayout) view.findViewById(R.id.ag_cropRice_layout);
		cropMilletLayout = (LinearLayout) view.findViewById(R.id.ag_cropMillet_layout);
		cropMustardLayout = (LinearLayout) view.findViewById(R.id.ag_cropMustard_layout);
		
		cropCornImg = (ImageView) view.findViewById(R.id.ag_cropCorn_icon);
		cropRiceImg = (ImageView) view.findViewById(R.id.ag_cropRice_icon);
		cropMilletImg = (ImageView) view.findViewById(R.id.ag_cropMillet_icon);
		cropMustardImg = (ImageView) view.findViewById(R.id.ag_cropMustard_icon);
		cropCornTxt = (TextView) view.findViewById(R.id.ag_cropCorn_text);
		cropRiceTxt = (TextView) view.findViewById(R.id.ag_cropRice_text);
		cropMilletTxt = (TextView) view.findViewById(R.id.ag_cropMillet_text);
		cropMustardTxt = (TextView) view.findViewById(R.id.ag_cropMustard_text);
		
		tvLegendTargetTillDate = (TextView) view.findViewById(R.id.ag_legend_targetTillDate);
		tvLegendTillDate = (TextView) view.findViewById(R.id.ag_legend_tillDate);
		tvLegendTotalTarget = (TextView) view.findViewById(R.id.ag_legend_totalTarget);
		imgLegendTotalTarget = (ImageView) view.findViewById(R.id.ag_legend_totalTargetImg);
		
		tvTargetTillDate = (TextView) view.findViewById(R.id.ag_targetTillDateTxt);
		tvTotalTarget = (TextView) view.findViewById(R.id.ag_toatalTargetTxt);
		tvTillDateAchieve = (TextView) view.findViewById(R.id.ag_tillDateAchievementTxt);
		
		mainLayout = (LinearLayout) view.findViewById(R.id.ag_mailLayout);
		
		mBarChart = (BarChart) view.findViewById(R.id.ag_barChart);
		
		agronomyImg.setImageResource(R.drawable.agronamy_icon_f);
		agronomyText.setTextColor(getResources().getColor(R.color.tab_activeText_color));
		agronomyBottom.setVisibility(View.VISIBLE);

		setTheme();
		setBarChatProperties();
		
		hideCropLayouts();
		
		demandLayout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mActivity.dashboardPopFragments();
				mActivity.pushFragments(MyConstants.TAB_DASHBOARD, new DemandGenFragment(), false, true);
			}
		});
		
		cropCornLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_CORN_ID);
			}
		});

		cropRiceLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_RICE_ID);
			}
		});

		cropMilletLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_MILLET_ID);
			}
		});

		cropMustardLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_MUSTARD_ID);
			}
		});

		
		
		btnPlus.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				  String seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(selectedCrop,MyConstants.ACTIVITY_AGR_ID,DBHandler.getInstance(mActivity).getDBObject(0));
                  boolean res = Utility.isSeasonExpire(seasonEndDate,Utility.getCurrentformatedDate());
				 if(res)
				 {
					 Utility.showAlert(mActivity, "",  getResources().getString(R.string.seacal) + "Agronomy" +  " of crop " + (Utility.getCropNameById(selectedCrop)) + " is over");
					 return;
				 } 
				 if(selectedCrop!=0){
				BaseFragment fragment = new AgronomyFragment();
				Bundle bundle = new Bundle();
				bundle.putInt("cropId", selectedCrop);
				fragment.setArguments(bundle);
				mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
			  }else{
				  Utility.showAlert(mActivity, "Alert", "Crop is not available");
			  }
			}
		});
		
		selectedCrop = 0;
		totalTarget = 0;
		
		List<Integer> totalTargetList = TargetAgronomyDAO.getInstance().getTotalTarget(DBHandler.getInstance(mActivity).getDBObject(0));
		if(totalTargetList != null && totalTargetList.size() == 1){
			totalTarget = totalTargetList.get(0);
		}
		
		targetAchieved = AgronomySummaryDAO.getInstance().getActivitiesCount(DBHandler.getInstance(mActivity).getDBObject(0));
		
		drawGraph(targetAchieved, totalTarget);
		//drawGraph(10, 50);
		setCrops(MyConstants.ACTIVITY_AGR_ID);
		
		return view;
	}
	
	private void setCrops(int activityId){
		List<DTO> seasonList = SeasonCalendarDAO.getInstance().getRecordInfoByValue("activityId", ""+activityId, DBHandler.getInstance(mActivity).getDBObject(0));
		if(seasonList != null && seasonList.size() > 0){
			hideCropLayouts();
			cropsList.clear();
			for(DTO tempDto : seasonList){
				SeasonCalendarDTO seasonDto = (SeasonCalendarDTO) tempDto;
				seasonId = seasonDto.getSeasonId();
				//dummy
				cropsList.add(seasonDto.getCropId());
				if(seasonDto.getCropId() == MyConstants.CROP_CORN_ID)
					cropCornLayout.setVisibility(View.VISIBLE);
				else if(seasonDto.getCropId() == MyConstants.CROP_RICE_ID)
					cropRiceLayout.setVisibility(View.VISIBLE);
				else if(seasonDto.getCropId() == MyConstants.CROP_MILLET_ID)
					cropMilletLayout.setVisibility(View.VISIBLE);
				else if(seasonDto.getCropId() == MyConstants.CROP_MUSTARD_ID)
					cropMustardLayout.setVisibility(View.VISIBLE);
			
			}
			
			cropSelection(cropsList.get(0));
			
		}
	}//end of setCrops
	
	private void hideCropLayouts(){
		cropCornLayout.setVisibility(View.GONE);
		cropRiceLayout.setVisibility(View.GONE);
		cropMilletLayout.setVisibility(View.GONE);
		cropMustardLayout.setVisibility(View.GONE);
	}

	private void cropSelection(long crop) {
		
		mBarChart.clear();
		
		cropCornImg.setImageResource(R.drawable.corn_icon);
		cropMilletImg.setImageResource(R.drawable.millet_icon);
		cropMustardImg.setImageResource(R.drawable.mustard_icon);
		cropRiceImg.setImageResource(R.drawable.rice_icon);
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
		}

		if (crop == MyConstants.CROP_CORN_ID) {
			cropCornImg.setImageResource(R.drawable.corn_icon_f);
			cropCornTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_CORN_ID;
			
			
			
		} else if (crop == MyConstants.CROP_RICE_ID) {
			cropRiceImg.setImageResource(R.drawable.rice_icon_f);
			cropRiceTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_RICE_ID;
		} else if (crop == MyConstants.CROP_MILLET_ID) {
			cropMilletImg.setImageResource(R.drawable.millet_icon_f);
			cropMilletTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_MILLET_ID;
		} else if (crop == MyConstants.CROP_MUSTARD_ID) {
			cropMustardImg.setImageResource(R.drawable.mustard_icon_f);
			cropMustardTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_MUSTARD_ID;
		}
		
		List<DTO> hybridsList = Top3HybridsDAO.getInstance().getRecords(MyConstants.ACTIVITY_AGR_ID, selectedCrop, DBHandler.getInstance(mActivity).getDBObject(0));
		if(hybridsList != null && hybridsList.size() > 0){
			hybridIdsList.clear();
			hybridNamesList.clear();
			activityAchievedMap.clear();
			activityTargetMap.clear();
			for(DTO dto : hybridsList){
				Top3HybridsDTO hybridsDTO = (Top3HybridsDTO) dto;
				hybridIdsList.add(hybridsDTO.getHybridId());
				hybridNamesList.add(hybridsDTO.getHybridName());
				List<Integer> totalAchievedList = null;
				List<Integer> totalHybridTargetList = null;
				
				totalHybridTargetList = TargetAgronomyDAO.getInstance().getTotalTargetByHybrid(String.valueOf(hybridsDTO.getHybridId()), DBHandler.getInstance(mActivity).getDBObject(0));
				
				totalAchievedList = AgronomySummaryDAO.getInstance().getAchievedCount(selectedCrop, hybridsDTO.getHybridId(),  DBHandler.getInstance(mActivity).getDBObject(0));
				
				if(totalHybridTargetList != null && totalHybridTargetList.size() == 1){
					activityTargetMap.put(hybridsDTO.getHybridName(), totalHybridTargetList.get(0));
				}
				
				if(totalAchievedList != null && totalAchievedList.size() == 1){
					activityAchievedMap.put(hybridsDTO.getHybridName(), totalAchievedList.get(0));
				}
				
			}
			
			if(activityTargetMap != null && activityAchievedMap != null){
				setBarGraphData(activityTargetMap, activityAchievedMap);
			}else{
				mBarChart.setVisibility(View.INVISIBLE);
			}
		}
		
		
	} // end cropSelection	
		


	/*@Override
	public void onResume() {
		 mActivity.invalidateOptionsMenu();
		*//*if(mActivity.menu != null){
			mActivity.menu.findItem(R.id.action_home).setIcon(R.drawable.transparent_img);
			mActivity.menu.findItem(R.id.action_home).setEnabled(false);
		}*//*
		super.onResume();
	}
	
	@Override
	public void onPause() {
		mActivity.invalidateOptionsMenu();
		*//*if(mActivity.menu != null){
			mActivity.menu.findItem(R.id.action_home).setIcon(R.drawable.home_icon);
			mActivity.menu.findItem(R.id.action_home).setEnabled(true);
		}*//*
		super.onPause();
	}*/
	
	private void drawGraph(int achieved, int totalTarget) {
		
		tvTillDateAchieve.setText(""+achieved);
		tvTotalTarget.setText(""+totalTarget);
		
		// configure value range and ticks
		if(achieved > totalTarget)
			speedometer.setMaxSpeed(achieved);
		else
			speedometer.setMaxSpeed(totalTarget);
		
		speedometer.setSpeed(achieved);

		// Configure value range colors
		if(achieved > totalTarget)
		{
			speedometer.addColoredRange(totalTarget, achieved, Color.rgb(66, 119, 48));
			if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
				speedometer.addColoredRange(0, totalTarget, Color.WHITE);
			}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
				speedometer.addColoredRange(0, totalTarget, Color.rgb(195, 195, 195));
			}
		}else{
			speedometer.addColoredRange(0, achieved, Color.rgb(66, 119, 48));
			if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
				speedometer.addColoredRange(achieved, totalTarget, Color.WHITE);
			}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
				speedometer.addColoredRange(achieved, totalTarget, Color.rgb(195, 195, 195));
			}
		}
		
	}

	private void setBarChatProperties() {
		
		mBarChart.setDrawBarShadow(false);
		mBarChart.setDrawValueAboveBar(true);

		mBarChart.setDescription("");

		// if more than 60 entries are displayed in the chart, no values will be
		// drawn
		mBarChart.setMaxVisibleValueCount(60);

		// scaling can now only be done on x- and y-axis separately
		mBarChart.setPinchZoom(true);

		//mBarChart.animateXY(2000, 2000);

		// draw shadows for each bar that show the maximum value
		// mChart.setDrawBarShadow(true);

		// mChart.setDrawXLabels(false);

		mBarChart.setDrawGridBackground(false);
		// mChart.setDrawYLabels(false);
		
		mBarChart.getLegend().setEnabled(false);

		// mTf = Typeface.createFromAsset(getAssets(), "OpenSans-Regular.ttf");

		XAxis xAxis = mBarChart.getXAxis();
		xAxis.setPosition(XAxisPosition.BOTTOM);
		// xAxis.setTypeface(mTf);
		xAxis.setDrawGridLines(false);
		xAxis.setSpaceBetweenLabels(2);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			xAxis.setTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			xAxis.setTextColor(Color.BLACK);
		}

		ValueFormatter custom = new com.activitytrack.graph.MyValueFormatter();

		YAxis leftAxis = mBarChart.getAxisLeft();
		leftAxis.setDrawGridLines(false);
		// leftAxis.setTypeface(mTf);
		leftAxis.setLabelCount(8);
		leftAxis.setValueFormatter(custom);
		leftAxis.setPosition(YAxisLabelPosition.OUTSIDE_CHART);
		leftAxis.setSpaceTop(15f);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			leftAxis.setTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			leftAxis.setTextColor(Color.BLACK);
		}

		YAxis rightAxis = mBarChart.getAxisRight();
		rightAxis.setEnabled(false);
		rightAxis.setDrawGridLines(false);
		// rightAxis.setTypeface(mTf);
		//rightAxis.setLabelCount(8);
		//rightAxis.setValueFormatter(custom);
		//rightAxis.setSpaceTop(15f);

		Legend l = mBarChart.getLegend();
		l.setPosition(LegendPosition.BELOW_CHART_LEFT);
		l.setForm(LegendForm.SQUARE);
		l.setFormSize(9f);
		l.setTextSize(11f);
		l.setXEntrySpace(4f);

		// setData(12, 50);

		//setBarGraphData();

	}
	
	public void setBarGraphData(LinkedHashMap<String, Integer> graphDataMap, LinkedHashMap<String, Integer> graphDataMap2){
		
//		LinkedHashMap<String, Integer> graphDataMap = new LinkedHashMap<String, Integer>();
//		graphDataMap.put("H-1", 22);
//		graphDataMap.put("H-2", 14);
//		graphDataMap.put("H-3", 13);
		/*graphDataMap.put("H-4", 26f);
		graphDataMap.put("H-5", 5f);
		graphDataMap.put("H-6", 16f);
		graphDataMap.put("H-7", 12f);
		graphDataMap.put("H-8", 16f);
		graphDataMap.put("H-9", 12f);*/
		
		Set<String> keys2 = graphDataMap.keySet();
		System.out.println("ffffff"+keys2);
		
		List<String> xVals2 = new ArrayList<String>();
		List<Integer> valuesList2 = new ArrayList<Integer>();
		for(String key:keys2){
			xVals2.add(key);
			valuesList2.add(graphDataMap.get(key));
		}
		
		ArrayList<BarEntry> yVals2 = new ArrayList<BarEntry>();
		
		for (int i = 0; i < valuesList2.size(); i++) {
			yVals2.add(new BarEntry(valuesList2.get(i), i));
		}
		
		BarDataSet set2 = new BarDataSet(yVals2, "DataSet1");
		
		set2.setBarSpacePercent(35f);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			set2.setValueTextColor(Color.WHITE);
			set2.setColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			set2.setColor(Color.rgb(195, 195, 195));
			set2.setValueTextColor(Color.BLACK);
		}
		
//		Map<String, Integer> graphDataMap2 = new HashMap<String, Integer>();
//		graphDataMap2.put("H-1", 12);
//		graphDataMap2.put("H-2", 11);
//		graphDataMap2.put("H-3", 19);
		/*graphDataMap2.put("H-4", 17f);
		graphDataMap2.put("H-5", 16f);
		graphDataMap2.put("H-6", 10f);
		graphDataMap2.put("H-7", 15f);
		graphDataMap2.put("H-8", 10f);
		graphDataMap2.put("H-9", 15f);*/
		
		Set<String> keys3 = graphDataMap2.keySet();
		
		List<String> xVals3 = new ArrayList<String>();
		List<Integer> valuesList3 = new ArrayList<Integer>();
		
		for(String key:keys3){
			xVals3.add(key);
			valuesList3.add(graphDataMap2.get(key));
		}
		
		ArrayList<BarEntry> yVals3 = new ArrayList<BarEntry>();
		
		for (int i = 0; i < valuesList3.size(); i++) {
			yVals3.add(new BarEntry(valuesList3.get(i), i));
		}
		
		BarDataSet set3 = new BarDataSet(yVals3, "DataSet2");
		
		set3.setBarSpacePercent(35f);
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			set3.setValueTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			set3.setValueTextColor(Color.BLACK);
		}
		
		set3.setColor(Color.rgb(66, 119, 48));
		
		ArrayList<BarDataSet> dataSets = new ArrayList<BarDataSet>();
		dataSets.add(set2);
		dataSets.add(set3);
		
		BarData data = new BarData(xVals2, dataSets);
		data.setValueTextSize(10f);
		mBarChart.setData(data);
		
	}
	

	
	
	private void setTheme() {
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
			
			//legend text colors
			tvLegendTargetTillDate.setTextColor(Color.WHITE);
			tvLegendTillDate.setTextColor(Color.WHITE);
			tvLegendTotalTarget.setTextColor(Color.WHITE);			
			imgLegendTotalTarget.setBackgroundColor(Color.WHITE);
			tvTotalTarget.setTextColor(Color.WHITE);
			
			//crop text colors
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
		
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
			
			//legend text colors
			tvLegendTargetTillDate.setTextColor(Color.BLACK);
			tvLegendTillDate.setTextColor(Color.BLACK);
			tvLegendTotalTarget.setTextColor(Color.BLACK);
			
			imgLegendTotalTarget.setBackgroundColor(Color.parseColor("#c3c3c3"));
			tvTotalTarget.setTextColor(Color.parseColor("#c3c3c3"));
			
			//crop text colors
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
		
		}
	}

	@Override
	public boolean onBackPressed(int callbackCode) {
		mActivity.onBackPressedCallBack(callbackCode);
		return true;
	}

 
 
 
}
