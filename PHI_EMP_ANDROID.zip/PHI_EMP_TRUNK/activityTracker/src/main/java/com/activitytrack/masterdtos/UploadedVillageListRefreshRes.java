package com.activitytrack.masterdtos;

import com.activitytrack.dtos.UploadedVillageListDTO;

import java.util.List;

public class UploadedVillageListRefreshRes {
    private int code;
    private List<UploadedVillageListDTO> villageProfileUploadedData;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<UploadedVillageListDTO> getVillageProfileUploadedData() {
        return villageProfileUploadedData;
    }

    public void setVillageProfileUploadedData(List<UploadedVillageListDTO> villageProfileUploadedData) {
        this.villageProfileUploadedData = villageProfileUploadedData;
    }
}
