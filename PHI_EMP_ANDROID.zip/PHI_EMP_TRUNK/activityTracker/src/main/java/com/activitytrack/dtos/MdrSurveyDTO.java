package com.activitytrack.dtos;

/**
 * Created by fatima.t on 29-03-2018.
 */

public class MdrSurveyDTO implements DTO {
    private String localImagePath;
    private String latlong;
    private String farmerName;
    private String mobileNo;
    private long noOfFamilies;
    private long totalLand;
    private String majorCropOneName;
    private long hybridAcresOne;
    private String majorCropTwoName;
    private long hybridAcresTwo;
    private String cropAcreageFor;
    private String segmentDetails;
    private long pioneerAcres;
    private long pioneerHybridOneId;
    private String pioneerHybridOneName;
    private long pioneerHybridTwoId;
    private String pioneerHybridTwoName;
    private String majorCompetitorOne;
    private long majorCompetitorOneAcres;
    private String majorCompetitorTwo;
    private long majorCompetitorTwoAcres;

    private long mobileId;
    private long activityId;

    public String getLocalImagePath() {
        return localImagePath;
    }

    public void setLocalImagePath(String localImagePath) {
        this.localImagePath = localImagePath;
    }

    public String getLatlong() {
        return latlong;
    }

    public void setLatlong(String latlong) {
        this.latlong = latlong;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public long getNoOfFamilies() {
        return noOfFamilies;
    }

    public void setNoOfFamilies(long noOfFamilies) {
        this.noOfFamilies = noOfFamilies;
    }

    public long getTotalLand() {
        return totalLand;
    }

    public void setTotalLand(long totalLand) {
        this.totalLand = totalLand;
    }

    public String getMajorCropOneName() {
        return majorCropOneName;
    }

    public void setMajorCropOneName(String majorCropOneName) {
        this.majorCropOneName = majorCropOneName;
    }

    public long getHybridAcresOne() {
        return hybridAcresOne;
    }

    public void setHybridAcresOne(long hybridAcresOne) {
        this.hybridAcresOne = hybridAcresOne;
    }

    public String getMajorCropTwoName() {
        return majorCropTwoName;
    }

    public void setMajorCropTwoName(String majorCropTwoName) {
        this.majorCropTwoName = majorCropTwoName;
    }

    public long getHybridAcresTwo() {
        return hybridAcresTwo;
    }

    public void setHybridAcresTwo(long hybridAcresTwo) {
        this.hybridAcresTwo = hybridAcresTwo;
    }

    public String getCropAcreageFor() {
        return cropAcreageFor;
    }

    public void setCropAcreageFor(String cropAcreageFor) {
        this.cropAcreageFor = cropAcreageFor;
    }

    public String getSegmentDetails() {
        return segmentDetails;
    }

    public void setSegmentDetails(String segmentDetails) {
        this.segmentDetails = segmentDetails;
    }

    public long getPioneerAcres() {
        return pioneerAcres;
    }

    public void setPioneerAcres(long pioneerAcres) {
        this.pioneerAcres = pioneerAcres;
    }

    public long getPioneerHybridOneId() {
        return pioneerHybridOneId;
    }

    public void setPioneerHybridOneId(long pioneerHybridOneId) {
        this.pioneerHybridOneId = pioneerHybridOneId;
    }

    public String getPioneerHybridOneName() {
        return pioneerHybridOneName;
    }

    public void setPioneerHybridOneName(String pioneerHybridOneName) {
        this.pioneerHybridOneName = pioneerHybridOneName;
    }

    public long getPioneerHybridTwoId() {
        return pioneerHybridTwoId;
    }

    public void setPioneerHybridTwoId(long pioneerHybridTwoId) {
        this.pioneerHybridTwoId = pioneerHybridTwoId;
    }

    public String getPioneerHybridTwoName() {
        return pioneerHybridTwoName;
    }

    public void setPioneerHybridTwoName(String pioneerHybridTwoName) {
        this.pioneerHybridTwoName = pioneerHybridTwoName;
    }

    public String getMajorCompetitorOne() {
        return majorCompetitorOne;
    }

    public void setMajorCompetitorOne(String majorCompetitorOne) {
        this.majorCompetitorOne = majorCompetitorOne;
    }

    public long getMajorCompetitorOneAcres() {
        return majorCompetitorOneAcres;
    }

    public void setMajorCompetitorOneAcres(long majorCompetitorOneAcres) {
        this.majorCompetitorOneAcres = majorCompetitorOneAcres;
    }

    public String getMajorCompetitorTwo() {
        return majorCompetitorTwo;
    }

    public void setMajorCompetitorTwo(String majorCompetitorTwo) {
        this.majorCompetitorTwo = majorCompetitorTwo;
    }

    public long getMajorCompetitorTwoAcres() {
        return majorCompetitorTwoAcres;
    }

    public void setMajorCompetitorTwoAcres(long majorCompetitorTwoAcres) {
        this.majorCompetitorTwoAcres = majorCompetitorTwoAcres;
    }

    public long getId() {
        return mobileId;
    }

    public void setId(long mobileid) {

        this.mobileId = mobileid;
    }

    public long getActivityId() {
        return activityId;
    }

    public void setActivityId(long activityId) {
        this.activityId = activityId;
    }
}
