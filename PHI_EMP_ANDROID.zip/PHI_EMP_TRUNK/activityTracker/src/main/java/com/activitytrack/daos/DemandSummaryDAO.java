package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.DemandSummaryDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class DemandSummaryDAO  implements DAO
{
	
	
	private final String TAG = "DmndSummary";
    private static DemandSummaryDAO demandSummaryDAO;

    public static DemandSummaryDAO getInstance()
    {
        if (demandSummaryDAO == null)
        {
        	demandSummaryDAO = new DemandSummaryDAO();
        }
        
        return demandSummaryDAO ;
    }


    /**
     * delete the Data
     */
    @Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}
   
    /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
  
	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			{
		List<DTO> demandSummaryInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
        	if(!(columnName != null && columnName.length() > 0))
        		columnName = "id";
        	
            cursor = dbObject.rawQuery("SELECT * FROM DEMAND_SUMMARY where "+columnName+"='"+columnValue+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {

                    /* DEMAND_SUMMARY
                         id
        				 activityId
        				 sampleCount
        				 hybridId
        				 cropId
        				 seasonCalendarId
        				 seasonId
        				 retailerCount
        				 farmerCount
        				 isSync
        				 
                     */
                	DemandSummaryDTO dto=new DemandSummaryDTO();
                	
                	 dto.setId(cursor.getLong(0));
                	 dto.setActivityId(cursor.getLong(1));
                	 dto.setSampleCount(cursor.getInt(2));
                	 dto.setHybridId(cursor.getLong(3));
                	 dto.setCropId(cursor.getLong(4));
                	 dto.setSeasonCalendarId(cursor.getLong(5));
                	 dto.setSeasonId(cursor.getLong(6));
                	 dto.setRetailerCount(cursor.getInt(7));
                	 dto.setFarmerCount(cursor.getInt(8));
                	 dto.setIsSync(cursor.getInt(9));
                	 
                	
                	demandSummaryInfo.add(dto); 
   				 
   			 }while(cursor.moveToNext());
   		 }
   		
   		}catch(Exception e)
   		{
			ATBuildLog.e(TAG +"getRecords()",e.getMessage());
   		}finally
   		
   		{
   			if(cursor!=null && !cursor.isClosed())
   			{
   				cursor.close();
   			}
   		
   		dbObject.close();
   		
   		}
   		
   		
   	 
   		return demandSummaryInfo;
   	}
	
	public List<Integer> getActivitiesCount(long cropId, String columnValue, SQLiteDatabase dbObject)
	{
		List<Integer> count = new ArrayList<Integer>();
        Cursor cursor = null;
        try
        {
			cursor = dbObject.rawQuery("SELECT sum(sampleCount), sum(farmerCount) FROM DEMAND_SUMMARY where cropId = '"+cropId+"' AND activityId='"+columnValue+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                count.add(cursor.getInt(0));
                count.add(cursor.getInt(1));
   		 	}
   		
   		}catch(Exception e)
   		{
			ATBuildLog.e(TAG +"getCount()",e.getMessage());
   		}finally
   		
   		{
   			if(cursor!=null && !cursor.isClosed())
   			{
   				cursor.close();
   			}
   		dbObject.close();
   		}
   		return count;
   	}
	
    
	 /**
     * Gets all the records from the database
     *
      * @param dbObject
      *            : Exposes methods to manage a SQLite database Object
      */
    
	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)
	{
		List<DTO> demandSummaryInfo=new  ArrayList<DTO>();
		 Cursor cursor=null;
		 try{
			 cursor=dbObject.rawQuery("SELECT * FROM  DEMAND_SUMMARY",null);
			 if(cursor.getCount()>0)
				 
			 {
				cursor.moveToFirst();
				 do{
					
					 DemandSummaryDTO dto=new DemandSummaryDTO();
	                	
					 dto.setId(cursor.getLong(0));
                	 dto.setActivityId(cursor.getLong(1));
                	 dto.setSampleCount(cursor.getInt(2));
                	 dto.setHybridId(cursor.getLong(3));
                	 dto.setCropId(cursor.getLong(4));
                	 dto.setSeasonCalendarId(cursor.getLong(5));
                	 dto.setSeasonId(cursor.getLong(6));
                	 dto.setRetailerCount(cursor.getInt(7));
                	 dto.setFarmerCount(cursor.getInt(8));
                	 dto.setIsSync(cursor.getInt(9));
                	 	
                	 demandSummaryInfo.add(dto); 
	           		 
					}while(cursor.moveToNext());
					 
				 }
				 
				 
			 }catch (Exception e) 
			 {
				 ATBuildLog.e(TAG + "getRecords()",e.getMessage());
				 
			}finally{
				if(cursor!=null && !cursor.isClosed())
				{
					cursor.close();
				}
				dbObject.close();
			}
			return demandSummaryInfo;
		}

			
    public List<Integer> getAchievedCount(String activityId, long cropId, long hybridId, SQLiteDatabase dbObject)  
	{
	List<Integer> achievedInfo = new ArrayList<Integer>();
    Cursor cursor = null;
    try
    {
    	 cursor = dbObject.rawQuery("select sum(sampleCount), sum(farmerCount) from DEMAND_SUMMARY where activityId = '"+activityId+"' and cropId ='"+cropId+"' and hybridId = '"+hybridId+"'", null);
        if (cursor.getCount() > 0)
        {
            cursor.moveToFirst();
            achievedInfo.add(cursor.getInt(0));
            achievedInfo.add(cursor.getInt(1));
        }
      } catch (Exception e)
	{
		ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	} finally
	{
	   if (cursor != null && !cursor.isClosed())
	   {
	       cursor.close();
	   }
	   dbObject.close();
	}
	
	return achievedInfo;
	}
		 
	/**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
   


	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		 try
		 {
			 DemandSummaryDTO  dto=(DemandSummaryDTO) dtoObject;
				
			 ContentValues cValues=new ContentValues();
			
			 /* DEMAND_SUMMARY
               	          id
        				 activityId
        				 sampleCount
        				 hybridId
        				 cropId
        				 seasonCalendarId
        				 seasonId
        				 retailerCount
        				 farmerCount
        				 isSync
        				
			  */
			 
			 cValues.put("activityId",dto.getActivityId());
			 cValues.put("sampleCount",dto.getSampleCount());
			 cValues.put("hybridId",dto.getHybridId());
			 cValues.put("cropId",dto.getCropId());
			 cValues.put("seasonCalendarId",dto.getSeasonCalendarId());
			 cValues.put("seasonId",dto.getSeasonId());
			 cValues.put("retailerCount",dto.getRetailerCount());
			 cValues.put("farmerCount",dto.getFarmerCount());
			 cValues.put("isSync",dto.getIsSync());
		     
			 dbObject.insert("DEMAND_SUMMARY", null, cValues);
			     return true;
			 }catch(SQLException e)
			 {
				 ATBuildLog.e(TAG +"insert()",e.getMessage());
				return false;
				
			 }finally{
				 dbObject.close();
			 }
			 
			 
		}
		
	
	/**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
		
		try
		 { 
			 DemandSummaryDTO dto= (DemandSummaryDTO) dtoObject;
			 
			 ContentValues cValues=new ContentValues(); 
			 
             if(dto.getSampleCount()!= 0 )
            	 cValues.put("sampleCount",dto.getSampleCount());
             
             if(dto.getHybridId()!= 0)
            	 cValues.put("hybridId",dto.getHybridId());
           
             if(dto.getCropId()!= 0)
            	 cValues.put("cropId",dto.getCropId());
           
             if(dto.getSeasonCalendarId()!= 0)
            	 cValues.put("seasonCalendarI",dto.getSeasonCalendarId());
            
             if(dto.getSeasonId()!= 0)
            	 cValues.put("seasonId",dto.getSeasonId());
            
             if(dto.getFarmerCount()!= 0)
            	 cValues.put("farmerCount",dto.getFarmerCount());
             
             if(dto.getRetailerCount()!= 0)
            	 cValues.put("retailerCount",dto.getRetailerCount());
            	 
			 cValues.put("isSync",dto.getIsSync());
			
			 
			 
			 int rowsEffected = dbObject.update("DEMAND_SUMMARY", cValues, "activityId='" +dto.getActivityId()+"' ", null);
	           if(rowsEffected > 0) 
	        	   return true;
		 
		 }catch(SQLException e)
		 {
			 ATBuildLog.e(TAG + "update()",e.getMessage());
			 e.printStackTrace();
		 } catch (Exception e)
		 {
			 e.printStackTrace();
		 }finally
		 {
			 dbObject.close();
		 }
		return false;
	}
	
	/**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM DEMAND_SUMMARY").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }


}
