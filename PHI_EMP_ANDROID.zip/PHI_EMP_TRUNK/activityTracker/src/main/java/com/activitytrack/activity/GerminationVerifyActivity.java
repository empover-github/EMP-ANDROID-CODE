package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.ActionBar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.activitytrack.daos.GerminationListDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.app.Activity.RESULT_OK;

public class GerminationVerifyActivity extends BaseActivity implements View.OnClickListener {
    private GerminationVerifyActivity thisActivity;
    private GerminationverificationListDTO model; 
    
    private EditText farmerNameEt, mobileNoEt, pincodeEt, yearEt, seasonEt, cropEt, totalSowedAcresEt, germinationfailedAcresEt, dateOfSowingEt, remarksEt;
    private TextView farmerNameTv, mobileNoTv, pincodeTv, yearTv, seasonTv, cropTv, totalSowedAcresTv, germinationfailedAcresTv, dateOfSowingTv, remarksTv;
    private Button btnSubmit;
    private LinearLayout mainlayout;


    public static final String EXTRA_MODEL_DATA = "extraData";
    private String latLongValues;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_LIGHT)) {
        setTheme(R.style.AppThemeLite);
    } else if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_DARK)) {
        setTheme(R.style.AppThemeAT);
    }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.germination_verification_activity);
        thisActivity = this;
        geoLocation = null;
        
        model = (GerminationverificationListDTO) getIntent().getSerializableExtra(EXTRA_MODEL_DATA);
        String log = model.getGerminationClaimTransactionId()+"-"+model.getTotalSowedAcres()+"-"+model.getGerminationFailedAcres()+"-"+model.getDateOfSowing();
        ATBuildLog.e("MDRVERIFY MODEL", log);

        // set Action bar
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setTitle("Germination Verification");
        }

        initializeViews();
        setChange();

        if (checkLocPermission())
            if (Utility.checkPlayServices(thisActivity)) {
                buildGoogleApiClient();
            }
    }

    private void initializeViews() {
        
        mainlayout = (LinearLayout) findViewById(R.id.mdr_gv_bg_layout);
        farmerNameEt = (EditText)findViewById(R.id.mdr_gv_farmerNameEt);
        mobileNoEt =  (EditText)findViewById(R.id.mdr_gv_farmerMobNoEt);
        pincodeEt = (EditText) findViewById(R.id.mdr_gv_farmerPincodeEt);
        yearEt = (EditText) findViewById(R.id.mdr_gv_yearEt);
        seasonEt =  (EditText)findViewById(R.id.mdr_gv_seasonEt);
        cropEt =  (EditText)findViewById(R.id.mdr_gv_cropEt);
        totalSowedAcresEt =  (EditText)findViewById(R.id.mdr_gv_totalSowedAcresEt);
        germinationfailedAcresEt =  (EditText)findViewById(R.id.mdr_gv_germFailedAcresEt);
        dateOfSowingEt =  (EditText)findViewById(R.id.mdr_gv_dateOfSowingEt);
        remarksEt = (EditText) findViewById(R.id.mdr_gv_remarksEt);

        farmerNameTv = (TextView) findViewById(R.id.mdr_gv_farmerNameTv);
        mobileNoTv = (TextView) findViewById(R.id.mdr_gv_farmerMobNoTv);
        pincodeTv = (TextView) findViewById(R.id.mdr_gv_farmerPincodeTv);
        yearTv = (TextView) findViewById(R.id.mdr_gv_yearTv);
        seasonTv = (TextView) findViewById(R.id.mdr_gv_seasonTv);
        cropTv = (TextView) findViewById(R.id.mdr_gv_cropTv);
        totalSowedAcresTv = (TextView) findViewById(R.id.mdr_gv_totalSowedAcresTv);
        germinationfailedAcresTv = (TextView) findViewById(R.id.mdr_gv_germFailedAcresTv);
        dateOfSowingTv = (TextView) findViewById(R.id.mdr_gv_dateOfSowingTv);
        remarksTv = (TextView) findViewById(R.id.mdr_gv_remarksTv);
        
        btnSubmit = (Button) findViewById(R.id.mdr_gv_submitBtn);
        btnSubmit.setOnClickListener(this);

        setModelData();
    }

    private void setModelData() {
        farmerNameEt.setText(model.getName());
        mobileNoEt.setText(model.getFarmerMobileNumber());
        pincodeEt.setText(model.getPincode());
        yearEt.setText(String.valueOf(model.getYear()));
        seasonEt.setText(model.getSeasonName());
        cropEt.setText(model.getCropName());
        totalSowedAcresEt.setText(String.valueOf(model.getTotalSowedAcres()));
        germinationfailedAcresEt.setText(String.valueOf(model.getGerminationFailedAcres()));
        dateOfSowingEt.setText(model.getDateOfSowing());
    }

    private void setChange() {
        if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_DARK)) {

            farmerNameTv.setTextColor(Color.WHITE);
            mobileNoTv.setTextColor(Color.WHITE);
            pincodeTv.setTextColor(Color.WHITE);
            yearTv.setTextColor(Color.WHITE);
            seasonTv.setTextColor(Color.WHITE);
            cropTv.setTextColor(Color.WHITE);
            totalSowedAcresTv.setTextColor(Color.WHITE);
            germinationfailedAcresTv.setTextColor(Color.WHITE);
            dateOfSowingTv.setTextColor(Color.WHITE);
            remarksTv.setTextColor(Color.WHITE);
            
            mainlayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {

            farmerNameTv.setTextColor(Color.BLACK);
            mobileNoTv.setTextColor(Color.BLACK);
            pincodeTv.setTextColor(Color.BLACK);
            yearTv.setTextColor(Color.BLACK);
            seasonTv.setTextColor(Color.BLACK);
            cropTv.setTextColor(Color.BLACK);
            totalSowedAcresTv.setTextColor(Color.BLACK);
            germinationfailedAcresTv.setTextColor(Color.BLACK);
            dateOfSowingTv.setTextColor(Color.BLACK);
            remarksTv.setTextColor(Color.BLACK);
            
            mainlayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void refresh() {

        latLongValues = geoLocation;
    }

    private boolean checkLocPermission() {

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(thisActivity, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    protected void getCurrentLocation(final Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (mGoogleApiClient != null) {
                if (mGoogleApiClient.isConnected()) {
                    mGoogleApiClient.disconnect();
                }
                mGoogleApiClient.connect();
            }
            CountDownTimer start = new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

                @Override
                public void onTick(long millisUntilFinished) {
                    if (geoLocation != null) {
                        latLongValues = geoLocation;
//                        onLocationCompleted(latLongValues);
//                        locationEt.setText(latLongValues);
                        hideProgressDialog();

                        this.cancel();
                    }
                }

                @Override
                public void onFinish() {
                    hideProgressDialog();
                    this.cancel();
                }
            }.start();
        } else {
            DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.gps), getString(R.string.ok));
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        geoLocation = null;
        if (geoLocation == null) {
            if (checkLocPermission())
                getCurrentLocation(thisActivity);
            else
                showDialogToOpenSetting();

        }

    }

    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(thisActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied location permission with never show option\nPlease enable permissions manually, tap on permissions then enable the location permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(thisActivity, getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }
    public void showInstalledAppDetails(Context context, String packageName) {
        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        finish();
    }

    @Override
    public void onClick(View v) {

        int i = v.getId();
        if (i == R.id.mdr_gv_submitBtn) {
            if (CheckValidations()){
                if (Utility.isValidStr(latLongValues)) {
                    showAlertToSave();
                } else {
                    getCurrentLocation(thisActivity);
                }
            }
        }
    }

    private boolean CheckValidations() {

        double totalAcres, germfailedAcres;

        if (Utility.isValidStr(totalSowedAcresEt.getText().toString().trim()))
            totalAcres = Double.parseDouble(totalSowedAcresEt.getText().toString().trim());
        else
            totalAcres = 0;

        if (Utility.isValidStr(germinationfailedAcresEt.getText().toString().trim()))
            germfailedAcres = Double.parseDouble(germinationfailedAcresEt.getText().toString().trim());
        else
            germfailedAcres = 0;

        if (!Utility.isValidStr(totalSowedAcresEt.getText().toString().trim())) {
            DialogManager.showToast(thisActivity, getString(R.string.total_acres_sowed_error));
            return false;
        } else if (!Utility.isValidStr(germinationfailedAcresEt.getText().toString().trim())) {
            DialogManager.showToast(thisActivity, getString(R.string.germination_faild_acres_sowed_error));
            return false;
        }  else if (totalAcres == 0) {
            DialogManager.showToast(thisActivity, getString(R.string.total_acres_sowed_error_valid));
            return false;
        }   else if (germfailedAcres == 0) {
            DialogManager.showToast(thisActivity, getString(R.string.germination_faild_acres_sowed_error_valid));
            return false;
        } else if (germfailedAcres > totalAcres) {
            DialogManager.showToast(thisActivity, getString(R.string.ger_failed_not_more_total_error));
            return false;
        }

        return true;
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(thisActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveData();
                setResult(RESULT_OK);
                finish();
            }


        });

        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }
    private void saveData() {
       /* germinationClaimTransactionId;
        year;
        seasonName;
        cropName;
        name;
        farmerMobileNumber;
        pincode;
        germinationFailedAcres;
        totalSowedAcres;
        dateOfSowing;
        status;
        sync;
        remarks;
        geoLocation;
        mdrVerifiedDate; // 2018-08-01 yy-mm-dd*/

        GerminationverificationListDTO dto = new GerminationverificationListDTO();
        dto.setGerminationClaimTransactionId(model.getGerminationClaimTransactionId());
        dto.setName(model.getName());
        dto.setFarmerMobileNumber(model.getFarmerMobileNumber());
        dto.setPincode(model.getPincode());
        dto.setYear(model.getYear());
        dto.setSeasonName(model.getSeasonName());
        dto.setCropName(model.getCropName());
        dto.setTotalSowedAcres(Double.parseDouble(totalSowedAcresEt.getText().toString().trim()));
        dto.setGerminationFailedAcres(Double.parseDouble(germinationfailedAcresEt.getText().toString().trim()));
        dto.setDateOfSowing(model.getDateOfSowing());
        dto.setSync(1);
        dto.setRemarks(remarksEt.getText().toString());
        dto.setGeoLocation(latLongValues);
        dto.setMdrVerifiedDate(Utility.getCurrentDateFrm());

        GerminationListDAO.getInstance().update(dto, DBHandler.getInstance(thisActivity).getDBObject(1));
    }

    @Override
    public void onBackPressed() {
        if (isDataAvaliable()) {
            showAlertToExitScreen();
        } else {
            finish();
            setResult(RESULT_CANCELED);
        }
    }

    private boolean isDataAvaliable() {

        /*if (locationEt.getText().toString().trim().length() > 0)
            return true;*/

        if (totalSowedAcresEt.getText().toString().trim().length() > 0)
            return true;

        if (germinationfailedAcresEt.getText().toString().trim().length() > 0)
            return true;

        if (dateOfSowingEt.getText().toString().trim().length() > 0)
            return true;

        if (remarksEt.getText().toString().trim().length() > 0)
            return true;
        return false;
    }
    private void showAlertToExitScreen() {
        AlertDialog.Builder builder = new AlertDialog.Builder(thisActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                setResult(RESULT_OK);
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }
}
