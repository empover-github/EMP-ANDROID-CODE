package com.activitytrack.masterdaos;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.masterdtos.Top3HybridsDTO;
import com.activitytrack.utility.ATBuildLog;

public class Top3HybridsDAO implements MasterDAO 
{
	private final String TAG = "Top3Hybrids";
    private static Top3HybridsDAO top3HybridsDAO;
   
    
    public static Top3HybridsDAO getInstance()
    {
        if (top3HybridsDAO == null)
        {
        	top3HybridsDAO = new Top3HybridsDAO();
        }
        
        return top3HybridsDAO;
    }

    /**
     * delete the Data
     */
  

    @Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}

    /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
    
    @Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			{
    	 List<DTO> top3HybridsInfo = new ArrayList<DTO>();
         Cursor cursor = null;
         try
         {
         	
             cursor = dbObject.rawQuery("SELECT * FROM  TOP3_HYBRIDS where id='"+columnValue+"' ", null);
             if (cursor.getCount() > 0)
             {
                 cursor.moveToFirst();
                 do
                 {
                	 /*TOP3_HYBRIDS
                     id
                     seasonId
                     activityId
                     cropId
                     hybridId
                     hybridName
                     */
                	 Top3HybridsDTO dto = new Top3HybridsDTO();
                	 
                	 dto.setId(cursor.getLong(0));
                	 dto.setSeasonId(cursor.getLong(1));
                	 dto.setActivityId(cursor.getLong(2));
                	 dto.setCropId(cursor.getLong(3));
                	 dto.setHybridId(cursor.getLong(4));
                	 dto.setHybridName(cursor.getString(5));
                	  
                    top3HybridsInfo.add(dto);
                 } while (cursor.moveToNext());
             }
         } catch (Exception e)
         {
             ATBuildLog.e(TAG + "getRecords()", e.getMessage());
         } finally
         {
             if (cursor != null && !cursor.isClosed())
             {
                 cursor.close();
             }
             dbObject.close();
         }

         return top3HybridsInfo;
     }
     
    public List<DTO> getRecords(long activityId, long cropId, SQLiteDatabase dbObject) 
			{
    	 List<DTO> top3HybridsInfo = new ArrayList<DTO>();
         Cursor cursor = null;
         try
         {
         	
             cursor = dbObject.rawQuery("SELECT * FROM  TOP3_HYBRIDS where cropId='"+cropId+"' ", null);
             if (cursor.getCount() > 0)
             {
                 cursor.moveToFirst();
                 do
                 {
                	 /*TOP3_HYBRIDS
                     id
                     seasonId
                     activityId
                     cropId
                     hybridId
                     */
                	 
                	 Top3HybridsDTO dto = new Top3HybridsDTO();
 	                
    	             dto.setId(cursor.getLong(0));
                	 dto.setSeasonId(cursor.getLong(1));
                	 dto.setActivityId(cursor.getLong(2));
                	 dto.setCropId(cursor.getLong(3));
                	 dto.setHybridId(cursor.getLong(4));
                	 dto.setHybridName(cursor.getString(5));
    	             
    	             top3HybridsInfo.add(dto);
    	             
                 } while (cursor.moveToNext());
             }
         } catch (Exception e)
         {
             ATBuildLog.e(TAG + "getRecords()", e.getMessage());
         } finally
         {
             if (cursor != null && !cursor.isClosed())
             {
                 cursor.close();
             }
             dbObject.close();
         }

         return top3HybridsInfo;
     }
    
    /**
     * Gets all the records from the database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */

            
    @Override
	public List<DTO> getRecords(SQLiteDatabase dbObject) 
	{
		List<DTO> top3HybridsInfo = new ArrayList<DTO>();
	       Cursor cursor = null;
	    try
	    {
	        cursor = dbObject.rawQuery("SELECT * FROM  TOP3_HYBRIDS", null);
	        if (cursor.getCount() > 0)
	        {
	            cursor.moveToFirst();
	            do
	            {
	            	Top3HybridsDTO dto = new Top3HybridsDTO();
	                
	             dto.setId(cursor.getLong(0));
            	 dto.setSeasonId(cursor.getLong(1));
            	 dto.setActivityId(cursor.getLong(2));
            	 dto.setCropId(cursor.getLong(3));
            	 dto.setHybridId(cursor.getLong(4));
            	 dto.setHybridName(cursor.getString(5));
	                
	                top3HybridsInfo.add(dto);

	            } while (cursor.moveToNext());
	        } 
	    } catch (Exception e)
	    {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	    } finally
	    {
	        if (cursor != null && !cursor.isClosed())
	        {
	            cursor.close();
	        }
	        dbObject.close();
	    }

		 
			return top3HybridsInfo;
		}
		 
    /**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
   	 
			
    @Override
  	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
    {
  	 
    	 try
         {            
         	Top3HybridsDTO dto = (Top3HybridsDTO) dtoObject;

             ContentValues cValues = new ContentValues();
            
             /*TOP3_HYBRIDS
             id
             seasonId
             activityId
             cropId
             hybridId
             
             */
             
             cValues.put("id", dto.getId());
             cValues.put("seasonId",dto.getSeasonId());
             cValues.put("activityId",dto.getActivityId());
             cValues.put("cropId",dto.getCropId());
             cValues.put("hybridId",dto.getHybridId());
             cValues.put("hybridName",dto.getHybridName());
             
             

             dbObject.insert("TOP3_HYBRIDS", null, cValues);
             return true;
         } catch (SQLException e)
         {
             ATBuildLog.e(TAG + "insert()", e.getMessage());
             return false;
         } finally
         {
             dbObject.close();
         }
    }
    	
    	 /**
 	     * Updates the data in the SQLite
 	     * 
 	     * @param dtoObject
 	     *            : DTO object is passed
 	     * @param dbObject
 	     *            : Exposes methods to manage a SQLite database Object
 	     * @return boolean : True if data is updated
 	     */
 	   
    @Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	{
    	 try
	        {
	            
	        Top3HybridsDTO dto = (Top3HybridsDTO ) dtoObject;

	            ContentValues cValues = new ContentValues();
	            
	             cValues.put("seasonId",dto.getSeasonId());
	             cValues.put("activityId",dto.getActivityId());
	             cValues.put("cropId",dto.getCropId());
	             cValues.put("hybridId",dto.getHybridId());
	             cValues.put("hybridName",dto.getHybridName());
	             

	            dbObject.update("TOP3_HYBRIDS", cValues, "id='" +dto.getId()+"' ", null);
	            return true;
	        } catch (SQLException e)
	        {
                ATBuildLog.e(TAG + "update()", e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        } finally
	        {
	            dbObject.close();
	        }
	        return false;
	    }
 
    /**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM  TOP3_HYBRIDS").execute();
            return true;
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }
}
