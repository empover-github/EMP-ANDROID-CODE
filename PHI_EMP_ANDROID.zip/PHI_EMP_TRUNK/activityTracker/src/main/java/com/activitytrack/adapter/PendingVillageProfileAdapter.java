package com.activitytrack.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.dtos.VillageProfileDTO;
import com.activitytrack.listeners.OnListItemClickListener;
import com.activitytrack.utility.MyConstants;

import java.util.List;

/**
 * Created by fatima.t on 20/12/2017.
 */

public class PendingVillageProfileAdapter extends RecyclerView.Adapter<PendingVillageProfileAdapter.VillageProfilesHolder> {
    Context context;
    List<VillageProfileDTO> profilesList;
    private OnListItemClickListener listener;

    public PendingVillageProfileAdapter(Context context, List<VillageProfileDTO> profilesList, OnListItemClickListener listener) {
        this.context = context;
        this.profilesList = profilesList;
        this.listener = listener;
    }

    @Override
    public VillageProfilesHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.vp_pending_list_item,parent,false);
        return new VillageProfilesHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(VillageProfilesHolder holder, int position) {
        holder.bind(profilesList.get(position));
    }

    @Override
    public int getItemCount() {
        return profilesList.size();
    }


    public class VillageProfilesHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvVillageName, tvCropName;
        LinearLayout mainLayout;
        Button deleteBtn, editBtn;
        TextView surveyCount;
        public VillageProfilesHolder(View view) {
            super(view);

            mainLayout = (LinearLayout) view.findViewById(R.id.pvp_list_mainLayout);
            tvVillageName = (TextView) view.findViewById(R.id.pvp_list_villageName);
            tvCropName = (TextView) view.findViewById(R.id.pvp_list_crop);
            // newly added
            deleteBtn = (Button) view.findViewById(R.id.pvp_list_deleteBtn);
            editBtn = (Button) view.findViewById(R.id.pvp_list_editBtn);
            surveyCount = (TextView) view.findViewById(R.id.survey_count);

//            mainLayout.setOnClickListener(this);
            deleteBtn.setOnClickListener(this);
            editBtn.setOnClickListener(this);
        }

        public void bind(final VillageProfileDTO profileModel ) {
            StringBuilder villageNameBuilder = new StringBuilder();
            villageNameBuilder.append("Village : ");
            villageNameBuilder.append("<b>");
            villageNameBuilder.append(profileModel.getVillageName());
            villageNameBuilder.append("</b>");

            if(MyConstants.YES.equalsIgnoreCase(profileModel.getIsPDAVillage()))
                villageNameBuilder.append(" (PDA)");
            villageNameBuilder.append(", ");
            villageNameBuilder.append(profileModel.getBlockName());
            villageNameBuilder.append(" - ");
            villageNameBuilder.append(profileModel.getPinCode());
            tvVillageName.setText(Html.fromHtml(villageNameBuilder.toString()));

            String cropData = "Crop : "+profileModel.getCropName()+" ("+profileModel.getSegmentName()+")";
            tvCropName.setText(cropData);

//            mainLayout.setTag(profileModel);
            deleteBtn.setTag(profileModel);
            editBtn.setTag(profileModel);

            int surveyCnt = profileModel.getSurveysNew() != null ? profileModel.getSurveysNew().size() : 0;
            surveyCount.setText(String.valueOf(surveyCnt));
        }

        @Override
        public void onClick(View v) {
            listener.onItemClick(v, getAdapterPosition());
        }
    }
}
