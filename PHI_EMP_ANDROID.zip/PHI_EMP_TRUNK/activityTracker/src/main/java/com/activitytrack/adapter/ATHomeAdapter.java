package com.activitytrack.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.activitytrack.activity.ATHomeFragment;
import com.activitytrack.activity.R;
import com.activitytrack.listeners.OnListItemClickListener;
import com.activitytrack.models.IconItems;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ATHomeAdapter extends RecyclerView.Adapter<ATHomeAdapter.MyHolder> {
    private Context context;
    private ArrayList<IconItems> imageArray;
    private OnListItemClickListener listener;

    public ATHomeAdapter(Context context, ArrayList<IconItems> imageArray, ATHomeFragment listener) {
        this.context = context;
        this.imageArray = imageArray;
        this.listener = listener;

    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.at_home_grid_layout, null);
        MyHolder myHolder = new MyHolder(layout);
        return myHolder;

    }

    @Override
    public void onBindViewHolder(ATHomeAdapter.MyHolder holder, int position) {
        Glide.with(context)
                .load(imageArray.get(position).getIcon())
                .error(R.drawable.image_placeholder)
                .placeholder(R.drawable.image_placeholder)
                .dontAnimate().into(holder.imageView);


        holder.bind(imageArray.get(position));
    }

    @Override
    public int getItemCount() {
        return imageArray.size();
    }

    class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        TextView textView;
        RelativeLayout rlyImageLayout;
        LinearLayout vmItemOverly;

        MyHolder(View itemView) {
            super(itemView);
            imageView = (ImageView) itemView.findViewById(R.id.grid_image);

            rlyImageLayout = (RelativeLayout) itemView.findViewById(R.id.at_layoutimage);


        }

        void bind(final IconItems iconItems) {

            rlyImageLayout.setTag(iconItems);
            rlyImageLayout.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            // int position = (int) v.getTag();
            listener.onItemClick(v, getAdapterPosition());
        }
    }
}
