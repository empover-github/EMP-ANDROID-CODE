package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.UploadedVillageListDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class UploadedVillageListDAO implements DAO {

    private final String TAG = "uploadedVillageProfile";
    private static UploadedVillageListDAO villageProfileDAO;

    public static UploadedVillageListDAO getInstance() {
        if (villageProfileDAO == null) {
            villageProfileDAO = new UploadedVillageListDAO();
        }
        return villageProfileDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM UPLOADED_VILLAGE_LIST where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    UploadedVillageListDTO dto = new UploadedVillageListDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setSeason(cursor.getString(2));
                    dto.setCrop(cursor.getString(3));
                    dto.setUploadedDate(cursor.getString(4));

                    pdaActivityInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }


    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM UPLOADED_VILLAGE_LIST ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    UploadedVillageListDTO dto = new UploadedVillageListDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setSeason(cursor.getString(2));
                    dto.setCrop(cursor.getString(3));
                    dto.setUploadedDate(cursor.getString(4));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override

    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;

    }


    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {


        try {
            UploadedVillageListDTO dto = (UploadedVillageListDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            cValues.put("id", dto.getId());
            cValues.put("villageName", dto.getVillageName());
            cValues.put("season", dto.getSeason());
            cValues.put("crop", dto.getCrop());
            cValues.put("uploadedDate", dto.getUploadedDate());

            long insertedRow = dbObject.insert("UPLOADED_VILLAGE_LIST", null, cValues);
            if (insertedRow > 0) {
                Cursor cursor = dbObject.rawQuery("SELECT MAX(id) FROM  UPLOADED_VILLAGE_LIST", null);
                if (cursor.getCount() > 0) {

                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            UploadedVillageListDTO dto = (UploadedVillageListDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getId() != 0)
                cValues.put("id", dto.getId());

            if (dto.getVillageName() != null)
                cValues.put("villageName", dto.getVillageName());

            if (dto.getVillageName() != null)
                cValues.put("season", dto.getSeason());

            if (dto.getVillageName() != null)
                cValues.put("crop", dto.getCrop());

            if (dto.getUploadedDate() != null)
                cValues.put("uploadedDate", dto.getUploadedDate());

            dbObject.update("UPLOADED_VILLAGE_LIST", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }



    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM UPLOADED_VILLAGE_LIST").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from UPLOADED_VILLAGE_LIST where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean deleteDataByDate(String date, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from UPLOADED_VILLAGE_LIST where uploadedDate < '" + date + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }



    public boolean deleteTableDataById(long id,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM UPLOADED_VILLAGE_LIST where id = '"+id+"'").execute();
            return true;
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public List<UploadedVillageListDTO> getRecordsUploaded(SQLiteDatabase dbObject) {
        List<UploadedVillageListDTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM UPLOADED_VILLAGE_LIST ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    UploadedVillageListDTO dto = new UploadedVillageListDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setSeason(cursor.getString(2));
                    dto.setCrop(cursor.getString(3));
                    dto.setUploadedDate(cursor.getString(4));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }
}
