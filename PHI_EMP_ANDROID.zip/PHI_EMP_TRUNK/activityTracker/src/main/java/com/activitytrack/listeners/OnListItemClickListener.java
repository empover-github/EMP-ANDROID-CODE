package com.activitytrack.listeners;

import android.view.View;


/**
 * Created by fatima.t on 04-04-2018.
 */
public interface OnListItemClickListener {
    void onItemLongClick(View view, int position);
    void onItemClick(View view, int position);
}
