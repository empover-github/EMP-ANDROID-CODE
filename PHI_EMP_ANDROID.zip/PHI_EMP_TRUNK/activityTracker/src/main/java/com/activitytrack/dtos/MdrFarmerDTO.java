package com.activitytrack.dtos;

public class MdrFarmerDTO  implements DTO
{
	    private long mobileid;
	    private String farmerName;
	    private long mobileNumber; 
	    private Float  acres;
	    private String majorCrop1;
	    private Float   majorCrop1Area;
	    private String majorCrop2;
	    private Float majorCrop2Area;
	    private long activityId;
		
	    public long getId() {
			return mobileid;
		}
		public void setId(long mobileid) {
			this.mobileid = mobileid;
		}
		public String getFarmerName() {
			return farmerName;
		}
		public void setFarmerName(String farmerName) {
			this.farmerName = farmerName;
		}
		public long getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(long mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public Float getAcres() {
			return acres;
		}
		public void setAcres(Float acres) {
			this.acres = acres;
		}
		public String getMajorCrop() {
			return majorCrop1;
		}
		public void setMajorCrop(String majorCrop) {
			this.majorCrop1 = majorCrop;
		}
		public Float getMajorCropAcres() {
			return majorCrop1Area;
		}
		public void setMajorCropAcres(Float majorCropAcres) {
			this.majorCrop1Area = majorCropAcres;
		}
		public String getSecondCrop() {
			return majorCrop2;
		}
		public void setSecondCrop(String secondCrop) {
			this.majorCrop2 = secondCrop;
		}
		public Float getSecondCropAcres() {
			return majorCrop2Area;
		}
		public void setSecondCropAcres(Float secondCropAcres) {
			this.majorCrop2Area = secondCropAcres;
		}
		public long getActivityId() {
			return activityId;
		}
		public void setActivityId(long activityId) {
			this.activityId = activityId;
		}
}
