package com.activitytrack.dtos;

import java.util.List;

/**
 * Created by rambabu.a on 26-02-2018.
 */

public class PravaktaHaGainDTO implements DTO {

    private String pravaktaName;
    private String mobileNo;
    private String villageName;
    private String pincode;
    private String imageUrlPath;
    private String blockName;
    private String districtName;
    private String previousYear;
    private String currentYear;
    private String totalPreviousAcres;
    private String totalPresentAcres;
    private String phiPreviousAcres;
    private String phiPresentAcres;
    private String targetPreviousAcres;
    private String targetPresentAcres;
    private boolean rice;
    private boolean corn;
    private boolean millet;
    private boolean mustard;
    private String targetHybrid;
    private String blockType;
    private String geoLocation;
    private int isSync;
    private long mobileId;
    private List<PravaktaFarmerDTO> pravaktaFarmers;


    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }



    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getPreviousYear() {
        return previousYear;
    }

    public void setPreviousYear(String previousYear) {
        this.previousYear = previousYear;
    }

    public String getCurrentYear() {
        return currentYear;
    }

    public void setCurrentYear(String currentYear) {
        this.currentYear = currentYear;
    }

    public String getTotalPreviousAcres() {
        return totalPreviousAcres;
    }

    public void setTotalPreviousAcres(String totalPreviousAcres) {
        this.totalPreviousAcres = totalPreviousAcres;
    }

    public String getTotalPresentAcres() {
        return totalPresentAcres;
    }

    public void setTotalPresentAcres(String totalPresentAcres) {
        this.totalPresentAcres = totalPresentAcres;
    }

    public String getPhiPreviousAcres() {
        return phiPreviousAcres;
    }

    public void setPhiPreviousAcres(String phiPreviousAcres) {
        this.phiPreviousAcres = phiPreviousAcres;
    }

    public String getPhiPresentAcres() {
        return phiPresentAcres;
    }

    public void setPhiPresentAcres(String phiPresentAcres) {
        this.phiPresentAcres = phiPresentAcres;
    }

    public String getTargetPreviousAcres() {
        return targetPreviousAcres;
    }

    public void setTargetPreviousAcres(String targetPreviousAcres) {
        this.targetPreviousAcres = targetPreviousAcres;
    }

    public String getTargetPresentAcres() {
        return targetPresentAcres;
    }

    public void setTargetPresentAcres(String targetPresentAcres) {
        this.targetPresentAcres = targetPresentAcres;
    }

    public String getTargetHybrid() {
        return targetHybrid;
    }

    public void setTargetHybrid(String targetHybrid) {
        this.targetHybrid = targetHybrid;
    }

    public String getBlockType() {
        return blockType;
    }

    public void setBlockType(String blockType) {
        this.blockType = blockType;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public long getId() {
        return mobileId;
    }

    public void setId(long mobileId) {
        this.mobileId = mobileId;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public String getPravaktaName() {
        return pravaktaName;
    }

    public void setPravaktaName(String pravaktaName) {
        this.pravaktaName = pravaktaName;
    }

    public String getImageUrlPath() {
        return imageUrlPath;
    }

    public void setImageUrlPath(String imageUrlPath) {
        this.imageUrlPath = imageUrlPath;
    }

    public boolean isRice() {
        return rice;
    }

    public void setRice(boolean rice) {
        this.rice = rice;
    }

    public boolean isCorn() {
        return corn;
    }

    public void setCorn(boolean corn) {
        this.corn = corn;
    }

    public boolean isMillet() {
        return millet;
    }

    public void setMillet(boolean millet) {
        this.millet = millet;
    }

    public boolean isMustard() {
        return mustard;
    }

    public void setMustard(boolean mustard) {
        this.mustard = mustard;
    }

    public void setPravaktaFarmers(List<PravaktaFarmerDTO> pravaktaFarmers) {
        this.pravaktaFarmers = pravaktaFarmers;
    }

    public List<PravaktaFarmerDTO> getPravaktaFarmers() {
        return pravaktaFarmers;
    }
}
