package com.activitytrack.asyncttasks;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;

import com.activitytrack.activity.OTPActivity;
import com.activitytrack.activity.R;
import com.activitytrack.masterdtos.DownloadMasterDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;

public class LoginAsync extends AsyncTask<String, Void, String> {
	String jsonData;
	Context context;
	ProgressDialog dlg;

	public LoginAsync(String inputJSON, Context context) {
		jsonData = inputJSON;
		this.context = context;
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		dlg = new ProgressDialog(context);
		dlg.setCanceledOnTouchOutside(false);
		dlg.setCancelable(false);
		dlg.setMessage(context.getResources().getString(R.string.progress_pleaseWait));
		dlg.show();
	}

	@Override
	protected String doInBackground(String... params) {
		HttpClient httpClient = null;
		try {
			HttpParams httpParams = new BasicHttpParams();
			int connectionTimeout = MyConstants.CONNECTION_TIME_LIMIT;
			int socketTimeout = MyConstants.CONNECTION_TIME_LIMIT;
			HttpConnectionParams.setConnectionTimeout(httpParams, connectionTimeout);
			HttpConnectionParams.setSoTimeout(httpParams, socketTimeout);
			httpClient = new DefaultHttpClient(httpParams);
			HttpPost httpPost = new HttpPost(params[0]);
			ATBuildLog.i("LoginAsync", "login request data :" + jsonData);
			StringEntity stringEntity = new StringEntity(jsonData);
			httpPost.setEntity(stringEntity);
			/*MultipartEntity entity = new MultipartEntity();
			 entity.addPart("jsonData", new StringBody(jsonData)); 				 
			 httpPost.setEntity(entity);*/
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity httpEntity = response.getEntity();
			InputStream instream = httpEntity.getContent();
			String responseStr = Utility.convertStreamToString(instream);
			return responseStr;
		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			if (httpClient != null)
				httpClient.getConnectionManager().shutdown();
		}

		return null;
	}

	@Override
	protected void onPostExecute(String result) {
		if (dlg != null) {
			dlg.dismiss();
		}
		
		if (result != null && !result.isEmpty()) {
		if(!Utility.isJSONValid(result)){
			Utility.showAlert(context, "", "It is not a valid Json");
		}else{
		try {
			
			JSONObject loginRes = new JSONObject(result);
			
			
			System.out.println("master Data : "+result);
			 
			Gson gson = new Gson();
			DownloadMasterDTO obj = gson.fromJson(result, DownloadMasterDTO.class);
			
			if(loginRes.getInt("code") == 100){
				
				String mobileNo = loginRes.getString("mobileNo");
				JSONObject object = new JSONObject(jsonData);
				Intent intent=new Intent(context, OTPActivity.class);
				intent.putExtra("mobileNo", mobileNo);
				intent.putExtra("loginId", object.getString("loginId"));
				intent.putExtra("password", object.getString("password"));
				context.startActivity(intent);
				
			}else if (loginRes.getInt("code") == 101) {
				Utility.showAlert(context, "", MyConstants.RES101MSG);
			} else if (loginRes.getInt("code") == 102) {
				Utility.showAlert(context, "", MyConstants.RES102MSG);
			} else if (loginRes.getInt("code") == 103) {
				Utility.showAlert(context, "", MyConstants.RES103MSG);
			} else if (loginRes.getInt("code") == 104) {
				Utility.showAlert(context, "", MyConstants.RES104MSG);
			}else if(loginRes.getInt("code") == 302){
				 
				AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
	            builder1.setMessage(context.getResources().getString(R.string.alreadyregister));
	            builder1.setCancelable(false);
	            builder1.setPositiveButton("Yes",
	                    new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int id) {
	                	  
	                	JSONObject jsonObject = new JSONObject();
	    				try {
	    					JSONObject inputJson = new JSONObject(jsonData);
	    					jsonObject.put("loginId", inputJson.getString("loginId"));
	    					jsonObject.put("password",inputJson.getString("password"));	
	    					jsonObject.put("confirm",1);
	    					String deviceID = Utility.getDeviceId(context);
	    					if (deviceID == null) {
	    						TelephonyManager telephonyManager = (TelephonyManager) context
	    								.getSystemService(Context.TELEPHONY_SERVICE);
	    					      deviceID = telephonyManager.getDeviceId();
	    					      Utility.setDeviceId(deviceID, context);
	    					}
	    					jsonObject.put("deviceId", deviceID);
	    			
	    					LoginAsync async = new LoginAsync(jsonObject.toString(), context);
	    					async.execute(MyConstants.AppURL+MyConstants.SENDOTP_URL);
	    					
	    				} catch (JSONException e) {
	    					e.printStackTrace();
	    				}
					
	                }
 
	            });
	            builder1.setNegativeButton("No",
	                    new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int id) {
	                    dialog.cancel();
	                }
	            });

	            AlertDialog alert11 = builder1.create();
	            alert11.show();
			 
				 
				
				//Utility.showAlert(context, "","This is user is already register other device if u continue  to login u loss the data in the previous data ,r u sure to continue yes r no");
				
				 
				
				

			}
 
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	}else{
		Utility.showAlert(context, "", "Network Problem please Contact Admin");
	}
 }

	protected void startActivity(Intent intent) {
		 
		
	}

	protected void finish() {
	 
		
	}
	
}
