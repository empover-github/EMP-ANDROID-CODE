package com.activitytrack.interfaces;

public interface BackButtonPressesCallback {
	public void onBackPressedCallBack(int callbcak);
}
