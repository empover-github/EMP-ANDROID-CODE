package com.activitytrack.dtos;

public class DemandSummaryDTO implements DTO 
{
	private long id;
	private long activityId;
	private  int farmerCount;
	private int retailerCount;
    //new
    private long cropId;
    private long hybridId;
    private long seasonId;
    private int isSync;
    //new
    private long seasonCalendarId;
    private int sampleCount;
    
    
    
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getActivityId() {
		return activityId;
	}
	public void setActivityId(long activityId) {
		this.activityId = activityId;
	}
	
	public int getFarmerCount() {
		return farmerCount;
	}
	public void setFarmerCount(int farmerCount) {
		this.farmerCount = farmerCount;
	}
	public int getRetailerCount() {
		return retailerCount;
	}
	public void setRetailerCount(int retailers) {
		this.retailerCount = retailers;
	}
	 
	public long getCropId() {
		return cropId;
	}
	public void setCropId(long cropId) {
		this.cropId = cropId;
	}
	public long getHybridId() {
		return hybridId;
	}
	public void setHybridId(long hybridId) {
		this.hybridId = hybridId;
	}
	public long getSeasonId() {
		return seasonId;
	}
	public void setSeasonId(long seasonId) {
		this.seasonId = seasonId;
	}
	public int getIsSync() {
		return isSync;
	}
	public void setIsSync(int isSync) {
		this.isSync = isSync;
	}
	public long getSeasonCalendarId() {
		return seasonCalendarId;
	}
	public void setSeasonCalendarId(long seasonCalendarId) {
		this.seasonCalendarId = seasonCalendarId;
	}
	public int getSampleCount() {
		return sampleCount;
	}
	public void setSampleCount(int sampleCount) {
		this.sampleCount = sampleCount;
	}
	 
	}
		
 
 