package com.activitytrack.utility;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.activitytrack.activity.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;



public class ProfileImageSelectionUtil {
    public static final int CAMERA = 100;
    public static final int GALLERY = 200;
    public static final int OPENCAMERA = 300;
    public static final int CAMERA_VIDEO = 300;
    public static final int VIDEO_GALLERY = 400;
    public static final int PHOTO_DELETE = 1000;
    public static final int VIDEO_DELETE = 2000;
    public static final int FIRSTIMAGE = 1;
    public static final int SECONDIMAGE = 2;
    public static final int CAMERAIMAGE = 3;
    public static String IMAGEPATH = "IMAGEPATH";
    public static String CURERENTPOS = "CURERENTPOS";
    static Dialog alertOptionDialog;
    public static boolean isUriTrue;

    /**
     * @return Check the Image capture functionality has the bug in device
     */



        /**
         * @return Check the Image capture functionality has the bug in device
         */
        public static boolean hasImageCaptureBug() {

            // list of known devices that have the bug
            ArrayList<String> devices = new ArrayList<String>();
            devices.add("android-devphone1/dream_devphone/dream");
            devices.add("generic/sdk/generic");
            devices.add("vodafone/vfpioneer/sapphire");
            devices.add("tmobile/kila/dream");
            devices.add("verizon/voles/sholes");
            devices.add("google_ion/google_ion/sapphire");

            boolean bool = devices.contains(android.os.Build.BRAND + "/"
                    + android.os.Build.PRODUCT + "/" + android.os.Build.DEVICE);

            return bool;

        }

  /*  public static void openCamera(Activity context, int requestCode) {
        Intent cameraIntent = null;
        if (requestCode == 100) {
            cameraIntent = new Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE);

            if (ProfileImageSelectionUtil.hasImageCaptureBug()) {
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(new File(Environment
                                .getExternalStorageDirectory().getPath())));
            } else {
                File dir = Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
                File output = new File(dir, "camerascript.png");
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(output));
            }
        } else {
            cameraIntent = new Intent(
                    MediaStore.ACTION_VIDEO_CAPTURE);
            if (ProfileImageSelectionUtil.hasImageCaptureBug()) {
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(new File(Environment
                                .getExternalStorageDirectory().getPath())));
            } else {
                File dir = Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
                File output = new File(dir, "cameravideo.mp4");
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(output));
            }
        }

        context.startActivityForResult(cameraIntent, requestCode);

    }*/

    private static String imagePathGlobal;
    private static Dialog mDialog;

    // private static String imagePathGlobal;

    public static Bitmap getImage(Intent data, Activity context) {

        try {
            Bitmap image = null;
            String imagePath = null;
            Uri uri = null;

            if (hasImageCaptureBug()) {
                File fi = new File(Environment.getExternalStorageDirectory()
                        .getPath());
                try {
                    uri = Uri.parse(MediaStore.Images.Media
                            .insertImage(context.getContentResolver(),
                                    fi.getAbsolutePath(), null, null));
                    if (!fi.delete()) {
                        Log.i("logMarker", "Failed to delete " + fi);
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                if (data == null) {

                    isUriTrue = false;
                    File fi = new File(
                            Environment
                                    .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                            "camerascript.png");

                    imagePath = fi.getAbsolutePath();

                    imagePathGlobal = imagePath;

                    System.out.println("ImagepAth" + imagePath);

                } else {

                    isUriTrue = true;
                    uri = data.getData();
                }

            }

            if (uri != null || imagePath != null) {

                try {

                    if (uri != null) {
                        imagePath = getRealPathFromURI(uri, context);

                        image = getBitmap(imagePath);
                    } else if (imagePath != null) {
                        image = getBitmap(imagePath);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else {
                BitmapFactory.Options options;

                try {
                    String imageInSD = "/storage/emulated/0/DCIM/camerascript.png";
                    Bitmap bitmap = BitmapFactory.decodeFile(imageInSD);
                    ProfileImageSelectionUtil.isUriTrue = false;
//					ScanActivity.capture_bug = true;
                    return bitmap;
                } catch (OutOfMemoryError e) {
                    try {
                        options = new BitmapFactory.Options();
                        options.inSampleSize = 2;
                        Bitmap bitmap = BitmapFactory.decodeFile(
                                "/storage/emulated/0/DCIM/camerascript.png",
                                options);
                        ProfileImageSelectionUtil.isUriTrue = false;
//						ScanActivity.capture_bug = true;
                        return bitmap;
                    } catch (Exception e1) {

                    }
                }
            }

            return image;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    /**
     * @param contentUri
     * @param context
     * @return Get original path from the given URI
     */
    public static String getRealPathFromURI(Uri contentUri, Activity context) {
        String res = null;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver().query(contentUri, proj,
                null, null, null);
        if (cursor.moveToFirst()) {

            int column_index = cursor
                    .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }

    /*public static void selectImageFromGallery(Context context, int requestCode) {

        Intent intent = new Intent();

        intent.setType("image*//*");
        intent.setAction(Intent.ACTION_PICK);

          startActivityForResult(intent, requestCode);

    }*/

    public static void selectVideoFromGallery(Activity context, int requestCode) {

        Intent intent = new Intent();

        intent.setType("video/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);

        context.startActivityForResult(intent, requestCode);

    }

    public static void showEditOption(final Context context) {

        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // mDialog.getWindow().setFlags(
        // WindowManager.LayoutParams.FLAG_FULLSCREEN,
        // WindowManager.LayoutParams.FLAG_FULLSCREEN);
        mDialog.setContentView(R.layout.paravakta_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mFromGallery;
        Button  mCancel;
        TextView mTitile = (TextView) mDialog.findViewById(R.id.alertTitle);
        TextView mRemovePhoto = (TextView) mDialog.findViewById(R.id.remove_photo);
        mRemovePhoto.setVisibility(View.VISIBLE);
        View view = mDialog.findViewById(R.id.remover_photo_line);
        view.setVisibility(View.VISIBLE);
        mFromCamera = (TextView) mDialog.findViewById(R.id.from_camera);
        mFromGallery = (TextView) mDialog.findViewById(R.id.from_galery);

        mCancel = (Button) mDialog.findViewById(R.id.cancel);

       /* mRemovePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                context.resetImage();
            }
        });*/

        mFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
               // openCamera((Activity) context, ProfileImageSelectionUtil.CAMERA);
            }
        });
        mFromGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
              /* selectImageFromGallery((Activity) context,
                        ProfileImageSelectionUtil.GALLERY);*/
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }

    public static void showOption(final Context context) {

        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // mDialog.getWindow().setFlags(
        // WindowManager.LayoutParams.FLAG_FULLSCREEN,
        // WindowManager.LayoutParams.FLAG_FULLSCREEN);
        mDialog.setContentView(R.layout.paravakta_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mFromGallery;
        Button  mCancel;
        TextView mTitile = (TextView) mDialog.findViewById(R.id.alertTitle);
        mFromCamera = (TextView) mDialog.findViewById(R.id.from_camera);
        mFromGallery = (TextView) mDialog.findViewById(R.id.from_galery);
        mCancel = (Button) mDialog.findViewById(R.id.cancel);

        mFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                //openCamera(context, ProfileImageSelectionUtil.CAMERA);
            }
        });
        mFromGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                /*selectImageFromGallery(context,
                        ProfileImageSelectionUtil.GALLERY);*/
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }

    public static Bitmap getBitmap(String path) {
        try {
            // decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new FileInputStream(path), null, o);
            // Find the correct scale value. It should be the power of 2.
            final int REQUIRED_SIZE = 70;
            int width_tmp = o.outWidth, height_tmp = o.outHeight;
            int scale = 1;
            while (true) {
                if (width_tmp / 2 < REQUIRED_SIZE
                        || height_tmp / 2 < REQUIRED_SIZE)
                    break;
                width_tmp /= 2;
                height_tmp /= 2;
                scale++;
            }

            // decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;

            Bitmap bitmap = BitmapFactory.decodeStream(
                    new FileInputStream(path), null, o2);
            return bitmap;
        } catch (FileNotFoundException e) {
            return null;
        } catch (Exception e) {
            return null;
        }

    }

    public static Bitmap getCorrectOrientationImage(Context context,
                                                    Uri selectedImage, Bitmap image) {

        String[] filePathColumn = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver().query(selectedImage,
                filePathColumn, null, null, null);
        cursor.moveToFirst();

        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String filePath = cursor.getString(columnIndex);
        cursor.close();
        int rotate = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(filePath);
            int orientation = exifInterface.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, 1);

            Matrix matrix = new Matrix();

            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) {
                rotate = 90;
            } else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) {
                rotate = 180;
            } else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) {
                rotate = 270;
            }
            if (rotate != 0) {
                int w = image.getWidth();
                int h = image.getHeight();

                matrix.preRotate(rotate);
                // Rotate the bitmap
                image = Bitmap.createBitmap(image, 0, 0, w, h, matrix, true);
                image = image.copy(Bitmap.Config.ARGB_8888, true);
            }
        } catch (Exception exception) {
            Log.d("check", "Could not rotate the image");
        }
        return image;
    }

    public static void saveBitmap(String filePath, Bitmap bitmap) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            //
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes);

            File file = new File(filePath);

            if (file.exists()) {
                file.delete();
                file.createNewFile();
            }
            // if (!file.exists()) {
            // file.createNewFile();
            // }
            // write the bytes in file
            FileOutputStream fo = new FileOutputStream(file);

            fo.write(bytes.toByteArray());

            // remember close de FileOutput
            fo.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//	public static Bitmap getsampleorientationImage(Context context,
//			Bitmap image) {
//		try {
//			String imageInSD = "/storage/emulated/0/DCIM/camerascript.png";
////			File file = new File(imageInSD);
//			BitmapFactory.Options bounds = new BitmapFactory.Options();
//			bounds.inJustDecodeBounds = true;
//			BitmapFactory.decodeFile(imageInSD, bounds);
//
//			BitmapFactory.Options opts = new BitmapFactory.Options();
//			Bitmap bm = BitmapFactory.decodeFile(imageInSD, opts);
//			ExifInterface exif = new ExifInterface(imageInSD);
//			String orientString = exif.getAttribute(ExifInterface.TAG_ORIENTATION);
//			int orientation = orientString != null ? Integer.parseInt(orientString) :  ExifInterface.ORIENTATION_NORMAL;
//
//			int rotationAngle = 0;
//			if (orientation == ExifInterface.ORIENTATION_ROTATE_90) rotationAngle = 90;
//			if (orientation == ExifInterface.ORIENTATION_ROTATE_180) rotationAngle = 180;
//			if (orientation == ExifInterface.ORIENTATION_ROTATE_270) rotationAngle = 270;
//
//			Matrix matrix = new Matrix();
//			matrix.setRotate(rotationAngle, (float) bm.getWidth() / 2, (float) bm.getHeight() / 2);
//			Bitmap rotatedBitmap = Bitmap.createBitmap(bm, 0, 0, bounds.outWidth, bounds.outHeight, matrix, true);
//			return rotatedBitmap;
//		} catch (Exception e) {

//		}
//		return null;
//	}

    public static Bitmap getCorrectOrientationImage(Context context,
                                                    Bitmap image) {

        int rotate = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(imagePathGlobal);
            int orientation = exifInterface.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, 1);

            Matrix matrix = new Matrix();

            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) {
                rotate = 90;
            } else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) {
                rotate = 180;
            } else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) {
                rotate = 270;
            }
            if (rotate != 0) {
                int w = image.getWidth();
                int h = image.getHeight();

                matrix.preRotate(rotate);
                // Rotate the bitmap
                image = Bitmap.createBitmap(image, 0, 0, w, h, matrix, true);
                image = image.copy(Bitmap.Config.ARGB_8888, true);
            }
        } catch (Exception exception) {
            Log.d("check", "Could not rotate the image");
        }

        return image;
    }
}
