package com.activitytrack.transdtos;

import com.activitytrack.dtos.AgronomyActivityDTO;
import com.activitytrack.dtos.DipstickDTO;
import com.activitytrack.dtos.FarmerSchoolSilageDTO;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.dtos.LiquidationTrackingDTO;
import com.activitytrack.dtos.MdrProfileDTO;
import com.activitytrack.dtos.PravaktaHaGainDTO;
import com.activitytrack.dtos.SegmentationRequestDTO;
import com.activitytrack.dtos.ThreeIDTO;
import com.activitytrack.dtos.VillageProfileDTO;

import java.util.List;

public class TransMainDTO {

	private long mdrId;
	private String password;
	private List<AgronomyActivityDTO> agronomies;
	private List<LiquidationTrackingDTO> liquidations;
	private List<MdrProfileDTO> mdrProfiles;
	private List<VillageProfileDTO> villageProfiles;
	private List<ActivitiesTransDTO> pdaActivities;
	private List<ActivitiesTransDTO> osaActivities;
	private List<ActivitiesTransDTO> psaActivities;

	private List<ThreeIDTO> threeI;
	private String versionNo;
	private String deviceId;
	private List<DipstickDTO> dipsticks;
	// new added
	private List<PravaktaHaGainDTO> pravaktaVillageHaGains;

	private List<SegmentationRequestDTO> farmerSegmentationTransactionDataList;

	//newly added
	private String mobileNumber;

	private List<GerminationverificationListDTO> germinationVerifiedList;
	private List<FarmerSchoolSilageDTO> farmerSegmentationDairyDevList;

	
	public List<DipstickDTO> getDipsticks() {
		return dipsticks;
	}
	public void setDipsticks(List<DipstickDTO> dipsticks) {
		this.dipsticks = dipsticks;
	}
	public long getMdrId() {
		return mdrId;
	}
	public void setMdrId(long mdrId) {
		this.mdrId = mdrId;
	}
	public List<AgronomyActivityDTO> getAgronomies() {
		return agronomies;
	}
	public void setAgronomies(List<AgronomyActivityDTO> agronomies) {
		this.agronomies = agronomies;
	}
	public List<LiquidationTrackingDTO> getLiquidations() {
		return liquidations;
	}
	public void setLiquidations(List<LiquidationTrackingDTO> liquidations) {
		this.liquidations = liquidations;
	}
	public List<MdrProfileDTO> getMdrProfile() {
		return mdrProfiles;
	}
	public void setMdrProfile(List<MdrProfileDTO> mdrProfile) {
		this.mdrProfiles = mdrProfile;
	}
	public List<ActivitiesTransDTO> getPdaActivities() {
		return pdaActivities;
	}
	public void setPdaActivities(List<ActivitiesTransDTO> pdaActivities) {
		this.pdaActivities = pdaActivities;
	}
	public List<ActivitiesTransDTO> getOsaActivities() {
		return osaActivities;
	}
	public void setOsaActivities(List<ActivitiesTransDTO> osaActivities) {
		this.osaActivities = osaActivities;
	}
	public List<ActivitiesTransDTO> getPsaActivities() {
		return psaActivities;
	}
	public void setPsaActivities(List<ActivitiesTransDTO> psaActivities) {
		this.psaActivities = psaActivities;
	}
	public List<ThreeIDTO> getThreeI() {
		return threeI;
	}
	public void setThreeI(List<ThreeIDTO> threeI) {
		this.threeI = threeI;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public List<PravaktaHaGainDTO> getPravaktaVillageHaGains() {
		return pravaktaVillageHaGains;
	}

	public void setPravaktaVillageHaGains(List<PravaktaHaGainDTO> pravaktaVillageHaGains) {
		this.pravaktaVillageHaGains = pravaktaVillageHaGains;
	}

	public List<VillageProfileDTO> getVillageProfiles() {
		return villageProfiles;
	}

	public void setVillageProfiles(List<VillageProfileDTO> villageProfiles) {
		this.villageProfiles = villageProfiles;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public List<GerminationverificationListDTO> getGerminationVerifiedList() {
		return germinationVerifiedList;
	}

	public void setGerminationVerifiedList(List<GerminationverificationListDTO> germinationVerifiedList) {
		this.germinationVerifiedList = germinationVerifiedList;
	}

	public List<SegmentationRequestDTO> getFarmerSegmentationTransactionDataList() {
		return farmerSegmentationTransactionDataList;
	}

	public void setFarmerSegmentationTransactionDataList(List<SegmentationRequestDTO> farmerSegmentationTransactionDataList) {
		this.farmerSegmentationTransactionDataList = farmerSegmentationTransactionDataList;
	}

	public List<FarmerSchoolSilageDTO> getFarmerSegmentationDairyDevList() {
		return farmerSegmentationDairyDevList;
	}

	public void setFarmerSegmentationDairyDevList(List<FarmerSchoolSilageDTO> farmerSegmentationDairyDevList) {
		this.farmerSegmentationDairyDevList = farmerSegmentationDairyDevList;
	}
}
