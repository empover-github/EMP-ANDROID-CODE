package com.activitytrack.daos;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.YieldCalculatorCropsDTO;
import com.activitytrack.utility.ATBuildLog;

public class YieldCalculatorCropsDAO  implements DAO
{

	private final String TAG="YieldCalc";
	private static YieldCalculatorCropsDAO yieldCalculatorDAO; 
	 
	public static YieldCalculatorCropsDAO getInstance()
    {
        if (yieldCalculatorDAO == null)
        {
        	yieldCalculatorDAO = new YieldCalculatorCropsDAO();
        }
        
        return yieldCalculatorDAO;
    }

    /**
     * delete the Data
     */

	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}

	
	  /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */

	
	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			
			{
		
		List<DTO> yieldCalculatorInfo=new ArrayList<DTO>();
		Cursor cursor=null; 
		try
		{
		if(!(columnName != null && columnName.length() > 0))	
		
			columnName="id";
		
		 cursor = dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR  where "+columnName+"='"+columnValue+"' ", null);
		 if(cursor.getCount()>0)
		 {
			 cursor.moveToFirst();
			 do
			 {
				 
				 /* YIELD_CALCULATOR
			      	id
					yieldFor
					length
					breadth
					rowSpacing
					rowsHarvested
					harvestedPlants
					population
					totalCobWeight
					shellingPercentage
					totalGrainWeight
					moisturePercentage
					hillsPerSQM
					totalEarheadWeight
					totalDryGrainWeight
					perAcreYield
					yieldGain
					perYieldGain
					activityId
					cropId
			     
			     */
				 
			 YieldCalculatorCropsDTO dto =new YieldCalculatorCropsDTO();
			 
			 dto.setMobileId(cursor.getLong(0));
			 dto.setYieldFor(cursor.getString(1));
			 dto.setLength(cursor.getFloat(2));
			 dto.setBreadth(cursor.getFloat(3));
			 dto.setRowSpacing(cursor.getFloat(4));
			 dto.setRowsHarvested(cursor.getFloat(5));
			 dto.setHarvestedPlants(cursor.getFloat(6));
             dto.setPopulation(cursor.getFloat(7));
             dto.setTotalCobWeight(cursor.getFloat(8));
             dto.setShellingPercentage(cursor.getFloat(9));
             dto.setTotalGrainWeight(cursor.getFloat(10));
             dto.setMoisturePercentage(cursor.getFloat(11));
             dto.setHillsPerSQM(cursor.getFloat(12));
             dto.setTotalEarheadWeight(cursor.getFloat(13));
             dto.setTotalDryGrainWeight(cursor.getFloat(14));
             dto.setPerAcreYield(cursor.getFloat(15));
             dto.setYieldGain(cursor.getFloat(16));
             dto.setPerYieldGain(cursor.getFloat(17));
             dto.setActivityId(cursor.getLong(18));
             dto.setCropId(cursor.getLong(19));
             
             
             yieldCalculatorInfo.add(dto);
             
			 }while(cursor.moveToNext());
		 }
		 
		}catch (Exception e) 
		 {
			 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
		}finally
		{
			if(cursor!= null && cursor.isClosed())
			{
				cursor.close();
			}
			
		   dbObject.close();
		}
          return yieldCalculatorInfo;
		 
			 
		
		 
		 
	}
	
	
	public List<DTO> getRecordInfoById(long cropId, long activityId, SQLiteDatabase dbObject) 
	{
		List<DTO> yieldCalculatorInfo=new ArrayList<DTO>();
		Cursor cursor=null; 
		try
		{
		 cursor = dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR  where cropId = '"+cropId+"' and activityId = '"+activityId+"' ", null);
		 if(cursor.getCount()>0)
		 {
			 cursor.moveToFirst();
			 do
			 {
				 
			 YieldCalculatorCropsDTO dto =new YieldCalculatorCropsDTO();
			 
			 dto.setMobileId(cursor.getLong(0));
			 dto.setYieldFor(cursor.getString(1));
			 dto.setLength(cursor.getFloat(2));
			 dto.setBreadth(cursor.getFloat(3));
			 dto.setRowSpacing(cursor.getFloat(4));
			 dto.setRowsHarvested(cursor.getFloat(5));
			 dto.setHarvestedPlants(cursor.getFloat(6));
             dto.setPopulation(cursor.getFloat(7));
             dto.setTotalCobWeight(cursor.getFloat(8));
             dto.setShellingPercentage(cursor.getFloat(9));
             dto.setTotalGrainWeight(cursor.getFloat(10));
             dto.setMoisturePercentage(cursor.getFloat(11));
             dto.setHillsPerSQM(cursor.getFloat(12));
             dto.setTotalEarheadWeight(cursor.getFloat(13));
             dto.setTotalDryGrainWeight(cursor.getFloat(14));
             dto.setPerAcreYield(cursor.getFloat(15));
             dto.setYieldGain(cursor.getFloat(16));
             dto.setPerYieldGain(cursor.getFloat(17));
             dto.setActivityId(cursor.getLong(18));
             dto.setCropId(cursor.getLong(19));
             
             
             yieldCalculatorInfo.add(dto);
             
			 }while(cursor.moveToNext());
		 }
		 
		}catch (Exception e) 
		 {
			 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
		}finally
		{
			if(cursor!= null && cursor.isClosed())
			{
				cursor.close();
			}
			
		   dbObject.close();
		}
		
        return yieldCalculatorInfo;  
	}

	 /**
     * Gets all the records from the database
     *
      * @param dbObject
      *            : Exposes methods to manage a SQLite database Object
      */

	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)
	
	
	{
		List<DTO> yieldCalculatorInfo=new ArrayList<DTO>();
		Cursor cursor=null; 
		try
		{
			cursor=dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR",null);
			 if(cursor.getCount()>0)
			 {
				 cursor.moveToFirst();
				 do
				 { 
				
					 
			  YieldCalculatorCropsDTO dto =new YieldCalculatorCropsDTO();
				 
				 
			  dto.setMobileId(cursor.getLong(0));
				 dto.setYieldFor(cursor.getString(1));
				 dto.setLength(cursor.getFloat(2));
				 dto.setBreadth(cursor.getFloat(3));
				 dto.setRowSpacing(cursor.getFloat(4));
				 dto.setRowsHarvested(cursor.getFloat(5));
				 dto.setHarvestedPlants(cursor.getFloat(6));
	             dto.setPopulation(cursor.getFloat(7));
	             dto.setTotalCobWeight(cursor.getFloat(8));
	             dto.setShellingPercentage(cursor.getFloat(9));
	             dto.setTotalGrainWeight(cursor.getFloat(10));
	             dto.setMoisturePercentage(cursor.getFloat(11));
	             dto.setHillsPerSQM(cursor.getFloat(12));
	             dto.setTotalEarheadWeight(cursor.getFloat(13));
	             dto.setTotalDryGrainWeight(cursor.getFloat(14));
	             dto.setPerAcreYield(cursor.getFloat(15));
	             dto.setYieldGain(cursor.getFloat(16));
	             dto.setPerYieldGain(cursor.getFloat(17));
	             dto.setActivityId(cursor.getLong(18));
	             dto.setCropId(cursor.getLong(19));
	             
	             yieldCalculatorInfo.add(dto);
				
				 }while(cursor.moveToNext());
			 }
			 
			}catch (Exception e) 
			 {
				 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
			}finally
			{
				if(cursor!= null && cursor.isClosed())
				{
					cursor.close();
				}
				
			   dbObject.close();
			}
	          return yieldCalculatorInfo;
			 
		 
		 
	}
	
	public List<YieldCalculatorCropsDTO> getRecordsForUpload(long activityId, SQLiteDatabase dbObject) 
	{
		List<YieldCalculatorCropsDTO> yieldCalculatorInfo=new ArrayList<YieldCalculatorCropsDTO>();
		Cursor cursor=null; 
		try
		{
		 cursor = dbObject.rawQuery("SELECT * FROM  YIELD_CALCULATOR  where activityId = '"+activityId+"' ", null);
		 if(cursor.getCount()>0)
		 {
			 cursor.moveToFirst();
			 do
			 {
				 
			 YieldCalculatorCropsDTO dto =new YieldCalculatorCropsDTO();
			 
			 dto.setMobileId(cursor.getLong(0));
			 dto.setYieldFor(cursor.getString(1));
			 dto.setLength(cursor.getFloat(2));
			 dto.setBreadth(cursor.getFloat(3));
			 dto.setRowSpacing(cursor.getFloat(4));
			 dto.setRowsHarvested(cursor.getFloat(5));
			 dto.setHarvestedPlants(cursor.getFloat(6));
             dto.setPopulation(cursor.getFloat(7));
             dto.setTotalCobWeight(cursor.getFloat(8));
             dto.setShellingPercentage(cursor.getFloat(9));
             dto.setTotalGrainWeight(cursor.getFloat(10));
             dto.setMoisturePercentage(cursor.getFloat(11));
             dto.setHillsPerSQM(cursor.getFloat(12));
             dto.setTotalEarheadWeight(cursor.getFloat(13));
             dto.setTotalDryGrainWeight(cursor.getFloat(14));
             dto.setPerAcreYield(cursor.getFloat(15));
             dto.setYieldGain(cursor.getFloat(16));
             dto.setPerYieldGain(cursor.getFloat(17));
             dto.setActivityId(cursor.getLong(18));
             dto.setCropId(cursor.getLong(19));
             
             
             yieldCalculatorInfo.add(dto);
             
			 }while(cursor.moveToNext());
		 }
		 
		}catch (Exception e) 
		 {
			 ATBuildLog.e(TAG +"getRecords()",e.getMessage());
		}finally
		{
			if(cursor!= null && cursor.isClosed())
			{
				cursor.close();
			}
			
		   dbObject.close();
		}
		
        return yieldCalculatorInfo;  
	}
	    	
    
    
	  /**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
	
	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		try
		{
			YieldCalculatorCropsDTO dto=(YieldCalculatorCropsDTO) dtoObject;
			
			ContentValues cValues=new ContentValues();
			
			/* YIELD_CALCULATOR
	      	id
			yieldFor
			length
			breadth
			rowSpacing
			rowsHarvested
			harvestedPlants
			population
			totalCobWeight
			shellingPercentage
			totalGrainWeight
			moisturePercentage
			hillsPerSQM
			totalEarheadWeight
			totalDryGrainWeight
			perAcreYield
			yieldGain
			perYieldGain
			activityId
			cropId
	     
	     */
			cValues.put("yieldFor",dto.getYieldFor());
			 cValues.put("length",dto.getLength());
			 cValues.put("breadth",dto.getBreadth());
			 cValues.put("rowSpacing",dto.getRowSpacing());
			 cValues.put("rowsHarvested",dto.getRowsHarvested());
			 cValues.put("harvestedPlants",dto.getHarvestedPlants());
			 cValues.put("population", dto.getPopulation());
	         cValues.put("totalCobWeight", dto.getTotalCobWeight());
	         cValues.put("shellingPercentage",dto.getShellingPercentage());
			cValues.put("totalGrainWeight",dto.getTotalGrainWeight());
			cValues.put("moisturePercentage",dto.getMoisturePercentage());
			cValues.put("hillsPerSQM",dto.getHillsPerSQM());
			cValues.put("totalEarheadWeight",dto.getTotalEarheadWeight());
			cValues.put("totalDryGrainWeight",dto.getTotalDryGrainWeight());
			cValues.put("perAcreYield",dto.getPerAcreYield());
			cValues.put("yieldGain",dto.getYieldGain());
			cValues.put("perYieldGain",dto.getPerYieldGain());
			cValues.put("activityId",dto.getActivityId());
			cValues.put("cropId",dto.getCropId());
	         
		dbObject.insert("YIELD_CALCULATOR", null, cValues);
		
		return true;
		
		}catch(SQLException e)
		{

			ATBuildLog.e(TAG +"insert()",e.getMessage());
				return false;
				
			
		}finally{
			 dbObject.close();
		 }
		 
	}

	/**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
  
	
	
	
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	
	{
		try{
			YieldCalculatorCropsDTO dto = (YieldCalculatorCropsDTO) dtoObject;
			ContentValues cValues=new ContentValues();
			
			if(dto.getLength() != null)
				cValues.put("length",dto.getLength());
			
			if(dto.getBreadth() != null)
				cValues.put("breadth",dto.getBreadth());
			
			if(dto.getRowSpacing() != null)
				cValues.put("rowSpacing",dto.getRowSpacing());
			
			if(dto.getRowsHarvested() != null)
				cValues.put("rowsHarvested",dto.getRowsHarvested());
			
			if(dto.getPopulation() != null)
				cValues.put("population", dto.getPopulation());
			
			if(dto.getTotalCobWeight() != null)
				cValues.put("totalCobWeight", dto.getTotalCobWeight());
			
			if(dto.getShellingPercentage() != null)
				cValues.put("shellingPercentage",dto.getShellingPercentage());
			
			if(dto.getTotalGrainWeight() != null)
				cValues.put("totalGrainWeight",dto.getTotalGrainWeight());
			
			if(dto.getMoisturePercentage() != null)
				cValues.put("moisturePercentage",dto.getMoisturePercentage());
			
			if(dto.getHillsPerSQM() != null)
				cValues.put("hillsPerSQM",dto.getHillsPerSQM());
			
			if(dto.getTotalEarheadWeight() != null)
				cValues.put("totalEarheadWeight",dto.getTotalEarheadWeight());
			
			if(dto.getTotalDryGrainWeight() != null)
				cValues.put("totalDryGrainWeight",dto.getTotalDryGrainWeight());
			
			if(dto.getPerAcreYield() != null)
				cValues.put("perAcreYield",dto.getPerAcreYield());
			
			if(dto.getYieldGain() != null)
				cValues.put("yieldGain",dto.getYieldGain());
			
			if(dto.getPerYieldGain() != null)
				cValues.put("perYieldGain",dto.getPerYieldGain());
			
			if(dto.getActivityId() != null)
				cValues.put("activityId",dto.getActivityId());
			
			if(dto.getCropId() != null)
				cValues.put("cropId",dto.getCropId());
			
			if(dto.getYieldFor() != null)
				cValues.put("yieldFor",dto.getYieldFor());
			
			if(dto.getHarvestedPlants() != null)
				cValues.put("harvestedPlants",dto.getHarvestedPlants());
				
	            dbObject.update("YIELD_CALCULATOR", cValues, "ActivityId='" +dto.getActivityId()+"' and cropId = '"+dto.getCropId()+"' and yieldFor = '"+dto.getYieldFor()+"' ", null);
	            
	            return true;
	             
	}catch(SQLException e)
	 {
		 ATBuildLog.e(TAG + "update()",e.getMessage());
		 e.printStackTrace();
	 } catch (Exception e)
	 {
		 e.printStackTrace();
	 }finally
	 {
		 dbObject.close();
	 }
	return false;
}
	 /**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM  YIELD_CALCULATOR").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

	
    public boolean deleteTableDataById(long activityId,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM YIELD_CALCULATOR where activityId = '"+activityId+"'").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataByActivityId(String activityId, SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("DELETE FROM YIELD_CALCULATOR  where   activityId = '"+activityId+"' ");
			return true;
		}catch(Exception e)
		{
			ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally
		
		{
		
		dbObject.close();
		
		}
		return false;
	}  
	


}
