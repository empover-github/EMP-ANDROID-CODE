package com.activitytrack.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.listeners.OnListItemClickListener;

import java.util.List;

/**
 * Created by fatima.t on 20/12/2017.
 */

public class GerminationVerficationListAdapter extends RecyclerView.Adapter<GerminationVerficationListAdapter.UploadedVillageHolder> {
    Context context;
    List<GerminationverificationListDTO> gerVerificationList;
    private OnListItemClickListener listener;

    public GerminationVerficationListAdapter(Context context, List<GerminationverificationListDTO> profilesList, OnListItemClickListener listener) {
        this.context = context;
        this.gerVerificationList = profilesList;
        this.listener = listener;
    }

    @Override
    public UploadedVillageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.germination_verification_list_item, parent, false);
        return new UploadedVillageHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(UploadedVillageHolder holder, int position) {
        holder.bind(gerVerificationList.get(position));
    }

    @Override
    public int getItemCount() {
        return gerVerificationList.size();
    }


    public class UploadedVillageHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView headerTv, farmerNameTv, farmerMobNoTv, farmerPincodeTv, germFailedAcresTv, dateOfSowingTv, statusTv, verifyTv;

        LinearLayout mainLayout;

        public UploadedVillageHolder(View view) {
            super(view);

            mainLayout = (LinearLayout) view.findViewById(R.id.gvl_parentLL);
            headerTv = (TextView) view.findViewById(R.id.gvl_titleTv);
            farmerNameTv = (TextView) view.findViewById(R.id.gvl_farmerNameTV);
            farmerMobNoTv = (TextView) view.findViewById(R.id.gvl_farmerMobNoTV);
            farmerPincodeTv = (TextView) view.findViewById(R.id.gvl_pincodeTV);
            germFailedAcresTv = (TextView) view.findViewById(R.id.gvl_germFailedTV);
            dateOfSowingTv = (TextView) view.findViewById(R.id.gvl_dateOfSowingTV);
            statusTv = (TextView) view.findViewById(R.id.gvl_statusTV);
            verifyTv = (TextView) view.findViewById(R.id.gvl_verifyTvBtn);

            mainLayout.setOnClickListener(this);
            verifyTv.setOnClickListener(this);
        }

        public void bind(final GerminationverificationListDTO gerModel) {
            String header = gerModel.getYear() +"-"+gerModel.getSeasonName()+"-"+gerModel.getCropName();
            String gerFailedAcres  = gerModel.getGerminationFailedAcres() +" acres" ;
            headerTv.setText(header);
            farmerNameTv.setText(gerModel.getName());
            farmerMobNoTv.setText(gerModel.getFarmerMobileNumber());
            farmerPincodeTv.setText(gerModel.getPincode());
            germFailedAcresTv.setText(gerFailedAcres);
            dateOfSowingTv.setText(gerModel.getDateOfSowing());
            statusTv.setText(gerModel.getStatus());

            mainLayout.setTag(gerModel);
            verifyTv.setTag(gerModel);
        }

        @Override
        public void onClick(View v) {
            listener.onItemClick(v, getAdapterPosition());
        }
    }
}
