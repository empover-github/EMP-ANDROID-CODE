package com.activitytrack.dtos;

import java.util.ArrayList;

/**
 * Created by fatima.t on 24-04-2018.
 */

public class DipsticDashboardDTO implements DTO {
    private long noOfFarmersPi;
    private long noOfFarmersFu;
    private long totalAcresPi;
    private long totalAcresFu;
    private long hybridAcresPi;
    private long hybridAcresFu;
    private long pioneerHybridAcresPi;
    private long pioneerHybridAcresFu;
    private ArrayList<String> issuedDataSet1keys;
    private ArrayList<Integer> issuedDataSet1Values;
    private ArrayList<String> issuedDataSet2keys;
    private ArrayList<Integer> issuedDataSet2Values;
    /*private LinkedHashMap<String, Integer> issuedDataSet1;
    private LinkedHashMap<String, Integer> issuedDataSet2;
    private LinkedHashMap<String, Integer> notIssuedDataSet1;
    private LinkedHashMap<String, Integer> notIssuedDataSet2;*/

    public long getNoOfFarmersPi() {
        return noOfFarmersPi;
    }

    public void setNoOfFarmersPi(long noOfFarmersPi) {
        this.noOfFarmersPi = noOfFarmersPi;
    }

    public long getNoOfFarmersFu() {
        return noOfFarmersFu;
    }

    public void setNoOfFarmersFu(long noOfFarmersFu) {
        this.noOfFarmersFu = noOfFarmersFu;
    }

    public long getTotalAcresPi() {
        return totalAcresPi;
    }

    public void setTotalAcresPi(long totalAcresPi) {
        this.totalAcresPi = totalAcresPi;
    }

    public long getTotalAcresFu() {
        return totalAcresFu;
    }

    public void setTotalAcresFu(long totalAcresFu) {
        this.totalAcresFu = totalAcresFu;
    }

    public long getHybridAcresPi() {
        return hybridAcresPi;
    }

    public void setHybridAcresPi(long hybridAcresPi) {
        this.hybridAcresPi = hybridAcresPi;
    }

    public long getHybridAcresFu() {
        return hybridAcresFu;
    }

    public void setHybridAcresFu(long hybridAcresFu) {
        this.hybridAcresFu = hybridAcresFu;
    }

    public long getPioneerHybridAcresPi() {
        return pioneerHybridAcresPi;
    }

    public void setPioneerHybridAcresPi(long pioneerHybridAcresPi) {
        this.pioneerHybridAcresPi = pioneerHybridAcresPi;
    }

    public long getPioneerHybridAcresFu() {
        return pioneerHybridAcresFu;
    }

    public void setPioneerHybridAcresFu(long pioneerHybridAcresFu) {
        this.pioneerHybridAcresFu = pioneerHybridAcresFu;
    }

    /*public LinkedHashMap<String, Integer> getIssuedDataSet1() {
        return issuedDataSet1;
    }

    public void setIssuedDataSet1(LinkedHashMap<String, Integer> issuedDataSet1) {
        this.issuedDataSet1 = issuedDataSet1;
    }

    public LinkedHashMap<String, Integer> getIssuedDataSet2() {
        return issuedDataSet2;
    }

    public void setIssuedDataSet2(LinkedHashMap<String, Integer> issuedDataSet2) {
        this.issuedDataSet2 = issuedDataSet2;
    }

    public LinkedHashMap<String, Integer> getNotIssuedDataSet1() {
        return notIssuedDataSet1;
    }

    public void setNotIssuedDataSet1(LinkedHashMap<String, Integer> notIssuedDataSet1) {
        this.notIssuedDataSet1 = notIssuedDataSet1;
    }

    public LinkedHashMap<String, Integer> getNotIssuedDataSet2() {
        return notIssuedDataSet2;
    }

    public void setNotIssuedDataSet2(LinkedHashMap<String, Integer> notIssuedDataSet2) {
        this.notIssuedDataSet2 = notIssuedDataSet2;
    }*/

    public ArrayList<String> getIssuedDataSet1keys() {
        return issuedDataSet1keys;
    }

    public void setIssuedDataSet1keys(ArrayList<String> issuedDataSet1keys) {
        this.issuedDataSet1keys = issuedDataSet1keys;
    }

    public ArrayList<Integer> getIssuedDataSet1Values() {
        return issuedDataSet1Values;
    }

    public void setIssuedDataSet1Values(ArrayList<Integer> issuedDataSet1Values) {
        this.issuedDataSet1Values = issuedDataSet1Values;
    }

    public ArrayList<String> getIssuedDataSet2keys() {
        return issuedDataSet2keys;
    }

    public void setIssuedDataSet2keys(ArrayList<String> issuedDataSet2keys) {
        this.issuedDataSet2keys = issuedDataSet2keys;
    }

    public ArrayList<Integer> getIssuedDataSet2Values() {
        return issuedDataSet2Values;
    }

    public void setIssuedDataSet2Values(ArrayList<Integer> issuedDataSet2Values) {
        this.issuedDataSet2Values = issuedDataSet2Values;
    }
}
