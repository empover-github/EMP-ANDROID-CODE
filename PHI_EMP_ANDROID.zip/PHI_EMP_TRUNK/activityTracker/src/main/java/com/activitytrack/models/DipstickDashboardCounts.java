package com.activitytrack.models;

/**
 * Created by fatima.t on 25-04-2018.
 */

public class DipstickDashboardCounts {
    private long noOfFarmers;
    private long totalNoOfAcres;
    private long totalNoOfHybridAcres;
    private long totalPioneerHybridAcres;

    public long getNoOfFarmers() {
        return noOfFarmers;
    }

    public void setNoOfFarmers(long noOfFarmers) {
        this.noOfFarmers = noOfFarmers;
    }

    public long getTotalNoOfAcres() {
        return totalNoOfAcres;
    }

    public void setTotalNoOfAcres(long totalNoOfAcres) {
        this.totalNoOfAcres = totalNoOfAcres;
    }

    public long getTotalNoOfHybridAcres() {
        return totalNoOfHybridAcres;
    }

    public void setTotalNoOfHybridAcres(long totalNoOfHybridAcres) {
        this.totalNoOfHybridAcres = totalNoOfHybridAcres;
    }

    public long getTotalPioneerHybridAcres() {
        return totalPioneerHybridAcres;
    }

    public void setTotalPioneerHybridAcres(long totalPioneerHybridAcres) {
        this.totalPioneerHybridAcres = totalPioneerHybridAcres;
    }
}
