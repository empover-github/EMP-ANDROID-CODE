package com.activitytrack.masterdaos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class MdrMasterDAO  implements MasterDAO
{
	private final String TAG = "MdrMaster";
    private static MdrMasterDAO mdrMasterDAO;
   
    
    public static MdrMasterDAO getInstance()
    {
        if (mdrMasterDAO == null)
        {
        	mdrMasterDAO = new MdrMasterDAO();
        }
        
        return mdrMasterDAO;
    }

    /**
     * delete the Data
     */
	
	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}
	
	
	 /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
	
	
	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject)  
			
			{
			List<DTO> mdrMasterInfo = new ArrayList<DTO>();
             Cursor cursor = null;
    try
    {
    	
        cursor = dbObject.rawQuery("SELECT * FROM  MDR_MASTER where id='"+columnValue+"' ", null);
        if (cursor.getCount() > 0)
        {
            cursor.moveToFirst();
            do
            {
            	/*MDR_MASTER
            	id
            	 name
            	 empId
            	 loginId
            	 password
            	 mobileNo
            	 regionId
            	  */
         
            	MdrMasterDTO dto = new MdrMasterDTO();
                
            	dto.setId(cursor.getLong(0));
            	dto.setName(cursor.getString(1));
            	dto.setEmpId(cursor.getString(2));
            	dto.setLoginId(cursor.getString(3));
            	dto.setPassword(cursor.getString(4));
            	dto.setMobileNo(cursor.getLong(5));
            	dto.setRegionId(cursor.getLong(6));
            	
                
                mdrMasterInfo.add(dto);
            
            } while (cursor.moveToNext());
        }
    } catch (Exception e)
    {
		ATBuildLog.e(TAG + "getRecords()", e.getMessage());
    } finally
    {
        if (cursor != null && !cursor.isClosed())
        {
            cursor.close();
        }
        dbObject.close();
    }

    return mdrMasterInfo;
}


	
	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject) 
	{
		List<DTO> mdrMasterInfo = new ArrayList<DTO>();
	       Cursor cursor = null;
	    try
	    {
	        cursor = dbObject.rawQuery("SELECT * FROM  MDR_MASTER  ", null);
	        if (cursor.getCount() > 0)
	        {
	            cursor.moveToFirst();
	            do
	            {
	            	MdrMasterDTO dto = new MdrMasterDTO();
	                
	            	dto.setId(cursor.getLong(0));
	            	dto.setName(cursor.getString(1));
	            	dto.setEmpId(cursor.getString(2));
	            	dto.setLoginId(cursor.getString(3));
	            	dto.setPassword(cursor.getString(4));
	            	dto.setMobileNo(cursor.getLong(5));
	            	dto.setRegionId(cursor.getLong(6));
	            	
	                mdrMasterInfo.add(dto);

	            } while (cursor.moveToNext());
	        } 
	    } catch (Exception e)
	    {
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	    } finally
	    {
	        if (cursor != null && !cursor.isClosed())
	        {
	            cursor.close();
	        }
	        dbObject.close();
	    }

		 
			return mdrMasterInfo;
		}
	
	public long getRegionId(SQLiteDatabase dbObject) 
	{
		long regionId = 0;
       Cursor cursor = null;
	    try
	    {
	        cursor = dbObject.rawQuery("SELECT regionId FROM  MDR_MASTER  ", null);
	        if (cursor.getCount() > 0)
	        {
	            cursor.moveToFirst();
	            regionId = cursor.getLong(0);
	        } 
	    } catch (Exception e)
	    {
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	    } finally
	    {
	        if (cursor != null && !cursor.isClosed())
	        {
	            cursor.close();
	        }
	        dbObject.close();
	    }

			return regionId;
		}
	
	/**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
   	 
		 
 
	
	
	
	
	
	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		 try
         {            
         	MdrMasterDTO dto = (MdrMasterDTO) dtoObject;

             ContentValues cValues = new ContentValues();

         	/*MDR_MASTER
        	 
        	 id
        	 name
        	 empId
        	 loginId
        	 password
        	 mobileNo
        	 regionId
        	 */
             cValues.put("id",dto.getId());
             cValues.put("name",dto.getName());
             cValues.put("empId",dto.getEmpId());
             cValues.put("loginId",dto.getLoginId());
             cValues.put("password",dto.getPassword());
             cValues.put("mobileNo",dto.getMobileNo());
             cValues.put("regionId",dto.getRegionId());
             
             
             dbObject.insert("MDR_MASTER", null, cValues);
             return true;
         } catch (SQLException e)
         {
			 ATBuildLog.e(TAG + "insert()", e.getMessage());
             return false;
         } finally
         {
             dbObject.close();
         }

	}
	 /**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
  

	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		 try
	        {
	            
	        	MdrMasterDTO dto = (MdrMasterDTO) dtoObject;

	            ContentValues cValues = new ContentValues();
	            
	            cValues.put("name", dto.getName());
	            cValues.put("empId",dto.getEmpId());
	            cValues.put("loginId",dto.getLoginId());
	            cValues.put("password",dto.getPassword());
	            cValues.put("mobileNo",dto.getMobileNo());
	            cValues.put("regionId",dto.getRegionId());
	            
	            dbObject.update("MDR_MASTER", cValues, "id='" +dto.getId()+"' ", null);
	            return true;
	        } catch (SQLException e)
	        {
				ATBuildLog.e(TAG + "update()", e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        } finally
	        {
	            dbObject.close();
	        }
	        return false;
	    }

	 
	  /**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM  MDR_MASTER").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

 
	public boolean updateloginId(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		 try
	        {
	            
	        	MdrMasterDTO dto = (MdrMasterDTO) dtoObject;

	            ContentValues cValues = new ContentValues();
	            
	            if(dto.getName()!= null)
	            	cValues.put("name", dto.getName());
	           
	            if(dto.getEmpId()!= null)
	            	cValues.put("empId",dto.getEmpId());
	           
	            if(dto.getPassword()!= null)
	            	cValues.put("password",dto.getPassword());
	            
	            if(dto.getMobileNo()!= 0)
	            	cValues.put("mobileNo",dto.getMobileNo());
	            
	            if(dto.getRegionId()!= 0)
	            	cValues.put("regionId",dto.getRegionId());
	            
	            dbObject.update("MDR_MASTER", cValues, "loginId='" +dto.getLoginId()+"' ", null);
	            return true;
	        } catch (SQLException e)
	        {
				ATBuildLog.e(TAG + "update()", e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        } finally
	        {
	            dbObject.close();
	        }
	        return false;
	    }



	public boolean isDataAvailable(SQLiteDatabase dbObject)
	{
		Cursor cursor = null;
		try
		{
			cursor = dbObject.rawQuery("SELECT count(id) FROM MDR_MASTER", null);
			if (cursor.getCount() > 0)
			{
				cursor.moveToFirst();
				return cursor.getLong(0) > 0;
			}
		} catch (Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		} finally
		{
			if (cursor != null && !cursor.isClosed())
			{
				cursor.close();
			}
			dbObject.close();
		}

		return  false;
	}
	
}
