package com.activitytrack.masterdtos;

import com.activitytrack.dtos.DTO;

public class OtherCropMasterDTO implements DTO
{
	private long id;
	private String name;
	private long cropId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getCropId() {
		return cropId;
	}

	public void setCropId(long cropId) {
		this.cropId = cropId;
	}
}
