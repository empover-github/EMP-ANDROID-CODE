package com.activitytrack.dtos;

public class NewMdrSurveyDTO implements DTO {

    private String localImagePath;
    private String geoLocation;
    private String farmerName;
    private String mobileNo ;
    private long noOfFamilies ;
    private long totalLand ;
    private long majorCompany1 ;
    private float majorCompany1Acreage ;
    private long majorCompany2 ;
    private float majorCompany2Acreage ;
    private long majorCompany3 ;
    private float majorCompany3Acreage ;
    private long majorCompany4 ;
    private float majorCompany4Acreage ;
    private long majorCompany5 ;
    private float majorCompany5Acreage ;
    private float otherCompanyAcreage ;
    private float segmentTypeUpland ;
    private float segmentTypeMidland ;
    private float segmentTypeMidLowland ;
    private float segmentTypeFineRice ;
    private float segmentTypeLowland ;
    private float pioneerHybridType1Acres ;
    private float pioneerHybridType2Acres ;
    private float pioneerHybridType3Acres ;
    private long pioneerHybrid1 ;
    private float pioneerHybrid1Acres ;
    private long pioneerHybrid2 ;
    private float pioneerHybrid2Acres ;
    private String  date;
    private long  mobileId ;
    private long  activityId ;
    private float  totalResearchAcres ;
    private long  majorResearchCompanyName ;

    private String highestCompanyName;
    private float  highestCompanyPercentage;



    public String getLocalImagePath() {
        return localImagePath;
    }

    public void setLocalImagePath(String localImagePath) {
        this.localImagePath = localImagePath;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public long getNoOfFamilies() {
        return noOfFamilies;
    }

    public void setNoOfFamilies(long noOfFamilies) {
        this.noOfFamilies = noOfFamilies;
    }

    public long getTotalLand() {
        return totalLand;
    }

    public void setTotalLand(long totalLand) {
        this.totalLand = totalLand;
    }

    public long getMajorCompany1() {
        return majorCompany1;
    }

    public void setMajorCompany1(long majorCompany1) {
        this.majorCompany1 = majorCompany1;
    }

    public float getMajorCompany1Acreage() {
        return majorCompany1Acreage;
    }

    public void setMajorCompany1Acreage(float majorCompany1Acreage) {
        this.majorCompany1Acreage = majorCompany1Acreage;
    }

    public long getMajorCompany2() {
        return majorCompany2;
    }

    public void setMajorCompany2(long majorCompany2) {
        this.majorCompany2 = majorCompany2;
    }

    public float getMajorCompany2Acreage() {
        return majorCompany2Acreage;
    }

    public void setMajorCompany2Acreage(float majorCompany2Acreage) {
        this.majorCompany2Acreage = majorCompany2Acreage;
    }

    public long getMajorCompany3() {
        return majorCompany3;
    }

    public void setMajorCompany3(long majorCompany3) {
        this.majorCompany3 = majorCompany3;
    }

    public float getMajorCompany3Acreage() {
        return majorCompany3Acreage;
    }

    public void setMajorCompany3Acreage(float majorCompany3Acreage) {
        this.majorCompany3Acreage = majorCompany3Acreage;
    }

    public long getMajorCompany4() {
        return majorCompany4;
    }

    public void setMajorCompany4(long majorCompany4) {
        this.majorCompany4 = majorCompany4;
    }

    public float getMajorCompany4Acreage() {
        return majorCompany4Acreage;
    }

    public void setMajorCompany4Acreage(float majorCompany4Acreage) {
        this.majorCompany4Acreage = majorCompany4Acreage;
    }

    public long getMajorCompany5() {
        return majorCompany5;
    }

    public void setMajorCompany5(long majorCompany5) {
        this.majorCompany5 = majorCompany5;
    }

    public float getMajorCompany5Acreage() {
        return majorCompany5Acreage;
    }

    public void setMajorCompany5Acreage(float majorCompany5Acreage) {
        this.majorCompany5Acreage = majorCompany5Acreage;
    }

    public float getOtherCompanyAcreage() {
        return otherCompanyAcreage;
    }

    public void setOtherCompanyAcreage(float otherCompanyAcreage) {
        this.otherCompanyAcreage = otherCompanyAcreage;
    }

    public float getSegmentTypeUpland() {
        return segmentTypeUpland;
    }

    public void setSegmentTypeUpland(float segmentTypeUpland) {
        this.segmentTypeUpland = segmentTypeUpland;
    }

    public float getSegmentTypeMidland() {
        return segmentTypeMidland;
    }

    public void setSegmentTypeMidland(float segmentTypeMidland) {
        this.segmentTypeMidland = segmentTypeMidland;
    }

    public float getSegmentTypeMidLowland() {
        return segmentTypeMidLowland;
    }

    public void setSegmentTypeMidLowland(float segmentTypeMidLowland) {
        this.segmentTypeMidLowland = segmentTypeMidLowland;
    }

    public float getSegmentTypeFineRice() {
        return segmentTypeFineRice;
    }

    public void setSegmentTypeFineRice(float segmentTypeFineRice) {
        this.segmentTypeFineRice = segmentTypeFineRice;
    }

    public float getSegmentTypeLowland() {
        return segmentTypeLowland;
    }

    public void setSegmentTypeLowland(float segmentTypeLowland) {
        this.segmentTypeLowland = segmentTypeLowland;
    }

    public float getPioneerHybridType1Acres() {
        return pioneerHybridType1Acres;
    }

    public void setPioneerHybridType1Acres(float pioneerHybridType1Acres) {
        this.pioneerHybridType1Acres = pioneerHybridType1Acres;
    }

    public float getPioneerHybridType2Acres() {
        return pioneerHybridType2Acres;
    }

    public void setPioneerHybridType2Acres(float pioneerHybridType2Acres) {
        this.pioneerHybridType2Acres = pioneerHybridType2Acres;
    }

    public float getPioneerHybridType3Acres() {
        return pioneerHybridType3Acres;
    }

    public void setPioneerHybridType3Acres(float pioneerHybridType3Acres) {
        this.pioneerHybridType3Acres = pioneerHybridType3Acres;
    }

    public long getPioneerHybrid1() {
        return pioneerHybrid1;
    }

    public void setPioneerHybrid1(long pioneerHybrid1) {
        this.pioneerHybrid1 = pioneerHybrid1;
    }

    public float getPioneerHybrid1Acres() {
        return pioneerHybrid1Acres;
    }

    public void setPioneerHybrid1Acres(float pioneerHybrid1Acres) {
        this.pioneerHybrid1Acres = pioneerHybrid1Acres;
    }

    public long getPioneerHybrid2() {
        return pioneerHybrid2;
    }

    public void setPioneerHybrid2(long pioneerHybrid2) {
        this.pioneerHybrid2 = pioneerHybrid2;
    }

    public float getPioneerHybrid2Acres() {
        return pioneerHybrid2Acres;
    }

    public void setPioneerHybrid2Acres(float pioneerHybrid2Acres) {
        this.pioneerHybrid2Acres = pioneerHybrid2Acres;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public long getId() {
        return mobileId;
    }

    public void setId(long mobileid) {

        this.mobileId = mobileid;
    }

    public long getActivityId() {
        return activityId;
    }

    public void setActivityId(long activityId) {
        this.activityId = activityId;
    }

    public float getTotalResearchAcres() {
        return totalResearchAcres;
    }

    public void setTotalResearchAcres(float totalResearchAcres) {
        this.totalResearchAcres = totalResearchAcres;
    }

    public long getMajorResearchCompanyName() {
        return majorResearchCompanyName;
    }

    public void setMajorResearchCompanyName(long majorResearchCompanyName) {
        this.majorResearchCompanyName = majorResearchCompanyName;
    }

    public String getHighestCompanyName() {
        return highestCompanyName;
    }

    public void setHighestCompanyName(String highestCompanyName) {
        this.highestCompanyName = highestCompanyName;
    }

    public float getHighestCompanyPercentage() {
        return highestCompanyPercentage;
    }

    public void setHighestCompanyPercentage(float highestCompanyPercentage) {
        this.highestCompanyPercentage = highestCompanyPercentage;
    }
}
