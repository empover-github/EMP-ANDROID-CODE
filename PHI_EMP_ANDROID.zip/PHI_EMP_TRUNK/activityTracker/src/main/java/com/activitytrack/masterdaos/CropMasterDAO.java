package com.activitytrack.masterdaos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;


public class CropMasterDAO implements MasterDAO {
    private final String TAG = "Crop";
    private static CropMasterDAO cropMasterDAO;


    public static CropMasterDAO getInstance() {
        if (cropMasterDAO == null) {
            cropMasterDAO = new CropMasterDAO();
        }

        return cropMasterDAO;
    }

    /**
     * delete the Data
     */


    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {

        return false;
    }


    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> cropMasterInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM CROP_MASTER where id='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    /*id
			     	name */
                    CropMasterDTO dto = new CropMasterDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setName(cursor.getString(1));

                    cropMasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return cropMasterInfo;
    }


    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */


    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject)


    {
        List<DTO> cropMasterInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM CROP_MASTER ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    CropMasterDTO dto = new CropMasterDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setName(cursor.getString(1));

                    cropMasterInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }


        return cropMasterInfo;
    }


    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */


    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            CropMasterDTO dto = (CropMasterDTO) dtoObject;

            ContentValues cValues = new ContentValues();
             /*id
 	     	name */

            cValues.put("id", dto.getId());
            cValues.put("name", dto.getName());

            dbObject.insert("CROP_MASTER", null, cValues);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;
        } finally {
            dbObject.close();
        }


    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            CropMasterDTO dto = (CropMasterDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            cValues.put("name", dto.getName());

            dbObject.update("CROP_MASTER", cValues, "id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM CROP_MASTER").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public String getName(long columnValue, SQLiteDatabase dbObject) {
        String name = null;
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM CROP_MASTER where id='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    /*id
			     	name */
                    name = cursor.getString(1);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return name;
    }


}
