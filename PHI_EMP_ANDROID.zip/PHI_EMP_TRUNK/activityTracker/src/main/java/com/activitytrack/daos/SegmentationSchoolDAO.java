package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.models.IdNameModel;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class SegmentationSchoolDAO implements DAO {

    private final String TAG = "segmentationSchool";
    private static SegmentationSchoolDAO segSchoolDAO;

    public static SegmentationSchoolDAO getInstance() {
        if (segSchoolDAO == null) {
            segSchoolDAO = new SegmentationSchoolDAO();
        }
        return segSchoolDAO;
    }
    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

/**
 * Gets the record from the database based on the value passed
 *
 * @param columnName  : Database column name
 * @param columnValue : Column Value
 * @param dbObject    : Exposes methods to manage a SQLite database Object
 */
@Override
public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
    List<DTO> getRecordsListByValue = new ArrayList<DTO>();
    Cursor cursor = null;
    try {
        cursor = dbObject.rawQuery("SELECT * FROM TABLE_FS_SCHOOL where " + columnName + "='" + columnValue + "' ", null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {

                IdNameModel dto = new IdNameModel();
                dto.setId(cursor.getLong(0));
                dto.setName(cursor.getString(1));

                getRecordsListByValue.add(dto);
            } while (cursor.moveToNext());
        }
    } catch (Exception e) {
        ATBuildLog.e(TAG + "getRecords()", e.getMessage());
    } finally {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        dbObject.close();
    }

    return getRecordsListByValue;
}

    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM TABLE_FS_SCHOOL ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    IdNameModel dto = new IdNameModel();
                    /*id NUMBER, name TEXT, seasonId TEXT*/
                    dto.setId(cursor.getLong(0));
                    dto.setName(cursor.getString(1));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override

    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {

        try
        {
            IdNameModel dto=(IdNameModel) dtoObject;
            /*id NUMBER, name TEXT, seasonId TEXT*/

            ContentValues cValues=new ContentValues();

            cValues.put("id", dto.getId());
            cValues.put("name", dto.getName());
            cValues.put("devCenterId",dto.getDevCenterId());


            dbObject.insert("TABLE_FS_SCHOOL", null, cValues);

            return true;

        }catch(SQLException e)
        {

            ATBuildLog.e(TAG +"insert()",e.getMessage());
            return false;


        }finally{
            dbObject.close();
        }

    }

    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            IdNameModel dto = (IdNameModel) dtoObject;
            /*id NUMBER, name TEXT, districtId TEXT*/

            ContentValues cValues = new ContentValues();

            cValues.put("id", dto.getId());
            cValues.put("name", dto.getName());
            cValues.put("devCenterId",dto.getDevCenterId());

            long insertedRow = dbObject.insert("TABLE_FS_SCHOOL", null, cValues);
            if (insertedRow > 0) {
                Cursor cursor = dbObject.rawQuery("SELECT MAX(id) FROM  TABLE_FS_SCHOOL", null);
                if (cursor.getCount() > 0) {

                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            IdNameModel dto = (IdNameModel) dtoObject;
            /*id NUMBER, name TEXT, districtId TEXT*/

            ContentValues cValues = new ContentValues();

            if (dto.getId() != 0)
                cValues.put("id", dto.getId());

            if (dto.getName() != null)
                cValues.put("name", dto.getName());

            if (dto.getDevCenterId() != 0)
                cValues.put("devCenterId", dto.getDevCenterId());



            dbObject.update("TABLE_FS_SCHOOL", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }



    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM TABLE_FS_SCHOOL").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from TABLE_FS_SCHOOL where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }


    public boolean deleteTableDataById(long id,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM TABLE_FS_SCHOOL where id = '"+id+"'").execute();
            return true;
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public List<IdNameModel> getAllRecords(SQLiteDatabase dbObject) {
        List<IdNameModel> allRecordsList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM TABLE_FS_SCHOOL ORDER BY name ASC", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    IdNameModel dto = new IdNameModel();

                    dto.setId(cursor.getLong(0));
                    dto.setName(cursor.getString(1));
                    dto.setDevCenterId(cursor.getLong(2));

                    allRecordsList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return allRecordsList;
    }

    public List<DTO> getRecordsById(long id, SQLiteDatabase dbObject) {

        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM TABLE_FS_SCHOOL where id = '" + id + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    IdNameModel dto = new IdNameModel();

                    dto.setId(cursor.getLong(0));
                    dto.setName(cursor.getString(1));
                    dto.setDevCenterId(cursor.getLong(2));


                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

}

