package com.activitytrack.dtos;

public class LiquidationTrackingDTO implements DTO
{
	private long id;
	private String location;
	private int isSync;
	
	private String crop;
	private String salesDate; 
	private String retailerName;
	private long retailerMobileNo;
	private int  pinCode;
	private int  season;
	private int pioneerSales;
	private int  competitor1Sales;
	private int  competitor2Sales;
	private int otherSales;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getIsSync() {
		return isSync;
	}
	public void setIsSync(int isSync) {
		this.isSync = isSync;
	}
	public String getCrop() {
		return crop;
	}
	public void setCrop(String crop) {
		this.crop = crop;
	}
	public String getSalesDate() {
		return salesDate;
	}
	public void setSalesDate(String salesDate) {
		this.salesDate = salesDate;
	}
	public String getRetailerName() {
		return retailerName;
	}
	public void setRetailerName(String retailerName) {
		this.retailerName = retailerName;
	}
	public long getRetailerMobileNo() {
		return retailerMobileNo;
	}
	public void setRetailerMobileNo(long retailerMobileNo) {
		this.retailerMobileNo = retailerMobileNo;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public int getSeason() {
		return season;
	}
	public void setSeason(int season) {
		this.season = season;
	}
	public int getPioneerSales() {
		return pioneerSales;
	}
	public void setPioneerSales(int pioneerSales) {
		this.pioneerSales = pioneerSales;
	}
	public int getCompetitor1Sales() {
		return competitor1Sales;
	}
	public void setCompetitor1Sales(int competitor1Sales) {
		this.competitor1Sales = competitor1Sales;
	}
	public int getCompetitor2Sales() {
		return competitor2Sales;
	}
	public void setCompetitor2Sales(int competitor2Sales) {
		this.competitor2Sales = competitor2Sales;
	}
	public int getOtherSales() {
		return otherSales;
	}
	public void setOtherSales(int otherSales) {
		this.otherSales = otherSales;
	}
	
	 
}
