package com.activitytrack.services;

import android.app.IntentService;
import android.content.Intent;

import com.activitytrack.apiinterface.APIRequestHandler;
import com.activitytrack.apiinterface.ComonInterface;
import com.activitytrack.daos.UpLoadFilePravaktaDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.UpLoadPravaktaFileDTO;
import com.activitytrack.masterdtos.UploadResponse;
import com.activitytrack.utility.MyConstants;

import java.io.File;
import java.util.List;

import retrofit.RetrofitError;
import retrofit.mime.TypedFile;

/**
 * Created by yakaswamy on 12-3-2018.
 */

public class ATUpLoadFileService extends IntentService {
    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */
    public ATUpLoadFileService(String name) {
        super(name);
    }

    public ATUpLoadFileService() {
        super("UpLoad Service");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        initUpLoad();
    }

    private void initUpLoad() {
        List<DTO> uploadFilesList = UpLoadFilePravaktaDAO.getInstance().getRecords(DBHandler.getInstance(this).getDBObject(0));
        if (uploadFilesList != null && !uploadFilesList.isEmpty()) {
            final UpLoadPravaktaFileDTO dto = (UpLoadPravaktaFileDTO) uploadFilesList.get(0);
            TypedFile imageTypedFile = new TypedFile("multipart/form-data", new File(dto.getImageUrlPath().substring(7)));

            if (dto.getType().equals(MyConstants.VILLAGE_PROFILE_IMAGE_TYPE)) {

                APIRequestHandler.getInstance().uploadImageVillageProfSurvey(dto, imageTypedFile, new ComonInterface() {
                    @Override
                    public void onRequestSuccess(Object responseObj) {
                        if (responseObj instanceof UploadResponse) {
                            UploadResponse response = (UploadResponse) responseObj;
                            if (response.getCode() == 100) {
                                UpLoadFilePravaktaDAO.getInstance().delete(dto, DBHandler.getInstance(ATUpLoadFileService.this).getDBObject(1));
                                try {
                                    File file = new File(dto.getImageUrlPath().substring(7));
                                    boolean deleted = file.delete();

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                //DialogManager.showToast(UpLoadFileService.this, response.getMessage());
                            }
                        }
                        initUpLoad();
                    }

                    @Override
                    public void onRequestFailure(RetrofitError errorCode) {
                        initUpLoad();
                    }
                });

            } else if (dto.getType().equals(MyConstants.FARMER_SEGMENTATION_IMAGE_TYPE) ||
                    dto.getType().equals(MyConstants.NESTLE_IMAGE_TYPE) ||
                    dto.getType().equals(MyConstants.FARMER_SEGMENTATION__RICE_IMAGE_TYPE)) {

                APIRequestHandler.getInstance().uploadImageFarmerSegmentation(dto, imageTypedFile, new ComonInterface() {
                    @Override
                    public void onRequestSuccess(Object responseObj) {
                        if (responseObj instanceof UploadResponse) {
                            UploadResponse response = (UploadResponse) responseObj;
                            if (response.getCode() == 100) {
                                UpLoadFilePravaktaDAO.getInstance().delete(dto, DBHandler.getInstance(ATUpLoadFileService.this).getDBObject(1));
                                try {
                                    File file = new File(dto.getImageUrlPath().substring(7));
                                    boolean deleted = file.delete();

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                //DialogManager.showToast(UpLoadFileService.this, response.getMessage());
                            }
                        }
                        initUpLoad();
                    }

                    @Override
                    public void onRequestFailure(RetrofitError errorCode) {
                        initUpLoad();
                    }
                });

            } else {

                APIRequestHandler.getInstance().uploadImage(dto, imageTypedFile, new ComonInterface() {
                    @Override
                    public void onRequestSuccess(Object responseObj) {
                        if (responseObj instanceof UploadResponse) {
                            UploadResponse response = (UploadResponse) responseObj;
                            if (response.getCode() == 100) {
                                UpLoadFilePravaktaDAO.getInstance().delete(dto, DBHandler.getInstance(ATUpLoadFileService.this).getDBObject(1));
                                try {
                                    File file = new File(dto.getImageUrlPath().substring(7));
                                    boolean deleted = file.delete();

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                //DialogManager.showToast(UpLoadFileService.this, response.getMessage());
                            }
                        }
                        initUpLoad();
                    }

                    @Override
                    public void onRequestFailure(RetrofitError errorCode) {
                        initUpLoad();
                    }
                });
            }


        } else {
            //Stop intent service
            //DialogManager.showToast(DownloadFileService.this, "Stopped intent service");
        }
    }
}