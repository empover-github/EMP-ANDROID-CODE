package com.activitytrack.models;

import com.activitytrack.dtos.DTO;

/**
 * Created by hareesh.a on 4/19/2018.
 */

public class IdNameModel implements DTO {
    private long id;
    private String name;
    private String status;
    private String lastUpdatedOn;
    private String seasonId;
    private long devCenterId;

    private int i;

    public IdNameModel() {

    }

    public IdNameModel(String name) {
        this.name = name;
    }

    public IdNameModel(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getDevCenterId() {
        return devCenterId;
    }

    public void setDevCenterId(long devCenterId) {
        this.devCenterId = devCenterId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastUpdatedOn() {
        return lastUpdatedOn;
    }

    public void setLastUpdatedOn(String lastUpdatedOn) {
        this.lastUpdatedOn = lastUpdatedOn;
    }

    public String getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(String seasonId) {
        this.seasonId = seasonId;
    }
}
