package com.activitytrack.activity;

import android.graphics.Rect;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.activitytrack.adapter.ATHomeAdapter;
import com.activitytrack.listeners.OnListItemClickListener;
import com.activitytrack.models.IconItems;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;

public class ATHomeFragment extends BaseFragment implements View.OnClickListener, OnListItemClickListener {

    private View rootView;
    RecyclerView rlAllProducts;
    private GridLayoutManager equipmentGridlayout;
    private ATHomeAdapter equipmentAdapter;
    private LinearLayout mainLayout;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.at_home_fragment, container, false);
        mainLayout = (LinearLayout) rootView.findViewById(R.id.at_home_mainlayout);
        setHasOptionsMenu(true);
        setTheme();
        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        rlAllProducts = (RecyclerView) rootView.findViewById(R.id.at_home_recycle);
        int[] imageArray = null;

        ArrayList<IconItems> data = new ArrayList<>();

        data.add(new IconItems(getString(R.string.dashboards), R.drawable.dashboards));
        data.add(new IconItems(getString(R.string.village_profile), R.drawable.village_profile));
        data.add(new IconItems(getString(R.string.pravakta_ha_ga), R.drawable.pravakta_ha_gain));
        data.add(new IconItems(getString(R.string.dipstick), R.drawable.dipstick_tile));
        if (Utility.getShowFarmerSegmention(mActivity))
            data.add(new IconItems(getString(R.string.silage_farmer), R.drawable.img_farmer_segmentation));
        data.add(new IconItems(getString(R.string.data_sync), R.drawable.data_sync));
        data.add(new IconItems(getString(R.string.attendanceCode), R.drawable.attendance_code));
        data.add(new IconItems(getString(R.string.yield_calcul), R.drawable.yield_calculator));
        data.add(new IconItems(getString(R.string.change_theme), R.drawable.change_theme));

        equipmentGridlayout = new GridLayoutManager(getActivity(), 3);
        rlAllProducts.setHasFixedSize(true);
        rlAllProducts.setLayoutManager(equipmentGridlayout);
        /*int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.margin2);
        rlAllProducts.addItemDecoration(new SpacesItemDecoration(spacingInPixels));*/
        equipmentAdapter = new ATHomeAdapter(getActivity(), data, this);
        rlAllProducts.setAdapter(equipmentAdapter);
        rlAllProducts.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    private void setTheme() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }
    }

    @Override
    public void onItemClick(View view, int position) {
        int i = view.getId();
        if (i == R.id.at_layoutimage) {
            navToFragment(position, view);

        }
    }

    public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
        private int space;

        public SpacesItemDecoration(int space) {
            this.space = space;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view,
                                   RecyclerView parent, RecyclerView.State state) {
            outRect.left = space;
            outRect.right = space;
            outRect.bottom = space;

            // Add top margin only for the first item to avoid double space between items
            if (parent.getChildLayoutPosition(view) == 0) {
                outRect.top = space;
            } else {
                outRect.top = space;
            }
        }
    }

    private void navToFragment(int position, View view) {
        IconItems iconItems = (IconItems) view.getTag();
        if (iconItems.getTitle().equals(getString(R.string.home))) {
            mActivity.displayView(1);
        } else if (iconItems.getTitle().equals(getString(R.string.dashboards))) {
            mActivity.displayView(2);
        } else if (iconItems.getTitle().equals(getString(R.string.village_profile))) {
            mActivity.displayView(3);

        } else if (iconItems.getTitle().equals(getString(R.string.pravakta_ha_ga))) {
            mActivity.displayView(4);

        } else if (iconItems.getTitle().equals(getString(R.string.dipstick))) {
            mActivity.displayView(5);

        } else if (iconItems.getTitle().equals(getString(R.string.attendanceCode))) {
            mActivity.displayView(6);

        } else if (iconItems.getTitle().equals(getString(R.string.yield_calcul))) {
            mActivity.displayView(7);

        } else if (iconItems.getTitle().equals(getString(R.string.data_sync))) {
            mActivity.displayView(8);

        } else if (iconItems.getTitle().equals(getString(R.string.change_theme))) {
            mActivity.displayView(9);
        }else if (iconItems.getTitle().equals(getString(R.string.silage_farmer))) {
            mActivity.displayView(10);
        }
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        return false;
    }
}
