package com.activitytrack.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.activitytrack.daos.AgronomyActivityDAO;
import com.activitytrack.daos.AgronomySummaryDAO;
import com.activitytrack.daos.CompanyMasterDAO;
import com.activitytrack.daos.DemandSummaryDAO;
import com.activitytrack.daos.DipstickDAO;
import com.activitytrack.daos.FSMasterDivisionDAO;
import com.activitytrack.daos.FarmerSchoolSilageDAO;
import com.activitytrack.daos.FarmerSegmentationDAO;
import com.activitytrack.daos.FarmerSegmentationRiceDAO;
import com.activitytrack.daos.GerminationListDAO;
import com.activitytrack.daos.LiquidationTrackingDAO;
import com.activitytrack.daos.MdrProfileDAO;
import com.activitytrack.daos.OSAActivityDAO;
import com.activitytrack.daos.PDAActivityDAO;
import com.activitytrack.daos.PSAActivityDAO;
import com.activitytrack.daos.PravaktaHaAgainDAO;
import com.activitytrack.daos.ResearchCompanyMasterDAO;
import com.activitytrack.daos.SegmentationCropDAO;
import com.activitytrack.daos.SegmentationGrainHybridDAO;
import com.activitytrack.daos.SegmentationGrainServicesDAO;
import com.activitytrack.daos.SegmentationRiceHybridDAO;
import com.activitytrack.daos.SegmentationRiceServicesDAO;
import com.activitytrack.daos.SegmentationSchoolDAO;
import com.activitytrack.daos.SegmentationSeasonDAO;
import com.activitytrack.daos.SegmentationSilageHybridDAO;
import com.activitytrack.daos.SegmentationSilageServicesDAO;
import com.activitytrack.daos.SegmentationYearDAO;
import com.activitytrack.daos.ThreeIDAO;
import com.activitytrack.daos.UpLoadFilePravaktaDAO;
import com.activitytrack.daos.UploadedVillageListDAO;
import com.activitytrack.daos.VillageProfileDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.AgronomyActivityDTO;
import com.activitytrack.dtos.AgronomySummaryDTO;
import com.activitytrack.dtos.CompanyMasterDTO;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.DemandSummaryDTO;
import com.activitytrack.dtos.DipstickDTO;
import com.activitytrack.dtos.FarmerSchoolSilageDTO;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.dtos.MdrProfileDTO;
import com.activitytrack.dtos.OSAActivityDTO;
import com.activitytrack.dtos.PDAActivityDTO;
import com.activitytrack.dtos.PSAActivityDTO;
import com.activitytrack.dtos.PravaktaHaGainDTO;
import com.activitytrack.dtos.SegmentationRequestDTO;
import com.activitytrack.dtos.ThreeIDTO;
import com.activitytrack.dtos.UpLoadPravaktaFileDTO;
import com.activitytrack.dtos.UploadedVillageListDTO;
import com.activitytrack.dtos.VillageProfileDTO;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdaos.DipstickMasterDAO;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.OtherCropMasterDAO;
import com.activitytrack.masterdaos.RetailerMasterDAO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdaos.SeasonMasterDAO;
import com.activitytrack.masterdaos.SegmentMasterDAO;
import com.activitytrack.masterdaos.TargetAgronomyDAO;
import com.activitytrack.masterdaos.TargetDemandOSADAO;
import com.activitytrack.masterdaos.TargetDemandPDADAO;
import com.activitytrack.masterdaos.TargetDemandPSADAO;
import com.activitytrack.masterdaos.Top3HybridsDAO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.masterdtos.DownloadMasterDTO;
import com.activitytrack.masterdtos.HybridMasterDTO;
import com.activitytrack.masterdtos.MasterDataDTO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.masterdtos.OtherCropMasterDTO;
import com.activitytrack.masterdtos.RetailerMasterDTO;
import com.activitytrack.masterdtos.SeasonCalendarDTO;
import com.activitytrack.masterdtos.SeasonMasterDTO;
import com.activitytrack.masterdtos.SegmentMasterDTO;
import com.activitytrack.masterdtos.TargetAgronomyDTO;
import com.activitytrack.masterdtos.TargetDemandOSADTO;
import com.activitytrack.masterdtos.TargetDemandPDADTO;
import com.activitytrack.masterdtos.TargetDemandPSADTO;
import com.activitytrack.masterdtos.Top3HybridsDTO;
import com.activitytrack.masterdtos.UploadResponse;
import com.activitytrack.models.IdNameModel;
import com.activitytrack.models.SegmentationMasterDataModel;
import com.activitytrack.services.ATUpLoadFileService;
import com.activitytrack.services.ATUpLoadFileServiceNewJob;
import com.activitytrack.transdtos.ActivitiesTransDTO;
import com.activitytrack.transdtos.TransMainDTO;
import com.activitytrack.transdtos.UploadDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.List;

public class DataSyncFragment extends BaseFragment {

    private View view;
    private ImageView imgDataUpload;
    private ImageView imgDataDownLoad;
    private LinearLayout mainLayout;
    private TextView tvDataUpload;
    private TextView tvDataDownLoad;
    private TextView tvDataUploadDate;
    private TextView tvDataDownLoadDate;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.datasync_fragment, container, false);
        imgDataDownLoad = (ImageView) view.findViewById(R.id.ds_dataDownload);
        imgDataUpload = (ImageView) view.findViewById(R.id.ds_dataUpload);
        tvDataDownLoad = (TextView) view.findViewById(R.id.ds_dataDownload_l);
        tvDataUpload = (TextView) view.findViewById(R.id.ds_dataUpload_l);
        tvDataDownLoadDate = (TextView) view.findViewById(R.id.ds_dataDownload_date);
        tvDataUploadDate = (TextView) view.findViewById(R.id.ds_dataUpload_date);

        mainLayout = (LinearLayout) view.findViewById(R.id.ds_bg_laylout);

        setChange();

        updateDateAndStatus();

        setDownloadColor();

        imgDataUpload.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (Utility.isDataPending(mActivity)) {
                    if (Utility.networkAvailability(mActivity)) {
                        UploadDTO data = generateUploadData();
                        Gson gson = new Gson();
                        UploadAsync async = new UploadAsync(mActivity, gson.toJson(data));
                        async.execute(MyConstants.AppURL + MyConstants.MDR_TRANSACTION);
                    } else {
                        Utility.showAlert(mActivity, "", getResources().getString(R.string.checkNetwork));
                    }
                } else {
                    Utility.showAlert(mActivity, "", getResources().getString(R.string.notavilableUpload));
                }

            }
        });


        imgDataDownLoad.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (Utility.isDataPending(mActivity)) {
                    Utility.showAlert(mActivity, "", "Upload data first then download");
                    return;
                }
                if (Utility.networkAvailability(mActivity)) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        List<DTO> userDtoList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
                        if (userDtoList != null && userDtoList.size() > 0) {
                            MdrMasterDTO loginDTO = (MdrMasterDTO) userDtoList.get(0);
                            jsonObject.put("loginId", loginDTO.getLoginId());
                            jsonObject.put("versionNo", ATMainActivity.versionCode);

                            DownloadAsync async = new DownloadAsync(jsonObject.toString(), mActivity);
                            async.execute(MyConstants.AppURL + MyConstants.MASTER_DATA);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    Utility.showAlert(mActivity, "", getResources().getString(R.string.checkNetwork));
                }
            }
        });
        return view;
    }

    private void updateDateAndStatus() {

        if (Utility.getLastUploadDate(mActivity) != null) {
            tvDataUploadDate.setText(Utility.getLastUploadDate(mActivity));
        } else {
            tvDataUploadDate.setText(Utility.getCurrentDateAndTime());
        }

        if (Utility.getLastDownloadDate(mActivity) != null) {
            tvDataDownLoadDate.setText(Utility.getLastDownloadDate(mActivity));
        } else {
            tvDataDownLoadDate.setText(Utility.getCurrentDateAndTime());
        }

        if (Utility.isDataPending(mActivity)) {
            imgDataUpload.setImageResource(R.drawable.data_upload_icon);
            tvDataUpload.setTextColor(Color.parseColor("#f00606"));
            tvDataUploadDate.setTextColor(Color.parseColor("#f00606"));
            imgDataUpload.setEnabled(true);
        } else {
            imgDataUpload.setImageResource(R.drawable.data_upload_icon_f);
            tvDataUpload.setTextColor(Color.parseColor("#427730"));
            tvDataUploadDate.setTextColor(Color.parseColor("#427730"));
            imgDataUpload.setEnabled(false);
        }
    }

    private void setDownloadColor() {
        if (Utility.getDataDownloadReq(mActivity)) {
            imgDataDownLoad.setImageResource(R.drawable.data_download_icon);
            tvDataDownLoad.setTextColor(Color.parseColor("#f00606"));
            tvDataDownLoadDate.setTextColor(Color.parseColor("#f00606"));
        } else {
            imgDataDownLoad.setImageResource(R.drawable.data_download_icon_f);
            tvDataDownLoad.setTextColor(Color.parseColor("#427730"));
            tvDataDownLoadDate.setTextColor(Color.parseColor("#427730"));
        }
    }

    private void setChange() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }
    }

    private class UploadAsync extends AsyncTask<String, Void, String> {

        String jsonData;
        Context context;
        ProgressDialog dlg;

        public UploadAsync(Context context, String data) {
            this.context = context;
            jsonData = data;
            System.out.println("transaction Data : " + data);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dlg = new ProgressDialog(context);
            dlg.setCanceledOnTouchOutside(false);
            dlg.setCancelable(false);
            dlg.setMessage(context.getResources().getString(
                    R.string.progress_pleaseWait));
            dlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpClient = null;
            try {
                HttpParams httpParams = new BasicHttpParams();
                int connectionTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                int socketTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                HttpConnectionParams.setConnectionTimeout(httpParams, connectionTimeout);
                HttpConnectionParams.setSoTimeout(httpParams, socketTimeout);
                httpClient = new DefaultHttpClient(httpParams);

                HttpPost httpPost = new HttpPost(params[0]);
                ATBuildLog.i("url", "url :" + params[0]);

                // httpPost.addHeader("Content-Type",
                // "multipart/mixed;boundary=xxBOUNDARYxx");
                ATBuildLog.i("LoginAsync", "request data :" + jsonData);

                StringEntity stringEntity = new StringEntity(jsonData);
                httpPost.setEntity(stringEntity);


				/*MultipartEntity entity = new MultipartEntity();
                entity.addPart("jsonData", new StringBody(jsonData));
				for (String string : imageNamesList) {
					File mypath = new File(string);
					if (mypath != null) {
						entity.addPart("file", new FileBody(mypath));
					}
				}
				httpPost.setEntity(entity);*/
                ATBuildLog.i("url", "url :" + httpPost.getURI());
                HttpResponse response = httpClient.execute(httpPost);
                HttpEntity httpEntity = response.getEntity();
                InputStream instream = httpEntity.getContent();
                String responseStr = Utility.convertStreamToString(instream);
                return responseStr;
            } catch (Exception exception) {
                exception.printStackTrace();
            } finally {
                if (httpClient != null)
                    httpClient.getConnectionManager().shutdown();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && !result.isEmpty()) {
                if (!Utility.isJSONValid(result)) {
                    if (dlg != null) {
                        dlg.dismiss();
                    }
                    Utility.showAlert(context, "", getResources().getString(R.string.ntjson));
                } else {
                    UploadResponse uploadResponse = new Gson().fromJson(result, UploadResponse.class);

                    if (uploadResponse.getCode() == 100) {
                        boolean dataDownloadRequired = uploadResponse.isDataDownloadRequired();
                        if (dataDownloadRequired) {
                            Utility.setDataDownloadReq(true, mActivity);
                        }
                        setDownloadColor();

                        Utility.setLastUploadDate(Utility.getCurrentDateAndTime(), context);
                        Utility.setNoOfProfilesUploadedByMdr("" + uploadResponse.getVillageProfileCount(), context); // TARA
                        Gson gson = new Gson();
                        UploadDTO uploadobj = gson.fromJson(jsonData, UploadDTO.class);
                        TransMainDTO uploadDto = uploadobj.getData();

                        List<AgronomyActivityDTO> agList = uploadDto.getAgronomies();
                        if (agList != null && agList.size() > 0) {
                            for (AgronomyActivityDTO dto : agList) {
                                dto.setUploadedDate(Utility.getCurrentformatedDate());
                                dto.setIsSync(0);
                                AgronomyActivityDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        List<MdrProfileDTO> mdrList = uploadDto.getMdrProfile();
                        if (mdrList != null && mdrList.size() > 0) {
                            for (MdrProfileDTO dto : mdrList) {
                                dto.setUploadedDate(Utility.getCurrentformatedDate());
                                dto.setIsSync(0);
                                MdrProfileDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        // TARA
                        List<VillageProfileDTO> villageList = uploadDto.getVillageProfiles();
                        if (villageList != null && villageList.size() > 0) {
                            for (VillageProfileDTO dto : villageList) {
                                dto.setUploadedDate(Utility.getCurrentformatedDate());
                                dto.setIsSync(0);
                                VillageProfileDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        List<ThreeIDTO> threeList = uploadDto.getThreeI();
                        if (threeList != null && threeList.size() > 0) {
                            for (ThreeIDTO dto : threeList) {
                                dto.setUploadedDate(Utility.getCurrentformatedDate());
                                dto.setIsSync(0);
                                ThreeIDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        List<ActivitiesTransDTO> pdaList = uploadDto.getPdaActivities();
                        if (pdaList != null && pdaList.size() > 0) {
                            for (ActivitiesTransDTO dto : pdaList) {
                                PDAActivityDTO activityDTO = new PDAActivityDTO();
                                activityDTO.setUploadedDate(Utility.getCurrentformatedDate());
                                activityDTO.setIsSync(0);
                                activityDTO.setId(dto.getId());
                                PDAActivityDAO.getInstance().update(activityDTO, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }


                        List<ActivitiesTransDTO> osaList = uploadDto.getOsaActivities();
                        if (osaList != null && osaList.size() > 0) {
                            for (ActivitiesTransDTO dto : osaList) {
                                OSAActivityDTO activityDTO = new OSAActivityDTO();
                                activityDTO.setUploadedDate(Utility.getCurrentformatedDate());
                                activityDTO.setIsSync(0);
                                activityDTO.setId(dto.getId());
                                OSAActivityDAO.getInstance().update(activityDTO, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        List<ActivitiesTransDTO> psaList = uploadDto.getPsaActivities();
                        if (psaList != null && psaList.size() > 0) {
                            for (ActivitiesTransDTO dto : psaList) {
                                PSAActivityDTO activityDTO = new PSAActivityDTO();
                                activityDTO.setUploadedDate(Utility.getCurrentformatedDate());
                                activityDTO.setIsSync(0);
                                activityDTO.setId(dto.getId());
                                PSAActivityDAO.getInstance().update(activityDTO, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        //To Do
                        //Update db record
                        List<SegmentationRequestDTO> segmentationList = uploadDto.getFarmerSegmentationTransactionDataList();
                        if (segmentationList != null && segmentationList.size() > 0) {
                            for (SegmentationRequestDTO dto : segmentationList) {
                                dto.setId(dto.getMobileId());
                                dto.setDate(Utility.getCurrentformatedDate());
                                dto.setIsSync(0);
                                FarmerSegmentationDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));

                                //newly added rams
                                FarmerSegmentationRiceDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        List<DipstickDTO> dipstickList = uploadDto.getDipsticks();
                        if (dipstickList != null && dipstickList.size() > 0) {
                            for (DipstickDTO dto : dipstickList) {
                                long effectedRow = DipstickMasterDAO.getInstance().insertActivity(dto, DBHandler.getInstance(mActivity).getDBObject(1));
                                if (effectedRow > 0)
                                    DipstickDAO.getInstance().deleteDataById(String.valueOf(dto.getId()), DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        List<PravaktaHaGainDTO> pravaktaHaGainDTOS = uploadDto.getPravaktaVillageHaGains();
                        if (pravaktaHaGainDTOS != null && pravaktaHaGainDTOS.size() > 0) {
                            for (PravaktaHaGainDTO dto : pravaktaHaGainDTOS) {
                                PravaktaHaAgainDAO.getInstance().deleteDataById(String.valueOf(dto.getId()), DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        //Insert images pending image into temp database to upload
                        List<UpLoadPravaktaFileDTO> pravaktaResModels = uploadResponse.getPravaktaVillageHaGainResponse();

                        if (pravaktaResModels != null && !pravaktaResModels.isEmpty()) {
                            for (UpLoadPravaktaFileDTO model : pravaktaResModels) {
                                if (Utility.isValidStr(model.getImageUrlPath()))
                                    UpLoadFilePravaktaDAO.getInstance().insert(model, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        // insert village profile survey images into temp database to upload
                        List<UpLoadPravaktaFileDTO> villageProf_surveyList = uploadResponse.getVillageProfileResponse();
                        if (villageProf_surveyList != null && !villageProf_surveyList.isEmpty()) {
                            for (UpLoadPravaktaFileDTO model : villageProf_surveyList) {
                                if (Utility.isValidStr(model.getImageUrlPath()))
                                    UpLoadFilePravaktaDAO.getInstance().insert(model, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }

                        // insert farmer segmentation images into temp database to upload
                        List<UpLoadPravaktaFileDTO> farmerSegmentationList = uploadResponse.getFarmerSegmentationResponse();
                        if (farmerSegmentationList != null && !farmerSegmentationList.isEmpty()) {
                            for (UpLoadPravaktaFileDTO model : farmerSegmentationList) {
                                if (Utility.isValidStr(model.getImageUrlPath()))
                                    UpLoadFilePravaktaDAO.getInstance().insert(model, DBHandler.getInstance(mActivity).getDBObject(1));
                            }
                        }


                        List<GerminationverificationListDTO> germinationList = uploadResponse.getGerminationPendingVerificationList();
                        if (germinationList != null) {
                            GerminationListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            for (GerminationverificationListDTO germinationDto : germinationList) {
                                GerminationListDAO.getInstance().insertActivity(germinationDto, DBHandler.getInstance(context).getDBObject(1));
                            }
                        }


                        FarmerSchoolSilageDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1)); // as nothing to maintin in Local DB so delete full table Data

                        startUpLoadService();

                        //Update UI
                        updateDateAndStatus();

                        if (dlg != null) {
                            dlg.dismiss();
                        }
                        Utility.showAlert(context, "", "Successfully Uploaded");
                    } else if (uploadResponse.getCode() == 101) {
                        if (dlg != null) {
                            dlg.dismiss();
                        }
                        Utility.showAlert(context, "", MyConstants.RES101MSG);
                    } else if (uploadResponse.getCode() == 102) {
                        if (dlg != null) {
                            dlg.dismiss();
                        }
                        Utility.showAlert(context, "", MyConstants.RES102MSG);
                    } else if (uploadResponse.getCode() == 103) {
                        if (dlg != null) {
                            dlg.dismiss();
                        }
                        Utility.showAlert(context, "", MyConstants.RES103MSG);
                    } else if (uploadResponse.getCode() == 104) {
                        if (dlg != null) {
                            dlg.dismiss();
                        }
                        Utility.showAlert(context, "", MyConstants.RES104MSG);
                    } else if (uploadResponse.getCode() == 302) {
                        if (dlg != null) {
                            dlg.dismiss();
                        }
                        Utility.showAlert(context, "", "This user is registered with other device\nyou cannot upload from this device");
                    } else {
                        if (dlg != null) {
                            dlg.dismiss();
                        }
                        if (Utility.isValidStr(uploadResponse.getMessage()))
                            Utility.showAlert(context, getString(R.string.alert), uploadResponse.getMessage());
                    }

                }
            } else {
                if (dlg != null) {
                    dlg.dismiss();
                }
                Utility.showAlert(context, "", getResources().getString(R.string.networkProblem));
            }

            if (dlg != null) {
                dlg.dismiss();
            }
        }
    }

    //Dummy
    private void startUpLoadService() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O){

            if (!Utility.isMyServiceRunning(mActivity, "com.activitytrack.services.ATUpLoadFileServiceNewJob")) {
                Intent intent = new Intent(mActivity, ATUpLoadFileServiceNewJob.class);
                ATUpLoadFileServiceNewJob.enqueueWork(mActivity,intent);
            }

        }else{

            if (!Utility.isMyServiceRunning(mActivity, "com.activitytrack.services.ATUpLoadFileService")) {
                Intent intent = new Intent(mActivity, ATUpLoadFileService.class);
                mActivity.startService(intent);
            }
        }
    }

    private UploadDTO generateUploadData() {
        UploadDTO transactionData = new UploadDTO();
        TransMainDTO data = new TransMainDTO();

        List<DTO> userDtoList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));


        if (userDtoList != null && userDtoList.size() > 0) {
            MdrMasterDTO loginDTO = (MdrMasterDTO) userDtoList.get(0);
            data.setMdrId(loginDTO.getId());
        }

        data.setVersionNo(ATMainActivity.versionCode);

        data.setAgronomies(AgronomyActivityDAO.getInstance().getRecordsForUpload(DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setLiquidations(LiquidationTrackingDAO.getInstance().getRecordsForUpload(DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setMdrProfile(MdrProfileDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setVillageProfiles(VillageProfileDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0))); // TARA
        data.setThreeI(ThreeIDAO.getInstance().getRecordsForUpload(DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setPdaActivities(PDAActivityDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setOsaActivities(OSAActivityDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setPsaActivities(PSAActivityDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setDeviceId(Utility.getDeviceId(mActivity));
        data.setDipsticks(DipstickDAO.getInstance().getRecordsForUpload(DBHandler.getInstance(mActivity).getDBObject(0)));
        // newly added
        data.setPravaktaVillageHaGains(PravaktaHaAgainDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0)));
        data.setGerminationVerifiedList(GerminationListDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0)));

        List<SegmentationRequestDTO> farmerCornList = FarmerSegmentationDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0));
        List<SegmentationRequestDTO> farmerRiceList = FarmerSegmentationRiceDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0));
        farmerCornList.addAll(farmerRiceList);
        data.setFarmerSegmentationTransactionDataList(farmerCornList);

        List<FarmerSchoolSilageDTO> nestleData = FarmerSchoolSilageDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0));
        data.setFarmerSegmentationDairyDevList(nestleData);

        transactionData.setData(data);

        return transactionData;
    }

    public class DownloadAsync extends AsyncTask<String, Void, String> {
        String jsonData;
        Context context;
        ProgressDialog dlg;

        public DownloadAsync(String inputJSON, Context context) {
            jsonData = inputJSON;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dlg = new ProgressDialog(context);
            dlg.setCanceledOnTouchOutside(false);
            dlg.setCancelable(false);
            dlg.setMessage(context.getResources().getString(R.string.progress_pleaseWait));
            dlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpClient = null;
            try {
                HttpParams httpParams = new BasicHttpParams();
                int connectionTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                int socketTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                HttpConnectionParams.setConnectionTimeout(httpParams, connectionTimeout);
                HttpConnectionParams.setSoTimeout(httpParams, socketTimeout);
                httpClient = new DefaultHttpClient(httpParams);
                HttpPost httpPost = new HttpPost(params[0]);
                ATBuildLog.i("LoginAsync", "request data :" + jsonData);
                StringEntity stringEntity = new StringEntity(jsonData);
                httpPost.setEntity(stringEntity);
                HttpResponse response = httpClient.execute(httpPost);
                HttpEntity httpEntity = response.getEntity();
                InputStream instream = httpEntity.getContent();
                return Utility.convertStreamToString(instream);
            } catch (Exception exception) {
                exception.printStackTrace();
            } finally {
                if (httpClient != null)
                    httpClient.getConnectionManager().shutdown();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && !result.isEmpty()) {
                if (!Utility.isJSONValid(result)) {
                    Utility.showAlert(context, "", getResources().getString(R.string.ntjson));
                } else {

                    try {

                        System.out.println("master Data : " + result);

                        Gson gson = new Gson();
                        DownloadMasterDTO obj = gson.fromJson(result, DownloadMasterDTO.class);


                        if (obj.getCode() == 100) {
                            //setting data download req
                            Utility.setDataDownloadReq(false, mActivity);

                            setDownloadColor();

                            MasterDataDTO mainDTO = obj.getData();

                            CropMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            HybridMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            OtherCropMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SeasonCalendarDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            MdrMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            RetailerMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetDemandPDADAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetDemandOSADAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetDemandPSADAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetAgronomyDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            Top3HybridsDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            DemandSummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SeasonMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            DipstickMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            CompanyMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            ResearchCompanyMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));

                            SegmentationSeasonDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationCropDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationYearDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            FSMasterDivisionDAO.getInstance().deleteTableData(DBHandler.getInstance(mActivity).getDBObject(1));
                            SegmentationSchoolDAO.getInstance().deleteTableData(DBHandler.getInstance(mActivity).getDBObject(1));
                            SegmentationGrainHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationSilageHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationGrainServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationSilageServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
//                            GerminationListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            // Germination Verfication
                            //newly added
                            SegmentationRiceHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationRiceServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));

                            Utility.setNoOfProfilesUploadedByMdr("" + mainDTO.getVillageProfileCount(), context); // TARA

                            List<CropMasterDTO> cropList = mainDTO.getCropMaster();
                            if (cropList != null)
                                for (CropMasterDTO cropMasterDTO : cropList) {
                                    CropMasterDAO.getInstance().insert(cropMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            List<HybridMasterDTO> hybridList = mainDTO.getHybridMaster();
                            if (hybridList != null)
                                for (HybridMasterDTO hybridMasterDTO : hybridList) {
                                    HybridMasterDAO.getInstance().insert(hybridMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            List<OtherCropMasterDTO> otherCropList = mainDTO.getOtherCropMaster();
                            if (otherCropList != null)
                                for (OtherCropMasterDTO otherCropMasterDTO : otherCropList) {
                                    OtherCropMasterDAO.getInstance().insert(otherCropMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            List<SegmentMasterDTO> segmentList = mainDTO.getSegmentMaster();
                            if (segmentList != null)
                                for (SegmentMasterDTO segmentMasterDTO : segmentList) {
                                    SegmentMasterDAO.getInstance().insert(segmentMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            List<SeasonCalendarDTO> seasonList = mainDTO.getSeasonCalendar();
                            if (seasonList != null)
                                for (SeasonCalendarDTO seasonCalendarDTO : seasonList) {
                                    SeasonCalendarDAO.getInstance().insert(seasonCalendarDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<SeasonMasterDTO> seasonMasterList = mainDTO.getSeasonMaster();
                            if (seasonMasterList != null)
                                for (SeasonMasterDTO seasonCalendarDTO : seasonMasterList) {
                                    SeasonMasterDAO.getInstance().insert(seasonCalendarDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<MdrMasterDTO> mdrMasterList = mainDTO.getMdrMaster();
                            if (mdrMasterList != null)
                                for (MdrMasterDTO mdrMasterDTO : mdrMasterList) {
                                    MdrMasterDAO.getInstance().insert(mdrMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<RetailerMasterDTO> retailerMasterList = mainDTO.getRetailerMaster();
                            if (retailerMasterList != null)
                                for (RetailerMasterDTO mdrMasterDTO : retailerMasterList) {
                                    RetailerMasterDAO.getInstance().insert(mdrMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetDemandPDADTO> targetDemandPDAList = mainDTO.getTargetDemandPDA();
                            if (targetDemandPDAList != null)
                                for (TargetDemandPDADTO targetDemandDTO : targetDemandPDAList) {
                                    TargetDemandPDADAO.getInstance().insert(targetDemandDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetDemandOSADTO> targetDemandOSAList = mainDTO.getTargetDemandOSA();
                            if (targetDemandOSAList != null)
                                for (TargetDemandOSADTO targetDemandDTO : targetDemandOSAList) {
                                    TargetDemandOSADAO.getInstance().insert(targetDemandDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetDemandPSADTO> targetDemandPSAList = mainDTO.getTargetDemandPSA();
                            if (targetDemandPSAList != null)
                                for (TargetDemandPSADTO targetDemandDTO : targetDemandPSAList) {
                                    TargetDemandPSADAO.getInstance().insert(targetDemandDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetAgronomyDTO> targetAgronomyList = mainDTO.getTargetAgronomy();
                            if (targetAgronomyList != null)
                                for (TargetAgronomyDTO targetAgronomyDTO : targetAgronomyList) {
                                    TargetAgronomyDAO.getInstance().insert(targetAgronomyDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<Top3HybridsDTO> top3HybridsList = mainDTO.getTop3Hybrids();
                            if (top3HybridsList != null)
                                for (Top3HybridsDTO top3HybridsDTO : top3HybridsList) {
                                    Top3HybridsDAO.getInstance().insert(top3HybridsDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<DemandSummaryDTO> demList = mainDTO.getDemandsumary();
                            if (demList != null) {
                                DemandSummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                AgronomySummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (DemandSummaryDTO demandSummaryDTO : demList) {
                                    if (demandSummaryDTO.getActivityId() == MyConstants.ACTIVITY_AGR_ID) {
                                        AgronomySummaryDTO dto = new AgronomySummaryDTO();
                                        dto.setActivityCount(demandSummaryDTO.getSampleCount());
                                        dto.setCropId(demandSummaryDTO.getCropId());
                                        dto.setHybridId(demandSummaryDTO.getHybridId());
                                        dto.setSeasonCalendarId(demandSummaryDTO.getSeasonCalendarId());
                                        dto.setSeasonId(demandSummaryDTO.getSeasonId());
                                        AgronomySummaryDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    } else {
                                        DemandSummaryDAO.getInstance().insert(demandSummaryDTO, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                            }

                            List<AgronomySummaryDTO> agrList = mainDTO.getAgronomySummary();
                            if (agrList != null) {
                                AgronomySummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (AgronomySummaryDTO demandSummaryDTO : agrList) {
                                    AgronomySummaryDAO.getInstance().insert(demandSummaryDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            }


                            List<UploadedVillageListDTO> uploadedVillageList = mainDTO.getVillageProfileUploadedData();
                            if (uploadedVillageList != null) {
                                UploadedVillageListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (UploadedVillageListDTO uploadedVillageDTO : uploadedVillageList) {
                                    UploadedVillageListDAO.getInstance().insertActivity(uploadedVillageDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            }

                            List<DipstickDTO> dipsticksList = mainDTO.getDipsticks();
                            if (dipsticksList != null)
                                for (DipstickDTO dipstickDTO : dipsticksList) {
                                    DipstickMasterDAO.getInstance().insertActivity(dipstickDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<CompanyMasterDTO> companyList = mainDTO.getCompanyMaster();
                            if (companyList != null)
                                for (CompanyMasterDTO companyDTO : companyList) {
                                    CompanyMasterDAO.getInstance().insert(companyDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<CompanyMasterDTO> researchCompanyList = mainDTO.getResearchCompanyMaster();
                            if (researchCompanyList != null)
                                for (CompanyMasterDTO companyDTO : researchCompanyList) {
                                    ResearchCompanyMasterDAO.getInstance().insert(companyDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<GerminationverificationListDTO> germinationList = mainDTO.getGerminationPendingVerificationList();
                            if (germinationList != null) {
                                GerminationListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (GerminationverificationListDTO germinationDto : germinationList) {
                                    GerminationListDAO.getInstance().insertActivity(germinationDto, DBHandler.getInstance(context).getDBObject(1));
                                }
                            }

                            // Farmer Segmentation
                            Utility.setShowFarmerSegmention(mainDTO.isShowFarmerSegmentation(), context);
                            SegmentationMasterDataModel farmerSegmentation = mainDTO.getFarmerSegmentationMasterData();

                            if (farmerSegmentation != null) {
                                List<IdNameModel> segSeasonList = farmerSegmentation.getSeason();
                                if (segSeasonList != null) {
                                    for (IdNameModel dto : segSeasonList) {
                                        SegmentationSeasonDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> segCropList = farmerSegmentation.getCrop();
                                if (segCropList != null) {
                                    for (IdNameModel dto : segCropList) {
                                        SegmentationCropDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                                //New Added FS
                                List<IdNameModel> setDivisionList = farmerSegmentation.getDivisionList();
                                if (setDivisionList != null) {
                                    for (IdNameModel dto : setDivisionList) {
                                        FSMasterDivisionDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                                List<IdNameModel> setSchoolList = farmerSegmentation.getSchoolList();
                                if (setSchoolList != null) {
                                    for (IdNameModel dto : setSchoolList) {
                                        SegmentationSchoolDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                                List<IdNameModel> segYearList = farmerSegmentation.getYears();
                                if (segYearList != null) {
                                    for (IdNameModel dto : segYearList) {
                                        SegmentationYearDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> grainHybridList = farmerSegmentation.getGrainHybrid();
                                if (grainHybridList != null) {
                                    for (IdNameModel dto : grainHybridList) {
                                        SegmentationGrainHybridDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> silageHybridList = farmerSegmentation.getSilageHybrid();
                                if (silageHybridList != null) {
                                    for (IdNameModel dto : silageHybridList) {
                                        SegmentationSilageHybridDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> grainServicesList = farmerSegmentation.getGrainFarmerServicesList();
                                if (grainServicesList != null) {
                                    for (IdNameModel dto : grainServicesList) {
                                        SegmentationGrainServicesDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> silageServicesList = farmerSegmentation.getSilageFarmerServicesList();
                                if (silageServicesList != null) {
                                    for (IdNameModel dto : silageServicesList) {
                                        SegmentationSilageServicesDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                                //newly added
                                List<IdNameModel> riceHybridList = farmerSegmentation.getRiceHybrid();
                                if (riceHybridList != null) {
                                    for (IdNameModel dto : riceHybridList) {
                                        SegmentationRiceHybridDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> riceServicesList = farmerSegmentation.getRiceFarmerServicesList();
                                if (riceServicesList != null) {
                                    for (IdNameModel dto : riceServicesList) {
                                        SegmentationRiceServicesDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                            }

                            updateDateAndStatus();

                            if (dlg != null) {
                                dlg.dismiss();
                            }

                            Utility.setLastDownloadDate(Utility.getCurrentDateAndTime(), context);

                            Utility.showAlert(mActivity, "", "Successfully Downloaded");

                        } else if (obj.getCode() == 101) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES101MSG);
                        } else if (obj.getCode() == 102) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES102MSG);
                        } else if (obj.getCode() == 103) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES103MSG);
                        } else if (obj.getCode() == 104) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES104MSG);
                        } else if (obj.getCode() == 302) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", "This user is registered with other device\nyou cannot download from this device");
                        } else {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            if (Utility.isValidStr(obj.getMessage()))
                                Utility.showAlert(context, getString(R.string.alert), obj.getMessage());
                        }

                    } catch (IllegalStateException | JsonSyntaxException exception) {
                        exception.printStackTrace();
                    }
                }
            } else {
                Utility.showAlert(context, "", getResources().getString(R.string.networkProblem));
            }

            if (dlg != null) {
                dlg.dismiss();
            }
        }

    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        mActivity.onBackPressedCallBack(callbackCode);
        return true;
    }
}
 
