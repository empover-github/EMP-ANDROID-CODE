package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.MdrFarmerDTO;
import com.activitytrack.dtos.MdrProfileDTO;
import com.activitytrack.dtos.MdrSurveyDTO;
import com.activitytrack.dtos.NewMdrSurveyDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class MdrProfileDAO implements DAO {

    private final String TAG = "MdrP";
    private static MdrProfileDAO mdrProfileDAO;

    public static MdrProfileDAO getInstance() {
        if (mdrProfileDAO == null) {
            mdrProfileDAO = new MdrProfileDAO();
        }

        return mdrProfileDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM MDR_PROFILE where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    /*MDR_PROFILE
                    id
			    	  villageName
			    	  cropId
			    	  totalCropArea
			    	  pioneerShare
			    	  majorCompetitorName1
			    	  itsShare1
			    	  majorCompetitorName2
			          itsShare2
			    	  date
			    	  location
			    	  isSync
			    	  uploadedDate
			    	  regionId 
                     */
                    MdrProfileDTO dto = new MdrProfileDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setCropId(cursor.getLong(2));
                    dto.setTotalCropArea(cursor.getFloat(3));
                    dto.setPioneerShare(cursor.getFloat(4));
                    dto.setMajorCompetitorName1(cursor.getString(5));
                    dto.setItsShare1(cursor.getFloat(6));
                    dto.setMajorCompetitorName2(cursor.getString(7));
                    dto.setItsShare2(cursor.getFloat(8));
                    dto.setDate(cursor.getString(9));
                    dto.setLocation(cursor.getString(10));
                    dto.setIsSync(cursor.getInt(11));
                    dto.setUploadedDate(cursor.getString(12));
                    dto.setRegionId(cursor.getLong(13));
                    dto.setNumberOfFarmers(cursor.getInt(14));
                    dto.setPinCode(cursor.getString(15));
                    dto.setBlockName(cursor.getString(16));
                    dto.setSegment(cursor.getLong(17));
                    dto.setCropHa(cursor.getFloat(18));
                    dto.setPhiHa(cursor.getFloat(19));
                    dto.setMajorPHIHybrid1(cursor.getLong(20));
                    dto.setMajorPHIHybrid2(cursor.getLong(21));
                    dto.setMajorCompetitionHybrid1(cursor.getString(22));
                    dto.setMajorCompetitionHybrid2(cursor.getString(23));

                    pdaActivityInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }


    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM MDR_PROFILE ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    MdrProfileDTO dto = new MdrProfileDTO();


                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setCropId(cursor.getLong(2));
                    dto.setTotalCropArea(cursor.getFloat(3));
                    dto.setPioneerShare(cursor.getFloat(4));
                    dto.setMajorCompetitorName1(cursor.getString(5));
                    dto.setItsShare1(cursor.getFloat(6));
                    dto.setMajorCompetitorName2(cursor.getString(7));
                    dto.setItsShare2(cursor.getFloat(8));
                    dto.setDate(cursor.getString(9));
                    dto.setLocation(cursor.getString(10));
                    dto.setIsSync(cursor.getInt(11));
                    dto.setUploadedDate(cursor.getString(12));
                    dto.setNumberOfFarmers(cursor.getInt(14));
                    dto.setPinCode(cursor.getString(15));
                    dto.setBlockName(cursor.getString(16));
                    dto.setSegment(cursor.getLong(17));
                    dto.setCropHa(cursor.getFloat(18));
                    dto.setPhiHa(cursor.getFloat(19));
                    dto.setMajorPHIHybrid1(cursor.getLong(20));
                    dto.setMajorPHIHybrid2(cursor.getLong(21));
                    dto.setMajorCompetitionHybrid1(cursor.getString(22));
                    dto.setMajorCompetitionHybrid2(cursor.getString(23));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }


    public List<MdrProfileDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<MdrProfileDTO> pdaActivityInfo = new ArrayList<MdrProfileDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM MDR_PROFILE where isSync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    MdrProfileDTO dto = new MdrProfileDTO();


                    dto.setId(cursor.getLong(0));
                    dto.setVillageName(cursor.getString(1));
                    dto.setCropId(cursor.getLong(2));
                    dto.setTotalCropArea(cursor.getFloat(3));
                    dto.setPioneerShare(cursor.getFloat(4));
                    dto.setMajorCompetitorName1(cursor.getString(5));
                    dto.setItsShare1(cursor.getFloat(6));
                    dto.setMajorCompetitorName2(cursor.getString(7));
                    dto.setItsShare2(cursor.getFloat(8));
                    dto.setDate(cursor.getString(9));
                    dto.setLocation(cursor.getString(10));
                    dto.setIsSync(cursor.getInt(11));
                    dto.setUploadedDate(cursor.getString(12));
                    dto.setRegionId(cursor.getLong(13));
                    dto.setNumberOfFarmers(cursor.getInt(14));
                    dto.setPinCode(cursor.getString(15));
                    dto.setBlockName(cursor.getString(16));
                    dto.setSegment(cursor.getLong(17));
                    dto.setCropHa(cursor.getFloat(18));
                    dto.setPhiHa(cursor.getFloat(19));
                    dto.setMajorPHIHybrid1(cursor.getLong(20));
                    dto.setMajorPHIHybrid2(cursor.getLong(21));
                    dto.setMajorCompetitionHybrid1(cursor.getString(22));
                    dto.setMajorCompetitionHybrid2(cursor.getString(23));
                    List<MdrFarmerDTO> farmers = MdrFarmerDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setFarmers(farmers);
                    // TARA
                    dbObject = DBHandler.getInstance(context).getDBObject(0);
                    List<MdrSurveyDTO> surveys = MdrSurveyDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setSurveys(surveys);

                    dbObject = DBHandler.getInstance(context).getDBObject(0);
                    List<NewMdrSurveyDTO> surveysNew = NewMdrSurveyDAO.getInstance().getRecordsForUpload(cursor.getLong(0), dbObject);
                    dto.setSurveysNew(surveysNew);


                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override

    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;

    }


    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {


        try {
            MdrProfileDTO dto = (MdrProfileDTO) dtoObject;

            ContentValues cValues = new ContentValues();
            /*MDR_PROFILE
            id
	    	  villageName
	    	  cropId
	    	  totalCropArea
	    	  pioneerShare
	    	  majorCompetitorName1
	    	  itsShare1
	    	  majorCompetitorName2
	          itsShare2
	    	  date
	    	  location
	    	  isSync
	    	  uploadedDate 
	    	  regionId
             */
            cValues.put("villageName", dto.getVillageName());
            cValues.put("cropId", dto.getCropId());
            cValues.put("totalCropArea", dto.getTotalCropArea());
            cValues.put("pioneerShare", dto.getPioneerShare());
            cValues.put("majorCompetitorName1", dto.getMajorCompetitorName1());
            cValues.put("itsShare1", dto.getItsShare1());
            cValues.put("majorCompetitorName2", dto.getMajorCompetitorName2());
            cValues.put("itsShare2", dto.getItsShare2());
            cValues.put("date", dto.getDate());
            cValues.put("location", dto.getLocation());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("uploadedDate", dto.getUploadedDate());
            cValues.put("regionId", dto.getRegionId());
            cValues.put("numberOfFarmers", dto.getNumberOfFarmers());
            cValues.put("pinCode", dto.getPinCode());
            cValues.put("blockName", dto.getBlockName());
            cValues.put("segment", dto.getSegment());
            cValues.put("cropHa", dto.getCropHa());
            cValues.put("phiHa", dto.getPhiHa());
            cValues.put("majorPHIHybrid1", dto.getMajorPHIHybrid1());
            cValues.put("majorPHIHybrid2", dto.getMajorPHIHybrid2());
            cValues.put("majorCompetitionHybrid1", dto.getMajorCompetitionHybrid1());
            cValues.put("majorCompetitionHybrid2", dto.getMajorCompetitionHybrid2());
            long insertedRow = dbObject.insert("MDR_PROFILE", null, cValues);
            if (insertedRow > 0) {
                Cursor cursor = dbObject.rawQuery("SELECT MAX(id) FROM  MDR_PROFILE", null);
                if (cursor.getCount() > 0) {

                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            MdrProfileDTO dto = (MdrProfileDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getVillageName() != null)
                cValues.put("villageName", dto.getVillageName());
            if (dto.getCropId() != 0)
                cValues.put("cropId", dto.getCropId());
            if (dto.getTotalCropArea() != 0)
                cValues.put("totalCropArea", dto.getTotalCropArea());
            if (dto.getPioneerShare() != 0)
                cValues.put("pioneerShare", dto.getPioneerShare());
            if (dto.getMajorCompetitorName1() != null)
                cValues.put("majorCompetitorName1", dto.getMajorCompetitorName1());
            if (dto.getItsShare1() != 0)
                cValues.put("itsShare1", dto.getItsShare1());
            if (dto.getMajorCompetitorName2() != null)
                cValues.put("majorCompetitorName2", dto.getMajorCompetitorName2());
            if (dto.getItsShare2() != 0)
                cValues.put("itsShare2", dto.getItsShare2());
            if (dto.getDate() != null)
                cValues.put("date", dto.getDate());
            if (dto.getLocation() != null)
                cValues.put("location", dto.getLocation());

            cValues.put("isSync", dto.getIsSync());

            if (dto.getUploadedDate() != null)
                cValues.put("uploadedDate", dto.getUploadedDate());

            if (dto.getRegionId() != 0)
                cValues.put("regionId", dto.getRegionId());

            if (dto.getNumberOfFarmers() != 0)
                cValues.put("numberOfFarmers", dto.getNumberOfFarmers());

            if (dto.getPinCode() != null)
                cValues.put("pinCode", dto.getPinCode());

            if (dto.getBlockName() != null)
                cValues.put("blockName", dto.getBlockName());

            if (dto.getSegment() != 0)
                cValues.put("segment", dto.getSegment());

            if (dto.getCropHa() != null)
                cValues.put("cropHa", dto.getCropHa());

            if (dto.getPhiHa() != null)
                cValues.put("phiHa", dto.getPhiHa());

            if (dto.getMajorPHIHybrid1() != 0)
                cValues.put("majorPHIHybrid1", dto.getMajorPHIHybrid1());

            if (dto.getMajorPHIHybrid2() != 0)
                cValues.put("majorPHIHybrid2", dto.getMajorPHIHybrid2());

            if (dto.getMajorCompetitionHybrid1() != null)
                cValues.put("majorCompetitionHybrid1", dto.getMajorCompetitionHybrid1());

            if (dto.getMajorCompetitionHybrid2() != null)
                cValues.put("majorCompetitionHybrid2", dto.getMajorCompetitionHybrid2());

            dbObject.update("MDR_PROFILE", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }


    public List<Long> getIdsByDate(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<Long> idsList = new ArrayList<Long>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "uploadedDate";

            cursor = dbObject.rawQuery("SELECT id FROM MDR_PROFILE  where " + columnName + " < '" + columnValue + "' and isSync = '0' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    idsList.add(cursor.getLong(0));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return idsList;
    }


    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM MDR_PROFILE").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from MDR_PROFILE where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean deleteDataByDate(String date, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from  MDR_PROFILE  where uploadedDate < '" + date + "' and isSync = '0'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT count(id) FROM MDR_PROFILE where isSync = 1", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return  false;
    }



    // Is data available for activityId and region id combination
    public boolean isDataAvailForRandACombo(long activityId, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT regionId FROM MDR_PROFILE where activityId = '" + activityId + "'", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return  false;
    }
}
