package com.activitytrack.activity;

import java.io.InputStream;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

public class ForgotPassWordActivity extends Activity {
	
	
	private   Button submit;
	private   EditText loginEdt;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	 
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_forgotpassword);
		
		ActionBar bar = getActionBar();
		bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#efefef")));
		bar.setTitle("ACTIVITY TRACKER");
		bar.setIcon(new ColorDrawable(Color.TRANSPARENT));
		centerActionBarTitle();
		
		submit = (Button)findViewById(R.id.forgot_submit);
		loginEdt = (EditText)findViewById(R.id.forgot_loginid);
		
		submit.setOnClickListener(new OnClickListener() {
			
				@Override
				public void onClick(View v) {
					 
						if(loginEdt.getText().toString().trim().length() > 0){
							 
							
							List<DTO> userList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(ForgotPassWordActivity.this).getDBObject(0));
							if(userList != null && userList.size() > 0){
								MdrMasterDTO dto=(MdrMasterDTO) userList.get(0);
								 
									if(loginEdt.getText().toString().trim().equals(dto.getLoginId())){
										if(Utility.networkAvailability(ForgotPassWordActivity.this)){
											JSONObject jsonObject = new JSONObject();
											try{
												jsonObject.put("loginId",loginEdt.getText().toString().trim());
											    
												String deviceID = Utility.getDeviceId(ForgotPassWordActivity.this);
												jsonObject.put("deviceId",deviceID);
												 
												
												ForgotPasswordAsync  async = new ForgotPasswordAsync (jsonObject.toString(),ForgotPassWordActivity.this);
												async.execute(MyConstants.AppURL+MyConstants.FORGOT_PASSWORD);
											}catch (JSONException e){
												e.printStackTrace();
											}
										}else {
											Utility.showAlert(ForgotPassWordActivity.this, "",getResources().getString(R.string.checkNetwork));
										}
										 
										 
									}else{
										Utility.showAlert(ForgotPassWordActivity.this, "",getResources().getString(R.string.validUserName));
									}
								  
								
							}else{
								if (Utility.networkAvailability(ForgotPassWordActivity.this)) {
									JSONObject jsonObject = new JSONObject();
									try {
										jsonObject.put("loginId", loginEdt.getText().toString().trim());
										
										String deviceID = Utility.getDeviceId(ForgotPassWordActivity.this);
										jsonObject.put("deviceId",deviceID);
									
										ForgotPasswordAsync  async = new ForgotPasswordAsync (jsonObject.toString(),ForgotPassWordActivity.this);
										async.execute(MyConstants.AppURL+MyConstants.FORGOT_PASSWORD);
										 
										
									} catch (JSONException e) {
										e.printStackTrace();
									}
		
								} else {
									Utility.showAlert(ForgotPassWordActivity.this, "",getResources().getString(R.string.checkNetwork));
								}
							}
							
						}else {
							Utility.showAlert(ForgotPassWordActivity.this, "", getResources().getString(R.string.loginIdEmpty));
						}
					  
		       }
				 
			});
			
		}
		
	private class ForgotPasswordAsync extends AsyncTask<String, Void, String> {
		String jsonData;
		Context context;
		ProgressDialog dlg;

		public ForgotPasswordAsync (String inputJSON, Context context) {
			jsonData = inputJSON;
			this.context = context;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			dlg = new ProgressDialog(context);
			dlg.setCanceledOnTouchOutside(false);
			dlg.setCancelable(false);
			dlg.setMessage(context.getResources().getString(R.string.progress_pleaseWait));
			dlg.show();
		}

		@Override
		protected String doInBackground(String... params) {
			HttpClient httpClient = null;
			try {
				HttpParams httpParams = new BasicHttpParams();
				int connectionTimeout = MyConstants.CONNECTION_TIME_LIMIT;
				int socketTimeout = MyConstants.CONNECTION_TIME_LIMIT;
				HttpConnectionParams.setConnectionTimeout(httpParams, connectionTimeout);
				HttpConnectionParams.setSoTimeout(httpParams, socketTimeout);
				httpClient = new DefaultHttpClient(httpParams);
				HttpPost httpPost = new HttpPost(params[0]);
				ATBuildLog.i("fogotPassword", "request data :" + jsonData);
				StringEntity stringEntity = new StringEntity(jsonData);
				httpPost.setEntity(stringEntity);
				/*MultipartEntity entity = new MultipartEntity();
				 entity.addPart("jsonData", new StringBody(jsonData)); 				 
				 httpPost.setEntity(entity);*/
				HttpResponse response = httpClient.execute(httpPost);
				HttpEntity httpEntity = response.getEntity();
				InputStream instream = httpEntity.getContent();
				String responseStr = Utility.convertStreamToString(instream);
				return responseStr;
			} catch (Exception exception) {
				exception.printStackTrace();
			} finally {
				if (httpClient != null)
					httpClient.getConnectionManager().shutdown();
			}

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			if (result != null && !result.isEmpty()) {
			if(!Utility.isJSONValid(result)){
				Utility.showAlert(context, "",getResources().getString(R.string.ntjson));
			}else{
			try {
				
				JSONObject loginRes = new JSONObject(result);
				
				
				System.out.println("master Data : "+result);
				 
				//Gson gson = new Gson();
				//DownloadMasterDTO obj = gson.fromJson(result, DownloadMasterDTO.class);
				
				if(loginRes.getInt("code") == 100){
					Toast.makeText(ForgotPassWordActivity.this,"Password will receive on your register mobile number",Toast.LENGTH_LONG).show();
					 
					
					 finish();
					
				}else if (loginRes.getInt("code") == 101) {
					Utility.showAlert(context, "", MyConstants.RES101MSG);
				} else if (loginRes.getInt("code") == 102) {
					Utility.showAlert(context, "", MyConstants.RES102MSG);
				} else if (loginRes.getInt("code") == 103) {
					Utility.showAlert(context, "", MyConstants.RES103MSG);
				} else if (loginRes.getInt("code") == 104) {
					Utility.showAlert(context, "", MyConstants.RES104MSG);
				}else if (loginRes.getInt("code") == 302) {
					Utility.showAlert(context, "", MyConstants.RES302MSG);
				
				}

			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		}else{
			Utility.showAlert(context, "",getResources().getString(R.string.networkProblem));
		}
		
		if (dlg != null) {
			dlg.dismiss();
		}
	 }
		
	}
	
	private void centerActionBarTitle() {
	    int titleId = 0;
	    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
	        titleId = getResources().getIdentifier("action_bar_title", "id", "android");
	    } else {
	        // This is the id is from your app's generated R class when 
	        // ActionBarActivity is used for SupportActionBar
	        titleId = R.id.action_home;
	    }

	    // Final check for non-zero invalid id
	    if (titleId > 0) {
	        TextView titleTextView = (TextView) findViewById(titleId);
	        DisplayMetrics metrics = getResources().getDisplayMetrics();
	        // Fetch layout parameters of titleTextView 
	        // (LinearLayout.LayoutParams : Info from HierarchyViewer)
	        LinearLayout.LayoutParams txvPars = (LayoutParams) titleTextView.getLayoutParams();
	        txvPars.gravity = Gravity.CENTER_HORIZONTAL;
	        txvPars.width = metrics.widthPixels;
	        titleTextView.setLayoutParams(txvPars);
	        titleTextView.setGravity(Gravity.CENTER);
	        titleTextView.setTextColor(Color.parseColor("#427730"));
	        titleTextView.setTextSize(20);
	        titleTextView.setTypeface(null, Typeface.BOLD);
	       
	    }
	}
}
