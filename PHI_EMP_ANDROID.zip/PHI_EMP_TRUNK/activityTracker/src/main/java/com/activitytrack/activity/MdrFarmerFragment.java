package com.activitytrack.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.activitytrack.daos.MdrFarmerDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.MdrFarmerDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.List;

public class MdrFarmerFragment extends AppCompatActivity {

	private EditText edtS1FarmerName;
	private EditText edtS1MobileNumber;
	private EditText edtS1Acres;
	private EditText edtS1MajorCrop;
	private EditText edtS1MajorCropAcres;
	private EditText edtS1SecondCrop;
	private EditText edtS1SecondCropAcres;
	
	private EditText edtS2FarmerName;
	private EditText edtS2MobileNumber;
	private EditText edtS2Acres;
	private EditText edtS2MajorCrop;
	private EditText edtS2MajorCropAcres;
	private EditText edtS2SecondCrop;
	private EditText edtS2SecondCropAcres;
	
	private EditText edtS3FarmerName;
	private EditText edtS3MobileNumber;
	private EditText edtS3Acres;
	private EditText edtS3MajorCrop;
	private EditText edtS3MajorCropAcres;
	private EditText edtS3SecondCrop;
	private EditText edtS3SecondCropAcres;
	
	private EditText edtS4FarmerName;
	private EditText edtS4MobileNumber;
	private EditText edtS4Acres;
	private EditText edtS4MajorCrop;
	private EditText edtS4MajorCropAcres;
	private EditText edtS4SecondCrop;
	private EditText edtS4SecondCropAcres;
	
	private EditText edtS5FarmerName;
	private EditText edtS5MobileNumber;
	private EditText edtS5Acres;
	private EditText edtS5MajorCrop;
	private EditText edtS5MajorCropAcres;
	private EditText edtS5SecondCrop;
	private EditText edtS5SecondCropAcres;
	
	private Button btnSubmit;
	private Button btnAddNext;
	
	private LinearLayout mainLayout;
	//private  String activity;
	private long activityId;

	private MdrFarmerFragment mActivity;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		if (Utility.getCurrentTheme(this).equals(MyConstants.THEME_LIGHT)) {
			setTheme(R.style.AppThemeLite);
		} else if (Utility.getCurrentTheme(this).equals(MyConstants.THEME_DARK)) {
			setTheme(R.style.AppThemeAT);
		}
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mdr_farmer_fragment);

		mActivity = this;

		ActionBar actionBar = getSupportActionBar();
		actionBar.setDisplayShowTitleEnabled(true);
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setDisplayShowHomeEnabled(true);
		actionBar.setTitle(getString(R.string.add_farmers));

		edtS1FarmerName=(EditText) findViewById(R.id.mdr_far_s1_farmerName);
		edtS1MobileNumber=(EditText)findViewById(R.id.mdr_far_s1_mobileNumber);
		edtS1Acres=(EditText) findViewById(R.id.mdr_far_s1_acres);
		edtS1MajorCrop=(EditText) findViewById(R.id.mdr_far_s1_majorCrop);
		edtS1MajorCropAcres=(EditText) findViewById(R.id.mdr_far_s1_majorCropAcres);
		edtS1SecondCrop=(EditText) findViewById(R.id.mdr_far_s1_secondCrop);
		edtS1SecondCropAcres=(EditText) findViewById(R.id.mdr_far_s1_secondCropAcres);
		
		edtS2FarmerName=(EditText) findViewById(R.id.mdr_far_s2_farmerName);
		edtS2MobileNumber=(EditText) findViewById(R.id.mdr_far_s2_mobileNumber);
		edtS2Acres=(EditText) findViewById(R.id.mdr_far_s2_acres);
		edtS2MajorCrop=(EditText) findViewById(R.id.mdr_far_s2_majorCrop);
		edtS2MajorCropAcres=(EditText) findViewById(R.id.mdr_far_s2_majorCropAcres);
		edtS2SecondCrop=(EditText) findViewById(R.id.mdr_far_s2_secondCrop);
		edtS2SecondCropAcres=(EditText) findViewById(R.id.mdr_far_s2_secondCropAcres);
	
		edtS3FarmerName=(EditText) findViewById(R.id.mdr_far_s3_farmerName);
		edtS3MobileNumber=(EditText) findViewById(R.id.mdr_far_s3_mobileNumber);
		edtS3Acres=(EditText) findViewById(R.id.mdr_far_s3_acres);
		edtS3MajorCrop=(EditText) findViewById(R.id.mdr_far_s3_majorCrop);
		edtS3MajorCropAcres=(EditText) findViewById(R.id.mdr_far_s3_majorCropAcres);
		edtS3SecondCrop=(EditText) findViewById(R.id.mdr_far_s3_secondCrop);
		edtS3SecondCropAcres=(EditText) findViewById(R.id.mdr_far_s3_secondCropAcres);
		
		edtS4FarmerName=(EditText) findViewById(R.id.mdr_far_s4_farmerName);
		edtS4MobileNumber=(EditText) findViewById(R.id.mdr_far_s4_mobileNumber);
		edtS4Acres=(EditText) findViewById(R.id.mdr_far_s4_acres);
		edtS4MajorCrop=(EditText) findViewById(R.id.mdr_far_s4_majorCrop);
		edtS4MajorCropAcres=(EditText) findViewById(R.id.mdr_far_s4_majorCropAcres);
		edtS4SecondCrop=(EditText) findViewById(R.id.mdr_far_s4_secondCrop);
		edtS4SecondCropAcres=(EditText) findViewById(R.id.mdr_far_s4_secondCropAcres);
		
		edtS5FarmerName=(EditText) findViewById(R.id.mdr_far_s5_farmerName);
		edtS5MobileNumber=(EditText) findViewById(R.id.mdr_far_s5_mobileNumber);
		edtS5Acres=(EditText) findViewById(R.id.mdr_far_s5_acres);
		edtS5MajorCrop=(EditText) findViewById(R.id.mdr_far_s5_majorCrop);
		edtS5MajorCropAcres=(EditText) findViewById(R.id.mdr_far_s5_majorCropAcres);
		edtS5SecondCrop=(EditText) findViewById(R.id.mdr_far_s5_secondCrop);
		edtS5SecondCropAcres=(EditText) findViewById(R.id.mdr_far_s5_secondCropAcres);
		
		mainLayout=(LinearLayout) findViewById(R.id.mdr_far_bg_laylout);
		
		btnSubmit=(Button) findViewById(R.id.mdr_far_submit);
		btnAddNext=(Button) findViewById(R.id.mdr_far_addNext);
		  
		setChange();
		 

		Bundle bundle = getIntent().getExtras();
		//activity = bundle.getString("activity");
		activityId = bundle.getLong("activityId");

		
		
		btnAddNext.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					String validateFarmer1 = validateFields().trim();
					 if(validateFarmer1.trim().length() == 0)
						{
						 String validateFarmer2 = validateFarmer(edtS2FarmerName, edtS2MobileNumber, edtS2Acres,edtS2MajorCrop,edtS2MajorCropAcres,edtS2SecondCrop,edtS2SecondCropAcres);
						 if(validateFarmer2.trim().length() == 0)
							{
							 String validateFarmer3 = validateFarmer(edtS3FarmerName, edtS3MobileNumber, edtS3Acres,edtS3MajorCrop,edtS3MajorCropAcres,edtS3SecondCrop,edtS3SecondCropAcres);
							 if(validateFarmer3.trim().length() == 0)
								{
								 String validateFarmer4 = validateFarmer(edtS4FarmerName, edtS4MobileNumber, edtS4Acres,edtS4MajorCrop,edtS4MajorCropAcres,edtS4SecondCrop,edtS4SecondCropAcres);
								 if(validateFarmer4.trim().length() == 0)
									{
									 String validateFarmer5 = validateFarmer(edtS5FarmerName, edtS5MobileNumber, edtS5Acres,edtS5MajorCrop,edtS5MajorCropAcres,edtS5SecondCrop,edtS5SecondCropAcres);
									 if(validateFarmer5.trim().length() == 0)
										{
									
									 
										 showAlertToAddNext();
										}else{
											if(!validateFarmer5.equals(getResources().getString(R.string.validmobilenum)))
											Utility.showAlert(mActivity, "", validateFarmer5);
										    }
										}else{
											if(!validateFarmer4.equals(getResources().getString(R.string.validmobilenum)))
											Utility.showAlert(mActivity, "", validateFarmer4);
									}
								}else{
									if(!validateFarmer3.equals(getResources().getString(R.string.validmobilenum)))
									Utility.showAlert(mActivity, "", validateFarmer3);
								}
							}else{
								if(!validateFarmer2.equals(getResources().getString(R.string.validmobilenum)))
								Utility.showAlert(mActivity, "", validateFarmer2);
							}
						}else{
							if(!validateFarmer1.equals(getResources().getString(R.string.validmobilenum).trim()))
								Utility.showAlert(mActivity, "", validateFarmer1);
						}
					
				}
			});
			
			btnSubmit.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) 
				{
					 String validateFarmer1 = validateFields();
					 if(validateFarmer1.trim().length() == 0)
						{
						 String validateFarmer2 = validateFarmer(edtS2FarmerName, edtS2MobileNumber, edtS2Acres,edtS2MajorCrop,edtS2MajorCropAcres,edtS2SecondCrop,edtS2SecondCropAcres);
						 if(validateFarmer2.trim().length() == 0)
							{
							 String validateFarmer3 = validateFarmer(edtS3FarmerName, edtS3MobileNumber, edtS3Acres,edtS3MajorCrop,edtS3MajorCropAcres,edtS3SecondCrop,edtS3SecondCropAcres);
							 if(validateFarmer3.trim().length() == 0)
								{
								 String validateFarmer4 = validateFarmer(edtS4FarmerName, edtS4MobileNumber, edtS4Acres,edtS4MajorCrop,edtS4MajorCropAcres,edtS4SecondCrop,edtS4SecondCropAcres);
								 if(validateFarmer4.trim().length() == 0)
									{
									 String validateFarmer5 = validateFarmer(edtS5FarmerName, edtS5MobileNumber, edtS5Acres,edtS5MajorCrop,edtS5MajorCropAcres,edtS5SecondCrop,edtS5SecondCropAcres);
									 if(validateFarmer5.trim().length() == 0)
										{
									    showAlertToSave();
										}else{
											if(!validateFarmer5.equals(getResources().getString(R.string.validmobilenum)))
											Utility.showAlert(mActivity, "", validateFarmer5);
										    }
										}else{
											if(!validateFarmer4.equals(getResources().getString(R.string.validmobilenum)))
											Utility.showAlert(mActivity, "", validateFarmer4);
									}
								}else{
									if(!validateFarmer3.equals(getResources().getString(R.string.validmobilenum)))
									Utility.showAlert(mActivity, "", validateFarmer3);
								}
							}else{
								if(!validateFarmer2.equals(getResources().getString(R.string.validmobilenum)))
								Utility.showAlert(mActivity, "", validateFarmer2);
							}
						}else{
							if(!validateFarmer1.equals(getResources().getString(R.string.validmobilenum).trim()))
								Utility.showAlert(mActivity, "", validateFarmer1);
						}
				}
			});
		}
		
	private String validateFarmer(EditText name, EditText mobileNo, EditText acres,EditText majorCrop,EditText majorCropAcres,EditText secondCrop,EditText secondCropAcres){
		
		int nameLen, mobileNoLen, acresLen, majorCropLen, majorCropAcresLen, secondCropLen, secondCropAcresLen;
		nameLen = name.getText().toString().trim().length();
		mobileNoLen = mobileNo.getText().toString().trim().length();
		acresLen = acres.getText().toString().trim().length();
		majorCropLen = majorCrop.getText().toString().trim().length();
		majorCropAcresLen = majorCropAcres.getText().toString().trim().length();
		secondCropLen = secondCrop.getText().toString().trim().length();
		secondCropAcresLen = secondCropAcres.getText().toString().trim().length();
		
		if(nameLen == 0 && mobileNoLen == 0 &&  acresLen == 0 && majorCropLen == 0 && majorCropAcresLen== 0 && secondCropLen == 0 && secondCropAcresLen ==0 ){
			return "";
		}else if(nameLen == 0 || mobileNoLen == 0 || acresLen == 0|| majorCropLen == 0 || majorCropAcresLen== 0 || secondCropLen == 0 || secondCropAcresLen ==0 ){
			return getResources().getString(R.string.enterallfields);
		}else if(mobileNoLen != 10){
			mobileNo.setError(getResources().getString(R.string.validmobilenum));
			return getResources().getString(R.string.validmobilenum) ;
		 
		} else if(Utility.isValidStr(mobileNo.getText().toString()) && mobileNoLen == 10){
			int sum = validateMobileOrPin(mobileNo.getText().toString().trim());
			if (sum == 0)
				return getResources().getString(R.string.mobile_number_not_all_zero);
			else
				return "";
		}else{
			return "";
		}
	}
	
	
	
	
	private String validateFields() 
	{
		if(edtS1FarmerName.getText().toString().trim().length()==0)
			return getResources().getString(R.string.farmernamentempty);
		
		if(edtS1MobileNumber.getText().toString().trim().length()==0)
			return getResources().getString(R.string.mobilenonyempty);
		
		if(edtS1MobileNumber.getText().toString().trim().length() <= 9)
		{
			edtS1MobileNumber.setError(getResources().getString(R.string.validmobilenum));
			return getResources().getString(R.string.validmobilenum);
		}

		if(edtS1Acres.getText().toString().trim().length()==0)
			return getResources().getString(R.string.acresntempty);
		
		if(edtS1MajorCrop.getText().toString().trim().length()==0)
			return getResources().getString(R.string.majorcropntempty) ;
		
		if(edtS1MajorCropAcres.getText().toString().trim().length()==0)
			return getResources().getString(R.string.majoracresntempty) ;
		
		if(edtS1SecondCrop.getText().toString().trim().length()==0)
			return  getResources().getString(R.string.secondcropntempty) ;
		
		if(edtS1SecondCropAcres.getText().toString().trim().length()==0)
			return getResources().getString(R.string.secondacresntempty);

		if (Utility.isValidStr(edtS1MobileNumber.getText().toString().trim()) && edtS1MobileNumber.length() == 10) {
			int sum = validateMobileOrPin(edtS1MobileNumber.getText().toString().trim());
			if (sum == 0)
				return getResources().getString(R.string.mobile_number_not_all_zero);
			else
				return "";
		}
		
		return "";
	
	}

	private void showAlertToSave() 
	{
		 AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		 builder.setMessage(getResources().getString(R.string.saveData));
		 builder.setPositiveButton(getResources().getString(R.string.yes),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
				saveData();
			}

			
			
		}); 
		 builder.setNegativeButton(getResources().getString(R.string.no),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
			}
		});
		
	builder.create().show();
	}
	
	private void showAlertToAddNext() 
	{
		 AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		 builder.setMessage(getResources().getString(R.string.saveData));
		 builder.setPositiveButton(getResources().getString(R.string.yes),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
				saveData();
			}
		}); 
		 builder.setNegativeButton(getResources().getString(R.string.no),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
			}
		});
		
	builder.create().show();
	}
		
	
	private void saveData()  
	{
		
		List<DTO> avalibleRecordsList = MdrFarmerDAO.getInstance().getRecordInfoByValue("activityId",""+activityId,DBHandler.getInstance(mActivity).getDBObject(0));
		
		List<MdrFarmerDTO> dtoList = new ArrayList<MdrFarmerDTO>(); 
		MdrFarmerDTO dto = new MdrFarmerDTO();
		
		
		dto.setFarmerName(edtS1FarmerName.getText().toString().trim());
		dto.setMobileNumber(Long.valueOf(edtS1MobileNumber.getText().toString().trim()));
		dto.setAcres(Float.valueOf(edtS1Acres.getText().toString().trim()));
		dto.setMajorCrop(edtS1MajorCrop.getText().toString().trim());
		dto.setMajorCropAcres(Float.valueOf(edtS1MajorCropAcres.getText().toString().trim()));
		dto.setSecondCrop(edtS1SecondCrop.getText().toString().trim());
		dto.setSecondCropAcres(Float.valueOf(edtS1SecondCropAcres.getText().toString().trim()));
		dto.setActivityId(activityId);
		dtoList.add(dto);
		 
		
		if(edtS2FarmerName.getText().toString().trim().length() > 0 && edtS2MobileNumber.getText().toString().trim().length()>0 && edtS2Acres.getText().toString().trim().length()>0)
		{
			MdrFarmerDTO dto1=new MdrFarmerDTO();
			dto1.setFarmerName(edtS2FarmerName.getText().toString().trim());
			dto1.setMobileNumber(Long.valueOf(edtS2MobileNumber.getText().toString().trim()));
			dto1.setAcres(Float.valueOf(edtS2Acres.getText().toString().trim()));
			dto1.setMajorCrop(edtS2MajorCrop.getText().toString().trim());
			dto1.setMajorCropAcres(Float.valueOf(edtS2MajorCropAcres.getText().toString().trim()));
			dto1.setSecondCrop(edtS2SecondCrop.getText().toString().trim());
			dto1.setSecondCropAcres(Float.valueOf(edtS2SecondCropAcres.getText().toString().trim()));
			dto1.setActivityId(activityId);
			dtoList.add(dto1);
			 
		 
		}
		 
		
		
		if(edtS3FarmerName.getText().toString().trim().length() > 0 && edtS3MobileNumber.getText().toString().trim().length()>0 && edtS3Acres.getText().toString().trim().length()>0)
		{
	
			MdrFarmerDTO dto2=new MdrFarmerDTO();
			dto2.setFarmerName(edtS3FarmerName.getText().toString().trim());
			dto2.setMobileNumber(Long.valueOf(edtS3MobileNumber.getText().toString().trim()));
			dto2.setAcres(Float.valueOf(edtS3Acres.getText().toString().trim()));
			dto2.setMajorCrop(edtS3MajorCrop.getText().toString().trim());
			dto2.setMajorCropAcres(Float.valueOf(edtS3MajorCropAcres.getText().toString().trim()));
			dto2.setSecondCrop(edtS3SecondCrop.getText().toString().trim());
			dto2.setSecondCropAcres(Float.valueOf(edtS3SecondCropAcres.getText().toString().trim()));
			dto2.setActivityId(activityId);
			dtoList.add(dto2);
			 
		}
		 
	 
		 
		 
		
		if(edtS4FarmerName.getText().toString().trim().length() > 0 && edtS4MobileNumber.getText().toString().trim().length()>0 && edtS4Acres.getText().toString().trim().length()>0)
		{
			MdrFarmerDTO dto3=new MdrFarmerDTO();
			dto3.setFarmerName(edtS4FarmerName.getText().toString().trim());
			dto3.setMobileNumber(Long.valueOf(edtS4MobileNumber.getText().toString().trim()));
			dto3.setAcres(Float.valueOf(edtS4Acres.getText().toString().trim()));
			dto3.setMajorCrop(edtS4MajorCrop.getText().toString().trim());
			dto3.setMajorCropAcres(Float.valueOf(edtS4MajorCropAcres.getText().toString().trim()));
			dto3.setSecondCrop(edtS4SecondCrop.getText().toString().trim());
			dto3.setSecondCropAcres(Float.valueOf(edtS4SecondCropAcres.getText().toString().trim()));
			dto3.setActivityId(activityId);
			dtoList.add(dto3);
		 
		
		} 
		
		if(edtS5FarmerName.getText().toString().trim().length() > 0 && edtS5MobileNumber.getText().toString().trim().length()>0 && edtS5Acres.getText().toString().trim().length()>0)
		{
			MdrFarmerDTO dto4=new MdrFarmerDTO();
			dto4.setFarmerName(edtS5FarmerName.getText().toString().trim());
			dto4.setMobileNumber(Long.valueOf(edtS5MobileNumber.getText().toString().trim()));
			dto4.setAcres(Float.valueOf(edtS5Acres.getText().toString().trim()));
			dto4.setMajorCrop(edtS5MajorCrop.getText().toString().trim());
			dto4.setMajorCropAcres(Float.valueOf(edtS5MajorCropAcres.getText().toString().trim()));
			dto4.setSecondCrop(edtS5SecondCrop.getText().toString().trim());
			dto4.setSecondCropAcres(Float.valueOf(edtS5SecondCropAcres.getText().toString().trim()));
			dto4.setActivityId(activityId);
			dtoList.add(dto4);
		
		} 
		
		boolean inserted = false;

		if(avalibleRecordsList !=null && avalibleRecordsList.size() < 20){
			if(avalibleRecordsList.size() == 0){
				if(dtoList.size() >= 1){
					inserted = insertData(dtoList);
				}else{
					Utility.showAlert(mActivity, "", getResources().getString(R.string.min1far));
				}
			}else{
				int availCount = avalibleRecordsList.size();
				if (availCount + dtoList.size() <= 20) {
					inserted = insertData(dtoList);
				} else {
					Utility.showAlert(mActivity, getResources().getString(R.string.max20far), "Already " + availCount + getResources().getString(R.string.faradded) + dtoList.size() + " farmers");
				}
			}
		}else{
			Utility.showAlert(mActivity, "",getResources().getString(R.string.al20far));
		}


		if (inserted) {
			Toast.makeText(mActivity, "Successfully inserted", Toast.LENGTH_SHORT).show();
			List<DTO> tempList = MdrFarmerDAO.getInstance().getRecordInfoByValue("activityId", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));
			if (tempList != null && tempList.size() > 0) {
				if (tempList.size() >= 15) {
					btnAddNext.setVisibility(View.GONE);
				}
			}

			clearFields();
			onBackPressed();
		} else {
			Toast.makeText(mActivity, "Failed to insert", Toast.LENGTH_SHORT).show();
		}
		
		
	}
	
	private boolean insertData(List<MdrFarmerDTO> list){
		for(MdrFarmerDTO dto : list){
			MdrFarmerDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getDBObject(1));
		}
		return true;
		
	}
	
	private void clearFields() 
	{
		edtS1FarmerName.setText("");
		edtS1MobileNumber.setText("");
		edtS1Acres.setText("");
		edtS1MajorCrop.setText("");
		edtS1MajorCropAcres.setText("");
		edtS1SecondCrop.setText("");
		edtS1SecondCropAcres.setText("");
		edtS2FarmerName.setText("");
		edtS2MobileNumber.setText("");
		edtS2Acres.setText("");
		edtS2MajorCrop.setText("");
		edtS2MajorCropAcres.setText("");
		edtS2SecondCrop.setText("");
		edtS2SecondCropAcres.setText("");
		edtS3FarmerName.setText("");
		edtS3MobileNumber.setText("");
		edtS3Acres.setText("");
		edtS3MajorCrop.setText("");
		edtS3MajorCropAcres.setText("");
		edtS3SecondCrop.setText("");
		edtS3SecondCropAcres.setText("");
		edtS4FarmerName.setText("");
		edtS4MobileNumber.setText("");
		edtS4Acres.setText("");
		edtS4MajorCrop.setText("");
		edtS4MajorCropAcres.setText("");
		edtS4SecondCrop.setText("");
		edtS4SecondCropAcres.setText("");
		edtS5FarmerName.setText("");
		edtS5MobileNumber.setText("");
		edtS5Acres.setText("");
		edtS5MajorCrop.setText("");
		edtS5MajorCropAcres.setText("");
		edtS5SecondCrop.setText("");
		edtS5SecondCropAcres.setText("");
		
		
	}

	private void setChange() {
		if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

		} else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {

			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));

		}
	}

	@Override
	public void onBackPressed() {
		if(isDataAvailable()){
			showAlertToExitScreen();
		}else{
			MdrFarmerFragment.this.setResult(Activity.RESULT_OK);
			MdrFarmerFragment.this.finish();
		}
	}
	
	private void showAlertToExitScreen(){
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.formExitMsg));
		builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				MdrFarmerFragment.this.setResult(Activity.RESULT_OK);
				MdrFarmerFragment.this.finish();
			}
		});
		
		builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
			}
		});
		
		builder.create().show();
	}
	
	
	private boolean isDataAvailable() {
		
		if (edtS1FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS1MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS1Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS1MajorCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS1MajorCropAcres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS1SecondCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS1SecondCropAcres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS2FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS2MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS2Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS2MajorCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS2MajorCropAcres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS2SecondCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS2SecondCropAcres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS3FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS3MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS3Acres.getText().toString().trim().length() > 0)
			return true;
	
		if (edtS3MajorCrop.getText().toString().trim().length() > 0)
			return true;
	
		if (edtS3MajorCropAcres.getText().toString().trim().length() > 0)
			return true;
	
		if (edtS3SecondCrop.getText().toString().trim().length() > 0)
			return true;
	
		if (edtS3SecondCropAcres.getText().toString().trim().length() > 0)
		 return true;

		if (edtS4FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS4MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS4Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS4MajorCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS4MajorCropAcres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS4SecondCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS4SecondCropAcres.getText().toString().trim().length() > 0)
			return true;
	
		if (edtS5FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS5MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS5Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS5MajorCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS5MajorCropAcres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS5SecondCrop.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS5SecondCropAcres.getText().toString().trim().length() > 0)
			return true;
	
		return false;
	}

	private int validateMobileOrPin(String trim) {
		int sum = 0;
		char[] arrayElements = trim.toCharArray();
		for (int i = 0; i < arrayElements.length; i++) {
			String v = String.valueOf(arrayElements[i]);
			sum += Integer.parseInt(v);
		}
		return sum;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == android.R.id.home) {
			onBackPressed();
		}
		return super.onOptionsItemSelected(item);
	}
		
}