package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.FarmerEntryDTO;
import com.activitytrack.dtos.OSAActivityDTO;
import com.activitytrack.dtos.RetailerInfoDTO;
import com.activitytrack.transdtos.ActivitiesTransDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;

import java.util.ArrayList;
import java.util.List;

public class OSAActivityDAO implements DAO {

    private final String TAG = "OSADAO";
    private static OSAActivityDAO osaActivityDAO;


    public static OSAActivityDAO getInstance() {
        if (osaActivityDAO == null) {
            osaActivityDAO = new OSAActivityDAO();
        }

        return osaActivityDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> osaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM OSA_ACTIVITY where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    /*OSA_ACTIVITY
                    id 
                    activityType
                    cropId
                    hybridId
                    numberOfFarmers
                    numberOfRetailers
                    competitorHybrid1
                    hybridAcres
                    competitorYield
                    location
                    isSync
                    seasonId
                    date
                    seasonCalendarId
                    uploadedDate
                     */

                    OSAActivityDTO dto = new OSAActivityDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setActivityType(cursor.getString(1));
                    dto.setCropId(cursor.getLong(2));
                    dto.setHybridId(cursor.getLong(3));
                    dto.setNumberOfFarmers(cursor.getInt(4));
                    dto.setNumberOfRetailers(cursor.getInt(5));
                    dto.setCompetitorHybrid1(cursor.getString(6));
                    dto.setHybridAcres(cursor.getFloat(7));
                    dto.setCompetitorYield(cursor.getFloat(8));
                    dto.setLocation(cursor.getString(9));
                    dto.setIsSync(cursor.getInt(10));
                    dto.setSeasonId(cursor.getLong(11));
                    dto.setDate(cursor.getString(12));
                    dto.setSeasonCalendarId(cursor.getLong(13));
                    dto.setUploadedDate(cursor.getString(14));
                    dto.setRegionId(cursor.getLong(15));
                    dto.setFarmerBarCodeDetails(cursor.getString(16));
                    dto.setFarmerAttendanceDetails(cursor.getString(17));
                    dto.setPincode(cursor.getString(18));
                    dto.setIsTBLParticipated(cursor.getString(19));
                    dto.setNumberOfPravaktas(cursor.getInt(20));
                    //newly added for faw
                    dto.setIsFAWDone(cursor.getString(21));

                    osaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return osaActivityInfo;
    }

    public List<Long> getIdsByDate(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<Long> idsList = new ArrayList<Long>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "uploadedDate";

            cursor = dbObject.rawQuery("SELECT id FROM OSA_ACTIVITY  where " + columnName + " < '" + columnValue + "' and isSync = '0' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    idsList.add(cursor.getLong(0));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return idsList;
    }

    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> osaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM OSA_ACTIVITY ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    OSAActivityDTO dto = new OSAActivityDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setActivityType(cursor.getString(1));
                    dto.setCropId(cursor.getLong(2));
                    dto.setHybridId(cursor.getLong(3));
                    dto.setNumberOfFarmers(cursor.getInt(4));
                    dto.setNumberOfRetailers(cursor.getInt(5));
                    dto.setCompetitorHybrid1(cursor.getString(6));
                    dto.setHybridAcres(cursor.getFloat(7));
                    dto.setCompetitorYield(cursor.getFloat(8));
                    dto.setLocation(cursor.getString(9));
                    dto.setIsSync(cursor.getInt(10));
                    dto.setSeasonId(cursor.getLong(11));
                    dto.setDate(cursor.getString(12));
                    dto.setSeasonCalendarId(cursor.getLong(13));
                    dto.setUploadedDate(cursor.getString(14));
                    dto.setRegionId(cursor.getLong(15));
                    dto.setFarmerBarCodeDetails(cursor.getString(16));
                    dto.setFarmerAttendanceDetails(cursor.getString(17));
                    dto.setPincode(cursor.getString(18));
                    dto.setIsTBLParticipated(cursor.getString(19));
                    dto.setNumberOfPravaktas(cursor.getInt(20));
                    //newly added for faw
                    dto.setIsFAWDone(cursor.getString(21));

                    osaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return osaActivityInfo;
    }


    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }


    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            OSAActivityDTO dto = (OSAActivityDTO) dtoObject;


            ContentValues cValues = new ContentValues();
        /*OSA_ACTIVITY
        id 
        activityType
        cropId
        hybridId
        numberOfFarmers
        numberOfRetailers
        competitorHybrid1
        hybridAcres
        competitorYield
        location
        isSync
        seasonId
        date
        seasonCalendarId
        uploadedDate
        regionId
         */
            cValues.put("activityType", dto.getActivityType());
            cValues.put("cropId", dto.getCropId());
            cValues.put("hybridId", dto.getHybridId());
            cValues.put("numberOfFarmers", dto.getNumberOfFarmers());
            cValues.put("numberOfRetailers", dto.getNumberOfRetailers());
            cValues.put("competitorHybrid1", dto.getCompetitorHybrid1());
            cValues.put("hybridAcres", dto.getHybridAcres());
            cValues.put("competitorYield", dto.getCompetitorYield());
            cValues.put("location", dto.getLocation());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("seasonId", dto.getSeasonId());
            cValues.put("date", dto.getDate());
            cValues.put("seasonCalendarId", dto.getSeasonCalendarId());
            cValues.put("uploadedDate", dto.getUploadedDate());
            cValues.put("regionId", dto.getRegionId());
            cValues.put("farmerBarCodeDetails", dto.getFarmerBarCodeDetails());
            cValues.put("farmerAttendanceDetails", dto.getFarmerAttendanceDetails());
            cValues.put("pincode", dto.getPincode());
            cValues.put("isTBLParticipated", dto.getIsTBLParticipated());
            cValues.put("numberOfPravaktas", dto.getNumberOfPravaktas());
            //newly added for faw
            cValues.put("isFAWDone", dto.getIsFAWDone());

            long insertedRow = dbObject.insert(" OSA_ACTIVITY", null, cValues);
            if (insertedRow > 0) {
                Cursor cursor = dbObject.rawQuery("SELECT MAX(id) FROM OSA_ACTIVITY ", null);
                if (cursor.getCount() > 0) {

                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            OSAActivityDTO dto = (OSAActivityDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getActivityType() != null)
                cValues.put("activityType", dto.getActivityType());
            if (dto.getCropId() != 0)
                cValues.put("cropId", dto.getCropId());
            if (dto.getHybridId() != 0)
                cValues.put("hybridId", dto.getHybridId());
            if (dto.getNumberOfFarmers() != 0)
                cValues.put("numberOfFarmers", dto.getNumberOfFarmers());
            if (dto.getNumberOfRetailers() != 0)
                cValues.put("numberOfRetailers", dto.getNumberOfRetailers());
            if (dto.getCompetitorHybrid1() != null)
                cValues.put("competitorHybrid1", dto.getCompetitorHybrid1());
            if (dto.getHybridAcres() != 0)
                cValues.put("hybridAcres", dto.getHybridAcres());
            if (dto.getCompetitorYield() != 0)
                cValues.put("competitorYield", dto.getCompetitorYield());
            if (dto.getLocation() != null)
                cValues.put("location", dto.getLocation());

            cValues.put("isSync", dto.getIsSync());

            if (dto.getSeasonId() != 0)
                cValues.put("seasonId", dto.getSeasonId());

            if (dto.getDate() != null)
                cValues.put("date", dto.getDate());

            if (dto.getSeasonCalendarId() != 0)
                cValues.put("seasonCalendarId", dto.getSeasonCalendarId());

            if (dto.getUploadedDate() != null)
                cValues.put("uploadedDate", dto.getUploadedDate());

            if (dto.getRegionId() != 0)
                cValues.put("regionId", dto.getRegionId());

            if (dto.getFarmerBarCodeDetails() != null)
                cValues.put("farmerBarCodeDetails", dto.getFarmerBarCodeDetails());

            if (dto.getFarmerAttendanceDetails() != null)
                cValues.put("farmerAttendanceDetails", dto.getFarmerAttendanceDetails());

            if (dto.getPincode() != null)
                cValues.put("pincode", dto.getPincode());

            //newly added
            if (dto.getIsTBLParticipated() != null)
                cValues.put("isTBLParticipated", dto.getIsTBLParticipated());

            if (dto.getNumberOfPravaktas() != 0)
                cValues.put("numberOfPravaktas", dto.getNumberOfPravaktas());

            //newly added for faw
            if (dto.getIsFAWDone() != null)
                cValues.put("isFAWDone", dto.getIsFAWDone());

            int rowsEffected = dbObject.update("OSA_ACTIVITY", cValues, "id='" + dto.getId() + "' ", null);

            if (rowsEffected > 0)
                return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM OSA_ACTIVITY").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteTableDataById(Long id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM  OSA_ACTIVITY where id = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public List<ActivitiesTransDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<ActivitiesTransDTO> osaActivityInfo = new ArrayList<ActivitiesTransDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM OSA_ACTIVITY where isSync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    ActivitiesTransDTO dto = new ActivitiesTransDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setActivityType(cursor.getString(1));
                    dto.setCropId(cursor.getLong(2));
                    dto.setHybridId(cursor.getLong(3));
                    dto.setNumberOfFarmers(cursor.getInt(4));
                    dto.setNumberOfRetailers(cursor.getInt(5));
                    dto.setCompetitorHybrid1(cursor.getString(6));
                    dto.setHybridYield(cursor.getFloat(7));
                    dto.setCompetitorYield(cursor.getFloat(8));
                    dto.setLocation(cursor.getString(9));
                    //dto.setIsSync(cursor.getInt(10));
                    dto.setSeasonId(cursor.getLong(11));
                    dto.setDate(cursor.getString(12));
                    dto.setSeasonCalendarId(cursor.getLong(13));
                    dto.setRegionId(cursor.getLong(15));
                    dto.setFarmerBarCodeDetails(cursor.getString(16));
                    dto.setFarmerAttendanceDetails(cursor.getString(17));
                    dto.setPincode(cursor.getString(18));
                    dto.setIsTBLParticipated(cursor.getString(19));
                    dto.setNumberOfPravaktas(cursor.getInt(20));
                    //newly added for faw
                    dto.setIsFAWDone(cursor.getString(21));



                    List<FarmerEntryDTO> farmers = FarmerEntryDAO.getInstance().getRecordsForUpload(MyConstants.ACTIVITY_OSA, cursor.getLong(0), DBHandler.getInstance(context).getDBObject(0));
                    dto.setFarmers(farmers);

                    dbObject = DBHandler.getInstance(context).getDBObject(0);

                    List<RetailerInfoDTO> retailes = RetailerInfoDAO.getInstance().getRecordsForUpload(MyConstants.ACTIVITY_OSA, cursor.getLong(0), DBHandler.getInstance(context).getDBObject(0));
                    dto.setRetailers(retailes);

                    osaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return osaActivityInfo;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from OSA_ACTIVITY where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean deleteDataByDate(String date, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from OSA_ACTIVITY  where uploadedDate < '" + date + "' and isSync = '0'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM OSA_ACTIVITY where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }
}
