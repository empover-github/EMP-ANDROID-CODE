/**
 * class files for all the DAO's
 */

package com.activitytrack.masterdaos;


import java.util.List;

import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;


public interface MasterDAO
{	
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject);
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject);
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject);
	public List<DTO> getRecords(SQLiteDatabase dbObject);
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject);
}
