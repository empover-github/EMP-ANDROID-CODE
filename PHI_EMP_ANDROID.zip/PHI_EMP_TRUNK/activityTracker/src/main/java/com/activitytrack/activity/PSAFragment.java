package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.CompoundButtonCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.daos.DemandSummaryDAO;
import com.activitytrack.daos.FarmerEntryDAO;
import com.activitytrack.daos.PSAActivityDAO;
import com.activitytrack.daos.RetailerInfoDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.DemandSummaryDTO;
import com.activitytrack.dtos.PSAActivityDTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdtos.HybridMasterDTO;
import com.activitytrack.masterdtos.SeasonCalendarDTO;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.FragmentIntentIntegrator;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.CAMERA;

public class PSAFragment extends BaseFragment {

    private View view;

    private RelativeLayout pdaLayout;
    private RelativeLayout osaLayout;
    private ImageView psaIcon;
    private View psaBottomIcon;
    private TextView psaText;
    private LinearLayout addFarmers;
    private LinearLayout addRetailer;

    private TextView tvNumberOfFarmers;
    private TextView tvNumberofRetailers;
    private TextView tvCompetitorHybrid1;
    private TextView tv30v92Yield;
    private TextView tvCompetitorYield1;
    private TextView tvPincode;
    //newly added
    private TextView tvIsTblParticipated;
    private TextView tvNumberOfPravaktas;
    private EditText edtNumberOfFarmers;
    private EditText edtNumberOfPravaktas;

    private EditText edtNumberofRetailers;
    private EditText edtCompetitorHybrid1;
    private EditText edtPincode;
    //private EditText edt30v92Yield;
    //private EditText edtCompetitorYield1;
    private LinearLayout mainLayout;

    private Spinner spnActivityType;
    private Spinner spnCropType;
    private Spinner spnHybridType;
    private String[] activitiesArray;
    private List<String> hybridNamesList = new ArrayList<String>();
    private List<DTO> hybridIdDTOList = new ArrayList<DTO>();
    private long hybridId;
    private List<String> cropNameList = new ArrayList<String>();

    private List<DTO> seasonDTOList = new ArrayList<DTO>();
    private long cropId;

    private Button btnSubmit;
    private Button btnCouponButton;
    private long activityId;
    private TextView tvAddFarmersCount;
    private TextView tvAddRetailerCount;
    private TextView tvAddAttendanceCount;
    private LinearLayout addFarmersCount;
    private LinearLayout addRetailerCount;
    private RelativeLayout addAttendanceCount;

    private long seasonId;

    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;

    String mCouponCode = "";
    private int scanCounter = 1;
    //    private StringBuilder farmerBarCodeBuilder;
    private String farmerBarCodeBuilder = null;
    private boolean isFinalScan;

    // newly added
    private RadioGroup radioGroisTblParticipated;
    private RadioButton radioButisTblParticipatedYes, radioButisTblParticipatedNo;

    //newly added for faw
    private LinearLayout layoutFaw;
    private String cropName, hybridName;
    private CheckBox psa_faw_cb;
    //newly added for faw
    private TextView tvFaw;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        cropId = bundle.getInt("cropId");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.psa_fragment, container, false);

        pdaLayout = (RelativeLayout) view.findViewById(R.id.activity_pda_layout);
        osaLayout = (RelativeLayout) view.findViewById(R.id.activity_osa_layout);
        psaIcon = (ImageView) view.findViewById(R.id.activity_psa);
        psaBottomIcon = view.findViewById(R.id.activity_psa_bottom);
        psaText = (TextView) view.findViewById(R.id.activity_psaText);

        psaIcon.setImageResource(R.drawable.psa_top_menu_icon_f);
        psaBottomIcon.setVisibility(View.VISIBLE);
        psaText.setTextColor(getResources().getColor(R.color.tab_activeText_color));

        addFarmers = (LinearLayout) view.findViewById(R.id.psa_addFarmers);
        addRetailer = (LinearLayout) view.findViewById(R.id.psa_addRetailer);

        osaLayout.setOnClickListener(new OSATabListener());
        pdaLayout.setOnClickListener(new PDATabListener());

        tvNumberOfFarmers = (TextView) view.findViewById(R.id.psa_numberOfFarmers_l);
        tvNumberofRetailers = (TextView) view.findViewById(R.id.psa_numberOfRetailers_l);
        tvCompetitorHybrid1 = (TextView) view.findViewById(R.id.psa_competitorHybrid1_l);
        tv30v92Yield = (TextView) view.findViewById(R.id.psa_30v92Yield_l);
        tvCompetitorYield1 = (TextView) view.findViewById(R.id.psa_competitorYeild_l);
        tvPincode = (TextView) view.findViewById(R.id.psa_pincode_l);
        btnCouponButton = (Button) view.findViewById(R.id.psa_couponButton);

        edtNumberOfFarmers = (EditText) view.findViewById(R.id.psa_numberOfFarmers);
        edtNumberofRetailers = (EditText) view.findViewById(R.id.psa_numberOfRetailers);
        edtCompetitorHybrid1 = (EditText) view.findViewById(R.id.psa_competitorHybrid1);
        edtPincode = (EditText) view.findViewById(R.id.psa_pincode);
        //edt30v92Yield=(EditText)view.findViewById(R.id.psa_30v92Yield);
        //edtCompetitorYield1=(EditText)view.findViewById(R.id.psa_competitorYeild);

        btnSubmit = (Button) view.findViewById(R.id.psa_submit);

        spnActivityType = (Spinner) view.findViewById(R.id.psa_activityType);
        spnCropType = (Spinner) view.findViewById(R.id.psa_cropType);
        spnHybridType = (Spinner) view.findViewById(R.id.psa_hybridType);

        activitiesArray = getResources().getStringArray(R.array.psa_spn1_items);

        tvAddFarmersCount = (TextView) view.findViewById(R.id.psa_addFarmersCir);
        tvAddRetailerCount = (TextView) view.findViewById(R.id.psa_addRetailerCir);
        tvAddAttendanceCount = (TextView) view.findViewById(R.id.psa_attendance_count);

        addFarmersCount = (LinearLayout) view.findViewById(R.id.psa_circle_addFarmers_l);
        addRetailerCount = (LinearLayout) view.findViewById(R.id.psa_circle_addRetailer_l);
        addAttendanceCount = (RelativeLayout) view.findViewById(R.id.psa_attendance_count_l);

        //newly added
        tvIsTblParticipated = (TextView) view.findViewById(R.id.psa_isTbl_l);
        tvNumberOfPravaktas = (TextView) view.findViewById(R.id.psa_numberOfPravakta_l);
        edtNumberOfPravaktas = (EditText) view.findViewById(R.id.psa_numberOfPravakta);

        radioGroisTblParticipated = (RadioGroup) view.findViewById(R.id.psa_isTbl_radio);
        radioButisTblParticipatedYes = (RadioButton) view.findViewById(R.id.psa_isTbl_radio_yes);
        radioButisTblParticipatedNo = (RadioButton) view.findViewById(R.id.psa_isTbl_radio_no);

        //newly added for Faw

        tvFaw = (TextView) view.findViewById(R.id.psa_isFaw_l);
        psa_faw_cb=(CheckBox)view.findViewById(R.id.psa_faw_cb);
        layoutFaw = (LinearLayout) view.findViewById(R.id.layout_psa_faw);


        ArrayAdapter<String> activitiesAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, activitiesArray);
        spnActivityType.setAdapter(activitiesAdapter);

        mainLayout = (LinearLayout) view.findViewById(R.id.psa_bg_layout);


        seasonDTOList = SeasonCalendarDAO.getInstance().getRecordInfoByValue("activityId", "" + MyConstants.ACTIVITY_PSA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
        if (seasonDTOList != null && seasonDTOList.size() > 0) {
            cropNameList.clear();
            for (DTO dto : seasonDTOList) {
                if (cropNameList.size() == 0) {
                    cropNameList.add(getResources().getString(R.string.select_crop));
                }
                SeasonCalendarDTO seasonCalendarDTO = (SeasonCalendarDTO) dto;
                cropNameList.add(seasonCalendarDTO.getCropName());
                seasonId = seasonCalendarDTO.getSeasonId();
            }
        }

        ArrayAdapter<String> cropAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, cropNameList);
        spnCropType.setAdapter(cropAdapter);
        if (cropId != 0)
            for (int i = 0; i < seasonDTOList.size(); i++) {
                SeasonCalendarDTO dto = (SeasonCalendarDTO) seasonDTOList.get(i);
                if (cropId == dto.getCropId())
                    spnCropType.setSelection(i + 1);
            }
        spnCropType.setOnItemSelectedListener(new OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> arg0, View view,
                                       int position, long id) {


                if (position > 0) {
                    SeasonCalendarDTO cropMasterDTO = (SeasonCalendarDTO) seasonDTOList.get(position - 1);
                    cropId = cropMasterDTO.getCropId();
                    hybridSpinnerPopulation(cropId);
                    //new added
                    //newly added for FAW
                    cropName = cropMasterDTO.getCropName();
                } else {
                    spnHybridType.setAdapter(null);
                    cropId = 0;
                }

                if (cropId > 0) {
                    String seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(cropId, MyConstants.ACTIVITY_PSA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
                    boolean res = Utility.isSeasonExpire(seasonEndDate, Utility.getCurrentformatedDate());
                    if (res) {
                        Utility.showAlert(mActivity, "", getResources().getString(R.string.seacal) + "PSA" + " of crop " + (Utility.getCropNameById((int) cropId)) + " is over");
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        activityId = Utility.getActivityId(mActivity);
        if (activityId == 0) {
            btnSubmit.setEnabled(false);
        } else {

            List<DTO> psaDTOList = PSAActivityDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));

            if (psaDTOList != null && psaDTOList.size() > 0) {
                //PSAActivityDTO psaDto = (PSAActivityDTO) psaDTOList.get(0);
//	        		if(psaDto.getActivityType() == null){
                List<DTO> farmersList = FarmerEntryDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                if (farmersList != null && farmersList.size() > 0) {
                    //set list size to textView
                    tvAddFarmersCount.setText(String.valueOf(farmersList.size()));
                    addFarmersCount.setVisibility(View.VISIBLE);

                } else {
                    //set empty to textView
                    tvAddFarmersCount.setText("");
                    addFarmersCount.setVisibility(View.INVISIBLE);
                }

                //get retailer size same as farmer(above)
                List<DTO> retailersList = RetailerInfoDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                if (retailersList != null && retailersList.size() > 0) {
                    //set list size to textView
                    tvAddRetailerCount.setText(String.valueOf(retailersList.size()));
                    addRetailerCount.setVisibility(View.VISIBLE);
                } else {
                    //set empty to textView
                    tvAddRetailerCount.setText("");
                    addRetailerCount.setVisibility(View.INVISIBLE);
                }


                if (farmersList.size() >= 1 && retailersList.size() >= 0) {
                    btnSubmit.setEnabled(true);
                }
//	        		}else{
//	        			btnSubmit.setEnabled(false);
//	            		activityId = 0;
//	            		Utility.setActivityId(0, mActivity);
//	        		}
                PSAActivityDTO dto = (PSAActivityDTO) psaDTOList.get(0);
                //Dummy
                String barcodes = dto.getFarmerAttendanceDetails();
                if (barcodes != null && !barcodes.isEmpty() && barcodes.split(",").length > 0) {
                    tvAddAttendanceCount.setText(String.valueOf(barcodes.split(",").length));
                    addAttendanceCount.setVisibility(View.VISIBLE);
                } else {
                    tvAddAttendanceCount.setText("");
                    addAttendanceCount.setVisibility(View.INVISIBLE);
                }

            } else {
                btnSubmit.setEnabled(false);
                activityId = 0;
                Utility.setActivityId(0, mActivity);
            }
        }

        setChange();

        btnCouponButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    if (activityId == 0) {
                        PSAActivityDTO psaDto = getDataObject();
                        psaDto.setIsSync(0);
                        activityId = PSAActivityDAO.getInstance().insertActivity(psaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                        }
                    } else {
                        PSAActivityDTO psaDto = getDataObject();
                        psaDto.setIsSync(0);
                        psaDto.setId(activityId);
                        PSAActivityDAO.getInstance().update(psaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    }
                } else {
                    Utility.showAlert(mActivity, "", validation);
                    return;
                }

                if (activityId > 0) {
                    if (android.os.Build.VERSION.SDK_INT >= 23) {
                        if (checkPermission()) {
                            scanQRCode(false);
                        }
                    } else {
                        scanQRCode(false);
                    }
                }
            }
        });

        btnSubmit.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    if (hybridId != 0) {
                        if (checkForLocation) {
                            if (location != null && location.length() > 0) {
                                attendanceCheck();
                            } else {
                                getCurrentLocation(mActivity);
                            }
                        } else {
                            attendanceCheck();
                        }
                    } else {
                        Utility.showAlert(mActivity, "Alert", getResources().getString(R.string.hybrids));
                    }

                } else {
                    Utility.showAlert(mActivity, "", validation);
                }
            }
        });


        addFarmers.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PSAActivityDTO psaDto = getDataObject();
                        psaDto.setIsSync(0);
                        activityId = PSAActivityDAO.getInstance().insertActivity(psaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                        }
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PSAActivityDTO psaDto = getDataObject();
                        psaDto.setIsSync(0);
                        psaDto.setId(activityId);
                        PSAActivityDAO.getInstance().update(psaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }

				/*if(activityId == 0){
                    PSAActivityDTO psaDto = new PSAActivityDTO();
					activityId = PSAActivityDAO.getInstance().insertActivity(psaDto, DBHandler.getInstance(mActivity).getDBObject(1));
					if(activityId >0){
						Utility.setActivityId(activityId, mActivity);
						DemandSummaryDTO summaryDTO = new DemandSummaryDTO();
						summaryDTO.setActivity(MyConstants.ACTIVITY_PSA);
						summaryDTO.setActivityId(activityId);
						summaryDTO.setDate(Utility.getCurrentDateFrm());
						summaryDTO.setFarmers(psaDto.getNumberOfFarmers());
						summaryDTO.setRetailers(psaDto.getNumberOfRetailers());
						summaryDTO.setCropId(psaDto.getCropId());
						summaryDTO.setHybridId(psaDto.getHybridId());
						summaryDTO.setSeasonId(psaDto.getSeasonId());
						DemandSummaryDAO.getInstance().insert(summaryDTO, DBHandler.getInstance(mActivity).getDBObject(1));
					}
				}*/

                if (activityId > 0) {
                    BaseFragment fragment = new FarmerEntryFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("activity", MyConstants.ACTIVITY_PSA);
                    bundle.putLong("activityId", activityId);
                    fragment.setArguments(bundle);
                    mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
                }
            }
        });

        addRetailer.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PSAActivityDTO psaDto = getDataObject();
                        psaDto.setIsSync(0);
                        activityId = PSAActivityDAO.getInstance().insertActivity(psaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                        }
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PSAActivityDTO psaDto = getDataObject();
                        psaDto.setIsSync(0);
                        psaDto.setId(activityId);
                        PSAActivityDAO.getInstance().update(psaDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }

                if (activityId > 0) {
                    BaseFragment fragment = new RetailerInfoFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("activity", MyConstants.ACTIVITY_PSA);
                    bundle.putLong("activityId", activityId);
                    fragment.setArguments(bundle);
                    mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
                }


            }
        });

        return view;
    }


    private void hybridSpinnerPopulation(long cropId) {
        hybridIdDTOList = HybridMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(mActivity).getDBObject(0));

        if (hybridIdDTOList != null && hybridIdDTOList.size() > 0) {
            hybridNamesList.clear();
            for (DTO dto : hybridIdDTOList) {
                if (hybridNamesList.size() == 0) {
                    hybridNamesList.add(getResources().getString(R.string.select_hybrid));
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                hybridNamesList.add(hybridMasterDTO.getHybridName());
            }
        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.noHybrid));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    mActivity.popFragments();
                }
            });

            builder.create().show();
        }


        ArrayAdapter<String> hybridIdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, hybridNamesList);

        spnHybridType.setAdapter(hybridIdAdapter);

        spnHybridType.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) hybridIdDTOList.get(position - 1);
                    hybridId = hybridMasterDTO.getId();
                    tv30v92Yield.setText((hybridMasterDTO.getHybridName() + " Yield(Qtl/Acer)"));
                    //newly added for hybirdName
                    hybridName = hybridMasterDTO.getHybridName();
                    //newly added for faw
                    if (cropId == (MyConstants.CROP_CORN_ID) && cropName.equalsIgnoreCase(MyConstants.CROP_CORN)) {
                        if (!hybridName.equalsIgnoreCase(MyConstants.FAW)) {
                            layoutFaw.setVisibility(View.VISIBLE);
                        } else {
                            layoutFaw.setVisibility(View.GONE);
                            if (psa_faw_cb.isChecked()){
                                psa_faw_cb.setChecked(false);
                            }
                        }

                    }

                } else {
                    tv30v92Yield.setText("Yield(Qtl/Acer)");
                    populate();
                    //newly added for faw
                    layoutFaw.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }


    private String validateFields() {
        if (spnActivityType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.activity);

        if (spnCropType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.crop);

        if (spnHybridType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.hybrid);

        if (edtNumberOfFarmers.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.nofarmemp);

        //newly added
        if (edtNumberOfPravaktas.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.nopravemp);

        if (edtNumberofRetailers.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.noretemp);


        if (edtCompetitorHybrid1.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.comhybemp);

        if (edtPincode.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.pincode);

        if (edtPincode.getText().toString().trim().length() < 6) {
            return getResources().getString(R.string.zeropincode);
        }

        //newly added
        if (radioGroisTblParticipated.getCheckedRadioButtonId() == -1) {
            return getResources().getString(R.string.isTblEmpty);
        }

		/*if(edt30v92Yield.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.hybyiemp);
		
		
		if(edtCompetitorYield1.getText().toString().trim().length( ) == 0)
			return getResources().getString(R.string.comyiemp);*/

		/*if(edtCouponScan1.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.couponUpload) ;*/

        return "";
    }

    private void attendanceCheck() {
        if (farmerBarCodeBuilder != null && !farmerBarCodeBuilder.isEmpty()) {
            showAlertToSave();
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setMessage(getResources().getString(R.string.scan_QR_confirmation));
            builder.setPositiveButton(getResources().getString(R.string.scan), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    scanQRCode(true);
                }
            });
            builder.setNegativeButton(getResources().getString(R.string.save), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    saveData();
                }
            });
            builder.create().show();
        }
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                saveData();
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();

    }

    private void saveData() {
        PSAActivityDTO dto = getDataObject();


        long seasonCalId = SeasonCalendarDAO.getInstance().getSeasonCalId(MyConstants.ACTIVITY_PSA_ID, cropId, DBHandler.getInstance(mActivity).getDBObject(0));
        dto.setSeasonCalendarId(seasonCalId);

        String seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(cropId, MyConstants.ACTIVITY_PSA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
        boolean res = Utility.isSeasonExpire(seasonEndDate, Utility.getCurrentformatedDate());
        if (res) {
            Utility.showAlert(mActivity, "", getResources().getString(R.string.seasonExp));
            return;
        }

        long regionId = MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
        if (regionId != 0)
            dto.setRegionId(regionId);

        boolean updateAck = PSAActivityDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
        if (updateAck) {
            DemandSummaryDTO summaryDTO = new DemandSummaryDTO();


            //summaryDTO.setDate(Utility.getCurrentDateFrm());
            summaryDTO.setActivityId(MyConstants.ACTIVITY_PSA_ID);
            summaryDTO.setSampleCount(1);
            summaryDTO.setHybridId(dto.getHybridId());
            summaryDTO.setCropId(dto.getCropId());
            summaryDTO.setSeasonCalendarId(dto.getSeasonCalendarId());
            summaryDTO.setSeasonId(dto.getSeasonId());
            summaryDTO.setRetailerCount(dto.getNumberOfRetailers());
            summaryDTO.setFarmerCount(dto.getNumberOfFarmers());
            summaryDTO.setIsSync(1);
            DemandSummaryDAO.getInstance().insert(summaryDTO, DBHandler.getInstance(mActivity).getDBObject(1));
            btnSubmit.setEnabled(false);
            Utility.showAlert(mActivity, null, MyConstants.SUC_MSG);
            clearFields();
            activityId = 0;
            Utility.setActivityId(activityId, mActivity);
        }
    }

    private void setChange() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            tvNumberOfFarmers.setTextColor(Color.WHITE);
            tvNumberofRetailers.setTextColor(Color.WHITE);
            tv30v92Yield.setTextColor(Color.WHITE);
            tvCompetitorHybrid1.setTextColor(Color.WHITE);
            tvCompetitorYield1.setTextColor(Color.WHITE);
            tvPincode.setTextColor(Color.WHITE);
            //newly added
            tvIsTblParticipated.setTextColor(Color.WHITE);
            tvNumberOfPravaktas.setTextColor(Color.WHITE);

            // newly added
            radioButisTblParticipatedYes.setTextColor(Color.WHITE);
            radioButisTblParticipatedNo.setTextColor(Color.WHITE);

            // newly added for faw
            tvFaw.setTextColor(Color.WHITE);
            psa_faw_cb.setTextColor(Color.WHITE);

            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedYes, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedNo, ColorStateList.valueOf(Color.WHITE));

                //newly added for Faw
                CompoundButtonCompat.setButtonTintList(psa_faw_cb, ColorStateList.valueOf(Color.WHITE));
            } else {
                radioButisTblParticipatedYes.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButisTblParticipatedNo.setButtonTintList(ColorStateList.valueOf(Color.WHITE));

                //newly added for faw
                psa_faw_cb.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
            }

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            tvNumberOfFarmers.setTextColor(Color.BLACK);
            tvNumberofRetailers.setTextColor(Color.BLACK);
            tv30v92Yield.setTextColor(Color.BLACK);
            tvCompetitorHybrid1.setTextColor(Color.BLACK);
            tvCompetitorYield1.setTextColor(Color.BLACK);
            tvPincode.setTextColor(Color.BLACK);

            //newly added
            tvIsTblParticipated.setTextColor(Color.BLACK);
            tvNumberOfPravaktas.setTextColor(Color.BLACK);
            //newly added for faw
            tvFaw.setTextColor(Color.BLACK);

            // newly added
            radioButisTblParticipatedYes.setTextColor(Color.BLACK);
            radioButisTblParticipatedNo.setTextColor(Color.BLACK);

            //newly added for Faw
            psa_faw_cb.setTextColor(Color.BLACK);

            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedYes, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButisTblParticipatedNo, ColorStateList.valueOf(Color.BLACK));

                //newly added for Faw
                CompoundButtonCompat.setButtonTintList(psa_faw_cb, ColorStateList.valueOf(Color.BLACK));
            } else {
                radioButisTblParticipatedYes.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButisTblParticipatedNo.setButtonTintList(ColorStateList.valueOf(Color.BLACK));

                //newly added for Faw
                psa_faw_cb.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
            }

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }
    }

    private void clearFields() {
        spnActivityType.setSelection(0);
        spnCropType.setSelection(0);
        spnHybridType.setSelection(0);
        edtNumberOfFarmers.setText("");
        edtNumberofRetailers.setText("");
        edtCompetitorHybrid1.setText("");
        edtPincode.setText("");
        //newlya dded
        radioGroisTblParticipated.clearCheck();
        edtNumberOfPravaktas.setText("");
        tvAddAttendanceCount.setText("");
        /*edt30v92Yield.setText("");
        edtCompetitorYield1.setText("");*/
        addAttendanceCount.setVisibility(View.INVISIBLE);
        addFarmersCount.setVisibility(View.INVISIBLE);
        addRetailerCount.setVisibility(View.INVISIBLE);
        checkForLocation = true;
        location = null;
        farmerBarCodeBuilder = null;

        //newly addd for faw
        psa_faw_cb.setChecked(false);
    }

    private class PDATabListener implements OnClickListener {

        public void onClick(View v) {
            if (activityId != 0) {
                showAlertToExitPDA();
            } else if (isDataAvailable()) {
                showAlertToExitPDA();
            } else {
                mActivity.popFragments();
                BaseFragment fragment = new PDAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }
        }

    }

    private class OSATabListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            if (activityId != 0) {
                showAlertToExitOSA();
            } else if (isDataAvailable()) {
                showAlertToExitOSA();
            } else {
                mActivity.popFragments();
                BaseFragment fragment = new OSAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }

        }
    }

    private void showAlertToExitOSA() {

        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setTitle(getResources().getString(R.string.exit));
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activityId > 0)
                    clearLinkedData(activityId);
                mActivity.popFragments();
                BaseFragment fragment = new OSAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void showAlertToExitPDA() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setTitle(getResources().getString(R.string.exit));
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activityId > 0)
                    clearLinkedData(activityId);
                mActivity.popFragments();
                BaseFragment fragment = new PDAFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("cropId", 0);
                fragment.setArguments(bundle);
                mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void clearLinkedData(long activityId) {
        RetailerInfoDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
        FarmerEntryDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
        PSAActivityDAO.getInstance().deleteTableDataById(activityId, DBHandler.getInstance(mActivity).getDBObject(1));
        Utility.setActivityId(0, mActivity);

    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        if (isDataAvailable()) {
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }
        return true;
    }

    private void showAlertToExitScreen(final int callbackCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activityId > 0) {
                    RetailerInfoDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                    FarmerEntryDAO.getInstance().deleteTableDataById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                    PSAActivityDAO.getInstance().deleteTableDataById(activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                    Utility.setActivityId(0, mActivity);
                }

                mActivity.onBackPressedCallBack(callbackCode);
            }
        });

        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    private boolean isDataAvailable() {
        if (activityId > 0) {
            List<DTO> farmersList = FarmerEntryDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (farmersList != null && farmersList.size() > 0) {
                return true;
            }

            List<DTO> retailersList = RetailerInfoDAO.getInstance().getRecordInfoById(MyConstants.ACTIVITY_PSA, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (retailersList != null && retailersList.size() > 0) {
                return true;
            }
        }

        if (spnActivityType.getSelectedItemPosition() > 0)
            return true;

        if (spnHybridType.getSelectedItemPosition() > 0)
            return true;

        if (edtNumberOfFarmers.getText().toString().trim().length() > 0)
            return true;
        //newly added
        if (edtNumberOfPravaktas.getText().toString().trim().length() > 0)
            return true;

        if (edtNumberofRetailers.getText().toString().trim().length() > 0)
            return true;

        if (edtCompetitorHybrid1.getText().toString().trim().length() > 0)
            return true;

        if (edtPincode.getText().toString().trim().length() > 0)
            return true;

        //newly added
        if (radioButisTblParticipatedYes.isChecked())
            return true;
        if (radioButisTblParticipatedNo.isChecked())
            return true;


		/*if(edt30v92Yield.getText().toString().trim().length() > 0)
            return true;
		
		if(edtCompetitorYield1.getText().toString().trim().length() > 0)
			return true;*/

		/*if(edtCouponScan1.getText().toString().trim().length() > 0)
            return true;*/

        return false;
    }


    private PSAActivityDTO getDataObject() {
        PSAActivityDTO dto = new PSAActivityDTO();

        dto.setActivityType(activitiesArray[spnActivityType.getSelectedItemPosition()]);
        dto.setCropId(cropId);
        dto.setHybridId(hybridId);
        dto.setNumberOfFarmers(Integer.valueOf(edtNumberOfFarmers.getText().toString().trim()));
        dto.setNumberOfRetailers(Integer.valueOf(edtNumberofRetailers.getText().toString().trim()));
        dto.setCompetitorHybrid1(edtCompetitorHybrid1.getText().toString().trim());
        //newly added
        dto.setNumberOfPravaktas(Integer.valueOf(edtNumberOfPravaktas.getText().toString().trim()));
        /*if (farmerBarCodeBuilder != null)
            dto.setFarmerBarCodeDetails(farmerBarCodeBuilder.toString());*/
        if (farmerBarCodeBuilder != null)
            dto.setFarmerAttendanceDetails(farmerBarCodeBuilder);
		/*dto.setHybridAcres(Float.valueOf(edt30v92Yield.getText().toString()));
		dto.setCompetitorYield(Float.valueOf(edtCompetitorYield1.getText().toString().trim()));*/
        dto.setDate(Utility.getCurrentDateAndTime());
        dto.setLocation(location);
        dto.setId(activityId);
        dto.setIsSync(1);
        dto.setSeasonId(seasonId);
        dto.setPincode(edtPincode.getText().toString().trim());
        //new added
        dto.setIsTBLParticipated(radioButtonText(radioGroisTblParticipated));
        //newly added for Faw

        if (layoutFaw.getVisibility() == View.VISIBLE) {
            if (psa_faw_cb.isChecked()) {
                dto.setIsFAWDone(getResources().getString(R.string.YES));
            }else{
                dto.setIsFAWDone(getResources().getString(R.string.NO));
            }
        }else{
            dto.setIsFAWDone("");
        }

        return dto;
    }


    // newly added
    private String radioButtonText(RadioGroup group) {
        if (group != null) {
            int id = group.getCheckedRadioButtonId();
            RadioButton btn = (RadioButton) group.findViewById(id);
            String selection = (String) btn.getText();
            if (selection != null && !selection.isEmpty())
                return (selection);
            else return "";
        }
        return "";
    }

    private void populate() {
        if (activityId != 0) {
            List<DTO> dtoList = PSAActivityDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (dtoList != null && dtoList.size() > 0) {
                PSAActivityDTO dto = (PSAActivityDTO) dtoList.get(0);
                if (hybridIdDTOList != null && hybridIdDTOList.size() > 0) {
                    for (int i = 0; i < hybridIdDTOList.size(); i++) {
                        HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) hybridIdDTOList.get(i);
                        if (dto.getHybridId() == hybridMasterDTO.getId()) {
                            spnHybridType.setSelection(i + 1);
                            hybridId = hybridMasterDTO.getId();
                            tv30v92Yield.setText((hybridMasterDTO.getHybridName() + " Yield(Qtl/Acer)"));
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            if (!mGoogleApiClient.isConnected())
                mGoogleApiClient.connect();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mGoogleApiClient != null) {
            if (mGoogleApiClient.isConnected())
                mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onDestroy() {
        checkForLocation = true;
        location = null;
        super.onDestroy();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                DialogManager.showToast(mActivity, "Scan cancelled");
            } else {
                String scanResult = result.getContents();
                processCoupon(scanResult);
                if (isFinalScan)
                    saveData();
            }
        }
        /*if(resultCode == Activity.RESULT_OK)
        {
            String result = data.getStringExtra("SCAN_RESULT");
            currentScannedCouponCode = result.substring(0, result.indexOf('/'));
            processCoupon(scanCounter, AppConstants.COUPON_TYPE_SCANNED);
        }*/
    }

    private void processCoupon(String couponCode) {
        //Using StringBuilder
       /* if (farmerBarCodeBuilder != null && farmerBarCodeBuilder.toString().contains(couponCode))
            return;
        if (farmerBarCodeBuilder != null) {
            farmerBarCodeBuilder.append(",").append(couponCode);

        } else {
            farmerBarCodeBuilder = new StringBuilder();
            farmerBarCodeBuilder.append(couponCode);
        }
        String barcodes = farmerBarCodeBuilder.toString();
        if (barcodes != null && !barcodes.isEmpty() && barcodes.split(",").length > 0) {
            tvAddAttendanceCount.setText(String.valueOf(barcodes.split(",").length));
            addAttendanceCount.setVisibility(View.VISIBLE);
        } else {
            tvAddAttendanceCount.setText("");
            addAttendanceCount.setVisibility(View.INVISIBLE);
        }*/

        if (farmerBarCodeBuilder != null && farmerBarCodeBuilder.contains(couponCode))
            return;

        String specialCharacters = "_";
        String str2[] = couponCode.split("");
        int couponloop = 0;
        for (String aStr2 : str2) {
            if (specialCharacters.equals(aStr2)) {
                //System.out.println("true");
                couponloop++;
            }
        }

        if (couponloop == 3) {
            farmerBarCodeBuilder = couponCode;
        } else {
            DialogManager.showToast(mActivity, "Invalid QRcode");
        }

        if (farmerBarCodeBuilder != null && !farmerBarCodeBuilder.isEmpty()) {
            tvAddAttendanceCount.setText("1");
            addAttendanceCount.setVisibility(View.VISIBLE);
        } else {
            tvAddAttendanceCount.setText("");
            addAttendanceCount.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * @fun showMoreScanDialog
     * @brief Method to show dialog to select the option for scanning more ot not
     */
    private void showMoreScanDialog(String st_currentCoupanScanCode) {

        DialogManager.showConformPopup(getContext(), new DialogMangerCallback() {
            @Override
            public void onOkClick() {
                scanQRCode(false);
            }

            @Override
            public void onCancelClick(View view) {

            }
        }, getString(R.string.moreScanHeader), getString(R.string.scanned_code) + " " + st_currentCoupanScanCode, getString(R.string.scan_more), getString(R.string.no));
        /*AlertDialog.Builder scanResultDialog = new AlertDialog.Builder(getContext());
        scanResultDialog.setTitle(R.string.moreScanHeader);
        scanResultDialog.setMessage(getString(R.string.scanned_code)+" "+st_currentCoupanScanCode);
        scanResultDialog.setPositiveButton(R.string.scan_more, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
//                        new IntentIntegrator(BarCodeScanner.this).initiateScan();
                scanQRCode();

            }
        });
        scanResultDialog.setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        scanResultDialog.show();*/
    }


    private void scanQRCode(boolean isFinalScan) {
        //	Log.d(TAG, "inside scanQRCode()");

        //mIntent = new Intent(mContext, QRScannerActivity.class);
//        mIntent = new Intent("com.google.zxing.client.android.SCAN");
//        startActivityForResult(mIntent, requestCode);

//		Log.d(TAG, "Exitting scanQRcode()");
        this.isFinalScan = isFinalScan;
        FragmentIntentIntegrator integrator = new FragmentIntentIntegrator(this);
        integrator.setPrompt("Scan a barcode");
        integrator.setCameraId(0);  // Use a specific camera of the device
        integrator.setOrientationLocked(true);
        integrator.setBeepEnabled(true);
        integrator.setCaptureActivity(ATCaptureActivityPortrait.class);
        integrator.initiateScan();

    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(mActivity.getApplicationContext(), CAMERA) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, CAMERA)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(mActivity, new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Need Camera Permission", "This app needs camera permission to scan barcode.", getString(R.string.grant), getString(R.string.cancel));

               /* AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                builder.setTitle("Need Camera Permission");
                builder.setMessage("This app needs camera permission to scan barcode.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(mActivity, new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        //finish();
                    }
                });
                builder.show();*/

            } else {

                // No explanation needed, we can request the permission.
                if (Utility.isFirstTime(mActivity)) {
                    Utility.setFirstTime(false, mActivity);
                    requestPermissions(new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);

                    // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                    // app-defined int constant. The callback method gets the
                    // result of the request.
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        requestPermissions(new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION_DENAIL);
                    }
                }
            }
        } else {
            return true;
        }

        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    scanQRCode(false);
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
            case REQUEST_CAMERA_PERMISSION_DENAIL: {
                showDialogToOpenSetting();
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private void showDialogToOpenSetting() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(mActivity, mActivity.getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {
        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", mActivity.getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        mActivity.finish();
    }
}
