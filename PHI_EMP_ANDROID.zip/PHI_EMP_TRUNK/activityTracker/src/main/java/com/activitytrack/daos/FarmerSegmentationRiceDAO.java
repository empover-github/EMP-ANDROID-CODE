package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.SegmentationRequestDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class FarmerSegmentationRiceDAO implements DAO {

    private final String TAG = "segmentationRiceRequest";
    private static FarmerSegmentationRiceDAO farmerSegmentationRiceDAO;

    public static FarmerSegmentationRiceDAO getInstance() {
        if (farmerSegmentationRiceDAO == null) {
            farmerSegmentationRiceDAO = new FarmerSegmentationRiceDAO();
        }
        return farmerSegmentationRiceDAO;
    }

    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            SegmentationRequestDTO dto = (SegmentationRequestDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            cValues.put("year", dto.getYear());
            cValues.put("season", dto.getSeason());
            cValues.put("crop", dto.getCrop());
            cValues.put("mobileNo", dto.getMobileNo());
            cValues.put("pincode", dto.getPincode());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("district", dto.getDistrict());
            cValues.put("village", dto.getVillage());
            cValues.put("block", dto.getBlock());
            cValues.put("totalPlanAc", dto.getTotalPlanAc());
            cValues.put("hybridAc", dto.getHybridAc());
            cValues.put("typeOfIrrigation", dto.getTypeOfIrrigation());
            cValues.put("maturity124Ac", dto.getMaturity124Ac());
            cValues.put("maturity134Ac", dto.getMaturity134Ac());
            cValues.put("maturity135Ac", dto.getMaturity135Ac());
            cValues.put("riceHybrid1", dto.getRiceHybrid1());
            cValues.put("riceHybrid2", dto.getRiceHybrid2());
            cValues.put("riceHybrid3", dto.getRiceHybrid3());
            cValues.put("riceHybrid4", dto.getRiceHybrid4());
            cValues.put("riceHybridValue1", dto.getRiceHybridValue1());
            cValues.put("riceHybridValue2", dto.getRiceHybridValue2());
            cValues.put("riceHybridValue3", dto.getRiceHybridValue3());
            cValues.put("riceHybridValue4", dto.getRiceHybridValue4());
            cValues.put("riceServices", dto.getRiceServices());

            cValues.put("riceCompetitorHybrid1", dto.getRiceCompetitorHybrid1());
            cValues.put("riceCompetitorHybrid2", dto.getRiceCompetitorHybrid2());
            cValues.put("riceCompetitorHybrid3", dto.getRiceCompetitorHybrid3());
            cValues.put("riceCompetitorHybrid4", dto.getRiceCompetitorHybrid4());

            cValues.put("riceCompetitorHybridValue1", dto.getRiceCompetitorHybridValue1());
            cValues.put("riceCompetitorHybridValue2", dto.getRiceCompetitorHybridValue2());
            cValues.put("riceCompetitorHybridValue3", dto.getRiceCompetitorHybridValue3());
            cValues.put("riceCompetitorHybridValue4", dto.getRiceCompetitorHybridValue4());
            cValues.put("directSowingRice", dto.getDirectSowingRice());

            cValues.put("localImagePath", dto.getLocalImagePath());
            cValues.put("isTBL", dto.getIsTBL());
            cValues.put("timeStamp", dto.getDate());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("geoLocation", dto.getGeoLocation());

            long inserted = dbObject.insert("SEGMENTATION_RICE_REQUEST", null, cValues);

                return true;

        } catch (SQLException e) {

            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;


        } finally {
            dbObject.close();
        }
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            SegmentationRequestDTO dto = (SegmentationRequestDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getId() != 0)
                cValues.put("id", dto.getId());

            if (dto.getYear() != null)
                cValues.put("year", dto.getYear());

            if (dto.getSeason() != 0)
                cValues.put("season", dto.getSeason());

            if (dto.getCrop() != 0)
                cValues.put("crop", dto.getCrop());

            if (dto.getMobileNo() != null)
                cValues.put("mobileNo", dto.getMobileNo());

            if (dto.getPincode() != null)
                cValues.put("pincode", dto.getPincode());

            if (dto.getFarmerName() != null)
                cValues.put("farmerName", dto.getFarmerName());

            if (dto.getDistrict() != null)
                cValues.put("district", dto.getDistrict());

            if (dto.getVillage() != null)
                cValues.put("village", dto.getVillage());

            if (dto.getBlock() != null)
                cValues.put("block", dto.getBlock());

            if (dto.getTotalPlanAc() != 0)
                cValues.put("totalPlanAc", dto.getTotalPlanAc());

            if (dto.getHybridAc() != 0)
                cValues.put("hybridAc", dto.getHybridAc());

            if (dto.getTypeOfIrrigation() != null)
                cValues.put("typeOfIrrigation", dto.getTypeOfIrrigation());

            if (dto.getMaturity124Ac() != 0)
                cValues.put("maturity124Ac", dto.getMaturity124Ac());

            if (dto.getMaturity134Ac() != 0)
                cValues.put("maturity134Ac", dto.getMaturity134Ac());

            if (dto.getMaturity135Ac() != 0)
                cValues.put("maturity135Ac", dto.getMaturity135Ac());

            if (dto.getRiceHybrid1() != null)
                cValues.put("riceHybrid1", dto.getRiceHybrid1());

            if (dto.getRiceHybrid2() != null)
                cValues.put("riceHybrid2", dto.getRiceHybrid2());

            if (dto.getRiceHybrid3() != null)
                cValues.put("riceHybrid3", dto.getRiceHybrid3());

            if (dto.getRiceHybrid4() != null)
                cValues.put("riceHybrid4", dto.getRiceHybrid4());

            if (dto.getRiceHybridValue1() != 0)
                cValues.put("riceHybridValue1", dto.getRiceHybridValue1());

            if (dto.getRiceHybridValue2() != 0)
                cValues.put("riceHybridValue2", dto.getRiceHybridValue2());

            if (dto.getRiceHybridValue3() != 0)
                cValues.put("riceHybridValue3", dto.getRiceHybridValue3());

            if (dto.getRiceHybridValue4() != 0)
                cValues.put("riceHybridValue4", dto.getRiceHybridValue4());

            if (dto.getRiceServices() != null)
                cValues.put("riceServices", dto.getRiceServices());

            if (dto.getRiceCompetitorHybrid1() != null)
                cValues.put("riceCompetitorHybrid1", dto.getRiceCompetitorHybrid1());

            if (dto.getRiceCompetitorHybrid2() != null)
                cValues.put("riceCompetitorHybrid2", dto.getRiceCompetitorHybrid2());

            if (dto.getRiceCompetitorHybrid3() != null)
                cValues.put("riceCompetitorHybrid3", dto.getRiceCompetitorHybrid3());

            if (dto.getRiceCompetitorHybrid4() != null)
                cValues.put("riceCompetitorHybrid4", dto.getRiceCompetitorHybrid4());

            if (dto.getRiceCompetitorHybridValue1() != 0)
                cValues.put("riceCompetitorHybridValue1", dto.getRiceCompetitorHybridValue1());

            if (dto.getRiceCompetitorHybridValue2() != 0)
                cValues.put("riceCompetitorHybridValue2", dto.getRiceCompetitorHybridValue2());

            if (dto.getRiceCompetitorHybridValue3() != 0)
                cValues.put("riceCompetitorHybridValue3", dto.getRiceCompetitorHybridValue3());

            if (dto.getRiceCompetitorHybridValue4() != 0)
                cValues.put("riceCompetitorHybridValue4", dto.getRiceCompetitorHybridValue4());

            if (dto.getDirectSowingRice() != null)
                cValues.put("directSowingRice", dto.getDirectSowingRice());

            if (dto.getLocalImagePath() != null)
                cValues.put("localImagePath", dto.getLocalImagePath());


            if (dto.getIsTBL() != null)
                cValues.put("isTBL", dto.getIsTBL());
            if (dto.getDate() != null)
                cValues.put("timeStamp", dto.getDate());


                cValues.put("isSync", dto.getIsSync());

            if (dto.getGeoLocation() != null)
                cValues.put("geoLocation", dto.getGeoLocation());

            dbObject.update("SEGMENTATION_RICE_REQUEST", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_RICE_REQUEST ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setHybridAc(cursor.getFloat(cursor.getColumnIndex("hybridAc")));
                    dto.setTypeOfIrrigation(cursor.getString(cursor.getColumnIndex("typeOfIrrigation")));
                    dto.setMaturity124Ac(cursor.getFloat(cursor.getColumnIndex("maturity124Ac")));
                    dto.setMaturity134Ac(cursor.getFloat(cursor.getColumnIndex("maturity134Ac")));
                    dto.setMaturity135Ac(cursor.getFloat(cursor.getColumnIndex("maturity135Ac")));
                    dto.setRiceHybrid1(cursor.getString(cursor.getColumnIndex("riceHybrid1")));
                    dto.setRiceHybrid2(cursor.getString(cursor.getColumnIndex("riceHybrid2")));
                    dto.setRiceHybrid3(cursor.getString(cursor.getColumnIndex("riceHybrid3")));
                    dto.setRiceHybrid4(cursor.getString(cursor.getColumnIndex("riceHybrid4")));
                    dto.setRiceHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceHybridValue1")));
                    dto.setRiceHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceHybridValue2")));
                    dto.setRiceHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceHybridValue3")));
                    dto.setRiceHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceHybridValue4")));
                    dto.setRiceServices(cursor.getString(cursor.getColumnIndex("riceServices")));
                    dto.setRiceCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid1")));
                    dto.setRiceCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid2")));
                    dto.setRiceCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid3")));
                    dto.setRiceCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid4")));
                    dto.setRiceCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue1")));
                    dto.setRiceCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue2")));
                    dto.setRiceCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue3")));
                    dto.setRiceCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue4")));
                    dto.setDirectSowingRice(cursor.getString(cursor.getColumnIndex("directSowingRice")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));

                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    @Override

    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> getRecordsListByValue = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_RICE_REQUEST where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setHybridAc(cursor.getFloat(cursor.getColumnIndex("hybridAc")));
                    dto.setTypeOfIrrigation(cursor.getString(cursor.getColumnIndex("typeOfIrrigation")));
                    dto.setMaturity124Ac(cursor.getFloat(cursor.getColumnIndex("maturity124Ac")));
                    dto.setMaturity134Ac(cursor.getFloat(cursor.getColumnIndex("maturity134Ac")));
                    dto.setMaturity135Ac(cursor.getFloat(cursor.getColumnIndex("maturity135Ac")));
                    dto.setRiceHybrid1(cursor.getString(cursor.getColumnIndex("riceHybrid1")));
                    dto.setRiceHybrid2(cursor.getString(cursor.getColumnIndex("riceHybrid2")));
                    dto.setRiceHybrid3(cursor.getString(cursor.getColumnIndex("riceHybrid3")));
                    dto.setRiceHybrid4(cursor.getString(cursor.getColumnIndex("riceHybrid4")));
                    dto.setRiceHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceHybridValue1")));
                    dto.setRiceHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceHybridValue2")));
                    dto.setRiceHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceHybridValue3")));
                    dto.setRiceHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceHybridValue4")));
                    dto.setRiceServices(cursor.getString(cursor.getColumnIndex("riceServices")));
                    dto.setRiceCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid1")));
                    dto.setRiceCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid2")));
                    dto.setRiceCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid3")));
                    dto.setRiceCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid4")));
                    dto.setRiceCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue1")));
                    dto.setRiceCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue2")));
                    dto.setRiceCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue3")));
                    dto.setRiceCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue4")));
                    dto.setDirectSowingRice(cursor.getString(cursor.getColumnIndex("directSowingRice")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    getRecordsListByValue.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return getRecordsListByValue;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM SEGMENTATION_RICE_REQUEST").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from SEGMENTATION_RICE_REQUEST where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }


    public boolean deleteTableDataById(long id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM SEGMENTATION_RICE_REQUEST where id = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }


    public List<SegmentationRequestDTO> getAllRecords(SQLiteDatabase dbObject) {
        List<SegmentationRequestDTO> allRecordsList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_RICE_REQUEST", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setHybridAc(cursor.getFloat(cursor.getColumnIndex("hybridAc")));
                    dto.setTypeOfIrrigation(cursor.getString(cursor.getColumnIndex("typeOfIrrigation")));
                    dto.setMaturity124Ac(cursor.getFloat(cursor.getColumnIndex("maturity124Ac")));
                    dto.setMaturity134Ac(cursor.getFloat(cursor.getColumnIndex("maturity134Ac")));
                    dto.setMaturity135Ac(cursor.getFloat(cursor.getColumnIndex("maturity135Ac")));
                    dto.setRiceHybrid1(cursor.getString(cursor.getColumnIndex("riceHybrid1")));
                    dto.setRiceHybrid2(cursor.getString(cursor.getColumnIndex("riceHybrid2")));
                    dto.setRiceHybrid3(cursor.getString(cursor.getColumnIndex("riceHybrid3")));
                    dto.setRiceHybrid4(cursor.getString(cursor.getColumnIndex("riceHybrid4")));
                    dto.setRiceHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceHybridValue1")));
                    dto.setRiceHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceHybridValue2")));
                    dto.setRiceHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceHybridValue3")));
                    dto.setRiceHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceHybridValue4")));
                    dto.setRiceServices(cursor.getString(cursor.getColumnIndex("riceServices")));
                    dto.setRiceCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid1")));
                    dto.setRiceCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid2")));
                    dto.setRiceCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid3")));
                    dto.setRiceCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid4")));
                    dto.setRiceCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue1")));
                    dto.setRiceCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue2")));
                    dto.setRiceCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue3")));
                    dto.setRiceCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue4")));
                    dto.setDirectSowingRice(cursor.getString(cursor.getColumnIndex("directSowingRice")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    allRecordsList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return allRecordsList;
    }

    public List<DTO> getRecordsById(long id, SQLiteDatabase dbObject) {

        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_RICE_REQUEST where id = '" + id + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setHybridAc(cursor.getFloat(cursor.getColumnIndex("hybridAc")));
                    dto.setTypeOfIrrigation(cursor.getString(cursor.getColumnIndex("typeOfIrrigation")));
                    dto.setMaturity124Ac(cursor.getFloat(cursor.getColumnIndex("maturity124Ac")));
                    dto.setMaturity134Ac(cursor.getFloat(cursor.getColumnIndex("maturity134Ac")));
                    dto.setMaturity135Ac(cursor.getFloat(cursor.getColumnIndex("maturity135Ac")));
                    dto.setRiceHybrid1(cursor.getString(cursor.getColumnIndex("riceHybrid1")));
                    dto.setRiceHybrid2(cursor.getString(cursor.getColumnIndex("riceHybrid2")));
                    dto.setRiceHybrid3(cursor.getString(cursor.getColumnIndex("riceHybrid3")));
                    dto.setRiceHybrid4(cursor.getString(cursor.getColumnIndex("riceHybrid4")));
                    dto.setRiceHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceHybridValue1")));
                    dto.setRiceHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceHybridValue2")));
                    dto.setRiceHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceHybridValue3")));
                    dto.setRiceHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceHybridValue4")));
                    dto.setRiceServices(cursor.getString(cursor.getColumnIndex("riceServices")));
                    dto.setRiceCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid1")));
                    dto.setRiceCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid2")));
                    dto.setRiceCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid3")));
                    dto.setRiceCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid4")));
                    dto.setRiceCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue1")));
                    dto.setRiceCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue2")));
                    dto.setRiceCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue3")));
                    dto.setRiceCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue4")));
                    dto.setDirectSowingRice(cursor.getString(cursor.getColumnIndex("directSowingRice")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    public List<SegmentationRequestDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<SegmentationRequestDTO> farmerSegmentationList = new ArrayList<SegmentationRequestDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_RICE_REQUEST where isSync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();


                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setHybridAc(cursor.getFloat(cursor.getColumnIndex("hybridAc")));
                    dto.setTypeOfIrrigation(cursor.getString(cursor.getColumnIndex("typeOfIrrigation")));
                    dto.setMaturity124Ac(cursor.getFloat(cursor.getColumnIndex("maturity124Ac")));
                    dto.setMaturity134Ac(cursor.getFloat(cursor.getColumnIndex("maturity134Ac")));
                    dto.setMaturity135Ac(cursor.getFloat(cursor.getColumnIndex("maturity135Ac")));
                    dto.setRiceHybrid1(cursor.getString(cursor.getColumnIndex("riceHybrid1")));
                    dto.setRiceHybrid2(cursor.getString(cursor.getColumnIndex("riceHybrid2")));
                    dto.setRiceHybrid3(cursor.getString(cursor.getColumnIndex("riceHybrid3")));
                    dto.setRiceHybrid4(cursor.getString(cursor.getColumnIndex("riceHybrid4")));
                    dto.setRiceHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceHybridValue1")));
                    dto.setRiceHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceHybridValue2")));
                    dto.setRiceHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceHybridValue3")));
                    dto.setRiceHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceHybridValue4")));
                    dto.setRiceServices(cursor.getString(cursor.getColumnIndex("riceServices")));
                    dto.setRiceCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid1")));
                    dto.setRiceCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid2")));
                    dto.setRiceCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid3")));
                    dto.setRiceCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid4")));
                    dto.setRiceCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue1")));
                    dto.setRiceCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue2")));
                    dto.setRiceCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue3")));
                    dto.setRiceCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue4")));
                    dto.setDirectSowingRice(cursor.getString(cursor.getColumnIndex("directSowingRice")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    farmerSegmentationList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return farmerSegmentationList;
    }


    public List<SegmentationRequestDTO> getRecordByList(SQLiteDatabase dbObject) {
        List<SegmentationRequestDTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_RICE_REQUEST ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setHybridAc(cursor.getFloat(cursor.getColumnIndex("hybridAc")));
                    dto.setTypeOfIrrigation(cursor.getString(cursor.getColumnIndex("typeOfIrrigation")));
                    dto.setMaturity124Ac(cursor.getFloat(cursor.getColumnIndex("maturity124Ac")));
                    dto.setMaturity134Ac(cursor.getFloat(cursor.getColumnIndex("maturity134Ac")));
                    dto.setMaturity135Ac(cursor.getFloat(cursor.getColumnIndex("maturity135Ac")));
                    dto.setRiceHybrid1(cursor.getString(cursor.getColumnIndex("riceHybrid1")));
                    dto.setRiceHybrid2(cursor.getString(cursor.getColumnIndex("riceHybrid2")));
                    dto.setRiceHybrid3(cursor.getString(cursor.getColumnIndex("riceHybrid3")));
                    dto.setRiceHybrid4(cursor.getString(cursor.getColumnIndex("riceHybrid4")));
                    dto.setRiceHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceHybridValue1")));
                    dto.setRiceHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceHybridValue2")));
                    dto.setRiceHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceHybridValue3")));
                    dto.setRiceHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceHybridValue4")));
                    dto.setRiceServices(cursor.getString(cursor.getColumnIndex("riceServices")));
                    dto.setRiceCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid1")));
                    dto.setRiceCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid2")));
                    dto.setRiceCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid3")));
                    dto.setRiceCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("riceCompetitorHybrid4")));
                    dto.setRiceCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue1")));
                    dto.setRiceCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue2")));
                    dto.setRiceCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue3")));
                    dto.setRiceCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("riceCompetitorHybridValue4")));
                    dto.setDirectSowingRice(cursor.getString(cursor.getColumnIndex("directSowingRice")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));

                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM SEGMENTATION_RICE_REQUEST where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }
}