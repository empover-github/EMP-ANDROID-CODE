package com.activitytrack.masterdtos;

import com.activitytrack.dtos.DTO;

/**
 * Created by hareesh.a on 7/5/2017.
 */

public class SegmentMasterDTO implements DTO {
    private long id;
    private String name;
    private long cropId;
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getSegmentName() {
        return name;
    }
    public void setSegmentName(String segmentName) {
        this.name = segmentName;
    }
    public long getCropId() {
        return cropId;
    }
    public void setCropId(long cropId) {
        this.cropId = cropId;
    }
}
