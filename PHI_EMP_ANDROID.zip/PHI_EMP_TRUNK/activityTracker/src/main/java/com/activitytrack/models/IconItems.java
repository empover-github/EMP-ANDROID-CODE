package com.activitytrack.models;

public class IconItems extends ExpandListItem {
    private String title;
    private int icon;
    private int position;

    public IconItems() {

    }

    public IconItems(String title, int icon) {

        this.title = title;
        this.icon = icon;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
