package com.activitytrack.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.Utility;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

public class GenerateCodeFragment extends BaseFragment {

    private View view;
    private String TAG = "";
    Bitmap bmp;
    private File mediaFile = null;
    private static final int REQUEST_STORAGE_PERMISSION = 102;
    private static final int REQUEST_STORAGE_PERMISSION_DENAIL = 103;
    private long mobileNo;
    private String customerId, deviceId;
    private ImageView generatedCodeImg;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        List<DTO> userDtoList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if (userDtoList != null && userDtoList.size() > 0) {
            MdrMasterDTO loginDTO = (MdrMasterDTO) userDtoList.get(0);
            customerId = loginDTO.getLoginId();
            mobileNo = loginDTO.getMobileNo();
        }
        deviceId = Utility.getDeviceId(mActivity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_generate_code, container, false);
        generatedCodeImg = (ImageView) view.findViewById(R.id.codeGeneratedImage);
        ImageView imgShare = (ImageView) view.findViewById(R.id.image_addBtn);

        long timeInMillis = Calendar.getInstance().getTimeInMillis();

        String codeText = customerId + "_" + mobileNo + "_" + deviceId + "_" + timeInMillis;
        try {
            bmp = generateQrCode(codeText);
            generatedCodeImg.setImageBitmap(bmp);
        } catch (WriterException e) {
            e.printStackTrace();
        }

        imgShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (ContextCompat.checkSelfPermission(mActivity,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            == PackageManager.PERMISSION_GRANTED) {
                        //Location Permission already granted
                        getImageStoredPath();
                    } else {
                        //Request Location Permission
                        checkPermission();
                    }
                }else {
                    getImageStoredPath();
                }
            }
        });
        return view;
    }


    public static Bitmap generateQrCode(String myCodeText) throws WriterException {
        Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<EncodeHintType, ErrorCorrectionLevel>();
        hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H); // H = 30% damage

        QRCodeWriter qrCodeWriter = new QRCodeWriter();

        int size = 256;

        BitMatrix bitMatrix = qrCodeWriter.encode(myCodeText, BarcodeFormat.QR_CODE, 512, 512);

//        BitMatrix bitMatrix = qrCodeWriter.encode(myCodeText, BarcodeFormat.QR_CODE, size, size, hintMap);
//        int width = bitMatrix.width();

        int width = 512;
        int height = 512;
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
//                bmp.setPixel(y, x, bitMatrix.get(x, y)==0 ? Color.BLACK : Color.WHITE);
                boolean val = bitMatrix.get(x, y);
                if (val)
                    bmp.setPixel(x, y, Color.BLACK);
                else
                    bmp.setPixel(x, y, Color.WHITE);
            }
        }
        return bmp;
    }

    private Boolean getImageStoredPath() {

        //Storing image in internal storage
        if (bmp != null) {
            storeImage(bmp);
        }

        // share found
        Uri u = null;
        if (mediaFile != null) {
            u = Uri.fromFile(mediaFile);
            Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
            emailIntent.setType("application/image");
            emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, "");
            emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
            emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
            emailIntent.putExtra(Intent.EXTRA_STREAM, u);
           // emailIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));

            return true;

        } else {
            DialogManager.showToast(mActivity, "Storage Path is not define");
        }

        return false;
    }

    private void storeImage(Bitmap image) {
        File pictureFile = getOutputMediaFile();
        if (pictureFile == null) {
            ATBuildLog.d(TAG,
                    "Error creating media file, check storage permissions: ");// e.getMessage());
            checkPermission();
            return;
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            ATBuildLog.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            ATBuildLog.d(TAG, "Error accessing file: " + e.getMessage());
        }
    }
//
//    *
//     * Create a File for saving an image or video
//
    private File getOutputMediaFile() {
// To be safe, you should check that the SDCard is mounted
// using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new
                File(Environment.getExternalStorageDirectory()
                + "/Android/data/"
                + mActivity.getPackageName()
                + "/Files");

// This location works best if you want the created images to be shared
// between applications and persist after your app has been uninstalled.

// Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }
// Create a media file name
        String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmm").format(new Date());
        String mImageName = "MI_" + timeStamp + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator + mImageName);
        return mediaFile;
    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Need Storage Permission", "This app needs Storage permission to demonize the crop.", getString(R.string.grant), getString(R.string.cancel));

               /* AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                builder.setTitle("Need Camera Permission");
                builder.setMessage("This app needs camera permission to scan barcode.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(mActivity, new String[]{CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        //finish();
                    }
                });
                builder.show();*/
            } else {
                // No explanation needed, we can request the permission.
                if (Utility.isFirstTime(mActivity)) {
                    Utility.setFirstTime(false, mActivity);
                    ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION);
                    //requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);

                    // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                    // app-defined int constant. The callback method gets the
                    // result of the request.
                } else {
                    ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION_DENAIL);
                    //requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }

        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_refresh) {
            long timeInMillis = Calendar.getInstance().getTimeInMillis();

            String codeText1 = customerId + "_" + mobileNo + "_" + deviceId + "_" + timeInMillis;
            try {
                bmp = generateQrCode(codeText1);
                generatedCodeImg.setImageBitmap(bmp);
            } catch (WriterException e) {
                e.printStackTrace();
            }


            return super.onOptionsItemSelected(item);
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        mActivity.onBackPressedCallBack(callbackCode);
    return true;
    }
}
