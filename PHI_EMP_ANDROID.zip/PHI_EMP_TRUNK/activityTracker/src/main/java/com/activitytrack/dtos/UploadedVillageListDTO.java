package com.activitytrack.dtos;

/**
 * Created by fatima.t on 01-05-2018.
 */

public class UploadedVillageListDTO implements DTO{
    private long id;
    private String villageName;
    private String season;
    private String crop;
    private String uploadedDate;
    private String sno;

    public UploadedVillageListDTO(String sno, String villageName, String season, String crop, String uploadedDate) {
        this.sno = sno;
        this.villageName = villageName;
        this.season = season;
        this.crop = crop;
        this.uploadedDate = uploadedDate;

    }

    public UploadedVillageListDTO(){}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(String uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }
}
