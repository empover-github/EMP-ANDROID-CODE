package com.activitytrack.interfaces;

/**
 * Created by Yakaswamy.g on 7/13/2017.
 */

public interface AsyncTaskCompleteListener {
    void onAsynComplete(String result);
}
