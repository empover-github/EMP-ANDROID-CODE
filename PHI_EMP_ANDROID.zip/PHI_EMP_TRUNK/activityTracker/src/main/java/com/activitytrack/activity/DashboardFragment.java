package com.activitytrack.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class DashboardFragment extends BaseFragment {
	
	private View view;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.agronomy_dashboard_fragment, container, false);
		
		return view;
	}
	
	@Override
	public boolean onBackPressed(int callbackCode) {
		mActivity.onBackPressedCallBack(callbackCode);
		return true;
	}

}
