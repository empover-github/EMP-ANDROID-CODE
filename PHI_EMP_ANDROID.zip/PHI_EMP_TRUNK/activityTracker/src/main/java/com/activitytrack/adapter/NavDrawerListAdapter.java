package com.activitytrack.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.listeners.OnListItemClickListener;

import java.util.ArrayList;

public class NavDrawerListAdapter extends RecyclerView.Adapter<NavDrawerListAdapter.MYHolder> {

    private Context context;
    private ArrayList<NavDrawerItem> navDrawerItems;
    private OnListItemClickListener listener;

    public NavDrawerListAdapter(Context context,
                                ArrayList<NavDrawerItem> navDrawerItems, OnListItemClickListener listener) {
        this.context = context;
        this.navDrawerItems = navDrawerItems;
        this.listener = listener;
    }

//
//    @Override
//    public View getView(int position, View convertView, ViewGroup parent) {
//
//        if (position == 0) {
//            if (convertView == null) {
//                LayoutInflater mInflater = (LayoutInflater) context
//                        .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
//                convertView = mInflater
//                        .inflate(R.layout.drawer_first, null);
//            }
//
//            ImageView imgIcon = (ImageView) convertView.findViewById(R.id.icon);
//            TextView txtTitle = (TextView) convertView.findViewById(R.id.title);
//
//            imgIcon.setImageResource(navDrawerItems.get(position).getIcon());
//            txtTitle.setText(navDrawerItems.get(position).getTitle());
//
//            return convertView;
//        } else if (position == navDrawerItems.size() - 1) {
//            if (convertView == null) {
//                LayoutInflater mInflater = (LayoutInflater) context
//                        .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
//                convertView = mInflater
//                        .inflate(R.layout.drawer_last, null);
//            }
//
//            ImageView imgIcon = (ImageView) convertView.findViewById(R.id.icon);
//            imgIcon.setImageResource(navDrawerItems.get(position).getIcon());
//            return convertView;
//        } else {
//            if (convertView == null) {
//                LayoutInflater mInflater = (LayoutInflater) context
//                        .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
//                convertView = mInflater
//                        .inflate(R.layout.drawer_list_item, null);
//            }
//
//            ImageView imgIcon = (ImageView) convertView.findViewById(R.id.icon);
//            TextView txtTitle = (TextView) convertView.findViewById(R.id.title);
//            imgIcon.setImageResource(navDrawerItems.get(position).getIcon());
//            txtTitle.setText(navDrawerItems.get(position).getTitle());
//            return convertView;
//        }
//    }


    @Override
    public MYHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.drawer_list_item, parent, false);
        return new MYHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(MYHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return navDrawerItems.size();
    }


    public class MYHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imgIcon;
        TextView txtTitle;
        RelativeLayout clickLayout;

        public MYHolder(View view) {
            super(view);
            imgIcon = (ImageView) view.findViewById(R.id.icon);
            txtTitle = (TextView) view.findViewById(R.id.title);
            clickLayout = (RelativeLayout) view.findViewById(R.id.clickLayout);
        }

        @Override
        public void onClick(View v) {
            int pos = (int) v.getTag();
            listener.onItemClick(v, pos);
        }

        public void bind(final int position) {
            imgIcon.setImageResource(navDrawerItems.get(position).getIcon());
            txtTitle.setText(navDrawerItems.get(position).getTitle());
            clickLayout.setOnClickListener(this);
            clickLayout.setTag(position);

        }
    }
}
