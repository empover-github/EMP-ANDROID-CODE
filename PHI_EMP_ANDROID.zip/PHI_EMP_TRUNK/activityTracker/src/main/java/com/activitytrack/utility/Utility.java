
package com.activitytrack.utility;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.Spanned;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.daos.AgronomyActivityDAO;
import com.activitytrack.daos.DipstickDAO;
import com.activitytrack.daos.FarmerSchoolSilageDAO;
import com.activitytrack.daos.FarmerSegmentationDAO;
import com.activitytrack.daos.FarmerSegmentationRiceDAO;
import com.activitytrack.daos.GerminationListDAO;
import com.activitytrack.daos.LiquidationTrackingDAO;
import com.activitytrack.daos.MdrProfileDAO;
import com.activitytrack.daos.OSAActivityDAO;
import com.activitytrack.daos.PDAActivityDAO;
import com.activitytrack.daos.PSAActivityDAO;
import com.activitytrack.daos.PravaktaHaAgainDAO;
import com.activitytrack.daos.ThreeIDAO;
import com.activitytrack.daos.VillageProfileDAO;
import com.activitytrack.database.DBHandler;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static android.content.Context.ACTIVITY_SERVICE;

public class Utility {

    private static ProgressDialog dialog;

    public static void setMenuStatus(int number, Context context) {
        SharedPreferences example = context.getSharedPreferences("menuid", 0);
        Editor editor = example.edit();
        editor.putInt("menuid", number);
        editor.apply();
    }

    public static int getMenuStatus(Context context) {
        SharedPreferences example = context.getSharedPreferences("menuid", 0);
        return example.getInt("menuid", 0);
    }

    public static void setCurrentAvtivity(int activity, Context context) {
        SharedPreferences example = context.getSharedPreferences("currActivity", 0);
        Editor editor = example.edit();
        editor.putInt("currActivity", activity);
        editor.apply();
    }

    public static int getCurrentAvtivity(Context context) {
        SharedPreferences example = context.getSharedPreferences("currActivity", 0);
        return example.getInt("currActivity", 0);
    }

    public static void setDataDownloadReq(boolean downloadReq, Context context) {
        SharedPreferences example = context.getSharedPreferences("downloadReq", 0);
        Editor editor = example.edit();
        editor.putBoolean("downloadReq", downloadReq);
        editor.apply();
    }

    public static boolean getDataDownloadReq(Context context) {
        SharedPreferences example = context.getSharedPreferences("downloadReq", 0);
        return example.getBoolean("downloadReq", false);
    }


    public static void setShowFarmerSegmention(boolean showFarmerSegmention, Context context) {
        SharedPreferences example = context.getSharedPreferences("showFarmerSegmention", 0);
        Editor editor = example.edit();
        editor.putBoolean("showFarmerSegmention", showFarmerSegmention);
        editor.apply();
    }

    public static boolean getShowFarmerSegmention(Context context) {
        SharedPreferences example = context.getSharedPreferences("showFarmerSegmention", 0);
        return example.getBoolean("showFarmerSegmention", false);
    }

    public static void setCurrentCrop(int crop, Context context) {
        SharedPreferences example = context.getSharedPreferences("currCrop", 0);
        Editor editor = example.edit();
        editor.putInt("currCrop", crop);
        editor.apply();
    }

    public static int getCurrentCrop(Context context) {
        SharedPreferences example = context.getSharedPreferences("currCrop", 0);
        return example.getInt("currCrop", 0);
    }

    public static void setCurrentTheme(String theme, Context context) {
        SharedPreferences example = context.getSharedPreferences("currTheme", 0);
        Editor editor = example.edit();
        editor.putString("currTheme", theme);
        editor.apply();
    }

    public static String getCurrentTheme(Context context) {
        SharedPreferences example = context.getSharedPreferences("currTheme", 0);
        return example.getString("currTheme", MyConstants.THEME_DARK);
    }

    public static void showAlert(Context context, String title, String message) {

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton(context.getResources().getString(R.string.ok), new OnClickListener() {


            public void onClick(DialogInterface dialog, int which) {


            }
        });

        builder.create().show();
    }

    /**
     * getCurrentDateAndTime method will give current date
     * in the form of yyyy-MM-dd HH:mm:ss.SSS
     *
     * @return 2015-02-19 11:30:00.015
     */

    public static String getCurrentDateAndTime() {
        Calendar c = Calendar.getInstance();// 2015-02-19 11:30:00.015
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd H:mm:ss.SSS");
        return sdf.format(c.getTime());
    }

    public static String getCurrentformatedDate() {
        Calendar c = Calendar.getInstance();// 2015-11-03
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(c.getTime());
    }

    public static String getDateBefore(int days) {
        Calendar c = Calendar.getInstance();// 2015-11-03
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(c.getTime().getTime() - TimeUnit.DAYS.toMillis(days));

        return sdf.format(date);
    }

    /**
     * getCurrentDate method will give current date
     * in the form of yyyyMMdd
     *
     * @return 20150219
     */

    public static String getCurrentDate() {
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        return sdf.format(c.getTime());
    }

    public static String getCurrentDateFrm() {
        Calendar c = Calendar.getInstance();// 2015-11-19
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(c.getTime());
    }

    /**
     * Checking the network Availability
     *
     * @return ture if network is availability in device
     */
    public static boolean networkAvailability(Context c) {
        try {
            boolean wifiAvailability = false;
            boolean gprsAvailability = false;

            ConnectivityManager cManager = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo[] networkInfo = cManager.getAllNetworkInfo();

            for (NetworkInfo nInfo : networkInfo) {

                if (nInfo.getTypeName().equalsIgnoreCase("WIFI")) {
                    if (nInfo.isConnected())
                        wifiAvailability = true;
                }
                if (nInfo.getTypeName().equalsIgnoreCase("MOBILE")) {
                    if (nInfo.isConnected())
                        gprsAvailability = true;
                }
            }

            return wifiAvailability || gprsAvailability;

        } catch (Exception e) {
            ATBuildLog.v("Utilities - Exception :", e.toString());
        }

        return false;
    }

    /**
     * method will convert the Input stream to String
     *
     * @param is
     * @return String
     * @throws IOException
     * @throws *//*Exception*/

    public static String convertStreamToString(InputStream is)
            throws IOException, Exception {

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;

        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }
        reader.close();
        System.out.println("String from Server===" + sb.toString());
        return sb.toString();
    }

    public static boolean isJSONValid(String test) {
        try {
            new JSONObject(test);
        } catch (JSONException ex) {
            // edited, to include @Arthur's comment
            // e.g. in case JSONArray is valid as well...
            try {
                new JSONArray(test);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

    public static void setLastUploadDate(String fileDir, Context context) {
        SharedPreferences example = context.getSharedPreferences("lastUpload",
                0);
        Editor editor = example.edit();
        editor.putString("lastUpload", fileDir);
        editor.apply();
    }

    public static String getLastUploadDate(Context context) {
        SharedPreferences example = context.getSharedPreferences("lastUpload",
                0);
        return example.getString("lastUpload", null);
    }

    public static void setLastDownloadDate(String fileDir, Context context) {
        SharedPreferences example = context.getSharedPreferences(
                "lastDownload", 0);
        Editor editor = example.edit();
        editor.putString("lastDownload", fileDir);
        editor.apply();
    }

    public static String getLastDownloadDate(Context context) {
        SharedPreferences example = context.getSharedPreferences(
                "lastDownload", 0);
        return example.getString("lastDownload", null);
    }

    public static void setActivityId(long id, Context context) {
        SharedPreferences example = context.getSharedPreferences("activityId", 0);
        Editor editor = example.edit();
        editor.putLong("activityId", id);
        editor.apply();
    }

    public static long getActivityId(Context context) {
        SharedPreferences example = context.getSharedPreferences("activityId", 0);
        return example.getLong("activityId", 0);
    }

    public static String getVersionName(Context context) {
        PackageInfo pInfo;
        String code = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            code = pInfo.versionName;
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
        return code;
    }

    public static String getVersionNo(Context context) {
        PackageInfo pInfo;
        String code = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            code = String.valueOf(pInfo.versionCode);
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
        return code;
    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    //	seasonEnddate.compareTo(Utility.getCurrentformatedDate())
    public static boolean isSeasonExpire(String seasonEndDate, String currentDate) {
        if (seasonEndDate != null && seasonEndDate.length() > 0 && currentDate != null && currentDate.length() > 0) {
            int res = seasonEndDate.compareTo(currentDate);
            return res < 0;
        } else {
            return false;
        }
    }


    public static String getCropNameById(int selectedCrop) {
        switch (selectedCrop) {

            case MyConstants.CROP_MILLET_ID:
                return MyConstants.CROP_MILLET;

            case MyConstants.CROP_CORN_ID:
                return MyConstants.CROP_CORN;

            case MyConstants.CROP_MUSTARD_ID:
                return MyConstants.CROP_MUSTARD;

            case MyConstants.CROP_RICE_ID:
                return MyConstants.CROP_RICE;

        }
        return "";
    }

    public static String getActivityNameById(int selectedActivityId) {
        switch (selectedActivityId) {
            case MyConstants.ACTIVITY_PDA_ID:

                return MyConstants.ACTIVITY_PDA.toUpperCase();

            case MyConstants.ACTIVITY_OSA_ID:

                return MyConstants.ACTIVITY_OSA.toUpperCase();

            case MyConstants.ACTIVITY_PSA_ID:

                return MyConstants.ACTIVITY_PSA.toUpperCase();

        }
        return "";

    }

    // new deviceId
    public static void setDeviceId(String deviceId, Context context) {
        SharedPreferences example = context.getSharedPreferences("deviceId", 0);
        Editor editor = example.edit();
        editor.putString("deviceId", deviceId);
        editor.apply();
    }

    public static String getDeviceId(Context context) {
        SharedPreferences example = context.getSharedPreferences("deviceId", Context.MODE_PRIVATE);
        String deviceId = example.getString("deviceId", null);
        if (deviceId == null) {
            deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
            setDeviceId(deviceId, context);
        }
        return deviceId;
    }

    public static boolean checkPlayServices(Context context) {
        int result = GooglePlayServicesUtil.isGooglePlayServicesAvailable(context);
        if (result == ConnectionResult.SUCCESS) {
            return true;
        } else if (ConnectionResult.SERVICE_VERSION_UPDATE_REQUIRED == result) {
            Utility.showAlert(context, "", "Update google play services for better performance");
        } else if (ConnectionResult.SERVICE_MISSING == result) {
            Utility.showAlert(context, "", "google play services missing install/update for better performance");
        } else if (ConnectionResult.SERVICE_DISABLED == result) {
            Utility.showAlert(context, "", "google play services disabled enable for better performance");
        } else if (ConnectionResult.SERVICE_INVALID == result) {
            Utility.showAlert(context, "", "google play services invalid install/update for better performance");
        }

		/*if (GooglePlayServicesUtil.isUserRecoverableError(result)) {
			
			 * GooglePlayServicesUtil.getErrorDialog(resultCode, this,
			 * 
			 * PLAY_SERVICES_RESOLUTION_REQUEST).show();
			 
		} else {
			Log.i("Tag", "This device is not supported.");
			Utility.showAlert(context, "", "This device is not supported better change device for better performance");
			
		}*/

        return false;
    }

    public static void showAlertToOpenGPS(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(context.getResources().getString(R.string.gps));
        builder.setPositiveButton(context.getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                context.startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        });

        builder.setNegativeButton(context.getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //((ATMainActivity) context).popFragments();
            }
        });

        builder.create().show();
    }

    public static Float getFloat(Object obj) {
        Float result = null;
        if (obj == null)
            return null;
        try {
            String str = String.valueOf(obj);
            if (str != null && !str.isEmpty()) {
                if (str.trim().length() == 1 && str.equals(".")) {
                    return null;
                }
                result = Float.valueOf(str);
            }
        } catch (Exception e) {
            result = null;
        }
        return result;
    }

    public static InputFilter getDecimal() {
        InputFilter filter = new InputFilter() {
            final int maxDigitsBeforeDecimalPoint = 4;
            final int maxDigitsAfterDecimalPoint = 2;

            @Override
            public CharSequence filter(CharSequence source, int start, int end,
                                       Spanned dest, int dstart, int dend) {
                StringBuilder builder = new StringBuilder(dest);
                builder.replace(dstart, dend, source
                        .subSequence(start, end).toString());
                if (!builder.toString().matches(
                        "(([1-9]{1})([0-9]{0," + (maxDigitsBeforeDecimalPoint) + "})?)?(\\.[0-9]{0," + maxDigitsAfterDecimalPoint + "})?"

                )) {
                    if (source.length() == 0)
                        return dest.subSequence(dstart, dend);
                    return "";
                }

                return null;

            }
        };
        return filter;
    }

    public static Dialog showProgressDialog(Context context, boolean shouldShowPro) {
        if(shouldShowPro) {
            dialog = new ProgressDialog(context);
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelable(false);
            dialog.setMessage(context.getResources().getString(R.string.progress_pleaseWait));
            dialog.show();
            return dialog;
        }else
            return null;

    }

    public static void hideProgressDialog(Dialog progress) {
        if (progress != null && progress.isShowing()) {
            progress.dismiss();
        }
    }

    public static boolean isValidJSON(String data) {
        try {
            new JSONObject(data);
        } catch (JSONException ex) {
            // edited, to include @Arthur's comment
            // e.g. in case JSONArray is valid as well...
            try {
                new JSONArray(data);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

    public static int getVersionCode(Context context) {
        PackageInfo pInfo;
        int code = 0;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            code = pInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return code;

    }

    public static boolean isFirstTime(Context context) {
        SharedPreferences example = context.getSharedPreferences(MyConstants.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        return example.getBoolean("smsread", true);
    }

    public static void setFirstTime(boolean token, Context context) {
        SharedPreferences example = context.getSharedPreferences(MyConstants.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = example.edit();
        editor.putBoolean("smsread", token);
        editor.apply();
    }


    public static boolean isDataPending(Context mActivity) {

        if (AgronomyActivityDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (LiquidationTrackingDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (MdrProfileDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        //TARA
        if (VillageProfileDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (ThreeIDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (PDAActivityDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (OSAActivityDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (PSAActivityDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (DipstickDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (PravaktaHaAgainDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (GerminationListDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }
        if (FarmerSegmentationDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (FarmerSegmentationRiceDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0))) {
            return true;
        }

        if (FarmerSchoolSilageDAO.getInstance().isDataAvailForUpload(DBHandler.getInstance(mActivity).getDBObject(0)))
            return true;

        return false;
    }

    // newly added
    public static boolean isValidStr(String string) {
        if (string != null && !string.trim().isEmpty())
            return true;
        else
            return false;
    }

    public static boolean isValidNumber(String string) {
        return string != null && !string.trim().isEmpty() && Double.valueOf(string.trim()) > 0;
    }

    public static int getNumberInt(EditText editText) {
        String string = getText(editText);
        if (!string.trim().isEmpty()) {
            return Integer.valueOf(string);
        }
        return 0;
    }

    public static boolean isFirstTimeCamera(final Context context) {
        SharedPreferences example = context.getSharedPreferences(MyConstants.SHARED_PREFERENCE, 0);
        return example.getBoolean("camera", true);
    }

    public static void setFirstTimeCamera(boolean token, Context context) {
        SharedPreferences example = context.getSharedPreferences(MyConstants.SHARED_PREFERENCE, 0);
        SharedPreferences.Editor editor = example.edit();
        editor.putBoolean("camera", token);
        editor.apply();
    }

    public static boolean isMyServiceRunning(Context context, String serviceClsName) {
        ActivityManager manager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClsName.equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }


    public static void setNoOfProfilesUploadedByMdr(String countValue, Context context) {
        SharedPreferences example = context.getSharedPreferences(MyConstants.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = example.edit();
        editor.putString("profilesUploaded", countValue);
        editor.apply();
    }

    public static String getNoOfProfilesUploadedByMdr(Context context) {
        SharedPreferences example = context.getSharedPreferences(MyConstants.SHARED_PREFERENCE, Context.MODE_PRIVATE);
        return example.getString("profilesUploaded", "");
    }

    public static String getText(EditText editText) {
        return editText.getText().toString().trim();
    }

    public static String getText(TextView textView) {
        return textView.getText().toString().trim();
    }

    public static String getText(Button button) {
        return button.getText().toString().trim();
    }

    public static String getYear(){
        Calendar instance = Calendar.getInstance();

        return String.valueOf(instance.get(Calendar.YEAR));
    }

    public static String formatDateToUser(String str) {
        String date = "";
        SimpleDateFormat myDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date1 = myDateFormat.parse(str);
            SimpleDateFormat myDateFormat2 = new SimpleDateFormat("dd-MMM-yyyy");
            date = myDateFormat2.format(date1);
        } catch (ParseException e) {

        }
        return date;
    }
    public static Date formatDateFromStrToDate2(String st_dob) {
        if (isValidStr(st_dob)) {
            try {
                SimpleDateFormat myDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
                return myDateFormat.parse(st_dob);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return Calendar.getInstance().getTime();
    }
    public static long convertStrToMilliSeconds(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date mDate = sdf.parse(date);
            long timeInMilliseconds = mDate.getTime();
            ATBuildLog.e("Date in milli :: " , String.valueOf(timeInMilliseconds));
            return timeInMilliseconds;
        } catch (ParseException e) {
            // TO DO Auto-generated catch block
            e.printStackTrace();
        }

        return 0;
    }

    public static String formatDateToServer(String str) {
        String date = "";
        SimpleDateFormat myDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        try {
            Date date1 = myDateFormat.parse(str);
            SimpleDateFormat myDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
            date = myDateFormat2.format(date1);
        } catch (ParseException e) {

        }
        return date;

    }

}

