package com.activitytrack.dtos;

public class FarmerSegmentationRequestDTO implements DTO {


    private String loginId;
    private String mobileNumber;
    private String versionNo;
    private String deviceType;
    private FarmerSegmentationRequest farmerSegmentationRequest;


    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(String versionNo) {
        this.versionNo = versionNo;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public FarmerSegmentationRequest getFarmerSegmentationRequest() {
        return farmerSegmentationRequest;
    }

    public void setFarmerSegmentationRequest(FarmerSegmentationRequest farmerSegmentationRequest) {
        this.farmerSegmentationRequest = farmerSegmentationRequest;
    }
}
