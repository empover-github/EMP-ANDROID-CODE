package com.activitytrack.dtos;

public class SegmentationRiceRequestDTO {
    //first section
    private long id;
    private String year;
    private long season;
    private long crop;
    private String mobileNo;
    private String pincode;

    //farmer details
    private String farmerName;
    private String district;
    private String village;
    private String block;
    private float totalRiceAc;
    private float hybridRiceAc;
    private String typeOfIrrgi;

    //hybird rice matyrity
    private float maturity124Ac;
    private float maturity134Ac;
    private float maturity135Ac;

    //pioneer hybird

    private String riceHybrid1Name;
    private double riceHybrid1Acres;
    private String riceHybrid2Name;
    private double riceHybrid2Acres;
    private String riceHybrid3Name;
    private double riceHybrid3Acres;
    private String riceHybrid4Name;
    private double riceHybrid4Acres;



    private String riceServices;

    //competitor hybird plan
    private String riceCompetitorHybrid1;
    private double riceCompetitorHybridValue1;
    private String riceCompetitorHybrid2;
    private double riceCompetitorHybridValue2;
    private String riceCompetitorHybrid3;
    private double riceCompetitorHybridValue3;
    private String riceCompetitorHybrid4;
    private double riceCompetitorHybridValue4;


    //others fields
    private String localImagePath;
    private String isTBL;
    private String directSowingRice;
    private String date;
    private int isSync;
    private long  mobileId ;
    private String geoLocation;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public long getSeason() {
        return season;
    }

    public void setSeason(long season) {
        this.season = season;
    }

    public long getCrop() {
        return crop;
    }

    public void setCrop(long crop) {
        this.crop = crop;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public float getTotalRiceAc() {
        return totalRiceAc;
    }

    public void setTotalRiceAc(float totalRiceAc) {
        this.totalRiceAc = totalRiceAc;
    }

    public float getHybridRiceAc() {
        return hybridRiceAc;
    }

    public void setHybridRiceAc(float hybridRiceAc) {
        this.hybridRiceAc = hybridRiceAc;
    }

    public String getTypeOfIrrgi() {
        return typeOfIrrgi;
    }

    public void setTypeOfIrrgi(String typeOfIrrgi) {
        this.typeOfIrrgi = typeOfIrrgi;
    }

    public float getMaturity124Ac() {
        return maturity124Ac;
    }

    public void setMaturity124Ac(float maturity124Ac) {
        this.maturity124Ac = maturity124Ac;
    }

    public float getMaturity134Ac() {
        return maturity134Ac;
    }

    public void setMaturity134Ac(float maturity134Ac) {
        this.maturity134Ac = maturity134Ac;
    }

    public float getMaturity135Ac() {
        return maturity135Ac;
    }

    public void setMaturity135Ac(float maturity135Ac) {
        this.maturity135Ac = maturity135Ac;
    }



    public String getRiceServices() {
        return riceServices;
    }

    public void setRiceServices(String riceServices) {
        this.riceServices = riceServices;
    }

    public String getRiceCompetitorHybrid1() {
        return riceCompetitorHybrid1;
    }

    public void setRiceCompetitorHybrid1(String riceCompetitorHybrid1) {
        this.riceCompetitorHybrid1 = riceCompetitorHybrid1;
    }

    public double getRiceCompetitorHybridValue1() {
        return riceCompetitorHybridValue1;
    }

    public void setRiceCompetitorHybridValue1(double riceCompetitorHybridValue1) {
        this.riceCompetitorHybridValue1 = riceCompetitorHybridValue1;
    }

    public String getRiceCompetitorHybrid2() {
        return riceCompetitorHybrid2;
    }

    public void setRiceCompetitorHybrid2(String riceCompetitorHybrid2) {
        this.riceCompetitorHybrid2 = riceCompetitorHybrid2;
    }

    public double getRiceCompetitorHybridValue2() {
        return riceCompetitorHybridValue2;
    }

    public void setRiceCompetitorHybridValue2(double riceCompetitorHybridValue2) {
        this.riceCompetitorHybridValue2 = riceCompetitorHybridValue2;
    }

    public String getRiceCompetitorHybrid3() {
        return riceCompetitorHybrid3;
    }

    public void setRiceCompetitorHybrid3(String riceCompetitorHybrid3) {
        this.riceCompetitorHybrid3 = riceCompetitorHybrid3;
    }

    public double getRiceCompetitorHybridValue3() {
        return riceCompetitorHybridValue3;
    }

    public void setRiceCompetitorHybridValue3(double riceCompetitorHybridValue3) {
        this.riceCompetitorHybridValue3 = riceCompetitorHybridValue3;
    }

    public String getRiceCompetitorHybrid4() {
        return riceCompetitorHybrid4;
    }

    public void setRiceCompetitorHybrid4(String riceCompetitorHybrid4) {
        this.riceCompetitorHybrid4 = riceCompetitorHybrid4;
    }

    public double getRiceCompetitorHybridValue4() {
        return riceCompetitorHybridValue4;
    }

    public void setRiceCompetitorHybridValue4(double riceCompetitorHybridValue4) {
        this.riceCompetitorHybridValue4 = riceCompetitorHybridValue4;
    }

    public String getLocalImagePath() {
        return localImagePath;
    }

    public void setLocalImagePath(String localImagePath) {
        this.localImagePath = localImagePath;
    }

    public String getIsTBL() {
        return isTBL;
    }

    public void setIsTBL(String isTBL) {
        this.isTBL = isTBL;
    }

    public String getDirectSowingRice() {
        return directSowingRice;
    }

    public void setDirectSowingRice(String directSowingRice) {
        this.directSowingRice = directSowingRice;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public long getMobileId() {
        return mobileId;
    }

    public void setMobileId(long mobileId) {
        this.mobileId = mobileId;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public String getRiceHybrid1Name() {
        return riceHybrid1Name;
    }

    public void setRiceHybrid1Name(String riceHybrid1Name) {
        this.riceHybrid1Name = riceHybrid1Name;
    }

    public double getRiceHybrid1Acres() {
        return riceHybrid1Acres;
    }

    public void setRiceHybrid1Acres(double riceHybrid1Acres) {
        this.riceHybrid1Acres = riceHybrid1Acres;
    }

    public String getRiceHybrid2Name() {
        return riceHybrid2Name;
    }

    public void setRiceHybrid2Name(String riceHybrid2Name) {
        this.riceHybrid2Name = riceHybrid2Name;
    }

    public double getRiceHybrid2Acres() {
        return riceHybrid2Acres;
    }

    public void setRiceHybrid2Acres(double riceHybrid2Acres) {
        this.riceHybrid2Acres = riceHybrid2Acres;
    }

    public String getRiceHybrid3Name() {
        return riceHybrid3Name;
    }

    public void setRiceHybrid3Name(String riceHybrid3Name) {
        this.riceHybrid3Name = riceHybrid3Name;
    }

    public double getRiceHybrid3Acres() {
        return riceHybrid3Acres;
    }

    public void setRiceHybrid3Acres(double riceHybrid3Acres) {
        this.riceHybrid3Acres = riceHybrid3Acres;
    }

    public String getRiceHybrid4Name() {
        return riceHybrid4Name;
    }

    public void setRiceHybrid4Name(String riceHybrid4Name) {
        this.riceHybrid4Name = riceHybrid4Name;
    }

    public double getRiceHybrid4Acres() {
        return riceHybrid4Acres;
    }

    public void setRiceHybrid4Acres(double riceHybrid4Acres) {
        this.riceHybrid4Acres = riceHybrid4Acres;
    }
}
