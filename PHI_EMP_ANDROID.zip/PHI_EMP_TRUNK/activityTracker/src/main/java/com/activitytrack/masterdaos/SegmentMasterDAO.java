package com.activitytrack.masterdaos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdtos.SegmentMasterDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;


public class SegmentMasterDAO implements MasterDAO
{
	private final String TAG = "SgmntMaster";
    private static SegmentMasterDAO segmentMasterDAO;

	
    public static SegmentMasterDAO getInstance()
    {
        if (segmentMasterDAO == null)
        {
            segmentMasterDAO = new SegmentMasterDAO();
        }
        
        return segmentMasterDAO;
    }

    /**
     * delete the Data
     */
  
    @Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}

    /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
   
    @Override
	public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) 
			{
    	List<DTO> segmentMasterInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
        	if(!(columnName !=null && columnName.length() > 0)){
        		columnName = "id";
        	}
        	
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENT_MASTER where "+columnName+"='"+columnValue+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                    /*id
			     	hybridCode
    				cropId */
                	SegmentMasterDTO dto = new SegmentMasterDTO();
                	dto.setId(cursor.getLong(0));
                	dto.setSegmentName(cursor.getString(1));
                	dto.setCropId(cursor.getLong(2));
                	
                    
                    segmentMasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return segmentMasterInfo;
    }
    
    /**
     * Gets all the records from the database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
  
    @Override
	public List<DTO> getRecords(SQLiteDatabase dbObject) 
	{
    	List<DTO> segmentMasterInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENT_MASTER ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                	SegmentMasterDTO dto = new SegmentMasterDTO();
                    
                	dto.setId(cursor.getLong(0));
                	dto.setSegmentName(cursor.getString(1));
                	dto.setCropId(cursor.getLong(2));
                    
                    segmentMasterInfo.add(dto);

                } while (cursor.moveToNext());
            } 
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return segmentMasterInfo;
    }
    
	
	 /**
    * Inserts the data in the SQLite database
    * 
    * @param dbObject
    *            : Exposes methods to manage a SQLite database Object
    * @param dtoObject
    *            : DTO object is passed
    */
    
    
    
    @Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
    {
		 
    	 try
         {            
         	SegmentMasterDTO dto = (SegmentMasterDTO) dtoObject;

             ContentValues cValues = new ContentValues();
             /*id
 	     	hybridName
 			cropId */
             
             cValues.put("id", dto.getId());
             cValues.put("segmentName", dto.getSegmentName());
             cValues.put("cropId", dto.getCropId());

             dbObject.insert("SEGMENT_MASTER", null, cValues);
             return true;
         } catch (SQLException e)
         {
             ATBuildLog.e(TAG + "insert()", e.getMessage());
             return false;
         } finally
         {
             dbObject.close();
         }

     }
   
    /**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */


	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		 try
	        {
	            
	        	SegmentMasterDTO dto = (SegmentMasterDTO) dtoObject;

	            ContentValues cValues = new ContentValues();
	            
	            cValues.put("segmentName", dto.getSegmentName());
	            cValues.put("cropId", dto.getCropId());

	            dbObject.update("SEGMENT_MASTER", cValues, "id='" +dto.getId()+"' ", null);
	            return true;
	        } catch (SQLException e)
	        {
                ATBuildLog.e(TAG + "update()", e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        } finally
	        {
	            dbObject.close();
	        }
	        return false;
	    }

		 

	  /**
     * Deletes all the table Data from SQLite
     * 

     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM SEGMENT_MASTER").execute();
            return true;
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

}
	
	