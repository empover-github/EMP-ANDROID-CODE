package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.daos.DipstickDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.DipstickDTO;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdaos.DipstickMasterDAO;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.OtherCropMasterDAO;
import com.activitytrack.masterdaos.SeasonMasterDAO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.masterdtos.HybridMasterDTO;
import com.activitytrack.masterdtos.OtherCropMasterDTO;
import com.activitytrack.masterdtos.SeasonMasterDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DipstickFragment extends BaseFragment implements OnClickListener {
    private View view;
    private TextView tvRiceAcres, tvHybridCropAcres, /*tvOtherCropAcres,*/
            tvTotalFarmAcres, tvFarmerName, tvFarmerMobileNo, tvPyear, tvCYear, tvtotalCornAcres, tvF2Acreages;
    private EditText edtFarmerName, edtFarmerMobileNo, edtCropAcresPy, edtCropAcresCy, edtHybridCropAcresPy, edtHybridCropAcresCy, edtOtherCropAcresPy, edtOtherCropAcresCy,
            edtTotalFarmAcresPy, edtTotalFarmAcresCy, edtPioneerHybrid1Py, edtPioneerHybrid1Cy, edtPioneerHybrid2Py, edtPioneerHybrid2Cy, edtCompetitorHybrid1Py,
            edtCompetitorHybrid1Cy, edtCompetitorHybrid2Py, edtCompetitorHybrid2Cy, edtCompetitorHybrid3Py, edtCompetitorHybrid3Cy, edtCompetitorHybrid4Py,
            edtCompetitorHybrid4Cy, edtCompetitorHybrid5Py, edtCompetitorHybrid5Cy, edtTotalHybridAcresPy, edtTotalHybridAcresCy, edtCompetitorHybrid1, edtCompetitorHybrid2,
            edtCompetitorHybrid3, edtCompetitorHybrid4, edtCompetitorHybrid5, edtOtherCropAcres2Py, edtOtherCropAcres2Cy, edtF2AcreagesPy, edtF2AcreagesCy;
    private LinearLayout mainLayout1, mainLayout2, mainLayout3;
    private Spinner spnPhase, spnYear, spnSeason, spnCrop, spnSampleIssued, spnHybrid, spnPioneerHyb1Name, spnPioneerHyb2Name,
            spnOtherCropAcres1, spnOtherCropAcres2, spnUserType;
    private String[] phasesArray;
    private List<String> yearsList = new ArrayList<String>();
    private String[] sampleIssueArray;
    private Button btnSubmit;
    private List<DTO> hybridIdDTOList;
    private List<DTO> pioneerHybrid1IdDTOList;

    private List<DTO> otherCropAcres1IdDTOList;
    private List<String> hybridNamesList = new ArrayList<String>();
    private List<String> originalPioneerHybrid1NamesList = new ArrayList<String>();
    private List<String> unSelectedpioneerHybrid1NamesList = new ArrayList<String>();
    private List<String> pioneerHybrid1NamesList = new ArrayList<String>();
    private List<String> pioneerHybrid2NamesList = new ArrayList<String>();
    private List<String> pioneerHybrid3NamesList = new ArrayList<>();
    private List<String> pioneerHybrid4NamesList = new ArrayList<>();

    private List<String> originalOtherCropAcresNamesList = new ArrayList<String>();
    private List<String> unselectedOtherCropAcresNamesList = new ArrayList<String>();
    private List<String> otherCropAcres1NamesList = new ArrayList<String>();
    private List<String> otherCropAcres2NamesList = new ArrayList<String>();
    private long cropId, hybridId, seasonId;
    private String strYear;
    private List<DTO> cropDTOList;
    private List<String> cropNameList = new ArrayList<String>();
    private List<DTO> seasonDTOList;
    private List<String> seasonNameList = new ArrayList<String>();
    private ArrayAdapter<String> cropAdapter;
    private ArrayAdapter<String> seasonAdapter;
    private boolean sampleIssue;
    private DipstickDTO dipstickDTO;
    private LinearLayout dipstick_layout;
    private long result, masterResult;
    private boolean isSpecialCase;
    private String defaultZero = "0";
    private String defaultEmpty = "";
    private long selectedOtherCropAcresId1 = -1;
    private long selectedOtherCropAcresId2 = -1;
    //newly added
    private String[] userTypeArray;
    private LinearLayout layoutHybird;
    private String userTypeValue;
    private LinearLayout lnrSeedSettingIssue, lnrF2Acreages;
    private TextView tvSeedSettingIssue, tvSeedSettingIssue1, tvSeedSettingIssue2, tvSeedSettingIssue3, tvSeedSettingIssue4, tvComp1SeedSettingIssue, tvComp2SeedSettingIssue;
    private EditText edtSeedSettingIssuePy, edtSeedSettingIssueCy, edtSeedSettingIssue1Py, edtSeedSettingIssue1Cy, edtSeedSettingIssue2Py, edtSeedSettingIssue2Cy,
            edtSeedSettingIssue3Py, edtSeedSettingIssue3Cy, edtSeedSettingIssue4Py, edtSeedSettingIssue4Cy;
    private Spinner spnPioneerHyb3Name, spnPioneerHyb4Name;
    private EditText edtPioneerHybrid3Py, edtPioneerHybrid3Cy, edtPioneerHybrid4Py, edtPioneerHybrid4Cy;
    private ArrayAdapter<String> otherCropAcres1IdAdapter, otherCropAcres2IdAdapter;
    private String other1CropName, other2CropName;
    private String pioneerHybrid1name = "";
    private String pioneerHybrid2name = "";
    private String pioneerHybrid3name = "";
    private String pioneerHybrid4name = "";
    private ArrayAdapter<String> pioneerHybrid1IdAdapter, pioneerHybrid2IdAdapter, pioneerHybrid3IdAdapter, pioneerHybrid4IdAdapter;
    //newly added
    private LinearLayout lnrNonHydbridAcres, lnrSeedSettingIssue1, lnrSeedSettingIssue2, lnrSeedSettingIssue3, lnrSeedSettingIssue4, lnrComp1SeedSettingIssue, lnrComp2SeedSettingIssue;
    private EditText edtCompeHybrid1SeedSettingIssuePy, edtCompeHybrid1SeedSettingIssueCy, edtCompeHybrid2SeedSettingIssuePy, edtCompeHybrid2SeedSettingIssueCy;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.dipstick_fragment, container, false);

        createReferences();

        //setting the theme
        setTheme();

        //setting adapter to to Phase
        setPhaseData();

        //yearsArray
        setYearsData();

        //setting season adapter
        setSeasonData();

        //setting crop adapter
        setCropData();

        //setting data to issue sample
        setSampleIssueData();
        // newly added setting data to userType
        setUserTypeData();

        edtFarmerMobileNo.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {


            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().length() == 10) {
                    pioneerHybrid1SpinnerPopulation(cropId);
                    pioneerHybrid2SpinnerPopulation();
                    pioneerHybrid3SpinnerPopulation();
                    pioneerHybrid4SpinnerPopulation();
                    // Set Data for OtherCropAcres1 and otherCropAcres2
                    otherCropAcres1SpinnerPopulation(cropId);
                    otherCropAcres2SpinnerPopulation();
                    if (spnPhase.getSelectedItemPosition() == 2 && spnYear.getSelectedItemPosition() != 0) {
                        dipstickDTO = DipstickMasterDAO.getInstance().getRecordInfoForPhase("PI", yearsList.get(spnYear.getSelectedItemPosition()), seasonId, cropId, s.toString().trim(), DBHandler.getInstance(mActivity).getDBObject(0));
                        isSpecialCase = false;
                        if (dipstickDTO != null) {
                            populateData(dipstickDTO);
                        } else {
                            dipstickDTO = DipstickDAO.getInstance().getRecordInfoForPhase("PI", yearsList.get(spnYear.getSelectedItemPosition()), seasonId, cropId, s.toString().trim(), DBHandler.getInstance(mActivity).getDBObject(0));
                            if (dipstickDTO != null) {
                                populateData(dipstickDTO);
                            } else {
                                edtFarmerName.setText("");
                                disableForm();
                            }

                            //disableForm();
                        }
                    } else if (spnPhase.getSelectedItemPosition() == 1) {
                        dipstickDTO = DipstickMasterDAO.getInstance().getRecordInfoForPhase("FU", String.valueOf(Integer.valueOf(yearsList.get(spnYear.getSelectedItemPosition())) - 1), seasonId, cropId, s.toString().trim(), DBHandler.getInstance(mActivity).getDBObject(0));
                        if (dipstickDTO != null) {
                            isSpecialCase = false;
                            populateData(dipstickDTO);
                        } else {
                            dipstickDTO = DipstickDAO.getInstance().getRecordInfoForPhase("FU", String.valueOf(Integer.valueOf(yearsList.get(spnYear.getSelectedItemPosition())) - 1), seasonId, cropId, s.toString().trim(), DBHandler.getInstance(mActivity).getDBObject(0));
                            if (dipstickDTO != null) {
                                isSpecialCase = false;
                                populateData(dipstickDTO);
                            } else {
                                isSpecialCase = true;
                            }
                        }

                        enableForm();
                    } else {
                        disableForm();
                    }
                } else {
                    if (spnPhase.getSelectedItemPosition() == 2) {
                        edtFarmerName.setText("");
                    }
                    disableForm();
                }
            }
        });

 /*       spnPioneerHyb1Name.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().isEmpty()) {
                    edtPioneerHybrid1Py.setText(defaultZero);
                    return;
                }
                if (getText(spnPioneerHyb1Name).equals(getText(spnPioneerHyb2Name))) {
                    Utility.showAlert(mActivity, null, "Pioneer hybrid1 and hybrid2 should not be same");
                    return;
                }
//                if (spnPhase.getSelectedItemPosition() != 1) {
                    if (dipstickDTO != null) {
                        if (s.toString().trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                            edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                            edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                            edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                            edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                            edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                            edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                            edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                        } else {
                            edtPioneerHybrid1Py.setText(defaultZero);
                        }
                    }
//                }
            }
        });

        spnPioneerHyb2Name.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().isEmpty()) {
                    edtPioneerHybrid2Py.setText(defaultZero);
                    return;
                }
                if (getText(spnPioneerHyb1Name).equals(getText(spnPioneerHyb2Name))) {
                    Utility.showAlert(mActivity, null, "Pioneer hybrid1 and hybrid2 should not be same");
                    return;
                }
           //     if (spnPhase.getSelectedItemPosition() != 1) {
                    if (dipstickDTO != null) {
                        if (s.toString().trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                            edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                            edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                            edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                            edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                            edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                            edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                            edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                        } else {
                            edtPioneerHybrid2Py.setText(defaultZero);
                        }
                    }
              //  }
            }
        });
*/
        edtCompetitorHybrid1.addTextChangedListener(new

                                                            TextWatcher() {

                                                                @Override
                                                                public void onTextChanged(CharSequence s, int start, int before, int count) {

                                                                }

                                                                @Override
                                                                public void beforeTextChanged(CharSequence s, int start, int count,
                                                                                              int after) {

                                                                }

                                                                @Override
                                                                public void afterTextChanged(Editable s) {
                                                                    if (s.toString().trim().isEmpty()) {
                                                                        edtCompetitorHybrid1Py.setText(defaultZero);
                                                                        return;
                                                                    }
                                                                    //     if (spnPhase.getSelectedItemPosition() != 1) {
                                                                    if (dipstickDTO != null) {
                                                                        if (s.toString().trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                                                            edtCompetitorHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                                                            edtCompetitorHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                                                            edtCompetitorHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                                                            edtCompetitorHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                                                            edtCompetitorHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                                                            edtCompetitorHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                                                            edtCompetitorHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                                                                        } else {
                                                                            edtCompetitorHybrid1Py.setText(defaultZero);
                                                                        }
                                                                    }
//                }
                                                                }
                                                            });

        edtCompetitorHybrid2.addTextChangedListener(new

                                                            TextWatcher() {

                                                                @Override
                                                                public void onTextChanged(CharSequence s, int start, int before, int count) {

                                                                }

                                                                @Override
                                                                public void beforeTextChanged(CharSequence s, int start, int count,
                                                                                              int after) {

                                                                }

                                                                @Override
                                                                public void afterTextChanged(Editable s) {
                                                                    if (s.toString().trim().isEmpty()) {
                                                                        edtCompetitorHybrid2Py.setText(defaultZero);
                                                                        return;
                                                                    }
                                                                    //        if (spnPhase.getSelectedItemPosition() != 1) {
                                                                    if (dipstickDTO != null) {
                                                                        if (s.toString().trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                                                            edtCompetitorHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                                                            edtCompetitorHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                                                            edtCompetitorHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                                                            edtCompetitorHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                                                            edtCompetitorHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                                                            edtCompetitorHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                                                                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                                                            edtCompetitorHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                                                                        } else {
                                                                            edtCompetitorHybrid2Py.setText(defaultZero);
                                                                        }
                                                                    }
                                                                    //          }
                                                                }
                                                            });

       /* edtCompetitorHybrid3.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().isEmpty()) {
                    edtCompetitorHybrid3Py.setText(defaultZero);
                    return;
                }
          //      if (spnPhase.getSelectedItemPosition() != 1) {
                    if (dipstickDTO != null) {
                        if (s.toString().trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                            edtCompetitorHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                            edtCompetitorHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                            edtCompetitorHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                            edtCompetitorHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                            edtCompetitorHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                            edtCompetitorHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                            edtCompetitorHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                        } else {
                            edtCompetitorHybrid3Py.setText(defaultZero);
                        }
                    }
               // }
            }
        });

        edtCompetitorHybrid4.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().isEmpty()) {
                    edtCompetitorHybrid4Py.setText(defaultZero);
                    return;
                }
     //           if (spnPhase.getSelectedItemPosition() != 1) {
                    if (dipstickDTO != null) {
                        if (s.toString().trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                            edtCompetitorHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                            edtCompetitorHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                            edtCompetitorHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                            edtCompetitorHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                            edtCompetitorHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                            edtCompetitorHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                            edtCompetitorHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                        } else {
                            edtCompetitorHybrid4Py.setText(defaultZero);
                        }
                    }
           //     }
            }
        });

        edtCompetitorHybrid5.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().isEmpty()) {
                    edtCompetitorHybrid5Py.setText(defaultZero);
                    return;
                }
       //         if (spnPhase.getSelectedItemPosition() != 1) {
                    if (dipstickDTO != null) {
                        if (s.toString().trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                            edtCompetitorHybrid5Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                            edtCompetitorHybrid5Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                            edtCompetitorHybrid5Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                            edtCompetitorHybrid5Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                            edtCompetitorHybrid5Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                            edtCompetitorHybrid5Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                        } else if (s.toString().trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                            edtCompetitorHybrid5Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                        } else {
                            edtCompetitorHybrid5Py.setText(defaultZero);
                        }
                    }
      //          }
            }
        });*/

        edtCropAcresCy.addTextChangedListener(cropTextWatcher);
        edtHybridCropAcresCy.addTextChangedListener(cropTextWatcher);
        edtOtherCropAcresCy.addTextChangedListener(cropTextWatcher);
        edtOtherCropAcres2Cy.addTextChangedListener(cropTextWatcher);
        //newly added
        edtF2AcreagesCy.addTextChangedListener(cropTextWatcher);
        //Newly Added
        edtSeedSettingIssueCy.addTextChangedListener(cropTextWatcher);

        edtCropAcresPy.addTextChangedListener(cropTextWatcherPy);
        edtHybridCropAcresPy.addTextChangedListener(cropTextWatcherPy);
        edtOtherCropAcresPy.addTextChangedListener(cropTextWatcherPy);
        edtOtherCropAcres2Py.addTextChangedListener(cropTextWatcherPy);
        //newly added
        edtF2AcreagesPy.addTextChangedListener(cropTextWatcherPy);
        //Newly Added
        edtSeedSettingIssuePy.addTextChangedListener(cropTextWatcherPy);

        edtPioneerHybrid1Cy.addTextChangedListener(hybridTextWatcher);
        edtPioneerHybrid2Cy.addTextChangedListener(hybridTextWatcher);
        edtPioneerHybrid3Cy.addTextChangedListener(hybridTextWatcher);
        edtPioneerHybrid4Cy.addTextChangedListener(hybridTextWatcher);
        edtCompetitorHybrid1Cy.addTextChangedListener(hybridTextWatcher);
        edtCompetitorHybrid2Cy.addTextChangedListener(hybridTextWatcher);
       /* edtCompetitorHybrid3Cy.addTextChangedListener(hybridTextWatcher);
        edtCompetitorHybrid4Cy.addTextChangedListener(hybridTextWatcher);
        edtCompetitorHybrid5Cy.addTextChangedListener(hybridTextWatcher);*/

      /*  //newly added
        edtSeedSettingIssue1Cy.addTextChangedListener(hybridTextWatcher);
        edtSeedSettingIssue2Cy.addTextChangedListener(hybridTextWatcher);
        edtSeedSettingIssue3Cy.addTextChangedListener(hybridTextWatcher);
        edtSeedSettingIssue4Cy.addTextChangedListener(hybridTextWatcher);
*/
        //Adding CompetitorHybrid
        edtCompetitorHybrid1.addTextChangedListener(hybridTextWatcher);
        edtCompetitorHybrid2.addTextChangedListener(hybridTextWatcher);
      /*  edtCompetitorHybrid3.addTextChangedListener(hybridTextWatcher);
        edtCompetitorHybrid4.addTextChangedListener(hybridTextWatcher);
        edtCompetitorHybrid5.addTextChangedListener(hybridTextWatcher);*/

        edtPioneerHybrid1Py.addTextChangedListener(hybridTextWatcherPy);
        edtPioneerHybrid2Py.addTextChangedListener(hybridTextWatcherPy);
        edtPioneerHybrid3Py.addTextChangedListener(hybridTextWatcherPy);
        edtPioneerHybrid4Py.addTextChangedListener(hybridTextWatcherPy);
        edtCompetitorHybrid1Py.addTextChangedListener(hybridTextWatcherPy);
        edtCompetitorHybrid2Py.addTextChangedListener(hybridTextWatcherPy);


       /* //newly added
        edtSeedSettingIssue1Py.addTextChangedListener(hybridTextWatcherPy);
        edtSeedSettingIssue2Py.addTextChangedListener(hybridTextWatcherPy);
        edtSeedSettingIssue3Py.addTextChangedListener(hybridTextWatcherPy);
        edtSeedSettingIssue4Py.addTextChangedListener(hybridTextWatcherPy);*/

       /* edtCompetitorHybrid3Py.addTextChangedListener(hybridTextWatcherPy);
        edtCompetitorHybrid4Py.addTextChangedListener(hybridTextWatcherPy);
        edtCompetitorHybrid5Py.addTextChangedListener(hybridTextWatcherPy);*/

        //FocusChangeListener for EditText
        edtCropAcresPy.setOnFocusChangeListener(focusListener);
        edtHybridCropAcresPy.setOnFocusChangeListener(focusListener);
        edtOtherCropAcresPy.setOnFocusChangeListener(focusListener);
        edtOtherCropAcres2Py.setOnFocusChangeListener(focusListener);
        edtPioneerHybrid1Py.setOnFocusChangeListener(focusListener);
        edtPioneerHybrid2Py.setOnFocusChangeListener(focusListener);
        edtPioneerHybrid3Py.setOnFocusChangeListener(focusListener);
        edtPioneerHybrid4Py.setOnFocusChangeListener(focusListener);
        edtCompetitorHybrid1Py.setOnFocusChangeListener(focusListener);
        edtCompetitorHybrid2Py.setOnFocusChangeListener(focusListener);
        //newly added
        edtF2AcreagesPy.setOnFocusChangeListener(focusListener);
        //newly added
        edtSeedSettingIssuePy.setOnFocusChangeListener(focusListener);
       /* edtCompetitorHybrid3Py.setOnFocusChangeListener(focusListener);
        edtCompetitorHybrid4Py.setOnFocusChangeListener(focusListener);
        edtCompetitorHybrid5Py.setOnFocusChangeListener(focusListener);*/
     /*   //newly added
        edtSeedSettingIssue1Py.setOnFocusChangeListener(focusListener);
        edtSeedSettingIssue2Py.setOnFocusChangeListener(focusListener);
        edtSeedSettingIssue3Py.setOnFocusChangeListener(focusListener);
        edtSeedSettingIssue4Py.setOnFocusChangeListener(focusListener);*/


        btnSubmit.setOnClickListener(this);

        return view;

    }

    private View.OnFocusChangeListener focusListener = new View.OnFocusChangeListener() {
        public void onFocusChange(View v, boolean hasFocus) {
            EditText focusedView = (EditText) v;
            if (!hasFocus) {
                if (getText(focusedView).isEmpty())
                    focusedView.setText(defaultZero);
            }
        }
    };

    private void createReferences() {

        dipstick_layout = (LinearLayout) view.findViewById(R.id.dipstick);
        tvFarmerName = (TextView) view.findViewById(R.id.dp_farmerName_l);
        tvFarmerMobileNo = (TextView) view.findViewById(R.id.dp_farmerMobileNo_l);

        edtFarmerName = (EditText) view.findViewById(R.id.dp_farmerName);
        edtFarmerMobileNo = (EditText) view.findViewById(R.id.dp_farmerMobileNo);

        edtFarmerName.setEnabled(false);
        edtFarmerMobileNo.setEnabled(false);
        //tvData=(TextView)view.findViewById(R.id.dp_data_l);
        tvPyear = (TextView) view.findViewById(R.id.dp_pY);
        tvCYear = (TextView) view.findViewById(R.id.dp_cY);

        tvRiceAcres = (TextView) view.findViewById(R.id.dp_RiceAcres_l);
        edtCropAcresPy = (EditText) view.findViewById(R.id.dp_RiceAcres_pY);
        edtCropAcresCy = (EditText) view.findViewById(R.id.dp_RiceAcres_cY);

        tvHybridCropAcres = (TextView) view.findViewById(R.id.dp_hybridRiceAcres_l);
        edtHybridCropAcresPy = (EditText) view.findViewById(R.id.dp_hybridRiceAcres_pY);
        edtHybridCropAcresCy = (EditText) view.findViewById(R.id.dp_hybridRiceAcres_cY);

//        tvOtherCropAcres = (TextView) view.findViewById(R.id.dp_otherCropAcres_l);
        spnOtherCropAcres1 = (Spinner) view.findViewById(R.id.dp_otherCropAcres1_spn);
        edtOtherCropAcresPy = (EditText) view.findViewById(R.id.dp_otherCropAcres_pY);
        edtOtherCropAcresCy = (EditText) view.findViewById(R.id.dp_otherCropAcres_cY);

        spnOtherCropAcres2 = (Spinner) view.findViewById(R.id.dp_otherCropAcres2_spn);
        edtOtherCropAcres2Py = (EditText) view.findViewById(R.id.dp_otherCropAcres2_pY);
        edtOtherCropAcres2Cy = (EditText) view.findViewById(R.id.dp_otherCropAcres2_cY);

        tvTotalFarmAcres = (TextView) view.findViewById(R.id.dp_totalFarmAcres_l);
        edtTotalFarmAcresPy = (EditText) view.findViewById(R.id.dp_totalFarmAcres_pY);
        edtTotalFarmAcresCy = (EditText) view.findViewById(R.id.dp_totalFarmAcres_cY);

        spnPioneerHyb1Name = (Spinner) view.findViewById(R.id.dp_30v92_l);
        edtPioneerHybrid1Py = (EditText) view.findViewById(R.id.dp_30v92_pY);
        edtPioneerHybrid1Cy = (EditText) view.findViewById(R.id.dp_30v92_cY);

        spnPioneerHyb2Name = (Spinner) view.findViewById(R.id.dp_p3396Acres_l);
        edtPioneerHybrid2Py = (EditText) view.findViewById(R.id.dp_p3396Acres_pY);
        edtPioneerHybrid2Cy = (EditText) view.findViewById(R.id.dp_p3396Acres_cY);

        spnPioneerHyb3Name = (Spinner) view.findViewById(R.id.dp_p3397Acres_l);
        edtPioneerHybrid3Py = (EditText) view.findViewById(R.id.dp_p3397Acres_pY);
        edtPioneerHybrid3Cy = (EditText) view.findViewById(R.id.dp_p3397Acres_cY);

        spnPioneerHyb4Name = (Spinner) view.findViewById(R.id.dp_p3398Acres_l);
        edtPioneerHybrid4Py = (EditText) view.findViewById(R.id.dp_p3398Acres_pY);
        edtPioneerHybrid4Cy = (EditText) view.findViewById(R.id.dp_p3398Acres_cY);

        edtCompetitorHybrid1 = (EditText) view.findViewById(R.id.dp_competitorHybrid1_l);
        edtCompetitorHybrid1Py = (EditText) view.findViewById(R.id.dp_competitorHybrid1_pY);
        edtCompetitorHybrid1Cy = (EditText) view.findViewById(R.id.dp_competitorHybrid1_cY);

        edtCompetitorHybrid2 = (EditText) view.findViewById(R.id.dp_competitorHybrid2_l);
        edtCompetitorHybrid2Py = (EditText) view.findViewById(R.id.dp_competitorHybrid2_pY);
        edtCompetitorHybrid2Cy = (EditText) view.findViewById(R.id.dp_competitorHybrid2_cY);

        /*edtCompetitorHybrid3 = (EditText) view.findViewById(R.id.dp_competitorHybrid3_l);
        edtCompetitorHybrid3Py = (EditText) view.findViewById(R.id.dp_competitorHybrid3_pY);
        edtCompetitorHybrid3Cy = (EditText) view.findViewById(R.id.dp_competitorHybrid3_cY);

        edtCompetitorHybrid4 = (EditText) view.findViewById(R.id.dp_competitorHybrid4_l);
        edtCompetitorHybrid4Py = (EditText) view.findViewById(R.id.dp_competitorHybrid4_pY);
        edtCompetitorHybrid4Cy = (EditText) view.findViewById(R.id.dp_competitorHybrid4_cY);

        edtCompetitorHybrid5 = (EditText) view.findViewById(R.id.dp_competitorHybrid5_l);
        edtCompetitorHybrid5Py = (EditText) view.findViewById(R.id.dp_competitorHybrid5_pY);
        edtCompetitorHybrid5Cy = (EditText) view.findViewById(R.id.dp_competitorHybrid5_cY);*/

        tvtotalCornAcres = (TextView) view.findViewById(R.id.dp_totalCornAcres_l);
        edtTotalHybridAcresPy = (EditText) view.findViewById(R.id.dp_totalCornAcres_pY);
        edtTotalHybridAcresCy = (EditText) view.findViewById(R.id.dp_totalCornAcres_cY);

        mainLayout1 = (LinearLayout) view.findViewById(R.id.dp_bg_layout1);
        mainLayout2 = (LinearLayout) view.findViewById(R.id.dp_bg_layout2);
        mainLayout3 = (LinearLayout) view.findViewById(R.id.dp_bg_layout3);

        spnPhase = (Spinner) view.findViewById(R.id.dp_phase);
        spnYear = (Spinner) view.findViewById(R.id.dp_year);
        spnSeason = (Spinner) view.findViewById(R.id.dp_season);
        spnCrop = (Spinner) view.findViewById(R.id.dp_cropType);
        spnSampleIssued = (Spinner) view.findViewById(R.id.dp_sampleIssued);
        spnHybrid = (Spinner) view.findViewById(R.id.dp_hybrid);
        btnSubmit = (Button) view.findViewById(R.id.dp_submit);
        //new added 17/07/2018
        spnUserType = (Spinner) view.findViewById(R.id.dp_user_type);
        layoutHybird = (LinearLayout) view.findViewById(R.id.dp_hybird_layout);
        tvF2Acreages = (TextView) view.findViewById(R.id.dp_f2Acreages_l);
        edtF2AcreagesPy = (EditText) view.findViewById(R.id.dp_f2Acreages_pY);
        edtF2AcreagesCy = (EditText) view.findViewById(R.id.dp_f2Acreages_cY);

        //New Added
        lnrSeedSettingIssue = (LinearLayout) view.findViewById(R.id.seed_setting_issue);
        lnrF2Acreages = (LinearLayout) view.findViewById(R.id.f2Acreages);
        tvSeedSettingIssue = (TextView) view.findViewById(R.id.dp_seed_setting_issue_l);
        edtSeedSettingIssuePy = (EditText) view.findViewById(R.id.dp_seed_setting_issue_pY);
        edtSeedSettingIssueCy = (EditText) view.findViewById(R.id.dp_seed_setting_issue_cY);

        lnrNonHydbridAcres = (LinearLayout) view.findViewById(R.id.dp_RiceAcres);
        lnrSeedSettingIssue1 = (LinearLayout) view.findViewById(R.id.seed_setting_issue1);
        tvSeedSettingIssue1 = (TextView) view.findViewById(R.id.dp_seed_setting_issue1_l);
        edtSeedSettingIssue1Py = (EditText) view.findViewById(R.id.dp_seed_setting_issue1_pY);
        edtSeedSettingIssue1Cy = (EditText) view.findViewById(R.id.dp_seed_setting_issue1_cY);

        lnrSeedSettingIssue2 = (LinearLayout) view.findViewById(R.id.seed_setting_issue2);
        tvSeedSettingIssue2 = (TextView) view.findViewById(R.id.dp_seed_setting_issue2_l);
        edtSeedSettingIssue2Py = (EditText) view.findViewById(R.id.dp_seed_setting_issue2_pY);
        edtSeedSettingIssue2Cy = (EditText) view.findViewById(R.id.dp_seed_setting_issue2_cY);

        lnrSeedSettingIssue3 = (LinearLayout) view.findViewById(R.id.seed_setting_issue3);
        tvSeedSettingIssue3 = (TextView) view.findViewById(R.id.dp_seed_setting_issue3_l);
        edtSeedSettingIssue3Py = (EditText) view.findViewById(R.id.dp_seed_setting_issue3_pY);
        edtSeedSettingIssue3Cy = (EditText) view.findViewById(R.id.dp_seed_setting_issue3_cY);

        lnrSeedSettingIssue4 = (LinearLayout) view.findViewById(R.id.seed_setting_issue4);
        tvSeedSettingIssue4 = (TextView) view.findViewById(R.id.dp_seed_setting_issue4_l);
        edtSeedSettingIssue4Py = (EditText) view.findViewById(R.id.dp_seed_setting_issue4_pY);
        edtSeedSettingIssue4Cy = (EditText) view.findViewById(R.id.dp_seed_setting_issue4_cY);


        lnrComp1SeedSettingIssue = (LinearLayout) view.findViewById(R.id.dp_competitorHybrid1_seed_setting_issue);
        tvComp1SeedSettingIssue = (TextView) view.findViewById(R.id.dp_competitorHybrid1_seed_setting_issue_l);
        edtCompeHybrid1SeedSettingIssuePy = (EditText) view.findViewById(R.id.dp_competitorHybrid1_seed_setting_issue_pY);
        edtCompeHybrid1SeedSettingIssueCy = (EditText) view.findViewById(R.id.dp_competitorHybrid1_seed_setting_issue_cY);

        lnrComp2SeedSettingIssue = (LinearLayout) view.findViewById(R.id.dp_competitorHybrid2_seed_setting_issue);
        tvComp2SeedSettingIssue = (TextView) view.findViewById(R.id.dp_competitorHybrid2_seed_setting_issue_l);
        edtCompeHybrid2SeedSettingIssuePy = (EditText) view.findViewById(R.id.dp_competitorHybrid2_seed_setting_issue_pY);
        edtCompeHybrid2SeedSettingIssueCy = (EditText) view.findViewById(R.id.dp_competitorHybrid2_seed_setting_issue_cY);
    }

    private TextWatcher cropTextWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            Float cropAcres = null;
            Float hybridAcres = null;
            Float otherCropAcres = null;
            Float otherCropAcres2 = null;
            //newly added
            Float f2Acresages = null;
            //newly added
            Float seedSettingIssue = null;

            float result = 0f;

            if (!isEmpty(edtCropAcresCy)) {
                cropAcres = Utility.getFloat(getText(edtCropAcresCy));
            }

            if (!isEmpty(edtHybridCropAcresCy)) {
                hybridAcres = Utility.getFloat(getText(edtHybridCropAcresCy));
            }

            //newly added
            if (!isEmpty(edtF2AcreagesCy)) {
                f2Acresages = Utility.getFloat(getText(edtF2AcreagesCy));
            }
            if (!isEmpty(edtOtherCropAcresCy)) {
                otherCropAcres = Utility.getFloat(getText(edtOtherCropAcresCy));
            }

            if (!isEmpty(edtOtherCropAcres2Cy)) {
                otherCropAcres2 = Utility.getFloat(getText(edtOtherCropAcres2Cy));
            }

            //newly added
            if (!isEmpty(edtSeedSettingIssueCy)) {
                seedSettingIssue = Utility.getFloat(getText(edtSeedSettingIssueCy));
            }

            if (cropAcres != null)
                result += cropAcres;

            if (hybridAcres != null)
                result += hybridAcres;

            //newly added
            if (f2Acresages != null)
                result += f2Acresages;

            if (otherCropAcres != null)
                result += otherCropAcres;

            if (otherCropAcres2 != null)
                result += otherCropAcres2;

            //newly added
            if (seedSettingIssue != null)
                result += seedSettingIssue;

            edtTotalFarmAcresCy.setText(String.valueOf(result));

        }
    };

    private TextWatcher cropTextWatcherPy = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            Float cropAcres = null;
            Float hybridAcres = null;
            Float otherCropAcres = null;
            Float otherCropAcres2 = null;
            //newly added
            Float f2Acresages = null;
            //newly added
            Float seedSettingIssue = null;

            float result = 0f;

            if (!isEmpty(edtCropAcresPy)) {
                cropAcres = Utility.getFloat(getText(edtCropAcresPy));
            }

            if (!isEmpty(edtHybridCropAcresPy)) {
                hybridAcres = Utility.getFloat(getText(edtHybridCropAcresPy));
            }

            //newly added
            if (!isEmpty(edtF2AcreagesPy)) {
                f2Acresages = Utility.getFloat(getText(edtF2AcreagesPy));
            }
            if (!isEmpty(edtOtherCropAcresPy)) {
                otherCropAcres = Utility.getFloat(getText(edtOtherCropAcresPy));
            }

            if (!isEmpty(edtOtherCropAcres2Py)) {
                otherCropAcres2 = Utility.getFloat(getText(edtOtherCropAcres2Py));
            }

            //newly added
            if (!isEmpty(edtSeedSettingIssuePy)) {
                seedSettingIssue = Utility.getFloat(getText(edtSeedSettingIssuePy));
            }

            if (cropAcres != null)
                result += cropAcres;

            if (hybridAcres != null)
                result += hybridAcres;

            //newly added
            if (f2Acresages != null)
                result += f2Acresages;

            if (otherCropAcres != null)
                result += otherCropAcres;

            if (otherCropAcres2 != null)
                result += otherCropAcres2;

            //newly added
            if (seedSettingIssue != null)
                result += seedSettingIssue;

            edtTotalFarmAcresPy.setText(String.valueOf(result));

        }
    };

    private TextWatcher hybridTextWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {


        }

        @Override
        public void afterTextChanged(Editable s) {

            Float pHyb1 = null;
            Float pHyb2 = null;
            Float pHyb3 = null;
            Float pHyb4 = null;
            Float compHyb1 = null;
            Float compHyb2 = null;
         /*   Float seedSettingIss1 = null;
            Float seedSettingIss2 = null;
            Float seedSettingIss3 = null;
            Float seedSettingIss4 = null;*/

            float result = 0f;

            if (!isEmpty(edtPioneerHybrid1Cy)) {
                pHyb1 = Utility.getFloat(getText(edtPioneerHybrid1Cy));
            }

            if (!isEmpty(edtPioneerHybrid2Cy)) {
                pHyb2 = Utility.getFloat(getText(edtPioneerHybrid2Cy));
            }
            if (!isEmpty(edtPioneerHybrid3Cy)) {
                pHyb3 = Utility.getFloat(getText(edtPioneerHybrid3Cy));
            }

            if (!isEmpty(edtPioneerHybrid4Cy)) {
                pHyb4 = Utility.getFloat(getText(edtPioneerHybrid4Cy));
            }

            if (!isEmpty(edtCompetitorHybrid1Cy)) {
                compHyb1 = Utility.getFloat(getText(edtCompetitorHybrid1Cy));
            }

            if (!isEmpty(edtCompetitorHybrid2Cy)) {
                compHyb2 = Utility.getFloat(getText(edtCompetitorHybrid2Cy));
            }
//           //newly added
//            if (!isEmpty(edtSeedSettingIssue1Cy)) {
//                seedSettingIss1 = Utility.getFloat(getText(edtSeedSettingIssue1Cy));
//            }
//            if (!isEmpty(edtSeedSettingIssue2Cy)) {
//                seedSettingIss2 = Utility.getFloat(getText(edtSeedSettingIssue2Cy));
//            }
//            if (!isEmpty(edtSeedSettingIssue3Cy)) {
//                seedSettingIss3 = Utility.getFloat(getText(edtSeedSettingIssue3Cy));
//            }
//            if (!isEmpty(edtSeedSettingIssue4Cy)) {
//                seedSettingIss4 = Utility.getFloat(getText(edtSeedSettingIssue4Cy));
//            }

            if (pHyb1 != null)
                result += pHyb1;

            if (pHyb2 != null)
                result += pHyb2;

            if (pHyb3 != null)
                result += pHyb3;

            if (pHyb4 != null)
                result += pHyb4;

            if (compHyb1 != null)
                result += compHyb1;

            if (compHyb2 != null)
                result += compHyb2;

            /*if (seedSettingIss1 != null)
                result += seedSettingIss1;

            if (seedSettingIss2 != null)
                result += seedSettingIss2;

            if (seedSettingIss3 != null)
                result += seedSettingIss3;

            if (seedSettingIss4 != null)
                result += seedSettingIss4;*/

            edtTotalHybridAcresCy.setText(String.valueOf(result));

        }
    };

    private TextWatcher hybridTextWatcherPy = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {


        }

        @Override
        public void afterTextChanged(Editable s) {

            Float pHyb1 = null;
            Float pHyb2 = null;
            Float pHyb3 = null;
            Float pHyb4 = null;
            Float compHyb1 = null;
            Float compHyb2 = null;
           /* Float seedSettingIss1 = null;
            Float seedSettingIss2 = null;
            Float seedSettingIss3 = null;
            Float seedSettingIss4 = null;*/

            float result = 0f;

            if (!isEmpty(edtPioneerHybrid1Py)) {
                pHyb1 = Utility.getFloat(getText(edtPioneerHybrid1Py));
            }

            if (!isEmpty(edtPioneerHybrid2Py)) {
                pHyb2 = Utility.getFloat(getText(edtPioneerHybrid2Py));
            }
            if (!isEmpty(edtPioneerHybrid3Py)) {
                pHyb3 = Utility.getFloat(getText(edtPioneerHybrid3Py));
            }

            if (!isEmpty(edtPioneerHybrid4Py)) {
                pHyb4 = Utility.getFloat(getText(edtPioneerHybrid4Py));
            }

            if (!isEmpty(edtCompetitorHybrid1Py)) {
                compHyb1 = Utility.getFloat(getText(edtCompetitorHybrid1Py));
            }

            if (!isEmpty(edtCompetitorHybrid2Py)) {
                compHyb2 = Utility.getFloat(getText(edtCompetitorHybrid2Py));
            }
            //newly added

          /*  if (!isEmpty(edtSeedSettingIssue1Py)) {
                seedSettingIss1 = Utility.getFloat(getText(edtSeedSettingIssue1Py));
            }

            if (!isEmpty(edtSeedSettingIssue2Py)) {
                seedSettingIss2 = Utility.getFloat(getText(edtSeedSettingIssue2Py));
            }

            if (!isEmpty(edtSeedSettingIssue3Py)) {
                seedSettingIss3 = Utility.getFloat(getText(edtSeedSettingIssue3Py));
            }

            if (!isEmpty(edtSeedSettingIssue4Py)) {
                seedSettingIss4 = Utility.getFloat(getText(edtSeedSettingIssue4Py));
            }*/
            if (pHyb1 != null)
                result += pHyb1;

            if (pHyb2 != null)
                result += pHyb2;

            if (pHyb3 != null)
                result += pHyb3;

            if (pHyb4 != null)
                result += pHyb4;

            if (compHyb1 != null)
                result += compHyb1;

            if (compHyb2 != null)
                result += compHyb2;

           /* if (seedSettingIss1 != null)
                result += seedSettingIss1;

            if (seedSettingIss2 != null)
                result += seedSettingIss2;

            if (seedSettingIss3 != null)
                result += seedSettingIss3;

            if (seedSettingIss4 != null)
                result += seedSettingIss4;
*/
            edtTotalHybridAcresPy.setText(String.valueOf(result));

        }
    };

    private void setPhaseData() {
        phasesArray = getResources().getStringArray(R.array.dipsticks_spn1_items);
        ArrayAdapter<String> phasesAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, phasesArray);
        spnPhase.setAdapter(phasesAdapter);

        spnPhase.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                spnYear.setSelection(0);
                if (position == 1) {
                    purchaseIntention();
                } else if (position == 2) {
                    followUp();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void setYearsData() {
        yearsList = getYearsList();
        ArrayAdapter<String> yearsAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, yearsList);
        spnYear.setAdapter(yearsAdapter);

        spnYear.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                spnSeason.setSelection(0);
                if (position > 0) {
                    strYear = yearsList.get(position);
                    if (spnPhase.getSelectedItemPosition() == 1) {
                        tvCYear.setText(("Y " + strYear + " (Plan)"));
                        tvPyear.setText(("Y " + (Integer.valueOf(strYear) - 1) + " (Actual)"));
                    } else if (spnPhase.getSelectedItemPosition() == 2) {
                        tvCYear.setText(("Y " + strYear + " (Actual)"));
                        tvPyear.setText(("Y " + strYear + " (Plan)"));
                    }
                } else {
                    tvCYear.setText("");
                    tvPyear.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void setSeasonData() {
        seasonDTOList = SeasonMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if (seasonDTOList != null && seasonDTOList.size() > 0) {
            seasonNameList.clear();
            for (DTO dto : seasonDTOList) {
                if (seasonNameList.size() == 0) {
                    seasonNameList.add("Select Season");
                }
                SeasonMasterDTO cropMasterDTO = (SeasonMasterDTO) dto;
                seasonNameList.add(cropMasterDTO.getName());

            }
        }

        ArrayAdapter<String> seasonAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, seasonNameList);
        spnSeason.setAdapter(seasonAdapter);

        spnSeason.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                spnCrop.setSelection(0);
                if (position > 0) {
                    DTO mainDTO = seasonDTOList.get(position - 1);
                    SeasonMasterDTO dto = (SeasonMasterDTO) mainDTO;
                    seasonId = dto.getId();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void setCropData() {
        cropDTOList = CropMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if (cropDTOList != null && cropDTOList.size() > 0) {
            cropNameList.clear();
            for (DTO dto : cropDTOList) {
                if (cropNameList.size() == 0) {
                    cropNameList.add("Select Crop");
                }
                CropMasterDTO cropMasterDTO = (CropMasterDTO) dto;
                cropNameList.add(cropMasterDTO.getName());

            }
        }

        //yearsArray
        ArrayAdapter<String> cropAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, cropNameList);
        spnCrop.setAdapter(cropAdapter);

        spnCrop.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                spnSampleIssued.setSelection(0);
                edtFarmerMobileNo.setText("");
                edtFarmerName.setText("");
                spnUserType.setSelection(0);
                spnUserType.setEnabled(true);
                if (position > 0) {
                    DTO mainDTO = cropDTOList.get(position - 1);
                    CropMasterDTO dto = (CropMasterDTO) mainDTO;
                    cropId = dto.getId();
                    tvRiceAcres.setText((cropNameList.get(position) + " Acres (Non Hybrid)"));
                    tvHybridCropAcres.setText(("Hybrid " + cropNameList.get(position) + " Acres"));
                    //newly added
                    //tvF2Acreages.setText("F2 "+ cropNameList.get(position)+" Acreages");
                    tvtotalCornAcres.setText(("Total Hybrid " + cropNameList.get(position) + " Acres"));

                    if (dto.getName().equalsIgnoreCase(getString(R.string.cron))) {
                        //lnrSeedSettingIssue.setVisibility(View.VISIBLE);
                        lnrNonHydbridAcres.setVisibility(View.GONE);

                        lnrSeedSettingIssue1.setVisibility(View.VISIBLE);
                        lnrSeedSettingIssue2.setVisibility(View.VISIBLE);
                        lnrSeedSettingIssue3.setVisibility(View.VISIBLE);
                        lnrSeedSettingIssue4.setVisibility(View.VISIBLE);

                        lnrComp1SeedSettingIssue.setVisibility(View.VISIBLE);
                        lnrComp2SeedSettingIssue.setVisibility(View.VISIBLE);

                    } else {
                        lnrSeedSettingIssue.setVisibility(View.GONE);
                        lnrNonHydbridAcres.setVisibility(View.VISIBLE);

                        lnrSeedSettingIssue1.setVisibility(View.GONE);
                        lnrSeedSettingIssue2.setVisibility(View.GONE);
                        lnrSeedSettingIssue3.setVisibility(View.GONE);
                        lnrSeedSettingIssue4.setVisibility(View.GONE);

                        lnrComp1SeedSettingIssue.setVisibility(View.GONE);
                        lnrComp2SeedSettingIssue.setVisibility(View.GONE);
                    }
                    if (dto.getName().equalsIgnoreCase(getString(R.string.mustard))) {
                        lnrF2Acreages.setVisibility(View.VISIBLE);

                    } else {
                        lnrF2Acreages.setVisibility(View.GONE);

                    }


                } else {
                    cropId = 0;
                    tvRiceAcres.setText(("Acres (Non Hybrid)"));
                    tvHybridCropAcres.setText(("Hybrid Acres"));
                    //newly added
                    // tvF2Acreages.setText("F2 Acreages");
                    tvtotalCornAcres.setText(("Total Hybrid Acres"));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void setSampleIssueData() {
        sampleIssueArray = getResources().getStringArray(R.array.dipsticks_spn4_items);
        ArrayAdapter<String> sampleAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, sampleIssueArray);

        spnSampleIssued.setAdapter(sampleAdapter);
        spnSampleIssued.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                edtFarmerMobileNo.setText("");
                edtFarmerName.setText("");
                if (position > 0) {
                    if (position == 1) {
                        if (cropId > 0) {
                            hybridSpinnerPopulation(cropId);
                        }
                        spnHybrid.setSelection(0);
                        //spnHybrid.setVisibility(View.VISIBLE);
                        layoutHybird.setVisibility(View.VISIBLE);

                        sampleIssue = true;
//                    spnUserType.setSelection(0);
                        edtFarmerMobileNo.setEnabled(false);
                        edtFarmerName.setEnabled(false);
                    } else {
                        spnHybrid.setSelection(0);
                        // spnHybrid.setVisibility(View.INVISIBLE);
//                    spnUserType.setSelection(0);
                        edtFarmerMobileNo.setEnabled(true);
                        edtFarmerName.setEnabled(true);
                        layoutHybird.setVisibility(View.GONE);
                        sampleIssue = false;
                    }
                } else {
                    edtFarmerMobileNo.setEnabled(false);
                    edtFarmerName.setEnabled(false);
                    spnHybrid.setSelection(0);
                    layoutHybird.setVisibility(View.GONE);
                    sampleIssue = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    //newly added
    private void setUserTypeData() {
        userTypeArray = getResources().getStringArray(R.array.dipsticks_spn5_user_type_items);
        ArrayAdapter<String> useTypeAdapter = new ArrayAdapter(mActivity, android.R.layout.simple_spinner_item, userTypeArray);
        spnUserType.setAdapter(useTypeAdapter);
        spnUserType.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI")) {
                        if (spnSampleIssued.getSelectedItem().toString().equalsIgnoreCase("No")) {
                            edtFarmerMobileNo.setEnabled(true);
                            edtFarmerMobileNo.requestFocus();
                            if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI")) {
                                edtFarmerName.setEnabled(true);
                            } else {
                                edtFarmerName.setEnabled(false);
                            }
                        }
                    } else if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("FU")) {
                        edtFarmerMobileNo.setEnabled(true);
                        edtFarmerMobileNo.requestFocus();
                        edtFarmerName.setEnabled(false);
                    }
                    userTypeValue = spnUserType.getSelectedItem().toString();
                } else {
                    spnSampleIssued.setSelection(0);
                    edtFarmerMobileNo.setEnabled(false);
                    edtFarmerName.setEnabled(false);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void pioneerHybrid1SpinnerPopulation(long cropId) {
        pioneerHybrid1IdDTOList = HybridMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(mActivity).getDBObject(0));

        if (pioneerHybrid1IdDTOList != null && pioneerHybrid1IdDTOList.size() > 0) {
            originalPioneerHybrid1NamesList.clear();
            for (DTO dto : pioneerHybrid1IdDTOList) {
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                originalPioneerHybrid1NamesList.add(hybridMasterDTO.getHybridName());

            }
        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.noHybrid));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    //mActivity.popFragments();
                    //dummy
                }
            });

            builder.create().show();
        }
        pioneerHybrid1NamesList.clear();
        if (pioneerHybrid1NamesList.size() == 0) {
            pioneerHybrid1NamesList.add("Pioneer hybrid1");
        }
        pioneerHybrid1NamesList.addAll(originalPioneerHybrid1NamesList);

        ArrayAdapter<String> pioneerHybrid1IdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, pioneerHybrid1NamesList);

        spnPioneerHyb1Name.setAdapter(pioneerHybrid1IdAdapter);

        spnPioneerHyb1Name.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pioneerHybrid1name = spnPioneerHyb1Name.getSelectedItem().toString();
                if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
                    if (position > 0) {
                        if ((Utility.isValidStr(edtHybridCropAcresPy.getText().toString()) && Float.valueOf(edtHybridCropAcresPy.getText().toString()) > 0) || (Utility.isValidStr(edtHybridCropAcresCy.getText().toString()) && Float.valueOf(edtHybridCropAcresCy.getText().toString()) > 0)) {
                            edtPioneerHybrid1Py.setEnabled(true);
                            edtPioneerHybrid1Cy.setEnabled(true);

                            spnPioneerHyb2Name.setEnabled(true);

//                            edtPioneerHybrid1Cy.requestFocus();

                            hybrid2List(pioneerHybrid1name);
                            //newly added
                            edtSeedSettingIssue1Py.setEnabled(true);
                            edtSeedSettingIssue1Cy.setEnabled(true);


                            if (spnPioneerHyb1Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid2name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid1 and hybrid2 should not be same");
                                spnPioneerHyb1Name.setSelection(0);
                            }
                            if (spnPioneerHyb1Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid3name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid1 and hybrid3 should not be same");
                                spnPioneerHyb1Name.setSelection(0);
                            }
                            if (spnPioneerHyb1Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid4name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid1 and hybrid4 should not be same");
                                spnPioneerHyb1Name.setSelection(0);
                            }
                            if (dipstickDTO != null) {
                                String s = spnPioneerHyb1Name.getSelectedItem().toString();

                                if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                    edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                                } else {
                                    edtPioneerHybrid1Py.setText(defaultZero);
                                }
                            }
                        } else {
                            spnPioneerHyb1Name.setSelection(0);
                            Utility.showAlert(mActivity, "", "Please enter" + " " + tvHybridCropAcres.getText().toString());
                        }
                    } else {
                        edtPioneerHybrid1Py.setText(defaultZero);
                        edtPioneerHybrid1Py.setEnabled(false);
                        edtPioneerHybrid1Cy.setText(defaultEmpty);
                        edtPioneerHybrid1Cy.setEnabled(false);

                        spnPioneerHyb2Name.setEnabled(false);
                        edtPioneerHybrid2Cy.setEnabled(false);
                        edtPioneerHybrid2Py.setEnabled(false);
                        spnPioneerHyb3Name.setEnabled(false);
                        edtPioneerHybrid3Cy.setEnabled(false);
                        edtPioneerHybrid3Py.setEnabled(false);
                        spnPioneerHyb4Name.setEnabled(false);
                        edtPioneerHybrid4Cy.setEnabled(false);
                        edtPioneerHybrid4Py.setEnabled(false);
                        //newly added
                        edtSeedSettingIssue1Py.setText(defaultZero);
                        edtSeedSettingIssue1Py.setEnabled(false);

                        edtSeedSettingIssue1Cy.setText(defaultEmpty);
                        edtSeedSettingIssue1Cy.setEnabled(false);
                        edtSeedSettingIssue2Py.setEnabled(false);
                        edtSeedSettingIssue2Cy.setEnabled(false);
                        edtSeedSettingIssue3Py.setEnabled(false);
                        edtSeedSettingIssue3Cy.setEnabled(false);
                        edtSeedSettingIssue4Py.setEnabled(false);
                        edtSeedSettingIssue4Cy.setEnabled(false);

                        hybrid1List("");

                        pioneerHybrid2NamesList.size();
                        spnPioneerHyb2Name.setSelection(0);
                    }
                } else {
                    if (position > 0) {
                        if (spnPioneerHyb1Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb2Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid1 and hybrid2 should not be same");
                            spnPioneerHyb1Name.setSelection(0);
                        }
                        if (spnPioneerHyb1Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb3Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid1 and hybrid3 should not be same");
                            spnPioneerHyb1Name.setSelection(0);
                        }
                        if (spnPioneerHyb1Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb4Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid1 and hybrid4 should not be same");
                            spnPioneerHyb1Name.setSelection(0);
                        }
                        if (dipstickDTO != null) {
                            String s = spnPioneerHyb1Name.getSelectedItem().toString();

                            if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                edtPioneerHybrid1Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                            } else {
                                edtPioneerHybrid1Py.setText(defaultZero);
                            }
                        }
                    }
                }

                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void hybrid1List(String hybrid1) {
        pioneerHybrid1NamesList.clear();
        pioneerHybrid1NamesList.add("Pioneer hybrid1");
        pioneerHybrid1NamesList.addAll(originalPioneerHybrid1NamesList);

        if (Utility.isValidStr(hybrid1) && pioneerHybrid1NamesList.size() > 0) {
            pioneerHybrid1NamesList.remove(pioneerHybrid2name);
        }
    }

    private void hybrid2List(String hybrid1) {
        pioneerHybrid2NamesList.clear();
        if (pioneerHybrid2NamesList.size() == 0) {
            pioneerHybrid2NamesList.add("Pioneer hybrid2");
        }
        pioneerHybrid2NamesList.addAll(originalPioneerHybrid1NamesList);
        pioneerHybrid2NamesList.remove(hybrid1);
    }

    private void pioneerHybrid2SpinnerPopulation() {

        if (pioneerHybrid1IdDTOList != null && pioneerHybrid1IdDTOList.size() > 0) {
            pioneerHybrid2NamesList.clear();
            for (DTO dto : pioneerHybrid1IdDTOList) {
                if (pioneerHybrid2NamesList.size() == 0) {
                    pioneerHybrid2NamesList.add("Pioneer hybrid2");
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                pioneerHybrid2NamesList.add(hybridMasterDTO.getHybridName());
            }
        }

        final ArrayAdapter<String> pioneerHybrid2IdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, pioneerHybrid2NamesList);

        spnPioneerHyb2Name.setAdapter(pioneerHybrid2IdAdapter);

        spnPioneerHyb2Name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pioneerHybrid2name = spnPioneerHyb2Name.getSelectedItem().toString();
                if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
                    if (position > 0) {
                        if ((Utility.isValidStr(edtPioneerHybrid1Py.getText().toString()) && Float.valueOf(edtPioneerHybrid1Py.getText().toString()) > 0) || (Utility.isValidStr(edtPioneerHybrid1Cy.getText().toString()) && Float.valueOf(edtPioneerHybrid1Cy.getText().toString()) > 0)) {
                            edtPioneerHybrid2Py.setEnabled(true);
                            edtPioneerHybrid2Cy.setEnabled(true);

                            spnPioneerHyb1Name.setEnabled(false);

                            //newly added
                            edtSeedSettingIssue2Py.setEnabled(true);
                            edtSeedSettingIssue2Cy.setEnabled(true);

                            spnPioneerHyb3Name.setEnabled(true);


//                            edtPioneerHybrid2Cy.requestFocus();
                            hybrid3List(pioneerHybrid1name, pioneerHybrid2name);

                            if (spnPioneerHyb2Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid1name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid2 and hybrid1 should not be same");
                                spnPioneerHyb2Name.setSelection(0);
                            }
                            if (spnPioneerHyb2Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid3name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid2 and hybrid3 should not be same");
                                spnPioneerHyb2Name.setSelection(0);
                            }
                            if (spnPioneerHyb2Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid4name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid2 and hybrid4 should not be same");
                                spnPioneerHyb2Name.setSelection(0);
                            }

                            if (dipstickDTO != null) {
                                String s = spnPioneerHyb2Name.getSelectedItem().toString();
                                if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                    edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                                } else {
                                    edtPioneerHybrid2Py.setText(defaultZero);
                                }
                            }
                        } else {
                            spnPioneerHyb2Name.setSelection(0);
                            Utility.showAlert(mActivity, "", "Please enter Pioneer hybrid1 'Plan' data");
                        }

                    } else {
                        edtPioneerHybrid2Py.setText(defaultZero);
                        edtPioneerHybrid2Py.setEnabled(false);
                        edtPioneerHybrid2Cy.setText(defaultEmpty);
                        edtPioneerHybrid2Cy.setEnabled(false);
                        //newly added
                        edtSeedSettingIssue2Py.setText(defaultZero);
                        edtSeedSettingIssue2Py.setEnabled(false);
                        edtSeedSettingIssue2Cy.setText(defaultEmpty);
                        edtSeedSettingIssue2Cy.setEnabled(false);

                        if (spnPioneerHyb1Name.getSelectedItemPosition() > 0) {
                            spnPioneerHyb1Name.setEnabled(true);
                            edtPioneerHybrid1Cy.setEnabled(true);
                            edtPioneerHybrid1Py.setEnabled(true);
                            //newly added
                            edtSeedSettingIssue1Py.setEnabled(true);
                            edtSeedSettingIssue1Cy.setEnabled(true);
                        } else {
                            edtPioneerHybrid1Cy.setEnabled(false);
                            edtPioneerHybrid1Py.setEnabled(false);
                            //newly added
                            edtSeedSettingIssue1Py.setEnabled(false);
                            edtSeedSettingIssue1Cy.setEnabled(false);
                        }

                        spnPioneerHyb3Name.setEnabled(false);
                        edtPioneerHybrid3Cy.setEnabled(false);
                        edtPioneerHybrid3Py.setEnabled(false);
                        spnPioneerHyb4Name.setEnabled(false);
                        edtPioneerHybrid4Cy.setEnabled(false);
                        edtPioneerHybrid4Py.setEnabled(false);
                        //newly added
                        edtSeedSettingIssue3Py.setEnabled(false);
                        edtSeedSettingIssue3Cy.setEnabled(false);
                        edtSeedSettingIssue4Py.setEnabled(false);
                        edtSeedSettingIssue4Cy.setEnabled(false);
                        hybrid1List("");
                        pioneerHybrid3NamesList.size();
                        spnPioneerHyb3Name.setSelection(0);
                    }

                } else {
                    if (position > 0) {
                        if (spnPioneerHyb2Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb1Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid2 and hybrid1 should not be same");
                            spnPioneerHyb2Name.setSelection(0);
                        }
                        if (spnPioneerHyb2Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb3Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid2 and hybrid3 should not be same");
                            spnPioneerHyb2Name.setSelection(0);
                        }
                        if (spnPioneerHyb2Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb4Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid2 and hybrid4 should not be same");
                            spnPioneerHyb2Name.setSelection(0);
                        }

                        if (dipstickDTO != null) {
                            String s = spnPioneerHyb2Name.getSelectedItem().toString();
                            if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                edtPioneerHybrid2Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                            } else {
                                edtPioneerHybrid2Py.setText(defaultZero);
                            }
                        }
                    }
                }

                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void hybrid3List(String pioneerHybrid1name, String pioneerHybrid2name) {
        pioneerHybrid3NamesList.clear();
        if (pioneerHybrid3NamesList.size() == 0) {
            pioneerHybrid3NamesList.add("Pioneer hybrid3");
        }
        pioneerHybrid3NamesList.addAll(originalPioneerHybrid1NamesList);
        pioneerHybrid3NamesList.remove(pioneerHybrid1name);
        pioneerHybrid3NamesList.remove(pioneerHybrid2name);
    }

    private void pioneerHybrid3SpinnerPopulation() {

        if (pioneerHybrid1IdDTOList != null && pioneerHybrid1IdDTOList.size() > 0) {
            pioneerHybrid3NamesList.clear();
            for (DTO dto : pioneerHybrid1IdDTOList) {
                if (pioneerHybrid3NamesList.size() == 0) {
                    pioneerHybrid3NamesList.add("Pioneer hybrid3");
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                pioneerHybrid3NamesList.add(hybridMasterDTO.getHybridName());
            }
        }

        ArrayAdapter<String> pioneerHybrid3IdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, pioneerHybrid3NamesList);

        spnPioneerHyb3Name.setAdapter(pioneerHybrid3IdAdapter);

        spnPioneerHyb3Name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pioneerHybrid3name = spnPioneerHyb3Name.getSelectedItem().toString();
                if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
                    if (position > 0) {
                        if ((Utility.isValidStr(edtPioneerHybrid2Py.getText().toString()) && Float.valueOf(edtPioneerHybrid2Py.getText().toString()) > 0) || (Utility.isValidStr(edtPioneerHybrid2Cy.getText().toString()) && Float.valueOf(edtPioneerHybrid2Cy.getText().toString()) > 0)) {
                            edtPioneerHybrid3Py.setEnabled(true);
                            edtPioneerHybrid3Cy.setEnabled(true);

                            spnPioneerHyb2Name.setEnabled(false);

                            spnPioneerHyb4Name.setEnabled(true);

                            //newly added
                            edtSeedSettingIssue3Py.setEnabled(true);
                            edtSeedSettingIssue3Cy.setEnabled(true);

                            hybrid4List(pioneerHybrid1name, pioneerHybrid2name, pioneerHybrid3name);

                            if (spnPioneerHyb3Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid1name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid1 should not be same");
                                spnPioneerHyb3Name.setSelection(0);
                            }
                            if (spnPioneerHyb3Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid2name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid2 should not be same");
                                spnPioneerHyb3Name.setSelection(0);
                            }
                            if (spnPioneerHyb3Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid4name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid4 should not be same");
                                spnPioneerHyb3Name.setSelection(0);
                            }

                            if (dipstickDTO != null) {
                                String s = spnPioneerHyb3Name.getSelectedItem().toString();
                                if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                    edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                                } else {
                                    edtPioneerHybrid3Py.setText(defaultZero);
                                }
                            }
                        } else {
                            spnPioneerHyb3Name.setSelection(0);
                            Utility.showAlert(mActivity, "", "Please enter Pioneer hybrid2 'Plan' data");
                        }
                    } else {
                        edtPioneerHybrid3Py.setText(defaultZero);
                        edtPioneerHybrid3Py.setEnabled(false);
                        edtPioneerHybrid3Cy.setText(defaultEmpty);
                        edtPioneerHybrid3Cy.setEnabled(false);

                        //newly added
                        edtSeedSettingIssue3Py.setText(defaultZero);
                        edtSeedSettingIssue3Py.setEnabled(false);
                        edtSeedSettingIssue3Cy.setText(defaultEmpty);
                        edtSeedSettingIssue3Cy.setEnabled(false);

                        if (spnPioneerHyb2Name.getSelectedItemPosition() > 0) {
                            spnPioneerHyb2Name.setEnabled(true);
                            edtPioneerHybrid2Cy.setEnabled(true);
                            edtPioneerHybrid2Py.setEnabled(true);
                            //newly added
                            edtSeedSettingIssue2Cy.setEnabled(true);
                            edtSeedSettingIssue2Py.setEnabled(true);

                        } else {
                            spnPioneerHyb2Name.setEnabled(false);
                            edtPioneerHybrid2Cy.setEnabled(false);
                            edtPioneerHybrid2Py.setEnabled(false);
                            //newly added
                            edtSeedSettingIssue2Cy.setEnabled(false);
                            edtSeedSettingIssue2Py.setEnabled(false);

                        }

                        spnPioneerHyb4Name.setEnabled(false);
                        edtPioneerHybrid4Cy.setEnabled(false);
                        edtPioneerHybrid4Py.setEnabled(false);
                        hybrid2List(pioneerHybrid1name);
                        //newly added
                        edtSeedSettingIssue4Cy.setEnabled(false);
                        edtSeedSettingIssue4Py.setEnabled(false);

                        pioneerHybrid4NamesList.size();
                        spnPioneerHyb4Name.setSelection(0);
                    }

                } else {
                    if (position > 0) {
                        if (spnPioneerHyb3Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb1Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid1 should not be same");
                            spnPioneerHyb3Name.setSelection(0);
                        }
                        if (spnPioneerHyb3Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb2Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid2 should not be same");
                            spnPioneerHyb3Name.setSelection(0);
                        }
                        if (spnPioneerHyb3Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb4Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid4 should not be same");
                            spnPioneerHyb3Name.setSelection(0);
                        }

                        if (dipstickDTO != null) {
                            String s = spnPioneerHyb3Name.getSelectedItem().toString();
                            if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                edtPioneerHybrid3Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                            } else {
                                edtPioneerHybrid3Py.setText(defaultZero);
                            }
                        }
                    }

                }

                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void hybrid4List(String pioneerHybrid1name, String pioneerHybrid2name, String pioneerHybrid3name) {
        pioneerHybrid4NamesList.clear();
        if (pioneerHybrid4NamesList.size() == 0) {
            pioneerHybrid4NamesList.add("Pioneer hybrid4");
        }
        pioneerHybrid4NamesList.addAll(originalPioneerHybrid1NamesList);
        pioneerHybrid4NamesList.remove(pioneerHybrid1name);
        pioneerHybrid4NamesList.remove(pioneerHybrid2name);
        pioneerHybrid4NamesList.remove(pioneerHybrid3name);
    }

    private void pioneerHybrid4SpinnerPopulation() {

        if (pioneerHybrid1IdDTOList != null && pioneerHybrid1IdDTOList.size() > 0) {
            pioneerHybrid4NamesList.clear();
            for (DTO dto : pioneerHybrid1IdDTOList) {
                if (pioneerHybrid4NamesList.size() == 0) {
                    pioneerHybrid4NamesList.add("Pioneer hybrid4");
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                pioneerHybrid4NamesList.add(hybridMasterDTO.getHybridName());
            }
        }


        ArrayAdapter<String> pioneerHybrid4IdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, pioneerHybrid4NamesList);

        spnPioneerHyb4Name.setAdapter(pioneerHybrid4IdAdapter);

        spnPioneerHyb4Name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pioneerHybrid4name = spnPioneerHyb4Name.getSelectedItem().toString();
                if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
                    if (position > 0) {
                        if ((Utility.isValidStr(edtPioneerHybrid3Py.getText().toString()) && Float.valueOf(edtPioneerHybrid3Py.getText().toString()) > 0) || (Utility.isValidStr(edtPioneerHybrid3Cy.getText().toString()) && Float.valueOf(edtPioneerHybrid3Cy.getText().toString()) > 0)) {
                            edtPioneerHybrid4Py.setEnabled(true);
                            edtPioneerHybrid4Cy.setEnabled(true);

                            spnPioneerHyb3Name.setEnabled(false);

                            //newly added
                            edtSeedSettingIssue4Py.setEnabled(true);
                            edtSeedSettingIssue4Cy.setEnabled(true);

//                            edtPioneerHybrid4Cy.requestFocus();

                            if (spnPioneerHyb4Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid1name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid1 should not be same");
                                spnPioneerHyb4Name.setSelection(0);
                            }
                            if (spnPioneerHyb4Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid2name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid2 should not be same");
                                spnPioneerHyb4Name.setSelection(0);
                            }
                            if (spnPioneerHyb4Name.getSelectedItem().toString().equalsIgnoreCase(pioneerHybrid3name)) {
                                Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid3 should not be same");
                                spnPioneerHyb4Name.setSelection(0);
                            }

                            if (dipstickDTO != null) {
                                String s = spnPioneerHyb4Name.getSelectedItem().toString();
                                if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                                } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                                } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                    edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                                } else {
                                    edtPioneerHybrid4Py.setText(defaultZero);
                                }
                            }
                        } else {
                            spnPioneerHyb4Name.setSelection(0);
                            Utility.showAlert(mActivity, "", "Please enter Pioneer hybrid3 'Plan' data");
                        }

                    } else {
                        edtPioneerHybrid4Py.setText(defaultZero);
                        edtPioneerHybrid4Py.setEnabled(false);
                        edtPioneerHybrid4Cy.setText(defaultEmpty);
                        edtPioneerHybrid4Cy.setEnabled(false);

                        //newly added
                        edtSeedSettingIssue4Py.setText(defaultZero);
                        edtSeedSettingIssue4Py.setEnabled(false);
                        edtSeedSettingIssue4Cy.setText(defaultEmpty);
                        edtSeedSettingIssue4Cy.setEnabled(false);


                        if (spnPioneerHyb3Name.getSelectedItemPosition() > 0) {
                            spnPioneerHyb3Name.setEnabled(true);
                            edtPioneerHybrid3Cy.setEnabled(true);
                            edtPioneerHybrid3Py.setEnabled(true);
                            //newly added
                            edtSeedSettingIssue3Py.setEnabled(true);
                            edtSeedSettingIssue3Cy.setEnabled(true);
                        } else {
                            spnPioneerHyb3Name.setEnabled(false);
                            edtPioneerHybrid3Cy.setEnabled(false);
                            edtPioneerHybrid3Py.setEnabled(false);

                            //newly added
                            edtSeedSettingIssue3Py.setEnabled(false);
                            edtSeedSettingIssue3Cy.setEnabled(false);
                        }

                        hybrid3List(pioneerHybrid1name, pioneerHybrid2name);
                        if (pioneerHybrid4NamesList.size() >= 0) {
                            spnPioneerHyb4Name.setSelection(0);
                        }
                    }

                } else {
                    if (position > 0) {
                        if (spnPioneerHyb4Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb1Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid1 should not be same");
                            spnPioneerHyb4Name.setSelection(0);
                        }
                        if (spnPioneerHyb4Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb2Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid2 should not be same");
                            spnPioneerHyb4Name.setSelection(0);
                        }
                        if (spnPioneerHyb4Name.getSelectedItem().toString().equalsIgnoreCase(spnPioneerHyb3Name.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "Pioneer hybrid3 and hybrid3 should not be same");
                            spnPioneerHyb4Name.setSelection(0);
                        }

                        if (dipstickDTO != null) {
                            String s = spnPioneerHyb4Name.getSelectedItem().toString();
                            if (s.trim().equals(dipstickDTO.getPioneerHyb1Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb1()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb2Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb2()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb3Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb3()));
                            } else if (s.trim().equals(dipstickDTO.getPioneerHyb4Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getPioneerHyb4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid1Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid1()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid2Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid2()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid3Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid3()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid4Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid4()));
                            } else if (s.trim().equals(dipstickDTO.getCompetitorHybrid5Name())) {
                                edtPioneerHybrid4Py.setText(String.valueOf(dipstickDTO.getCompetitorHybrid5()));
                            } else {
                                edtPioneerHybrid4Py.setText(defaultZero);
                            }
                        }
                    }
                }

                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    private void otherCropAcres1SpinnerPopulation(long cropId) {
        otherCropAcres1IdDTOList = OtherCropMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(mActivity).getDBObject(0));

        if (otherCropAcres1IdDTOList != null && otherCropAcres1IdDTOList.size() > 0) {
            originalOtherCropAcresNamesList.clear();
            for (DTO dto : otherCropAcres1IdDTOList) {
               /* if (otherCropAcres1NamesList.size() == 0) {
                    otherCropAcres1NamesList.add("Other Crop Acres 1");
                }*/
                OtherCropMasterDTO hybridMasterDTO = (OtherCropMasterDTO) dto;
                originalOtherCropAcresNamesList.add(hybridMasterDTO.getName());
            }
        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.masterDownload));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    //mActivity.popFragments();
                    //dummy
                    //   mActivity.displayView();
                }
            });

            builder.create().show();
        }
        otherCropAcres1NamesList.clear();
        if (otherCropAcres1NamesList.size() == 0) {
            otherCropAcres1NamesList.add("Other Crop Acres 1");
        }
        otherCropAcres1NamesList.addAll(originalOtherCropAcresNamesList);

        otherCropAcres1IdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, otherCropAcres1NamesList);

        spnOtherCropAcres1.setAdapter(otherCropAcres1IdAdapter);

        spnOtherCropAcres1.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                other1CropName = spnOtherCropAcres1.getSelectedItem().toString();
                if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
                    if (position > 0) {

                        edtOtherCropAcresPy.setEnabled(true);
                        edtOtherCropAcresCy.setEnabled(true);

                        spnOtherCropAcres2.setEnabled(true);


                        unselectedOtherCropAcresNamesList.clear();
                        unselectedOtherCropAcresNamesList.addAll(originalOtherCropAcresNamesList);
                        for (int i = 0; i < otherCropAcres1NamesList.size(); i++) {
                            if (otherCropAcres1NamesList.get(i).equalsIgnoreCase(spnOtherCropAcres1.getSelectedItem().toString())) {
                                unselectedOtherCropAcresNamesList.remove(otherCropAcres1NamesList.get(i));
                            }

                        }
                        otherCropAcres2NamesList.clear();
                        if (otherCropAcres2NamesList.size() == 0) {
                            otherCropAcres2NamesList.add("Other Crop Acres 2");
                        }
                        otherCropAcres2NamesList.addAll(unselectedOtherCropAcresNamesList);

                        String spnAcera1 = spnOtherCropAcres1.getSelectedItem().toString();
                        for (int i = 0; i < otherCropAcres1IdDTOList.size(); i++) {
                            OtherCropMasterDTO masterDTO = (OtherCropMasterDTO) otherCropAcres1IdDTOList.get(i);
                            if (masterDTO.getName().equalsIgnoreCase(spnAcera1))
                                selectedOtherCropAcresId1 = masterDTO.getId();
                        }
                        if (dipstickDTO != null) {
                            if (selectedOtherCropAcresId1 == dipstickDTO.getOtherCrop1()) {
                                edtOtherCropAcresPy.setText(String.valueOf(dipstickDTO.getOtherCropArea1()));
                            } else {
                                edtOtherCropAcresPy.setText(defaultZero);
                            }
                        } else {
                            edtOtherCropAcresPy.setText(defaultZero);
                        }
                    } else {
                        edtOtherCropAcresPy.setText(defaultZero);
                        edtOtherCropAcresPy.setEnabled(false);
                        edtOtherCropAcresCy.setEnabled(false);

                        spnOtherCropAcres2.setEnabled(false);
                        edtOtherCropAcres2Py.setEnabled(false);
                        edtOtherCropAcres2Cy.setEnabled(false);

                        otherCropAcres2NamesList.size();
                        spnOtherCropAcres2.setSelection(0);
                    }
                } else {
                    if (position > 0) {

                        if (spnOtherCropAcres1.getSelectedItem().toString().equalsIgnoreCase(spnOtherCropAcres2.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "OtherCropAcres1 and otherCropAcres2 should not be same");
                            spnOtherCropAcres1.setSelection(0);
                       /* selectedOtherCropAcresId1 = -1;
                        selectedOtherCropAcresId2 = -1;*/
                        }

                        OtherCropMasterDTO masterDTO = (OtherCropMasterDTO) otherCropAcres1IdDTOList.get(position - 1);
                        selectedOtherCropAcresId1 = masterDTO.getId();
                        if (dipstickDTO != null) {
                            if (selectedOtherCropAcresId1 == dipstickDTO.getOtherCrop1()) {
                                edtOtherCropAcresPy.setText(String.valueOf(dipstickDTO.getOtherCropArea1()));
                            } else {
                                edtOtherCropAcresPy.setText(defaultZero);
                            }
                        } else {
                            edtOtherCropAcresPy.setText(defaultZero);
                        }
                    } else {
                        edtOtherCropAcresPy.setText(defaultZero);
                    }
                }

                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void otherCropAcres2SpinnerPopulation() {

        if (otherCropAcres1IdDTOList != null && otherCropAcres1IdDTOList.size() > 0) {
            otherCropAcres2NamesList.clear();
            for (DTO dto : otherCropAcres1IdDTOList) {
                if (otherCropAcres2NamesList.size() == 0) {
                    otherCropAcres2NamesList.add("Other Crop Acres 2");
                }
                OtherCropMasterDTO hybridMasterDTO = (OtherCropMasterDTO) dto;
                otherCropAcres2NamesList.add(hybridMasterDTO.getName());
            }
        }

        otherCropAcres2IdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, otherCropAcres2NamesList);

        spnOtherCropAcres2.setAdapter(otherCropAcres2IdAdapter);

        spnOtherCropAcres2.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                other2CropName = spnOtherCropAcres2.getSelectedItem().toString();

                if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
                    if (position > 0) {
                        if ((Utility.isValidStr(edtOtherCropAcresPy.getText().toString()) && Float.valueOf(edtOtherCropAcresPy.getText().toString()) > 0) || (Utility.isValidStr(edtOtherCropAcresCy.getText().toString()) && Float.valueOf(edtOtherCropAcresCy.getText().toString()) > 0)) {
                            edtOtherCropAcres2Py.setEnabled(true);
                            edtOtherCropAcres2Cy.setEnabled(true);

                            spnOtherCropAcres1.setEnabled(false);
                            edtOtherCropAcresPy.setEnabled(false);
                            edtOtherCropAcresCy.setEnabled(false);

//                            edtOtherCropAcres2Cy.requestFocus();
                            removeSelectedHybrid(other2CropName);

                            String spnAcera2 = spnOtherCropAcres2.getSelectedItem().toString();
                            for (int i = 0; i < otherCropAcres1IdDTOList.size(); i++) {
                                OtherCropMasterDTO masterDTO = (OtherCropMasterDTO) otherCropAcres1IdDTOList.get(i);
                                if (masterDTO.getName().equalsIgnoreCase(spnAcera2))
                                    selectedOtherCropAcresId2 = masterDTO.getId();
                            }

                            if (dipstickDTO != null) {
                                if (selectedOtherCropAcresId2 == dipstickDTO.getOtherCrop2()) {
                                    edtOtherCropAcres2Py.setText(String.valueOf(dipstickDTO.getOtherCropArea2()));
                                } else {
                                    edtOtherCropAcres2Py.setText(defaultZero);
                                }
                            } else {
                                edtOtherCropAcres2Py.setText(defaultZero);
                            }
                        } else {
                            spnOtherCropAcres2.setSelection(0);
                            Utility.showAlert(mActivity, "", "Please enter Other Crop Acres 1 'Plan' data");
                        }


                    } else {
                        edtOtherCropAcres2Py.setEnabled(false);
                        edtOtherCropAcres2Cy.setEnabled(false);

                        if (spnOtherCropAcres1.getSelectedItemPosition() > 0) {
                            spnOtherCropAcres1.setEnabled(true);
                            edtOtherCropAcresCy.setEnabled(true);
                            edtOtherCropAcresPy.setEnabled(true);
                        } else {
                            edtOtherCropAcresCy.setEnabled(false);
                            edtOtherCropAcresPy.setEnabled(false);
                        }


//                        edtOtherCropAcresCy.requestFocus();
                        refreshOtherAcers1();
                        edtOtherCropAcres2Py.setText(defaultZero);
                    }
                } else {
                    if (position > 0) {

                        if (spnOtherCropAcres2.getSelectedItem().toString().equalsIgnoreCase(spnOtherCropAcres1.getSelectedItem().toString())) {
                            Utility.showAlert(mActivity, "", "OtherCropAcres2 and otherCropAcres1 should not be same");
                            spnOtherCropAcres2.setSelection(0);
                        /*selectedOtherCropAcresId1 = -1;
                        selectedOtherCropAcresId2 = -1;*/
                        }

                        OtherCropMasterDTO masterDTO = (OtherCropMasterDTO) otherCropAcres1IdDTOList.get(position - 1);
                        selectedOtherCropAcresId2 = masterDTO.getId();

                        if (dipstickDTO != null) {
                            if (selectedOtherCropAcresId2 == dipstickDTO.getOtherCrop2()) {
                                edtOtherCropAcres2Py.setText(String.valueOf(dipstickDTO.getOtherCropArea2()));
                            } else {
                                edtOtherCropAcres2Py.setText(defaultZero);
                            }
                        } else {
                            edtOtherCropAcres2Py.setText(defaultZero);
                        }
                    } else {
                        edtOtherCropAcres2Py.setText(defaultZero);
                    }
                }

                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void refreshOtherAcers1() {
        otherCropAcres1NamesList.clear();
        if (otherCropAcres1NamesList.size() == 0) {
            otherCropAcres1NamesList.add("Other Crop Acres 1");
        }
        otherCropAcres1NamesList.addAll(originalOtherCropAcresNamesList);
    }

    private void removeSelectedHybrid(String other2CropName) {

        unselectedOtherCropAcresNamesList.clear();
        unselectedOtherCropAcresNamesList.addAll(originalOtherCropAcresNamesList);
        if (Utility.isValidStr(other2CropName)) {
            for (int i = 0; i < otherCropAcres2NamesList.size(); i++) {
                if (otherCropAcres2NamesList.get(i).equalsIgnoreCase(other2CropName)) {
                    unselectedOtherCropAcresNamesList.remove(otherCropAcres2NamesList.get(i));
                }
            }
        }
        otherCropAcres1NamesList.clear();
        if (otherCropAcres1NamesList.size() == 0) {
            otherCropAcres1NamesList.add("Other Crop Acres 1");
        }
        otherCropAcres1NamesList.addAll(unselectedOtherCropAcresNamesList);
    }


    private void hybridSpinnerPopulation(long cropId) {
        hybridIdDTOList = HybridMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(mActivity).getDBObject(0));

        if (hybridIdDTOList != null && hybridIdDTOList.size() > 0) {
            hybridNamesList.clear();
            for (DTO dto : hybridIdDTOList) {
                if (hybridNamesList.size() == 0) {
                    hybridNamesList.add("Select Hybrid");
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                hybridNamesList.add(hybridMasterDTO.getHybridName());
            }
        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.noHybrid));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    //mActivity.popFragments();
                    //dummy
                }
            });

            builder.create().show();
        }

        ArrayAdapter<String> hybridIdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, hybridNamesList);

        spnHybrid.setAdapter(hybridIdAdapter);
        // spnHybridType.setSelection(Utility.getHybridType(mActivity)!=0?Utility.getHybridType(mActivity):0);
        spnHybrid.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position > 0) {
                    if (spnUserType.getSelectedItemPosition() > 0) {
                        edtFarmerMobileNo.setEnabled(true);
                        edtFarmerMobileNo.requestFocus();
                        if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI")) {
                            edtFarmerName.setEnabled(true);
                        } else {
                            edtFarmerName.setEnabled(false);
                        }
                        HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) hybridIdDTOList.get(position - 1);
                        hybridId = hybridMasterDTO.getId();
                    } else {
                        hybridId = 0;
                    }
                } else {
                    edtFarmerMobileNo.setEnabled(false);
                    edtFarmerName.setEnabled(false);
                    spnHybrid.setSelection(0);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private List<String> getYearsList() {
        yearsList.clear();
        yearsList.add("Select Year");
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);

        for (int i = year - 1; i <= year + 1; i++) {
            yearsList.add("" + i);
        }

        return yearsList;
    }


    private void setTheme() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            tvFarmerName.setTextColor(Color.WHITE);
            tvFarmerMobileNo.setTextColor(Color.WHITE);
            tvRiceAcres.setTextColor(Color.WHITE);
            tvHybridCropAcres.setTextColor(Color.WHITE);
            //newly added
            tvF2Acreages.setTextColor(Color.WHITE);
//            tvOtherCropAcres.setTextColor(Color.WHITE);
            tvTotalFarmAcres.setTextColor(Color.WHITE);
            spnPioneerHyb1Name.setBackgroundResource(R.drawable.spinner_bg_img);
            spnPioneerHyb2Name.setBackgroundResource(R.drawable.spinner_bg_img);
            spnPioneerHyb3Name.setBackgroundResource(R.drawable.spinner_bg_img);
            spnPioneerHyb4Name.setBackgroundResource(R.drawable.spinner_bg_img);
            edtCompetitorHybrid1.setTextColor(Color.WHITE);
            edtCompetitorHybrid2.setTextColor(Color.WHITE);
            /*edtCompetitorHybrid3.setTextColor(Color.WHITE);
            edtCompetitorHybrid4.setTextColor(Color.WHITE);
            edtCompetitorHybrid5.setTextColor(Color.WHITE);*/
            tvtotalCornAcres.setTextColor(Color.WHITE);
            //New Added
            tvSeedSettingIssue.setTextColor(Color.WHITE);
            edtSeedSettingIssuePy.setTextColor(Color.WHITE);
            edtSeedSettingIssueCy.setTextColor(Color.WHITE);

            //newly added
            tvSeedSettingIssue1.setTextColor(Color.WHITE);
            edtSeedSettingIssue1Py.setTextColor(Color.WHITE);
            edtSeedSettingIssue1Cy.setTextColor(Color.WHITE);

            tvSeedSettingIssue2.setTextColor(Color.WHITE);
            edtSeedSettingIssue2Py.setTextColor(Color.WHITE);
            edtSeedSettingIssue2Cy.setTextColor(Color.WHITE);

            tvSeedSettingIssue3.setTextColor(Color.WHITE);
            edtSeedSettingIssue3Py.setTextColor(Color.WHITE);
            edtSeedSettingIssue3Cy.setTextColor(Color.WHITE);

            tvSeedSettingIssue4.setTextColor(Color.WHITE);
            edtSeedSettingIssue4Py.setTextColor(Color.WHITE);
            edtSeedSettingIssue4Cy.setTextColor(Color.WHITE);


            tvComp1SeedSettingIssue.setTextColor(Color.WHITE);
            edtCompeHybrid1SeedSettingIssuePy.setTextColor(Color.WHITE);
            edtCompeHybrid1SeedSettingIssueCy.setTextColor(Color.WHITE);

            tvComp2SeedSettingIssue.setTextColor(Color.WHITE);
            edtCompeHybrid2SeedSettingIssuePy.setTextColor(Color.WHITE);
            edtCompeHybrid2SeedSettingIssueCy.setTextColor(Color.WHITE);


            spnOtherCropAcres1.setBackgroundResource(R.drawable.spinner_bg_img);
            spnOtherCropAcres2.setBackgroundResource(R.drawable.spinner_bg_img);
            mainLayout1.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
            mainLayout2.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
            mainLayout3.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            tvFarmerName.setTextColor(Color.BLACK);
            tvFarmerMobileNo.setTextColor(Color.BLACK);
            tvRiceAcres.setTextColor(Color.BLACK);
            tvHybridCropAcres.setTextColor(Color.BLACK);
            //newly added
            tvF2Acreages.setTextColor(Color.BLACK);
//            tvOtherCropAcres.setTextColor(Color.BLACK);
            tvTotalFarmAcres.setTextColor(Color.BLACK);
            spnPioneerHyb1Name.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnPioneerHyb2Name.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnPioneerHyb3Name.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnPioneerHyb4Name.setBackgroundResource(R.drawable.spinner_bg_img_light);
            edtCompetitorHybrid1.setTextColor(Color.BLACK);
            edtCompetitorHybrid2.setTextColor(Color.BLACK);
            /*edtCompetitorHybrid3.setTextColor(Color.BLACK);
            edtCompetitorHybrid4.setTextColor(Color.BLACK);
            edtCompetitorHybrid5.setTextColor(Color.BLACK);*/
            tvtotalCornAcres.setTextColor(Color.BLACK);
            //New Added
            tvSeedSettingIssue.setTextColor(Color.BLACK);
            edtSeedSettingIssuePy.setTextColor(Color.BLACK);
            edtSeedSettingIssueCy.setTextColor(Color.BLACK);

            //newly added
            tvSeedSettingIssue1.setTextColor(Color.BLACK);
            edtSeedSettingIssue1Py.setTextColor(Color.BLACK);
            edtSeedSettingIssue1Cy.setTextColor(Color.BLACK);

            tvSeedSettingIssue2.setTextColor(Color.BLACK);
            edtSeedSettingIssue2Py.setTextColor(Color.BLACK);
            edtSeedSettingIssue2Cy.setTextColor(Color.BLACK);

            tvSeedSettingIssue3.setTextColor(Color.BLACK);
            edtSeedSettingIssue3Py.setTextColor(Color.BLACK);
            edtSeedSettingIssue3Cy.setTextColor(Color.BLACK);

            tvSeedSettingIssue4.setTextColor(Color.BLACK);
            edtSeedSettingIssue4Py.setTextColor(Color.BLACK);
            edtSeedSettingIssue4Cy.setTextColor(Color.BLACK);

            tvComp1SeedSettingIssue.setTextColor(Color.BLACK);
            edtCompeHybrid1SeedSettingIssuePy.setTextColor(Color.BLACK);
            edtCompeHybrid1SeedSettingIssueCy.setTextColor(Color.BLACK);

            tvComp2SeedSettingIssue.setTextColor(Color.BLACK);
            edtCompeHybrid2SeedSettingIssuePy.setTextColor(Color.BLACK);
            edtCompeHybrid2SeedSettingIssueCy.setTextColor(Color.BLACK);


            spnOtherCropAcres1.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnOtherCropAcres2.setBackgroundResource(R.drawable.spinner_bg_img_light);
            mainLayout1.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
            mainLayout2.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
            mainLayout3.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        if (isDataAvailable()) {
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }
        return true;
    }


    private String getText(EditText editText) {
        return editText.getText().toString().trim();
    }

    private boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }

    private void populateData(DipstickDTO dto) {
        if (dto != null) {

            edtFarmerName.setText(dto.getFarmerName());

            edtCropAcresPy.setText(String.valueOf(dto.getCropAcres()));
            edtHybridCropAcresPy.setText(String.valueOf(dto.getHybridCropAcres()));
//            edtOtherCropAcresPy.setText(String.valueOf(dto.getOtherCropAcres()));
            //newly added
            edtF2AcreagesPy.setText(String.valueOf(dto.getF2Acreages()));
            edtOtherCropAcresPy.setText(String.valueOf(dto.getOtherCropArea1()));
            edtOtherCropAcres2Py.setText(String.valueOf(dto.getOtherCropArea2()));

            edtOtherCropAcresPy.setText(String.valueOf(dto.getOtherCropArea1()));
            edtOtherCropAcres2Py.setText(String.valueOf(dto.getOtherCropArea2()));

            //newly added
            edtSeedSettingIssuePy.setText(String.valueOf(dto.getSeedSettingIssue()));


            enableForm();

//            Commented due to Populating previous year data not only for FU but also for PI
//            if (spnPhase.getSelectedItemPosition() == 2) {
            edtCompetitorHybrid1.setText(dto.getCompetitorHybrid1Name());
            edtCompetitorHybrid2.setText(dto.getCompetitorHybrid2Name());
                /*edtCompetitorHybrid3.setText(dto.getCompetitorHybrid3Name());
                edtCompetitorHybrid4.setText(dto.getCompetitorHybrid4Name());
                edtCompetitorHybrid5.setText(dto.getCompetitorHybrid5Name());*/
            if (pioneerHybrid1NamesList.size() > 0) {
                for (int i = 0; i < pioneerHybrid1NamesList.size(); i++) {
                    if (pioneerHybrid1NamesList.get(i).equalsIgnoreCase(dto.getPioneerHyb1Name())) {
                        spnPioneerHyb1Name.setSelection(i);
                    }

                }
            }
            if (pioneerHybrid2NamesList.size() > 0) {
                for (int i = 0; i < pioneerHybrid2NamesList.size(); i++) {
                    if (pioneerHybrid2NamesList.get(i).equalsIgnoreCase(dto.getPioneerHyb2Name())) {
                        spnPioneerHyb2Name.setSelection(i);
                    }

                }
            }
            if (pioneerHybrid3NamesList.size() > 0) {
                for (int i = 0; i < pioneerHybrid3NamesList.size(); i++) {
                    if (pioneerHybrid3NamesList.get(i).equalsIgnoreCase(dto.getPioneerHyb3Name())) {
                        spnPioneerHyb3Name.setSelection(i);
                    }

                }
            }
            if (pioneerHybrid4NamesList.size() > 0) {
                for (int i = 0; i < pioneerHybrid4NamesList.size(); i++) {
                    if (pioneerHybrid4NamesList.get(i).equalsIgnoreCase(dto.getPioneerHyb4Name())) {
                        spnPioneerHyb4Name.setSelection(i);
                    }

                }
            }

            if (otherCropAcres1IdDTOList.size() > 0) {
                long previouslySelectedId = dto.getOtherCrop1();
                for (int i = 0; i < otherCropAcres1IdDTOList.size(); i++) {
                    OtherCropMasterDTO masterDTO = (OtherCropMasterDTO) otherCropAcres1IdDTOList.get(i);
                    long newId = masterDTO.getId();
                    if (newId == previouslySelectedId) {
                        String name = masterDTO.getName();
                        if (otherCropAcres1NamesList.get(i + 1).equalsIgnoreCase(name)) {
                            spnOtherCropAcres1.setSelection(i + 1);
                        }
                    }
                }
            }

            if (otherCropAcres1IdDTOList.size() > 0) {
                long previouslySelectedId = dto.getOtherCrop2();
                for (int i = 0; i < otherCropAcres1IdDTOList.size(); i++) {
                    OtherCropMasterDTO masterDTO = (OtherCropMasterDTO) otherCropAcres1IdDTOList.get(i);
                    long newId = masterDTO.getId();
                    if (newId == previouslySelectedId) {
                        String name = masterDTO.getName();
                        if (otherCropAcres2NamesList.get(i + 1).equalsIgnoreCase(name)) {
                            spnOtherCropAcres2.setSelection(i + 1);
                        }
                    }
                }
            }

            if (dto.getPioneerHyb1() > 0)
                edtPioneerHybrid1Py.setText(String.valueOf(dto.getPioneerHyb1()));
            else
                edtPioneerHybrid1Py.setText(defaultZero);

            //newly added
            if (dto.getSeedSettingIssue1() != null)
                edtSeedSettingIssue1Py.setText(String.valueOf(dto.getSeedSettingIssue1()));
            else
                edtSeedSettingIssue1Py.setText(defaultZero);

            if (dto.getPioneerHyb2() > 0)
                edtPioneerHybrid2Py.setText(String.valueOf(dto.getPioneerHyb2()));
            else
                edtPioneerHybrid2Py.setText(defaultZero);

            //newly added
            if (dto.getSeedSettingIssue2() != null)
                edtSeedSettingIssue2Py.setText(String.valueOf(dto.getSeedSettingIssue2()));
            else
                edtSeedSettingIssue2Py.setText(defaultZero);

            if (dto.getPioneerHyb3() > 0)
                edtPioneerHybrid3Py.setText(String.valueOf(dto.getPioneerHyb3()));
            else
                edtPioneerHybrid3Py.setText(defaultZero);

            //newly added
            if (dto.getSeedSettingIssue3() != null)
                edtSeedSettingIssue3Py.setText(String.valueOf(dto.getSeedSettingIssue3()));
            else
                edtSeedSettingIssue3Py.setText(defaultZero);

            if (dto.getPioneerHyb4() > 0)
                edtPioneerHybrid4Py.setText(String.valueOf(dto.getPioneerHyb4()));
            else
                edtPioneerHybrid4Py.setText(defaultZero);
            //newly added
            if (dto.getSeedSettingIssue4() != null)
                edtSeedSettingIssue4Py.setText(String.valueOf(dto.getSeedSettingIssue4()));
            else
                edtSeedSettingIssue4Py.setText(defaultZero);

            if (dto.getCompetitorHybrid1() > 0)
                edtCompetitorHybrid1Py.setText(String.valueOf(dto.getCompetitorHybrid1()));
            else
                edtCompetitorHybrid1Py.setText(defaultZero);

            //newly added
            if (dto.getCompetitorHybrid1SeedSettingIssue() != null)
                edtCompeHybrid1SeedSettingIssuePy.setText(String.valueOf(dto.getCompetitorHybrid1SeedSettingIssue()));
            else
                edtCompeHybrid1SeedSettingIssuePy.setText(defaultZero);

            if (dto.getCompetitorHybrid2() > 0)
                edtCompetitorHybrid2Py.setText(String.valueOf(dto.getCompetitorHybrid2()));
            else
                edtCompetitorHybrid2Py.setText(defaultZero);

            //newly added
            if (dto.getCompetitorHybrid2SeedSettingIssue() != null)
                edtCompeHybrid2SeedSettingIssuePy.setText(String.valueOf(dto.getCompetitorHybrid2SeedSettingIssue()));
            else
                edtCompeHybrid2SeedSettingIssuePy.setText(defaultZero);

               /* if(dto.getCompetitorHybrid3() > 0)
                    edtCompetitorHybrid3Py.setText(String.valueOf(dto.getCompetitorHybrid3()));
                else
                    edtCompetitorHybrid3Py.setText(defaultZero);

                if(dto.getCompetitorHybrid4() > 0)
                    edtCompetitorHybrid4Py.setText(String.valueOf(dto.getCompetitorHybrid4()));
                else
                    edtCompetitorHybrid4Py.setText(defaultZero);

                if(dto.getCompetitorHybrid5() > 0)
                    edtCompetitorHybrid5Py.setText(String.valueOf(dto.getCompetitorHybrid5()));
                else
                    edtCompetitorHybrid5Py.setText(defaultZero);*/

            //newly added
            if (dto.getUserType() != null) {
                if (!(userTypeValue.equalsIgnoreCase(dto.getUserType()))) {
                    String dtoUserType = dto.getUserType();
                    for (String string : userTypeArray) {
                        if (string.equalsIgnoreCase(dtoUserType)) {
                            if (dtoUserType.equalsIgnoreCase("User")) {
                                spnUserType.setSelection(1);
                                spnUserType.setEnabled(false);
                            }
                           /* else if (dto.getUserType().equalsIgnoreCase("Non User PDA Farmer")) {
                                spnUserType.setSelection(3);
                                spnUserType.setEnabled(false);
                            } else if (dto.getUserType().equalsIgnoreCase("Non User")) {
                                spnUserType.setSelection(2);
                                spnUserType.setEnabled(false);
                            }*/
                           /* else if(!(dto.getUserType().equalsIgnoreCase(userTypeValue)) && userTypeValue.equalsIgnoreCase("Non User PDA Farmer")){
                                spnUserType.setSelection(3);
                                spnUserType.setEnabled(false);
                            }*/

                        }
                       /* else if(!(dto.getUserType().equalsIgnoreCase(userTypeValue)) && userTypeValue.equalsIgnoreCase("Non User PDA Farmer")){
                            spnUserType.setSelection(3);
                            spnUserType.setEnabled(false);
                        }*/
                    }
                }
            }
            if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
//                spnOtherCropAcres1.setEnabled(false);
                spnOtherCropAcres2.setEnabled(false);

//                spnPioneerHyb1Name.setEnabled(false);
                spnPioneerHyb2Name.setEnabled(false);
                spnPioneerHyb3Name.setEnabled(false);
                spnPioneerHyb4Name.setEnabled(false);
            } else {
                spnOtherCropAcres1.setEnabled(true);
                spnOtherCropAcres2.setEnabled(true);
                spnPioneerHyb1Name.setEnabled(true);
                spnPioneerHyb2Name.setEnabled(true);
                spnPioneerHyb3Name.setEnabled(true);
                spnPioneerHyb4Name.setEnabled(true);
            }
            edtCompetitorHybrid1.setEnabled(true);
            edtCompetitorHybrid2.setEnabled(true);
                /*edtCompetitorHybrid3.setEnabled(true);
                edtCompetitorHybrid4.setEnabled(true);
                edtCompetitorHybrid5.setEnabled(true);*/
//            }

        } else {
            clearForm();
        }
    }

    private void hideSeedSetting() {
        lnrSeedSettingIssue.setVisibility(View.GONE);
        lnrNonHydbridAcres.setVisibility(View.GONE);
        lnrSeedSettingIssue1.setVisibility(View.GONE);
        lnrSeedSettingIssue2.setVisibility(View.GONE);
        lnrSeedSettingIssue3.setVisibility(View.GONE);
        lnrSeedSettingIssue4.setVisibility(View.GONE);
        lnrComp1SeedSettingIssue.setVisibility(View.GONE);
        lnrComp2SeedSettingIssue.setVisibility(View.GONE);
    }

    private void clearForm() {
        spnPioneerHyb1Name.setSelection(0);
        spnPioneerHyb2Name.setSelection(0);
        spnPioneerHyb3Name.setSelection(0);
        spnPioneerHyb4Name.setSelection(0);

        if (otherCropAcres1NamesList.size() > 0) {
            spnOtherCropAcres1.setSelection(0);
        }
        if (otherCropAcres2NamesList.size() > 0) {
            spnOtherCropAcres2.setSelection(0);
        }
//        if(otherCropAcres1NamesList != null) {
//            otherCropAcres1NamesList.clear();
//            otherCropAcres1NamesList.add("Other Crop Acres 1");
//        }
//        if(otherCropAcres1IdAdapter!= null) {
//            otherCropAcres1IdAdapter.notifyDataSetChanged();
//        }
//        if(otherCropAcres2NamesList != null) {
//            otherCropAcres2NamesList.clear();
//            otherCropAcres2NamesList.add("Other Crop Acres 2");
//        }
//        if(otherCropAcres2IdAdapter!= null) {
//            otherCropAcres2IdAdapter.notifyDataSetChanged();
//        }
        edtCompetitorHybrid1.setText("");
        edtCompetitorHybrid2.setText("");
       /* edtCompetitorHybrid3.setText("");
        edtCompetitorHybrid4.setText("");
        edtCompetitorHybrid5.setText("");*/

        //edtFarmerName.setText("");

        edtCropAcresPy.setText(defaultZero);
        edtHybridCropAcresPy.setText(defaultZero);
        //newly added
        edtF2AcreagesPy.setText(defaultZero);
        //newly added
        edtSeedSettingIssuePy.setText(defaultZero);
        edtOtherCropAcresPy.setText(defaultZero);
        edtOtherCropAcres2Py.setText(defaultZero);

        edtPioneerHybrid1Py.setText(defaultZero);
        edtPioneerHybrid2Py.setText(defaultZero);
        edtPioneerHybrid3Py.setText(defaultZero);
        edtPioneerHybrid4Py.setText(defaultZero);
        edtCompetitorHybrid1Py.setText(defaultZero);
        edtCompetitorHybrid2Py.setText(defaultZero);
        /*edtCompetitorHybrid3Py.setText(defaultZero);
        edtCompetitorHybrid4Py.setText(defaultZero);
        edtCompetitorHybrid5Py.setText(defaultZero);*/

        //newly added
        edtSeedSettingIssue1Py.setText(defaultZero);
        edtSeedSettingIssue2Py.setText(defaultZero);
        edtSeedSettingIssue3Py.setText(defaultZero);
        edtSeedSettingIssue4Py.setText(defaultZero);

        edtCompeHybrid1SeedSettingIssuePy.setText(defaultZero);
        edtCompeHybrid2SeedSettingIssuePy.setText(defaultZero);

        //edtTotalHybridAcresPy.setText("0");
        //edtTotalFarmAcresPy.setText("0");

        edtCropAcresCy.setText("");
        edtHybridCropAcresCy.setText("");
        //newly added
        edtF2AcreagesCy.setText("");
        edtOtherCropAcresCy.setText("");
        edtOtherCropAcres2Cy.setText("");

        edtPioneerHybrid1Cy.setText("");
        edtPioneerHybrid2Cy.setText("");
        edtPioneerHybrid3Cy.setText("");
        edtPioneerHybrid4Cy.setText("");
        edtCompetitorHybrid1Cy.setText("");
        edtCompetitorHybrid2Cy.setText("");
       /* edtCompetitorHybrid3Cy.setText("");
        edtCompetitorHybrid4Cy.setText("");
        edtCompetitorHybrid5Cy.setText("");*/
        //newly added
        edtSeedSettingIssueCy.setText("");
        //newly added
        edtSeedSettingIssue1Cy.setText("");
        edtSeedSettingIssue2Cy.setText("");
        edtSeedSettingIssue3Cy.setText("");
        edtSeedSettingIssue4Cy.setText("");

        edtCompeHybrid1SeedSettingIssueCy.setText("");
        edtCompeHybrid2SeedSettingIssueCy.setText("");
    }

    private void enableForm() {
        //clearForm();
        edtCropAcresCy.setEnabled(true);
        edtHybridCropAcresCy.setEnabled(true);
        //newly added
        edtF2AcreagesCy.setEnabled(true);
        if (spnPhase.getSelectedItem().toString().equalsIgnoreCase("PI") && isSpecialCase) {
            edtOtherCropAcresCy.setEnabled(false);
            edtOtherCropAcres2Cy.setEnabled(false);

            edtPioneerHybrid1Cy.setEnabled(false);
            edtPioneerHybrid2Cy.setEnabled(false);
            edtPioneerHybrid3Cy.setEnabled(false);
            edtPioneerHybrid4Cy.setEnabled(false);

            //newly added
            edtSeedSettingIssue1Cy.setEnabled(false);
            edtSeedSettingIssue2Cy.setEnabled(false);
            edtSeedSettingIssue3Cy.setEnabled(false);
            edtSeedSettingIssue4Cy.setEnabled(false);


        } else {
            edtOtherCropAcresCy.setEnabled(true);
            edtOtherCropAcres2Cy.setEnabled(true);

            edtPioneerHybrid1Cy.setEnabled(true);
            edtPioneerHybrid2Cy.setEnabled(true);
            edtPioneerHybrid3Cy.setEnabled(true);
            edtPioneerHybrid4Cy.setEnabled(true);

            //newly added
            edtSeedSettingIssue1Cy.setEnabled(true);
            edtSeedSettingIssue2Cy.setEnabled(true);
            edtSeedSettingIssue3Cy.setEnabled(true);
            edtSeedSettingIssue4Cy.setEnabled(true);

        }
        //newly added
        edtSeedSettingIssueCy.setEnabled(true);

        if (isSpecialCase) {
            edtCropAcresPy.setEnabled(true);
            edtHybridCropAcresPy.setEnabled(true);
            //newly added
            edtF2AcreagesPy.setEnabled(true);
            //newly added
            edtSeedSettingIssuePy.setEnabled(true);

            edtCompetitorHybrid1Py.setEnabled(true);
            edtCompetitorHybrid2Py.setEnabled(true);

            //newly added
            edtCompeHybrid1SeedSettingIssuePy.setEnabled(true);
            edtCompeHybrid2SeedSettingIssuePy.setEnabled(true);
        } else {

            edtCropAcresPy.setEnabled(false);
            edtHybridCropAcresPy.setEnabled(false);
            //newly added
            edtF2AcreagesPy.setEnabled(false);
            //newly added
            edtSeedSettingIssuePy.setEnabled(false);
            edtOtherCropAcresPy.setEnabled(false);
            edtOtherCropAcres2Py.setEnabled(false);

            edtPioneerHybrid1Py.setEnabled(false);
            edtPioneerHybrid2Py.setEnabled(false);
            edtPioneerHybrid3Py.setEnabled(false);
            edtPioneerHybrid4Py.setEnabled(false);

            edtCompetitorHybrid1Py.setEnabled(false);
            edtCompetitorHybrid2Py.setEnabled(false);

            //newly added
            edtSeedSettingIssue1Py.setEnabled(false);
            edtSeedSettingIssue2Py.setEnabled(false);
            edtSeedSettingIssue3Py.setEnabled(false);
            edtSeedSettingIssue4Py.setEnabled(false);

            edtCompeHybrid1SeedSettingIssuePy.setEnabled(false);
            edtCompeHybrid2SeedSettingIssuePy.setEnabled(false);
        }

        edtCompetitorHybrid1Cy.setEnabled(true);
        edtCompetitorHybrid2Cy.setEnabled(true);

        spnOtherCropAcres1.setEnabled(true);
        spnPioneerHyb1Name.setEnabled(true);

        edtCompetitorHybrid1.setEnabled(true);
        edtCompetitorHybrid2.setEnabled(true);

        //newly added
        edtCompeHybrid1SeedSettingIssueCy.setEnabled(true);
        edtCompeHybrid2SeedSettingIssueCy.setEnabled(true);
    }


    private void disableForm() {
        clearForm();
        isSpecialCase = false;
        edtCropAcresCy.setEnabled(false);
        edtHybridCropAcresCy.setEnabled(false);
        //newly added
        edtF2AcreagesCy.setEnabled(false);
        edtOtherCropAcresCy.setEnabled(false);
        edtOtherCropAcres2Cy.setEnabled(false);

        //newly added
        edtSeedSettingIssueCy.setEnabled(false);
        edtCropAcresPy.setEnabled(false);
        edtHybridCropAcresPy.setEnabled(false);
        //newly addd
        edtF2AcreagesPy.setEnabled(false);
        //newly addd
        edtSeedSettingIssuePy.setEnabled(false);
        edtOtherCropAcresPy.setEnabled(false);
        edtOtherCropAcres2Py.setEnabled(false);

        edtPioneerHybrid1Py.setEnabled(false);
        edtPioneerHybrid2Py.setEnabled(false);
        edtPioneerHybrid3Py.setEnabled(false);
        edtPioneerHybrid4Py.setEnabled(false);

        edtCompetitorHybrid1Py.setEnabled(false);
        edtCompetitorHybrid2Py.setEnabled(false);

        //newly added
        edtSeedSettingIssue1Py.setEnabled(false);
        edtSeedSettingIssue2Py.setEnabled(false);
        edtSeedSettingIssue3Py.setEnabled(false);
        edtSeedSettingIssue4Py.setEnabled(false);

        edtCompeHybrid1SeedSettingIssuePy.setEnabled(false);
        edtCompeHybrid2SeedSettingIssuePy.setEnabled(false);

        edtPioneerHybrid1Cy.setEnabled(false);
        edtPioneerHybrid2Cy.setEnabled(false);
        edtPioneerHybrid3Cy.setEnabled(false);
        edtPioneerHybrid4Cy.setEnabled(false);

        edtCompetitorHybrid1Cy.setEnabled(false);
        edtCompetitorHybrid2Cy.setEnabled(false);

        //newly added
        edtSeedSettingIssue1Cy.setEnabled(false);
        edtSeedSettingIssue2Cy.setEnabled(false);
        edtSeedSettingIssue3Cy.setEnabled(false);
        edtSeedSettingIssue4Cy.setEnabled(false);

        edtCompeHybrid1SeedSettingIssueCy.setEnabled(false);
        edtCompeHybrid2SeedSettingIssueCy.setEnabled(false);

        spnOtherCropAcres1.setEnabled(false);
        spnOtherCropAcres2.setEnabled(false);

        spnPioneerHyb1Name.setEnabled(false);
        spnPioneerHyb2Name.setEnabled(false);
        spnPioneerHyb3Name.setEnabled(false);
        spnPioneerHyb4Name.setEnabled(false);

        edtCompetitorHybrid1.setEnabled(false);
        edtCompetitorHybrid2.setEnabled(false);
    }

    private String validateFields() {
        if (spnPhase.getSelectedItemPosition() <= 0) {
            return "Select Phase";
        }

        if (spnYear.getSelectedItemPosition() <= 0) {
            return "Select Planed Year";
        }

        if (spnSeason.getSelectedItemPosition() <= 0) {
            return "Select Season";
        }

        if (spnCrop.getSelectedItemPosition() <= 0) {
            return "Select Crop";
        }

        //newly added
        if (spnUserType.getSelectedItemPosition() <= 0) {
            return "Select user type";
        }
        String phaseAction = null;
        if (spnPhase.getSelectedItemPosition() == 1) {
            phaseAction = "plan";
            if (spnSampleIssued.getSelectedItemPosition() <= 0) {
                return "Select sample issued";
            }

            if (spnSampleIssued.getSelectedItemPosition() == 1) {
                if (spnHybrid.getSelectedItemPosition() <= 0) {
                    return "Select issued sample hybrid";
                }
            }

            if (isEmpty(edtFarmerName)) {
                return "Enter farmer name";
            }

            if (isEmpty(edtHybridCropAcresCy)) {
                return "Enter value for " + tvHybridCropAcres.getText().toString();
            }

          /*  if (!isEmpty(spnPioneerHyb1Name) && getText(spnPioneerHyb1Name).equals(getText(spnPioneerHyb2Name))) {
                return "Pioneer hybrid1 and hybrid2 should not be same";
            }*/
        } else if (spnPhase.getSelectedItemPosition() == 2) {
            phaseAction = "actual";
        }

        if (isEmpty(edtFarmerMobileNo)) {
            return "Enter farmer mobile number";
        }

        if (getText(edtFarmerMobileNo).length() != 10) {
            return "Enter valid mobile number";
        }

        //newly added
        if (!isEmpty(edtPioneerHybrid1Cy) && !isEmpty(edtSeedSettingIssue1Cy))
            if (Float.valueOf(edtSeedSettingIssue1Cy.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid1Cy.getText().toString().trim()))
                return "Seed setting issue value should not greater than pioneer hybrid 1 " + phaseAction;

        if (!isEmpty(edtPioneerHybrid2Cy) && !isEmpty(edtSeedSettingIssue2Cy))
            if (Float.valueOf(edtSeedSettingIssue2Cy.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid2Cy.getText().toString().trim()))
                return "Seed setting issue value should not greater than pioneer hybrid 2 " + phaseAction;

        if (!isEmpty(edtPioneerHybrid3Cy) && !isEmpty(edtSeedSettingIssue3Cy))
            if (Float.valueOf(edtSeedSettingIssue3Cy.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid3Cy.getText().toString().trim()))
                return "Seed setting issue value should not greater than pioneer hybrid3 " + phaseAction;

        if (!isEmpty(edtPioneerHybrid4Cy) && !isEmpty(edtSeedSettingIssue4Cy))
            if (Float.valueOf(edtSeedSettingIssue4Cy.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid4Cy.getText().toString().trim()))
                return "Seed setting issue value should not greater than pioneer hybrid 4 " + phaseAction;

        if (!isEmpty(edtCompetitorHybrid1Cy) && !isEmpty(edtCompeHybrid1SeedSettingIssueCy))
            if (Float.valueOf(edtCompeHybrid1SeedSettingIssueCy.getText().toString().trim()) > Float.valueOf(edtCompetitorHybrid1Cy.getText().toString().trim())) {
                return " Competitor hybrid 1 seed setting issue value should not greater than competitor hybrid 1 " + phaseAction;
            }

        if (!isEmpty(edtCompetitorHybrid2Cy) && !isEmpty(edtCompeHybrid2SeedSettingIssueCy))
            if (Float.valueOf(edtCompeHybrid2SeedSettingIssueCy.getText().toString().trim()) > Float.valueOf(edtCompetitorHybrid2Cy.getText().toString().trim())) {
                return " Competitor hybrid 2 seed setting issue value should not greater than competitor hybrid 2 " + phaseAction;
            }

        if (isSpecialCase) {

            if (Float.valueOf(edtOtherCropAcresPy.getText().toString()) > 0 || !isEmpty(edtOtherCropAcresCy)) {
                if (other1CropName.equalsIgnoreCase("Other Crop Acres 1"))
                    return "Select Other Crop Acres 1";
            }
            if (spnOtherCropAcres1.getSelectedItemPosition() > 0) {
                if (Utility.isValidStr(edtOtherCropAcresPy.getText().toString().trim())) {
                    double edtOtherCropAcresPyValue = Double.valueOf(edtOtherCropAcresPy.getText().toString().trim());
                    if (edtOtherCropAcresPyValue == 0 && isEmpty(edtOtherCropAcresCy))
                        return "Enter Other Crop Acres 1 value";
                } else {
                    return "Enter Other Crop Acres 1 value";
                }
            }


            if (Float.valueOf(edtOtherCropAcres2Py.getText().toString()) > 0 || !isEmpty(edtOtherCropAcres2Cy)) {
                if (other2CropName.equalsIgnoreCase("Other Crop Acres 2"))
                    return "Select Other Crop Acres 2";
            }
            if (spnOtherCropAcres2.getSelectedItemPosition() > 0) {
                if (Utility.isValidStr(edtOtherCropAcres2Py.getText().toString().trim())) {
                    double edtOtherCropAcresPyValue = Double.valueOf(edtOtherCropAcres2Py.getText().toString().trim());
                    if (edtOtherCropAcresPyValue == 0 && isEmpty(edtOtherCropAcres2Cy))
                        return "Enter Other Crop Acres 2 value";
                } else {
                    return "Enter Other Crop Acres 2 value";
                }
            }

            if (Float.valueOf(edtPioneerHybrid1Py.getText().toString()) > 0 || !isEmpty(edtPioneerHybrid1Cy)) {
                if (pioneerHybrid1name.equalsIgnoreCase("Pioneer hybrid1"))
                    return "Select Pioneer Hybrid1";
            }
            if (spnPioneerHyb1Name.getSelectedItemPosition() > 0)
                if (isEmpty(edtPioneerHybrid1Py) && isEmpty(edtPioneerHybrid1Cy))
                    return "Enter Pioneer Hybrid1 value";

            if (Float.valueOf(edtPioneerHybrid2Py.getText().toString()) > 0 || !isEmpty(edtPioneerHybrid2Cy)) {
                if (pioneerHybrid2name.equalsIgnoreCase("Pioneer hybrid2"))
                    return "Select Pioneer Hybrid2";
            }
            if (spnPioneerHyb2Name.getSelectedItemPosition() > 0)
                if (isEmpty(edtPioneerHybrid2Py) && isEmpty(edtPioneerHybrid2Cy))
                    return "Enter Pioneer Hybrid2 value";

            if (Float.valueOf(edtPioneerHybrid3Py.getText().toString()) > 0 || !isEmpty(edtPioneerHybrid3Cy)) {
                if (pioneerHybrid3name.equalsIgnoreCase("Pioneer hybrid3"))
                    return "Select Pioneer Hybrid3";
            }
            if (spnPioneerHyb3Name.getSelectedItemPosition() > 0)
                if (isEmpty(edtPioneerHybrid3Py) && isEmpty(edtPioneerHybrid3Cy))
                    return "Enter Pioneer Hybrid3 value";

            if (Float.valueOf(edtPioneerHybrid4Py.getText().toString()) > 0 || !isEmpty(edtPioneerHybrid4Cy)) {
                if (pioneerHybrid4name.equalsIgnoreCase("Pioneer hybrid4"))
                    return "Select Pioneer Hybrid4";
            }
            if (spnPioneerHyb4Name.getSelectedItemPosition() > 0)
                if (isEmpty(edtPioneerHybrid4Py) && isEmpty(edtPioneerHybrid4Cy))
                    return "Enter Pioneer Hybrid4 value";

            if (Float.valueOf(edtCompetitorHybrid1Py.getText().toString()) > 0 || !isEmpty(edtCompetitorHybrid1Cy)) {
                if (isEmpty(edtCompetitorHybrid1))
                    return "Enter Competitor Hybrid1";
            }
            if (!isEmpty(edtCompetitorHybrid1))
                if (isEmpty(edtCompetitorHybrid1Py) && isEmpty(edtCompetitorHybrid1Cy))
                    return "Enter Competitor Hybrid1 value";

            if (Float.valueOf(edtCompetitorHybrid2Py.getText().toString()) > 0 || !isEmpty(edtCompetitorHybrid2Cy)) {
                if (isEmpty(edtCompetitorHybrid2))
                    return "Enter Competitor Hybrid2";
            }
            if (!isEmpty(edtCompetitorHybrid2))
                if (isEmpty(edtCompetitorHybrid2Py) && isEmpty(edtCompetitorHybrid2Cy))
                    return "Enter Competitor Hybrid2 value";

            float actualfarmedHybridAcresPy = getText(edtHybridCropAcresPy).isEmpty() ? 0.0f : Float.valueOf(getText(edtHybridCropAcresPy));
            float actualtotalHybAcresPy = getText(edtTotalHybridAcresPy).isEmpty() ? 0.0f : Float.valueOf(getText(edtTotalHybridAcresPy));
            if (actualfarmedHybridAcresPy != actualtotalHybAcresPy)
                return "Actual Hybrid " + cropNameList.get(spnCrop.getSelectedItemPosition()) + " Acres must be equals to Total Hybrid " + cropNameList.get(spnCrop.getSelectedItemPosition()) + " Acres";

            //Newly added
            if (!isEmpty(edtPioneerHybrid1Py) && !isEmpty(edtSeedSettingIssue1Py))
                if (Float.valueOf(edtSeedSettingIssue1Py.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid1Py.getText().toString().trim()))
                    return "Seed setting issue value should not greater than pioneer hybrid 1 actual";

            if (!isEmpty(edtPioneerHybrid2Py) && !isEmpty(edtSeedSettingIssue2Py))
                if (Float.valueOf(edtSeedSettingIssue2Py.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid2Py.getText().toString().trim()))
                    return "Seed setting issue value should not greater than pioneer hybrid 2 actual";

            if (!isEmpty(edtSeedSettingIssue3Py) && !isEmpty(edtPioneerHybrid3Py))
                if (Float.valueOf(edtSeedSettingIssue3Py.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid3Py.getText().toString().trim()))
                    return "Seed setting issue value should not greater than pioneer hybrid3 actual ";

            if (!isEmpty(edtPioneerHybrid4Py) && !isEmpty(edtSeedSettingIssue4Py))
                if (Float.valueOf(edtSeedSettingIssue4Py.getText().toString().trim()) > Float.valueOf(edtPioneerHybrid4Py.getText().toString().trim()))
                    return "Seed setting issue value should not greater than pioneer hybrid 4 actual";

            if (!isEmpty(edtCompetitorHybrid1Py) && !isEmpty(edtCompeHybrid1SeedSettingIssuePy))
                if (Float.valueOf(edtCompeHybrid1SeedSettingIssuePy.getText().toString().trim()) > Float.valueOf(edtCompetitorHybrid1Py.getText().toString().trim()))
                    return " Competitor hybrid 1 seed setting issue value should not greater than competitor hybrid 1 actual";

            if (!isEmpty(edtCompetitorHybrid2Py) && !isEmpty(edtCompeHybrid2SeedSettingIssuePy))
                if (Float.valueOf(edtCompeHybrid2SeedSettingIssuePy.getText().toString().trim()) > Float.valueOf(edtCompetitorHybrid2Py.getText().toString().trim()))
                    return " Competitor hybrid 2 seed setting issue value should not greater than competitor hybrid 2 actual";

        } else {

            if (spnOtherCropAcres1.getSelectedItemPosition() > 0) {
                if (isEmpty(edtOtherCropAcresCy))
                    return "Enter value for " + spnOtherCropAcres1.getSelectedItem().toString();
            }
            if (!isEmpty(edtOtherCropAcresCy)) {
                if (spnOtherCropAcres1.getSelectedItemPosition() <= 0)
                    return "Select other crop acres 1";
            }

            if (spnOtherCropAcres2.getSelectedItemPosition() > 0) {
                if (isEmpty(edtOtherCropAcres2Cy))
                    return "Enter value for " + spnOtherCropAcres2.getSelectedItem().toString();
            }
            if (!isEmpty(edtOtherCropAcres2Cy)) {
                if (spnOtherCropAcres2.getSelectedItemPosition() <= 0)
                    return "Select other crop acres 2";
            }


            if (spnPioneerHyb1Name.getSelectedItemPosition() > 0) {
                if (isEmpty(edtPioneerHybrid1Cy))
                    return "Enter value for hybrid " + spnPioneerHyb1Name.getSelectedItem().toString();
            }
            if (!isEmpty(edtPioneerHybrid1Cy)) {
                if (spnPioneerHyb1Name.getSelectedItemPosition() < 0)
                    return "Select Pioneer Hybrid1";
            }
            if (spnPioneerHyb2Name.getSelectedItemPosition() > 0) {
                if (isEmpty(edtPioneerHybrid2Cy))
                    return "Enter value for hybrid " + spnPioneerHyb2Name.getSelectedItem().toString();
            }
            if (!isEmpty(edtPioneerHybrid2Cy)) {
                if (spnPioneerHyb2Name.getSelectedItemPosition() < 0)
                    return "Select Pioneer Hybrid2";
            }
            if (spnPioneerHyb3Name.getSelectedItemPosition() > 0) {
                if (isEmpty(edtPioneerHybrid3Cy))
                    return "Enter value for hybrid " + spnPioneerHyb3Name.getSelectedItem().toString();
            }
            if (!isEmpty(edtPioneerHybrid3Cy)) {
                if (spnPioneerHyb3Name.getSelectedItemPosition() < 0)
                    return "Select Pioneer Hybrid3";
            }
            if (spnPioneerHyb4Name.getSelectedItemPosition() > 0) {
                if (isEmpty(edtPioneerHybrid4Cy))
                    return "Enter value for hybrid " + spnPioneerHyb4Name.getSelectedItem().toString();
            }
            if (!isEmpty(edtPioneerHybrid4Cy)) {
                if (spnPioneerHyb4Name.getSelectedItemPosition() < 0)
                    return "Select Pioneer Hybrid4";
            }

            if (!isEmpty(edtCompetitorHybrid1)) {
                if (isEmpty(edtCompetitorHybrid1Cy))
                    return "Enter value for hybrid " + getText(edtCompetitorHybrid1);
            }
            if (!isEmpty(edtCompetitorHybrid1Cy)) {
                if (isEmpty(edtCompetitorHybrid1))
                    return "Enter Competitor Hybrid1";
            }
            if (!isEmpty(edtCompetitorHybrid2)) {
                if (isEmpty(edtCompetitorHybrid2Cy))
                    return "Enter value for hybrid " + getText(edtCompetitorHybrid2);
            }
            if (!isEmpty(edtCompetitorHybrid2Cy)) {
                if (isEmpty(edtCompetitorHybrid2))
                    return "Enter Competitor Hybrid2";
            }
        }
        float farmedHybridAcres = getText(edtHybridCropAcresCy).isEmpty() ? 0.0f : Float.valueOf(getText(edtHybridCropAcresCy));

        float totalHybAcres = getText(edtTotalHybridAcresCy).isEmpty() ? 0.0f : Float.valueOf(getText(edtTotalHybridAcresCy));

//		float totalCropAcres = Float.valueOf(getText(edtCropAcresCy));

		/*if(totalCropAcres < totalHybAcres){
            return ""+cropNameList.get(spnCrop.getSelectedItemPosition())+" acres should not be less than hybrid "+cropNameList.get(spnCrop.getSelectedItemPosition())+" acres";
		}*/

        if (farmedHybridAcres != totalHybAcres)
            return "Hybrid " + cropNameList.get(spnCrop.getSelectedItemPosition()) + " Acres must be equals to Total Hybrid " + cropNameList.get(spnCrop.getSelectedItemPosition()) + " Acres";

        String strPioneerHybridName1, strPioneerHybridName2, strCompetitorHybridName1, strCompetitorHybridName2;
        strPioneerHybridName1 = spnPioneerHyb1Name.getSelectedItem().toString();
        strPioneerHybridName2 = spnPioneerHyb2Name.getSelectedItem().toString();
        strCompetitorHybridName1 = getText(edtCompetitorHybrid1);
        strCompetitorHybridName2 = getText(edtCompetitorHybrid2);

        if (!strPioneerHybridName1.isEmpty()) {
            if (strPioneerHybridName1.equals(strPioneerHybridName2) || strPioneerHybridName1.equals(strCompetitorHybridName1) ||
                    strPioneerHybridName1.equals(strCompetitorHybridName2))
                return "hybrid " + strPioneerHybridName1 + " is repeated";
        }

        if (!strPioneerHybridName2.isEmpty()) {
            if (strPioneerHybridName2.equals(strCompetitorHybridName1) || strPioneerHybridName2.equals(strCompetitorHybridName2))
                return "hybrid " + strPioneerHybridName2 + " is repeated";
        }

        if (!strCompetitorHybridName1.isEmpty()) {
            if (strCompetitorHybridName1.equals(strCompetitorHybridName2))
                return "hybrid " + strCompetitorHybridName1 + " is repeated";
        }

        return null;
    }


    private void saveData() {
        DipstickDTO dto = new DipstickDTO();
        dto.setActivityType(phasesArray[spnPhase.getSelectedItemPosition()]);
        dto.setYear(Integer.valueOf(strYear));
        long regionId = MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
        if (regionId != 0)
            dto.setRegionId(regionId);
        dto.setDate(Utility.getCurrentDateAndTime());
        dto.setLocation(location);
        dto.setSeasonId(seasonId);
        dto.setCropId(cropId);
        dto.setIsSampleIssued(sampleIssue);
        //newly added
        dto.setUserType(userTypeArray[spnUserType.getSelectedItemPosition()]);
        dto.setHybridId(hybridId);
        dto.setFarmerName(getText(edtFarmerName));
        dto.setFarmerNumber(getText(edtFarmerMobileNo));
        dto.setCropAcres(getText(edtCropAcresCy));
        dto.setHybridCropAcres(getText(edtHybridCropAcresCy));
        //newly added
        if (Utility.isValidStr(getText(edtF2AcreagesCy))) {
            dto.setF2Acreages(getText(edtF2AcreagesCy));
        }
        //newly added
        if (Utility.isValidStr(getText(edtSeedSettingIssueCy))) {
            dto.setSeedSettingIssue(getText(edtSeedSettingIssueCy));
        }
//        dto.setOtherCropAcres(getText(edtOtherCropAcresCy));
        dto.setOtherCrop1(selectedOtherCropAcresId1);
        dto.setOtherCrop2(selectedOtherCropAcresId2);

        if (!getText(edtPioneerHybrid1Cy).isEmpty() && Float.valueOf(getText(edtPioneerHybrid1Cy)) > 0) {
            dto.setPioneerHyb1(getText(edtPioneerHybrid1Cy));
            dto.setPioneerHyb1Name(spnPioneerHyb1Name.getSelectedItem().toString());
        }

        //newly added
        if (!getText(edtSeedSettingIssue1Cy).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue1Cy)) > 0)
            dto.setSeedSettingIssue1(getText(edtSeedSettingIssue1Cy));

        if (!getText(edtPioneerHybrid2Cy).isEmpty() && Float.valueOf(getText(edtPioneerHybrid2Cy)) > 0) {
            dto.setPioneerHyb2(getText(edtPioneerHybrid2Cy));
            dto.setPioneerHyb2Name(spnPioneerHyb2Name.getSelectedItem().toString());
        }
        //newly added
        if (!getText(edtSeedSettingIssue2Cy).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue2Cy)) > 0)
            dto.setSeedSettingIssue2(getText(edtSeedSettingIssue2Cy));

        if (!getText(edtPioneerHybrid3Cy).isEmpty() && Float.valueOf(getText(edtPioneerHybrid3Cy)) > 0) {
            dto.setPioneerHyb3(getText(edtPioneerHybrid3Cy));
            dto.setPioneerHyb3Name(spnPioneerHyb3Name.getSelectedItem().toString());
        }

        //newly added
        if (!getText(edtSeedSettingIssue3Cy).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue3Cy)) > 0)
            dto.setSeedSettingIssue3(getText(edtSeedSettingIssue3Cy));

        if (!getText(edtPioneerHybrid4Cy).isEmpty() && Float.valueOf(getText(edtPioneerHybrid4Cy)) > 0) {
            dto.setPioneerHyb4(getText(edtPioneerHybrid4Cy));
            dto.setPioneerHyb4Name(spnPioneerHyb4Name.getSelectedItem().toString());
        }

        //newly added
        if (!getText(edtSeedSettingIssue4Cy).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue4Cy)) > 0)
            dto.setSeedSettingIssue4(getText(edtSeedSettingIssue4Cy));


        if (!getText(edtCompetitorHybrid1Cy).isEmpty() && Float.valueOf(getText(edtCompetitorHybrid1Cy)) > 0) {
            dto.setCompetitorHybrid1(getText(edtCompetitorHybrid1Cy));
            dto.setCompetitorHybrid1Name(getText(edtCompetitorHybrid1));
        }
        //newly added
        if (!getText(edtCompeHybrid1SeedSettingIssueCy).isEmpty() && Float.valueOf(getText(edtCompeHybrid1SeedSettingIssueCy)) > 0)
            dto.setCompetitorHybrid1SeedSettingIssue(getText(edtCompeHybrid1SeedSettingIssueCy));

        if (!getText(edtCompetitorHybrid2Cy).isEmpty() && Float.valueOf(getText(edtCompetitorHybrid2Cy)) > 0) {
            dto.setCompetitorHybrid2(getText(edtCompetitorHybrid2Cy));
            dto.setCompetitorHybrid2Name(getText(edtCompetitorHybrid2));
        }

        //newly added
        if (!getText(edtCompeHybrid2SeedSettingIssueCy).isEmpty() && Float.valueOf(getText(edtCompeHybrid2SeedSettingIssueCy)) > 0)
            dto.setCompetitorHybrid2SeedSettingIssue(getText(edtCompeHybrid2SeedSettingIssueCy));

        if (!getText(edtOtherCropAcresCy).isEmpty() && Double.valueOf(getText(edtOtherCropAcresCy)) > 0) {
            dto.setOtherCropArea1(Double.valueOf(getText(edtOtherCropAcresCy)));
        }

        if (!getText(edtOtherCropAcres2Cy).isEmpty() && Double.valueOf(getText(edtOtherCropAcres2Cy)) > 0) {
            dto.setOtherCropArea2(Double.valueOf(getText(edtOtherCropAcres2Cy)));
        }
        dto.setIsSync(1);
        result = DipstickDAO.getInstance().insertActivity(dto, DBHandler.getInstance(mActivity).getDBObject(1));
        //Updating Master Data
        if (isSpecialCase && !edtHybridCropAcresPy.getText().toString().trim().equals("0") && phasesArray[spnPhase.getSelectedItemPosition()].equalsIgnoreCase("PI")) {
            DipstickDTO masterdto = new DipstickDTO();
            masterdto.setActivityType(MyConstants.PHASE_SU);
            masterdto.setYear(Integer.valueOf(strYear) - 1);
            long masterRegionId = MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
            if (regionId != 0)
                masterdto.setRegionId(masterRegionId);
            masterdto.setDate(Utility.getCurrentDateAndTime());
            masterdto.setLocation(location);
            masterdto.setSeasonId(seasonId);
            masterdto.setCropId(cropId);
            masterdto.setIsSampleIssued(sampleIssue);
            //newly added
            masterdto.setUserType(userTypeArray[spnUserType.getSelectedItemPosition()]);
            masterdto.setHybridId(hybridId);
            masterdto.setFarmerName(getText(edtFarmerName));
            masterdto.setFarmerNumber(getText(edtFarmerMobileNo));
            masterdto.setCropAcres(getText(edtCropAcresPy));
            masterdto.setHybridCropAcres(getText(edtHybridCropAcresPy));
            //newly added
            if (Utility.isValidStr(getText(edtF2AcreagesPy))) {
                masterdto.setF2Acreages(getText(edtF2AcreagesPy));
            }
            //newly added
            if (Utility.isValidStr(getText(edtSeedSettingIssuePy))) {
                masterdto.setSeedSettingIssue(getText(edtSeedSettingIssuePy));
            }
//            masterdto.setOtherCropAcres(getText(edtOtherCropAcresPy));
            masterdto.setOtherCrop1(selectedOtherCropAcresId1);
            masterdto.setOtherCrop2(selectedOtherCropAcresId2);

            if (!getText(edtPioneerHybrid1Py).isEmpty() && Float.valueOf(getText(edtPioneerHybrid1Py)) > 0) {
                masterdto.setPioneerHyb1(getText(edtPioneerHybrid1Py));
                masterdto.setPioneerHyb1Name(spnPioneerHyb1Name.getSelectedItem().toString());
            }

            //newly added
            if (!getText(edtSeedSettingIssue1Py).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue1Py)) > 0)
                masterdto.setSeedSettingIssue1(getText(edtSeedSettingIssue1Py));


            if (!getText(edtPioneerHybrid2Py).isEmpty() && Float.valueOf(getText(edtPioneerHybrid2Py)) > 0) {
                masterdto.setPioneerHyb2(getText(edtPioneerHybrid2Py));
                masterdto.setPioneerHyb2Name(spnPioneerHyb2Name.getSelectedItem().toString());
            }

            //newly added
            if (!getText(edtSeedSettingIssue2Py).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue2Py)) > 0)
                masterdto.setSeedSettingIssue2(getText(edtSeedSettingIssue2Py));


            if (!getText(edtPioneerHybrid3Py).isEmpty() && Float.valueOf(getText(edtPioneerHybrid3Py)) > 0) {
                masterdto.setPioneerHyb3(getText(edtPioneerHybrid3Py));
                masterdto.setPioneerHyb3Name(spnPioneerHyb3Name.getSelectedItem().toString());
            }

            //newly added
            if (!getText(edtSeedSettingIssue3Py).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue3Py)) > 0)
                masterdto.setSeedSettingIssue3(getText(edtSeedSettingIssue3Py));

            if (!getText(edtPioneerHybrid4Py).isEmpty() && Float.valueOf(getText(edtPioneerHybrid4Py)) > 0) {
                masterdto.setPioneerHyb4(getText(edtPioneerHybrid4Py));
                masterdto.setPioneerHyb4Name(spnPioneerHyb4Name.getSelectedItem().toString());
            }

            //newly added
            if (!getText(edtSeedSettingIssue4Py).isEmpty() && Float.valueOf(getText(edtSeedSettingIssue4Py)) > 0)
                masterdto.setSeedSettingIssue4(getText(edtSeedSettingIssue4Py));

            if (!getText(edtCompetitorHybrid1Py).isEmpty() && Float.valueOf(getText(edtCompetitorHybrid1Py)) > 0) {
                masterdto.setCompetitorHybrid1(getText(edtCompetitorHybrid1Py));
                masterdto.setCompetitorHybrid1Name(getText(edtCompetitorHybrid1));
            }
            //newly added
            if (!getText(edtCompeHybrid1SeedSettingIssuePy).isEmpty() && Float.valueOf(getText(edtCompeHybrid1SeedSettingIssuePy)) > 0)
                masterdto.setCompetitorHybrid1SeedSettingIssue(getText(edtCompeHybrid1SeedSettingIssuePy));

            if (!getText(edtCompetitorHybrid2Py).isEmpty() && Float.valueOf(getText(edtCompetitorHybrid2Py)) > 0) {
                masterdto.setCompetitorHybrid2(getText(edtCompetitorHybrid2Py));
                masterdto.setCompetitorHybrid2Name(getText(edtCompetitorHybrid2));
            }

            //newly added
            if (!getText(edtCompeHybrid2SeedSettingIssuePy).isEmpty() && Float.valueOf(getText(edtCompeHybrid2SeedSettingIssuePy)) > 0)
                masterdto.setCompetitorHybrid2SeedSettingIssue(getText(edtCompeHybrid2SeedSettingIssuePy));

            if (!getText(edtOtherCropAcresPy).isEmpty() && Double.valueOf(getText(edtOtherCropAcresPy)) > 0) {
                masterdto.setOtherCropArea1(Double.valueOf(getText(edtOtherCropAcresPy)));
            }

            if (!getText(edtOtherCropAcres2Py).isEmpty() && Double.valueOf(getText(edtOtherCropAcres2Py)) > 0) {
                masterdto.setOtherCropArea2(Double.valueOf(getText(edtOtherCropAcres2Py)));
            }
            masterdto.setIsSync(1);
            masterResult = DipstickDAO.getInstance().insertActivity(masterdto, DBHandler.getInstance(mActivity).getDBObject(1));
        }

        if (result > 0) {
            Utility.showAlert(mActivity, null, "Saved Successfully");
            spnPhase.setSelection(0);
            spnUserType.setSelection(0);
            spnUserType.setEnabled(true);
            //clear name dummy
            edtFarmerName.setText("");
            hideSeedSetting();
        } else if (result == -2) {
            Utility.showAlert(mActivity, null, "For Phase " + dto.getActivityType() + ", Year " + dto.getYear() + ", Season " + seasonNameList.get(spnSeason.getSelectedItemPosition()) + ", Crop " + cropNameList.get(spnCrop.getSelectedItemPosition()) + " for Farmer " + dto.getFarmerName() + " already exists");
        } else {
            Utility.showAlert(mActivity, null, "Failed Save Data");
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.dp_submit) {
            /*String validation = validateFields();
            if(validation == null){
				saveData();
			}else{
				Utility.showAlert(mActivity, null, validation);
			}*/
            dipstick_layout.clearFocus();

            String validation = validateFields();
            if (validation == null) {
                if (checkForLocation) {
                    if (location != null && location.length() > 0) {
                        showAlertToSave();
                    } else {
                        getCurrentLocation(mActivity);
                    }
                } else {
                    showAlertToSave();
                }

            } else {
                Utility.showAlert(mActivity, "", validation);
            }
        }

    }


    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveData();
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void purchaseIntention() {
//        spnOtherCropAcres1.setEnabled(true);
//        spnOtherCropAcres2.setEnabled(true);

//        spnPioneerHyb1Name.setEnabled(true);
//        spnPioneerHyb2Name.setEnabled(true);
//        spnPioneerHyb3Name.setEnabled(true);
//        spnPioneerHyb4Name.setEnabled(true);
//        edtFarmerName.setEnabled(true);

        spnSampleIssued.setVisibility(View.VISIBLE);
    }

    private void followUp() {
        spnOtherCropAcres1.setEnabled(false);
        spnOtherCropAcres2.setEnabled(false);
        spnPioneerHyb1Name.setEnabled(false);
        spnPioneerHyb2Name.setEnabled(false);
        spnPioneerHyb3Name.setEnabled(false);
        spnPioneerHyb4Name.setEnabled(false);
        edtFarmerName.setEnabled(false);
        spnSampleIssued.setSelection(0);
        spnSampleIssued.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            if (!mGoogleApiClient.isConnected())
                mGoogleApiClient.connect();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mGoogleApiClient != null) {
            if (mGoogleApiClient.isConnected())
                mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onDestroy() {
        checkForLocation = true;
        location = null;
        super.onDestroy();
    }

    private void showAlertToExitScreen(final int callbackCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                mActivity.onBackPressedCallBack(callbackCode);
            }
        });

        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    private boolean isDataAvailable() {
        if (spnPhase.getSelectedItemPosition() > 0) {
            return true;
        }

        if (spnYear.getSelectedItemPosition() > 0) {
            return true;
        }

        if (spnSeason.getSelectedItemPosition() > 0) {
            return true;
        }

        if (spnCrop.getSelectedItemPosition() > 0) {
            return true;
        }

        if (spnSampleIssued.getSelectedItemPosition() > 0) {
            return true;
        }
        //newly added
        return spnUserType.getSelectedItemPosition() > 0;
    }
}
