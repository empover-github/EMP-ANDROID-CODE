package com.activitytrack.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;
//import android.support.v4.graphics.drawable.DrawableCompat;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.adapter.CropAdapter;
import com.activitytrack.apiinterface.APIRequestHandler;
import com.activitytrack.apiinterface.ComonInterface;
import com.activitytrack.daos.FSMasterDivisionDAO;
import com.activitytrack.daos.FarmerSchoolSilageDAO;
import com.activitytrack.daos.FarmerSegmentationDAO;
import com.activitytrack.daos.FarmerSegmentationRiceDAO;
import com.activitytrack.daos.SegmentationCropDAO;
import com.activitytrack.daos.SegmentationGrainHybridDAO;
import com.activitytrack.daos.SegmentationGrainServicesDAO;
import com.activitytrack.daos.SegmentationRiceHybridDAO;
import com.activitytrack.daos.SegmentationRiceServicesDAO;
import com.activitytrack.daos.SegmentationSchoolDAO;
import com.activitytrack.daos.SegmentationSeasonDAO;
import com.activitytrack.daos.SegmentationSilageHybridDAO;
import com.activitytrack.daos.SegmentationSilageServicesDAO;
import com.activitytrack.daos.SegmentationYearDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.FarmerSchoolSilageDTO;
import com.activitytrack.dtos.FarmerSegmentationNestleResponse;
import com.activitytrack.dtos.FarmerSegmentationNestleResponseDTO;
import com.activitytrack.dtos.FarmerSegmentationRequest;
import com.activitytrack.dtos.FarmerSegmentationRequestDTO;
import com.activitytrack.dtos.FarmerSegmentationResponse;
import com.activitytrack.dtos.FarmerSegmentationResponseDTO;
import com.activitytrack.dtos.SegmentationRequestDTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.models.IdNameModel;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MultiSpinner;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.bumptech.glide.Glide;

import net.sourceforge.opencamera.MainActivityOC;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit.RetrofitError;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;


public class FarmerSegmentationFragment extends BaseFragment implements View.OnClickListener, ComonInterface, CompoundButton.OnCheckedChangeListener {

    private View rootView;
    private ImageView profileImage;
    private Spinner spnYear, spnSeason, spnCrop, spnGrainHybrid1, spnGrainHybrid2, spnGrainHybrid3, spnGrainHybrid4, spnSilageHybrid1,
            spnSilageHybrid2, spnSilageHybrid3, spnSilageHybrid4;
    private MultiSpinner spnGrainServices1, spnSilageServices1;
    private EditText edtMobileNo, edtPincode, edtFarmerName, edtDistrictName, edtVillageName, edtBlockName, edtPlanCrop, edtGrainAC,
            edtSilageAC, edtGrainHybridValue1, edtGrainHybridValue2, edtGrainHybridValue3, edtGrainHybridValue4, edtSilageHybridValue1,
            edtSilageHybridValue2, edtCompetitorGrainPlanValue1, edtCompetitorGrainPlanValue2, edtCompetitorGrainPlanValue3,
            edtCompetitorGrainPlanValue4, edtCompetitorSilagePlanValue1, edtCompetitorSilagePlanValue2, fb_shift_yearET;
    private Button btnEdit;
    private Button btnGetDetails;
    private Button btnProceedNext;
    private LinearLayout lnrFarmerDetails;
    private LinearLayout lnrExpandFarmerDetails;
    private LinearLayout lnrExpandFarmerAC;
    private LinearLayout lnrExpandGrainAC;
    private LinearLayout lnrExpandSilageAC;
    private LinearLayout lnrExpandCompetitorGrainPlan;
    private LinearLayout lnrExpandCompetitorSilagePlan;
    private LinearLayout lnrGrainServices1;
    private LinearLayout lnrSilageServices1;

    private LinearLayout lnrLayoutHeading, lnrExpandHeading, lnrExpandCurrentHybrid, lnrExpandTraining;
    private ImageView imgHeading, imgCurrentHybrid, imgTraining, imgFeedback;

    private EditText edtPHIGrainAC, edtPHISilageAC, edtCompetitorGrainPlan1, edtCompetitorGrainPlan2, edtCompetitorGrainPlan3, edtCompetitorGrainPlan4, edtCompetitorSilagePlan1, edtCompetitorSilagePlan2;
    private ImageView imgFarmerDetails, imgFarmerAC, imgGrainAC, imgSilageAC, imgCompetitorGrainPlan, imgCompetitorSilagePlan;
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    private static final int REQUEST_CODE_FOR_IMAGE_CROPPING = 65;
    public static final int OPENCAMERA = 300;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private String imagePath;
    private Uri uriStr;
    private RadioGroup radioGroup, radioGroupSowingRice, radioGroupSilageFeeding, feedbackRadioGrp;
    private List<IdNameModel> yearList = new ArrayList<>();
    private List<IdNameModel> seasonList = new ArrayList<>();
    private List<IdNameModel> cropList = new ArrayList<>();
    private List<String> growProduceList = new ArrayList<>();
    private List<String> originalGrainHybridList = new ArrayList<>();
    private List<String> originalSilageHybridList = new ArrayList<>();
    private List<String> grainHybrid1List = new ArrayList<>();
    private List<String> grainHybrid2List = new ArrayList<>();
    private List<String> grainHybrid3List = new ArrayList<>();
    private List<String> grainHybrid4List = new ArrayList<>();
    private List<String> silageHybrid1List = new ArrayList<>();
    private List<String> silageHybrid2List = new ArrayList<>();
    private List<String> silageHybrid3List = new ArrayList<>();
    private List<String> silageHybrid4List = new ArrayList<>();
    private List<IdNameModel> originalGrainServicesList = new ArrayList<>();
    private List<IdNameModel> originalSilageServicesList = new ArrayList<>();
    private List<String> stringGrainServicesList = new ArrayList<>();
    private List<String> stringSilageServicesList = new ArrayList<>();
    private ArrayAdapter<String> grainServicesAdapter, silageServicesAdapter, riceServicesAdapter;

    private String grainHybrid1name = "";
    private String grainHybrid2name = "";
    private String grainHybrid3name = "";
    private String grainHybrid4name = "";

    private String silageHybrid1name = "";
    private String silageHybrid2name = "";
    private String silageHybrid3name = "";
    private String silageHybrid4name = "";

    private boolean[] selectedItems, silageSelectedItems, riceSelectedItems;
    private List<String> segmentationGrainHybridDTOList, segmentationSilageHybridDTOList;
    private TextView txtTotalCrop, txtHybridRice, txtSilageCrop;
    private String loginId, mobileNo, appVersion, deviceType;
    private FarmerSegmentationResponseDTO dto;
    private FarmerSegmentationNestleResponseDTO dtoNestle;
    private TextView grainHybridCommitHeaderTv, grainHybridCompititorHeaderTv, silageHybridCommitHeaderTv, silageHybridCompititorHeaderTv;
    private String latLongValues;
    private String seletedCrop;
    //newly added for rice
    private LinearLayout lnrImgClickFarmerAC, lnrImgClickMaturity, lnrExpandMaturity, lnrImgClickCompetitorGrainPlan, lnrLayoutDirectSowing, lnrImgClickSilageAC, lnrTypeIrrgiation, lnrfeedbackHeader, lnrFeedbackBody, lnrFeedbackYesLL;
    LinearLayout lnrImgClickHeading, lnrImgClickCurrentHybrid, lnrImgClickTraining;
    private ImageView imgMaturity;
    private Spinner spnIrrgiaTypes;
    private List<IdNameModel> originalRiceServicesList = new ArrayList<>();
    private List<String> stringRicenServicesList = new ArrayList<>();
    private List<String> segmentationRiceHybridDTOList;
    private List<String> originalRiceHybridList = new ArrayList<>();
    private List<String> riceHybrid1List = new ArrayList<>();
    private List<String> riceHybrid2List = new ArrayList<>();
    private List<String> riceHybrid3List = new ArrayList<>();
    private List<String> riceHybrid4List = new ArrayList<>();
    private String riceHybrid1name = "";
    private String riceHybrid2name = "";
    private String riceHybrid3name = "";
    private String riceHybrid4name = "";
    private EditText edtMaturity124Acr, edtMaturity134Acr, edtMaturity135Acr;
    private Button btnSubmit;

    private EditText edtCattleNestle, edtMilkNestle;


    private List<IdNameModel> farmerList = new ArrayList<>();
    private List<IdNameModel> schoolList = new ArrayList<>();
    private List<IdNameModel> divisionList = new ArrayList<>();
    private Spinner spnDivision, spnSchool;
    private View view1, view2;
    private LinearLayout lnrPlanCrops, lnrGrainAC, lnrSilageAC, lnrcattleNestle, lnrMilkNestle;
    private Spinner spnGrowing;
    private EditText edtAcresGrow;
    private TextView txtHybrid1, txtHybrid2, txtHybrid3, txtHybrid4, txtHybrid5;
    private EditText edtHybridValue1, edtHybridValue2, edtHybridValue3, edtHybridValue4, edtHybridValue5;
    private RadioGroup radioGroupPlant, radioGroupGrow, radioGroupHarvest, radioGroupStore, radioGroupFeed;

    private CropAdapter schoolAdapter;
    private LinearLayout lnrImgClickGrainAC;
    private LinearLayout lnrImgClickCompetitorSilagePlan;
    private LinearLayout lnrCornLayout, lnrGrowingAcres;
    private LinearLayout lnrSpnGrowing;
    private String serverImagePath;
    private TextView feedbackShiftYearTv;
    private CheckBox cbShelling, cbGrainWeight, cbEarliness, cbGrainMoisture, cbStandability;
    private RatingBar fbRatingBar;
    private int nextYear;
    static String yearGet;

    //new Added kiran
    TextView commitment_strip_tv;
    EditText edtCompetitorSilagePlan3, edtCompetitorSilagePlanValue3, edtCompetitorSilagePlan4, edtCompetitorSilagePlanValue4,
            edtCompetitorSilagePlan5, edtCompetitorSilagePlanValue5, edtCompetitorGrainPlan5, edtCompetitorGrainPlanValue5;
    LinearLayout layout_competitor3, layout_competitor4, layout_competitor5, layout_competitorGrain5;
    EditText edtSilageHybridValue3, edtSilageHybridValue4;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.at_segmentation_fragment, container, false);

        location = null;
        getIntentData();
        initializationViews();
        if (checkLocPermission()) {
            if (Utility.checkPlayServices(mActivity)) {
                buildGoogleApiClient();
            }
        }

        layout_competitor3.setVisibility(View.GONE);
        layout_competitor4.setVisibility(View.GONE);
        layout_competitor5.setVisibility(View.GONE);
        layout_competitorGrain5.setVisibility(View.GONE);

        return rootView;
    }

    private void getIntentData() {
        loginId = getArguments().getString("loginId");
        mobileNo = getArguments().getString("mobileNumber");
        appVersion = getArguments().getString("versionNo");
        deviceType = "Android";
    }

    private void initializationViews() {

        //newly added kiran
        commitment_strip_tv = rootView.findViewById(R.id.commitment_strip_tv);
        layout_competitor3 = rootView.findViewById(R.id.layout_competitor3);
        layout_competitor4 = rootView.findViewById(R.id.layout_competitor4);
        layout_competitor5 = rootView.findViewById(R.id.layout_competitor5);
        layout_competitorGrain5 = rootView.findViewById(R.id.layout_competitorGrain5);

        edtCompetitorGrainPlan5 = rootView.findViewById(R.id.edt_competitorGrain5);
        setFilter(edtCompetitorGrainPlan5);
        edtCompetitorGrainPlanValue5 = rootView.findViewById(R.id.edt_competitorGrainvalue5);

        edtCompetitorSilagePlan5 = rootView.findViewById(R.id.edt_competitorSilage5);
        setFilter(edtCompetitorSilagePlan5);
        edtCompetitorSilagePlanValue5 = rootView.findViewById(R.id.edt_competitorSilagevalue5);


        profileImage = rootView.findViewById(R.id.ns_profile_image);
        ImageView cameraIcon = rootView.findViewById(R.id.ns_profile_capture);

        spnYear = rootView.findViewById(R.id.sp_year);
        spnSeason = rootView.findViewById(R.id.sp_season);
        spnCrop = rootView.findViewById(R.id.sp_crop);

        view1 = rootView.findViewById(R.id.view);
        view2 = rootView.findViewById(R.id.view1);

        edtMobileNo = rootView.findViewById(R.id.edt_mobile);
        btnEdit = rootView.findViewById(R.id.btn_edit);
        edtPincode = rootView.findViewById(R.id.edt_pincode);
        btnGetDetails = rootView.findViewById(R.id.btn_mobile_submit);

        lnrFarmerDetails = rootView.findViewById(R.id.layout_farmer_details);
        LinearLayout lnrImgClickFarmerDetails = rootView.findViewById(R.id.ns_img_farmerDetails);
        imgFarmerDetails = rootView.findViewById(R.id.fs_img_farmerDetails);
        lnrExpandFarmerDetails = rootView.findViewById(R.id.layout_click_farmerDetails);
        edtFarmerName = rootView.findViewById(R.id.edt_name);
        edtDistrictName = rootView.findViewById(R.id.edt_district);
        edtBlockName = rootView.findViewById(R.id.edt_block);
        edtVillageName = rootView.findViewById(R.id.edt_village);

        txtTotalCrop = rootView.findViewById(R.id.txt_total_crop);
        edtPlanCrop = rootView.findViewById(R.id.edt_total_crop);
        edtGrainAC = rootView.findViewById(R.id.edt_plan_grain);
        edtSilageAC = rootView.findViewById(R.id.edt_plan_silage);
        btnProceedNext = rootView.findViewById(R.id.btn_proceed_next);

        lnrImgClickFarmerAC = rootView.findViewById(R.id.ns_img_farmerAC);
        imgFarmerAC = rootView.findViewById(R.id.fs_img_farmerAC);
        lnrExpandFarmerAC = rootView.findViewById(R.id.layout_click_farmerAC);
        lnrImgClickGrainAC = rootView.findViewById(R.id.ns_img_grainAC);
        imgGrainAC = rootView.findViewById(R.id.fs_img_grainAC);
        lnrExpandGrainAC = rootView.findViewById(R.id.layout_click_grainAC);
        lnrImgClickSilageAC = rootView.findViewById(R.id.ns_img_silageAC);
        imgSilageAC = rootView.findViewById(R.id.fs_img_silageAC);
        lnrExpandSilageAC = rootView.findViewById(R.id.layout_click_silageAC);
        lnrImgClickCompetitorGrainPlan = rootView.findViewById(R.id.ns_img_competitorGrainPlan);
        imgCompetitorGrainPlan = rootView.findViewById(R.id.fs_img_competitorGrainPlan);
        lnrExpandCompetitorGrainPlan = rootView.findViewById(R.id.layout_click_competitorGrainPlan);
        lnrImgClickCompetitorSilagePlan = rootView.findViewById(R.id.ns_img_competitorSilagePlan);
        imgCompetitorSilagePlan = rootView.findViewById(R.id.fs_img_competitorSilagePlan);
        lnrExpandCompetitorSilagePlan = rootView.findViewById(R.id.layout_click_competitorSilagePlan);
        lnrGrainServices1 = rootView.findViewById(R.id.layout_spinner13);
        lnrSilageServices1 = rootView.findViewById(R.id.layout_spinner14);

        lnrPlanCrops = rootView.findViewById(R.id.layout_total_crop);
        lnrGrainAC = rootView.findViewById(R.id.layout_plan_grain);
        lnrSilageAC = rootView.findViewById(R.id.layout_plan_silage);
        lnrcattleNestle = rootView.findViewById(R.id.layout_cattle_nestle);
        lnrMilkNestle = rootView.findViewById(R.id.layout_milk_nestle);

        edtPHIGrainAC = rootView.findViewById(R.id.edt_phi_ac_grain);
        edtPHISilageAC = rootView.findViewById(R.id.edt_phi_ac_silage);
        spnGrainHybrid1 = rootView.findViewById(R.id.sp_spinner1);
        spnGrainHybrid2 = rootView.findViewById(R.id.sp_spinner2);
        spnGrainHybrid3 = rootView.findViewById(R.id.sp_spinner3);
        spnGrainHybrid4 = rootView.findViewById(R.id.sp_spinner4);
        spnSilageHybrid1 = rootView.findViewById(R.id.sp_spinner5);
        spnSilageHybrid2 = rootView.findViewById(R.id.sp_spinner6);
        spnSilageHybrid3 = rootView.findViewById(R.id.sp_spinner7);
        spnSilageHybrid4 = rootView.findViewById(R.id.sp_spinner8);
        spnGrainServices1 = rootView.findViewById(R.id.sp_spinner13);
        spnSilageServices1 = rootView.findViewById(R.id.sp_spinner14);

        edtGrainHybridValue1 = rootView.findViewById(R.id.edt_spinner1);
        edtGrainHybridValue2 = rootView.findViewById(R.id.edt_spinner2);
        edtGrainHybridValue3 = rootView.findViewById(R.id.edt_spinner3);
        edtGrainHybridValue4 = rootView.findViewById(R.id.edt_spinner4);
        edtSilageHybridValue1 = rootView.findViewById(R.id.edt_spinner5);
        edtSilageHybridValue2 = rootView.findViewById(R.id.edt_spinner6);
        edtSilageHybridValue3 = rootView.findViewById(R.id.edt_spinner7);
        edtSilageHybridValue4 = rootView.findViewById(R.id.edt_spinner8);
        edtCompetitorGrainPlan1 = rootView.findViewById(R.id.edt_competitorGrain1);
        setFilter(edtCompetitorGrainPlan1);
        edtCompetitorGrainPlan2 = rootView.findViewById(R.id.edt_competitorGrain2);
        setFilter(edtCompetitorGrainPlan2);
        edtCompetitorGrainPlan3 = rootView.findViewById(R.id.edt_competitorGrain3);
        setFilter(edtCompetitorGrainPlan3);
        edtCompetitorGrainPlan4 = rootView.findViewById(R.id.edt_competitorGrain4);
        setFilter(edtCompetitorGrainPlan4);
        edtCompetitorGrainPlanValue1 = rootView.findViewById(R.id.edt_competitorGrainvalue1);
        edtCompetitorGrainPlanValue2 = rootView.findViewById(R.id.edt_competitorGrainvalue2);
        edtCompetitorGrainPlanValue3 = rootView.findViewById(R.id.edt_competitorGrainvalue3);
        edtCompetitorGrainPlanValue4 = rootView.findViewById(R.id.edt_competitorGrainvalue4);
        edtCompetitorSilagePlan1 = rootView.findViewById(R.id.edt_competitorSilage1);
        setFilter(edtCompetitorSilagePlan1);
        edtCompetitorSilagePlan2 = rootView.findViewById(R.id.edt_competitorSilage2);
        setFilter(edtCompetitorSilagePlan2);

        edtCompetitorSilagePlanValue1 = rootView.findViewById(R.id.edt_competitorSilagevalue1);
        edtCompetitorSilagePlanValue2 = rootView.findViewById(R.id.edt_competitorSilagevalue2);

        //newly added kiran
        edtCompetitorSilagePlan3 = rootView.findViewById(R.id.edt_competitorSilage3);
        setFilter(edtCompetitorSilagePlan3);
        edtCompetitorSilagePlan4 = rootView.findViewById(R.id.edt_competitorSilage4);
        setFilter(edtCompetitorSilagePlan4);

        edtCompetitorSilagePlanValue3 = rootView.findViewById(R.id.edt_competitorSilagevalue3);
        edtCompetitorSilagePlanValue4 = rootView.findViewById(R.id.edt_competitorSilagevalue4);

        radioGroup = rootView.findViewById(R.id.radio_tbl);

        btnSubmit = rootView.findViewById(R.id.btn_submit);

        grainHybridCommitHeaderTv = rootView.findViewById(R.id.fs_grain_commit_headerTv);
        grainHybridCompititorHeaderTv = rootView.findViewById(R.id.fs_grain_compititor_headerTv);
        silageHybridCommitHeaderTv = rootView.findViewById(R.id.fs_silage_commit_headerTv);
        silageHybridCompititorHeaderTv = rootView.findViewById(R.id.fs_silage_compititor_headerTv);

        //newly added
        txtHybridRice = rootView.findViewById(R.id.txt_plan_grain);
        txtSilageCrop = rootView.findViewById(R.id.txt_plan_silage);

        lnrImgClickMaturity = rootView.findViewById(R.id.ns_img_maturity_rice);
        lnrExpandMaturity = rootView.findViewById(R.id.layout_click_maturity);
        lnrImgClickMaturity.setOnClickListener(this);
        imgMaturity = rootView.findViewById(R.id.fs_img_maturity_rice);
        spnIrrgiaTypes = rootView.findViewById(R.id.spinner_phi_maturity_rice_types);
        lnrLayoutDirectSowing = rootView.findViewById(R.id.layout_direct_sowing_rice);

        radioGroupSowingRice = rootView.findViewById(R.id.radio_sowing_rice);
        lnrTypeIrrgiation = rootView.findViewById(R.id.layout_phi_maturity_types);

        edtMaturity124Acr = rootView.findViewById(R.id.edt_phi_maturity_rice_124);
        edtMaturity134Acr = rootView.findViewById(R.id.edt_phi_maturity_rice_134);
        edtMaturity135Acr = rootView.findViewById(R.id.edt_phi_maturity_rice_135);

        // Newly Added for static Nestle

        spnDivision = rootView.findViewById(R.id.farmer_division);
        spnSchool = rootView.findViewById(R.id.sp_school);


        edtCattleNestle = rootView.findViewById(R.id.edt_cattle_nestle);
        edtMilkNestle = rootView.findViewById(R.id.edt_milk_nestle);

        lnrLayoutHeading = rootView.findViewById(R.id.layout_heading);
        lnrImgClickHeading = rootView.findViewById(R.id.ns_img_heading1);
        lnrImgClickHeading.setOnClickListener(this);
        imgHeading = rootView.findViewById(R.id.fs_img_heading);
        lnrExpandHeading = rootView.findViewById(R.id.expand_heading);

        radioGroupSilageFeeding = rootView.findViewById(R.id.radio_feeding);
        spnGrowing = rootView.findViewById(R.id.sp_growing);
        edtAcresGrow = rootView.findViewById(R.id.edt_acres_grown);


        lnrImgClickCurrentHybrid = rootView.findViewById(R.id.ns_current_hybrid);
        lnrImgClickCurrentHybrid.setOnClickListener(this);
        imgCurrentHybrid = rootView.findViewById(R.id.fs_current_hybrid);
        lnrExpandCurrentHybrid = rootView.findViewById(R.id.expand_currentHybrid);

        txtHybrid1 = rootView.findViewById(R.id.txt_hybrid1);
        txtHybrid2 = rootView.findViewById(R.id.txt_hybrid2);
        txtHybrid3 = rootView.findViewById(R.id.txt_hybrid3);
        txtHybrid4 = rootView.findViewById(R.id.txt_hybrid4);
        txtHybrid5 = rootView.findViewById(R.id.txt_hybrid5);

        edtHybridValue1 = rootView.findViewById(R.id.edt_hybridvalue1);
        edtHybridValue2 = rootView.findViewById(R.id.edt_hybridvalue2);
        edtHybridValue3 = rootView.findViewById(R.id.edt_hybridvalue3);
        edtHybridValue4 = rootView.findViewById(R.id.edt_hybridvalue4);
        edtHybridValue5 = rootView.findViewById(R.id.edt_hybridvalue5);


        lnrImgClickTraining = rootView.findViewById(R.id.ns_training);
        lnrImgClickTraining.setOnClickListener(this);
        imgTraining = rootView.findViewById(R.id.fs_training);
        lnrExpandTraining = rootView.findViewById(R.id.expand_training);

        radioGroupPlant = rootView.findViewById(R.id.radio_plant);
        radioGroupGrow = rootView.findViewById(R.id.radio_grow);
        radioGroupHarvest = rootView.findViewById(R.id.radio_harvest);
        radioGroupStore = rootView.findViewById(R.id.radio_store);
        radioGroupFeed = rootView.findViewById(R.id.radio_feednestle);

        lnrCornLayout = rootView.findViewById(R.id.layout_corn);
        lnrGrowingAcres = rootView.findViewById(R.id.layout_acres_grown);
        lnrSpnGrowing = rootView.findViewById(R.id.layout_growing);


        lnrfeedbackHeader = rootView.findViewById(R.id.fs_feedback_header_ll);
        lnrfeedbackHeader.setOnClickListener(this);
        lnrFeedbackBody = rootView.findViewById(R.id.fs_feedback_body_ll);
        lnrFeedbackYesLL = rootView.findViewById(R.id.fs_feedback_yes_ll);
        lnrFeedbackYesLL.setVisibility(View.GONE);
        imgFeedback = rootView.findViewById(R.id.fs_img_feedback);
        feedbackShiftYearTv = rootView.findViewById(R.id.fs_feedback_shift_year);
        Calendar c = Calendar.getInstance();
        nextYear = c.get(Calendar.YEAR);
        nextYear = nextYear + 1;
        String fbShiftYearTv = getString(R.string.feedback_shift_hybrid_acres).replace("$1", String.valueOf(nextYear));
        feedbackShiftYearTv.setText(fbShiftYearTv);
        feedbackRadioGrp = rootView.findViewById(R.id.radio_feedback);
        feedbackRadioGrp.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radio_fb_yes) {
                lnrFeedbackYesLL.setVisibility(View.VISIBLE);
            } else {
                lnrFeedbackYesLL.setVisibility(View.GONE);
            }
        });
        cbShelling = rootView.findViewById(R.id.cb_shelling);
        cbGrainWeight = rootView.findViewById(R.id.cb_grain_weight);
        cbEarliness = rootView.findViewById(R.id.cb_earliness);
        cbGrainMoisture = rootView.findViewById(R.id.cb_grain_moisture);
        cbStandability = rootView.findViewById(R.id.cb_standability);

        cbShelling.setOnCheckedChangeListener(this);
        cbGrainWeight.setOnCheckedChangeListener(this);
        cbEarliness.setOnCheckedChangeListener(this);
        cbGrainMoisture.setOnCheckedChangeListener(this);
        cbStandability.setOnCheckedChangeListener(this);
        fb_shift_yearET = rootView.findViewById(R.id.fs_fb_shift_yr_perTv);
        fb_shift_yearET.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int percentage = Utility.isValidStr(s.toString()) ? Integer.valueOf(s.toString()) : 0;
                if (percentage < 0 || percentage > 100) {
                    fb_shift_yearET.setText("");
                } else {
                    fb_shift_yearET.setTag(percentage); // tag is not required, just not to put else part empty keeping this
                }
            }
        });
        fbRatingBar = rootView.findViewById(R.id.fs_fb_ratingBar);
//        fbRatingBar.setProgressDrawable(getResources().getDrawable(R.drawable.red_star_rating));
        setRatingStarColor(0, 0);

        fbRatingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating >= 0 && rating <= 3)
                    setRatingStarColor(1, rating);
                else if (rating >= 4 && rating <= 6)
                    setRatingStarColor(2, rating);
                else if (rating >= 7)
                    setRatingStarColor(3, rating);
                fbRatingBar.setTag(fbRatingBar.getRating());
            }
        });

        List<IdNameModel> divisionDTOList = FSMasterDivisionDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());
        List<IdNameModel> schoolDTOList = SegmentationSchoolDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());
        List<IdNameModel> yearDTOList = SegmentationYearDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());
        List<IdNameModel> seasonDTOList = SegmentationSeasonDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());
        List<IdNameModel> cropDTOList = SegmentationCropDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());

        if (divisionDTOList == null || divisionDTOList.size() <= 0 || yearDTOList == null || yearDTOList.size() <= 0 || seasonDTOList == null || seasonDTOList.size() <= 0 || cropDTOList == null || cropDTOList.size() <= 0 || schoolDTOList == null || schoolDTOList.size() <= 0) {
            DialogManager.showSingleBtnPopup(mActivity, new DialogMangerCallback() {
                @Override
                public void onOkClick() {
                    mActivity.displayView(8);
                }

                @Override
                public void onCancelClick(View view) {

                }
            }, "Alert!", "Please Download Farmer Segmentation master data from 'DATA SYNC", "OK");
        }

        divisionList.clear();
        if (divisionDTOList != null && divisionDTOList.size() > 0) {
            for (IdNameModel dto : divisionDTOList) {
                if (divisionList.size() == 0) {
                    divisionList.add(new IdNameModel(MyConstants.FARMER_SEGMENTATION));
                }
                divisionList.add(dto);
            }
        }

        schoolList.clear();
        if (schoolDTOList != null && schoolDTOList.size() > 0) {
            for (IdNameModel dto : schoolDTOList) {
                if (schoolList.size() == 0) {
                    schoolList.add(new IdNameModel("Select School"));
                }
                schoolList.add(dto);
            }
        }


        yearList.clear();
        if (yearDTOList != null && yearDTOList.size() > 0) {
            for (IdNameModel dto : yearDTOList) {
                if (yearList.size() == 0) {
                    yearList.add(new IdNameModel("Select Year"));
                }
                yearList.add(dto);
            }
        }


        seasonList.clear();
        if (seasonDTOList != null && seasonDTOList.size() > 0) {
            for (IdNameModel dto : seasonDTOList) {
                if (seasonList.size() == 0) {
                    seasonList.add(new IdNameModel("Select Season"));
                }
                seasonList.add(dto);
            }
        }

        cropList.clear();
        if (cropDTOList != null && cropDTOList.size() > 0) {
            for (IdNameModel dto : cropDTOList) {
                if (cropList.size() == 0) {
                    cropList.add(new IdNameModel("Select Crop"));
                }
                cropList.add(dto);
            }
        }


        CropAdapter yearAdapter = new CropAdapter(mActivity, yearList);
        CropAdapter seasonAdapter = new CropAdapter(mActivity, seasonList);
        CropAdapter cropAdapter = new CropAdapter(mActivity, cropList);
        CropAdapter divisionAdapter = new CropAdapter(mActivity, divisionList);
        schoolAdapter = new CropAdapter(mActivity, schoolList);

        spnSchool.setAdapter(schoolAdapter);
        spnDivision.setAdapter(divisionAdapter);
        spnYear.setAdapter(yearAdapter);
        spnSeason.setAdapter(seasonAdapter);
        spnCrop.setAdapter(cropAdapter);

        btnEdit.setEnabled(false);
        btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));

        profileImage.setOnClickListener(v -> openOptionsDialog());

        cameraIcon.setOnClickListener(v -> openOptionsDialog());

        edtMobileNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edtMobileNo.length() == 1 && edtMobileNo.getText().toString().trim().equalsIgnoreCase("0")) {
                    edtMobileNo.setText("");
                }
            }
        });

        edtPincode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edtPincode.length() == 1 && edtPincode.getText().toString().trim().equalsIgnoreCase("0")) {
                    edtPincode.setText("");
                }
            }
        });

        spnDivision.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                IdNameModel data = divisionList.get(position);
                spnDivision.setTag(data);
                String instituteId = String.valueOf(data.getId());
                if (position == 0) { // 0 means here we have selected farmer segmentation
                    view1.setVisibility(View.VISIBLE);
                    view2.setVisibility(View.VISIBLE);
                    spnYear.setVisibility(View.VISIBLE);
                    spnCrop.setVisibility(View.VISIBLE);
                    spnSeason.setVisibility(View.VISIBLE);
                    spnSchool.setVisibility(View.GONE);

                } else {
                    spnSchool.setSelection(0);
                    spnSchool.setEnabled(true);
                    view1.setVisibility(View.VISIBLE);
                    view2.setVisibility(View.GONE);
                    spnYear.setVisibility(View.VISIBLE);
                    spnSchool.setVisibility(View.VISIBLE);
                    spnCrop.setVisibility(View.GONE);
                    spnSeason.setVisibility(View.GONE);
                    dto = null;
                    setSpnSchool(instituteId);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnSchool.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                IdNameModel data = schoolList.get(position);
                spnSchool.setTag(data);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnSeason.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                IdNameModel data = seasonList.get(position);
                String seasonId = String.valueOf(data.getId());
                spnSeason.setTag(data);
                spnCrop.setSelection(0);
                if (position != 0) {
                    List<DTO> seasonByCropList = SegmentationCropDAO.getInstance().getRecordInfoByValue("seasonId", seasonId, DBHandler.getInstance(mActivity).getReadableDatabase());

                    cropList.clear();
                    if (seasonByCropList != null && seasonByCropList.size() > 0) {
                        for (DTO dto : seasonByCropList) {
                            if (cropList.size() == 0) {
                                cropList.add(new IdNameModel("Select Crop"));
                            }
                            IdNameModel idDTO = (IdNameModel) dto;
                            cropList.add(idDTO);
                        }
                    }
                    seasonAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spnCrop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                IdNameModel data = cropList.get(position);
                seletedCrop = data.getName();
                spnCrop.setTag(data);
                getMasterData();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position,
                                       long id) {
                IdNameModel data = yearList.get(position);
                spnYear.setTag(data);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        radioGroupSilageFeeding.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radio_feedyes) {
                lnrSpnGrowing.setVisibility(View.VISIBLE);
                lnrGrowingAcres.setVisibility(View.VISIBLE);
                lnrImgClickCurrentHybrid.setVisibility(View.VISIBLE);
                lnrExpandCurrentHybrid.setVisibility(View.VISIBLE);
            } else {
                lnrSpnGrowing.setVisibility(View.GONE);
                lnrGrowingAcres.setVisibility(View.GONE);
                lnrImgClickCurrentHybrid.setVisibility(View.GONE);
                lnrExpandCurrentHybrid.setVisibility(View.GONE);
                edtAcresGrow.setText("");
                spnGrowing.setSelection(0);
                edtHybridValue1.setText("");
                edtHybridValue2.setText("");
                edtHybridValue3.setText("");
                edtHybridValue4.setText("");
            }
        });

        btnGetDetails.setOnClickListener(this);
        btnEdit.setOnClickListener(this);

        lnrImgClickFarmerDetails.setOnClickListener(this);
        btnProceedNext.setOnClickListener(this);

        lnrImgClickFarmerAC.setOnClickListener(this);
        lnrImgClickGrainAC.setOnClickListener(this);
        lnrImgClickSilageAC.setOnClickListener(this);
        lnrImgClickCompetitorGrainPlan.setOnClickListener(this);
        lnrImgClickCompetitorSilagePlan.setOnClickListener(this);
        lnrImgClickHeading.setOnClickListener(this);
        lnrImgClickCurrentHybrid.setOnClickListener(this);
        lnrImgClickTraining.setOnClickListener(this);

        btnSubmit.setOnClickListener(this);


        edtHybridValue1.addTextChangedListener(new MyTextWatcher(edtHybridValue1));
        edtHybridValue2.addTextChangedListener(new MyTextWatcher(edtHybridValue2));
        edtHybridValue3.addTextChangedListener(new MyTextWatcher(edtHybridValue3));
        edtHybridValue4.addTextChangedListener(new MyTextWatcher(edtHybridValue4));
        edtHybridValue5.addTextChangedListener(new MyTextWatcher(edtHybridValue5));


        edtPlanCrop.addTextChangedListener(new MyTextWatcher(edtPlanCrop));
        edtGrainAC.addTextChangedListener(new MyTextWatcher(edtGrainAC));
        edtSilageAC.addTextChangedListener(new MyTextWatcher(edtSilageAC));
        edtPHIGrainAC.addTextChangedListener(new MyTextWatcher(edtPHIGrainAC));
        edtPHISilageAC.addTextChangedListener(new MyTextWatcher(edtPHISilageAC));
        edtGrainHybridValue1.addTextChangedListener(new MyTextWatcher(edtGrainHybridValue1));
        edtGrainHybridValue2.addTextChangedListener(new MyTextWatcher(edtGrainHybridValue2));
        edtGrainHybridValue3.addTextChangedListener(new MyTextWatcher(edtGrainHybridValue3));
        edtGrainHybridValue4.addTextChangedListener(new MyTextWatcher(edtGrainHybridValue4));
        edtSilageHybridValue1.addTextChangedListener(new MyTextWatcher(edtSilageHybridValue1));
        edtSilageHybridValue2.addTextChangedListener(new MyTextWatcher(edtSilageHybridValue2));
        edtSilageHybridValue3.addTextChangedListener(new MyTextWatcher(edtSilageHybridValue3));
        edtSilageHybridValue4.addTextChangedListener(new MyTextWatcher(edtSilageHybridValue4));
        edtCompetitorGrainPlanValue1.addTextChangedListener(new MyTextWatcher(edtCompetitorGrainPlanValue1));
        edtCompetitorGrainPlanValue2.addTextChangedListener(new MyTextWatcher(edtCompetitorGrainPlanValue2));
        edtCompetitorGrainPlanValue3.addTextChangedListener(new MyTextWatcher(edtCompetitorGrainPlanValue3));
        edtCompetitorGrainPlanValue4.addTextChangedListener(new MyTextWatcher(edtCompetitorGrainPlanValue4));
        edtCompetitorGrainPlanValue5.addTextChangedListener(new MyTextWatcher(edtCompetitorGrainPlanValue5));
        edtCompetitorSilagePlanValue1.addTextChangedListener(new MyTextWatcher(edtCompetitorSilagePlanValue1));
        edtCompetitorSilagePlanValue2.addTextChangedListener(new MyTextWatcher(edtCompetitorSilagePlanValue2));

        edtCompetitorSilagePlanValue3.addTextChangedListener(new MyTextWatcher(edtCompetitorSilagePlanValue3));
        edtCompetitorSilagePlanValue4.addTextChangedListener(new MyTextWatcher(edtCompetitorSilagePlanValue4));
        edtCompetitorSilagePlanValue5.addTextChangedListener(new MyTextWatcher(edtCompetitorSilagePlanValue5));

       /* if (seasonData.getName().equalsIgnoreCase(MyConstants.SPRING) && cropData.getName().equalsIgnoreCase(MyConstants.CORN)){
            edt_competitorSilagevalue3.addTextChangedListener(new MyTextWatcher(edt_competitorSilagevalue3));
            edt_competitorSilagevalue4.addTextChangedListener(new MyTextWatcher(edt_competitorSilagevalue4));
        }*/


        //newly added
        edtMaturity124Acr.addTextChangedListener(new MyTextWatcher(edtMaturity124Acr));
        edtMaturity134Acr.addTextChangedListener(new MyTextWatcher(edtMaturity134Acr));
        edtMaturity135Acr.addTextChangedListener(new MyTextWatcher(edtMaturity135Acr));

        growProduceList.add("Select");
        growProduceList.add("Growing");
        growProduceList.add("Procuring");
        ArrayAdapter<String> nestleHeadGrowProducAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, growProduceList);
        spnGrowing.setAdapter(nestleHeadGrowProducAdapter);
    }

    private void setRatingStarColor(int i, float rating) {

        LayerDrawable layers = (LayerDrawable) fbRatingBar.getProgressDrawable();
        DrawableCompat.setTint(layers.getDrawable(0), 0x33000000); // The background tint
        if (i <= 1) {
            DrawableCompat.setTint(layers.getDrawable(1), getResources().getColor(R.color.red));
            DrawableCompat.setTint(layers.getDrawable(2), getResources().getColor(R.color.red));
        } else if (i == 2) {
            DrawableCompat.setTint(layers.getDrawable(1), getResources().getColor(R.color.dark_green));
            DrawableCompat.setTint(layers.getDrawable(2), getResources().getColor(R.color.orange));
        } else if (i == 3) {
            DrawableCompat.setTint(layers.getDrawable(1), getResources().getColor(R.color.dark_green));
            DrawableCompat.setTint(layers.getDrawable(2), getResources().getColor(R.color.dark_green));
        }

    }

    private void setSpnSchool(String instituteId) {

        if (Utility.isValidStr(instituteId)) {
            List<DTO> instituteByschoolList = SegmentationSchoolDAO.getInstance().getRecordInfoByValue("devCenterId", instituteId, DBHandler.getInstance(mActivity).getReadableDatabase());

            schoolList.clear();
            if (instituteByschoolList != null && instituteByschoolList.size() > 0) {
                for (DTO dto : instituteByschoolList) {
                    if (schoolList.size() == 0) {
                        schoolList.add(new IdNameModel("Select School"));
                    }
                    IdNameModel idDTO = (IdNameModel) dto;
                    schoolList.add(idDTO);
                }
            }
//            schoolAdapter.notifyDataSetChanged();
            spnSchool.setAdapter(schoolAdapter);
        }
    }


    private boolean checkLocPermission() {

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            return ActivityCompat.checkSelfPermission(mActivity, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return true;
        }
    }

    private void getMasterData() {
        IdNameModel nameModel = (IdNameModel) spnCrop.getTag();
        if (!MyConstants.RICE.equalsIgnoreCase(nameModel.getName())) {
            grainHybrid1SpinnerPopulation();
            grainHybrid2SpinnerPopulation();
            grainHybrid3SpinnerPopulation();
            grainHybrid4SpinnerPopulation();

            silageHybrid1SpinnerPopulation();
            silageHybrid2SpinnerPopulation();
            silageHybrid3SpinnerPopulation();
            silageHybrid4SpinnerPopulation();

            List<IdNameModel> grainServicesDTOList = SegmentationGrainServicesDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());
            if (grainServicesDTOList != null && grainServicesDTOList.size() > 0) {
                originalGrainServicesList.clear();
                originalGrainServicesList.addAll(grainServicesDTOList);
            }
            stringGrainServicesList.clear();

            for (IdNameModel dto : originalGrainServicesList) {
                stringGrainServicesList.add(dto.getName());
            }

            grainServicesAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, stringGrainServicesList);
            spnGrainServices1.setAdapter(grainServicesAdapter, false, onSelectedListener);
            selectedItems = new boolean[grainServicesAdapter.getCount()];
            selectedItems[0] = false; // select second item
            spnGrainServices1.setSelected(selectedItems);
            grainServicesAdapter.notifyDataSetChanged();


            List<IdNameModel> silageServicesDTOList = SegmentationSilageServicesDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());
            if (silageServicesDTOList != null && silageServicesDTOList.size() > 0) {
                originalSilageServicesList.clear();
                originalSilageServicesList.addAll(silageServicesDTOList);
            }
            stringSilageServicesList.clear();

            for (IdNameModel dto : originalSilageServicesList) {
                stringSilageServicesList.add(dto.getName());
            }


            silageServicesAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, stringSilageServicesList);
            spnSilageServices1.setAdapter(silageServicesAdapter, false, onSilageSelectedListener);
            silageSelectedItems = new boolean[silageServicesAdapter.getCount()];
            silageSelectedItems[0] = false; // select second item
            spnSilageServices1.setSelected(silageSelectedItems);
            silageServicesAdapter.notifyDataSetChanged();

        } else {
            //NEWLY ADDED FOR RICE
            riceHybrid1SpinnerPopulation();
            riceHybrid2SpinnerPopulation();
            riceHybrid3SpinnerPopulation();
            riceHybrid4SpinnerPopulation();

            //newly added for Rice Hydird List
            List<IdNameModel> riceServicesDTOList = SegmentationRiceServicesDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getReadableDatabase());
            if (riceServicesDTOList != null && riceServicesDTOList.size() > 0) {
                originalRiceServicesList.clear();
                originalRiceServicesList.addAll(riceServicesDTOList);
            }
            stringRicenServicesList.clear();

            for (IdNameModel dto : originalRiceServicesList) {
                stringRicenServicesList.add(dto.getName());
            }
            riceServicesAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, stringRicenServicesList);
            spnGrainServices1.setAdapter(riceServicesAdapter, false, onRiceSelectedListener);
            riceSelectedItems = new boolean[riceServicesAdapter.getCount()];
            if (riceSelectedItems.length > 0)
                riceSelectedItems[0] = false; // select second item
            spnGrainServices1.setSelected(riceSelectedItems);
            riceServicesAdapter.notifyDataSetChanged();
        }
    }


    private void grainHybrid1SpinnerPopulation() {
        segmentationGrainHybridDTOList = SegmentationGrainHybridDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getDBObject(0));

        if (segmentationGrainHybridDTOList != null && segmentationGrainHybridDTOList.size() > 0) {
            originalGrainHybridList.clear();
            originalGrainHybridList.addAll(segmentationGrainHybridDTOList);
        }


        grainHybrid1List.clear();
        if (grainHybrid1List.size() == 0) {
            grainHybrid1List.add(MyConstants.SelectHybrid1);
        }

        grainHybrid1List.addAll(originalGrainHybridList);

        ArrayAdapter<String> grainHybrid1Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, grainHybrid1List);

        spnGrainHybrid1.setAdapter(grainHybrid1Adapter);

        spnGrainHybrid1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0
                        || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");
                    selectedItems[0] = false;
                    spnGrainServices1.setSelected(selectedItems);
                    grainServicesAdapter.notifyDataSetChanged();
                }
                if (position > 0) {

                    spnGrainHybrid2.setEnabled(true);
                    grainHybrid1name = spnGrainHybrid1.getSelectedItem().toString();

                    hybrid2List(grainHybrid1name);

                    if (spnGrainHybrid1.getSelectedItem().toString().equalsIgnoreCase(grainHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid1 and Grain hybrid2 should not be same");
                        spnGrainHybrid1.setSelection(0);
                    }
                    if (spnGrainHybrid1.getSelectedItem().toString().equalsIgnoreCase(grainHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid1 and Grain hybrid3 should not be same");
                        spnGrainHybrid1.setSelection(0);
                    }
                    if (spnGrainHybrid1.getSelectedItem().toString().equalsIgnoreCase(grainHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid1 and Grain hybrid4 should not be same");
                        spnGrainHybrid1.setSelection(0);
                    }
                    if (dto != null && Utility.isValidStr(dto.getGrainHybrid2Name())) {
                        for (int i = 0; i < grainHybrid2List.size(); i++) {
                            if (grainHybrid2List.get(i).equalsIgnoreCase(dto.getGrainHybrid2Name())) {
                                spnGrainHybrid2.setSelection(i);
                                break;
                            }
                        }
                    }

                } else {
                    spnGrainHybrid2.setEnabled(false);
                    spnGrainHybrid3.setEnabled(false);
                    spnGrainHybrid4.setEnabled(false);
                    hybrid1List();
                    spnGrainHybrid2.setSelection(0);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void grainHybrid2SpinnerPopulation() {

        if (segmentationGrainHybridDTOList != null && segmentationGrainHybridDTOList.size() > 0) {
            grainHybrid2List.clear();
            for (String dto : segmentationGrainHybridDTOList) {
                if (grainHybrid2List.size() == 0) {
                    grainHybrid2List.add(MyConstants.SelectHybrid2);
                }
                grainHybrid2List.add(dto);
            }
        }
        ArrayAdapter<String> grainHybrid2Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, grainHybrid2List);
        spnGrainHybrid2.setAdapter(grainHybrid2Adapter);

        spnGrainHybrid2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0 || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");
                    selectedItems[0] = false;
                    spnGrainServices1.setSelected(selectedItems);
                    grainServicesAdapter.notifyDataSetChanged();
                }

                if (position > 0) {
                    grainHybrid2name = spnGrainHybrid2.getSelectedItem().toString();

                    spnGrainHybrid1.setEnabled(false);
                    spnGrainHybrid3.setEnabled(true);
                    hybrid3List(grainHybrid1name, grainHybrid2name);

                    if (spnGrainHybrid2.getSelectedItem().toString().equalsIgnoreCase(grainHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid2 and Grain hybrid1 should not be same");
                        spnGrainHybrid2.setSelection(0);
                    }
                    if (spnGrainHybrid2.getSelectedItem().toString().equalsIgnoreCase(grainHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid2 and Grain hybrid3 should not be same");
                        spnGrainHybrid2.setSelection(0);
                    }
                    if (spnGrainHybrid2.getSelectedItem().toString().equalsIgnoreCase(grainHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid2 and Grain hybrid4 should not be same");
                        spnGrainHybrid2.setSelection(0);
                    }

                    if (dto != null && Utility.isValidStr(dto.getGrainHybrid3Name())) {
                        for (int i = 0; i < grainHybrid3List.size(); i++) {
                            if (grainHybrid3List.get(i).equalsIgnoreCase(dto.getGrainHybrid3Name())) {
                                spnGrainHybrid3.setSelection(i);
                                break;
                            }
                        }
                    }

                } else {
                    if (spnGrainHybrid1.getSelectedItemPosition() > 0) {
                        spnGrainHybrid1.setEnabled(true);
                    }
                    spnGrainHybrid3.setEnabled(false);
                    spnGrainHybrid4.setEnabled(false);
                    hybrid1List();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void grainHybrid3SpinnerPopulation() {
        if (segmentationGrainHybridDTOList != null && segmentationGrainHybridDTOList.size() > 0) {
            grainHybrid3List.clear();
            for (String dto : segmentationGrainHybridDTOList) {
                if (grainHybrid3List.size() == 0) {
                    grainHybrid3List.add(MyConstants.SelectHybrid3);
                }
                grainHybrid3List.add(dto);
            }
        }

        ArrayAdapter<String> grainHybrid3Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, grainHybrid3List);
        spnGrainHybrid3.setAdapter(grainHybrid3Adapter);

        spnGrainHybrid3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0 || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");
                    selectedItems[0] = false;
                    spnGrainServices1.setSelected(selectedItems);
                    grainServicesAdapter.notifyDataSetChanged();
                }
                if (position > 0) {
                    grainHybrid3name = spnGrainHybrid3.getSelectedItem().toString();

                    spnGrainHybrid2.setEnabled(false);
                    spnGrainHybrid4.setEnabled(true);
                    hybrid4List(grainHybrid1name, grainHybrid2name, grainHybrid3name);

                    if (spnGrainHybrid3.getSelectedItem().toString().equalsIgnoreCase(grainHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid3 and Grain hybrid1 should not be same");
                        spnGrainHybrid3.setSelection(0);
                    }
                    if (spnGrainHybrid3.getSelectedItem().toString().equalsIgnoreCase(grainHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid3 and Grain hybrid2 should not be same");
                        spnGrainHybrid3.setSelection(0);
                    }
                    if (spnGrainHybrid3.getSelectedItem().toString().equalsIgnoreCase(grainHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid3 and Grain hybrid4 should not be same");
                        spnGrainHybrid3.setSelection(0);
                    }
                    if (dto != null && Utility.isValidStr(dto.getGrainHybrid4Name())) {
                        for (int i = 0; i < grainHybrid4List.size(); i++) {
                            if (grainHybrid4List.get(i).equalsIgnoreCase(dto.getGrainHybrid4Name())) {
                                spnGrainHybrid4.setSelection(i);
                                break;
                            }
                        }
                    }

                } else {
                    if (spnGrainHybrid2.getSelectedItemPosition() > 0) {
                        spnGrainHybrid2.setEnabled(true);
                    } /*else {
                        spnGrainHybrid2.setEnabled(false);
                    }*/
                    spnGrainHybrid4.setEnabled(false);
                    hybrid2List(grainHybrid1name);
                    spnGrainHybrid4.setSelection(0);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void grainHybrid4SpinnerPopulation() {

        if (segmentationGrainHybridDTOList != null && segmentationGrainHybridDTOList.size() > 0) {
            grainHybrid4List.clear();
            for (String dto : segmentationGrainHybridDTOList) {
                if (grainHybrid4List.size() == 0) {
                    grainHybrid4List.add(MyConstants.SelectHybrid4);
                }
                grainHybrid4List.add(dto);
            }
        }

        ArrayAdapter<String> grainHybrid4Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, grainHybrid4List);
        spnGrainHybrid4.setAdapter(grainHybrid4Adapter);

        spnGrainHybrid4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0 || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");
                    selectedItems[0] = false;
                    spnGrainServices1.setSelected(selectedItems);
                    grainServicesAdapter.notifyDataSetChanged();
                }

                if (position > 0) {
                    grainHybrid4name = spnGrainHybrid4.getSelectedItem().toString();

                    spnGrainHybrid3.setEnabled(false);

                    if (spnGrainHybrid4.getSelectedItem().toString().equalsIgnoreCase(grainHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid3 and Grain hybrid1 should not be same");
                        spnGrainHybrid4.setSelection(0);
                    }
                    if (spnGrainHybrid4.getSelectedItem().toString().equalsIgnoreCase(grainHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid3 and Grain hybrid2 should not be same");
                        spnGrainHybrid4.setSelection(0);
                    }
                    if (spnGrainHybrid4.getSelectedItem().toString().equalsIgnoreCase(grainHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Grain hybrid3 and Grain hybrid3 should not be same");
                        spnGrainHybrid4.setSelection(0);
                    }
                } else {
                    if (spnGrainHybrid3.getSelectedItemPosition() > 0) {
                        spnGrainHybrid3.setEnabled(true);
                    } else {
                        spnGrainHybrid3.setEnabled(false);
                    }
                    hybrid3List(grainHybrid1name, grainHybrid2name);
                    if (grainHybrid4List.size() >= 0) {
                        spnGrainHybrid4.setSelection(0);
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void silageHybrid1SpinnerPopulation() {
        segmentationSilageHybridDTOList = SegmentationSilageHybridDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getDBObject(0));

        if (segmentationSilageHybridDTOList != null && segmentationSilageHybridDTOList.size() > 0) {
            originalSilageHybridList.clear();
            originalSilageHybridList.addAll(segmentationSilageHybridDTOList);
        }

        silageHybrid1List.clear();
        if (silageHybrid1List.size() == 0) {
            silageHybrid1List.add(MyConstants.SelectSilageHybrid1);
        }
        silageHybrid1List.addAll(originalSilageHybridList);

        ArrayAdapter<String> silageHybrid1Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, silageHybrid1List);
        spnSilageHybrid1.setAdapter(silageHybrid1Adapter);

        spnSilageHybrid1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (spnSilageHybrid1.getSelectedItemPosition() > 0 || spnSilageHybrid2.getSelectedItemPosition() > 0) {
                    lnrSilageServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrSilageServices1.setVisibility(View.GONE);
                    spnSilageServices1.setText("");
                    silageSelectedItems[0] = false;
                    spnSilageServices1.setSelected(silageSelectedItems);
                    silageServicesAdapter.notifyDataSetChanged();
                }
                if (position > 0) {
                    silageHybrid1name = spnSilageHybrid1.getSelectedItem().toString();

                    spnSilageHybrid2.setEnabled(true);
                    silageHybrid2List(silageHybrid1name);

                    if (spnSilageHybrid1.getSelectedItem().toString().equalsIgnoreCase(silageHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid1 and Silage hybrid2 should not be same");
                        spnSilageHybrid1.setSelection(0);
                    }

                    if (dto != null && Utility.isValidStr(dto.getSilageHybrid2Name())) {
                        for (int i = 0; i < silageHybrid2List.size(); i++) {
                            if (silageHybrid2List.get(i).equalsIgnoreCase(dto.getSilageHybrid2Name())) {
                                spnSilageHybrid2.setSelection(i);
                                break;
                            }
                        }
                    }
                } else {
                    spnSilageHybrid2.setEnabled(false);
                    silageHybrid1List();
                    spnSilageHybrid2.setSelection(0);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void silageHybrid2SpinnerPopulation() {
        if (segmentationSilageHybridDTOList != null && segmentationSilageHybridDTOList.size() > 0) {
            silageHybrid2List.clear();
            for (String dto : segmentationSilageHybridDTOList) {
                if (silageHybrid2List.size() == 0) {
                    silageHybrid2List.add(MyConstants.SelectSilageHybrid2);
                }
                silageHybrid2List.add(dto);
            }
        }
        ArrayAdapter<String> silageHybrid2Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, silageHybrid2List);
        spnSilageHybrid2.setAdapter(silageHybrid2Adapter);

        spnSilageHybrid2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (spnSilageHybrid1.getSelectedItemPosition() > 0 || spnSilageHybrid2.getSelectedItemPosition() > 0 || spnSilageHybrid3.getSelectedItemPosition() > 0 || spnSilageHybrid4.getSelectedItemPosition() > 0) {
                    lnrSilageServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrSilageServices1.setVisibility(View.GONE);
                    spnSilageServices1.setText("");
                    silageSelectedItems[0] = false;
                    spnSilageServices1.setSelected(silageSelectedItems);
                    silageServicesAdapter.notifyDataSetChanged();
                }

                if (position > 0) {
                    silageHybrid2name = spnSilageHybrid2.getSelectedItem().toString();

                    spnSilageHybrid1.setEnabled(false);
                    spnSilageHybrid3.setEnabled(true);
                    silageHybrid3List(silageHybrid1name, silageHybrid2name);

                    if (spnSilageHybrid2.getSelectedItem().toString().equalsIgnoreCase(silageHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid2 and Silage hybrid1 should not be same");
                        spnSilageHybrid2.setSelection(0);
                    }
                    if (spnSilageHybrid2.getSelectedItem().toString().equalsIgnoreCase(silageHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid2 and Silage hybrid3 should not be same");
                        spnSilageHybrid2.setSelection(0);
                    }
                    if (spnSilageHybrid2.getSelectedItem().toString().equalsIgnoreCase(silageHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid2 and Silage hybrid4 should not be same");
                        spnSilageHybrid2.setSelection(0);
                    }

                    if (dto != null && Utility.isValidStr(dto.getSilageHybrid2Name())) {
                        for (int i = 0; i < silageHybrid2List.size(); i++) {
                            if (silageHybrid2List.get(i).equalsIgnoreCase(dto.getSilageHybrid2Name())) {
                                spnSilageHybrid3.setSelection(i);
                                break;
                            }
                        }
                    }

                } else {
                    if (spnSilageHybrid1.getSelectedItemPosition() > 0) {
                        spnSilageHybrid1.setEnabled(true);
                    }
                    spnSilageHybrid3.setEnabled(false);
                    spnSilageHybrid4.setEnabled(false);
                    silageHybrid1List();
                    spnSilageHybrid3.setSelection(0);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    private void silageHybrid3SpinnerPopulation() {
        if (segmentationSilageHybridDTOList != null && segmentationSilageHybridDTOList.size() > 0) {
            silageHybrid3List.clear();
            for (String dto : segmentationSilageHybridDTOList) {
                if (silageHybrid3List.size() == 0) {
                    silageHybrid3List.add(MyConstants.SelectSilageHybrid3);
                }
                silageHybrid3List.add(dto);
            }
        }

        ArrayAdapter<String> silageHybrid3Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, silageHybrid3List);
        spnSilageHybrid3.setAdapter(silageHybrid3Adapter);

        spnSilageHybrid3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnSilageHybrid1.getSelectedItemPosition() > 0 || spnSilageHybrid2.getSelectedItemPosition() > 0 || spnSilageHybrid3.getSelectedItemPosition() > 0 || spnSilageHybrid4.getSelectedItemPosition() > 0) {
                    lnrSilageServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrSilageServices1.setVisibility(View.GONE);
                    spnSilageServices1.setText("");
                    silageSelectedItems[0] = false;
                    spnSilageServices1.setSelected(silageSelectedItems);
                    silageServicesAdapter.notifyDataSetChanged();
                }
                if (position > 0) {
                    silageHybrid3name = Utility.isValidStr(spnSilageHybrid3.getSelectedItem().toString()) ? spnSilageHybrid3.getSelectedItem().toString() : "";

                    spnSilageHybrid2.setEnabled(false);
                    spnSilageHybrid4.setEnabled(true);
                    silageHybrid4List(silageHybrid1name, silageHybrid2name, silageHybrid3name);

                    if (spnSilageHybrid3.getSelectedItem().toString().equalsIgnoreCase(silageHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid3 and Silage hybrid1 should not be same");
                        spnSilageHybrid3.setSelection(0);
                    }
                    if (spnSilageHybrid3.getSelectedItem().toString().equalsIgnoreCase(silageHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid3 and Silage hybrid2 should not be same");
                        spnSilageHybrid3.setSelection(0);
                    }
                    if (spnSilageHybrid3.getSelectedItem().toString().equalsIgnoreCase(silageHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid3 and Silage hybrid4 should not be same");
                        spnSilageHybrid3.setSelection(0);
                    }
                    if (dto != null && Utility.isValidStr(dto.getSilageHybrid4Name())) {
                        for (int i = 0; i < silageHybrid4List.size(); i++) {
                            if (silageHybrid4List.get(i).equalsIgnoreCase(dto.getSilageHybrid4Name())) {
                                spnSilageHybrid4.setSelection(i);
                                break;
                            }
                        }
                    }

                } else {
                    if (spnSilageHybrid2.getSelectedItemPosition() > 0) {
                        spnSilageHybrid2.setEnabled(true);
                    } /*else {
                        spnSilageHybrid2.setEnabled(false);
                    }*/
                    spnSilageHybrid4.setEnabled(false);
                    silageHybrid2List(silageHybrid1name);
                    spnSilageHybrid4.setSelection(0);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void silageHybrid4SpinnerPopulation() {

        if (segmentationSilageHybridDTOList != null && segmentationSilageHybridDTOList.size() > 0) {
            silageHybrid4List.clear();
            for (String dto : segmentationSilageHybridDTOList) {
                if (silageHybrid4List.size() == 0) {
                    silageHybrid4List.add(MyConstants.SelectSilageHybrid2);
                }
                silageHybrid4List.add(dto);
            }
        }

        ArrayAdapter<String> silageHybrid4Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, silageHybrid4List);
        spnSilageHybrid4.setAdapter(silageHybrid4Adapter);

        spnSilageHybrid4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnSilageHybrid1.getSelectedItemPosition() > 0 || spnSilageHybrid2.getSelectedItemPosition() > 0 || spnSilageHybrid3.getSelectedItemPosition() > 0 || spnSilageHybrid4.getSelectedItemPosition() > 0) {
                    lnrSilageServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrSilageServices1.setVisibility(View.GONE);
                    spnSilageServices1.setText("");
                    silageSelectedItems[0] = false;
                    spnSilageServices1.setSelected(silageSelectedItems);
                    silageServicesAdapter.notifyDataSetChanged();
                }

                if (position > 0) {
                    silageHybrid3name = spnGrainHybrid4.getSelectedItem().toString();

                    spnSilageHybrid3.setEnabled(false);

                    if (spnSilageHybrid4.getSelectedItem().toString().equalsIgnoreCase(silageHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid3 and Silage hybrid1 should not be same");
                        spnSilageHybrid4.setSelection(0);
                    }
                    if (spnSilageHybrid4.getSelectedItem().toString().equalsIgnoreCase(silageHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid3 and Silage hybrid2 should not be same");
                        spnSilageHybrid4.setSelection(0);
                    }
                    if (spnSilageHybrid4.getSelectedItem().toString().equalsIgnoreCase(silageHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Silage hybrid3 and Silage hybrid3 should not be same");
                        spnSilageHybrid4.setSelection(0);
                    }
                } else {
                    if (spnSilageHybrid3.getSelectedItemPosition() > 0) {
                        spnSilageHybrid3.setEnabled(true);
                    } else {
                        spnSilageHybrid3.setEnabled(false);
                    }
                    silageHybrid3List(silageHybrid1name, silageHybrid2name);
                    if (silageHybrid4List.size() >= 0) {
                        spnSilageHybrid4.setSelection(0);
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void riceHybrid1SpinnerPopulation() {
        segmentationRiceHybridDTOList = SegmentationRiceHybridDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getDBObject(0));

        if (segmentationRiceHybridDTOList != null && segmentationRiceHybridDTOList.size() > 0) {
            originalRiceHybridList.clear();
            originalRiceHybridList.addAll(segmentationRiceHybridDTOList);
        }


        riceHybrid1List.clear();
        if (riceHybrid1List.size() == 0) {
            riceHybrid1List.add(MyConstants.SelectHybrid1);
        }
        riceHybrid1List.addAll(originalRiceHybridList);

        ArrayAdapter<String> riceHybrid1Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, riceHybrid1List);

        spnGrainHybrid1.setAdapter(riceHybrid1Adapter);
        riceHybrid1Adapter.notifyDataSetChanged();

        spnGrainHybrid1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0 || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");
                    riceSelectedItems[0] = false;
                    spnGrainServices1.setSelected(riceSelectedItems);
                    riceServicesAdapter.notifyDataSetChanged();
                }
                if (position > 0) {
                    spnGrainHybrid1.setEnabled(false);
                    spnGrainHybrid2.setEnabled(true);
                    riceHybrid1name = spnGrainHybrid1.getSelectedItem().toString();

                    hybrid2ListForRice(riceHybrid1name);

                    if (spnGrainHybrid1.getSelectedItem().toString().equalsIgnoreCase(riceHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid1 and Rice hybrid2 should not be same");
                        spnGrainHybrid1.setSelection(0);
                    }
                    if (spnGrainHybrid1.getSelectedItem().toString().equalsIgnoreCase(riceHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid1 and Rice hybrid3 should not be same");
                        spnGrainHybrid1.setSelection(0);
                    }
                    if (spnGrainHybrid1.getSelectedItem().toString().equalsIgnoreCase(riceHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid1 and Rice hybrid4 should not be same");
                        spnGrainHybrid1.setSelection(0);
                    }
                    if (dto != null && Utility.isValidStr(dto.getRiceHybrid2Name())) {
                        for (int i = 0; i < riceHybrid2List.size(); i++) {
                            if (riceHybrid2List.get(i).equalsIgnoreCase(dto.getRiceHybrid2Name())) {
                                spnGrainHybrid2.setSelection(i);
                                break;
                            }
                        }
                    }
                } else {

                    spnGrainHybrid2.setEnabled(false);
                    spnGrainHybrid3.setEnabled(false);
                    spnGrainHybrid4.setEnabled(false);
                    hybrid1ListForRice();
                    spnGrainHybrid2.setSelection(0);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    private void riceHybrid2SpinnerPopulation() {
        if (segmentationRiceHybridDTOList != null && segmentationGrainHybridDTOList.size() > 0) {
            riceHybrid2List.clear();
            for (String dto : segmentationRiceHybridDTOList) {
                if (riceHybrid2List.size() == 0) {
                    riceHybrid2List.add(MyConstants.SelectHybrid2);
                }
                riceHybrid2List.add(dto);
            }
        }
        ArrayAdapter<String> riceHybrid2Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, riceHybrid2List);
        spnGrainHybrid2.setAdapter(riceHybrid2Adapter);
        riceHybrid2Adapter.notifyDataSetChanged();

        spnGrainHybrid2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0 || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");
                    riceSelectedItems[0] = false;
                    spnGrainServices1.setSelected(riceSelectedItems);
                    riceServicesAdapter.notifyDataSetChanged();
                }

                if (position > 0) {
                    riceHybrid2name = spnGrainHybrid2.getSelectedItem().toString();

                    spnGrainHybrid1.setEnabled(false);
                    spnGrainHybrid3.setEnabled(true);
                    hybrid3ListForRice(riceHybrid1name, riceHybrid2name);

                    if (spnGrainHybrid2.getSelectedItem().toString().equalsIgnoreCase(riceHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid2 and Rice hybrid1 should not be same");
                        spnGrainHybrid2.setSelection(0);
                    }
                    if (spnGrainHybrid2.getSelectedItem().toString().equalsIgnoreCase(riceHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid2 and Rice hybrid3 should not be same");
                        spnGrainHybrid2.setSelection(0);
                    }
                    if (spnGrainHybrid2.getSelectedItem().toString().equalsIgnoreCase(riceHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid2 and Rice hybrid4 should not be same");
                        spnGrainHybrid2.setSelection(0);
                    }
                    if (dto != null && Utility.isValidStr(dto.getRiceHybrid3Name())) {
                        for (int i = 0; i < riceHybrid3List.size(); i++) {
                            if (riceHybrid3List.get(i).equalsIgnoreCase(dto.getRiceHybrid3Name())) {
                                spnGrainHybrid3.setSelection(i);
                                break;
                            }
                        }
                    }
                } else {
                    if (spnGrainHybrid1.getSelectedItemPosition() > 0) {
                        spnGrainHybrid1.setEnabled(true);
                    }
                    spnGrainHybrid3.setEnabled(false);
                    spnGrainHybrid4.setEnabled(false);
                    hybrid1ListForRice();
                    spnGrainHybrid3.setSelection(0);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void riceHybrid3SpinnerPopulation() {
        if (segmentationRiceHybridDTOList != null && segmentationRiceHybridDTOList.size() > 0) {

            riceHybrid3List.clear();
            for (String dto : segmentationRiceHybridDTOList) {
                if (riceHybrid3List.size() == 0) {
                    riceHybrid3List.add(MyConstants.SelectHybrid3);
                }
                riceHybrid3List.add(dto);
            }
        }

        ArrayAdapter<String> riceHybrid3Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, riceHybrid3List);
        spnGrainHybrid3.setAdapter(riceHybrid3Adapter);
        riceHybrid3Adapter.notifyDataSetChanged();
        spnGrainHybrid3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0 || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");

                    riceSelectedItems[0] = false;
                    spnGrainServices1.setSelected(riceSelectedItems);
                    riceServicesAdapter.notifyDataSetChanged();
                }
                if (position > 0) {
                    riceHybrid3name = spnGrainHybrid3.getSelectedItem().toString();

                    spnGrainHybrid2.setEnabled(false);
                    spnGrainHybrid4.setEnabled(true);
                    hybrid4ListForRice(riceHybrid1name, riceHybrid2name, riceHybrid3name);

                    if (spnGrainHybrid3.getSelectedItem().toString().equalsIgnoreCase(riceHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid3 and Rice hybrid1 should not be same");
                        spnGrainHybrid3.setSelection(0);
                    }
                    if (spnGrainHybrid3.getSelectedItem().toString().equalsIgnoreCase(riceHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid3 and Rice hybrid2 should not be same");
                        spnGrainHybrid3.setSelection(0);
                    }
                    if (spnGrainHybrid3.getSelectedItem().toString().equalsIgnoreCase(riceHybrid4name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid3 and Rice hybrid4 should not be same");
                        spnGrainHybrid3.setSelection(0);
                    }

                    if (dto != null && Utility.isValidStr(dto.getRiceHybrid4Name())) {
                        for (int i = 0; i < riceHybrid4List.size(); i++) {
                            if (riceHybrid4List.get(i).equalsIgnoreCase(dto.getRiceHybrid4Name())) {
                                spnGrainHybrid4.setSelection(i);
                                break;
                            }
                        }
                    }

                } else {
                    if (spnGrainHybrid2.getSelectedItemPosition() > 0) {
                        spnGrainHybrid2.setEnabled(true);
                    } /*else {
                        spnGrainHybrid2.setEnabled(false);
                    }*/
                    spnGrainHybrid4.setEnabled(false);
                    //hybrid2List(grainHybrid1name);
                    hybrid2List(riceHybrid1name);
                    spnGrainHybrid4.setSelection(0);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void riceHybrid4SpinnerPopulation() {

        if (segmentationRiceHybridDTOList != null && segmentationRiceHybridDTOList.size() > 0) {
            // grainHybrid4List.clear();
            riceHybrid4List.clear();
            for (String dto : segmentationGrainHybridDTOList) {
                if (riceHybrid4List.size() == 0) {
                    riceHybrid4List.add(MyConstants.SelectHybrid4);
                }
                riceHybrid4List.add(dto);
            }
        }

        ArrayAdapter<String> riceHybrid4Adapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_item, riceHybrid4List);
        spnGrainHybrid4.setAdapter(riceHybrid4Adapter);
        riceHybrid4Adapter.notifyDataSetChanged();

        spnGrainHybrid4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spnGrainHybrid1.getSelectedItemPosition() > 0 || spnGrainHybrid2.getSelectedItemPosition() > 0 || spnGrainHybrid3.getSelectedItemPosition() > 0 || spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    lnrGrainServices1.setVisibility(View.VISIBLE);
                } else {
                    lnrGrainServices1.setVisibility(View.GONE);
                    spnGrainServices1.setText("");
                    //selectedItems[0] = false;
                    riceSelectedItems[0] = false;
                    spnGrainServices1.setSelected(riceSelectedItems);
                    riceServicesAdapter.notifyDataSetChanged();
                }

                if (position > 0) {
                    riceHybrid4name = spnGrainHybrid4.getSelectedItem().toString();

                    spnGrainHybrid3.setEnabled(false);

                    if (spnGrainHybrid4.getSelectedItem().toString().equalsIgnoreCase(riceHybrid1name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid3 and Rice hybrid1 should not be same");
                        spnGrainHybrid4.setSelection(0);
                    }
                    if (spnGrainHybrid4.getSelectedItem().toString().equalsIgnoreCase(riceHybrid2name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid3 and Rice hybrid2 should not be same");
                        spnGrainHybrid4.setSelection(0);
                    }
                    if (spnGrainHybrid4.getSelectedItem().toString().equalsIgnoreCase(riceHybrid3name)) {
                        Utility.showAlert(mActivity, "", "Rice hybrid3 and Rice hybrid3 should not be same");
                        spnGrainHybrid4.setSelection(0);
                    }
                } else {
                    if (spnGrainHybrid3.getSelectedItemPosition() > 0) {
                        spnGrainHybrid3.setEnabled(true);
                    } else {
                        spnGrainHybrid3.setEnabled(false);
                    }
                    hybrid3ListForRice(riceHybrid1name, riceHybrid2name);
                    if (riceHybrid4List.size() >= 0) {
                        spnGrainHybrid4.setSelection(0);
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    private void hybrid1List() {
        grainHybrid1List.clear();
        grainHybrid1List.add(MyConstants.SelectHybrid1);
        grainHybrid1List.addAll(originalGrainHybridList);

        if (Utility.isValidStr("") && grainHybrid1List.size() > 0) {
            for (String dto : originalGrainHybridList) {
                if (dto.equalsIgnoreCase("")) {
                    grainHybrid1List.remove(dto);
                }
            }
        }
    }

    private void hybrid2List(String hybrid1) {
        grainHybrid2List.clear();
        if (grainHybrid2List.size() == 0) {
            grainHybrid2List.add(MyConstants.SelectHybrid2);
        }
        grainHybrid2List.addAll(originalGrainHybridList);
        for (String dto : originalGrainHybridList) {
            if (dto.equalsIgnoreCase(hybrid1)) {
                grainHybrid2List.remove(dto);
            }
        }
    }

    private void hybrid3List(String grainHybrid1name, String grainHybrid2name) {
        grainHybrid3List.clear();
        if (grainHybrid3List.size() == 0) {
            grainHybrid3List.add(MyConstants.SelectHybrid3);
        }
        grainHybrid3List.addAll(originalGrainHybridList);
        for (String dto : originalGrainHybridList) {
            if (dto.equalsIgnoreCase(grainHybrid1name)) {
                grainHybrid3List.remove(dto);
            }
            if (dto.equalsIgnoreCase(grainHybrid2name)) {
                grainHybrid3List.remove(dto);
            }
        }
    }

    private void hybrid4List(String grainHybrid1name, String grainHybrid2name, String
            grainHybrid3name) {
        grainHybrid4List.clear();
        if (grainHybrid4List.size() == 0) {
            grainHybrid4List.add(MyConstants.SelectHybrid4);
        }
        grainHybrid4List.addAll(originalGrainHybridList);
        for (String dto : originalGrainHybridList) {
            if (dto.equalsIgnoreCase(grainHybrid1name)) {
                grainHybrid4List.remove(dto);
            }
            if (dto.equalsIgnoreCase(grainHybrid2name)) {
                grainHybrid4List.remove(dto);
            }
            if (dto.equalsIgnoreCase(grainHybrid3name)) {
                grainHybrid4List.remove(dto);
            }

        }
    }

    private void silageHybrid1List() {
        silageHybrid1List.clear();
        silageHybrid1List.add(MyConstants.SelectSilageHybrid1);
        silageHybrid1List.addAll(originalSilageHybridList);

        if (Utility.isValidStr("") && silageHybrid1List.size() > 0) {
            for (String dto : originalSilageHybridList) {
                if (dto.equalsIgnoreCase("")) {
                    silageHybrid1List.remove(dto);
                }
            }
        }
    }


    private void silageHybrid2List(String hybrid1) {
        silageHybrid2List.clear();
        if (silageHybrid2List.size() == 0) {
            silageHybrid2List.add(MyConstants.SelectSilageHybrid2);
        }
        silageHybrid2List.addAll(originalSilageHybridList);
        for (String dto : originalSilageHybridList) {
            if (dto.equalsIgnoreCase(hybrid1)) {
                silageHybrid2List.remove(dto);
            }
        }
    }

    private void silageHybrid3List(String grainHybrid1name, String grainHybrid2name) {
        silageHybrid3List.clear();
        if (silageHybrid3List.size() == 0) {
            silageHybrid3List.add(MyConstants.SelectSilageHybrid3);
        }
        silageHybrid3List.addAll(originalSilageHybridList);
        for (String dto : originalSilageHybridList) {
            if (dto.equalsIgnoreCase(grainHybrid1name)) {
                silageHybrid3List.remove(dto);
            }
            if (dto.equalsIgnoreCase(grainHybrid2name)) {
                silageHybrid3List.remove(dto);
            }
        }
    }

    private void silageHybrid4List(String grainHybrid1name, String grainHybrid2name, String
            grainHybrid3name) {
        silageHybrid4List.clear();
        if (silageHybrid4List.size() == 0) {
            silageHybrid4List.add(MyConstants.SelectSilageHybrid4);
        }
        silageHybrid4List.addAll(originalSilageHybridList);
        for (String dto : originalSilageHybridList) {
            if (dto.equalsIgnoreCase(grainHybrid1name)) {
                silageHybrid4List.remove(dto);
            }
            if (dto.equalsIgnoreCase(grainHybrid2name)) {
                silageHybrid4List.remove(dto);
            }
            if (dto.equalsIgnoreCase(grainHybrid3name)) {
                silageHybrid4List.remove(dto);
            }

        }
    }


    //newly added for Rice
    private void hybrid1ListForRice() {

        riceHybrid1List.clear();
        riceHybrid1List.add(MyConstants.SelectHybrid1);
        riceHybrid1List.addAll(originalRiceHybridList);

        if (Utility.isValidStr("") && riceHybrid1List.size() > 0) {
            for (String dto : originalRiceHybridList) {
                if (dto.equalsIgnoreCase("")) {
                    riceHybrid1List.remove(dto);
                }
            }
        }
    }

    private void hybrid2ListForRice(String hybrid1) {

        riceHybrid2List.clear();
        if (riceHybrid2List.size() == 0) {
            riceHybrid2List.add(MyConstants.SelectHybrid2);
        }
        riceHybrid2List.addAll(originalRiceHybridList);
        for (String dto : originalRiceHybridList) {
            if (dto.equalsIgnoreCase(hybrid1)) {
                riceHybrid2List.remove(dto);
            }
        }
    }


    private void hybrid3ListForRice(String riceHybrid1name, String riceHybrid2name) {

        riceHybrid3List.clear();
        if (riceHybrid3List.size() == 0) {
            riceHybrid3List.add(MyConstants.SelectHybrid3);
        }
        riceHybrid3List.addAll(originalRiceHybridList);
        for (String dto : originalRiceHybridList) {
            if (dto.equalsIgnoreCase(riceHybrid1name)) {
                riceHybrid3List.remove(dto);
            }
            if (dto.equalsIgnoreCase(riceHybrid2name)) {
                riceHybrid3List.remove(dto);
            }
        }
    }

    private void hybrid4ListForRice(String riceHybrid1name, String riceHybrid2name, String
            riceHybrid3name) {

        riceHybrid4List.clear();
        if (riceHybrid4List.size() == 0) {
            riceHybrid4List.add(MyConstants.SelectHybrid4);
        }
        riceHybrid4List.addAll(originalRiceHybridList);
        for (String dto : originalRiceHybridList) {
            if (dto.equalsIgnoreCase(riceHybrid1name)) {
                riceHybrid4List.remove(dto);
            }
            if (dto.equalsIgnoreCase(riceHybrid2name)) {
                riceHybrid4List.remove(dto);
            }
            if (dto.equalsIgnoreCase(riceHybrid3name)) {
                riceHybrid4List.remove(dto);
            }

        }
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.btn_mobile_submit) {
            String mobileValidation = checkValidation();
            if (mobileValidation == null) {
                if (Utility.networkAvailability(mActivity)) {
                    IdNameModel seasonData, cropData, divisionData, schoolData;
                    FarmerSegmentationRequestDTO dto = new FarmerSegmentationRequestDTO();
                    IdNameModel yearData = (IdNameModel) spnYear.getTag();
                    seasonData = (IdNameModel) spnSeason.getTag();
                    cropData = (IdNameModel) spnCrop.getTag();
                    divisionData = (IdNameModel) spnDivision.getTag();
                    schoolData = (IdNameModel) spnSchool.getTag();
                    FarmerSegmentationRequest farmerSegmentationRequest = new FarmerSegmentationRequest();
                    farmerSegmentationRequest.setYear(yearData.getName());
                    if (seasonData != null)
                        farmerSegmentationRequest.setSeasonId(seasonData.getId());
                    else
                        farmerSegmentationRequest.setSeasonId(0);
                    if (cropData != null)
                        farmerSegmentationRequest.setCropId(cropData.getId());
                    else
                        farmerSegmentationRequest.setCropId(0);
                    if (divisionData != null)
                        farmerSegmentationRequest.setDevCenterId(divisionData.getId());
                    else
                        farmerSegmentationRequest.setDevCenterId(0);

                    if (schoolData != null)
                        farmerSegmentationRequest.setSchoolId(schoolData.getId());
                    else
                        farmerSegmentationRequest.setSchoolId(0);


                    farmerSegmentationRequest.setFarmerMobileNumber(edtMobileNo.getText().toString());
                    farmerSegmentationRequest.setPinCode(edtPincode.getText().toString());
                    dto.setLoginId(loginId);
                    dto.setMobileNumber(mobileNo);
                    dto.setVersionNo(appVersion);
                    dto.setDeviceType(deviceType);
                    dto.setFarmerSegmentationRequest(farmerSegmentationRequest);

                    assert divisionData != null;
                    if ("Farmer Segmentation".equalsIgnoreCase(divisionData.getName()))
                        APIRequestHandler.getInstance().getFarmerSegmentation(dto, mActivity, this, true);
                    else
                        APIRequestHandler.getInstance().getFarmerSegmentationNestle(dto, mActivity, this, true);

                } else {
                    Utility.showAlert(mActivity, "", getResources().getString(R.string.checkNetwork));
                }

            } else {
                DialogManager.showSingleBtnPopup(mActivity, null, getString(R.string.alert), mobileValidation, getString(R.string.ok));
            }
        } else if (i == R.id.btn_edit) {
            showAlertToEditScreen();
        } else if (i == R.id.btn_proceed_next) {
            String validation = checkFarmerDetailsValidation();
            if (validation == null) {
                setProceedFocus();
                if (dto != null) {
                    populateServiceData(dto);
                } else if (dtoNestle != null) {
                    pupolateNestleServiceData(dtoNestle);
                }
                //callOTPTimer();
            } else {
                DialogManager.showSingleBtnPopup(mActivity, null, getString(R.string.alert), validation, getString(R.string.ok));
            }
        } else if (i == R.id.ns_img_farmerDetails) {
            if (lnrExpandFarmerDetails.getVisibility() == View.VISIBLE) {
                lnrExpandFarmerDetails.setVisibility(View.GONE);
                imgFarmerDetails.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandFarmerDetails.setVisibility(View.VISIBLE);
                imgFarmerDetails.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.ns_img_farmerAC) {
            if (lnrExpandFarmerAC.getVisibility() == View.VISIBLE) {
                lnrExpandFarmerAC.setVisibility(View.GONE);
                imgFarmerAC.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandFarmerAC.setVisibility(View.VISIBLE);
                imgFarmerAC.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.ns_img_grainAC) {
            if (lnrExpandGrainAC.getVisibility() == View.VISIBLE) {
                lnrExpandGrainAC.setVisibility(View.GONE);
                imgGrainAC.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandGrainAC.setVisibility(View.VISIBLE);
                imgGrainAC.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.ns_img_silageAC) {
            if (lnrExpandSilageAC.getVisibility() == View.VISIBLE) {
                lnrExpandSilageAC.setVisibility(View.GONE);
                imgSilageAC.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandSilageAC.setVisibility(View.VISIBLE);
                imgSilageAC.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.ns_img_competitorGrainPlan) {
            if (lnrExpandCompetitorGrainPlan.getVisibility() == View.VISIBLE) {
                lnrExpandCompetitorGrainPlan.setVisibility(View.GONE);
                imgCompetitorGrainPlan.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandCompetitorGrainPlan.setVisibility(View.VISIBLE);
                imgCompetitorGrainPlan.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.ns_img_competitorSilagePlan) {
            if (lnrExpandCompetitorSilagePlan.getVisibility() == View.VISIBLE) {
                lnrExpandCompetitorSilagePlan.setVisibility(View.GONE);
                imgCompetitorSilagePlan.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandCompetitorSilagePlan.setVisibility(View.VISIBLE);
                imgCompetitorSilagePlan.setBackgroundResource(R.drawable.dropdown_down);
            }

        } else if (i == R.id.ns_img_maturity_rice) {
            if (lnrExpandMaturity.getVisibility() == View.VISIBLE) {
                lnrExpandMaturity.setVisibility(View.GONE);
                imgMaturity.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandMaturity.setVisibility(View.VISIBLE);
                imgMaturity.setBackgroundResource(R.drawable.dropdown_down);
            }

        } else if (i == R.id.ns_img_heading1) {
            if (lnrExpandHeading.getVisibility() == View.VISIBLE) {
                lnrExpandHeading.setVisibility(View.GONE);
                imgHeading.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandHeading.setVisibility(View.VISIBLE);
                imgHeading.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.ns_current_hybrid) {
            if (lnrExpandCurrentHybrid.getVisibility() == View.VISIBLE) {
                lnrExpandCurrentHybrid.setVisibility(View.GONE);
                imgCurrentHybrid.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandCurrentHybrid.setVisibility(View.VISIBLE);
                imgCurrentHybrid.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.ns_training) {
            if (lnrExpandTraining.getVisibility() == View.VISIBLE) {
                lnrExpandTraining.setVisibility(View.GONE);
                imgTraining.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrExpandTraining.setVisibility(View.VISIBLE);
                imgTraining.setBackgroundResource(R.drawable.dropdown_down);
            }
        } else if (i == R.id.btn_submit) {
            String validation = submitValidation();
            if (validation == null) {
                showAlertToSave();
            } else {
                DialogManager.showSingleBtnPopup(mActivity, null, getString(R.string.alert), validation, getString(R.string.ok));
            }

        } else if (i == R.id.fs_feedback_header_ll) {
            if (lnrFeedbackBody.getVisibility() == View.VISIBLE) {
                lnrFeedbackBody.setVisibility(View.GONE);
                imgFeedback.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrFeedbackBody.setVisibility(View.VISIBLE);
                imgFeedback.setBackgroundResource(R.drawable.dropdown_down);
            }

        }
    }

    private void pupolateNestleServiceData(FarmerSegmentationNestleResponseDTO nestleModel) {
        IdNameModel data = (IdNameModel) spnDivision.getTag();
        if (!data.getName().equalsIgnoreCase("Farmer Segmentation")) { // Nestle Selected
            if (Utility.isValidStr(nestleModel.getSilageFeeding())) {
                if (nestleModel.getSilageFeeding().equalsIgnoreCase("yes"))
                    radioGroupSilageFeeding.check(R.id.radio_feedyes);
                else
                    radioGroupSilageFeeding.check(R.id.radio_feedno);
            }

            if (Utility.isValidStr(nestleModel.getGrowingProcuring())) {
                if (nestleModel.getGrowingProcuring().equalsIgnoreCase("Growing"))
                    spnGrowing.setSelection(1);
                else if (nestleModel.getGrowingProcuring().equalsIgnoreCase("procuring"))
                    spnGrowing.setSelection(2);
            }

            if (nestleModel.getAcres() > 0)
                edtAcresGrow.setText(String.valueOf(nestleModel.getAcres()));

            if (Utility.isValidStr(nestleModel.getHybridName1()))
                txtHybrid1.setText(nestleModel.getHybridName1());
            if (Utility.isValidStr(nestleModel.getHybridName2()))
                txtHybrid2.setText(nestleModel.getHybridName2());
            if (Utility.isValidStr(nestleModel.getHybridName3()))
                txtHybrid3.setText(nestleModel.getHybridName3());
            if (Utility.isValidStr(nestleModel.getHybridName4()))
                txtHybrid4.setText(nestleModel.getHybridName4());
            if (Utility.isValidStr(nestleModel.getHybridName5()))
                txtHybrid5.setText(nestleModel.getHybridName5());

            if (nestleModel.getHybridValue1() > 0)
                edtHybridValue1.setText(String.valueOf(nestleModel.getHybridValue1()));
            if (nestleModel.getHybridValue2() > 0)
                edtHybridValue2.setText(String.valueOf(nestleModel.getHybridValue2()));
            if (nestleModel.getHybridValue3() > 0)
                edtHybridValue3.setText(String.valueOf(nestleModel.getHybridValue3()));
            if (nestleModel.getHybridValue4() > 0)
                edtHybridValue4.setText(String.valueOf(nestleModel.getHybridValue4()));
            if (nestleModel.getHybridValue5() > 0)
                edtHybridValue5.setText(String.valueOf(nestleModel.getHybridValue5()));

            if (Utility.isValidStr(nestleModel.getPlant())) {
                if (nestleModel.getPlant().equalsIgnoreCase("yes"))
                    radioGroupPlant.check(R.id.radio_training_yes);
                else
                    radioGroupPlant.check(R.id.radio_training_no);
            }

            if (Utility.isValidStr(nestleModel.getGrow())) {
                if (nestleModel.getGrow().equalsIgnoreCase("yes"))
                    radioGroupGrow.check(R.id.radio_grow_yes);
                else
                    radioGroupGrow.check(R.id.radio_grow_no);
            }

            if (Utility.isValidStr(nestleModel.getHarvest())) {
                if (nestleModel.getHarvest().equalsIgnoreCase("yes"))
                    radioGroupHarvest.check(R.id.radio_harvest_yes);
                else
                    radioGroupHarvest.check(R.id.radio_harvest_no);
            }

            if (Utility.isValidStr(nestleModel.getStore())) {
                if (nestleModel.getStore().equalsIgnoreCase("yes"))
                    radioGroupStore.check(R.id.radio_store_yes);
                else
                    radioGroupStore.check(R.id.radio_store_no);
            }

            if (Utility.isValidStr(nestleModel.getFeed())) {
                if (nestleModel.getFeed().equalsIgnoreCase("yes"))
                    radioGroupFeed.check(R.id.radio_feednestle_yes);
                else
                    radioGroupFeed.check(R.id.radio_feednestle_no);
            }
        }
    }

    private void populateServiceData(FarmerSegmentationResponseDTO dto) {

        IdNameModel yearData = (IdNameModel) spnYear.getTag();
        IdNameModel seasonData = (IdNameModel) spnSeason.getTag();
        IdNameModel cropData = (IdNameModel) spnCrop.getTag();

        if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
            if (dto.getMaturity124Ac() > 0) {
                edtMaturity124Acr.setText(String.valueOf(dto.getMaturity124Ac()));
            }
            if (dto.getMaturity134Ac() > 0) {
                edtMaturity134Acr.setText(String.valueOf(dto.getMaturity134Ac()));
            }
            if (dto.getMaturity135Ac() > 0) {
                edtMaturity135Acr.setText(String.valueOf(dto.getMaturity135Ac()));
            }

            if (Utility.isValidStr(String.valueOf(dto.getRiceHybrid1Name()))) {
                for (int i = 0; i < riceHybrid1List.size(); i++) {
                    if (riceHybrid1List.get(i).equalsIgnoreCase(dto.getRiceHybrid1Name())) {
                        spnGrainHybrid1.setSelection(i);
                        break;
                    }
                }
            }

            if (dto.getRiceHybrid1Acres() > 0) {
                edtGrainHybridValue1.setText(String.valueOf(dto.getRiceHybrid1Acres()));
            }
            if (dto.getRiceHybrid2Acres() > 0) {
                edtGrainHybridValue2.setText(String.valueOf(dto.getRiceHybrid2Acres()));
            }
            if (dto.getRiceHybrid3Acres() > 0) {
                edtGrainHybridValue3.setText(String.valueOf(dto.getRiceHybrid3Acres()));
            }
            if (dto.getRiceHybrid4Acres() > 0) {
                edtGrainHybridValue4.setText(String.valueOf(dto.getRiceHybrid4Acres()));
            }


            if (Utility.isValidStr(dto.getRiceCompetitorHybrid1())) {
                edtCompetitorGrainPlan1.setText(String.valueOf(dto.getRiceCompetitorHybrid1()));
            }
            if (Utility.isValidStr(dto.getRiceCompetitorHybrid2())) {
                edtCompetitorGrainPlan2.setText(String.valueOf(dto.getRiceCompetitorHybrid2()));
            }
            if (Utility.isValidStr(dto.getRiceCompetitorHybrid3())) {
                edtCompetitorGrainPlan3.setText(String.valueOf(dto.getRiceCompetitorHybrid3()));
            }
            if (Utility.isValidStr(dto.getRiceCompetitorHybrid4())) {
                edtCompetitorGrainPlan4.setText(String.valueOf(dto.getRiceCompetitorHybrid4()));
            }


            if (dto.getRiceCompetitorHybridValue1() > 0) {
                edtCompetitorGrainPlanValue1.setText(String.valueOf(dto.getRiceCompetitorHybridValue1()));
            }
            if (dto.getRiceCompetitorHybridValue2() > 0) {
                edtCompetitorGrainPlanValue2.setText(String.valueOf(dto.getRiceCompetitorHybridValue2()));
            }
            if (dto.getRiceCompetitorHybridValue3() > 0) {
                edtCompetitorGrainPlanValue3.setText(String.valueOf(dto.getRiceCompetitorHybridValue3()));
            }
            if (dto.getRiceCompetitorHybridValue4() > 0) {
                edtCompetitorGrainPlanValue4.setText(String.valueOf(dto.getRiceCompetitorHybridValue4()));
            }

            if (Utility.isValidStr(dto.getRiceServices())) {
                spnGrainServices1.setText(dto.getRiceServices());
            }

            if (Utility.isValidStr(dto.getDirectSowingRice())) {
                if (dto.getDirectSowingRice().equalsIgnoreCase("Yes")) {
                    radioGroupSowingRice.check(R.id.radio_yes_sowing_rice);
                } else {
                    radioGroupSowingRice.check(R.id.radio_no_sowing_rice);
                }
            }

            if (Utility.isValidStr(dto.getTblParticipated())) {
                if (dto.getTblParticipated().equalsIgnoreCase("yes")) {
                    radioGroup.check(R.id.radio_yes);
                } else {
                    radioGroup.check(R.id.radio_no);
                }
            }

        } else {

            if (dto.getPhiCommitmentGrainAcres() > 0)
                edtPHIGrainAC.setText(String.valueOf(dto.getPhiCommitmentGrainAcres()));
            if (dto.getPhiCommitmentSilageAcres() > 0)
                edtPHISilageAC.setText(String.valueOf(dto.getPhiCommitmentSilageAcres()));

            // Spinner Grain Hybrids
            if (Utility.isValidStr(String.valueOf(dto.getGrainHybrid1Name()))) {
                for (int i = 0; i < grainHybrid1List.size(); i++) {
                    if (grainHybrid1List.get(i).equalsIgnoreCase(dto.getGrainHybrid1Name())) {
                        spnGrainHybrid1.setSelection(i);
                        break;
                    }
                }
            }
            if (dto.getGrainHybrid1Acres() > 0)
                edtGrainHybridValue1.setText(String.valueOf(dto.getGrainHybrid1Acres()));
            if (dto.getGrainHybrid2Acres() > 0)
                edtGrainHybridValue2.setText(String.valueOf(dto.getGrainHybrid2Acres()));
            if (dto.getGrainHybrid3Acres() > 0)
                edtGrainHybridValue3.setText(String.valueOf(dto.getGrainHybrid3Acres()));
            if (dto.getGrainHybrid4Acres() > 0)
                edtGrainHybridValue4.setText(String.valueOf(dto.getGrainHybrid4Acres()));

            // Spinner Silage Hybrids
            if (Utility.isValidStr(String.valueOf(dto.getSilageHybrid1Name()))) {
                for (int i = 0; i < silageHybrid1List.size(); i++) {
                    if (silageHybrid1List.get(i).equalsIgnoreCase(dto.getSilageHybrid1Name())) {
                        spnSilageHybrid1.setSelection(i);
                        break;
                    }
                }
            }
            if (dto.getSilageHybrid1Acres() > 0)
                edtSilageHybridValue1.setText(String.valueOf(dto.getSilageHybrid1Acres()));
            if (dto.getSilageHybrid2Acres() > 0)
                edtSilageHybridValue2.setText(String.valueOf(dto.getSilageHybrid2Acres()));
            if (dto.getSilageHybrid3Acres() > 0)
                edtSilageHybridValue3.setText(String.valueOf(dto.getSilageHybrid3Acres()));
            if (dto.getSilageHybrid4Acres() > 0)
                edtSilageHybridValue4.setText(String.valueOf(dto.getSilageHybrid4Acres()));

//            if (yearData.getName().equalsIgnoreCase("2019")) {
            if (yearData.getName().trim().equalsIgnoreCase(Utility.getYear().trim())) {

                // Grain Competitor Labels
                if (Utility.isValidStr(dto.getGrainCompetitorHybrid1()) && dto.getGrainCompetitorHybrid1().equalsIgnoreCase("DKC9108"))
                    edtCompetitorGrainPlan1.setText(dto.getGrainCompetitorHybrid1());
                if (Utility.isValidStr(dto.getGrainCompetitorHybrid2()) && dto.getGrainCompetitorHybrid2().equalsIgnoreCase("DKC9162"))
                    edtCompetitorGrainPlan2.setText(dto.getGrainCompetitorHybrid2());
                if (Utility.isValidStr(dto.getGrainCompetitorHybrid3()) && dto.getGrainCompetitorHybrid3().equalsIgnoreCase("LEMAGRAIN"))
                    edtCompetitorGrainPlan3.setText(dto.getGrainCompetitorHybrid3());
                if (Utility.isValidStr(dto.getGrainCompetitorHybrid4()) && dto.getGrainCompetitorHybrid4().equalsIgnoreCase("ADVANTA"))
                    edtCompetitorGrainPlan4.setText(dto.getGrainCompetitorHybrid4());
                if (Utility.isValidStr(dto.getGrainCompetitorHybrid5()) && dto.getGrainCompetitorHybrid5().equalsIgnoreCase("OTHER"))
                    edtCompetitorGrainPlan5.setText(dto.getGrainCompetitorHybrid5());

                // Grain Competitor Values
                if (dto.getGrainCompetitorHybridValue1() > 0 && Utility.isValidStr(dto.getGrainCompetitorHybrid1()) && dto.getGrainCompetitorHybrid1().equalsIgnoreCase("DKC9108"))
                    edtCompetitorGrainPlanValue1.setText(String.valueOf(dto.getGrainCompetitorHybridValue1()));
                if (dto.getGrainCompetitorHybridValue2() > 0 && Utility.isValidStr(dto.getGrainCompetitorHybrid2()) && dto.getGrainCompetitorHybrid2().equalsIgnoreCase("DKC9162"))
                    edtCompetitorGrainPlanValue2.setText(String.valueOf(dto.getGrainCompetitorHybridValue2()));
                if (dto.getGrainCompetitorHybridValue3() > 0 && Utility.isValidStr(dto.getGrainCompetitorHybrid3()) && dto.getGrainCompetitorHybrid3().equalsIgnoreCase("LEMAGRAIN"))
                    edtCompetitorGrainPlanValue3.setText(String.valueOf(dto.getGrainCompetitorHybridValue3()));
                if (dto.getGrainCompetitorHybridValue4() > 0 && Utility.isValidStr(dto.getGrainCompetitorHybrid4()) && dto.getGrainCompetitorHybrid4().equalsIgnoreCase("ADVANTA"))
                    edtCompetitorGrainPlanValue4.setText(String.valueOf(dto.getGrainCompetitorHybridValue4()));
                if (dto.getGrainCompetitorHybridValue5() > 0 && Utility.isValidStr(dto.getGrainCompetitorHybrid5()) && dto.getGrainCompetitorHybrid5().equalsIgnoreCase("OTHER"))
                    edtCompetitorGrainPlanValue5.setText(String.valueOf(dto.getGrainCompetitorHybridValue5()));

                // Silage Competitor Labels
                if (Utility.isValidStr(dto.getSilageCompetitorHybrid1()) && dto.getSilageCompetitorHybrid1().equalsIgnoreCase("DKC9108"))
                    edtCompetitorSilagePlan1.setText(dto.getSilageCompetitorHybrid1());
                if (Utility.isValidStr(dto.getSilageCompetitorHybrid2()) && dto.getSilageCompetitorHybrid2().equalsIgnoreCase("DKC9162"))
                    edtCompetitorSilagePlan2.setText(dto.getSilageCompetitorHybrid2());
                if (Utility.isValidStr(dto.getSilageCompetitorHybrid3()) && dto.getSilageCompetitorHybrid3().equalsIgnoreCase("LEMAGRAIN"))
                    edtCompetitorSilagePlan3.setText(dto.getSilageCompetitorHybrid3());
                if (Utility.isValidStr(dto.getSilageCompetitorHybrid4()) && dto.getSilageCompetitorHybrid4().equalsIgnoreCase("ADVANTA"))
                    edtCompetitorSilagePlan4.setText(dto.getSilageCompetitorHybrid4());
                if (Utility.isValidStr(dto.getSilageCompetitorHybrid5()) && dto.getSilageCompetitorHybrid5().equalsIgnoreCase("OTHER"))
                    edtCompetitorSilagePlan5.setText(dto.getSilageCompetitorHybrid5());

                // Silage Competitor Values
                if (dto.getSilageCompetitorHybridValue1() > 0 && Utility.isValidStr(dto.getSilageCompetitorHybrid1()) && dto.getSilageCompetitorHybrid1().equalsIgnoreCase("DKC9108"))
                    edtCompetitorSilagePlanValue1.setText(String.valueOf(dto.getSilageCompetitorHybridValue1()));
                if (dto.getSilageCompetitorHybridValue2() > 0 && Utility.isValidStr(dto.getSilageCompetitorHybrid2()) && dto.getSilageCompetitorHybrid2().equalsIgnoreCase("DKC9162"))
                    edtCompetitorSilagePlanValue2.setText(String.valueOf(dto.getSilageCompetitorHybridValue2()));
                if (dto.getSilageCompetitorHybridValue3() > 0 && Utility.isValidStr(dto.getSilageCompetitorHybrid3()) && dto.getSilageCompetitorHybrid3().equalsIgnoreCase("LEMAGRAIN"))
                    edtCompetitorSilagePlanValue3.setText(String.valueOf(dto.getSilageCompetitorHybridValue3()));
                if (dto.getSilageCompetitorHybridValue4() > 0 && Utility.isValidStr(dto.getSilageCompetitorHybrid4()) && dto.getSilageCompetitorHybrid4().equalsIgnoreCase("ADVANTA"))
                    edtCompetitorSilagePlanValue4.setText(String.valueOf(dto.getSilageCompetitorHybridValue4()));
                if (dto.getSilageCompetitorHybridValue5() > 0 && Utility.isValidStr(dto.getSilageCompetitorHybrid5()) && dto.getSilageCompetitorHybrid5().equalsIgnoreCase("OTHER"))
                    edtCompetitorSilagePlanValue5.setText(String.valueOf(dto.getSilageCompetitorHybridValue5()));

                if (Utility.isValidStr(dto.getGrainFarmerServices()))
                    spnGrainServices1.setText(dto.getGrainFarmerServices());
                if (Utility.isValidStr(dto.getSilageFarmerServices()))
                    spnSilageServices1.setText(dto.getSilageFarmerServices());

                if (Utility.isValidStr(dto.getTblParticipated())) {
                    if (dto.getTblParticipated().equalsIgnoreCase("yes")) {
                        radioGroup.check(R.id.radio_yes);
                    } else {
                        radioGroup.check(R.id.radio_no);
                    }
                }
                if (Utility.isValidStr(dto.getVisitedCornHybrid())) {
                    if (dto.getVisitedCornHybrid().equalsIgnoreCase("Yes"))
                        feedbackRadioGrp.check(R.id.radio_fb_yes);
                    else
                        feedbackRadioGrp.check(R.id.radio_fb_no);
                }

                if (Utility.isValidStr(dto.getVisitedCornHybridLike())) {
                    String[] prevLiked = dto.getVisitedCornHybridLike().split(",");
                    for (int i = 0; i < prevLiked.length; i++) {
                        if (getString(R.string.shelling_percentage).equalsIgnoreCase(prevLiked[i]))
                            cbShelling.setChecked(true);
                        else if (getString(R.string.grain_weight).equalsIgnoreCase(prevLiked[i]))
                            cbGrainWeight.setChecked(true);
                        else if (getString(R.string.earliness_short_crop_duration).equalsIgnoreCase(prevLiked[i]))
                            cbEarliness.setChecked(true);
                        else if (getString(R.string.grain_moisture_percentage).equalsIgnoreCase(prevLiked[i]))
                            cbGrainMoisture.setChecked(true);
                        else if (getString(R.string.standability).equalsIgnoreCase(prevLiked[i]))
                            cbStandability.setChecked(true);
                    }
                }

                if (Utility.isValidStr(dto.getRateHybrid()))
                    fbRatingBar.setRating(Float.parseFloat(dto.getRateHybrid()));

                if (Utility.isValidStr(dto.getShiftNextYrAcres()))
                    fb_shift_yearET.setText(dto.getShiftNextYrAcres());
            }
        }
    }

    private String submitValidation() {
        IdNameModel data = (IdNameModel) spnDivision.getTag();
        String name = data.getName();


        if (name.equalsIgnoreCase(MyConstants.FARMER_SEGMENTATION)) {
            if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                //maturity
                if (Utility.getText(edtMaturity124Acr).isEmpty())
                    return getString(R.string.empty_maturity_124);

                if (Utility.getText(edtMaturity134Acr).isEmpty())
                    return getString(R.string.empty_maturity_134);

                if (Utility.getText(edtMaturity135Acr).isEmpty())
                    return getString(R.string.empty_maturity_135);

                double gct124 = 0, gct134 = 0, gct135 = 0, total;

                if (Utility.isValidStr(edtMaturity124Acr.getText().toString().trim()))
                    gct124 = Double.parseDouble(edtMaturity124Acr.getText().toString().trim());
                if (Utility.isValidStr(edtMaturity134Acr.getText().toString().trim()))
                    gct134 = Double.parseDouble(edtMaturity134Acr.getText().toString().trim());
                if (Utility.isValidStr(edtMaturity135Acr.getText().toString().trim()))
                    gct135 = Double.parseDouble(edtMaturity135Acr.getText().toString().trim());
                total = gct124 + gct134 + gct135;

                if (total != Double.parseDouble(edtGrainAC.getText().toString().trim()))
                    return "Sum of hybrid rice duration should be equal to hybrid rice acres";

                //pioneer hydird validation

              /*  if (Utility.getText(edtGrainHybridValue1).isEmpty() || Utility.getText(edtGrainHybridValue2).isEmpty() ||
                        Utility.getText(edtGrainHybridValue3).isEmpty() || Utility.getText(edtGrainHybridValue4).isEmpty()) {
                    return "Please enter any one Rice Hybrid Value";
                }*/

                if (spnGrainHybrid1.getSelectedItemPosition() > 0) {
                    if (Utility.getText(edtGrainHybridValue1).isEmpty()) {
                        return getString(R.string.please_enter_rice_hybrid_value1);
                    }
                }
                if (!Utility.getText(edtGrainHybridValue1).isEmpty()) {
                    if (spnGrainHybrid1.getSelectedItemPosition() <= 0) {
                        return getString(R.string.please_select_rice_hybrid1);
                    }
                }
                if (spnGrainHybrid2.getSelectedItemPosition() > 0) {
                    if (Utility.getText(edtGrainHybridValue2).isEmpty()) {
                        return getString(R.string.please_enter_rice_hybrid_value2);
                    }
                }
                if (!Utility.getText(edtGrainHybridValue2).isEmpty()) {
                    if (spnGrainHybrid2.getSelectedItemPosition() <= 0) {
                        return getString(R.string.please_select_rice_hybrid2);
                    }
                }
                if (spnGrainHybrid3.getSelectedItemPosition() > 0) {
                    if (Utility.getText(edtGrainHybridValue3).isEmpty()) {
                        return getString(R.string.please_enter_rice_hybrid_value3);
                    }
                }
                if (!Utility.getText(edtGrainHybridValue3).isEmpty()) {
                    if (spnGrainHybrid3.getSelectedItemPosition() <= 0) {
                        return getString(R.string.please_select_rice_hybrid3);
                    }
                }
                if (spnGrainHybrid4.getSelectedItemPosition() > 0) {
                    if (Utility.getText(edtGrainHybridValue4).isEmpty()) {
                        return getString(R.string.please_enter_rice_hybrid_value4);
                    }
                }
                if (!Utility.getText(edtGrainHybridValue4).isEmpty()) {
                    if (spnGrainHybrid4.getSelectedItemPosition() <= 0) {
                        return getString(R.string.please_select_rice_hybrid4);
                    }
                }

                //Competitior hybird
                if (!Utility.getText(edtCompetitorGrainPlan1).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlanValue1).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_value1);
                    }
                }
                if (!Utility.getText(edtCompetitorGrainPlanValue1).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlan1).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_hybrid1);
                    }
                }
                if (!Utility.getText(edtCompetitorGrainPlan2).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlanValue2).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_value2);
                    }
                }
                if (!Utility.getText(edtCompetitorGrainPlanValue2).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlan2).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_hybrid2);
                    }
                }
                if (!Utility.getText(edtCompetitorGrainPlan3).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlanValue3).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_value3);
                    }
                }
                if (!Utility.getText(edtCompetitorGrainPlanValue3).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlan3).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_hybrid3);
                    }
                }
                if (!Utility.getText(edtCompetitorGrainPlan4).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlanValue4).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_value4);
                    }
                }
                if (!Utility.getText(edtCompetitorGrainPlanValue4).isEmpty()) {
                    if (Utility.getText(edtCompetitorGrainPlan4).isEmpty()) {
                        return getString(R.string.please_enter_rice_competitor_hybrid4);
                    }
                }

                double gh1 = 0, gh2 = 0, gh3 = 0, gh4 = 0, totalVal;
                double riceH1 = 0, riceH2 = 0, riceH3 = 0, riceH4 = 0;

                if (Utility.isValidStr(edtGrainHybridValue1.getText().toString().trim()))
                    riceH1 = Double.parseDouble(edtGrainHybridValue1.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue2.getText().toString().trim()))
                    riceH2 = Double.parseDouble(edtGrainHybridValue2.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue3.getText().toString().trim()))
                    riceH3 = Double.parseDouble(edtGrainHybridValue3.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue4.getText().toString().trim()))
                    riceH4 = Double.parseDouble(edtGrainHybridValue4.getText().toString().trim());

                if (Utility.isValidStr(edtCompetitorGrainPlanValue1.getText().toString().trim()))
                    gh1 = Double.parseDouble(edtCompetitorGrainPlanValue1.getText().toString().trim());
                if (Utility.isValidStr(edtCompetitorGrainPlanValue2.getText().toString().trim()))
                    gh2 = Double.parseDouble(edtCompetitorGrainPlanValue2.getText().toString().trim());
                if (Utility.isValidStr(edtCompetitorGrainPlanValue3.getText().toString().trim()))
                    gh3 = Double.parseDouble(edtCompetitorGrainPlanValue3.getText().toString().trim());
                if (Utility.isValidStr(edtCompetitorGrainPlanValue4.getText().toString().trim()))
                    gh4 = Double.parseDouble(edtCompetitorGrainPlanValue4.getText().toString().trim());

                totalVal = riceH1 + riceH2 + riceH3 + riceH4 + gh1 + gh2 + gh3 + gh4;

                if (totalVal != Double.parseDouble(edtGrainAC.getText().toString().trim()))
//                    return "Sum of all hybrid values should be equal to hybrid rice acres";
                    return "Sum of all Pioneer and Competitor Hybrid Plan values should be equals to Hybrid Rice Acres";


                if (radioGroupSowingRice.getCheckedRadioButtonId() == -1)
                    return getString(R.string.fs_select_diect_sowing_radio);

                if (radioGroup.getCheckedRadioButtonId() == -1)
                    return getString(R.string.fs_select_radio_button);

            } else {

                if (Utility.getText(edtPHIGrainAC).isEmpty())
                    return getString(R.string.please_phi_grain);
                if (Utility.getText(edtPHISilageAC).isEmpty())
                    return getString(R.string.please_phi_silage);

                if (Double.parseDouble(edtPHIGrainAC.getText().toString().trim()) <= 0 && Double.parseDouble(edtPHISilageAC.getText().toString().trim()) <= 0)
                    return getString(R.string.please_enter_phi_grain_or_silage);

                if (Double.parseDouble(edtPHIGrainAC.getText().toString().trim()) > 0) {
                    if (spnGrainHybrid1.getSelectedItem().toString().equalsIgnoreCase(MyConstants.SelectHybrid1)) {
                        return getString(R.string.please_select_grain_hybrid);
                    }

                    if (spnGrainHybrid1.getSelectedItemPosition() > 0) {
                        if (Utility.getText(edtGrainHybridValue1).isEmpty()) {
                            return getString(R.string.please_enter_grain_hybrid_value);
                        }
                    }
                    if (!Utility.getText(edtGrainHybridValue1).isEmpty()) {
                        if (spnGrainHybrid1.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_grain_hybrid);
                        }
                    }
                    if (spnGrainHybrid2.getSelectedItemPosition() > 0) {
                        if (Utility.getText(edtGrainHybridValue2).isEmpty()) {
                            return getString(R.string.please_enter_grain_hybrid_value1);
                        }
                    }
                    if (!Utility.getText(edtGrainHybridValue2).isEmpty()) {
                        if (spnGrainHybrid2.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_grain_hybrid1);
                        }
                    }
                    if (spnGrainHybrid3.getSelectedItemPosition() > 0) {
                        if (Utility.getText(edtGrainHybridValue3).isEmpty()) {
                            return getString(R.string.please_enter_grain_hybrid_value2);
                        }
                    }
                    if (!Utility.getText(edtGrainHybridValue3).isEmpty()) {
                        if (spnGrainHybrid3.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_grain_hybrid2);
                        }
                    }
                    if (spnGrainHybrid4.getSelectedItemPosition() > 0) {
                        if (Utility.getText(edtGrainHybridValue4).isEmpty()) {
                            return getString(R.string.please_enter_grain_hybrid_value3);
                        }
                    }
                    if (!Utility.getText(edtGrainHybridValue4).isEmpty()) {
                        if (spnGrainHybrid4.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_grain_hybrid3);
                        }
                    }
                }

                if (Double.parseDouble(edtPHISilageAC.getText().toString().trim()) > 0) {
                    if (spnSilageHybrid1.getSelectedItem().toString().equalsIgnoreCase(MyConstants.SelectSilageHybrid1)) {
                        return getString(R.string.please_select_silage_hybrid);
                    }

                    if (spnSilageHybrid1.getSelectedItemPosition() > 0) {
                        if (Utility.getText(edtSilageHybridValue1).isEmpty()) {
                            return getString(R.string.please_enter_silage_hybrid_value);
                        }
                    }
                    if (!Utility.getText(edtSilageHybridValue1).isEmpty()) {
                        if (spnSilageHybrid1.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_silage_hybrid);
                        }
                    }
                    if (spnSilageHybrid2.getSelectedItemPosition() > 0) {
                        if (Utility.getText(edtSilageHybridValue2).isEmpty()) {
                            return getString(R.string.please_enter_silage_hybrid_value1);
                        }
                    }
                    if (!Utility.getText(edtSilageHybridValue2).isEmpty()) {
                        if (spnSilageHybrid2.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_silage_hybrid1);
                        }
                    }

                    if (!Utility.getText(edtSilageHybridValue3).isEmpty()) {
                        if (spnSilageHybrid3.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_silage_hybrid2);
                        }
                    }

                    if (!Utility.getText(edtSilageHybridValue4).isEmpty()) {
                        if (spnSilageHybrid4.getSelectedItemPosition() <= 0) {
                            return getString(R.string.please_select_silage_hybrid3);
                        }
                    }
                }

                if (radioGroup.getCheckedRadioButtonId() == -1)
                    return getString(R.string.fs_select_radio_button);

                if (feedbackRadioGrp.getCheckedRadioButtonId() == -1)
                    return getString(R.string.feedback_spring_corn_hrbid_error);

                if (feedbackRadioGrp.getCheckedRadioButtonId() == R.id.radio_fb_yes) {
                    if (cbShelling.isChecked() == false && cbGrainWeight.isChecked() == false && cbEarliness.isChecked() == false && cbGrainMoisture.isChecked() == false && cbStandability.isChecked() == false)
                        return getString(R.string.feedback_spring_corn_hrbid_yes_error);

                    if (fbRatingBar.getRating() <= 0)
                        return getString(R.string.rating_hybrid_error);

                    if (!Utility.isValidStr(fb_shift_yearET.getText().toString().trim()))
                        return getString(R.string.fb_shift_year_percentage_error).replace("$1", String.valueOf(nextYear));
                }
            }
        } else {
            if (radioGroupSilageFeeding.getCheckedRadioButtonId() == -1)
                return "Please select silage feeding";

            if (radioGroupSilageFeeding.getCheckedRadioButtonId() == R.id.radio_feedyes) {
                if (spnGrowing.getSelectedItemPosition() == 0) {
                    return "Please select growing or procuring";
                }

                if (Utility.getText(edtAcresGrow).isEmpty())
                    return "Please enter growing acres";

                if (Utility.isValidStr(edtAcresGrow.getText().toString().trim())) {

                    if (Utility.getText(edtHybridValue1).isEmpty() && Utility.getText(edtHybridValue2).isEmpty() &&
                            Utility.getText(edtHybridValue3).isEmpty() && Utility.getText(edtHybridValue4).isEmpty() &&
                            Utility.getText(edtHybridValue5).isEmpty())
                        return "Please enter any one of current hybrids used";

                    double gct1 = 0, gct2 = 0, gct3 = 0, gct4 = 0, gct5 = 0, total;

                    if (Utility.isValidStr(edtHybridValue1.getText().toString().trim()))
                        gct1 = Double.parseDouble(edtHybridValue1.getText().toString().trim());
                    if (Utility.isValidStr(edtHybridValue2.getText().toString().trim()))
                        gct2 = Double.parseDouble(edtHybridValue2.getText().toString().trim());
                    if (Utility.isValidStr(edtHybridValue3.getText().toString().trim()))
                        gct3 = Double.parseDouble(edtHybridValue3.getText().toString().trim());
                    if (Utility.isValidStr(edtHybridValue4.getText().toString().trim()))
                        gct4 = Double.parseDouble(edtHybridValue4.getText().toString().trim());
                    if (Utility.isValidStr(edtHybridValue5.getText().toString().trim()))
                        gct5 = Double.parseDouble(edtHybridValue5.getText().toString().trim());

                    total = gct1 + gct2 + gct3 + gct4 + gct5;

                    if (total != Double.parseDouble(edtAcresGrow.getText().toString().trim()))
                        return "Sum of current hybrid used should  be equal to growing acres";

                }
            }

            if (radioGroupPlant.getCheckedRadioButtonId() == -1)
                return "Please select training - Plant ";

            if (radioGroupGrow.getCheckedRadioButtonId() == -1)
                return "Please select training - Grow ";

            if (radioGroupHarvest.getCheckedRadioButtonId() == -1)
                return "Please select training - Harvest ";

            if (radioGroupStore.getCheckedRadioButtonId() == -1)
                return "Please select training - Store ";

            if (radioGroupFeed.getCheckedRadioButtonId() == -1)
                return "Please select training - Feed ";
        }

        return null;
    }

    private void setProceedFocus() {
        IdNameModel data = (IdNameModel) spnDivision.getTag();
        String name = data.getName();

        IdNameModel yearData = (IdNameModel) spnYear.getTag();
        IdNameModel seasonData = (IdNameModel) spnSeason.getTag();
        IdNameModel cropData = (IdNameModel) spnCrop.getTag();


        if (name.equalsIgnoreCase(MyConstants.FARMER_SEGMENTATION)) {

            if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {


                layout_competitor3.setVisibility(View.GONE);
                layout_competitor4.setVisibility(View.GONE);
                layout_competitor5.setVisibility(View.GONE);
                layout_competitorGrain5.setVisibility(View.GONE);

                edtFarmerName.setEnabled(false);
                edtDistrictName.setEnabled(false);
                edtBlockName.setEnabled(false);
                edtVillageName.setEnabled(false);
                edtPlanCrop.setEnabled(false);
                edtGrainAC.setEnabled(false);
                edtSilageAC.setEnabled(false);

                btnEdit.setEnabled(false);
                btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));
                btnProceedNext.setEnabled(false);
                btnProceedNext.setBackgroundColor(getResources().getColor(R.color.drak_grey));

                // btn proceed scroll to top.
                edtMaturity124Acr.requestFocus();

                //Full Layout
                lnrCornLayout.setVisibility(View.VISIBLE);

                //Nestle Layout
                lnrLayoutHeading.setVisibility(View.GONE);

                //Rice Layout
                lnrImgClickMaturity.setVisibility(View.VISIBLE);
                lnrExpandMaturity.setVisibility(View.VISIBLE);
                lnrLayoutDirectSowing.setVisibility(View.VISIBLE);

                //Corn Layout
                lnrImgClickFarmerAC.setVisibility(View.GONE);
                lnrExpandFarmerAC.setVisibility(View.GONE);
                lnrImgClickGrainAC.setVisibility(View.VISIBLE);
                lnrExpandGrainAC.setVisibility(View.VISIBLE);
                lnrImgClickSilageAC.setVisibility(View.GONE);
                lnrExpandSilageAC.setVisibility(View.GONE);
                lnrImgClickCompetitorGrainPlan.setVisibility(View.VISIBLE);
                lnrExpandCompetitorGrainPlan.setVisibility(View.VISIBLE);
                lnrImgClickCompetitorSilagePlan.setVisibility(View.GONE);
                lnrExpandCompetitorSilagePlan.setVisibility(View.GONE);


                //label change
                grainHybridCommitHeaderTv.setText(getString(R.string.rice_pionner_hybrid));
                grainHybridCompititorHeaderTv.setText(getString(R.string.rice_comp_hybrid));

                edtCompetitorGrainPlan1.setHint(MyConstants.CompetitorHybrid1);
                edtCompetitorGrainPlan1.setEnabled(true);
                edtCompetitorGrainPlan2.setHint(MyConstants.CompetitorHybrid2);
                edtCompetitorGrainPlan2.setEnabled(true);
                edtCompetitorGrainPlan3.setHint(MyConstants.CompetitorHybrid3);
                edtCompetitorGrainPlan3.setEnabled(true);
                edtCompetitorGrainPlan4.setHint(MyConstants.CompetitorHybrid4);
                edtCompetitorGrainPlan4.setEnabled(true); // TARA

                spnGrainHybrid1.setEnabled(true);
            } else {
                edtFarmerName.setEnabled(false);
                edtDistrictName.setEnabled(false);
                edtBlockName.setEnabled(false);
                edtVillageName.setEnabled(false);
                edtPlanCrop.setEnabled(false);
                edtGrainAC.setEnabled(false);
                edtSilageAC.setEnabled(false);
                spnGrainHybrid1.setEnabled(true);
                spnSilageHybrid1.setEnabled(true); // TARA

                btnEdit.setEnabled(false);
                btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));
                btnProceedNext.setEnabled(false);
                btnProceedNext.setBackgroundColor(getResources().getColor(R.color.drak_grey));
                edtPHIGrainAC.requestFocus();

                //Full Layout
                lnrCornLayout.setVisibility(View.VISIBLE);

                //Nestle Layout
                lnrLayoutHeading.setVisibility(View.GONE);

                //Rice Layout
                lnrImgClickMaturity.setVisibility(View.GONE);
                lnrExpandMaturity.setVisibility(View.GONE);
                lnrLayoutDirectSowing.setVisibility(View.GONE);

                //Corn Layout
                lnrImgClickFarmerAC.setVisibility(View.VISIBLE);
                lnrExpandFarmerAC.setVisibility(View.VISIBLE);
                lnrImgClickGrainAC.setVisibility(View.VISIBLE);
                lnrExpandGrainAC.setVisibility(View.VISIBLE);
                lnrImgClickSilageAC.setVisibility(View.VISIBLE);
                lnrExpandSilageAC.setVisibility(View.VISIBLE);
                lnrImgClickCompetitorGrainPlan.setVisibility(View.VISIBLE);
                lnrExpandCompetitorGrainPlan.setVisibility(View.VISIBLE);
                lnrImgClickCompetitorSilagePlan.setVisibility(View.VISIBLE);
                lnrExpandCompetitorSilagePlan.setVisibility(View.VISIBLE);
                lnrFeedbackBody.setVisibility(View.VISIBLE);
                lnrfeedbackHeader.setVisibility(View.VISIBLE);


                if (seasonData.getName().equalsIgnoreCase(MyConstants.SPRING) && cropData.getName().equalsIgnoreCase(MyConstants.CORN)) {

                    layout_competitorGrain5.setVisibility(View.VISIBLE);

                    edtCompetitorGrainPlan1.setText("DKC9108");
                    edtCompetitorGrainPlan1.setEnabled(false);

                    edtCompetitorGrainPlan2.setText("DKC9162");
                    edtCompetitorGrainPlan2.setEnabled(false);

                    edtCompetitorGrainPlan3.setText("Lemagrain");
                    edtCompetitorGrainPlan3.setEnabled(false);

                    edtCompetitorGrainPlan4.setText("Advanta");
                    edtCompetitorGrainPlan4.setEnabled(false);

                    edtCompetitorGrainPlan5.setText("Other");
                    edtCompetitorGrainPlan5.setEnabled(false);

                    layout_competitor3.setVisibility(View.VISIBLE);
                    layout_competitor4.setVisibility(View.VISIBLE);
                    layout_competitor5.setVisibility(View.VISIBLE);

                    edtCompetitorSilagePlan1.setText("DKC9108");
                    edtCompetitorSilagePlan1.setEnabled(false);

                    edtCompetitorSilagePlan2.setText("DKC9162");
                    edtCompetitorSilagePlan2.setEnabled(false);

                    edtCompetitorSilagePlan3.setText("Lemagrain");
                    edtCompetitorSilagePlan3.setEnabled(false);

                    edtCompetitorSilagePlan4.setText("Advanta");
                    edtCompetitorSilagePlan4.setEnabled(false);

                    edtCompetitorSilagePlan5.setText("Other");
                    edtCompetitorSilagePlan5.setEnabled(false);

                    if (Utility.isValidStr(yearData.getName()))

                        yearGet = yearData.getName();

                    commitment_strip_tv.setText("PHI Acres Actual " + yearData.getName());

                    grainHybridCompititorHeaderTv.setText("Competitor Actual Grain " + yearData.getName());
                    grainHybridCommitHeaderTv.setText("PHI Grain Acres Actual " + yearData.getName());

                    silageHybridCommitHeaderTv.setText("PHI Silage Actual " + yearData.getName());
                    silageHybridCompititorHeaderTv.setText("Competitor Actual Silage " + yearData.getName());
                } else {
                    commitment_strip_tv.setText(getString(R.string.phi_ac));
                }
            }
        } else {
            edtFarmerName.setEnabled(false);
            edtDistrictName.setEnabled(false);
            edtBlockName.setEnabled(false);
            edtVillageName.setEnabled(false);
            edtCattleNestle.setEnabled(false);
            edtMilkNestle.setEnabled(false);

            btnEdit.setEnabled(false);
            btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));
            btnProceedNext.setEnabled(false);
            btnProceedNext.setBackgroundColor(getResources().getColor(R.color.drak_grey));

            //Nestle Layout
            lnrLayoutHeading.setVisibility(View.VISIBLE);

            //Farmer Segmentation
            lnrCornLayout.setVisibility(View.GONE);

        }
        btnSubmit.setVisibility(View.VISIBLE);
    }

    private void setEditFocus() {
        IdNameModel data = (IdNameModel) spnDivision.getTag();
        String name = data.getName();
        if (name.equalsIgnoreCase(MyConstants.FARMER_SEGMENTATION)) {
            if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                btnEdit.setEnabled(false);
                btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));

                spnDivision.setEnabled(true);
                spnYear.setEnabled(true);
                spnSeason.setEnabled(true);
                spnCrop.setEnabled(true);

                edtMobileNo.setEnabled(true);
                edtPincode.setEnabled(true);

                lnrFarmerDetails.setVisibility(View.GONE);
                lnrExpandFarmerDetails.setVisibility(View.GONE);

                btnGetDetails.setEnabled(true);
                btnGetDetails.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                profileImage.setImageResource(R.drawable.img_profile_avatar);
                uriStr = null;
                imagePath = null;
                edtFarmerName.setText("");
                edtDistrictName.setText("");
                edtBlockName.setText("");
                edtVillageName.setText("");
                edtPlanCrop.setText("");
                edtGrainAC.setText("");

                // edtSilageAC.setText("");

                //edtPHIGrainAC.setText("");
                //edtPHISilageAC.setText("");

                edtGrainHybridValue1.setText("");
                edtGrainHybridValue2.setText("");
                edtGrainHybridValue3.setText("");
                edtGrainHybridValue4.setText("");
                edtSilageHybridValue1.setText("");
                edtSilageHybridValue2.setText("");
                spnGrainServices1.setText("");
                spnSilageServices1.setText("");
                spnGrainHybrid1.setSelection(0);
                spnGrainHybrid2.setSelection(0);
                spnGrainHybrid3.setSelection(0);
                spnGrainHybrid4.setSelection(0);
                spnSilageHybrid1.setSelection(0);
                spnSilageHybrid2.setSelection(0);
                edtCompetitorGrainPlan1.setText("");
                edtCompetitorGrainPlan2.setText("");
                edtCompetitorGrainPlan3.setText("");
                edtCompetitorGrainPlan4.setText("");
                edtCompetitorGrainPlanValue1.setText("");
                edtCompetitorGrainPlanValue2.setText("");
                edtCompetitorGrainPlanValue3.setText("");
                edtCompetitorGrainPlanValue4.setText("");
                edtCompetitorSilagePlan1.setText("");
                edtCompetitorSilagePlan2.setText("");
                radioGroup.clearCheck();
                //newly added
                radioGroupSowingRice.clearCheck();

            } else {
                btnEdit.setEnabled(false);
                btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));

                spnDivision.setEnabled(true);
                spnYear.setEnabled(true);
                spnSeason.setEnabled(true);
                spnCrop.setEnabled(true);

                edtMobileNo.setEnabled(true);
                edtPincode.setEnabled(true);

                lnrFarmerDetails.setVisibility(View.GONE);
                lnrExpandFarmerDetails.setVisibility(View.GONE);

                btnGetDetails.setEnabled(true);
                btnGetDetails.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                profileImage.setImageResource(R.drawable.img_profile_avatar);
                uriStr = null;
                imagePath = null;
                edtFarmerName.setText("");
                edtDistrictName.setText("");
                edtBlockName.setText("");
                edtVillageName.setText("");
                edtPlanCrop.setText("");
                edtGrainAC.setText("");
                edtSilageAC.setText("");
                edtPHIGrainAC.setText("");
                edtPHISilageAC.setText("");
                edtGrainHybridValue1.setText("");
                edtGrainHybridValue2.setText("");
                edtGrainHybridValue3.setText("");
                edtGrainHybridValue4.setText("");
                edtSilageHybridValue1.setText("");
                edtSilageHybridValue2.setText("");
                edtSilageHybridValue3.setText("");
                edtSilageHybridValue4.setText("");
                spnGrainServices1.setText("");
                spnSilageServices1.setText("");
                spnGrainHybrid1.setSelection(0);
                spnGrainHybrid2.setSelection(0);
                spnGrainHybrid3.setSelection(0);
                spnGrainHybrid4.setSelection(0);
                spnSilageHybrid1.setSelection(0);
                spnSilageHybrid2.setSelection(0);
                spnSilageHybrid3.setSelection(0);
                spnSilageHybrid4.setSelection(0);
                edtCompetitorGrainPlan1.setText("");
                edtCompetitorGrainPlan2.setText("");
                edtCompetitorGrainPlan3.setText("");
                edtCompetitorGrainPlan4.setText("");
                edtCompetitorGrainPlanValue1.setText("");
                edtCompetitorGrainPlanValue2.setText("");
                edtCompetitorGrainPlanValue3.setText("");
                edtCompetitorGrainPlanValue4.setText("");
                edtCompetitorSilagePlan1.setText("");
                edtCompetitorSilagePlan2.setText("");
                edtCompetitorSilagePlanValue1.setText("");
                edtCompetitorSilagePlanValue2.setText("");
                radioGroup.clearCheck();

                //newly added kiran
                edtCompetitorGrainPlan5.setText("");
                edtCompetitorGrainPlanValue5.setText("");

                edtCompetitorSilagePlan3.setText("");
                edtCompetitorSilagePlan4.setText("");
                edtCompetitorSilagePlan5.setText("");
                edtCompetitorSilagePlanValue3.setText("");
                edtCompetitorSilagePlanValue4.setText("");
                edtCompetitorSilagePlanValue5.setText("");

            }
        } else {
            btnEdit.setEnabled(false);
            btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));

            spnDivision.setEnabled(true);
            spnYear.setEnabled(true);
            spnSchool.setEnabled(true);

            edtMobileNo.setEnabled(true);
            edtPincode.setEnabled(true);

            lnrFarmerDetails.setVisibility(View.GONE);
            lnrExpandFarmerDetails.setVisibility(View.GONE);

            btnGetDetails.setEnabled(true);
            btnGetDetails.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            profileImage.setImageResource(R.drawable.img_profile_avatar);
            uriStr = null;
            imagePath = null;
            edtFarmerName.setText("");
            edtDistrictName.setText("");
            edtBlockName.setText("");
            edtVillageName.setText("");
            edtCattleNestle.setText("");
            edtMilkNestle.setText("");

            radioGroupSilageFeeding.clearCheck();
            spnGrowing.setSelection(0);
            edtAcresGrow.setText("");
            edtHybridValue1.setText("");
            edtHybridValue2.setText("");
            edtHybridValue3.setText("");
            edtHybridValue4.setText("");
            edtHybridValue5.setText("");
            radioGroupPlant.clearCheck();
            radioGroupGrow.clearCheck();
            radioGroupHarvest.clearCheck();
            radioGroupStore.clearCheck();
            radioGroupFeed.clearCheck();
        }

    }

    private String checkFarmerDetailsValidation() {
        IdNameModel data = (IdNameModel) spnDivision.getTag();
        String name = data.getName();

        if (!Utility.isValidStr(imagePath) && !Utility.isValidStr(serverImagePath))
            return "Please capture farmer image";

        if (name.equalsIgnoreCase(MyConstants.FARMER_SEGMENTATION)) {
            if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {

                if (Utility.getText(edtFarmerName).isEmpty())
                    return getString(R.string.please_enter_farmer);

                if (Utility.getText(edtDistrictName).isEmpty())
                    return getString(R.string.please_enter_district);

                if (Utility.getText(edtBlockName).isEmpty())
                    return getString(R.string.please_enter_block);

                if (Utility.getText(edtVillageName).isEmpty())
                    return getString(R.string.please_enter_village);

                if (Utility.getText(edtPlanCrop).isEmpty())
                    return getString(R.string.please_enter_rice);

                if (Utility.getText(edtGrainAC).isEmpty())
                    return getString(R.string.please_enter_hybrid);

                if (spnIrrgiaTypes.getSelectedItemPosition() == 0)
                    return getString(R.string.please_select_irrg);

            } else {
                if (Utility.getText(edtFarmerName).isEmpty())
                    return getString(R.string.please_enter_farmer);

                if (Utility.getText(edtDistrictName).isEmpty())
                    return getString(R.string.please_enter_district);

                if (Utility.getText(edtBlockName).isEmpty())
                    return getString(R.string.please_enter_block);

                if (Utility.getText(edtVillageName).isEmpty())
                    return getString(R.string.please_enter_village);

                if (!Utility.isValidStr(edtPlanCrop.getText().toString()))
                    return getString(R.string.please_enter_plan);

                if (!Utility.isValidStr(edtGrainAC.getText().toString()))
                    return getString(R.string.please_enter_grain);

                if (!Utility.isValidStr(edtSilageAC.getText().toString()))
                    return getString(R.string.please_enter_silage);

                if (Double.parseDouble(edtPlanCrop.getText().toString().trim()) <= 0)
                    return "Please enter valid Total Plan Crop Acres";

                if (Double.parseDouble(edtGrainAC.getText().toString().trim()) <= 0 && Double.parseDouble(edtSilageAC.getText().toString().trim()) <= 0)
                    return "Please enter Grain or Silage Acres";
            }
        } else {
            if (Utility.getText(edtFarmerName).isEmpty())
                return getString(R.string.please_enter_farmer);

            if (Utility.getText(edtDistrictName).isEmpty())
                return getString(R.string.please_enter_district);

            if (Utility.getText(edtBlockName).isEmpty())
                return getString(R.string.please_enter_block);

            if (Utility.getText(edtVillageName).isEmpty())
                return getString(R.string.please_enter_village);

            if (Utility.getText(edtCattleNestle).isEmpty())
                return getString(R.string.please_enter_total_cattles);

            if (Utility.getText(edtMilkNestle).isEmpty())
                return getString(R.string.please_enter_average_milk);

        }
        return null;
    }

    private String checkValidation() {
//        if (spnDivision.getSelectedItem().toString().equalsIgnoreCase("Farmer Segmentation")) {
        if (spnDivision.getSelectedItemPosition() == 0) {
            if (spnYear.getSelectedItemPosition() <= 0)
                return getString(R.string.please_select_year);

            if (spnSeason.getSelectedItemPosition() <= 0)
                return getString(R.string.please_select_season);

            if (spnCrop.getSelectedItemPosition() <= 0)
                return getString(R.string.please_select_crop);

            if (Utility.getText(edtMobileNo).isEmpty() || Utility.getText(edtMobileNo).length() < 10)
                return getString(R.string.fs_mobile);

            if (Utility.getText(edtPincode).isEmpty() || Utility.getText(edtPincode).length() < 6)
                return getString(R.string.fs_pin_no);
        } else {
            if (spnYear.getSelectedItemPosition() <= 0)
                return getString(R.string.please_select_year);

            if (spnSchool.getSelectedItemPosition() <= 0)
                return getString(R.string.please_select_school);

            if (Utility.getText(edtMobileNo).isEmpty() || Utility.getText(edtMobileNo).length() < 10)
                return getString(R.string.fs_mobile);

            if (Utility.getText(edtPincode).isEmpty() || Utility.getText(edtPincode).length() < 6)
                return getString(R.string.fs_pin_no);
        }

        return null;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_clear) {
            clearFields();
            return super.onOptionsItemSelected(item);
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        if (isDataAvailable()) {
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }
        return true;
    }

    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(mActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", (dialog, which) -> showInstalledAppDetails(mActivity, mActivity.getPackageName()));

        builder.setNegativeButton("Cancel", (dialog, which) -> {
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {
        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", packageName, null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        mActivity.finish();
    }

    private void openOptionsDialog() {
        cameraPermission();
    }

    private void cameraPermission() {
        File newfile = createFile();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkPermission()) {
                if (!Utility.isValidStr(imagePath)) {
                    openCameraApp(newfile);
                } else {
                    showOptionOpenCameraforNewSurvey(mActivity, newfile);
                }
            }
        } else {
            if (!Utility.isValidStr(imagePath)) {
                openCameraApp(newfile);
            } else {
                showOptionOpenCameraforNewSurvey(mActivity, newfile);
            }
        }
    }

    private File createFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + File.separator + "FarmerSegmentation");
        if (!myDir.exists())
            myDir.mkdirs();

        File newfile = new File(myDir, "IMG_" + System.currentTimeMillis() + ".JPG");
        try {
            newfile.createNewFile();
        } catch (IOException ignored) {
        }
        return newfile;
    }

    public void openCameraApp(File newfile) {
        Uri outputFileUri = Uri.fromFile(newfile);
        Intent intent = new Intent(mActivity, MainActivityOC.class);
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE); // without this not working, not getting data only
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        startActivityForResult(intent, OPENCAMERA);
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(mActivity, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new androidx.appcompat.app.AlertDialog.Builder(mActivity)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", (dialogInterface, i) -> {
                            //Prompt the user once explanation has been shown
                            ActivityCompat.requestPermissions(mActivity,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                    MY_PERMISSIONS_REQUEST_LOCATION);
                        })
                        .create()
                        .show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.CAMERA) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));

            } else {
                // No explanation needed, we can request the permission.
                if (Utility.isFirstTimeCamera(mActivity)) {

                    DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            Utility.setFirstTimeCamera(false, mActivity);
                            ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));


                } else {
                    ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }
        return false;
    }


    private void showOptionOpenCameraforNewSurvey(final FragmentActivity context,
                                                  final File newfile) {
        final Dialog mDialog;
        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.paravakta_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mREmovePhoto, mViewPhoto;
        Button mCancel;
        mFromCamera = mDialog.findViewById(R.id.from_camera);
        mREmovePhoto = mDialog.findViewById(R.id.remove_photo);
        mViewPhoto = mDialog.findViewById(R.id.view_image);
        mCancel = mDialog.findViewById(R.id.cancel);

        mFromCamera.setOnClickListener(v -> {
            mDialog.dismiss();
            openCameraApp(newfile);
        });
        mREmovePhoto.setOnClickListener(v -> {
            mDialog.dismiss();
            profileImage.setImageResource(R.drawable.img_profile_avatar);
            uriStr = null;
            imagePath = null;
        });

        mViewPhoto.setOnClickListener(view -> {
            mDialog.dismiss();
            if (profileImage.getDrawable() != null) {
                if (uriStr != null) {
                    ImageViewer(mActivity, uriStr.toString());
                }
            }
        });
        mCancel.setOnClickListener(v -> mDialog.dismiss());
        mDialog.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        ExecutorService mExecutor;
        if (requestCode == OPENCAMERA) {
            if (resultCode == RESULT_OK) {
                try {
                    mExecutor = Executors.newSingleThreadExecutor();
                    Uri myUri = (Uri) data.getExtras().get("data");
                    uriStr = myUri;
                    mExecutor.submit(new LoadScaledImageTask(mActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                    imagePath = myUri.toString();
                } catch (Exception ignore) {

                }
            } else if (resultCode == RESULT_CANCELED) {
                DialogManager.showToast(mActivity, getString(R.string.user_cancelled_image_capture));
            } else {
                DialogManager.showToast(mActivity, getString(R.string.failed_to_capture_image));
            }
        } else if (requestCode == REQUEST_CODE_FOR_IMAGE_CROPPING) {
            if (resultCode == RESULT_OK) {
                mExecutor = Executors.newSingleThreadExecutor();
                Uri myUri = data.getData();
                uriStr = myUri;
                mExecutor.submit(new LoadScaledImageTask(mActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                imagePath = myUri.toString();
            } else if (resultCode == RESULT_CANCELED) {
                DialogManager.showToast(mActivity, getString(R.string.at_user_cancelled_image_cropping));
            }
        }
    }

    private int calcImageSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        Display display = mActivity.getWindowManager().getDefaultDisplay();
        display.getMetrics(metrics);
        return Math.min(Math.max(metrics.widthPixels, metrics.heightPixels), 2048);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            //ProfileImageSelectionUtil.showOption(null, mActivity);
                            openCameraApp(newfile);
                        else
                            checkPermission();
                    } else {
                        openCameraApp(newfile);
                        //ProfileImageSelectionUtil.showOption(null, mActivity);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
            break;
            case REQUEST_CAMERA_PERMISSION_DENAIL: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            openCameraApp(newfile);
                        else
                            showDialogToOpenSetting();
                    } else {
                        openCameraApp(newfile);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    showDialogToOpenSetting();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
            break;

            // other 'case' lines to check for other
            // permissions this app might request
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(mActivity,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient != null) {
                            mGoogleApiClient.connect();
                        } else {
                            buildGoogleApiClient();
                            mGoogleApiClient.connect();
                        }
                    }
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(mActivity, "permission denied", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override
    public void onRequestSuccess(Object responseObj) {
        if (responseObj != null && isAdded()) {
            if (responseObj instanceof FarmerSegmentationResponse) {
                FarmerSegmentationResponse response = (FarmerSegmentationResponse) responseObj;
                if (response.getCode() == 100) {
                    if (Utility.isValidStr(response.getMessage())) {
                        DialogManager.showSingleBtnPopup(mActivity, null, "Alert!", response.getMessage(), "OK");
                    }
                    setServiceData(response);
                } else {
                    String severMsg = response.getMessage();
                    if (Utility.isValidStr(severMsg))
                        DialogManager.showToast(mActivity, severMsg);
                }
            } else if (responseObj instanceof FarmerSegmentationNestleResponse) {
                FarmerSegmentationNestleResponse responseNestle = (FarmerSegmentationNestleResponse) responseObj;
                if (responseNestle.getCode() == 100) {
                    if (Utility.isValidStr(responseNestle.getMessage())) {
                        DialogManager.showSingleBtnPopup(mActivity, null, "Alert!", responseNestle.getMessage(), "OK");
                    }
                    setNestleServiceData(responseNestle);
                } else {
                    String severMsg = responseNestle.getMessage();
                    if (Utility.isValidStr(severMsg))
                        DialogManager.showToast(mActivity, severMsg);
                }
            }
        }
    }

    private void setNestleServiceData(FarmerSegmentationNestleResponse responseNestle) {
        dtoNestle = responseNestle.getFarmerSegmentationDairyDevResponse();
        setNestleViewData();
        if (Utility.isValidStr(dtoNestle.getServerImagePath())) {
            serverImagePath = dtoNestle.getServerImagePath();
            Glide.with(mActivity)
                    .load(dtoNestle.getServerImagePath())
                    .error(R.drawable.img_profile_avatar)
                    .placeholder(R.drawable.img_profile_avatar)
                    .dontAnimate().into(profileImage);
        }

        if (Utility.isValidStr(dtoNestle.getFarmerName())) {
            edtFarmerName.setText(dtoNestle.getFarmerName());
        }
        if (Utility.isValidStr(dtoNestle.getDistrictName())) {
            edtDistrictName.setText(dtoNestle.getDistrictName());
            edtDistrictName.setEnabled(false);
        }
        if (Utility.isValidStr(dtoNestle.getBlockName())) {
            edtBlockName.setText(dtoNestle.getBlockName());
            edtBlockName.setEnabled(false);
        }
        if (Utility.isValidStr(dtoNestle.getVillageName())) {
            edtVillageName.setText(dtoNestle.getVillageName());
        }
        if (dtoNestle.getTotalNumberCattles() > 0) {
            edtCattleNestle.setText(String.valueOf(dtoNestle.getTotalNumberCattles()));
        }
        if (dtoNestle.getAverageMilkYield() > 0) {
            edtMilkNestle.setText(String.valueOf(dtoNestle.getAverageMilkYield()));
        }
    }

    private void setNestleViewData() {
        btnEdit.setEnabled(true);
        btnEdit.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        btnGetDetails.setEnabled(false);
        btnGetDetails.setBackgroundColor(getResources().getColor(R.color.drak_grey));
        lnrFarmerDetails.setVisibility(View.VISIBLE);
        lnrExpandFarmerDetails.setVisibility(View.VISIBLE);

        spnDivision.setEnabled(false);
        spnYear.setEnabled(false);
        spnSchool.setEnabled(false);

        edtMobileNo.setEnabled(false);
        edtPincode.setEnabled(false);
        edtDistrictName.setEnabled(true);
        edtBlockName.setEnabled(true);
        edtFarmerName.setEnabled(true);
        edtVillageName.setEnabled(true);
        edtCattleNestle.setEnabled(true);
        edtMilkNestle.setEnabled(true);

        lnrGrainAC.setVisibility(View.GONE);
        lnrSilageAC.setVisibility(View.GONE);
        lnrPlanCrops.setVisibility(View.GONE);
        lnrcattleNestle.setVisibility(View.VISIBLE);
        lnrMilkNestle.setVisibility(View.VISIBLE);

        lnrTypeIrrgiation.setVisibility(View.GONE);
        btnProceedNext.setEnabled(true);
        btnProceedNext.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

        lnrFeedbackBody.setVisibility(View.GONE);
        lnrfeedbackHeader.setVisibility(View.GONE);
        lnrFeedbackYesLL.setVisibility(View.GONE);
        feedbackRadioGrp.check(-1);
    }

    private void setViewData() {

        IdNameModel data = (IdNameModel) spnCrop.getTag();
        IdNameModel dataSeason = (IdNameModel) spnSeason.getTag();
        IdNameModel dataYear = (IdNameModel) spnYear.getTag();

        Log.e("spinner items", data.getName() + "," + dataSeason.getName());
        // String selectedSpinner = data.getName();
        //IdNameModel selectModel = (IdNameModel) cropAdapter.getItem(spnCrop.getSelectedItemPosition());
        if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {

            btnEdit.setEnabled(true);
            btnEdit.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            btnGetDetails.setEnabled(false);
            btnGetDetails.setBackgroundColor(getResources().getColor(R.color.drak_grey));
            lnrFarmerDetails.setVisibility(View.VISIBLE);
            lnrExpandFarmerDetails.setVisibility(View.VISIBLE);
            imgFarmerDetails.setBackgroundResource(R.drawable.dropdown_down);
            spnDivision.setEnabled(false);
            spnYear.setEnabled(false);
            spnSeason.setEnabled(false);
            spnCrop.setEnabled(false);

            lnrPlanCrops.setVisibility(View.VISIBLE);
            txtTotalCrop.setText("Total " + data.getName() + " Acres");

            lnrGrainAC.setVisibility(View.VISIBLE);
            txtHybridRice.setText("Hybrid " + data.getName() + " Acres");

            lnrSilageAC.setVisibility(View.GONE);
            lnrcattleNestle.setVisibility(View.GONE);
            lnrMilkNestle.setVisibility(View.GONE);

            edtMobileNo.setEnabled(false);
            edtPincode.setEnabled(false);
            edtDistrictName.setEnabled(true);
            edtBlockName.setEnabled(true);
            edtFarmerName.setEnabled(true);
            edtVillageName.setEnabled(true);

            edtPlanCrop.setEnabled(true);
            edtGrainAC.setEnabled(true);
            lnrTypeIrrgiation.setVisibility(View.VISIBLE);

            btnProceedNext.setEnabled(true);
            btnProceedNext.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

            lnrfeedbackHeader.setVisibility(View.GONE);
            lnrFeedbackBody.setVisibility(View.GONE);
            lnrFeedbackYesLL.setVisibility(View.GONE);
            feedbackRadioGrp.check(-1);
        } else {
            btnEdit.setEnabled(true);
            btnEdit.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            btnGetDetails.setEnabled(false);
            btnGetDetails.setBackgroundColor(getResources().getColor(R.color.drak_grey));

            lnrFarmerDetails.setVisibility(View.VISIBLE);
            lnrExpandFarmerDetails.setVisibility(View.VISIBLE);
            imgFarmerDetails.setBackgroundResource(R.drawable.dropdown_down);

            spnDivision.setEnabled(false);
            spnYear.setEnabled(false);
            spnSeason.setEnabled(false);
            spnCrop.setEnabled(false);

            edtMobileNo.setEnabled(false);
            edtPincode.setEnabled(false);
            edtDistrictName.setEnabled(true);
            edtBlockName.setEnabled(true);
            edtFarmerName.setEnabled(true);
            edtVillageName.setEnabled(true);
            edtPlanCrop.setEnabled(true);
            edtGrainAC.setEnabled(true);
            edtSilageAC.setEnabled(true);
            lnrcattleNestle.setVisibility(View.GONE);
            lnrMilkNestle.setVisibility(View.GONE);
            lnrTypeIrrgiation.setVisibility(View.GONE);
            btnProceedNext.setEnabled(true);
            btnProceedNext.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

            lnrPlanCrops.setVisibility(View.VISIBLE);
            lnrGrainAC.setVisibility(View.VISIBLE);
            lnrSilageAC.setVisibility(View.VISIBLE);

            if (data.getName().equalsIgnoreCase(MyConstants.CORN) && dataSeason.getName().equalsIgnoreCase(MyConstants.SPRING)) {
                txtTotalCrop.setHeight(50);
                txtTotalCrop.setText("Total " + dataSeason.getName() + " " + data.getName() + " Acres " + dataYear.getName());
                txtHybridRice.setText("Grain Acres " + dataYear.getName());
                txtSilageCrop.setText("Silage Acres " + dataYear.getName());
            } else {
                txtTotalCrop.setText("Plan Total " + data.getName() + " Acres");
                txtHybridRice.setText(getString(R.string.plan_grain));
                txtSilageCrop.setText(getString(R.string.plan_silage));
            }
            lnrfeedbackHeader.setVisibility(View.VISIBLE);
            lnrFeedbackBody.setVisibility(View.VISIBLE);
        }
    }

    private void setServiceData(FarmerSegmentationResponse response) {
        dto = response.getFarmerSegmentationResponse();
        setViewData();
        if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
            if (Utility.isValidStr(dto.getServerImagePath())) {
                serverImagePath = dto.getServerImagePath();
                Glide.with(mActivity)
                        .load(dto.getServerImagePath())
                        .error(R.drawable.img_profile_avatar)
                        .placeholder(R.drawable.img_profile_avatar)
                        .dontAnimate().into(profileImage);
            }
            if (Utility.isValidStr(dto.getFarmerName())) {
                edtFarmerName.setText(dto.getFarmerName());
            }
            if (Utility.isValidStr(dto.getDistrictName())) {
                edtDistrictName.setText(dto.getDistrictName());
                edtDistrictName.setEnabled(false);
            }
            if (Utility.isValidStr(dto.getBlockName())) {
                edtBlockName.setText(dto.getBlockName());
                edtBlockName.setEnabled(false);
            }
            if (Utility.isValidStr(dto.getVillageName())) {
                edtVillageName.setText(dto.getVillageName());
            }
            if (dto.getPlanTotalCropAcres() > 0) {
                edtPlanCrop.setText(String.valueOf(dto.getPlanTotalCropAcres()));
            }
            if (dto.getHybridAc() > 0) {
                edtGrainAC.setText(String.valueOf(dto.getHybridAc()));
            }

            String[] typesIrrgaitionArray = getResources().getStringArray(R.array.types_irrigation);
            if (dto.getTypeOfIrrigation() != null) {
                for (int i = 0; i < typesIrrgaitionArray.length; i++) {
                    if (typesIrrgaitionArray[i].equalsIgnoreCase(dto.getTypeOfIrrigation()))
                        spnIrrgiaTypes.setSelection(i);
                }
            }
        } else {
            if (Utility.isValidStr(dto.getServerImagePath())) {
                serverImagePath = dto.getServerImagePath();
                Glide.with(mActivity)
                        .load(dto.getServerImagePath())
                        .error(R.drawable.img_profile_avatar)
                        .placeholder(R.drawable.img_profile_avatar)
                        .dontAnimate().into(profileImage);
            }

            if (Utility.isValidStr(dto.getFarmerName())) {
                edtFarmerName.setText(dto.getFarmerName());
            }
            if (Utility.isValidStr(dto.getDistrictName())) {
                edtDistrictName.setText(dto.getDistrictName());
                edtDistrictName.setEnabled(false);
            }
            if (Utility.isValidStr(dto.getBlockName())) {
                edtBlockName.setText(dto.getBlockName());
                edtBlockName.setEnabled(false);
            }
            if (Utility.isValidStr(dto.getVillageName())) {
                edtVillageName.setText(dto.getVillageName());
            }
            if (dto.getPlanTotalCropAcres() > 0) {
                edtPlanCrop.setText(String.valueOf(dto.getPlanTotalCropAcres()));
            }
            if (dto.getPlanGrainAcres() > 0)
                edtGrainAC.setText(String.valueOf(dto.getPlanGrainAcres()));

            if (dto.getPlanSilageAcres() > 0)
                edtSilageAC.setText(String.valueOf(dto.getPlanSilageAcres()));
        }
    }

    @Override
    public void onRequestFailure(RetrofitError errorCode) {
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        int i = buttonView.getId();
        if (i == R.id.cb_shelling) {

        } else if (i == R.id.cb_grain_weight) {

        } else if (i == R.id.cb_earliness) {

        } else if (i == R.id.cb_grain_moisture) {

        } else if (i == R.id.cb_standability) {

        }
    }

    public static class LoadScaledImageTask implements Runnable {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        Context context;
        Uri uri;
        ImageView imageView;
        int width;

        public LoadScaledImageTask(Context context, Uri uri, ImageView imageView, int width) {
            this.context = context;
            this.uri = uri;
            this.imageView = imageView;
            this.width = width;
        }

        @Override
        public void run() {
            final int exifRotation = com.isseiaoki.simplecropview.util.Utils.getExifOrientation(context, uri);
            int maxSize = com.isseiaoki.simplecropview.util.Utils.getMaxSize();
            int requestSize = Math.min(width, maxSize);
            try {
                final Bitmap sampledBitmap = com.isseiaoki.simplecropview.util.Utils.decodeSampledBitmapFromUri(context, uri, requestSize);
                mHandler.post(() -> {
                    imageView.setImageMatrix(com.isseiaoki.simplecropview.util.Utils.getMatrixFromExifOrientation(exifRotation));
                    imageView.setImageBitmap(sampledBitmap);
                });
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private MultiSpinner.MultiSpinnerListener onSelectedListener = new MultiSpinner.MultiSpinnerListener() {
        public void onItemsSelected(boolean[] selected) {
            // Do something here with the selected items
            List<IdNameModel> selectedGrainServicesList = new ArrayList<>();
            StringBuilder builder = new StringBuilder();
            selectedGrainServicesList.clear();
            for (int i = 0; i < selected.length; i++) {
                if (selected[i]) {
                    if (builder.length() != 0) {
                        builder.append(",");
                    }
                    builder.append(grainServicesAdapter.getItem(i));
                    selectedGrainServicesList.add(originalGrainServicesList.get(i));
                }
            }
            String valueForGrainServicesSpinner = builder.toString();
            spnGrainServices1.setText(valueForGrainServicesSpinner);
        }
    };

    private MultiSpinner.MultiSpinnerListener onSilageSelectedListener = new MultiSpinner.MultiSpinnerListener() {
        public void onItemsSelected(boolean[] selected) {
            // Do something here with the selected items
            List<IdNameModel> selectedSilageServicesList = new ArrayList<>();
            StringBuilder builder = new StringBuilder();
            selectedSilageServicesList.clear();
            for (int i = 0; i < selected.length; i++) {
                if (selected[i]) {
                    if (builder.length() != 0) {
                        builder.append(",");
                    }
                    builder.append(silageServicesAdapter.getItem(i));
                    selectedSilageServicesList.add(originalSilageServicesList.get(i));
                }
            }
            String valueForSilageServicesSpinner = builder.toString();
            spnSilageServices1.setText(valueForSilageServicesSpinner);
        }
    };
    private MultiSpinner.MultiSpinnerListener onRiceSelectedListener = new MultiSpinner.MultiSpinnerListener() {
        public void onItemsSelected(boolean[] selected) {
            // Do something here with the selected items

            List<IdNameModel> selectedRiceServicesList = new ArrayList<>();
            StringBuilder builder = new StringBuilder();
            selectedRiceServicesList.clear();
            for (int i = 0; i < selected.length; i++) {
                if (selected[i]) {
                    if (builder.length() != 0) {
                        builder.append(",");
                    }
                    builder.append(riceServicesAdapter.getItem(i));
                    selectedRiceServicesList.add(originalRiceServicesList.get(i));
                }
            }
            String valueForRiceServicesSpinner = builder.toString();
            spnGrainServices1.setText(valueForRiceServicesSpinner);
        }
    };

    @Override
    public void onDestroy() {
        checkForLocation = true;
        location = null;
        super.onDestroy();
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), (dialog, which) -> {
            saveData();
            clearFields();
            DialogManager.showToast(mActivity, "Successfully saved data in Offline, Please go to 'DATA SYNC' and  tap on 'DATA UPLOAD' to Submit.");
        });

        builder.setNegativeButton(getResources().getString(R.string.no), (dialog, which) -> {
        });
        builder.create().show();
    }

    private void clearFields() {
        spnDivision.setSelection(0);
        spnCrop.setSelection(0);
        spnYear.setSelection(0);
        spnSeason.setSelection(0);
        edtMobileNo.setText("");
        edtPincode.setText("");
        profileImage.setImageResource(R.drawable.img_profile_avatar);
        uriStr = null;
        imagePath = null;
        edtFarmerName.setText("");
        edtDistrictName.setText("");
        edtBlockName.setText("");
        edtVillageName.setText("");
        edtPlanCrop.setText("");
        edtGrainAC.setText("");
        edtSilageAC.setText("");

        edtPHIGrainAC.setText("");
        edtPHISilageAC.setText("");
        edtGrainHybridValue1.setText("");
        edtGrainHybridValue2.setText("");
        edtGrainHybridValue3.setText("");
        edtGrainHybridValue4.setText("");
        edtSilageHybridValue1.setText("");
        edtSilageHybridValue2.setText("");
        edtSilageHybridValue3.setText("");
        edtSilageHybridValue4.setText("");
        spnGrainServices1.setText("");
        spnSilageServices1.setText("");
        spnGrainHybrid1.setSelection(0);
        spnGrainHybrid2.setSelection(0);
        spnGrainHybrid3.setSelection(0);
        spnGrainHybrid4.setSelection(0);
        spnSilageHybrid1.setSelection(0);
        spnSilageHybrid2.setSelection(0);
        spnSilageHybrid3.setSelection(0);
        spnSilageHybrid4.setSelection(0);
        edtCompetitorGrainPlan1.setText("");
        edtCompetitorGrainPlan2.setText("");
        edtCompetitorGrainPlan3.setText("");
        edtCompetitorGrainPlan4.setText("");
        edtCompetitorGrainPlanValue1.setText("");
        edtCompetitorGrainPlanValue2.setText("");
        edtCompetitorGrainPlanValue3.setText("");
        edtCompetitorGrainPlanValue4.setText("");
        edtCompetitorSilagePlan1.setText("");
        edtCompetitorSilagePlan2.setText("");
        edtCompetitorSilagePlanValue1.setText("");
        edtCompetitorSilagePlanValue2.setText("");

        edtCompetitorSilagePlan3.setText("");
        edtCompetitorSilagePlan4.setText("");
        edtCompetitorSilagePlan5.setText("");
        edtCompetitorSilagePlanValue3.setText("");
        edtCompetitorSilagePlanValue4.setText("");
        edtCompetitorSilagePlanValue5.setText("");

        edtCompetitorGrainPlan5.setText("");
        edtCompetitorGrainPlanValue5.setText("");

        radioGroup.clearCheck();
        btnEdit.setEnabled(false);
        btnEdit.setBackgroundColor(getResources().getColor(R.color.drak_grey));
        spnDivision.setEnabled(true);
        spnYear.setEnabled(true);
        spnSeason.setEnabled(true);
        spnCrop.setEnabled(true);
        edtMobileNo.setEnabled(true);
        edtPincode.setEnabled(true);
        btnGetDetails.setEnabled(true);
        btnGetDetails.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        checkForLocation = true;
        location = null;
        grainHybrid1name = "";
        grainHybrid2name = "";
        grainHybrid3name = "";
        grainHybrid4name = "";
        silageHybrid1name = "";
        silageHybrid2name = "";
        silageHybrid3name = "";
        silageHybrid4name = "";

        //Rice
        edtMaturity124Acr.setText("");
        edtMaturity134Acr.setText("");
        edtMaturity135Acr.setText("");
        spnIrrgiaTypes.setSelection(0);
        radioGroupSowingRice.clearCheck();

        // Nestle
        spnSchool.setSelection(0);
        edtCattleNestle.setText("");
        edtMilkNestle.setText("");
        spnSchool.setEnabled(true);
        radioGroupSilageFeeding.clearCheck();
        spnGrowing.setSelection(0);
        edtAcresGrow.setText("");
        edtHybridValue1.setText("");
        edtHybridValue2.setText("");
        edtHybridValue3.setText("");
        edtHybridValue4.setText("");
        edtHybridValue5.setText("");
        radioGroupPlant.clearCheck();
        radioGroupGrow.clearCheck();
        radioGroupHarvest.clearCheck();
        radioGroupStore.clearCheck();
        radioGroupFeed.clearCheck();

        serverImagePath = null;

        lnrFarmerDetails.setVisibility(View.GONE);
        lnrExpandFarmerDetails.setVisibility(View.GONE);

        //Farmer Segmentation
        lnrCornLayout.setVisibility(View.GONE);

        // //Nestle Layout
        lnrLayoutHeading.setVisibility(View.GONE);
        lnrFeedbackBody.setVisibility(View.GONE);
        lnrfeedbackHeader.setVisibility(View.GONE);
        btnSubmit.setVisibility(View.GONE);
        lnrFeedbackYesLL.setVisibility(View.GONE);
        feedbackRadioGrp.check(-1);
    }

    private void saveData() {
        IdNameModel data = (IdNameModel) spnDivision.getTag();
        String name = data.getName();
        SegmentationRequestDTO dto = new SegmentationRequestDTO();
        if (name.equalsIgnoreCase(MyConstants.FARMER_SEGMENTATION)) {
            if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                IdNameModel yearData = (IdNameModel) spnYear.getTag();
                IdNameModel seasonData = (IdNameModel) spnSeason.getTag();
                IdNameModel cropData = (IdNameModel) spnCrop.getTag();
                dto.setYear(yearData.getName());
                dto.setSeason(seasonData.getId());
                dto.setCrop(cropData.getId());
                dto.setMobileNo(edtMobileNo.getText().toString());
                dto.setPincode(edtPincode.getText().toString());
                dto.setLocalImagePath(imagePath);
                dto.setFarmerName(edtFarmerName.getText().toString());
                dto.setDistrict(edtDistrictName.getText().toString());
                dto.setBlock(edtBlockName.getText().toString());
                dto.setVillage(edtVillageName.getText().toString());
                dto.setTotalPlanAc(Float.parseFloat(edtPlanCrop.getText().toString()));

                //newly added for rice
                dto.setHybridAc(Float.parseFloat(edtGrainAC.getText().toString()));
                dto.setTypeOfIrrigation(spinnerString(spnIrrgiaTypes));
                dto.setMaturity124Ac(Float.parseFloat(edtMaturity124Acr.getText().toString()));
                dto.setMaturity134Ac(Float.parseFloat(edtMaturity134Acr.getText().toString()));
                dto.setMaturity135Ac(Float.parseFloat(edtMaturity135Acr.getText().toString()));

                //pioneer commit
                if (spinnerString(spnGrainHybrid1).equalsIgnoreCase(MyConstants.SelectHybrid1))
                    dto.setRiceHybrid1(null);
                else
                    dto.setRiceHybrid1(spinnerString(spnGrainHybrid1));

                if (spinnerString(spnGrainHybrid2).equalsIgnoreCase(MyConstants.SelectHybrid2))
                    dto.setRiceHybrid2(null);
                else
                    dto.setRiceHybrid2(spinnerString(spnGrainHybrid2));

                if (spinnerString(spnGrainHybrid3).equalsIgnoreCase(MyConstants.SelectHybrid3))
                    dto.setRiceHybrid3(null);
                else
                    dto.setRiceHybrid3(spinnerString(spnGrainHybrid3));

                if (spinnerString(spnGrainHybrid4).equalsIgnoreCase(MyConstants.SelectHybrid4))
                    dto.setRiceHybrid4(null);
                else
                    dto.setRiceHybrid4(spinnerString(spnGrainHybrid4));


                if (Utility.isValidStr(edtGrainHybridValue1.getText().toString()))
                    dto.setRiceHybridValue1(Float.parseFloat(edtGrainHybridValue1.getText().toString()));
                else
                    dto.setRiceHybridValue1(0);

                if (Utility.isValidStr(edtGrainHybridValue2.getText().toString()))
                    dto.setRiceHybridValue2(Float.parseFloat(edtGrainHybridValue2.getText().toString()));
                else
                    dto.setRiceHybridValue2(0);

                if (Utility.isValidStr(edtGrainHybridValue3.getText().toString()))
                    dto.setRiceHybridValue3(Float.parseFloat(edtGrainHybridValue3.getText().toString()));
                else
                    dto.setRiceHybridValue3(0);

                if (Utility.isValidStr(edtGrainHybridValue4.getText().toString()))
                    dto.setRiceHybridValue4(Float.parseFloat(edtGrainHybridValue4.getText().toString()));
                else
                    dto.setRiceHybridValue4(0);

                dto.setRiceCompetitorHybrid1(edtCompetitorGrainPlan1.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan1.getText().toString().trim());
                dto.setRiceCompetitorHybrid2(edtCompetitorGrainPlan2.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan2.getText().toString().trim());
                dto.setRiceCompetitorHybrid3(edtCompetitorGrainPlan3.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan3.getText().toString().trim());
                dto.setRiceCompetitorHybrid4(edtCompetitorGrainPlan4.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan4.getText().toString().trim());

                if (Utility.isValidStr(edtCompetitorGrainPlanValue1.getText().toString()))
                    dto.setRiceCompetitorHybridValue1(Float.parseFloat(edtCompetitorGrainPlanValue1.getText().toString()));
                else
                    dto.setRiceCompetitorHybridValue1(0);

                if (Utility.isValidStr(edtCompetitorGrainPlanValue2.getText().toString()))
                    dto.setRiceCompetitorHybridValue2(Float.parseFloat(edtCompetitorGrainPlanValue2.getText().toString()));
                else
                    dto.setRiceCompetitorHybridValue2(0);

                if (Utility.isValidStr(edtCompetitorGrainPlanValue3.getText().toString()))
                    dto.setRiceCompetitorHybridValue3(Float.parseFloat(edtCompetitorGrainPlanValue3.getText().toString()));
                else
                    dto.setRiceCompetitorHybridValue3(0);

                if (Utility.isValidStr(edtCompetitorGrainPlanValue4.getText().toString()))
                    dto.setRiceCompetitorHybridValue4(Float.parseFloat(edtCompetitorGrainPlanValue4.getText().toString()));
                else
                    dto.setRiceCompetitorHybridValue4(0);


                if (radioGroupSowingRice.getCheckedRadioButtonId() == R.id.radio_yes_sowing_rice) {
                    dto.setDirectSowingRice("Yes");
                } else {
                    dto.setDirectSowingRice("No");
                }

                if (radioGroup.getCheckedRadioButtonId() == R.id.radio_yes) {
                    dto.setIsTBL("Yes");
                } else {
                    dto.setIsTBL("No");
                }
                dto.setRiceServices(spnGrainServices1.getText().toString());

                dto.setGeoLocation(latLongValues);
                dto.setDate(Utility.getCurrentDateAndTime());
                dto.setIsSync(1);

                FarmerSegmentationRiceDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getWritableDatabase());
            } else {
                IdNameModel yearData = (IdNameModel) spnYear.getTag();
                IdNameModel seasonData = (IdNameModel) spnSeason.getTag();
                IdNameModel cropData = (IdNameModel) spnCrop.getTag();
                dto.setYear(yearData.getName());
                dto.setSeason(seasonData.getId());
                dto.setCrop(cropData.getId());
                dto.setMobileNo(edtMobileNo.getText().toString());
                dto.setPincode(edtPincode.getText().toString());
                dto.setLocalImagePath(imagePath);
                dto.setFarmerName(edtFarmerName.getText().toString());
                dto.setDistrict(edtDistrictName.getText().toString());
                dto.setBlock(edtBlockName.getText().toString());
                dto.setVillage(edtVillageName.getText().toString());
                dto.setTotalPlanAc(Float.parseFloat(edtPlanCrop.getText().toString()));
                dto.setPlanGrainAc(Float.parseFloat(edtGrainAC.getText().toString()));
                dto.setPlansilageAc(Float.parseFloat(edtSilageAC.getText().toString()));
                dto.setPhiGrainAc(Float.parseFloat(edtPHIGrainAC.getText().toString()));
                dto.setPhiSilageAc(Float.parseFloat(edtPHISilageAC.getText().toString()));

                if (Double.parseDouble(edtPHIGrainAC.getText().toString().trim()) > 0) {
                    // Grain Hybrid Labels
                    if (spinnerString(spnGrainHybrid1).equalsIgnoreCase(MyConstants.SelectHybrid1))
                        dto.setGrainHybrid1(null);
                    else
                        dto.setGrainHybrid1(spinnerString(spnGrainHybrid1));
                    if (spinnerString(spnGrainHybrid2).equalsIgnoreCase(MyConstants.SelectHybrid2))
                        dto.setGrainHybrid2(null);
                    else
                        dto.setGrainHybrid2(spinnerString(spnGrainHybrid2));
                    if (spinnerString(spnGrainHybrid3).equalsIgnoreCase(MyConstants.SelectHybrid3))
                        dto.setGrainHybrid3(null);
                    else
                        dto.setGrainHybrid3(spinnerString(spnGrainHybrid3));
                    if (spinnerString(spnGrainHybrid4).equalsIgnoreCase(MyConstants.SelectHybrid4))
                        dto.setGrainHybrid4(null);
                    else
                        dto.setGrainHybrid4(spinnerString(spnGrainHybrid4));

                    // Grain Hybrid Values
                    if (Utility.isValidStr(edtGrainHybridValue1.getText().toString()))
                        dto.setGrainHybridValue1(Float.parseFloat(edtGrainHybridValue1.getText().toString()));
                    else
                        dto.setGrainHybridValue1(0);
                    if (Utility.isValidStr(edtGrainHybridValue2.getText().toString()))
                        dto.setGrainHybridValue2(Float.parseFloat(edtGrainHybridValue2.getText().toString()));
                    else
                        dto.setGrainHybridValue2(0);
                    if (Utility.isValidStr(edtGrainHybridValue3.getText().toString()))
                        dto.setGrainHybridValue3(Float.parseFloat(edtGrainHybridValue3.getText().toString()));
                    else
                        dto.setGrainHybridValue3(0);
                    if (Utility.isValidStr(edtGrainHybridValue4.getText().toString()))
                        dto.setGrainHybridValue4(Float.parseFloat(edtGrainHybridValue4.getText().toString()));
                    else
                        dto.setGrainHybridValue4(0);
                }

                if (Double.parseDouble(edtPHISilageAC.getText().toString().trim()) > 0) {
                    // Silage Hybrid Labels
                    if (spinnerString(spnSilageHybrid1).equalsIgnoreCase(MyConstants.SelectSilageHybrid1))
                        dto.setSilageHybrid1(null);
                    else
                        dto.setSilageHybrid1(spinnerString(spnSilageHybrid1));
                    if (spinnerString(spnSilageHybrid2).equalsIgnoreCase(MyConstants.SelectSilageHybrid2))
                        dto.setSilageHybrid2(null);
                    else
                        dto.setSilageHybrid2(spinnerString(spnSilageHybrid2));

                    if (spinnerString(spnSilageHybrid3).equalsIgnoreCase(MyConstants.SelectSilageHybrid3))
                        dto.setSilageHybrid3(null);
                    else
                        dto.setSilageHybrid3(spinnerString(spnSilageHybrid3));

                    if (spinnerString(spnSilageHybrid4).equalsIgnoreCase(MyConstants.SelectSilageHybrid4))
                        dto.setSilageHybrid4(null);
                    else
                        dto.setSilageHybrid4(spinnerString(spnSilageHybrid4));

                    // Silage Hybrid Values
                    if (Utility.isValidStr(edtSilageHybridValue1.getText().toString()))
                        dto.setSilageHybridValue1(Float.parseFloat(edtSilageHybridValue1.getText().toString()));
                    else
                        dto.setSilageHybridValue1(0);
                    if (Utility.isValidStr(edtSilageHybridValue2.getText().toString()))
                        dto.setSilageHybridValue2(Float.parseFloat(edtSilageHybridValue2.getText().toString()));
                    else
                        dto.setSilageHybridValue2(0);

                    if (Utility.isValidStr(edtSilageHybridValue3.getText().toString()))
                        dto.setSilageHybridValue3(Float.parseFloat(edtSilageHybridValue3.getText().toString()));
                    else
                        dto.setSilageHybridValue3(0);

                    if (Utility.isValidStr(edtSilageHybridValue4.getText().toString()))
                        dto.setSilageHybridValue4(Float.parseFloat(edtSilageHybridValue4.getText().toString()));
                    else
                        dto.setSilageHybridValue4(0);
                }

                // Grain Compititor lables
                dto.setGrainCompetitorHybrid1(edtCompetitorGrainPlan1.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan1.getText().toString().trim());
                dto.setGrainCompetitorHybrid2(edtCompetitorGrainPlan2.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan2.getText().toString().trim());
                dto.setGrainCompetitorHybrid3(edtCompetitorGrainPlan3.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan3.getText().toString().trim());
                dto.setGrainCompetitorHybrid4(edtCompetitorGrainPlan4.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan4.getText().toString().trim());
                dto.setGrainCompetitorHybrid5(edtCompetitorGrainPlan5.getText().toString().trim().isEmpty() ? null : edtCompetitorGrainPlan5.getText().toString().trim());

                // Grain Compititor values
                if (Utility.isValidStr(edtCompetitorGrainPlanValue1.getText().toString()))
                    dto.setGrainCompetitorHybridValue1(Float.parseFloat(edtCompetitorGrainPlanValue1.getText().toString()));
                else
                    dto.setGrainCompetitorHybridValue1(0);
                if (Utility.isValidStr(edtCompetitorGrainPlanValue2.getText().toString()))
                    dto.setGrainCompetitorHybridValue2(Float.parseFloat(edtCompetitorGrainPlanValue2.getText().toString()));
                else
                    dto.setGrainCompetitorHybridValue2(0);
                if (Utility.isValidStr(edtCompetitorGrainPlanValue3.getText().toString()))
                    dto.setGrainCompetitorHybridValue3(Float.parseFloat(edtCompetitorGrainPlanValue3.getText().toString()));
                else
                    dto.setGrainCompetitorHybridValue3(0);
                if (Utility.isValidStr(edtCompetitorGrainPlanValue4.getText().toString()))
                    dto.setGrainCompetitorHybridValue4(Float.parseFloat(edtCompetitorGrainPlanValue4.getText().toString()));
                else
                    dto.setGrainCompetitorHybridValue4(0);

                if (Utility.isValidStr(edtCompetitorGrainPlanValue5.getText().toString()))
                    dto.setGrainCompetitorHybridValue5(Float.parseFloat(edtCompetitorGrainPlanValue5.getText().toString()));
                else
                    dto.setGrainCompetitorHybridValue5(0);

                // Silage Compititor Lables
                dto.setSilageCompetitorHybrid1(edtCompetitorSilagePlan1.getText().toString().trim().isEmpty() ? null : edtCompetitorSilagePlan1.getText().toString().trim());
                dto.setSilageCompetitorHybrid2(edtCompetitorSilagePlan2.getText().toString().trim().isEmpty() ? null : edtCompetitorSilagePlan2.getText().toString().trim());
                dto.setSilageCompetitorHybrid3(edtCompetitorSilagePlan3.getText().toString().trim().isEmpty() ? null : edtCompetitorSilagePlan3.getText().toString().trim());
                dto.setSilageCompetitorHybrid4(edtCompetitorSilagePlan4.getText().toString().trim().isEmpty() ? null : edtCompetitorSilagePlan4.getText().toString().trim());
                dto.setSilageCompetitorHybrid5(edtCompetitorSilagePlan5.getText().toString().trim().isEmpty() ? null : edtCompetitorSilagePlan5.getText().toString().trim());

                // Silage Competitot values
                if (Utility.isValidStr(edtCompetitorSilagePlanValue1.getText().toString()))
                    dto.setSilageCompetitorHybridValue1(Float.parseFloat(edtCompetitorSilagePlanValue1.getText().toString()));
                else
                    dto.setSilageCompetitorHybridValue1(0);
                if (Utility.isValidStr(edtCompetitorSilagePlanValue2.getText().toString()))
                    dto.setSilageCompetitorHybridValue2(Float.parseFloat(edtCompetitorSilagePlanValue2.getText().toString()));
                else
                    dto.setSilageCompetitorHybridValue2(0);

                if (Utility.isValidStr(edtCompetitorSilagePlanValue3.getText().toString()))
                    dto.setSilageCompetitorHybridValue3(Float.parseFloat(edtCompetitorSilagePlanValue3.getText().toString()));
                else
                    dto.setSilageCompetitorHybridValue3(0);

                if (Utility.isValidStr(edtCompetitorSilagePlanValue4.getText().toString()))
                    dto.setSilageCompetitorHybridValue4(Float.parseFloat(edtCompetitorSilagePlanValue4.getText().toString()));
                else
                    dto.setSilageCompetitorHybridValue4(0);

                if (Utility.isValidStr(edtCompetitorSilagePlanValue5.getText().toString()))
                    dto.setSilageCompetitorHybridValue5(Float.parseFloat(edtCompetitorSilagePlanValue5.getText().toString()));
                else
                    dto.setSilageCompetitorHybridValue5(0);

                dto.setGrainServices(spnGrainServices1.getText().toString());
                dto.setSilageServices(spnSilageServices1.getText().toString());
                if (radioGroup.getCheckedRadioButtonId() == R.id.radio_yes) {
                    dto.setIsTBL("Yes");
                } else {
                    dto.setIsTBL("No");
                }
                dto.setGeoLocation(latLongValues);
                dto.setDate(Utility.getCurrentDateAndTime());
                dto.setIsSync(1);

                // insert here feedback Values
                if (feedbackRadioGrp.getCheckedRadioButtonId() == R.id.radio_fb_yes)
                    dto.setVisitedCornHybrid("Yes");
                else
                    dto.setVisitedCornHybrid("No");

                if (dto.getVisitedCornHybrid().equalsIgnoreCase("Yes")) {
                    ArrayList<CheckBox> checkBoxes = new ArrayList<>();
                    checkBoxes.add(cbShelling);
                    checkBoxes.add(cbGrainWeight);
                    checkBoxes.add(cbEarliness);
                    checkBoxes.add(cbGrainMoisture);
                    checkBoxes.add(cbStandability);
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < checkBoxes.size(); i++) {
                        String checked = String.valueOf(checkBoxes.get(i).getTag());
                        if (checkBoxes.get(i).isChecked()) {
                            if (i < checkBoxes.size() - 1) {
                                builder.append(checked);
                                builder.append(",");
                            } else {
                                builder.append(checked);
                            }
                        }
                    }
                    String selectedCheckBoxes = Utility.isValidStr(builder.toString()) ? builder.toString() : "";
                    dto.setVisitedCornHybridLike(selectedCheckBoxes);

                    dto.setRateHybrid(String.valueOf(fbRatingBar.getRating()));
                    dto.setShiftNextYrAcres(Utility.isValidStr(fb_shift_yearET.getText().toString().trim()) ? String.valueOf(fb_shift_yearET.getText().toString().trim()) : "0");
                }
                FarmerSegmentationDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getWritableDatabase());
            }
        } else {
            // nestle selected
            FarmerSchoolSilageDTO silageDto = new FarmerSchoolSilageDTO();
            IdNameModel yearData = (IdNameModel) spnYear.getTag();
            silageDto.setYear(yearData.getName());
            silageDto.setMobileNo(edtMobileNo.getText().toString());
            silageDto.setPincode(edtPincode.getText().toString());
            silageDto.setFarmerName(edtFarmerName.getText().toString());
            silageDto.setDistrict(edtDistrictName.getText().toString());
            silageDto.setBlock(edtBlockName.getText().toString());
            silageDto.setVillage(edtVillageName.getText().toString());
            silageDto.setGeoLocation(latLongValues);
            silageDto.setLocalImagePath(imagePath);
            silageDto.setDate(Utility.getCurrentDateAndTime());
            silageDto.setIsSync(1);
            silageDto.setDevCenterId(divisionList.get(spnDivision.getSelectedItemPosition()).getId());
            silageDto.setSchoolId(schoolList.get(spnSchool.getSelectedItemPosition()).getId());
            silageDto.setTotalNoOfCattles(Integer.parseInt(edtCattleNestle.getText().toString().trim()));
            silageDto.setAvgMilkYield(Integer.parseInt(edtMilkNestle.getText().toString().trim()));
            if (radioGroupSilageFeeding.getCheckedRadioButtonId() == R.id.radio_feedyes)
                silageDto.setSilageFeeding("Yes");
            else
                silageDto.setSilageFeeding("No");

            if (spnGrowing.getSelectedItem().toString().equalsIgnoreCase("Select")) {
                silageDto.setGrowingOrProcuring("");
            } else {
                silageDto.setGrowingOrProcuring(spnGrowing.getSelectedItem().toString());
            }

            if (Utility.isValidStr(edtAcresGrow.getText().toString().trim())) {
                silageDto.setSilageAcres(Integer.parseInt(edtAcresGrow.getText().toString().trim()));
            } else {
                silageDto.setSilageAcres(0);
            }
            silageDto.setCurrHyb1Name(txtHybrid1.getText().toString().trim());
            silageDto.setCurrHyb1Value(edtHybridValue1.getText().toString().trim());

            silageDto.setCurrHyb2Name(txtHybrid2.getText().toString().trim());
            silageDto.setCurrHyb2Value(edtHybridValue2.getText().toString().trim());

            silageDto.setCurrHyb3Name(txtHybrid3.getText().toString().trim());
            silageDto.setCurrHyb3Value(edtHybridValue3.getText().toString().trim());

            silageDto.setCurrHyb4Name(txtHybrid4.getText().toString().trim());
            silageDto.setCurrHyb4Value(edtHybridValue4.getText().toString().trim());

            silageDto.setCurrHyb5Name(txtHybrid5.getText().toString().trim());
            silageDto.setCurrHyb5Value(edtHybridValue5.getText().toString().trim());

            if (radioGroupPlant.getCheckedRadioButtonId() == R.id.radio_training_yes)
                silageDto.setTrainingPlant("Yes");
            else
                silageDto.setTrainingPlant("No");

            if (radioGroupGrow.getCheckedRadioButtonId() == R.id.radio_grow_yes)
                silageDto.setTrainingGrow("Yes");
            else
                silageDto.setTrainingGrow("No");

            if (radioGroupHarvest.getCheckedRadioButtonId() == R.id.radio_harvest_yes)
                silageDto.setTrainingHarvest("Yes");
            else
                silageDto.setTrainingHarvest("No");

            if (radioGroupStore.getCheckedRadioButtonId() == R.id.radio_store_yes)
                silageDto.setTrainingStore("Yes");
            else
                silageDto.setTrainingStore("No");

            if (radioGroupFeed.getCheckedRadioButtonId() == R.id.radio_feednestle_yes)
                silageDto.setTrainingFeed("Yes");
            else
                silageDto.setTrainingFeed("No");

            FarmerSchoolSilageDAO.getInstance().insert(silageDto, DBHandler.getInstance(mActivity).getWritableDatabase());
        }
    }

    private String spinnerString(Spinner name) {
        Object selectObj = name.getSelectedItem();
        return selectObj != null ? selectObj.toString() : "";
    }

    private boolean isDataAvailable() {

        if (spnYear.getSelectedItemPosition() > 0)
            return true;

        if (spnSeason.getSelectedItemPosition() > 0)
            return true;

        if (spnCrop.getSelectedItemPosition() > 0)
            return true;

        return spnYear.getSelectedItemPosition() > 0;
    }

    private void showAlertToExitScreen(final int callbackCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), (dialog, which) -> mActivity.onBackPressedCallBack(callbackCode));

        builder.setNegativeButton(getResources().getString(R.string.cancel), (dialog, which) -> {
        });
        builder.create().show();
    }


    private class MyTextWatcher implements TextWatcher {

        View view;
        private MyTextWatcher(View v) {
            view = v;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            IdNameModel yearData = (IdNameModel) spnYear.getTag();
            int i = view.getId();
            if (i == R.id.edt_total_crop) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        edtGrainAC.setText("");
                    } else {
                        edtGrainAC.setText("");
                        edtSilageAC.setText("");
                    }
                } else {
                    edtGrainAC.setText("");
                    edtSilageAC.setText("");
                }
            } else if (i == R.id.edt_plan_grain) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        personalDetailsFilterByRice(edtGrainAC);
                    } else {
                        personalDetailsFilter(edtGrainAC);
                    }

                } else {
                    personalDetailsFilter(edtGrainAC);
                }
            } else if (i == R.id.edt_plan_silage) {
                personalDetailsFilter(edtSilageAC);
            } else if (i == R.id.edt_phi_ac_grain) {
                if (Utility.isValidStr(edtGrainAC.getText().toString().trim())) {
                    if (Utility.isValidStr(edtPHIGrainAC.getText().toString().trim())) {

                        edtCompetitorGrainPlanValue1.setText("");
                        edtCompetitorGrainPlanValue2.setText("");
                        edtCompetitorGrainPlanValue3.setText("");
                        edtCompetitorGrainPlanValue4.setText("");
                        edtCompetitorGrainPlanValue5.setText("");

                        double phiGrainAc = Double.parseDouble(edtPHIGrainAC.getText().toString().trim());

                        if (phiGrainAc > Double.parseDouble(edtGrainAC.getText().toString().trim())) {
                            DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                                @Override
                                public void onOkClick() {
                                    edtPHIGrainAC.setText("");
                                    grainHybridCommitHeaderTv.setText(getString(R.string.phi_hybrid_grain));
                                    grainHybridCompititorHeaderTv.setText(getString(R.string.competitor_grain_plan));
                                    // here clear fields if they are filled
                                    spnGrainHybrid1.setSelection(0);
                                    edtGrainHybridValue1.setText("");
                                    edtGrainHybridValue2.setText("");
                                    edtGrainHybridValue3.setText("");
                                    edtGrainHybridValue4.setText("");
                                    edtCompetitorGrainPlanValue1.setText("");
                                    edtCompetitorGrainPlanValue2.setText("");
                                    edtCompetitorGrainPlanValue3.setText("");
                                    edtCompetitorGrainPlanValue4.setText("");
                                    edtCompetitorGrainPlanValue5.setText("");
                                }
                                @Override
                                public void onCancelClick(View view) {
                                }
                            }, getString(R.string.alert), getString(R.string.phi_grain_acres_error).replace("$1", txtHybridRice.getText().toString()), getString(R.string.ok));
                        } else {
                            if (Utility.isValidStr(edtPHIGrainAC.getText().toString().trim())) {
                                grainHybridCommitHeaderTv.setText("PHI Grain Acres Actual " + yearData.getName() + " - " + edtPHIGrainAC.getText().toString().trim() + " ACRES");
                                double grainCompititorVal = Double.parseDouble(edtGrainAC.getText().toString().trim()) - Double.parseDouble(edtPHIGrainAC.getText().toString().trim());
                                grainHybridCompititorHeaderTv.setText("Competitor Actual Grain " + yearData.getName() + " - " + (int) grainCompititorVal + " ACRES");
                            }
                        }
                    } else {
                        grainHybridCommitHeaderTv.setText(getString(R.string.phi_hybrid_grain));
                        grainHybridCompititorHeaderTv.setText(getString(R.string.competitor_grain_plan));
                    }
                } else {
                    grainHybridCommitHeaderTv.setText(getString(R.string.phi_hybrid_grain));
                    grainHybridCompititorHeaderTv.setText(getString(R.string.competitor_grain_plan));
                }
            } else if (i == R.id.edt_phi_ac_silage) {
                if (Utility.isValidStr(edtSilageAC.getText().toString().trim())) {
                    if (Utility.isValidStr(edtPHISilageAC.getText().toString().trim())) {

                        edtCompetitorSilagePlanValue1.setText("");
                        edtCompetitorSilagePlanValue2.setText("");
                        edtCompetitorSilagePlanValue3.setText("");
                        edtCompetitorSilagePlanValue4.setText("");
                        edtCompetitorSilagePlanValue5.setText("");

                        double phiSilageAc = Double.parseDouble(edtPHISilageAC.getText().toString().trim());
                        if (phiSilageAc > Double.parseDouble(edtSilageAC.getText().toString().trim())) {
                            DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                                @Override
                                public void onOkClick() {
                                    edtPHISilageAC.setText("");
                                    silageHybridCommitHeaderTv.setText(getString(R.string.phi_hybrid_silage));
                                    silageHybridCompititorHeaderTv.setText(getString(R.string.competitor_silage_plan));
                                    // here Clear all the fields
                                    spnSilageHybrid1.setSelection(0);
                                    edtSilageHybridValue1.setText("");
                                    edtSilageHybridValue2.setText("");
                                    edtSilageHybridValue3.setText("");
                                    edtSilageHybridValue4.setText("");
                                    edtCompetitorSilagePlanValue1.setText("");
                                    edtCompetitorSilagePlanValue2.setText("");
                                    edtCompetitorSilagePlanValue3.setText("");
                                    edtCompetitorSilagePlanValue4.setText("");
                                    edtCompetitorSilagePlanValue5.setText("");
                                }
                                @Override
                                public void onCancelClick(View view) {
                                }
                            }, getString(R.string.alert), getString(R.string.phi_silage_acres_error).replace("$1", txtSilageCrop.getText().toString()), getString(R.string.ok));
                        } else {
                            if (Utility.isValidStr(edtPHISilageAC.getText().toString().trim())) {
//                                silageHybridCommitHeaderTv.setText(getString(R.string.phi_hybrid_silage) + " - " + edtPHISilageAC.getText().toString().trim() + " AC");
                                silageHybridCommitHeaderTv.setText("PHI Silage Actual " + yearData.getName() + " - " + edtPHISilageAC.getText().toString().trim() + " ACRES");
                                double silageCompititorVal = Double.parseDouble(edtSilageAC.getText().toString().trim()) - Double.parseDouble(edtPHISilageAC.getText().toString().trim());
//                                silageHybridCompititorHeaderTv.setText(getString(R.string.competitor_silage_plan) + " - " + (int) silageCompititorVal + " AC");
                                silageHybridCompititorHeaderTv.setText("Competitor Actual Silage " + yearData.getName() + " - " + (int) silageCompititorVal + " ACRES");
                            }
                        }
                    } else {
                        silageHybridCommitHeaderTv.setText(getString(R.string.phi_hybrid_silage));
                        silageHybridCompititorHeaderTv.setText(getString(R.string.competitor_silage_plan));
                    }
                } else {
                    silageHybridCommitHeaderTv.setText(getString(R.string.phi_hybrid_silage));
                    silageHybridCompititorHeaderTv.setText(getString(R.string.competitor_silage_plan));
                }
            } else if (i == R.id.edt_spinner1) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceHybridCommitTotal(edtGrainHybridValue1);
                    } else {
                        if (spnGrainHybrid1.getSelectedItemPosition() > 0)
                            grainHybridCommitTotal(edtGrainHybridValue1);
                        /*else
                            DialogManager.showToast(getContext(), "Please select Grain Hybrid 1");*/

                    }
                }
            } else if (i == R.id.edt_spinner2) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceHybridCommitTotal(edtGrainHybridValue2);
                    } else {
//                        if (Utility.isValidStr(edtGrainHybridValue1.getText().toString().trim()))
                            grainHybridCommitTotal(edtGrainHybridValue2);
                    }
                }
            } else if (i == R.id.edt_spinner3) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceHybridCommitTotal(edtGrainHybridValue3);
                    } else {
                        grainHybridCommitTotal(edtGrainHybridValue3);
                    }
                }
            } else if (i == R.id.edt_spinner4) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceHybridCommitTotal(edtGrainHybridValue4);
                    } else {
                        grainHybridCommitTotal(edtGrainHybridValue4);
                    }
                }
            } else if (i == R.id.edt_spinner5) {
                if (spnSilageHybrid1.getSelectedItemPosition() > 0)
                    silageHybridCommitTotal(edtSilageHybridValue1);
                /*else
                    DialogManager.showToast(getContext(), "Please select Silage Hybrid 1");*/

            } else if (i == R.id.edt_spinner6) {
//                if (Utility.isValidStr(edtSilageHybridValue1.getText().toString().trim()))
                    silageHybridCommitTotal(edtSilageHybridValue2);
            } else if (i == R.id.edt_spinner7) {
                silageHybridCommitTotal(edtSilageHybridValue3);
            } else if (i == R.id.edt_spinner8) {
                silageHybridCommitTotal(edtSilageHybridValue4);
            } else if (i == R.id.edt_competitorGrainvalue1) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceCompetitorTotal(edtCompetitorGrainPlanValue1);
                    } else {
                        grainCompetitorTotal(edtCompetitorGrainPlanValue1);
                    }
                }
            } else if (i == R.id.edt_competitorGrainvalue2) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceCompetitorTotal(edtCompetitorGrainPlanValue2);
                    } else {
                        grainCompetitorTotal(edtCompetitorGrainPlanValue2);
                    }
                }
            } else if (i == R.id.edt_competitorGrainvalue3) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceCompetitorTotal(edtCompetitorGrainPlanValue3);
                    } else {
                        grainCompetitorTotal(edtCompetitorGrainPlanValue3);
                    }
                }
            } else if (i == R.id.edt_competitorGrainvalue4) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceCompetitorTotal(edtCompetitorGrainPlanValue4);
                    } else {
                        grainCompetitorTotal(edtCompetitorGrainPlanValue4);
                    }
                }
            } else if (i == R.id.edt_competitorGrainvalue5) {
                if (seletedCrop != null && !seletedCrop.isEmpty()) {
                    if (seletedCrop.equalsIgnoreCase(MyConstants.RICE)) {
                        riceCompetitorTotal(edtCompetitorGrainPlanValue5);
                    } else {
                        grainCompetitorTotal(edtCompetitorGrainPlanValue5);
                    }
                }
            } else if (i == R.id.edt_competitorSilagevalue1) {
                silageCompititorTotal(edtCompetitorSilagePlanValue1);
            } else if (i == R.id.edt_competitorSilagevalue2) {
                silageCompititorTotal(edtCompetitorSilagePlanValue2);
            } else if (i == R.id.edt_competitorSilagevalue3) {
                silageCompititorTotal(edtCompetitorSilagePlanValue3);
            } else if (i == R.id.edt_competitorSilagevalue4) {
                silageCompititorTotal(edtCompetitorSilagePlanValue4);
            } else if (i == R.id.edt_competitorSilagevalue5) {
                silageCompititorTotal(edtCompetitorSilagePlanValue5);
            } else if (i == R.id.edt_phi_maturity_rice_124 || i == R.id.edt_phi_maturity_rice_134 || i == R.id.edt_phi_maturity_rice_135) {
                riceMaturity124(s);
            } else if (i == R.id.edt_hybridvalue1 || i == R.id.edt_hybridvalue2 || i == R.id.edt_hybridvalue3 || i == R.id.edt_hybridvalue4 || i == R.id.edt_hybridvalue5) {
                currentHybridUsed(s);
            }
        }
    }

    private void currentHybridUsed(Editable edtText) {
        double gh1 = 0, gh2 = 0, gh3 = 0, gh4 = 0, gh5 = 0, total = 0, phiRiceVal;

        if (Utility.isValidStr(edtAcresGrow.getText().toString().trim())) {
            if (Double.parseDouble(edtAcresGrow.getText().toString().trim()) > 0) {
                if (Utility.isValidStr(edtHybridValue1.getText().toString().trim()))
                    gh1 = Double.parseDouble(edtHybridValue1.getText().toString().trim());
                if (Utility.isValidStr(edtHybridValue2.getText().toString().trim()))
                    gh2 = Double.parseDouble(edtHybridValue2.getText().toString().trim());
                if (Utility.isValidStr(edtHybridValue3.getText().toString().trim()))
                    gh3 = Double.parseDouble(edtHybridValue3.getText().toString().trim());
                if (Utility.isValidStr(edtHybridValue4.getText().toString().trim()))
                    gh4 = Double.parseDouble(edtHybridValue4.getText().toString().trim());
                if (Utility.isValidStr(edtHybridValue5.getText().toString().trim()))
                    gh5 = Double.parseDouble(edtHybridValue5.getText().toString().trim());

                total = gh1 + gh2 + gh3 + gh4 + gh5;
                phiRiceVal = Double.parseDouble(edtAcresGrow.getText().toString().trim());

                if (total > phiRiceVal) {
                    DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            edtText.clear();
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.alert), "Sum of current hybrid used should not be more than growing acres", getString(R.string.ok));
                }
            }
        }
    }


    private void personalDetailsFilter(EditText edtPlanAC) {
        if (Utility.isValidStr(edtPlanCrop.getText().toString().trim())) {
            double sum = 0;
            if (Utility.isValidStr(edtGrainAC.getText().toString().trim())) {
                sum = sum + Double.parseDouble(edtGrainAC.getText().toString().trim());
            }
            if (Utility.isValidStr(edtSilageAC.getText().toString().trim())) {
                sum = sum + Double.parseDouble(edtSilageAC.getText().toString().trim());
            }

            if (sum > Double.parseDouble(edtPlanCrop.getText().toString().trim())) {
                DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        edtPlanAC.setText("");
                    }
                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Alert", getString(R.string.farSeg_total_plan_acres_error), getString(R.string.ok));
            }
        }
    }

    private void personalDetailsFilterByRice(EditText edtPlanAC) {
        if (Utility.isValidStr(edtPlanCrop.getText().toString().trim())) {
            double sum = 0;
            if (Utility.isValidStr(edtGrainAC.getText().toString().trim())) {
                sum = sum + Double.parseDouble(edtGrainAC.getText().toString().trim());
            }

            if (sum > Double.parseDouble(edtPlanCrop.getText().toString().trim())) {
                DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        edtPlanAC.setText("");
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Alert", getString(R.string.farSeg_rice_total_plan_acres_error), getString(R.string.ok));
            }
        }
    }

    private void grainHybridCommitTotal(EditText editText) {
        double gh1 = 0, gh2 = 0, gh3 = 0, gh4 = 0, total = 0, phiGrainVal;

        if (Utility.isValidStr(edtPHIGrainAC.getText().toString().trim()) && !edtPHIGrainAC.equals("0")) {
            if (Double.parseDouble(edtPHIGrainAC.getText().toString().trim()) > 0) {
                if (Utility.isValidStr(edtGrainHybridValue1.getText().toString().trim()))
                    gh1 = Double.parseDouble(edtGrainHybridValue1.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue2.getText().toString().trim()))
                    gh2 = Double.parseDouble(edtGrainHybridValue2.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue3.getText().toString().trim()))
                    gh3 = Double.parseDouble(edtGrainHybridValue3.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue4.getText().toString().trim()))
                    gh4 = Double.parseDouble(edtGrainHybridValue4.getText().toString().trim());

                total = gh1 + gh2 + gh3 + gh4;
                phiGrainVal = Double.parseDouble(edtPHIGrainAC.getText().toString().trim());

                if (total > phiGrainVal) {
                    DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            editText.setText("");
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.alert), "Sum of all PHI Grain Acres values should not be more than Grain Acres " + yearGet, getString(R.string.ok));
                }
            } else if (!editText.getText().toString().trim().isEmpty()) {
                editText.setText("");
                DialogManager.showToast(getContext(), "You can not enter Grain Hybrid Commit because its value is 0");
            }
        } /*else {
            editText.setText("");
            DialogManager.showToast(getContext(), "You can not enter Grain Hybrid Commit because its value is 0");
        }*/
    }

    private void grainCompetitorTotal(EditText editText) {
        double gct1 = 0, gct2 = 0, gct3 = 0, gct4 = 0, gct5 = 0, total, grainCompitotorRequired = 0;
        if (Utility.isValidStr(edtGrainAC.getText().toString().trim()) && Utility.isValidStr(edtPHIGrainAC.getText().toString().trim()))
            grainCompitotorRequired = Double.parseDouble(edtGrainAC.getText().toString().trim()) - Double.parseDouble(edtPHIGrainAC.getText().toString().trim());

        if (grainCompitotorRequired > 0) {
            if (Utility.isValidStr(edtCompetitorGrainPlanValue1.getText().toString().trim()))
                gct1 = Double.parseDouble(edtCompetitorGrainPlanValue1.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue2.getText().toString().trim()))
                gct2 = Double.parseDouble(edtCompetitorGrainPlanValue2.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue3.getText().toString().trim()))
                gct3 = Double.parseDouble(edtCompetitorGrainPlanValue3.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue4.getText().toString().trim()))
                gct4 = Double.parseDouble(edtCompetitorGrainPlanValue4.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue5.getText().toString().trim()))
                gct5 = Double.parseDouble(edtCompetitorGrainPlanValue5.getText().toString().trim());

            total = gct1 + gct2 + gct3 + gct4 + gct5;
            if (total > grainCompitotorRequired) {
                DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        editText.setText("");
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, getString(R.string.alert), " Sum of all Competitors Grain Plan values should not be more than " + grainCompitotorRequired + " AC", getString(R.string.ok));
            }
        } else if (!editText.getText().toString().trim().isEmpty()) {
            editText.setText("");
            DialogManager.showToast(getContext(), "Grain competitor plan is not available");
        }
    }

    private void silageHybridCommitTotal(EditText editText) {
        double sh1 = 0, sh2 = 0, sh3 = 0, sh4 = 0, sTotal = 0, phiSilageVal;

        if (Utility.isValidStr(edtPHISilageAC.getText().toString().trim()) && !edtPHISilageAC.equals("0")) {
            if (Double.parseDouble(edtPHISilageAC.getText().toString().trim()) > 0) {
                if (Utility.isValidStr(edtSilageHybridValue1.getText().toString().trim()))
                    sh1 = Double.parseDouble(edtSilageHybridValue1.getText().toString().trim());
                if (Utility.isValidStr(edtSilageHybridValue2.getText().toString().trim()))
                    sh2 = Double.parseDouble(edtSilageHybridValue2.getText().toString().trim());
                if (Utility.isValidStr(edtSilageHybridValue3.getText().toString().trim()))
                    sh3 = Double.parseDouble(edtSilageHybridValue3.getText().toString().trim());
                if (Utility.isValidStr(edtSilageHybridValue4.getText().toString().trim()))
                    sh4 = Double.parseDouble(edtSilageHybridValue4.getText().toString().trim());

                sTotal = sh1 + sh2 + sh3 + sh4;
                phiSilageVal = Double.parseDouble(edtPHISilageAC.getText().toString().trim());

                if (sTotal > phiSilageVal) {
                    DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            editText.setText("");
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.alert), "Sum of all PHI Silage Acres values should not be more than Silage Acres " + yearGet, getString(R.string.ok));
                }
            } else if (!editText.getText().toString().trim().isEmpty()) {
                editText.setText("");
                DialogManager.showToast(getContext(), "You can not enter Silage Hybrid Commit because its value is 0");
            }
        } /*else {
            editText.setText("");
            DialogManager.showToast(getContext(), "You can not enter Silage Hybrid Commit because its value is 0");
        }*/
    }

    private void silageCompititorTotal(EditText editText) {
        double sct1 = 0, sct2 = 0, sct3 = 0, sct4 = 0, sct5 = 0, total, silageCompitotorRequired = 0;
        if (Utility.isValidStr(edtSilageAC.getText().toString().trim()) && Utility.isValidStr(edtPHISilageAC.getText().toString().trim()))
            silageCompitotorRequired = Double.parseDouble(edtSilageAC.getText().toString().trim()) - Double.parseDouble(edtPHISilageAC.getText().toString().trim());

        if (silageCompitotorRequired > 0) {
            if (Utility.isValidStr(edtCompetitorSilagePlanValue1.getText().toString().trim()))
                sct1 = Double.parseDouble(edtCompetitorSilagePlanValue1.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorSilagePlanValue2.getText().toString().trim()))
                sct2 = Double.parseDouble(edtCompetitorSilagePlanValue2.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorSilagePlanValue3.getText().toString().trim()))
                sct3 = Double.parseDouble(edtCompetitorSilagePlanValue3.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorSilagePlanValue4.getText().toString().trim()))
                sct4 = Double.parseDouble(edtCompetitorSilagePlanValue4.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorSilagePlanValue5.getText().toString().trim()))
                sct5 = Double.parseDouble(edtCompetitorSilagePlanValue5.getText().toString().trim());

            total = sct1 + sct2 + sct3 + sct4 + sct5;
            if (total > silageCompitotorRequired) {
                DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        editText.setText("");
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, getString(R.string.alert), " Sum of all Competitor Silage Plan values should not be more than " + silageCompitotorRequired + " AC", getString(R.string.ok));
            }
        } else if (!editText.getText().toString().trim().isEmpty()) {
            editText.setText("");
            DialogManager.showToast(getContext(), "You can not enter Competitor Silage Plan because its value is 0");
        }
    }

    private void riceCompetitorTotal(EditText editText) {
        double gct1 = 0, gct2 = 0, gct3 = 0, gct4 = 0, total, riceCompitotorRequired = 0;

        double riceH1 = 0, riceH2 = 0, riceH3 = 0, riceH4 = 0;
        if (Utility.isValidStr(edtGrainAC.getText().toString().trim())) {
            riceCompitotorRequired = Double.parseDouble(edtGrainAC.getText().toString().trim());
            if (Utility.isValidStr(edtGrainHybridValue1.getText().toString().trim()))
                riceH1 = Double.parseDouble(edtGrainHybridValue1.getText().toString().trim());
            if (Utility.isValidStr(edtGrainHybridValue2.getText().toString().trim()))
                riceH2 = Double.parseDouble(edtGrainHybridValue2.getText().toString().trim());
            if (Utility.isValidStr(edtGrainHybridValue3.getText().toString().trim()))
                riceH3 = Double.parseDouble(edtGrainHybridValue3.getText().toString().trim());
            if (Utility.isValidStr(edtGrainHybridValue4.getText().toString().trim()))
                riceH4 = Double.parseDouble(edtGrainHybridValue4.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue1.getText().toString().trim()))
                gct1 = Double.parseDouble(edtCompetitorGrainPlanValue1.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue2.getText().toString().trim()))
                gct2 = Double.parseDouble(edtCompetitorGrainPlanValue2.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue3.getText().toString().trim()))
                gct3 = Double.parseDouble(edtCompetitorGrainPlanValue3.getText().toString().trim());
            if (Utility.isValidStr(edtCompetitorGrainPlanValue4.getText().toString().trim()))
                gct4 = Double.parseDouble(edtCompetitorGrainPlanValue4.getText().toString().trim());
            total = riceH1 + riceH2 + riceH3 + riceH4 + gct1 + gct2 + gct3 + gct4;

            if (riceCompitotorRequired > 0) {
                if (total > riceCompitotorRequired) {
                    DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            editText.setText("");
                        }
                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.alert), " Sum of all Competitors Rice Plan values should not be more than " + riceCompitotorRequired + "", getString(R.string.ok));
                }
            } else if (!editText.getText().toString().trim().isEmpty()) {
                editText.setText("");
                DialogManager.showToast(getContext(), "Rice competitor plan is not available");
            }
        }
    }

    private void riceMaturity124(Editable edtText) {
        double gh1 = 0, gh2 = 0, gh3 = 0, total, phiRiceVal;

        if (Utility.isValidStr(edtGrainAC.getText().toString().trim())) {
            if (Double.parseDouble(edtGrainAC.getText().toString().trim()) > 0) {
                if (Utility.isValidStr(edtMaturity124Acr.getText().toString().trim()))
                    gh1 = Double.parseDouble(edtMaturity124Acr.getText().toString().trim());
                if (Utility.isValidStr(edtMaturity134Acr.getText().toString().trim()))
                    gh2 = Double.parseDouble(edtMaturity134Acr.getText().toString().trim());
                if (Utility.isValidStr(edtMaturity135Acr.getText().toString().trim()))
                    gh3 = Double.parseDouble(edtMaturity135Acr.getText().toString().trim());

                total = gh1 + gh2 + gh3;
                phiRiceVal = Double.parseDouble(edtGrainAC.getText().toString().trim());

                if (total > phiRiceVal) {
                    DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            edtText.clear();
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.alert), "Sum of hybrid rice duration should not be more than hybrid rice acres", getString(R.string.ok));
                }
            }
        }
    }

    private void riceHybridCommitTotal(EditText editText) {
        double gh1 = 0, gh2 = 0, gh3 = 0, gh4 = 0, total = 0, phiGrainVal = 0;
        double riceH1 = 0, riceH2 = 0, riceH3 = 0, riceH4 = 0;
        if (Utility.isValidStr(edtGrainAC.getText().toString().trim())) {
            if (Double.parseDouble(edtGrainAC.getText().toString().trim()) > 0) {
                phiGrainVal = Double.parseDouble(edtGrainAC.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue1.getText().toString().trim()))
                    riceH1 = Double.parseDouble(edtGrainHybridValue1.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue2.getText().toString().trim()))
                    riceH2 = Double.parseDouble(edtGrainHybridValue2.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue3.getText().toString().trim()))
                    riceH3 = Double.parseDouble(edtGrainHybridValue3.getText().toString().trim());
                if (Utility.isValidStr(edtGrainHybridValue4.getText().toString().trim()))
                    riceH4 = Double.parseDouble(edtGrainHybridValue4.getText().toString().trim());

                if (Utility.isValidStr(edtCompetitorGrainPlanValue1.getText().toString().trim()))
                    gh1 = Double.parseDouble(edtCompetitorGrainPlanValue1.getText().toString().trim());
                if (Utility.isValidStr(edtCompetitorGrainPlanValue2.getText().toString().trim()))
                    gh2 = Double.parseDouble(edtCompetitorGrainPlanValue2.getText().toString().trim());
                if (Utility.isValidStr(edtCompetitorGrainPlanValue3.getText().toString().trim()))
                    gh3 = Double.parseDouble(edtCompetitorGrainPlanValue3.getText().toString().trim());
                if (Utility.isValidStr(edtCompetitorGrainPlanValue4.getText().toString().trim()))
                    gh4 = Double.parseDouble(edtCompetitorGrainPlanValue4.getText().toString().trim());

                total = riceH1 + riceH2 + riceH3 + riceH4 + gh1 + gh2 + gh3 + gh4;

                if (total > phiGrainVal) {
                    DialogManager.showSingleBtnPopup(getContext(), new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            editText.setText("");
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.alert), "Sum of all hybrid values should not be more than  " + phiGrainVal + " ", getString(R.string.ok));
                }
            }
        }
    }

    public static void setFilter(EditText editText) {
        InputFilter[] inputFilters = editText.getFilters();
        InputFilter[] newFilters = new InputFilter[inputFilters.length + 1];
        System.arraycopy(inputFilters, 0, newFilters, 0, inputFilters.length);
        newFilters[inputFilters.length] = new InputFilter.AllCaps();
        editText.setFilters(newFilters);
    }

    private void showAlertToEditScreen() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage("If you edit segmentation details entered farmer data will be lost.");
        builder.setPositiveButton(getResources().getString(R.string.edit), (dialog, which) -> setEditFocus());

        builder.setNegativeButton(getResources().getString(R.string.cancel), (dialog, which) -> {
        });

        builder.create().show();
    }

    @Override
    public void onStart() {
        super.onStart();
        location = null;
        if (checkLocPermission())
            getCurrentLocation(mActivity);
    }

    protected void getCurrentLocation(final Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (mGoogleApiClient != null) {
                if (mGoogleApiClient.isConnected()) {
                    mGoogleApiClient.disconnect();
                }
                mGoogleApiClient.connect();
            }
            CountDownTimer start = new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

                @Override
                public void onTick(long millisUntilFinished) {
                    if (location != null) {
                        latLongValues = location;
                        hideProgressDialog();
                        this.cancel();
                    }
                }
                @Override
                public void onFinish() {
                    hideProgressDialog();
                    this.cancel();
                }
            }.start();
        } else {
            com.activitytrack.utility.DialogManager.showSingleBtnPopup(mActivity, null, getString(com.activitytrack.activity.R.string.alert), getString(com.activitytrack.activity.R.string.gps), getString(com.activitytrack.activity.R.string.ok));
        }
    }
}