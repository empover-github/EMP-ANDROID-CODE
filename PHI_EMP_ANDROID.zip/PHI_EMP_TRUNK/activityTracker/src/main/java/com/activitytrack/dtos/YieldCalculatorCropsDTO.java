package com.activitytrack.dtos;

public class YieldCalculatorCropsDTO  implements DTO 
{
	private long mobileId;
    private String yieldFor;
    private Float length;
    private Float breadth;
    private Float rowSpacing;
    private Float rowsHarvested;
    private Float harvestedPlants;
    private Float population;
    private Float totalCobWeight;
    private Float shellingPercentage;
    private Float totalGrainWeight;
    private Float moisturePercentage;
    private Float hillsPerSQM;
    private Float totalEarheadWeight;
    private Float totalDryGrainWeight;
    private Float perAcreYield;
    private Float yieldGain;
    private Float perYieldGain;
    private Long activityId;
    private Long cropId;
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	public String getYieldFor() {
		return yieldFor;
	}
	public void setYieldFor(String yieldFor) {
		this.yieldFor = yieldFor;
	}
	public Float getLength() {
		return length;
	}
	public void setLength(Float length) {
		this.length = length;
	}
	public Float getBreadth() {
		return breadth;
	}
	public void setBreadth(Float breadth) {
		this.breadth = breadth;
	}
	public Float getRowSpacing() {
		return rowSpacing;
	}
	public void setRowSpacing(Float rowSpacing) {
		this.rowSpacing = rowSpacing;
	}
	public Float getRowsHarvested() {
		return rowsHarvested;
	}
	public void setRowsHarvested(Float rowsHarvested) {
		this.rowsHarvested = rowsHarvested;
	}
	public Float getHarvestedPlants() {
		return harvestedPlants;
	}
	public void setHarvestedPlants(Float harvestedPlants) {
		this.harvestedPlants = harvestedPlants;
	}
	public Float getPopulation() {
		return population;
	}
	public void setPopulation(Float population) {
		this.population = population;
	}
	public Float getTotalCobWeight() {
		return totalCobWeight;
	}
	public void setTotalCobWeight(Float totalCobWeight) {
		this.totalCobWeight = totalCobWeight;
	}
	public Float getShellingPercentage() {
		return shellingPercentage;
	}
	public void setShellingPercentage(Float shellingPercentage) {
		this.shellingPercentage = shellingPercentage;
	}
	public Float getTotalGrainWeight() {
		return totalGrainWeight;
	}
	public void setTotalGrainWeight(Float totalGrainWeight) {
		this.totalGrainWeight = totalGrainWeight;
	}
	public Float getMoisturePercentage() {
		return moisturePercentage;
	}
	public void setMoisturePercentage(Float moisturePercentage) {
		this.moisturePercentage = moisturePercentage;
	}
	public Float getHillsPerSQM() {
		return hillsPerSQM;
	}
	public void setHillsPerSQM(Float hillsPerSQM) {
		this.hillsPerSQM = hillsPerSQM;
	}
	public Float getTotalEarheadWeight() {
		return totalEarheadWeight;
	}
	public void setTotalEarheadWeight(Float totalEarheadWeight) {
		this.totalEarheadWeight = totalEarheadWeight;
	}
	public Float getTotalDryGrainWeight() {
		return totalDryGrainWeight;
	}
	public void setTotalDryGrainWeight(Float totalDryGrainWeight) {
		this.totalDryGrainWeight = totalDryGrainWeight;
	}
	public Float getPerAcreYield() {
		return perAcreYield;
	}
	public void setPerAcreYield(Float perAcreYield) {
		this.perAcreYield = perAcreYield;
	}
	public Float getYieldGain() {
		return yieldGain;
	}
	public void setYieldGain(Float yieldGain) {
		this.yieldGain = yieldGain;
	}
	public Float getPerYieldGain() {
		return perYieldGain;
	}
	public void setPerYieldGain(Float perYieldGain) {
		this.perYieldGain = perYieldGain;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Long getCropId() {
		return cropId;
	}
	public void setCropId(Long cropId) {
		this.cropId = cropId;
	}
}
