package com.activitytrack.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;
import androidx.core.widget.CompoundButtonCompat;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.daos.PravaktaFarmerDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.PravaktaFarmerDTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.bumptech.glide.Glide;
import com.soundcloud.android.crop.Crop;

import net.sourceforge.opencamera.MainActivityOC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by rambabu.a on 05-03-2018.
 */

public class PravaktaFarmerDataActivity extends AppCompatActivity {
    private Button btnFarSubmit;
    private ImageView profileImageFarm, imageCaptureFarm;
    private TextView tvRadioBtnPda, tvRadioBtnPion, tvTotalAcres, tvPhiAcres, tvTargetAcres, tvCrop, tvTargerHybrid, tvPreviousYear, tvCurrentYear, tvFarmName, tvFarmMobileNo;
    private EditText edtTotalAcresPYear, edtTotalAcresCYear, edtPhiAcresPYear, edtPhiAcresCYear, edtTargetAcresPYear, edtTargetAcresCYear, edtTargerHybrid, edtFarmerName, edtFarmerMobNo;
    private LinearLayout mainLayout;
    private CheckBox checkBoxCorn, checkBoxRice, checkBoxMillet, checkBoxMustard;
    private LinearLayout layoutClear, layoutPlus;
    private StringBuilder builder = null;
    private List<String> listTarget;
    private long activityId;
    private RadioGroup radioGroPdaPre, radioGroPdaCurr, radioGroPionPre, radioGroPionCurr;
    private RadioButton radioButPdaPreYes, radioButPdaPreNo, radioButPdaCurYes, radioButPdaCurNo, radioButPionPreYes, radioButPionPreNo, radioButPionCurYes, radioButPionCurNo;
    private int previousYear, currentYear;
    private PravaktaFarmerDTO pravaktaFarmerData;
    private PravaktaFarmerDataActivity pravaktaFarmerDataActivity;
    private String imagePath;
    private Uri uriStr;
    public static final int OPENCAMERA = 300;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    File myDir;
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    private static final int REQUEST_CODE_FOR_IMAGE_CROPPING = 67 ;
    private RelativeLayout rlTraget;
    private ExecutorService mExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pravakat_data_activity);
        pravaktaFarmerDataActivity = this;


       /* if (Utility.getCurrentTheme(pravaktaFarmerDataActivity).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(pravaktaFarmerDataActivity).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }*/


        /*Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar_at);
        setSupportActionBar(mToolbar);
        TextView mTitleTextView = (TextView) findViewById(R.id.header_text_at);
        mTitleTextView.setText(getResources().getString(R.string.farmer_details));*/
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setTitle(getResources().getString(R.string.farmer_details));
        }
        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            if(bundle.containsKey("activityId"))
                activityId = bundle.getLong("activityId");

        if (bundle.containsKey("PravaktaFarmerModel") && bundle.getSerializable("PravaktaFarmerModel") != null)
            pravaktaFarmerData = (PravaktaFarmerDTO) bundle.getSerializable("PravaktaFarmerModel");

        }
        initializeViews();
        setChange();
    }

    private void setChange() {
        if (Utility.getCurrentTheme(PravaktaFarmerDataActivity.this).equals(MyConstants.THEME_DARK)) {
            tvRadioBtnPda.setTextColor(Color.WHITE);
            tvRadioBtnPion.setTextColor(Color.WHITE);
            tvTotalAcres.setTextColor(Color.WHITE);
            tvPhiAcres.setTextColor(Color.WHITE);
            tvTargetAcres.setTextColor(Color.WHITE);
            tvCrop.setTextColor(Color.WHITE);
            tvTargerHybrid.setTextColor(Color.WHITE);
            tvPreviousYear.setTextColor(Color.WHITE);
            tvCurrentYear.setTextColor(Color.WHITE);
            tvFarmName.setTextColor(Color.WHITE);
            tvFarmMobileNo.setTextColor(Color.WHITE);
            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(checkBoxRice, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(checkBoxCorn, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(checkBoxMillet, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(checkBoxMustard, ColorStateList.valueOf(Color.WHITE));

                CompoundButtonCompat.setButtonTintList(radioButPdaPreYes, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButPdaCurYes, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButPdaPreNo, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButPdaCurNo, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButPionPreYes, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButPionCurYes, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButPionPreNo, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButPionCurNo, ColorStateList.valueOf(Color.WHITE));

            } else {
                checkBoxRice.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                checkBoxCorn.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                checkBoxMillet.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                checkBoxMustard.setButtonTintList(ColorStateList.valueOf(Color.WHITE));


                radioButPdaPreYes.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButPdaCurYes.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButPdaPreNo.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButPdaCurNo.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButPionPreYes.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButPionCurYes.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButPionPreNo.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButPionCurNo.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
            }

            checkBoxRice.setTextColor(Color.WHITE);
            checkBoxCorn.setTextColor(Color.WHITE);
            checkBoxMillet.setTextColor(Color.WHITE);
            checkBoxMustard.setTextColor(Color.WHITE);

            radioButPdaPreYes.setTextColor(Color.WHITE);
            radioButPdaCurYes.setTextColor(Color.WHITE);
            radioButPdaPreNo.setTextColor(Color.WHITE);
            radioButPdaCurNo.setTextColor(Color.WHITE);
            radioButPionPreYes.setTextColor(Color.WHITE);
            radioButPionCurYes.setTextColor(Color.WHITE);
            radioButPionPreNo.setTextColor(Color.WHITE);
            radioButPionCurNo.setTextColor(Color.WHITE);


            /* edtTotalAcresPYear.setTextColor(Color.WHITE);
            edtTotalAcresCYear.setTextColor(Color.WHITE);
            edtPhiAcresPYear.setTextColor(Color.WHITE);
            edtPhiAcresCYear.setTextColor(Color.WHITE);
            edtTargetAcresPYear.setTextColor(Color.WHITE);
            edtTargetAcresCYear.setTextColor(Color.WHITE);
            edtTargerHybrid.setTextColor(Color.WHITE);
            edtFarmerName.setTextColor(Color.WHITE);
            edtFarmerMobNo.setTextColor(Color.WHITE);

            edtTotalAcresPYear.setBackgroundResource(R.drawable.textfield_bg);
            edtTotalAcresCYear.setBackgroundResource(R.drawable.textfield_bg);
            edtPhiAcresPYear.setBackgroundResource(R.drawable.textfield_bg);
            edtPhiAcresCYear.setBackgroundResource(R.drawable.textfield_bg);
            edtTargetAcresPYear.setBackgroundResource(R.drawable.textfield_bg);
            edtTargetAcresCYear.setBackgroundResource(R.drawable.textfield_bg);

            edtFarmerName.setBackgroundResource(R.drawable.textfield_bg);
            edtFarmerMobNo.setBackgroundResource(R.drawable.textfield_bg);*/

            rlTraget.setBackgroundResource(R.drawable.textfield_bg);


            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
            //layoutPht.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(PravaktaFarmerDataActivity.this).equals(MyConstants.THEME_LIGHT)) {
            tvRadioBtnPda.setTextColor(Color.BLACK);
            tvRadioBtnPion.setTextColor(Color.BLACK);
            tvTotalAcres.setTextColor(Color.BLACK);
            tvPhiAcres.setTextColor(Color.BLACK);
            tvTargetAcres.setTextColor(Color.BLACK);
            tvCrop.setTextColor(Color.BLACK);
            tvTargerHybrid.setTextColor(Color.BLACK);
            tvPreviousYear.setTextColor(Color.BLACK);
            tvCurrentYear.setTextColor(Color.BLACK);
            tvFarmName.setTextColor(Color.BLACK);
            tvFarmMobileNo.setTextColor(Color.BLACK);
            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(checkBoxRice, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(checkBoxCorn, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(checkBoxMillet, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(checkBoxMustard, ColorStateList.valueOf(Color.BLACK));

                CompoundButtonCompat.setButtonTintList(radioButPdaPreYes, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButPdaCurYes, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButPdaPreNo, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButPdaCurNo, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButPionPreYes, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButPionCurYes, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButPionPreNo, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButPionCurNo, ColorStateList.valueOf(Color.BLACK));
            } else {
                checkBoxRice.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                checkBoxCorn.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                checkBoxMillet.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                checkBoxMustard.setButtonTintList(ColorStateList.valueOf(Color.BLACK));

                radioButPdaPreYes.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButPdaCurYes.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButPdaPreNo.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButPdaCurNo.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButPionPreYes.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButPionCurYes.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButPionPreNo.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButPionCurNo.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
            }

            checkBoxRice.setTextColor(Color.BLACK);
            checkBoxCorn.setTextColor(Color.BLACK);
            checkBoxMillet.setTextColor(Color.BLACK);
            checkBoxMustard.setTextColor(Color.BLACK);

            radioButPdaPreYes.setTextColor(Color.BLACK);
            radioButPdaCurYes.setTextColor(Color.BLACK);
            radioButPdaPreNo.setTextColor(Color.BLACK);
            radioButPdaCurNo.setTextColor(Color.BLACK);
            radioButPionPreYes.setTextColor(Color.BLACK);
            radioButPionCurYes.setTextColor(Color.BLACK);
            radioButPionPreNo.setTextColor(Color.BLACK);
            radioButPionCurNo.setTextColor(Color.BLACK);

            /*edtTotalAcresPYear.setTextColor(Color.BLACK);
            edtTotalAcresCYear.setTextColor(Color.BLACK);
            edtPhiAcresPYear.setTextColor(Color.BLACK);
            edtPhiAcresCYear.setTextColor(Color.BLACK);
            edtTargetAcresPYear.setTextColor(Color.BLACK);
            edtTargetAcresCYear.setTextColor(Color.BLACK);
            edtTargerHybrid.setTextColor(Color.BLACK);
            edtFarmerName.setTextColor(Color.BLACK);
            edtFarmerMobNo.setTextColor(Color.BLACK);


            edtTotalAcresPYear.setBackgroundResource(R.drawable.textfield_bg_lite);
            edtTotalAcresCYear.setBackgroundResource(R.drawable.textfield_bg_lite);
            edtPhiAcresPYear.setBackgroundResource(R.drawable.textfield_bg_lite);
            edtPhiAcresCYear.setBackgroundResource(R.drawable.textfield_bg_lite);
            edtTargetAcresPYear.setBackgroundResource(R.drawable.textfield_bg_lite);
            edtTargetAcresCYear.setBackgroundResource(R.drawable.textfield_bg_lite);

            edtFarmerName.setBackgroundResource(R.drawable.textfield_bg_lite);
            edtFarmerMobNo.setBackgroundResource(R.drawable.textfield_bg_lite);*/

            rlTraget.setBackgroundResource(R.drawable.textfield_bg_lite);

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
            //layoutPht.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        }
    }

    private void initializeViews() {


        profileImageFarm = (ImageView) findViewById(R.id.ph_profile_farmer_image);
        imageCaptureFarm = (ImageView) findViewById(R.id.ph_profile_farmer_capture);

        tvRadioBtnPda = (TextView) findViewById(R.id.ph_pda_attended_l);
        tvRadioBtnPion = (TextView) findViewById(R.id.ph_pion_attended_l);
        tvTotalAcres = (TextView) findViewById(R.id.ph_total_acres_farm_l);
        tvPhiAcres = (TextView) findViewById(R.id.ph_phi_acres_farm_l);
        tvTargetAcres = (TextView) findViewById(R.id.ph_target_acres_farm_l);
        tvCrop = (TextView) findViewById(R.id.ph_crop_farm_l);
        tvTargerHybrid = (TextView) findViewById(R.id.ph_farm_target_hybrid_l);
        tvPreviousYear = (TextView) findViewById(R.id.ph_pY_farmer);
        tvCurrentYear = (TextView) findViewById(R.id.ph_cY_farmer);

        edtTotalAcresPYear = (EditText) findViewById(R.id.ph_total_acres_farm_pY);
        edtTotalAcresCYear = (EditText) findViewById(R.id.ph_total_acres_farm_cY);
        edtPhiAcresPYear = (EditText) findViewById(R.id.ph_phi_acres_farm_pY);
        edtPhiAcresCYear = (EditText) findViewById(R.id.ph_phi_acres_farm_cY);
        edtTargetAcresPYear = (EditText) findViewById(R.id.ph_target_acres_farm_pY);
        edtTargetAcresCYear = (EditText) findViewById(R.id.ph_target_acres_farm_cY);
        edtTargerHybrid = (EditText) findViewById(R.id.ph_farm_target_hybrid);

        checkBoxCorn = (CheckBox) findViewById(R.id.ph_farm_checkbox_cron);
        checkBoxRice = (CheckBox) findViewById(R.id.ph_farm_checkbox_rice);
        checkBoxMillet = (CheckBox) findViewById(R.id.ph_farm_checkbox_millet);
        checkBoxMustard = (CheckBox) findViewById(R.id.ph_farm_checkbox_mustard);
        edtTargerHybrid = (EditText) findViewById(R.id.ph_farm_target_hybrid);
        btnFarSubmit = (Button) findViewById(R.id.ph_farm_submit);
        layoutClear = (LinearLayout) findViewById(R.id.ph_farm_layout_clear);
        layoutPlus = (LinearLayout) findViewById(R.id.ph_farm_layout_plus);
        mainLayout = (LinearLayout) findViewById(R.id.ph_main_layout_farmer);

        radioGroPdaPre = (RadioGroup) findViewById(R.id.ph_pda_radio_pre);
        radioGroPdaCurr = (RadioGroup) findViewById(R.id.ph_pda_radio_curr);
        radioGroPionPre = (RadioGroup) findViewById(R.id.ph_pion_radio_pre);
        radioGroPionCurr = (RadioGroup) findViewById(R.id.ph_pion_radio_curr);

        radioButPdaPreYes = (RadioButton) findViewById(R.id.ph_farm_pda_pre_yes);
        radioButPdaPreNo = (RadioButton) findViewById(R.id.ph_farm_pda_pre_no);
        radioButPdaCurYes = (RadioButton) findViewById(R.id.ph_farm_pda_curr_yes);
        radioButPdaCurNo = (RadioButton) findViewById(R.id.ph_farm_pda_curr_no);
        radioButPionPreYes = (RadioButton) findViewById(R.id.ph_farm_pion_pre_yes);
        radioButPionPreNo = (RadioButton) findViewById(R.id.ph_farm_pion_pre_no);
        radioButPionCurYes = (RadioButton) findViewById(R.id.ph_farm_pion_curr_yes);
        radioButPionCurNo = (RadioButton) findViewById(R.id.ph_farm_pion_curr_no);
        //RelativeLayout
        rlTraget = (RelativeLayout) findViewById(R.id.rl_target_farmer);


        // newly added
        edtFarmerName = (EditText) findViewById(R.id.ph_farmer_farmerName);
        edtFarmerMobNo = (EditText) findViewById(R.id.ph_farm_farmerMobileNo);
        tvFarmName = (TextView) findViewById(R.id.ph_farm_farmerName_l);
        tvFarmMobileNo = (TextView) findViewById(R.id.ph_farm_farmerMobileNo_l);
        Calendar calendar = Calendar.getInstance();
        currentYear = calendar.get(Calendar.YEAR);
        previousYear = calendar.get(Calendar.YEAR) - 1;
        tvPreviousYear.setText(tvPreviousYear.getText().toString().replace("$1", String.valueOf(previousYear)));
        tvCurrentYear.setText(tvCurrentYear.getText().toString().replace("$1", String.valueOf(currentYear)));
        if (pravaktaFarmerData != null) {
            edtFarmerName.setText(pravaktaFarmerData.getFarmerName());
            edtFarmerMobNo.setText(pravaktaFarmerData.getFarmerMobileNo());
            if (pravaktaFarmerData.getPdaAttendPre().equalsIgnoreCase("YES"))
                radioButPdaPreYes.setChecked(true);
            if (pravaktaFarmerData.getPdaAttendPre().equalsIgnoreCase("NO"))
                radioButPdaPreNo.setChecked(true);
            if (pravaktaFarmerData.getPdaAttendCurr().equalsIgnoreCase("YES"))
                radioButPdaCurYes.setChecked(true);

            if (pravaktaFarmerData.getPionUserPre().equalsIgnoreCase("YES"))
                radioButPionPreYes.setChecked(true);

            if (pravaktaFarmerData.getPionUserPre().equalsIgnoreCase("NO"))
                radioButPionPreNo.setChecked(true);

            if (pravaktaFarmerData.getPionUserCurr().equalsIgnoreCase("NO"))
                radioButPionCurNo.setChecked(true);

            edtTotalAcresPYear.setText(pravaktaFarmerData.getTotalPreviousAcresFarm());
            edtTotalAcresCYear.setText(pravaktaFarmerData.getTotalPresentAcresFarm());
            edtPhiAcresPYear.setText(pravaktaFarmerData.getPhiPreviousAcresFarm());
            edtPhiAcresCYear.setText(pravaktaFarmerData.getPhiPresentAcresFarm());
            edtTargetAcresPYear.setText(pravaktaFarmerData.getTargetPreviousAcresFarm());
            edtTargetAcresCYear.setText(pravaktaFarmerData.getTargetPresentAcresFarm());

            if (pravaktaFarmerData.getCorn()) {
                checkBoxCorn.setChecked(true);
            }

            if (pravaktaFarmerData.getRice()) {
                checkBoxRice.setChecked(true);
            }

            if (pravaktaFarmerData.getMillet()) {
                checkBoxMillet.setChecked(true);
            }

            if (pravaktaFarmerData.getMustard()) {
                checkBoxMustard.setChecked(true);
            }
            edtTargerHybrid.setText(pravaktaFarmerData.getTargetHybridFarm());
        }
        setListeners();


    }

    private void setListeners() {

        btnFarSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    showAlertToSave();
                } else {
                    Utility.showAlert(PravaktaFarmerDataActivity.this, "", validation);
                }
            }
        });
        layoutClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtTargerHybrid.setText("");
                layoutClear.setVisibility(View.INVISIBLE);
                builder = null;
            }
        });
        layoutPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listTarget = new ArrayList<String>(Arrays.asList(edtTargerHybrid.getText().toString().split(",")));
                if (listTarget.size() > 4) {
                    DialogManager.showSingleBtnPopup(PravaktaFarmerDataActivity.this, null, getString(R.string.alert), getString(R.string.total_hybrid), getString(R.string.ok));
                } else {
                    showOTPPopup(PravaktaFarmerDataActivity.this);
                }
            }
        });
        imageCaptureFarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraPermission();
            }
        });

        profileImageFarm.setOnClickListener(new View.OnClickListener() { 
            @Override
            public void onClick(View v) {
                cameraPermission();
            }
        });

        radioButPdaCurNo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radioButPdaCurNo.isChecked()) {

                    DialogManager.showToast(getApplicationContext(), getString(R.string.curr_no_mdr_atte));
                   // Toast.makeText(PravaktaFarmerDataActivity.this, getResources().getString(R.string.curr_no_mdr_atte), Toast.LENGTH_LONG).show();

                }
            }
        });

        radioButPionCurYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radioButPionCurYes.isChecked()) {
                    DialogManager.showToast(getApplicationContext(), getString(R.string.curr_yes_mdr_pion));
                   // Toast.makeText(PravaktaFarmerDataActivity.this, getResources().getString(R.string.curr_yes_mdr_pion), Toast.LENGTH_LONG).show();

                }
            }
        });

    }

    private String getText(EditText editText) {

        return editText.getText().toString().trim();
    }

    private boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }

    private String validateFields() {
        if (isEmpty(edtFarmerName)) {
            return getResources().getString(R.string.farmernamentempty);
        }
        if (isEmpty(edtFarmerMobNo)) {
            return getResources().getString(R.string.mobilenonyempty);
        }
        if (getText(edtFarmerMobNo).length() != 10) {
            return getResources().getString(R.string.validmobilenum);
        }

        if (radioGroPdaPre.getCheckedRadioButtonId() == -1) {
            return getResources().getString(R.string.select_pda_pre);
        }
        if (radioGroPdaCurr.getCheckedRadioButtonId() == -1) {
            return getResources().getString(R.string.select_pda_cur);
        }
        if (radioButPdaCurNo.isChecked()) {
            return getResources().getString(R.string.curr_no_mdr_atte);
        }
        if (radioGroPionPre.getCheckedRadioButtonId() == -1) {
            return getResources().getString(R.string.select_pion_pre);
        }
        if (radioGroPionCurr.getCheckedRadioButtonId() == -1) {
            return getResources().getString(R.string.select_pion_curr);

        }
        if (radioButPionCurYes.isChecked()) {
            return getResources().getString(R.string.curr_yes_mdr_pion);
        }
        if (isEmpty(edtTotalAcresPYear)) {
            return getResources().getString(R.string.totalacresnameempty);
        }
        if (isEmpty(edtTotalAcresCYear)) {
            return getResources().getString(R.string.totalacrescurrentnameempty);
        }

        if (isEmpty(edtPhiAcresPYear)) {
            return getResources().getString(R.string.phiacresnameempty);
        }

        if (isEmpty(edtPhiAcresCYear)) {
            return getResources().getString(R.string.phiacrescurrentnameempty);
        }
        if (Integer.valueOf(getText(edtPhiAcresPYear)) > Integer.valueOf(getText(edtTotalAcresPYear)))
            return getString(R.string.tot_acre_pre);

        if (Integer.valueOf(getText(edtPhiAcresCYear)) > Integer.valueOf(getText(edtTotalAcresCYear)))
            return getString(R.string.tot_acre_cur);

        if (isEmpty(edtTargetAcresPYear)) {
            return getResources().getString(R.string.targetacresnameempty);
        }
        if (isEmpty(edtTargetAcresCYear)) {
            return getResources().getString(R.string.targetacrescurrentnameempty);
        }
        if (Integer.valueOf(getText(edtTargetAcresPYear)) > Integer.valueOf(getText(edtTotalAcresPYear)))
            return getString(R.string.total_acr_pre);
        if (Integer.valueOf(getText(edtTargetAcresCYear)) > Integer.valueOf(getText(edtTotalAcresCYear))) {
            return getString(R.string.total_acr_cur);
        }

        if (!(checkBoxCorn.isChecked() || checkBoxRice.isChecked() || checkBoxMillet.isChecked() || checkBoxMustard.isChecked())) {
            return getResources().getString(R.string.check_any_crop);
        }
        if (isEmpty(edtTargerHybrid)) {
            return getResources().getString(R.string.targerHybridnamentempty);
        }
        return "";
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(PravaktaFarmerDataActivity.this);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                saveData();
            }


        });

        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }


    private String radioButtonText(RadioGroup group) {
        if (group != null) {
            int id = group.getCheckedRadioButtonId();
            RadioButton btn = (RadioButton) group.findViewById(id);
            String selection = (String) btn.getText();
            if (selection != null && !selection.isEmpty())
                return (selection);
            else return "";
        }
        return "";
    }

    private void saveData() {

        // List<DTO> avalibleRecordsList = PravaktaFarmerDAO.getInstance().getRecordInfoByValue("activityId", "" + activityId, DBHandler.getInstance(PravaktaFarmerDataActivity.this).getDBObject(0));
        List<PravaktaFarmerDTO> dtoList = new ArrayList<PravaktaFarmerDTO>();
        PravaktaFarmerDTO dto = new PravaktaFarmerDTO();
        dto.setFarmerName(edtFarmerName.getText().toString().trim());
        dto.setFarmerMobileNo(edtFarmerMobNo.getText().toString().trim());
        dto.setPdaAttendPre(radioButtonText(radioGroPdaPre));
        dto.setPdaAttendCurr(radioButtonText(radioGroPdaCurr));
        dto.setPionUserPre(radioButtonText(radioGroPionPre));
        dto.setPionUserCurr(radioButtonText(radioGroPionCurr));
        dto.setPreviousYear(String.valueOf(previousYear));
        dto.setCurrentYear(String.valueOf(currentYear));
        dto.setTotalPreviousAcresFarm(edtTotalAcresPYear.getText().toString().trim());
        dto.setTotalPresentAcresFarm(edtTotalAcresCYear.getText().toString().trim());
        dto.setPhiPreviousAcresFarm(edtPhiAcresPYear.getText().toString().trim());
        dto.setPhiPresentAcresFarm(edtPhiAcresCYear.getText().toString().trim());
        dto.setTargetPreviousAcresFarm(edtTargetAcresPYear.getText().toString().trim());
        dto.setTargetPresentAcresFarm(edtTargetAcresCYear.getText().toString().trim());
        if (checkBoxCorn.isChecked())
            dto.setCorn(true);
        if (checkBoxRice.isChecked())
            dto.setRice(true);
        if (checkBoxMillet.isChecked())
            dto.setMillet(true);
        if (checkBoxMustard.isChecked())
            dto.setMustard(true);
        dto.setTargetHybridFarm(edtTargerHybrid.getText().toString().trim());
        dto.setActivityId(activityId);
        dto.setImageUrlPath(imagePath);
        dtoList.add(dto);
        boolean inserted = PravaktaFarmerDAO.getInstance().insert(dto, DBHandler.getInstance(PravaktaFarmerDataActivity.this).getDBObject(1));

        if (inserted) {
            Toast.makeText(PravaktaFarmerDataActivity.this, "Successfully Saved", Toast.LENGTH_SHORT).show();
            if (dtoList.size() > 0) {
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
            }
            //  finish();
            //  clearFields();
        } else {
            Toast.makeText(PravaktaFarmerDataActivity.this, "Failed to save", Toast.LENGTH_SHORT).show();

        }
    }

    private void clearFields() {
        edtFarmerName.setText("");
        edtFarmerMobNo.setText("");
        radioGroPdaPre.clearCheck();
        radioGroPdaCurr.clearCheck();
        radioGroPionPre.clearCheck();
        radioGroPionCurr.clearCheck();
        edtTotalAcresPYear.setText("");
        edtTotalAcresCYear.setText("");
        edtPhiAcresPYear.setText("");
        edtPhiAcresCYear.setText("");
        edtTargetAcresPYear.setText("");
        edtTargetAcresCYear.setText("");
        edtTargerHybrid.setText("");
        if (checkBoxRice.isChecked())
            checkBoxRice.setChecked(false);
        if (checkBoxCorn.isChecked())
            checkBoxCorn.setChecked(false);
        if (checkBoxMustard.isChecked())
            checkBoxMustard.setChecked(false);
        if (checkBoxMillet.isChecked())
            checkBoxMillet.setChecked(false);
    }

    /*private boolean insertData(List<PravaktaFarmerDTO> list) {
        for (PravaktaFarmerDTO dto : list) {
            PravaktaFarmerDAO.getInstance().insert(dto, DBHandler.getInstance(PravaktaFarmerDataActivity.this).getDBObject(1));
        }
        return true;
    }*/

    private void showOTPPopup(final Context mContex) {
        final Button mokBtn, mcancelBtn;
        final TextView mTextView;
        final EditText mEditText;
        final Dialog mDialog;
        mDialog = new Dialog(mContex);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.pravakta_farmer_popup_btn);
        //  final Dialog mDialog = Utility.getDialog(mContext, R.layout.big_farmer_popup_btn);
        mDialog.setCancelable(true);
        mDialog.setCanceledOnTouchOutside(true);
        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.rc_parent_view_for_font);

        mTextView = (TextView) mDialog.findViewById(R.id.tv_question);
        mEditText = (EditText) mDialog.findViewById(R.id.edt_comment_no);
        mokBtn = (Button) mDialog.findViewById(R.id.btn_ok);
        mcancelBtn = (Button) mDialog.findViewById(R.id.cancel_btn);
        mTextView.setText(tvTargerHybrid.getText().toString());
        mcancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mokBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (getText(mEditText).isEmpty()) {
                    DialogManager.showToast(getApplicationContext(), getString(R.string.min_char));
                } else {
                    if (builder == null) {
                        builder = new StringBuilder();
                    } else {
                        builder.append(",");
                    }
                    builder.append(mEditText.getText().toString().trim());
                    edtTargerHybrid.setText(builder);
                    layoutClear.setVisibility(View.VISIBLE);
                    mDialog.dismiss();
                }
            }
        });
        mDialog.show();
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(pravaktaFarmerDataActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(pravaktaFarmerDataActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new androidx.appcompat.app.AlertDialog.Builder(pravaktaFarmerDataActivity)
                        .setTitle(getString(R.string.permission_location_title))
                        .setMessage(getString(R.string.permission_location_body))
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(pravaktaFarmerDataActivity,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(pravaktaFarmerDataActivity,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    private void cameraPermission() {
        File newfile = createFile();

        if (!Utility.isValidStr(imagePath)) {
            openCameraApp(newfile);
        } else {
            showOptionOpenCameraforPravakta(null, pravaktaFarmerDataActivity, newfile);
        }
    }

    public void openCameraApp(File newfile) {
        /*String root = Environment.getExternalStorageDirectory().toString();
//		File myDir = new File(root + File.separator+"Fatima_OC_TEST");
		File myDir = new File(root + File.separator+"CropDiagnosis");
//		File myDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);

		if(!myDir.exists())
			myDir.mkdirs();

		File newfile = new File(myDir, "IMG_"+System.currentTimeMillis()+".JPG");
		try {
			newfile.createNewFile();
		} catch (IOException e) {}*/

        Uri outputFileUri = Uri.fromFile(newfile);
        String uriString = outputFileUri.toString();

        Intent intent = new Intent(pravaktaFarmerDataActivity, MainActivityOC.class);
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE); // without this not working, not getting data only
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        startActivityForResult(intent, OPENCAMERA);
    }

    private File createFile() {
//        String root = Environment.getExternalStorageDirectory().toString();
        String dirPath = getFilesDir().getAbsolutePath();//Environment.getExternalStorageDirectory().toString();
        dirPath = dirPath + File.separator + "Files";
        myDir = new File(dirPath + File.separator + "PravathaGainImage");
        if (!myDir.exists())
            myDir.mkdirs();

        File newfile = new File(myDir, "IMG_" + System.currentTimeMillis() + ".JPG");
        try {
            newfile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return newfile;
    }


    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(pravaktaFarmerDataActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(pravaktaFarmerDataActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(pravaktaFarmerDataActivity, Manifest.permission.CAMERA) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(pravaktaFarmerDataActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(pravaktaFarmerDataActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(pravaktaFarmerDataActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, getString(R.string.permission_camera_storage_title), getString(R.string.permission_camera_storage_euipment_body), getString(R.string.ok), getString(R.string.cancel));

            } else {
                // No explanation needed, we can request the permission.
                if (Utility.isFirstTimeCamera(pravaktaFarmerDataActivity)) {

                    DialogManager.showConformPopup(pravaktaFarmerDataActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            Utility.setFirstTimeCamera(false, pravaktaFarmerDataActivity);
                            ActivityCompat.requestPermissions(pravaktaFarmerDataActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.permission_camera_storage_title), getString(R.string.permission_camera_storage_euipment_body), getString(R.string.ok), getString(R.string.cancel));


                } else {
                    ActivityCompat.requestPermissions(pravaktaFarmerDataActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }

        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            //ProfileImageSelectionUtil.showOption(null, mActivity);
                            openCameraApp(newfile);
                        else
                            checkPermission();
                    } else {
                        openCameraApp(newfile);
                        //ProfileImageSelectionUtil.showOption(null, mActivity);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
            break;
            case REQUEST_CAMERA_PERMISSION_DENAIL: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            openCameraApp(newfile);
                        else
                            showDialogToOpenSetting();
                    } else {

                        openCameraApp(newfile);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    showDialogToOpenSetting();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }

        }

    }


    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(pravaktaFarmerDataActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(pravaktaFarmerDataActivity, pravaktaFarmerDataActivity.getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {

        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", pravaktaFarmerDataActivity.getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        pravaktaFarmerDataActivity.finish();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == OPENCAMERA) {
            if (resultCode == RESULT_OK) {
                try {/*
//                    uriStr = (Uri) data.getExtras().get("data");
                    Uri uriStrTremp = (Uri) data.getExtras().get("data");  // if we captured new pic but not cropped, thn showing old pic in imageView but when we click on see full photo thn new pic is shown. thats why created local variable

                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(pravaktaFarmerDataActivity.getContentResolver(), uriStrTremp);

                    if (bitmap != null) {
                        String imagePath = storeImage(bitmap, "profile" + "_");
                        Uri mCapturedUri = Uri.fromFile(new File(imagePath));

//                        new Crop(mCapturedUri).output(uriStr).asSquare().start(pravaktaFarmerDataActivity);
                        Intent gotoCropImage = new Intent(PravaktaFarmerDataActivity.this, ATCropMyImageActivity.class);
                        gotoCropImage.setData(uriStrTremp);
                        startActivityForResult(gotoCropImage, REQUEST_CODE_FOR_IMAGE_CROPPING);
                    }*/

                    mExecutor = Executors.newSingleThreadExecutor();
                    Uri myUri = (Uri) data.getExtras().get("data");
                    uriStr = myUri;
                    mExecutor.submit(new LoadScaledImageTask(PravaktaFarmerDataActivity.this, myUri, profileImageFarm, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                    imagePath = myUri.toString();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (resultCode == RESULT_CANCELED) {
                // user cancelled Image capture
                DialogManager.showToast(pravaktaFarmerDataActivity, getString(R.string.user_cancelled_image_capture));
            } else {
                // failed to capture image
                DialogManager.showToast(pravaktaFarmerDataActivity, getString(R.string.failed_to_capture_image));
            }
        } else if (requestCode == Crop.REQUEST_CROP
                && resultCode == RESULT_OK) {

            try {
                // get the returned data
                Bundle extras = data.getExtras();
                // get the cropped bitmap
                Uri thePic = extras.getParcelable(MediaStore.EXTRA_OUTPUT);

                if (thePic == null)
                    return;
                profileImageFarm.setImageBitmap(null);

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(pravaktaFarmerDataActivity.getContentResolver(), thePic);

                profileImageFarm.setImageBitmap(bitmap);

//                imageTypedFile = new TypedFile("multipart/form-data", new File(thePic.toString().substring(7)));

                imagePath = thePic.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (requestCode == REQUEST_CODE_FOR_IMAGE_CROPPING ){
            if (resultCode == RESULT_OK ) {
                mExecutor = Executors.newSingleThreadExecutor();
                Uri myUri = data.getData();
                uriStr = myUri;
                mExecutor.submit(new LoadScaledImageTask(PravaktaFarmerDataActivity.this, myUri, profileImageFarm, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                imagePath = myUri.toString();
            } else if (resultCode == RESULT_CANCELED){

                DialogManager.showToast(PravaktaFarmerDataActivity.this, getString(R.string.at_user_cancelled_image_cropping));
            }
        }
    }

    private String storeImage(Bitmap image, String fileName) {
        File pictureFile = getOutputMediaFile(fileName);
        if (pictureFile == null) {
            // Log.d(TAG,
            // "Error creating media file, check storage permissions: ");//
            // e.getMessage());
            return "";
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.JPEG, 80, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            // Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            // Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
        System.out.println("Path:" + pictureFile.getAbsolutePath());
        return pictureFile.getAbsolutePath();
    }

    /**
     * Create a File for saving an image or video
     */
    private File getOutputMediaFile(String fileName) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(
                Environment.getExternalStorageDirectory() + "/Android/data/"
                        + pravaktaFarmerDataActivity.getPackageName() + "/Files");

        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }
        // Create a media file name

        File mediaFile;
        String mImageName = "ActivityTracker_" + fileName + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator
                + mImageName);
        return mediaFile;
    }

    private void showOptionOpenCameraforPravakta(String title, final FragmentActivity context, final File newfile) {
        final Dialog mDialog;
        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.paravakta_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mRemovePhoto, mViewPhoto;
        Button mCancel;
        TextView mTitile = (TextView) mDialog.findViewById(R.id.alertTitle);
        if (Utility.isValidStr(title))
            mTitile.setText(title);
        mFromCamera = (TextView) mDialog.findViewById(R.id.from_camera);
        mRemovePhoto = (TextView) mDialog.findViewById(R.id.remove_photo);
        mViewPhoto = (TextView) mDialog.findViewById(R.id.view_image) ;

        mCancel = (Button) mDialog.findViewById(R.id.cancel);

        mFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                openCameraApp(newfile);
            }
        });
        mRemovePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                profileImageFarm.setImageResource(R.drawable.img_profile_avatar);
                uriStr = null;
                imagePath = null;
            }
        });

        mViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                if (profileImageFarm.getDrawable() != null) {
                    if (uriStr != null) {
                        ImageViewer(PravaktaFarmerDataActivity.this, uriStr.toString());
                    }
                }
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        if (isDataAvaliable()) {
            showAlertToExitScreen();
        } else {
            finish();
        }

    }

    private boolean isDataAvaliable() {
        if (imagePath != null)
            return true;

        if (edtFarmerName.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtFarmerMobNo.getText().toString().trim().length() > 0) {
            return true;
        }

        if (radioButPdaPreYes.isChecked()) {
            return true;
        }
        if (radioButPdaPreNo.isChecked()) {
            return true;
        }
        if (radioButPdaCurYes.isChecked()) {
            return true;
        }
        if (radioButPdaCurNo.isChecked()) {
            return true;
        }
        if (radioButPionPreYes.isChecked()) {
            return true;
        }
        if (radioButPionPreNo.isChecked()) {
            return true;
        }
        if (radioButPionCurYes.isChecked()) {
            return true;
        }
        if (radioButPionCurNo.isChecked()) {
            return true;
        }


        if (edtTotalAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtTotalAcresCYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtPhiAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtPhiAcresCYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtTargetAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtTargetAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (checkBoxCorn.isChecked() || checkBoxRice.isChecked() || checkBoxMillet.isChecked() || checkBoxMustard.isChecked()) {
            return true;
        }
        if (edtTargerHybrid.getText().toString().trim().length() > 0) {
            return true;
        }
        return false;
    }

    private void showAlertToExitScreen() {
        AlertDialog.Builder builder = new AlertDialog.Builder(PravaktaFarmerDataActivity.this);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                //mActivity.onBackPressedCallBack(callbackCode);
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    //View full Image
    public void ImageViewer(Context context, final String imgUrl) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.image_viewer, null);

        ViewGroup root = (ViewGroup) layout
                .findViewById(R.id.main_activity_view);

        final Dialog imageDialog = new Dialog(context,
                android.R.style.Theme_Translucent_NoTitleBar);
        imageDialog.setContentView(layout);
        ImageView closeBtn = (ImageView) imageDialog
                .findViewById(R.id.closeBtn);
        ImageView editBtn = (ImageView) imageDialog.findViewById(R.id.editBtn);
        editBtn.setVisibility(View.VISIBLE);
        ImageView save_btn = (ImageView) imageDialog
                .findViewById(R.id.save_btn);
        ImageView imageview = (ImageView) imageDialog
                .findViewById(R.id.imageview);
        if (imgUrl != null && !imgUrl.isEmpty()) {
            Glide.with(this).load(imgUrl).placeholder(R.drawable.loadinggg).error(R.drawable.image_not_exist).into(imageview);
        }
        editBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                imageDialog.dismiss();
            }
        });
        imageDialog.show();

    }
    // from 1276- 1316 , related to cropping image funcationality
    public static class LoadScaledImageTask implements Runnable {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        Context context;
        Uri uri;
        ImageView imageView;
        int width;

        public LoadScaledImageTask(Context context, Uri uri, ImageView imageView, int width) {
            this.context = context;
            this.uri = uri;
            this.imageView = imageView;
            this.width = width;
        }
        @Override
        public void run() {
            final int exifRotation = com.isseiaoki.simplecropview.util.Utils.getExifOrientation(context, uri);
            int maxSize = com.isseiaoki.simplecropview.util.Utils.getMaxSize();
            int requestSize = Math.min(width, maxSize);
            try {
                final Bitmap sampledBitmap = com.isseiaoki.simplecropview.util.Utils.decodeSampledBitmapFromUri(context, uri, requestSize);
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        imageView.setImageMatrix(com.isseiaoki.simplecropview.util.Utils.getMatrixFromExifOrientation(exifRotation));
                        imageView.setImageBitmap(sampledBitmap);
                    }
                });
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    private int calcImageSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        Display display =getWindowManager().getDefaultDisplay();
        display.getMetrics(metrics);
        return Math.min(Math.max(metrics.widthPixels, metrics.heightPixels), 2048);
    }

}
