package com.activitytrack.dtos;

public class ThreeIDTO implements DTO
{
 
	private long mobileId;
	private  Long retailerMobileNo;
	private String retailerFirmName;
	private int threeIPhaseNo; 
	private String date;
	private String location;
	private int isSync;
	private long regionId;
	
	private String uploadedDate;
	
	public int getThreeIPhaseNo() {
		return threeIPhaseNo;
	}
	public void setThreeIPhaseNo(int threeIPhaseNo) {
		this.threeIPhaseNo = threeIPhaseNo;
	}
	public long getId() {
		return mobileId;
	}
	public void setId(long id) {
		this.mobileId = id;
	}
	public Long getRetailerMobileNo() {
		return retailerMobileNo;
	}
	public void setRetailerMobileNo(Long retailerMobileNo) {
		this.retailerMobileNo = retailerMobileNo;
	}
	public String getRetailersFirmName() {
		return retailerFirmName;
	}
	public void setRetailersFirmName(String retailersFirmName) {
		this.retailerFirmName = retailersFirmName;
	}
	 
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getIsSync() {
		return isSync;
	}
	public void setIsSync(int isSync) {
		this.isSync = isSync;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getRetailerFirmName() {
		return retailerFirmName;
	}
	public void setRetailerFirmName(String retailerFirmName) {
		this.retailerFirmName = retailerFirmName;
	}
	public long getRegionId() {
		return regionId;
	}
	public void setRegionId(long regionId) {
		this.regionId = regionId;
	}

}
