package com.activitytrack.dtos;

public class FarmerSchoolSilageDTO implements DTO {
    private long id;
    private String year;
    private String mobileNo;
    private String pincode;
    private String farmerName;
    private String district;
    private String village;
    private String block;
    private String geoLocation;
    private String localImagePath;
    private String isTBL;
    private String date;
    private int isSync;
    private long mobileId;

    private long devCenterId;
    private long schoolId;
    private int totalNoOfCattles;
    private int avgMilkYield;
    private String silageFeeding;
    private String growingOrProcuring;
    private int silageAcres;
    private String currHyb1Name;
    private String currHyb1Value;
    private String currHyb2Name;
    private String currHyb2Value;
    private String currHyb3Name;
    private String currHyb3Value;
    private String currHyb4Name;
    private String currHyb4Value;
    private String currHyb5Name;
    private String currHyb5Value;
    private String trainingPlant;
    private String trainingGrow;
    private String trainingHarvest;
    private String trainingStore;
    private String trainingFeed;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public String getLocalImagePath() {
        return localImagePath;
    }

    public void setLocalImagePath(String localImagePath) {
        this.localImagePath = localImagePath;
    }

    public String getIsTBL() {
        return isTBL;
    }

    public void setIsTBL(String isTBL) {
        this.isTBL = isTBL;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public long getMobileId() {
        return mobileId;
    }

    public void setMobileId(long mobileId) {
        this.mobileId = mobileId;
    }

    public long getDevCenterId() {
        return devCenterId;
    }

    public void setDevCenterId(long devCenterId) {
        this.devCenterId = devCenterId;
    }

    public long getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(long schoolId) {
        this.schoolId = schoolId;
    }

    public int getTotalNoOfCattles() {
        return totalNoOfCattles;
    }

    public void setTotalNoOfCattles(int totalNoOfCattles) {
        this.totalNoOfCattles = totalNoOfCattles;
    }

    public int getAvgMilkYield() {
        return avgMilkYield;
    }

    public void setAvgMilkYield(int avgMilkYield) {
        this.avgMilkYield = avgMilkYield;
    }

    public String getSilageFeeding() {
        return silageFeeding;
    }

    public void setSilageFeeding(String silageFeeding) {
        this.silageFeeding = silageFeeding;
    }

    public String getGrowingOrProcuring() {
        return growingOrProcuring;
    }

    public void setGrowingOrProcuring(String growingOrProcuring) {
        this.growingOrProcuring = growingOrProcuring;
    }

    public int getSilageAcres() {
        return silageAcres;
    }

    public void setSilageAcres(int silageAcres) {
        this.silageAcres = silageAcres;
    }

    public String getCurrHyb1Name() {
        return currHyb1Name;
    }

    public void setCurrHyb1Name(String currHyb1Name) {
        this.currHyb1Name = currHyb1Name;
    }

    public String getCurrHyb1Value() {
        return currHyb1Value;
    }

    public void setCurrHyb1Value(String currHyb1Value) {
        this.currHyb1Value = currHyb1Value;
    }

    public String getCurrHyb2Name() {
        return currHyb2Name;
    }

    public void setCurrHyb2Name(String currHyb2Name) {
        this.currHyb2Name = currHyb2Name;
    }

    public String getCurrHyb2Value() {
        return currHyb2Value;
    }

    public void setCurrHyb2Value(String currHyb2Value) {
        this.currHyb2Value = currHyb2Value;
    }

    public String getCurrHyb3Name() {
        return currHyb3Name;
    }

    public void setCurrHyb3Name(String currHyb3Name) {
        this.currHyb3Name = currHyb3Name;
    }

    public String getCurrHyb3Value() {
        return currHyb3Value;
    }

    public void setCurrHyb3Value(String currHyb3Value) {
        this.currHyb3Value = currHyb3Value;
    }

    public String getCurrHyb4Name() {
        return currHyb4Name;
    }

    public void setCurrHyb4Name(String currHyb4Name) {
        this.currHyb4Name = currHyb4Name;
    }

    public String getCurrHyb4Value() {
        return currHyb4Value;
    }

    public void setCurrHyb4Value(String currHyb4Value) {
        this.currHyb4Value = currHyb4Value;
    }

    public String getCurrHyb5Name() {
        return currHyb5Name;
    }

    public void setCurrHyb5Name(String currHyb5Name) {
        this.currHyb5Name = currHyb5Name;
    }

    public String getCurrHyb5Value() {
        return currHyb5Value;
    }

    public void setCurrHyb5Value(String currHyb5Value) {
        this.currHyb5Value = currHyb5Value;
    }

    public String getTrainingPlant() {
        return trainingPlant;
    }

    public void setTrainingPlant(String trainingPlant) {
        this.trainingPlant = trainingPlant;
    }

    public String getTrainingGrow() {
        return trainingGrow;
    }

    public void setTrainingGrow(String trainingGrow) {
        this.trainingGrow = trainingGrow;
    }

    public String getTrainingHarvest() {
        return trainingHarvest;
    }

    public void setTrainingHarvest(String trainingHarvest) {
        this.trainingHarvest = trainingHarvest;
    }

    public String getTrainingStore() {
        return trainingStore;
    }

    public void setTrainingStore(String trainingStore) {
        this.trainingStore = trainingStore;
    }

    public String getTrainingFeed() {
        return trainingFeed;
    }

    public void setTrainingFeed(String trainingFeed) {
        this.trainingFeed = trainingFeed;
    }
}
