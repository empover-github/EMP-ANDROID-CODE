package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.DipstickDTO;
import com.activitytrack.models.DipstickDashboardCounts;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class DipstickDAO implements DAO {

    private final String TAG = "PDADAO";
    private static DipstickDAO dipstickDAO;

    public static DipstickDAO getInstance() {
        if (dipstickDAO == null) {
            dipstickDAO = new DipstickDAO();
        }

        return dipstickDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        return null;
    }

    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    public List<DTO> getRecordInfoByMobileNo(String columnValue, SQLiteDatabase dbObject) {
        return null;
    }

    public DipstickDTO getRecordInfoForPhase(String phase, String year, long seasonId, long cropId, String mobileNo, SQLiteDatabase dbObject) {
        DipstickDTO dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM DIPSTICK where activityType='" + phase + "' and year='" + year + "' and seasonId='" + seasonId + "' and cropId='" + cropId + "' and farmerNumber='" + mobileNo + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                	/*DIPSTICK_MASTER
        			id 
        			activityType
        			year
        			seasonId
        			cropId
        			isSampleIssued
        			hybridId
        			farmerName
        			farmerNumber
        			cropAcres
        			hybridCropAcres
        			otherCropAcres
        			pioneerHyb1
        			pioneerHyb2
        			competitorHybrid1
        			competitorHybrid2
        			competitorHybrid3
        			competitorHybrid4
        			competitorHybrid5
        			date
        			regionId
        			location
        			isSync
        			uploadedDate
        			pioneerHyb1Name
        			pioneerHyb2Name
        			userType
        			f2Acreages*/
                    dto = new DipstickDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setActivityType(cursor.getString(cursor.getColumnIndex("activityType")));
                    dto.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setIsSampleIssued(cursor.getInt(cursor.getColumnIndex("isSampleIssued")) > 0 ? true : false);
                    dto.setHybridId(cursor.getLong(cursor.getColumnIndex("hybridId")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setFarmerNumber(cursor.getString(cursor.getColumnIndex("farmerNumber")));
                    dto.setCropAcres(cursor.getFloat(cursor.getColumnIndex("cropAcres")));
                    dto.setHybridCropAcres(cursor.getFloat(cursor.getColumnIndex("hybridCropAcres")));
                    dto.setOtherCropAcres(cursor.getFloat(cursor.getColumnIndex("otherCropAcres")));
                    dto.setPioneerHyb1(cursor.getFloat(cursor.getColumnIndex("pioneerHyb1")));
                    dto.setPioneerHyb2(cursor.getFloat(cursor.getColumnIndex("pioneerHyb2")));
                    dto.setPioneerHyb3(cursor.getFloat(cursor.getColumnIndex("pioneerHyb3")));
                    dto.setPioneerHyb4(cursor.getFloat(cursor.getColumnIndex("pioneerHyb4")));
                    dto.setCompetitorHybrid1(cursor.getFloat(cursor.getColumnIndex("competitorHybrid1")));
                    dto.setCompetitorHybrid2(cursor.getFloat(cursor.getColumnIndex("competitorHybrid2")));
                    dto.setCompetitorHybrid3(cursor.getFloat(cursor.getColumnIndex("competitorHybrid3")));
                    dto.setCompetitorHybrid4(cursor.getFloat(cursor.getColumnIndex("competitorHybrid4")));
                    dto.setCompetitorHybrid5(cursor.getFloat(cursor.getColumnIndex("competitorHybrid5")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setRegionId(cursor.getLong(cursor.getColumnIndex("regionId")));
                    dto.setLocation(cursor.getString(cursor.getColumnIndex("location")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setUploadedDate(cursor.getString(cursor.getColumnIndex("uploadedDate")));
                    dto.setPioneerHyb1Name(cursor.getString(cursor.getColumnIndex("pioneerHyb1Name")));
                    dto.setPioneerHyb2Name(cursor.getString(cursor.getColumnIndex("pioneerHyb2Name")));
                    dto.setPioneerHyb3Name(cursor.getString(cursor.getColumnIndex("pioneerHyb3Name")));
                    dto.setPioneerHyb4Name(cursor.getString(cursor.getColumnIndex("pioneerHyb4Name")));
                    dto.setCompetitorHybrid1Name(cursor.getString(cursor.getColumnIndex("competitorHybrid1Name")));
                    dto.setCompetitorHybrid2Name(cursor.getString(cursor.getColumnIndex("competitorHybrid2Name")));
                    dto.setCompetitorHybrid3Name(cursor.getString(cursor.getColumnIndex("competitorHybrid3Name")));
                    dto.setCompetitorHybrid4Name(cursor.getString(cursor.getColumnIndex("competitorHybrid4Name")));
                    dto.setCompetitorHybrid5Name(cursor.getString(cursor.getColumnIndex("competitorHybrid5Name")));
                    dto.setOtherCrop1(cursor.getLong(cursor.getColumnIndex("otherCrop1")));
                    dto.setOtherCrop2(cursor.getLong(cursor.getColumnIndex("otherCrop2")));
                    dto.setOtherCropArea1(cursor.getDouble(cursor.getColumnIndex("otherCropArea1")));
                    dto.setOtherCropArea2(cursor.getDouble(cursor.getColumnIndex("otherCropArea2")));
                    dto.setUserType(cursor.getString(cursor.getColumnIndex("userType")));
                    dto.setF2Acreages(cursor.getFloat(cursor.getColumnIndex("f2Acreages")));
                    dto.setSeedSettingIssue(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue")));

                    dto.setSeedSettingIssue1(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue1")));
                    dto.setSeedSettingIssue2(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue2")));
                    dto.setSeedSettingIssue3(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue3")));
                    dto.setSeedSettingIssue4(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue4")));

                    dto.setCompetitorHybrid1SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid1SeedSettingIssue")));
                    dto.setCompetitorHybrid2SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid2SeedSettingIssue")));

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            /*  ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return dto;
    }

    public DipstickDashboardCounts getDipstickDashboardCounts(String phase, String year, long seasonId, SQLiteDatabase dbObject) {
        DipstickDashboardCounts dto = null;
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id), sum(cropAcres), sum(hybridCropAcres), sum(pioneerHyb1), sum(pioneerHyb2),  FROM DIPSTICK where activityType='" + phase + "' and year='" + year + "' and seasonId='" + seasonId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    dto = new DipstickDashboardCounts();

                    dto.setNoOfFarmers(cursor.getLong(0));
                    dto.setTotalNoOfAcres(cursor.getLong(1));
                    dto.setTotalNoOfHybridAcres(cursor.getLong(2));
                    long totalPHIAcres = cursor.getLong(3) + cursor.getLong(4);
                    dto.setTotalPioneerHybridAcres(totalPHIAcres);


                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            /*  ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return dto;
    }

    public List<Long> getIdsByDate(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<Long> idsList = new ArrayList<Long>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "uploadedDate";

            cursor = dbObject.rawQuery("SELECT id FROM DIPSTICK where " + columnName + " < '" + columnValue + "' and isSync = '0' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    idsList.add(cursor.getLong(0));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            /* ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return idsList;
    }


    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM DIPSTICK ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DipstickDTO dto = new DipstickDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setActivityType(cursor.getString(cursor.getColumnIndex("activityType")));
                    dto.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setIsSampleIssued(cursor.getInt(cursor.getColumnIndex("isSampleIssued")) > 0 ? true : false);
                    dto.setHybridId(cursor.getLong(cursor.getColumnIndex("hybridId")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setFarmerNumber(cursor.getString(cursor.getColumnIndex("farmerNumber")));
                    dto.setCropAcres(cursor.getFloat(cursor.getColumnIndex("cropAcres")));
                    dto.setHybridCropAcres(cursor.getFloat(cursor.getColumnIndex("hybridCropAcres")));
                    dto.setOtherCropAcres(cursor.getFloat(cursor.getColumnIndex("otherCropAcres")));
                    dto.setPioneerHyb1(cursor.getFloat(cursor.getColumnIndex("pioneerHyb1")));
                    dto.setPioneerHyb2(cursor.getFloat(cursor.getColumnIndex("pioneerHyb2")));
                    dto.setPioneerHyb3(cursor.getFloat(cursor.getColumnIndex("pioneerHyb3")));
                    dto.setPioneerHyb4(cursor.getFloat(cursor.getColumnIndex("pioneerHyb4")));
                    dto.setCompetitorHybrid1(cursor.getFloat(cursor.getColumnIndex("competitorHybrid1")));
                    dto.setCompetitorHybrid2(cursor.getFloat(cursor.getColumnIndex("competitorHybrid2")));
                    dto.setCompetitorHybrid3(cursor.getFloat(cursor.getColumnIndex("competitorHybrid3")));
                    dto.setCompetitorHybrid4(cursor.getFloat(cursor.getColumnIndex("competitorHybrid4")));
                    dto.setCompetitorHybrid5(cursor.getFloat(cursor.getColumnIndex("competitorHybrid5")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setRegionId(cursor.getLong(cursor.getColumnIndex("regionId")));
                    dto.setLocation(cursor.getString(cursor.getColumnIndex("location")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setUploadedDate(cursor.getString(cursor.getColumnIndex("uploadedDate")));
                    dto.setPioneerHyb1Name(cursor.getString(cursor.getColumnIndex("pioneerHyb1Name")));
                    dto.setPioneerHyb2Name(cursor.getString(cursor.getColumnIndex("pioneerHyb2Name")));
                    dto.setPioneerHyb3Name(cursor.getString(cursor.getColumnIndex("pioneerHyb3Name")));
                    dto.setPioneerHyb4Name(cursor.getString(cursor.getColumnIndex("pioneerHyb4Name")));
                    dto.setCompetitorHybrid1Name(cursor.getString(cursor.getColumnIndex("competitorHybrid1Name")));
                    dto.setCompetitorHybrid2Name(cursor.getString(cursor.getColumnIndex("competitorHybrid2Name")));
                    dto.setCompetitorHybrid3Name(cursor.getString(cursor.getColumnIndex("competitorHybrid3Name")));
                    dto.setCompetitorHybrid4Name(cursor.getString(cursor.getColumnIndex("competitorHybrid4Name")));
                    dto.setCompetitorHybrid5Name(cursor.getString(cursor.getColumnIndex("competitorHybrid5Name")));
                    dto.setOtherCrop1(cursor.getLong(cursor.getColumnIndex("otherCrop1")));
                    dto.setOtherCrop2(cursor.getLong(cursor.getColumnIndex("otherCrop2")));
                    dto.setOtherCropArea1(cursor.getDouble(cursor.getColumnIndex("otherCropArea1")));
                    dto.setOtherCropArea2(cursor.getDouble(cursor.getColumnIndex("otherCropArea2")));
                    dto.setUserType(cursor.getString(cursor.getColumnIndex("userType")));
                    dto.setF2Acreages(cursor.getFloat(cursor.getColumnIndex("f2Acreages")));
                    dto.setSeedSettingIssue(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue")));

                    dto.setSeedSettingIssue1(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue1")));
                    dto.setSeedSettingIssue2(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue2")));
                    dto.setSeedSettingIssue3(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue3")));
                    dto.setSeedSettingIssue4(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue4")));

                    dto.setCompetitorHybrid1SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid1SeedSettingIssue")));
                    dto.setCompetitorHybrid2SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid2SeedSettingIssue")));


                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            /*  ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    public List<DipstickDTO> getRecordsForUpload(SQLiteDatabase dbObject) {
        List<DipstickDTO> pdaActivityInfo = new ArrayList<DipstickDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM DIPSTICK where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    DipstickDTO dto = new DipstickDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setActivityType(cursor.getString(cursor.getColumnIndex("activityType")));
                    dto.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setIsSampleIssued(cursor.getInt(cursor.getColumnIndex("isSampleIssued")) > 0 ? true : false);
                    dto.setHybridId(cursor.getLong(cursor.getColumnIndex("hybridId")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setFarmerNumber(cursor.getString(cursor.getColumnIndex("farmerNumber")));
                    dto.setCropAcres(cursor.getFloat(cursor.getColumnIndex("cropAcres")));
                    dto.setHybridCropAcres(cursor.getFloat(cursor.getColumnIndex("hybridCropAcres")));
                    dto.setOtherCropAcres(cursor.getFloat(cursor.getColumnIndex("otherCropAcres")));
                    dto.setPioneerHyb1(cursor.getFloat(cursor.getColumnIndex("pioneerHyb1")));
                    dto.setPioneerHyb2(cursor.getFloat(cursor.getColumnIndex("pioneerHyb2")));
                    dto.setPioneerHyb3(cursor.getFloat(cursor.getColumnIndex("pioneerHyb3")));
                    dto.setPioneerHyb4(cursor.getFloat(cursor.getColumnIndex("pioneerHyb4")));
                    dto.setCompetitorHybrid1(cursor.getFloat(cursor.getColumnIndex("competitorHybrid1")));
                    dto.setCompetitorHybrid2(cursor.getFloat(cursor.getColumnIndex("competitorHybrid2")));
                    dto.setCompetitorHybrid3(cursor.getFloat(cursor.getColumnIndex("competitorHybrid3")));
                    dto.setCompetitorHybrid4(cursor.getFloat(cursor.getColumnIndex("competitorHybrid4")));
                    dto.setCompetitorHybrid5(cursor.getFloat(cursor.getColumnIndex("competitorHybrid5")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setRegionId(cursor.getLong(cursor.getColumnIndex("regionId")));
                    dto.setLocation(cursor.getString(cursor.getColumnIndex("location")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setUploadedDate(cursor.getString(cursor.getColumnIndex("uploadedDate")));
                    dto.setPioneerHyb1Name(cursor.getString(cursor.getColumnIndex("pioneerHyb1Name")));
                    dto.setPioneerHyb2Name(cursor.getString(cursor.getColumnIndex("pioneerHyb2Name")));
                    dto.setPioneerHyb3Name(cursor.getString(cursor.getColumnIndex("pioneerHyb3Name")));
                    dto.setPioneerHyb4Name(cursor.getString(cursor.getColumnIndex("pioneerHyb4Name")));
                    dto.setCompetitorHybrid1Name(cursor.getString(cursor.getColumnIndex("competitorHybrid1Name")));
                    dto.setCompetitorHybrid2Name(cursor.getString(cursor.getColumnIndex("competitorHybrid2Name")));
                    dto.setCompetitorHybrid3Name(cursor.getString(cursor.getColumnIndex("competitorHybrid3Name")));
                    dto.setCompetitorHybrid4Name(cursor.getString(cursor.getColumnIndex("competitorHybrid4Name")));
                    dto.setCompetitorHybrid5Name(cursor.getString(cursor.getColumnIndex("competitorHybrid5Name")));
                    dto.setOtherCrop1(cursor.getLong(cursor.getColumnIndex("otherCrop1")));
                    dto.setOtherCrop2(cursor.getLong(cursor.getColumnIndex("otherCrop2")));
                    dto.setOtherCropArea1(cursor.getDouble(cursor.getColumnIndex("otherCropArea1")));
                    dto.setOtherCropArea2(cursor.getDouble(cursor.getColumnIndex("otherCropArea2")));
                    dto.setUserType(cursor.getString(cursor.getColumnIndex("userType")));
                    dto.setF2Acreages(cursor.getFloat(cursor.getColumnIndex("f2Acreages")));
                    dto.setSeedSettingIssue(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue")));

                    dto.setSeedSettingIssue1(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue1")));
                    dto.setSeedSettingIssue2(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue2")));
                    dto.setSeedSettingIssue3(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue3")));
                    dto.setSeedSettingIssue4(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue4")));

                    dto.setCompetitorHybrid1SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid1SeedSettingIssue")));
                    dto.setCompetitorHybrid2SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid2SeedSettingIssue")));


                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            /* ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {

        return false;
    }


    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DipstickDTO dto = (DipstickDTO) dtoObject;

            Cursor cursor = dbObject.rawQuery("SELECT id FROM DIPSTICK where activityType='" + dto.getActivityType() + "' and year='" + dto.getYear() + "' and seasonId='" + dto.getSeasonId() + "' and cropId='" + dto.getCropId() + "' and farmerNumber='" + dto.getFarmerNumber() + "'", null);
            if (cursor.getCount() > 0) {
                return -2;
            }

            cursor = dbObject.rawQuery("SELECT id FROM DIPSTICK_MASTER where activityType='" + dto.getActivityType() + "' and year='" + dto.getYear() + "' and seasonId='" + dto.getSeasonId() + "' and cropId='" + dto.getCropId() + "' and farmerNumber='" + dto.getFarmerNumber() + "'", null);
            if (cursor.getCount() > 0) {
                return -2;
            }

            ContentValues cValues = new ContentValues();
            /*DIPSTICK
			id 
			activityType
			year
			seasonId
			cropId
			isSampleIssued
			hybridId
			farmerName
			farmerNumber
			cropAcres
			hybridCropAcres
			otherCropAcres
			pioneerHyb1
			pioneerHyb2
			competitorHybrid1
			competitorHybrid2
			competitorHybrid3
			competitorHybrid4
			competitorHybrid5
			date
			regionId
			location
			isSync
			uploadedDate
			pioneerHyb1Name
			pioneerHyb2Name
			 userType
			 Acreages*/

            cValues.put("activityType", dto.getActivityType());
            cValues.put("year", dto.getYear());
            cValues.put("seasonId", dto.getSeasonId());
            cValues.put("cropId", dto.getCropId());
            cValues.put("isSampleIssued", dto.getIsSampleIssued());
            cValues.put("hybridId", dto.getHybridId());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("farmerNumber", dto.getFarmerNumber());
            cValues.put("cropAcres", dto.getCropAcres());
            cValues.put("hybridCropAcres", dto.getHybridCropAcres());
            cValues.put("otherCropAcres", dto.getOtherCropAcres());
            cValues.put("pioneerHyb1", dto.getPioneerHyb1());
            cValues.put("pioneerHyb2", dto.getPioneerHyb2());
            cValues.put("pioneerHyb3", dto.getPioneerHyb3());
            cValues.put("pioneerHyb4", dto.getPioneerHyb4());
            cValues.put("competitorHybrid1", dto.getCompetitorHybrid1());
            cValues.put("competitorHybrid2", dto.getCompetitorHybrid2());
            cValues.put("competitorHybrid3", dto.getCompetitorHybrid3());
            cValues.put("competitorHybrid4", dto.getCompetitorHybrid4());
            cValues.put("competitorHybrid5", dto.getCompetitorHybrid5());
            cValues.put("date", dto.getDate());
            cValues.put("regionId", dto.getRegionId());
            cValues.put("location", dto.getLocation());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("uploadedDate", dto.getUploadedDate());
            cValues.put("pioneerHyb1Name", dto.getPioneerHyb1Name());
            cValues.put("pioneerHyb2Name", dto.getPioneerHyb2Name());
            cValues.put("pioneerHyb3Name", dto.getPioneerHyb3Name());
            cValues.put("pioneerHyb4Name", dto.getPioneerHyb4Name());
            cValues.put("competitorHybrid1Name", dto.getCompetitorHybrid1Name());
            cValues.put("competitorHybrid2Name", dto.getCompetitorHybrid2Name());
            cValues.put("competitorHybrid3Name", dto.getCompetitorHybrid3Name());
            cValues.put("competitorHybrid4Name", dto.getCompetitorHybrid4Name());
            cValues.put("competitorHybrid5Name", dto.getCompetitorHybrid5Name());
            cValues.put("otherCrop1", dto.getOtherCrop1());
            cValues.put("otherCrop2", dto.getOtherCrop2());
            cValues.put("otherCropArea1", dto.getOtherCropArea1());
            cValues.put("otherCropArea2", dto.getOtherCropArea2());
            cValues.put("userType", dto.getUserType());
            cValues.put("f2Acreages", dto.getF2Acreages());
            cValues.put("seedSettingIssue", dto.getSeedSettingIssue());

            cValues.put("seedSettingIssue1", dto.getSeedSettingIssue1());
            cValues.put("seedSettingIssue2", dto.getSeedSettingIssue2());
            cValues.put("seedSettingIssue3", dto.getSeedSettingIssue3());
            cValues.put("seedSettingIssue4", dto.getSeedSettingIssue4());

            cValues.put("competitorHybrid1SeedSettingIssue", dto.getCompetitorHybrid1SeedSettingIssue());
            cValues.put("competitorHybrid2SeedSettingIssue", dto.getCompetitorHybrid2SeedSettingIssue());

            long insertedRow = dbObject.insert("DIPSTICK", null, cValues);
            if (insertedRow > 0) {
                return insertedRow;
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DipstickDTO dto = (DipstickDTO) dtoObject;
            ContentValues cValues = new ContentValues();
            /*DIPSTICK
			id 
			activityType
			year
			seasonId
			cropId
			isSampleIssued
			hybridId
			farmerName
			farmerNumber
			cropAcres
			hybridCropAcres
			otherCropAcres
			pioneerHyb1
			pioneerHyb2
			competitorHybrid1
			competitorHybrid2
			competitorHybrid3
			competitorHybrid4
			competitorHybrid5
			date
			regionId
			location
			isSync
			uploadedDate
			pioneerHyb1Name
			pioneerHyb2Name
			userType
			f2Acreages*/

            if (dto.getActivityType() != null && !dto.getActivityType().isEmpty())
                cValues.put("activityType", dto.getActivityType());
            if (dto.getYear() != 0)
                cValues.put("year", dto.getYear());
            if (dto.getSeasonId() != null)
                cValues.put("seasonId", dto.getSeasonId());
            if (dto.getCropId() != null)
                cValues.put("cropId", dto.getCropId());
            if (dto.getIsSampleIssued())
                cValues.put("isSampleIssued", dto.getIsSampleIssued());
            if (dto.getHybridId() != null)
                cValues.put("hybridId", dto.getHybridId());
            if (dto.getFarmerName() != null && !dto.getFarmerName().isEmpty())
                cValues.put("farmerName", dto.getFarmerName());
            if (dto.getFarmerNumber() != null && !dto.getFarmerNumber().isEmpty())
                cValues.put("farmerNumber", dto.getFarmerNumber());
            if (dto.getCropAcres() != null)
                cValues.put("cropAcres", dto.getCropAcres());
            if (dto.getHybridCropAcres() != null)
                cValues.put("hybridCropAcres", dto.getHybridCropAcres());
            if (dto.getOtherCropAcres() != null)
                cValues.put("otherCropAcres", dto.getOtherCropAcres());
            if (dto.getPioneerHyb1() != null)
                cValues.put("pioneerHyb1", dto.getPioneerHyb1());
            if (dto.getPioneerHyb2() != null)
                cValues.put("pioneerHyb2", dto.getPioneerHyb2());
            if (dto.getPioneerHyb3() != null)
                cValues.put("pioneerHyb3", dto.getPioneerHyb3());
            if (dto.getPioneerHyb4() != null)
                cValues.put("pioneerHyb4", dto.getPioneerHyb4());
            if (dto.getCompetitorHybrid1() != null)
                cValues.put("competitorHybrid1", dto.getCompetitorHybrid1());
            if (dto.getCompetitorHybrid2() != null)
                cValues.put("competitorHybrid2", dto.getCompetitorHybrid2());
            if (dto.getCompetitorHybrid3() != null)
                cValues.put("competitorHybrid3", dto.getCompetitorHybrid3());
            if (dto.getCompetitorHybrid4() != null)
                cValues.put("competitorHybrid4", dto.getCompetitorHybrid4());
            if (dto.getCompetitorHybrid5() != null)
                cValues.put("competitorHybrid5", dto.getCompetitorHybrid5());
            if (dto.getDate() != null)
                cValues.put("date", dto.getDate());
            if (dto.getRegionId() != -1)
                cValues.put("regionId", dto.getRegionId());
            if (dto.getLocation() != null)
                cValues.put("location", dto.getLocation());
            if (dto.getIsSync() != -1)
                cValues.put("isSync", dto.getIsSync());
            if (dto.getUploadedDate() != null)
                cValues.put("uploadedDate", dto.getUploadedDate());
            if (dto.getPioneerHyb1Name() != null)
                cValues.put("pioneerHyb1Name", dto.getPioneerHyb1Name());
            if (dto.getPioneerHyb2Name() != null)
                cValues.put("pioneerHyb2Name", dto.getPioneerHyb2Name());
            if (dto.getPioneerHyb3Name() != null)
                cValues.put("pioneerHyb3Name", dto.getPioneerHyb3Name());
            if (dto.getPioneerHyb4Name() != null)
                cValues.put("pioneerHyb4Name", dto.getPioneerHyb4Name());

            if (dto.getCompetitorHybrid1Name() != null)
                cValues.put("competitorHybrid1Name", dto.getCompetitorHybrid1Name());

            if (dto.getCompetitorHybrid2Name() != null)
                cValues.put("competitorHybrid2Name", dto.getCompetitorHybrid2Name());

            if (dto.getCompetitorHybrid3Name() != null)
                cValues.put("competitorHybrid3Name", dto.getCompetitorHybrid3Name());

            if (dto.getCompetitorHybrid4Name() != null)
                cValues.put("competitorHybrid4Name", dto.getCompetitorHybrid4Name());

            if (dto.getCompetitorHybrid5Name() != null)
                cValues.put("competitorHybrid5Name", dto.getCompetitorHybrid5Name());

            if (dto.getOtherCrop1() != 0)
                cValues.put("otherCrop1", dto.getOtherCrop1());

            if (dto.getOtherCrop2() != 0)
                cValues.put("otherCrop2", dto.getOtherCrop2());

            if (dto.getOtherCropArea1() != 0)
                cValues.put("otherCropArea1", dto.getOtherCropArea1());

            if (dto.getOtherCropArea2() != 0)
                cValues.put("otherCropArea2", dto.getOtherCropArea2());

            if (dto.getUserType() != null)
                cValues.put("userType", dto.getUserType());

            if (dto.getF2Acreages() != null)
                cValues.put("f2Acreages", dto.getF2Acreages());

            if (dto.getSeedSettingIssue() != null)
                cValues.put("seedSettingIssue", dto.getSeedSettingIssue());

            if (dto.getSeedSettingIssue1() != null)
                cValues.put("seedSettingIssue1", dto.getSeedSettingIssue1());

            if (dto.getSeedSettingIssue2() != null)
                cValues.put("seedSettingIssue2", dto.getSeedSettingIssue2());

            if (dto.getSeedSettingIssue3() != null)
                cValues.put("seedSettingIssue3", dto.getSeedSettingIssue3());

            if (dto.getSeedSettingIssue4() != null)
                cValues.put("seedSettingIssue4", dto.getSeedSettingIssue4());

            if (dto.getCompetitorHybrid1SeedSettingIssue() != null)
                cValues.put("competitorHybrid1SeedSettingIssue", dto.getCompetitorHybrid1SeedSettingIssue());

            if (dto.getCompetitorHybrid2SeedSettingIssue() != null)
                cValues.put("competitorHybrid2SeedSettingIssue", dto.getCompetitorHybrid2SeedSettingIssue());


            int rowsEffected = dbObject.update("DIPSTICK", cValues, "id='" + dto.getId() + "' ", null);
            if (rowsEffected > 0)
                return true;

        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;
        } finally {
            dbObject.close();
        }

        return false;
    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    public boolean updateSync(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            DipstickDTO dto = (DipstickDTO) dtoObject;
            ContentValues cValues = new ContentValues();
            /*DIPSTICK
			id 
			isSync
			uploadedDate */

            if (dto.getIsSync() != -1)
                cValues.put("isSync", dto.getIsSync());
            if (dto.getUploadedDate() != null)
                cValues.put("uploadedDate", dto.getUploadedDate());

            int rowsEffected = dbObject.update("DIPSTICK", cValues, "id ='" + dto.getId() + "' ", null);
            if (rowsEffected > 0)
                return true;

        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;
        } finally {
            dbObject.close();
        }

        return false;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM DIPSTICK").execute();
            return true;
        } catch (Exception e) {
            /* ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());*/
        }
        return false;
    }

    public boolean deleteTableDataById(Long id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM DIPSTICK where id = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            /* ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());*/
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from DIPSTICK where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean deleteDataByDate(String date, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from  DIPSTICK  where uploadedDate < '" + date + "' and isSync = '0'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM DIPSTICK where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }
}
