package com.activitytrack.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.activitytrack.daos.DemandSummaryDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdaos.TargetDemandOSADAO;
import com.activitytrack.masterdaos.TargetDemandPDADAO;
import com.activitytrack.masterdaos.TargetDemandPSADAO;
import com.activitytrack.masterdaos.Top3HybridsDAO;
import com.activitytrack.masterdtos.SeasonCalendarDTO;
import com.activitytrack.masterdtos.Top3HybridsDTO;
import com.activitytrack.meterlib.SpeedometerGauge;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.Legend.LegendForm;
import com.github.mikephil.charting.components.Legend.LegendPosition;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.XAxis.XAxisPosition;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.components.YAxis.YAxisLabelPosition;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ValueFormatter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public class DemandGenFragment extends BaseFragment {

	private ImageView btnPlus;

	private RelativeLayout agronomyLayout;
	private ImageView demandImg;
	private TextView demandText;
	private View demandBottom;

	private SpeedometerGauge speedometer;

	private ImageView pdaImg;
	private ImageView osaImg;
	private ImageView psaImg;

	private int selectedActivityId;
	//private String selectedActivity;
	private int selectedCrop;

	private LinearLayout cropCornLayout;
	private LinearLayout cropRiceLayout;
	private LinearLayout cropMilletLayout;
	private LinearLayout cropMustardLayout;
	
	private ImageView cropCornImg;
	private ImageView cropRiceImg;
	private ImageView cropMilletImg;
	private ImageView cropMustardImg;
	private TextView cropCornTxt;
	private TextView cropRiceTxt;
	private TextView cropMilletTxt;
	private TextView cropMustardTxt;

	private LinearLayout mainLayout;
	private BarChart mActivityBarChart;
	private BarChart mFarmerBarChart;
	
	private TextView tvLegendTotalTarget;
	private TextView tvLegendTillDate;
	private TextView tvLegendTargetTillDate;
	private ImageView imgLegendTotalTarget;
	private TextView tvTotalTarget;
	private TextView tvTillDateAchieve;
	private TextView tvTargetTillDate;
	
	private int totalTarget;
	private int tillDateTarget;
	private int targetAchieved;
	
	private int totalTargetFrm;
	private int tillDateTargetFrm;
	private int targetAchievedFrm;
	
	//private long seasonId;
	//private long seasonCalId;
	
	private List<Long> hybridIdsList = new ArrayList<Long>();
	private List<String> hybridNamesList = new ArrayList<String>();
	
	private LinkedHashMap<String, Integer> activityTargetMap = new LinkedHashMap<String, Integer>();
	private LinkedHashMap<String, Integer> activityAchievedMap = new LinkedHashMap<String, Integer>();
	private LinkedHashMap<String, Integer> farmersTargetMap = new LinkedHashMap<String, Integer>();
	private LinkedHashMap<String, Integer> farmersAchievedMap = new LinkedHashMap<String, Integer>();
	
	private List<Long> cropsList = new ArrayList<Long>();
	
	private View view;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(Utility.checkPlayServices(mActivity)){
			buildGoogleApiClient();
		}

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.demand_generation_fragment, container,
				false);

		// tab ids references
		agronomyLayout = (RelativeLayout) view
				.findViewById(R.id.db_agronomylayout);
		demandImg = (ImageView) view.findViewById(R.id.db_demandImg);
		demandText = (TextView) view.findViewById(R.id.db_demandText);
		demandBottom = view.findViewById(R.id.db_demandBottom);

		// activities references
		pdaImg = (ImageView) view.findViewById(R.id.dg_pda);
		osaImg = (ImageView) view.findViewById(R.id.dg_osa);
		psaImg = (ImageView) view.findViewById(R.id.dg_psa);

		// crops image references
		cropCornLayout = (LinearLayout) view.findViewById(R.id.dg_cropCorn_layout);
		cropRiceLayout = (LinearLayout) view.findViewById(R.id.dg_cropRice_layout);
		cropMilletLayout = (LinearLayout) view.findViewById(R.id.dg_cropMillet_layout);
		cropMustardLayout = (LinearLayout) view.findViewById(R.id.dg_cropMustard_layout);
		
		cropCornImg = (ImageView) view.findViewById(R.id.dg_cropCorn_icon);
		cropRiceImg = (ImageView) view.findViewById(R.id.dg_cropRice_icon);
		cropMilletImg = (ImageView) view.findViewById(R.id.dg_cropMillet_icon);
		cropMustardImg = (ImageView) view.findViewById(R.id.dg_cropMustard_icon);
		cropCornTxt = (TextView) view.findViewById(R.id.dg_cropCorn_text);
		cropRiceTxt = (TextView) view.findViewById(R.id.dg_cropRice_text);
		cropMilletTxt = (TextView) view.findViewById(R.id.dg_cropMillet_text);
		cropMustardTxt = (TextView) view.findViewById(R.id.dg_cropMustard_text);
		
		tvLegendTargetTillDate = (TextView) view.findViewById(R.id.pda_legend_targetTillDate);
		tvLegendTillDate = (TextView) view.findViewById(R.id.pda_legend_tillDate);
		tvLegendTotalTarget = (TextView) view.findViewById(R.id.pda_legend_totalTarget);
		imgLegendTotalTarget = (ImageView) view.findViewById(R.id.pda_legend_totalTargetImg);
		
		tvTargetTillDate = (TextView) view.findViewById(R.id.pda_targetTillDateTxt);
		tvTotalTarget = (TextView) view.findViewById(R.id.pda_toatalTargetTxt);
		tvTillDateAchieve = (TextView) view.findViewById(R.id.pda_tillDateAchievementTxt);
		
		mainLayout = (LinearLayout) view.findViewById(R.id.pda_mailLayout);
		
		mActivityBarChart = (BarChart) view.findViewById(R.id.dg_activityBarChart);

		mFarmerBarChart = (BarChart) view.findViewById(R.id.dg_farmerBarChart);
		
		btnPlus = (ImageView) view.findViewById(R.id.dg_addBtn);

		speedometer = (SpeedometerGauge) view.findViewById(R.id.dg_progressmeter);
		
		setTheme();
		
		hideCropLayouts();
		
		if(Utility.getCurrentAvtivity(mActivity) != 0){
			activitySelection(Utility.getCurrentAvtivity(mActivity));
		}else{
			// setting pda is default active
			activitySelection(MyConstants.ACTIVITY_PDA_ID);
		}
		
		if(Utility.getCurrentCrop(mActivity) != 0){
			cropSelection(Utility.getCurrentCrop(mActivity));
		}else{
			// crop default selection
			//cropSelection(MyConstants.CROP_CORN_ID);
		}

		setActivityBarChatProperties();
		setFarmerBarChatProperties();
		
		demandImg.setImageResource(R.drawable.demand_generation_icon_f);
		demandText.setTextColor(getResources().getColor(R.color.tab_activeText_color));
		demandBottom.setVisibility(View.VISIBLE);

		agronomyLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mActivity.dashboardPopFragments();
				mActivity.pushFragments(MyConstants.TAB_DASHBOARD,
						new AgronomyDashboradFragment(), false, true);
			}
		});

		pdaImg.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				activitySelection(MyConstants.ACTIVITY_PDA_ID);
			}
		});

		osaImg.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				activitySelection(MyConstants.ACTIVITY_OSA_ID);
			}
		});

		psaImg.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				activitySelection(MyConstants.ACTIVITY_PSA_ID);
			}
		});

		cropCornLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_CORN_ID);
			}
		});

		cropRiceLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_RICE_ID);
			}
		});

		cropMilletLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_MILLET_ID);
			}
		});

		cropMustardLayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				cropSelection(MyConstants.CROP_MUSTARD_ID);
			}
		});

		btnPlus.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(selectedCrop > 0){
					String  seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(selectedCrop, selectedActivityId,DBHandler.getInstance(mActivity).getDBObject(0));
				    boolean res = Utility.isSeasonExpire(seasonEndDate,Utility.getCurrentformatedDate());
					 if(res)
					 {
						 Utility.showAlert(mActivity, "", getResources().getString(R.string.seacal) + (Utility.getActivityNameById(selectedActivityId)) +  " of crop " + ( Utility.getCropNameById(selectedCrop)) + " is over");
					     return;
					 }
				}
				 
				BaseFragment fragment = null;
				if (selectedActivityId == MyConstants.ACTIVITY_PDA_ID) {
					fragment = new PDAFragment();
				} else if (selectedActivityId == MyConstants.ACTIVITY_OSA_ID) {

					fragment = new OSAFragment();
				} else if (selectedActivityId == MyConstants.ACTIVITY_PSA_ID) {
					fragment = new PSAFragment();
				}
				
				if(selectedActivityId != Utility.getCurrentAvtivity(mActivity)){
					Utility.setCurrentAvtivity(selectedActivityId, mActivity);
				}
				
				if(selectedCrop != Utility.getCurrentCrop(mActivity)){
					Utility.setCurrentCrop(selectedCrop, mActivity);
				}
				if(selectedCrop != 0){
				if (fragment != null) {
					Bundle bundle = new Bundle();
					bundle.putInt("cropId", selectedCrop);
					fragment.setArguments(bundle);
					mActivity.pushFragments(MyConstants.TAB_DASHBOARD, fragment, false, true);
				}
				}else{
					Utility.showAlert(mActivity, "Alert", getResources().getString(R.string.cropntavailable)+" "+Utility.getActivityNameById(selectedActivityId)+" activity");
				}
			}
		});

		return view;
	}
	
	/*@Override
	public void onResume() {
		mActivity.invalidateOptionsMenu();
		*//*if(mActivity.menu != null){
			mActivity.menu.findItem(R.id.action_home).setIcon(R.drawable.transparent_img);
			mActivity.menu.findItem(R.id.action_home).setEnabled(false);
		}*//*
		super.onResume();
	}
	
	@Override
	public void onPause() {
		mActivity.invalidateOptionsMenu();
		*//*if(mActivity.menu != null){
			mActivity.menu.findItem(R.id.action_home).setIcon(R.drawable.home_icon);
			mActivity.menu.findItem(R.id.action_home).setEnabled(true);
		}*//*
		super.onPause();
	}*/

	private void drawGraph1(int achieved, int targetTillDate, int totalTarget) {
		
		totalTarget = 50;
		targetTillDate = 45;
		achieved = 40;
		
		tvTillDateAchieve.setText(""+achieved+"/"+targetAchievedFrm);
		tvTargetTillDate.setText(""+targetTillDate+"/"+tillDateTargetFrm);
		tvTotalTarget.setText(""+totalTarget+"/"+totalTargetFrm);
		
		// configure value range and ticks
		if(achieved > totalTarget)
			speedometer.setMaxSpeed(achieved);
		else
			speedometer.setMaxSpeed(totalTarget);

		speedometer.setSpeed(achieved);

		speedometer.addColoredRange(0, totalTarget, Color.WHITE);
		speedometer.addColoredRange(0, targetTillDate, Color.rgb(246, 129, 33));
		speedometer.addColoredRange(0, achieved, Color.rgb(66, 119, 48));
		
	}
	
	private void drawGraph(int achieved, int targetTillDate, int totalTarget) {
		
		tvTillDateAchieve.setText(""+achieved+"/"+targetAchievedFrm);
		tvTargetTillDate.setText(""+targetTillDate+"/"+tillDateTargetFrm);
		tvTotalTarget.setText(""+totalTarget+"/"+totalTargetFrm);
		
		// configure value range and ticks
		if(achieved > totalTarget)
			speedometer.setMaxSpeed(achieved);
		else
			speedometer.setMaxSpeed(totalTarget);

		speedometer.setSpeed(achieved);

		
		
		if(achieved > totalTarget){
			speedometer.addColoredRange(totalTarget, achieved, Color.rgb(66, 119, 48));
			if(tillDateTarget > 0)
				speedometer.addColoredRange(0, targetTillDate, Color.rgb(246, 129, 33));
			if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
				speedometer.addColoredRange(tillDateTarget, totalTarget, Color.WHITE);
			}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
				speedometer.addColoredRange(tillDateTarget, totalTarget, Color.rgb(195, 195, 195));
			}
		}else if(achieved > targetTillDate){
			speedometer.addColoredRange(targetTillDate, achieved, Color.rgb(66, 119, 48));
			if(tillDateTarget > 0)
				speedometer.addColoredRange(0, targetTillDate, Color.rgb(246, 129, 33));
			if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
				speedometer.addColoredRange(achieved, totalTarget, Color.WHITE);
			}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
				speedometer.addColoredRange(achieved, totalTarget, Color.rgb(195, 195, 195));
			}
		}else{
			speedometer.addColoredRange(0, achieved, Color.rgb(66, 119, 48));
			speedometer.addColoredRange(achieved, targetTillDate, Color.rgb(246, 129, 33));
			if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
				speedometer.addColoredRange(targetTillDate, totalTarget, Color.WHITE);
			}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
				speedometer.addColoredRange(targetTillDate, totalTarget, Color.rgb(195, 195, 195));
			}
		}
		
	}
	
	private void activitySelection(int activity) {
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			psaImg.setImageResource(R.drawable.psa_icon_d);
			pdaImg.setImageResource(R.drawable.pda_icon_d);
			osaImg.setImageResource(R.drawable.osa_icon_d);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			psaImg.setImageResource(R.drawable.psa_icon_l);
			pdaImg.setImageResource(R.drawable.pda_icon_l);
			osaImg.setImageResource(R.drawable.osa_icon_l);
		}
		
		if (activity == MyConstants.ACTIVITY_PDA_ID) {
			pdaImg.setImageResource(R.drawable.pda_icon_f);
			selectedActivityId = MyConstants.ACTIVITY_PDA_ID;
			//selectedActivity = MyConstants.ACTIVITY_PDA;
			selectedCrop = 0;

			setCrops(MyConstants.ACTIVITY_PDA_ID);
			
		} else if (activity == MyConstants.ACTIVITY_OSA_ID) {
			osaImg.setImageResource(R.drawable.osa_icon_f);
			selectedActivityId = MyConstants.ACTIVITY_OSA_ID;
			//selectedActivity = MyConstants.ACTIVITY_OSA;
			selectedCrop = 0;
			
			setCrops(MyConstants.ACTIVITY_OSA_ID);
		} else if (activity == MyConstants.ACTIVITY_PSA_ID) {
			psaImg.setImageResource(R.drawable.psa_icon_f);
			selectedActivityId = MyConstants.ACTIVITY_PSA_ID;
			//selectedActivity = MyConstants.ACTIVITY_PSA;
			selectedCrop = 0;

			setCrops(MyConstants.ACTIVITY_PSA_ID);
		}

	} // end activitySelection
	
	private void setCrops(int activityId){
		hideCropLayouts();
		List<DTO> seasonList = SeasonCalendarDAO.getInstance().getRecordInfoByValue("activityId", ""+activityId, DBHandler.getInstance(mActivity).getDBObject(0));
		if(seasonList != null && seasonList.size() > 0){
			cropsList.clear();
			for(DTO tempDto : seasonList){
				SeasonCalendarDTO seasonDto = (SeasonCalendarDTO) tempDto;
				//seasonId = seasonDto.getSeasonId();
				//dummy
				//seasonCalId = 1;
				cropsList.add(seasonDto.getCropId());
				if(seasonDto.getCropId() == MyConstants.CROP_CORN_ID)
					cropCornLayout.setVisibility(View.VISIBLE);
				else if(seasonDto.getCropId() == MyConstants.CROP_RICE_ID)
					cropRiceLayout.setVisibility(View.VISIBLE);
				else if(seasonDto.getCropId() == MyConstants.CROP_MILLET_ID)
					cropMilletLayout.setVisibility(View.VISIBLE);
				else if(seasonDto.getCropId() == MyConstants.CROP_MUSTARD_ID)
					cropMustardLayout.setVisibility(View.VISIBLE);
			
			}
			
			cropSelection(cropsList.get(0));
			
		}
	}//end of setCrops

	private void cropSelection(long crop) {
		
		mActivityBarChart.clear();
		mFarmerBarChart.clear();
		
		cropCornImg.setImageResource(R.drawable.corn_icon);
		cropMilletImg.setImageResource(R.drawable.millet_icon);
		cropMustardImg.setImageResource(R.drawable.mustard_icon);
		cropRiceImg.setImageResource(R.drawable.rice_icon);
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
		}

		if (crop == MyConstants.CROP_CORN_ID) {
			cropCornImg.setImageResource(R.drawable.corn_icon_f);
			cropCornTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_CORN_ID;
		} else if (crop == MyConstants.CROP_RICE_ID) {
			cropRiceImg.setImageResource(R.drawable.rice_icon_f);
			cropRiceTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_RICE_ID;
		} else if (crop == MyConstants.CROP_MILLET_ID) {
			cropMilletImg.setImageResource(R.drawable.millet_icon_f);
			cropMilletTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_MILLET_ID;
		} else if (crop == MyConstants.CROP_MUSTARD_ID) {
			cropMustardImg.setImageResource(R.drawable.mustard_icon_f);
			cropMustardTxt.setTextColor(getResources().getColor(
					R.color.tab_activeText_color));
			selectedCrop = MyConstants.CROP_MUSTARD_ID;
		}

		if (selectedActivityId == MyConstants.ACTIVITY_PDA_ID) {
			tillDateTarget = 0;
			tillDateTargetFrm = 0;
			totalTarget = 0;
			totalTargetFrm = 0;
			targetAchieved = 0;
			targetAchievedFrm = 0;

			List<Integer> totalTargetList = TargetDemandPDADAO.getInstance().getTotalTarget(crop, DBHandler.getInstance(mActivity).getDBObject(0));
			if(totalTargetList != null && totalTargetList.size() == 2){
				totalTarget = totalTargetList.get(0);
				totalTargetFrm = totalTargetList.get(1);
			}

			List<Integer> tillDateTargetList = TargetDemandPDADAO.getInstance().getTillDateTarget(crop, Utility.getCurrentDateFrm(), DBHandler.getInstance(mActivity).getDBObject(0));
			if(tillDateTargetList != null && tillDateTargetList.size() == 2){
				tillDateTarget = tillDateTargetList.get(0);
				tillDateTargetFrm = tillDateTargetList.get(1);
			}

			List<Integer> achievedList = DemandSummaryDAO.getInstance().getActivitiesCount(crop,""+MyConstants.ACTIVITY_PDA_ID,DBHandler.getInstance(mActivity).getDBObject(0));

			{
				targetAchieved = achievedList.get(0);
				targetAchievedFrm = achievedList.get(1);
			}

			drawGraph(targetAchieved, tillDateTarget, totalTarget);
		} else if (selectedActivityId == MyConstants.ACTIVITY_OSA_ID) {
			tillDateTarget = 0;
			tillDateTargetFrm = 0;
			totalTarget = 0;
			totalTargetFrm = 0;
			targetAchieved = 0;
			targetAchievedFrm = 0;

			List<Integer> totalTargetList = TargetDemandOSADAO.getInstance().getTotalTarget(crop, DBHandler.getInstance(mActivity).getDBObject(0));
			if(totalTargetList != null && totalTargetList.size() == 2){
				totalTarget = totalTargetList.get(0);
				totalTargetFrm = totalTargetList.get(1);
			}

			List<Integer> tillDateTargetList = TargetDemandOSADAO.getInstance().getTillDateTarget(crop, Utility.getCurrentDateFrm(), DBHandler.getInstance(mActivity).getDBObject(0));
			if(tillDateTargetList != null && tillDateTargetList.size() == 2){
				tillDateTarget = tillDateTargetList.get(0);
				tillDateTargetFrm = tillDateTargetList.get(1);
			}

			List<Integer> achievedList = DemandSummaryDAO.getInstance().getActivitiesCount(crop,""+MyConstants.ACTIVITY_OSA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
			if(achievedList != null && achievedList.size() == 2){
				targetAchieved = achievedList.get(0);
				targetAchievedFrm = achievedList.get(1);
			}

			drawGraph(targetAchieved, tillDateTarget, totalTarget);
		} else if (selectedActivityId == MyConstants.ACTIVITY_PSA_ID) {
			tillDateTarget = 0;
			tillDateTargetFrm = 0;
			totalTarget = 0;
			totalTargetFrm = 0;
			targetAchieved = 0;
			targetAchievedFrm = 0;

			List<Integer> totalTargetList = TargetDemandPSADAO.getInstance().getTotalTarget(crop, DBHandler.getInstance(mActivity).getDBObject(0));
			if(totalTargetList != null && totalTargetList.size() == 2){
				totalTarget = totalTargetList.get(0);
				totalTargetFrm = totalTargetList.get(1);
			}

			List<Integer> tillDateTargetList = TargetDemandPSADAO.getInstance().getTillDateTarget(crop, Utility.getCurrentDateFrm(), DBHandler.getInstance(mActivity).getDBObject(0));
			if(tillDateTargetList != null && tillDateTargetList.size() == 2){
				tillDateTarget = tillDateTargetList.get(0);
				tillDateTargetFrm = tillDateTargetList.get(1);
			}

			List<Integer> achievedList = DemandSummaryDAO.getInstance().getActivitiesCount(crop,""+ MyConstants.ACTIVITY_PSA_ID, DBHandler.getInstance(mActivity).getDBObject(0));
			if(achievedList != null && achievedList.size() == 2){
				targetAchieved = achievedList.get(0);
				targetAchievedFrm = achievedList.get(1);
			}

			drawGraph(targetAchieved, tillDateTarget, totalTarget);
		}

		
		List<DTO> hybridsList = Top3HybridsDAO.getInstance().getRecords(selectedActivityId, selectedCrop, DBHandler.getInstance(mActivity).getDBObject(0));
		if(hybridsList != null && hybridsList.size() > 0){
			hybridIdsList.clear();
			hybridNamesList.clear();
			activityAchievedMap.clear();
			activityTargetMap.clear();
			farmersAchievedMap.clear();
			farmersTargetMap.clear();
			for(DTO dto : hybridsList){
				Top3HybridsDTO hybridsDTO = (Top3HybridsDTO) dto;
				hybridIdsList.add(hybridsDTO.getHybridId());
				hybridNamesList.add(hybridsDTO.getHybridName());
				List<Integer> totalAchievedList = null;
				List<Integer> totalHybridTargetList = null;
				
				switch(selectedActivityId){
				case MyConstants.ACTIVITY_PDA_ID:
					 
					totalHybridTargetList = TargetDemandPDADAO.getInstance().getTotalTargetByHybrid(String.valueOf(hybridsDTO.getHybridId()), DBHandler.getInstance(mActivity).getDBObject(0));
					
					totalAchievedList = DemandSummaryDAO.getInstance().getAchievedCount(""+MyConstants.ACTIVITY_PDA_ID, selectedCrop, hybridsDTO.getHybridId(),  DBHandler.getInstance(mActivity).getDBObject(0));
					
					break;
				case MyConstants.ACTIVITY_OSA_ID:
					 	
					totalHybridTargetList = TargetDemandOSADAO.getInstance().getTotalTargetByHybrid(String.valueOf(hybridsDTO.getHybridId()), DBHandler.getInstance(mActivity).getDBObject(0));
					
					totalAchievedList = DemandSummaryDAO.getInstance().getAchievedCount(""+MyConstants.ACTIVITY_OSA_ID, selectedCrop, hybridsDTO.getHybridId(),  DBHandler.getInstance(mActivity).getDBObject(0));
					
					break;
				case MyConstants.ACTIVITY_PSA_ID:
					 
					totalHybridTargetList = TargetDemandPSADAO.getInstance().getTotalTargetByHybrid(String.valueOf(hybridsDTO.getHybridId()), DBHandler.getInstance(mActivity).getDBObject(0));
					
					totalAchievedList = DemandSummaryDAO.getInstance().getAchievedCount(""+MyConstants.ACTIVITY_PSA_ID, selectedCrop, hybridsDTO.getHybridId(),  DBHandler.getInstance(mActivity).getDBObject(0));
					
					break;
				}
				
				
				
				if(totalHybridTargetList != null && totalHybridTargetList.size() == 2){
					activityTargetMap.put(hybridsDTO.getHybridName(), totalHybridTargetList.get(0));
					farmersTargetMap.put(hybridsDTO.getHybridName(), totalHybridTargetList.get(1));
				}
				
				if(totalAchievedList != null && totalAchievedList.size() == 2){
					activityAchievedMap.put(hybridsDTO.getHybridName(), totalAchievedList.get(0));
					farmersAchievedMap.put(hybridsDTO.getHybridName(), totalAchievedList.get(1));
				}
				
			}
			
			if(activityTargetMap != null && activityAchievedMap != null){
				setDateToActivityBarGraph(activityTargetMap, activityAchievedMap);
			}
			
			if(farmersTargetMap != null && farmersAchievedMap != null){
				setDateToFarmerBarGraph(farmersTargetMap, farmersAchievedMap);
			}
		}
		
	} // end cropSelection	
	
	private void hideCropLayouts(){
		cropCornLayout.setVisibility(View.GONE);
		cropRiceLayout.setVisibility(View.GONE);
		cropMilletLayout.setVisibility(View.GONE);
		cropMustardLayout.setVisibility(View.GONE);
		mActivityBarChart.clear();
		mFarmerBarChart.clear();
	}

	private void setActivityBarChatProperties() {
		
		mActivityBarChart.setDrawBarShadow(false);
		mActivityBarChart.setDrawValueAboveBar(true);

		mActivityBarChart.setDescription("");

		// if more than 60 entries are displayed in the chart, no values will be
		// drawn
		mActivityBarChart.setMaxVisibleValueCount(60);

		// scaling can now only be done on x- and y-axis separately
		mActivityBarChart.setPinchZoom(true);

		//mBarChart.animateXY(2000, 2000);

		// draw shadows for each bar that show the maximum value
		// mChart.setDrawBarShadow(true);

		// mChart.setDrawXLabels(false);

		mActivityBarChart.setDrawGridBackground(false);
		// mChart.setDrawYLabels(false);
		
		mActivityBarChart.getLegend().setEnabled(false);

		// mTf = Typeface.createFromAsset(getAssets(), "OpenSans-Regular.ttf");

		XAxis xAxis = mActivityBarChart.getXAxis();
		xAxis.setPosition(XAxisPosition.BOTTOM);
		// xAxis.setTypeface(mTf);
		xAxis.setDrawGridLines(false);
		xAxis.setSpaceBetweenLabels(2);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			xAxis.setTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			xAxis.setTextColor(Color.BLACK);
		}

		ValueFormatter custom = new com.activitytrack.graph.MyValueFormatter();

		YAxis leftAxis = mActivityBarChart.getAxisLeft();
		leftAxis.setDrawGridLines(false);
		// leftAxis.setTypeface(mTf);
		leftAxis.setLabelCount(8);
		leftAxis.setValueFormatter(custom);
		leftAxis.setPosition(YAxisLabelPosition.OUTSIDE_CHART);
		leftAxis.setSpaceTop(15f);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			leftAxis.setTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			leftAxis.setTextColor(Color.BLACK);
		}

		YAxis rightAxis = mActivityBarChart.getAxisRight();
		rightAxis.setEnabled(false);
		rightAxis.setDrawGridLines(false);
		// rightAxis.setTypeface(mTf);
		//rightAxis.setLabelCount(8);
		//rightAxis.setValueFormatter(custom);
		//rightAxis.setSpaceTop(15f);

		Legend l = mActivityBarChart.getLegend();
		l.setPosition(LegendPosition.BELOW_CHART_LEFT);
		l.setForm(LegendForm.SQUARE);
		l.setFormSize(9f);
		l.setTextSize(11f);
		l.setXEntrySpace(4f);

		// setData(12, 50);

		//setDateToActivityBarGraph();

	}
	
	public void setDateToActivityBarGraph(LinkedHashMap<String, Integer> graphDataMap, LinkedHashMap<String, Integer> graphDataMap2){
		
		Set<String> keys2 = graphDataMap.keySet();
		System.out.println("ffffff"+keys2);
		
		List<String> xVals2 = new ArrayList<String>();
		List<Integer> valuesList2 = new ArrayList<Integer>();
		for(String key:keys2){
			xVals2.add(key);
			valuesList2.add(graphDataMap.get(key));
		}
		
		ArrayList<BarEntry> yVals2 = new ArrayList<BarEntry>();
		
		for (int i = 0; i < valuesList2.size(); i++) {
			yVals2.add(new BarEntry(valuesList2.get(i), i));
		}
		
		BarDataSet set2 = new BarDataSet(yVals2, "DataSet1");
		
		set2.setBarSpacePercent(35f);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			set2.setValueTextColor(Color.WHITE);
			set2.setColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			set2.setColor(Color.rgb(195, 195, 195));
			set2.setValueTextColor(Color.BLACK);
		}
		
		Set<String> keys3 = graphDataMap2.keySet();
		
		List<String> xVals3 = new ArrayList<String>();
		List<Integer> valuesList3 = new ArrayList<Integer>();
		
		for(String key:keys3){
			xVals3.add(key);
			valuesList3.add(graphDataMap2.get(key));
		}
		
		ArrayList<BarEntry> yVals3 = new ArrayList<BarEntry>();
		
		for (int i = 0; i < valuesList3.size(); i++) {
			yVals3.add(new BarEntry(valuesList3.get(i), i));
		}
		
		BarDataSet set3 = new BarDataSet(yVals3, "DataSet2");
		
		set3.setBarSpacePercent(35f);
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			set3.setValueTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			set3.setValueTextColor(Color.BLACK);
		}
		
		set3.setColor(Color.rgb(66, 119, 48));
		
		ArrayList<BarDataSet> dataSets = new ArrayList<BarDataSet>();
		dataSets.add(set2);
		dataSets.add(set3);
		
		BarData data = new BarData(xVals2, dataSets);
		data.setValueTextSize(10f);
		mActivityBarChart.setData(data);
		
	}
	
	private void setFarmerBarChatProperties() {
		
		mFarmerBarChart.setDrawBarShadow(false);
		mFarmerBarChart.setDrawValueAboveBar(true);

		mFarmerBarChart.setDescription("");

		// if more than 60 entries are displayed in the chart, no values will be
		// drawn
		mFarmerBarChart.setMaxVisibleValueCount(60);

		// scaling can now only be done on x- and y-axis separately
		mFarmerBarChart.setPinchZoom(true);

		//mBarChart.animateXY(2000, 2000);

		// draw shadows for each bar that show the maximum value
		// mChart.setDrawBarShadow(true);

		// mChart.setDrawXLabels(false);

		mFarmerBarChart.setDrawGridBackground(false);
		// mChart.setDrawYLabels(false);
		
		mFarmerBarChart.getLegend().setEnabled(false);

		// mTf = Typeface.createFromAsset(getAssets(), "OpenSans-Regular.ttf");

		XAxis xAxis = mFarmerBarChart.getXAxis();
		xAxis.setPosition(XAxisPosition.BOTTOM);
		// xAxis.setTypeface(mTf);
		xAxis.setDrawGridLines(false);
		xAxis.setSpaceBetweenLabels(2);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			xAxis.setTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			xAxis.setTextColor(Color.BLACK);
		}

		ValueFormatter custom = new com.activitytrack.graph.MyValueFormatter();

		YAxis leftAxis = mFarmerBarChart.getAxisLeft();
		leftAxis.setDrawGridLines(false);
		// leftAxis.setTypeface(mTf);
		leftAxis.setLabelCount(8);
		leftAxis.setValueFormatter(custom);
		leftAxis.setPosition(YAxisLabelPosition.OUTSIDE_CHART);
		leftAxis.setSpaceTop(15f);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			leftAxis.setTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			leftAxis.setTextColor(Color.BLACK);
		}

		YAxis rightAxis = mFarmerBarChart.getAxisRight();
		rightAxis.setEnabled(false);
		rightAxis.setDrawGridLines(false);
		// rightAxis.setTypeface(mTf);
		//rightAxis.setLabelCount(8);
		//rightAxis.setValueFormatter(custom);
		//rightAxis.setSpaceTop(15f);

		Legend l = mFarmerBarChart.getLegend();
		l.setPosition(LegendPosition.BELOW_CHART_LEFT);
		l.setForm(LegendForm.SQUARE);
		l.setFormSize(9f);
		l.setTextSize(11f);
		l.setXEntrySpace(4f);

		// setData(12, 50);

		//setDateToFarmerBarGraph();

	}
	
	public void setDateToFarmerBarGraph(LinkedHashMap<String, Integer> graphDataMap, LinkedHashMap<String, Integer> graphDataMap2){
		
		Set<String> keys2 = graphDataMap.keySet();
		System.out.println("ffffff"+keys2);
		
		List<String> xVals2 = new ArrayList<String>();
		List<Integer> valuesList2 = new ArrayList<Integer>();
		for(String key:keys2){
			xVals2.add(key);
			valuesList2.add(graphDataMap.get(key));
		}
		
		ArrayList<BarEntry> yVals2 = new ArrayList<BarEntry>();
		
		for (int i = 0; i < valuesList2.size(); i++) {
			yVals2.add(new BarEntry(valuesList2.get(i), i));
		}
		
		BarDataSet set2 = new BarDataSet(yVals2, "DataSet1");
		
		set2.setBarSpacePercent(35f);
		
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			set2.setValueTextColor(Color.WHITE);
			set2.setColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			set2.setColor(Color.rgb(195, 195, 195));
			set2.setValueTextColor(Color.BLACK);
		}
		
//		Map<String, Integer> graphDataMap2 = new HashMap<String, Integer>();
//		graphDataMap2.put("H-1", 12);
//		graphDataMap2.put("H-2", 11);
//		graphDataMap2.put("H-3", 19);
//		graphDataMap2.put("H-4", 17f);
//		graphDataMap2.put("H-5", 16f);
//		graphDataMap2.put("H-6", 10f);
//		graphDataMap2.put("H-7", 15f);
//		graphDataMap2.put("H-8", 10f);
//		graphDataMap2.put("H-9", 15f);
		
		Set<String> keys3 = graphDataMap2.keySet();
		
		List<String> xVals3 = new ArrayList<String>();
		List<Integer> valuesList3 = new ArrayList<Integer>();
		
		for(String key:keys3){
			xVals3.add(key);
			valuesList3.add(graphDataMap2.get(key));
		}
		
		ArrayList<BarEntry> yVals3 = new ArrayList<BarEntry>();
		
		for (int i = 0; i < valuesList3.size(); i++) {
			yVals3.add(new BarEntry(valuesList3.get(i), i));
		}
		
		BarDataSet set3 = new BarDataSet(yVals3, "DataSet2");
		
		set3.setBarSpacePercent(35f);
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			set3.setValueTextColor(Color.WHITE);
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			set3.setValueTextColor(Color.BLACK);
		}
		
		set3.setColor(Color.rgb(66, 119, 48));
		
		ArrayList<BarDataSet> dataSets = new ArrayList<BarDataSet>();
		dataSets.add(set2);
		dataSets.add(set3);
		
		BarData data = new BarData(xVals2, dataSets);
		data.setValueTextSize(10f);
		mFarmerBarChart.setData(data);
		
	}
	
	private void setTheme(){
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
			
			//legend text colors
			tvLegendTargetTillDate.setTextColor(Color.WHITE);
			tvLegendTillDate.setTextColor(Color.WHITE);
			tvLegendTotalTarget.setTextColor(Color.WHITE);			
			imgLegendTotalTarget.setBackgroundColor(Color.WHITE);
			tvTotalTarget.setTextColor(Color.WHITE);
			
			//activity images
			pdaImg.setBackgroundResource(R.drawable.pda_icon_d);
			osaImg.setBackgroundResource(R.drawable.osa_icon_d);
			psaImg.setBackgroundResource(R.drawable.psa_icon_d);
			
			//crop text colors
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_gray));
			
		}else if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)){
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
			
			//legend text colors
			tvLegendTargetTillDate.setTextColor(Color.BLACK);
			tvLegendTillDate.setTextColor(Color.BLACK);
			tvLegendTotalTarget.setTextColor(Color.BLACK);
			
			imgLegendTotalTarget.setBackgroundColor(Color.parseColor("#c3c3c3"));
			tvTotalTarget.setTextColor(Color.parseColor("#c3c3c3"));
			
			//activity images
			pdaImg.setBackgroundResource(R.drawable.pda_icon_l);
			osaImg.setBackgroundResource(R.drawable.osa_icon_l);
			psaImg.setBackgroundResource(R.drawable.psa_icon_l);
			
			//crop text colors
			cropCornTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMilletTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropMustardTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			cropRiceTxt.setTextColor(getResources().getColor(R.color.dark_theme_text_black));
			
		}
		
	}
	
	@Override
	public boolean onBackPressed(int callbackCode) {
		mActivity.onBackPressedCallBack(callbackCode);
		return true;
	}

	
	
	}
