package com.activitytrack.daos;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.MdrSurveyDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fatima.t on 29-03-2018.
 */

public class MdrSurveyDAO implements DAO {
    private final String TAG = "villageSurvey";
    private static MdrSurveyDAO mdrSurveyDAO;

    public static MdrSurveyDAO getInstance() {
        if (mdrSurveyDAO == null) {
            mdrSurveyDAO = new MdrSurveyDAO();
        }

        return mdrSurveyDAO;
    }

    /**
     * delete the Data
     */

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {

        return false;
    }


    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */

    @SuppressLint("LongLogTag")
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_SURVEY where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    /*String localImagePath;
                    String latlong;
                    String geoLocation;
                    String farmerName;
                    String mobileNo;
                    long noOfFamilies;
                    long totalLand;
                    String majorCropOneName;
                    long hybridAcresOne;
                    String majorCropTwoName;
                    long hybridAcresTwo;
                    String cropAcreageFor;
                    String segmentDetails;
                    long pioneerAcres;
                    long pioneerHybridOneId;
                    String pioneerHybridOneName;
                    long pioneerHybridTwoId;
                    String pioneerHybridTwoName;
                    String majorCompetitorOne;
                    long majorCompetitorOneAcres;
                    String majorCompetitorTwo;
                    long majorCompetitorTwoAcres;

                    long mobileId;
                    long activityId;*/

                    MdrSurveyDTO dto = new MdrSurveyDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setLocalImagePath(cursor.getString(1));
                    dto.setLatlong(cursor.getString(2));
//                    dto.setGeoLocation(cursor.getString(3));
                    dto.setFarmerName(cursor.getString(3));
                    dto.setMobileNo(cursor.getString(4));
                    dto.setNoOfFamilies(cursor.getLong(5));
                    dto.setTotalLand(cursor.getLong(6));
                    dto.setMajorCropOneName(cursor.getString(7));
                    dto.setHybridAcresOne(cursor.getLong(8));
                    dto.setMajorCropTwoName(cursor.getString(9));
                    dto.setHybridAcresTwo(cursor.getLong(10));
                    dto.setCropAcreageFor(cursor.getString(11));
                    dto.setSegmentDetails(cursor.getString(12));
                    dto.setPioneerAcres(cursor.getLong(13));
                    dto.setPioneerHybridOneId(cursor.getLong(14));
                    dto.setPioneerHybridOneName(cursor.getString(15));
                    dto.setPioneerHybridTwoId(cursor.getLong(16));
                    dto.setPioneerHybridTwoName(cursor.getString(17));
                    dto.setMajorCompetitorOne(cursor.getString(18));
                    dto.setMajorCompetitorOneAcres(cursor.getLong(19));
                    dto.setMajorCompetitorTwo(cursor.getString(20));
                    dto.setMajorCompetitorTwoAcres(cursor.getLong(21));
                    dto.setActivityId(cursor.getLong(22));

                    addSurveyInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    @SuppressLint("LongLogTag")
    public List<DTO> getRecordInfoById(long activityId, SQLiteDatabase dbObject) {

        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_SURVEY where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    MdrSurveyDTO dto = new MdrSurveyDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setLocalImagePath(cursor.getString(1));
                    dto.setLatlong(cursor.getString(2));
//                    dto.setGeoLocation(cursor.getString(3));
                    dto.setFarmerName(cursor.getString(3));
                    dto.setMobileNo(cursor.getString(4));
                    dto.setNoOfFamilies(cursor.getLong(5));
                    dto.setTotalLand(cursor.getLong(6));
                    dto.setMajorCropOneName(cursor.getString(7));
                    dto.setHybridAcresOne(cursor.getLong(8));
                    dto.setMajorCropTwoName(cursor.getString(9));
                    dto.setHybridAcresTwo(cursor.getLong(10));
                    dto.setCropAcreageFor(cursor.getString(11));
                    dto.setSegmentDetails(cursor.getString(12));
                    dto.setPioneerAcres(cursor.getLong(13));
                    dto.setPioneerHybridOneId(cursor.getLong(14));
                    dto.setPioneerHybridOneName(cursor.getString(15));
                    dto.setPioneerHybridTwoId(cursor.getLong(16));
                    dto.setPioneerHybridTwoName(cursor.getString(17));
                    dto.setMajorCompetitorOne(cursor.getString(18));
                    dto.setMajorCompetitorOneAcres(cursor.getLong(19));
                    dto.setMajorCompetitorTwo(cursor.getString(20));
                    dto.setMajorCompetitorTwoAcres(cursor.getLong(21));
                    dto.setActivityId(cursor.getLong(22));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */


    @SuppressLint("LongLogTag")
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_SURVEY", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    MdrSurveyDTO dto = new MdrSurveyDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setLocalImagePath(cursor.getString(1));
                    dto.setLatlong(cursor.getString(2));
//                    dto.setGeoLocation(cursor.getString(3));
                    dto.setFarmerName(cursor.getString(3));
                    dto.setMobileNo(cursor.getString(4));
                    dto.setNoOfFamilies(cursor.getLong(5));
                    dto.setTotalLand(cursor.getLong(6));
                    dto.setMajorCropOneName(cursor.getString(7));
                    dto.setHybridAcresOne(cursor.getLong(8));
                    dto.setMajorCropTwoName(cursor.getString(9));
                    dto.setHybridAcresTwo(cursor.getLong(10));
                    dto.setCropAcreageFor(cursor.getString(11));
                    dto.setSegmentDetails(cursor.getString(12));
                    dto.setPioneerAcres(cursor.getLong(13));
                    dto.setPioneerHybridOneId(cursor.getLong(14));
                    dto.setPioneerHybridOneName(cursor.getString(15));
                    dto.setPioneerHybridTwoId(cursor.getLong(16));
                    dto.setPioneerHybridTwoName(cursor.getString(17));
                    dto.setMajorCompetitorOne(cursor.getString(18));
                    dto.setMajorCompetitorOneAcres(cursor.getLong(19));
                    dto.setMajorCompetitorTwo(cursor.getString(20));
                    dto.setMajorCompetitorTwoAcres(cursor.getLong(21));
                    dto.setActivityId(cursor.getLong(22));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }


    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */


    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            MdrSurveyDTO dto = (MdrSurveyDTO) dtoObject;

            ContentValues cValues = new ContentValues();

                    /*  id INTEGER PRIMARY KEY AUTOINCREMENT,
                    localImagePath TEXT,
                    latlong TEXT,
                    geoLocation TEXT,
                    farmerName TEXT,
                    mobileNo TEXT,
                    noOfFamilies NUMBER,
                    totalLand NUMBER,
                    majorCropOneName TEXT,
                    hybridAcresOne NUMBER,
                    majorCropTwoName TEXT,
                    hybridAcresTwo NUMBER,
                    cropAcreageFor TEXT,
                    segmentDetails TEXT,
                    pioneerAcres NUMBER,
                    pioneerHybridOneId NUMBER,
                    pioneerHybridOneName TEXT,
                    pioneerHybridTwoId NUMBER,
                    pioneerHybridTwoName TEXT,
                    majorCompetitorOne TEXT,
                    majorCompetitorOneAcres NUMBER,
                    majorCompetitorTwo TEXT,
                    majorCompetitorTwoAcres NUMBER,
                    activityId NUMBER    */

            cValues.put("localImagePath", dto.getLocalImagePath());
            cValues.put("latlong", dto.getLatlong());
//            cValues.put("geoLocation", dto.getGeoLocation());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("mobileNo", dto.getMobileNo());
            cValues.put("noOfFamilies", dto.getNoOfFamilies());
            cValues.put("totalLand", dto.getTotalLand());
            cValues.put("majorCropOneName", dto.getMajorCropOneName());
            cValues.put("hybridAcresOne", dto.getHybridAcresOne());
            cValues.put("majorCropTwoName", dto.getMajorCropTwoName());
            cValues.put("hybridAcresTwo", dto.getHybridAcresTwo());
            cValues.put("cropAcreageFor", dto.getCropAcreageFor());
            cValues.put("segmentDetails", dto.getSegmentDetails());
            cValues.put("pioneerAcres", dto.getPioneerAcres());
            cValues.put("pioneerHybridOneId", dto.getPioneerHybridOneId());
            cValues.put("pioneerHybridOneName", dto.getPioneerHybridOneName());
            cValues.put("pioneerHybridTwoId", dto.getPioneerHybridTwoId());
            cValues.put("pioneerHybridTwoName", dto.getPioneerHybridTwoName());
            cValues.put("majorCompetitorOne", dto.getMajorCompetitorOne());
            cValues.put("majorCompetitorOneAcres", dto.getMajorCompetitorOneAcres());
            cValues.put("majorCompetitorTwo", dto.getMajorCompetitorTwo());
            cValues.put("majorCompetitorTwoAcres", dto.getMajorCompetitorTwoAcres());
            cValues.put("activityId", dto.getActivityId());

            dbObject.insert("ADD_MDR_SURVEY", null, cValues);
            return true;
        } catch (SQLException e) {
            Log.e(TAG + "insert()", e.getMessage());
            return false;
        } finally {
            dbObject.close();
        }

    }


    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            MdrSurveyDTO dto = (MdrSurveyDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getLocalImagePath() != null)
               cValues.put("localImagePath", dto.getLocalImagePath());

            if (dto.getLatlong() != null)
                cValues.put("latlong", dto.getLatlong());

            /*if (dto.getGeoLocation() != null)
                cValues.put("geoLocation", dto.getGeoLocation());*/

            if (dto.getFarmerName() != null)
                cValues.put("farmerName", dto.getFarmerName());

            if (dto.getMobileNo() != null)
                cValues.put("mobileNo", dto.getMobileNo());

            if (dto.getNoOfFamilies() != 0)
                cValues.put("noOfFamilies", dto.getNoOfFamilies());

            if (dto.getTotalLand() != 0)
                cValues.put("totalLand", dto.getTotalLand());

            if (dto.getMajorCropOneName() != null)
                cValues.put("majorCropOneName", dto.getMajorCropOneName());

            if (dto.getHybridAcresOne() != 0)
                cValues.put("hybridAcresOne", dto.getHybridAcresOne());

            if (dto.getMajorCropTwoName() != null)
                cValues.put("majorCropTwoName", dto.getMajorCropTwoName());

            if (dto.getHybridAcresTwo() != 0)
                cValues.put("hybridAcresTwo", dto.getHybridAcresTwo());

            if (dto.getCropAcreageFor() != null)
                cValues.put("cropAcreageFor", dto.getCropAcreageFor());

            if (dto.getSegmentDetails() != null)
                cValues.put("segmentDetails", dto.getSegmentDetails());

            if (dto.getPioneerAcres() != 0)
                cValues.put("pioneerAcres", dto.getPioneerAcres());

            if (dto.getPioneerHybridOneId() != 0)
                cValues.put("pioneerHybridOneId", dto.getPioneerHybridOneId());

            if (dto.getPioneerHybridOneName() != null)
                cValues.put("pioneerHybridOneName", dto.getPioneerHybridOneName());

            if (dto.getPioneerHybridTwoId() != 0)
                cValues.put("pioneerHybridTwoId", dto.getPioneerHybridTwoId());

            if (dto.getPioneerHybridTwoName() != null)
                cValues.put("pioneerHybridTwoName", dto.getPioneerHybridTwoName());

            if (dto.getMajorCompetitorOne() != null)
                cValues.put("majorCompetitorOne", dto.getMajorCompetitorOne());

            if (dto.getMajorCompetitorOneAcres() != 0)
                cValues.put("majorCompetitorOneAcres", dto.getMajorCompetitorOneAcres());

            if (dto.getMajorCompetitorTwo() != null)
                cValues.put("majorCompetitorTwo", dto.getMajorCompetitorTwo());

            if (dto.getMajorCompetitorTwoAcres() != 0)
                cValues.put("majorCompetitorTwoAcres", dto.getMajorCompetitorTwoAcres());

            if (dto.getActivityId() != 0)
                cValues.put("activityId", dto.getActivityId());


            dbObject.update("ADD_MDR_SURVEY", cValues, "id='" + dto.getId() + "' ", null);

            return true;
        } catch (SQLException e) {
            Log.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    @SuppressLint("LongLogTag")
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM ADD_MDR_SURVEY").execute();
            return true;
        } catch (Exception e) {
            Log.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    @SuppressLint("LongLogTag")
    public List<MdrSurveyDTO> getRecordsForUpload(long activityId, SQLiteDatabase dbObject) {

        List<MdrSurveyDTO> addSurveyInfo = new ArrayList<MdrSurveyDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_SURVEY where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    MdrSurveyDTO dto = new MdrSurveyDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setLocalImagePath(cursor.getString(1));
                    dto.setLatlong(cursor.getString(2));
//                    dto.setGeoLocation(cursor.getString(3));
                    dto.setFarmerName(cursor.getString(3));
                    dto.setMobileNo(cursor.getString(4));
                    dto.setNoOfFamilies(cursor.getLong(5));
                    dto.setTotalLand(cursor.getLong(6));
                    dto.setMajorCropOneName(cursor.getString(7));
                    dto.setHybridAcresOne(cursor.getLong(8));
                    dto.setMajorCropTwoName(cursor.getString(9));
                    dto.setHybridAcresTwo(cursor.getLong(10));
                    dto.setCropAcreageFor(cursor.getString(11));
                    dto.setSegmentDetails(cursor.getString(12));
                    dto.setPioneerAcres(cursor.getLong(13));
                    dto.setPioneerHybridOneId(cursor.getLong(14));
                    dto.setPioneerHybridOneName(cursor.getString(15));
                    dto.setPioneerHybridTwoId(cursor.getLong(16));
                    dto.setPioneerHybridTwoName(cursor.getString(17));
                    dto.setMajorCompetitorOne(cursor.getString(18));
                    dto.setMajorCompetitorOneAcres(cursor.getLong(19));
                    dto.setMajorCompetitorTwo(cursor.getString(20));
                    dto.setMajorCompetitorTwoAcres(cursor.getLong(21));
                    dto.setActivityId(cursor.getLong(22));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }

           dbObject.close();
        }

        return addSurveyInfo;
    }

    @SuppressLint("LongLogTag")
    public boolean deleteTableDataById(long activityId, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM ADD_MDR_SURVEY where activityId = '" + activityId + "'").execute();
            return true;
        } catch (Exception e) {
            Log.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    @SuppressLint("LongLogTag")
    public List<MdrSurveyDTO> getRecordInfoByView(long activityId, SQLiteDatabase dbObject) {

        List<MdrSurveyDTO> addSurveyInfo = new ArrayList<MdrSurveyDTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_SURVEY where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    MdrSurveyDTO dto = new MdrSurveyDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setLocalImagePath(cursor.getString(1));
                    dto.setLatlong(cursor.getString(2));
//                    dto.setGeoLocation(cursor.getString(3));
                    dto.setFarmerName(cursor.getString(3));
                    dto.setMobileNo(cursor.getString(4));
                    dto.setNoOfFamilies(cursor.getLong(5));
                    dto.setTotalLand(cursor.getLong(6));
                    dto.setMajorCropOneName(cursor.getString(7));
                    dto.setHybridAcresOne(cursor.getLong(8));
                    dto.setMajorCropTwoName(cursor.getString(9));
                    dto.setHybridAcresTwo(cursor.getLong(10));
                    dto.setCropAcreageFor(cursor.getString(11));
                    dto.setSegmentDetails(cursor.getString(12));
                    dto.setPioneerAcres(cursor.getLong(13));
                    dto.setPioneerHybridOneId(cursor.getLong(14));
                    dto.setPioneerHybridOneName(cursor.getString(15));
                    dto.setPioneerHybridTwoId(cursor.getLong(16));
                    dto.setPioneerHybridTwoName(cursor.getString(17));
                    dto.setMajorCompetitorOne(cursor.getString(18));
                    dto.setMajorCompetitorOneAcres(cursor.getLong(19));
                    dto.setMajorCompetitorTwo(cursor.getString(20));
                    dto.setMajorCompetitorTwoAcres(cursor.getLong(21));
                    dto.setActivityId(cursor.getLong(22));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    public boolean deleteDataById(String activityId ,SQLiteDatabase dbObject) {
        try
        {
            dbObject.execSQL("DELETE FROM ADD_MDR_SURVEY where activityId = '"+activityId+"'");
            return true;
        }catch(Exception e)
        {
            ATBuildLog.e(TAG +"delete",e.getMessage());
        }finally

        {

            dbObject.close();

        }
        return false;
    }

}
