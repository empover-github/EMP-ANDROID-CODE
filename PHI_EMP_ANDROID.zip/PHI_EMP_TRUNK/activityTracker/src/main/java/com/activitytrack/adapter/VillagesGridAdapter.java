package com.activitytrack.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.activitytrack.activity.R;

public class VillagesGridAdapter extends BaseAdapter {
	private List<String> list;
	private Context context;
	public VillagesGridAdapter(List<String> list, Context context) {
		this.list = list;
		this.context = context;
	}

	@Override
	public int getCount() {
		
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;

        if (convertView == null)
        {

            gridView = new View(context);

            // get layout from mobile.xml
            gridView = inflater.inflate(R.layout.villages_grid_item, null);

            // set value into textview
           

            // set image based on selected text
            ImageView imageView = (ImageView) gridView.findViewById(R.id.pda_grid_closeBtn);
            TextView textView = (TextView) gridView.findViewById(R.id.pda_grid_villageName);
            textView.setText(list.get(position));
            
            imageView.setTag(position);
            
            imageView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					int position = (Integer) v.getTag();
					
				}
			});

        } else
        {
            gridView = (View) convertView;
        }

        return gridView;
    }
	
}
