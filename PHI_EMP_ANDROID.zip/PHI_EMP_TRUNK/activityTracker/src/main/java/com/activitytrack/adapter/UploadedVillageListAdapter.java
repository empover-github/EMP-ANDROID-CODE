package com.activitytrack.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.dtos.UploadedVillageListDTO;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by fatima.t on 20/12/2017.
 */

public class UploadedVillageListAdapter extends RecyclerView.Adapter<UploadedVillageListAdapter.UploadedVillageHolder> {
    Context context;
    List<UploadedVillageListDTO> profilesList;
//    private OnListItemClickListener listener;

    public UploadedVillageListAdapter(Context context, List<UploadedVillageListDTO> profilesList/*, OnListItemClickListener listener*/) {
        this.context = context;
        this.profilesList = profilesList;
//        this.listener = listener;
    }

    @Override
    public UploadedVillageHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View notifiView = LayoutInflater.from(parent.getContext()).inflate(R.layout.uploaded_village_list_item, parent, false);
        return new UploadedVillageHolder(notifiView);
    }

    @Override
    public void onBindViewHolder(UploadedVillageHolder holder, int position) {
        holder.bind(profilesList.get(position), position);
    }

    @Override
    public int getItemCount() {
        return profilesList.size();
    }


    public class UploadedVillageHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvSNo, tvVillageName, tvCrop_Season, tvUploadedDate;
        LinearLayout mainLayout;

        public UploadedVillageHolder(View view) {
            super(view);

            mainLayout = (LinearLayout) view.findViewById(R.id.uvl_list_mainLayout);
            tvSNo = (TextView) view.findViewById(R.id.uvl_sno);
            tvVillageName = (TextView) view.findViewById(R.id.uvl_villageName);
            tvCrop_Season = (TextView) view.findViewById(R.id.uvl_crop_season);
            tvUploadedDate = (TextView) view.findViewById(R.id.uvl_uploadDate);

        }

        public void bind(final UploadedVillageListDTO profileModel, int position) {

            position=position+1;
            /*if (position == 0) {
                tvSNo.setText(profileModel.getSno());
                tvUploadedDate.setText(profileModel.getUploadedDate());
            } else {*/
                tvSNo.setText(String.valueOf(position));
                tvUploadedDate.setText(formatDateToServer(profileModel.getUploadedDate()));
          // }

            tvVillageName.setText(profileModel.getVillageName());
            tvCrop_Season.setText( profileModel.getSeason()+ "-" +profileModel.getCrop() );
        }

        @Override
        public void onClick(View v) {
            /*listener.onItemClick(v, getAdapterPosition());*/
        }
    }


    public static String formatDateToServer(String str) {
        String date = "";
        SimpleDateFormat myDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"); // existing format
        try {
            Date date1 = myDateFormat.parse(str);
            SimpleDateFormat myDateFormat2 = new SimpleDateFormat("dd-MMM-yy HH:mm");  // required format
            date = myDateFormat2.format(date1);
        } catch (java.text.ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

}
