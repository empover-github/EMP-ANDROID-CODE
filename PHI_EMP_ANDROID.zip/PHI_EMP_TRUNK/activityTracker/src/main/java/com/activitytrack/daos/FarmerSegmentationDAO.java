package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.SegmentationRequestDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fatima.t on 04-12-2018.
 */

public class FarmerSegmentationDAO implements DAO {

    private final String TAG = "segmentationRequest";
    private static FarmerSegmentationDAO segRequestDAO;

    public static FarmerSegmentationDAO getInstance() {
        if (segRequestDAO == null) {
            segRequestDAO = new FarmerSegmentationDAO();
        }
        return segRequestDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> getRecordsListByValue = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_REQUEST where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setPlanGrainAc(cursor.getFloat(cursor.getColumnIndex("planGrainAc")));
                    dto.setPlansilageAc(cursor.getFloat(cursor.getColumnIndex("plansilageAc")));
                    dto.setPhiGrainAc(cursor.getFloat(cursor.getColumnIndex("phiGrainAc")));
                    dto.setPhiSilageAc(cursor.getFloat(cursor.getColumnIndex("phiSilageAc")));
                    dto.setGrainHybrid1(cursor.getString(cursor.getColumnIndex("grainHybrid1")));
                    dto.setGrainHybrid2(cursor.getString(cursor.getColumnIndex("grainHybrid2")));
                    dto.setGrainHybrid3(cursor.getString(cursor.getColumnIndex("grainHybrid3")));
                    dto.setGrainHybrid4(cursor.getString(cursor.getColumnIndex("grainHybrid4")));
                    dto.setGrainHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainHybridValue1")));
                    dto.setGrainHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainHybridValue2")));
                    dto.setGrainHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainHybridValue3")));
                    dto.setGrainHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainHybridValue4")));
                    dto.setSilageHybrid1(cursor.getString(cursor.getColumnIndex("silageHybrid1")));
                    dto.setSilageHybrid2(cursor.getString(cursor.getColumnIndex("silageHybrid2")));
                    dto.setSilageHybrid3(cursor.getString(cursor.getColumnIndex("silageHybrid3")));
                    dto.setSilageHybrid4(cursor.getString(cursor.getColumnIndex("silageHybrid4")));
                    dto.setSilageHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageHybridValue1")));
                    dto.setSilageHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageHybridValue2")));
                    dto.setSilageHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageHybridValue3")));
                    dto.setSilageHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageHybridValue4")));
                    dto.setGrainCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid1")));
                    dto.setGrainCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid2")));
                    dto.setGrainCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid3")));
                    dto.setGrainCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid4")));
                    dto.setGrainCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue1")));
                    dto.setGrainCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue2")));
                    dto.setGrainCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue3")));
                    dto.setGrainCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue4")));
                    dto.setSilageCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid1")));
                    dto.setSilageCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid2")));
                    dto.setSilageCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid3")));
                    dto.setSilageCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid4")));
                    dto.setSilageCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue1")));
                    dto.setSilageCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue2")));
                    dto.setSilageCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue3")));
                    dto.setSilageCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue4")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setGrainServices(cursor.getString(cursor.getColumnIndex("grainServices")));
                    dto.setSilageServices(cursor.getString(cursor.getColumnIndex("silageServices")));

                    dto.setVisitedCornHybrid(cursor.getString(cursor.getColumnIndex("visitedCornHybrid")));
                    dto.setVisitedCornHybridLike(cursor.getString(cursor.getColumnIndex("visitedCornHybridLike")));
                    dto.setRateHybrid(cursor.getString(cursor.getColumnIndex("rateHybrid")));
                    dto.setShiftNextYrAcres(cursor.getString(cursor.getColumnIndex("shiftNextYrAcres")));

                    dto.setGrainCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid5")));
                    dto.setGrainCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue5")));
                    dto.setSilageCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid5")));
                    dto.setSilageCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue5")));

                    getRecordsListByValue.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return getRecordsListByValue;
    }


    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_REQUEST ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setPlanGrainAc(cursor.getFloat(cursor.getColumnIndex("planGrainAc")));
                    dto.setPlansilageAc(cursor.getFloat(cursor.getColumnIndex("plansilageAc")));
                    dto.setPhiGrainAc(cursor.getFloat(cursor.getColumnIndex("phiGrainAc")));
                    dto.setPhiSilageAc(cursor.getFloat(cursor.getColumnIndex("phiSilageAc")));
                    dto.setGrainHybrid1(cursor.getString(cursor.getColumnIndex("grainHybrid1")));
                    dto.setGrainHybrid2(cursor.getString(cursor.getColumnIndex("grainHybrid2")));
                    dto.setGrainHybrid3(cursor.getString(cursor.getColumnIndex("grainHybrid3")));
                    dto.setGrainHybrid4(cursor.getString(cursor.getColumnIndex("grainHybrid4")));
                    dto.setGrainHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainHybridValue1")));
                    dto.setGrainHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainHybridValue2")));
                    dto.setGrainHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainHybridValue3")));
                    dto.setGrainHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainHybridValue4")));
                    dto.setSilageHybrid1(cursor.getString(cursor.getColumnIndex("silageHybrid1")));
                    dto.setSilageHybrid2(cursor.getString(cursor.getColumnIndex("silageHybrid2")));
                    dto.setSilageHybrid3(cursor.getString(cursor.getColumnIndex("silageHybrid3")));
                    dto.setSilageHybrid4(cursor.getString(cursor.getColumnIndex("silageHybrid4")));
                    dto.setSilageHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageHybridValue1")));
                    dto.setSilageHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageHybridValue2")));
                    dto.setSilageHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageHybridValue3")));
                    dto.setSilageHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageHybridValue4")));
                    dto.setGrainCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid1")));
                    dto.setGrainCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid2")));
                    dto.setGrainCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid3")));
                    dto.setGrainCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid4")));
                    dto.setGrainCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue1")));
                    dto.setGrainCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue2")));
                    dto.setGrainCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue3")));
                    dto.setGrainCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue4")));
                    dto.setSilageCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid1")));
                    dto.setSilageCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid2")));
                    dto.setSilageCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid3")));
                    dto.setSilageCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid4")));
                    dto.setSilageCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue1")));
                    dto.setSilageCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue2")));
                    dto.setSilageCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue3")));
                    dto.setSilageCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue4")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setGrainServices(cursor.getString(cursor.getColumnIndex("grainServices")));
                    dto.setSilageServices(cursor.getString(cursor.getColumnIndex("silageServices")));

                    dto.setVisitedCornHybrid(cursor.getString(cursor.getColumnIndex("visitedCornHybrid")));
                    dto.setVisitedCornHybridLike(cursor.getString(cursor.getColumnIndex("visitedCornHybridLike")));
                    dto.setRateHybrid(cursor.getString(cursor.getColumnIndex("rateHybrid")));
                    dto.setShiftNextYrAcres(cursor.getString(cursor.getColumnIndex("shiftNextYrAcres")));

                    dto.setGrainCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid5")));
                    dto.setGrainCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue5")));
                    dto.setSilageCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid5")));
                    dto.setSilageCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue5")));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */
    @Override

    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {

        try {
            SegmentationRequestDTO dto = (SegmentationRequestDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            cValues.put("year", dto.getYear());
            cValues.put("season", dto.getSeason());
            cValues.put("crop", dto.getCrop());
            cValues.put("mobileNo", dto.getMobileNo());
            cValues.put("pincode", dto.getPincode());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("district", dto.getDistrict());
            cValues.put("village", dto.getVillage());
            cValues.put("block", dto.getBlock());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("totalPlanAc", dto.getTotalPlanAc());
            cValues.put("planGrainAc", dto.getPlanGrainAc());
            cValues.put("plansilageAc", dto.getPlansilageAc());
            cValues.put("phiGrainAc", dto.getPhiGrainAc());
            cValues.put("phiSilageAc", dto.getPhiSilageAc());
            cValues.put("grainHybrid1", dto.getGrainHybrid1());
            cValues.put("grainHybrid2", dto.getGrainHybrid2());
            cValues.put("grainHybrid3", dto.getGrainHybrid3());
            cValues.put("grainHybrid4", dto.getGrainHybrid4());
            cValues.put("grainHybridValue1", dto.getGrainHybridValue1());
            cValues.put("grainHybridValue2", dto.getGrainHybridValue2());
            cValues.put("grainHybridValue3", dto.getGrainHybridValue3());
            cValues.put("grainHybridValue4", dto.getGrainHybridValue4());
            cValues.put("silageHybrid1", dto.getSilageHybrid1());
            cValues.put("silageHybrid2", dto.getSilageHybrid2());
            cValues.put("silageHybrid3", dto.getSilageHybrid3());
            cValues.put("silageHybrid4", dto.getSilageHybrid4());
            cValues.put("silageHybridValue1", dto.getSilageHybridValue1());
            cValues.put("silageHybridValue2", dto.getSilageHybridValue2());
            cValues.put("silageHybridValue3", dto.getSilageHybridValue3());
            cValues.put("silageHybridValue4", dto.getSilageHybridValue4());
            cValues.put("grainCompetitorHybrid1", dto.getGrainCompetitorHybrid1());
            cValues.put("grainCompetitorHybrid2", dto.getGrainCompetitorHybrid2());
            cValues.put("grainCompetitorHybrid3", dto.getGrainCompetitorHybrid3());
            cValues.put("grainCompetitorHybrid4", dto.getGrainCompetitorHybrid4());
            cValues.put("grainCompetitorHybridValue1", dto.getGrainCompetitorHybridValue1());
            cValues.put("grainCompetitorHybridValue2", dto.getGrainCompetitorHybridValue2());
            cValues.put("grainCompetitorHybridValue3", dto.getGrainCompetitorHybridValue3());
            cValues.put("grainCompetitorHybridValue4", dto.getGrainCompetitorHybridValue4());
            cValues.put("silageCompetitorHybrid1", dto.getSilageCompetitorHybrid1());
            cValues.put("silageCompetitorHybrid2", dto.getSilageCompetitorHybrid2());
            cValues.put("silageCompetitorHybrid3", dto.getSilageCompetitorHybrid3());
            cValues.put("silageCompetitorHybrid4", dto.getSilageCompetitorHybrid4());
            cValues.put("silageCompetitorHybridValue1", dto.getSilageCompetitorHybridValue1());
            cValues.put("silageCompetitorHybridValue2", dto.getSilageCompetitorHybridValue2());
            cValues.put("silageCompetitorHybridValue3", dto.getSilageCompetitorHybridValue3());
            cValues.put("silageCompetitorHybridValue4", dto.getSilageCompetitorHybridValue4());
            cValues.put("isTBL", dto.getIsTBL());
            cValues.put("localImagePath", dto.getLocalImagePath());
            cValues.put("geoLocation", dto.getGeoLocation());
            cValues.put("timeStamp", dto.getDate());
            cValues.put("grainServices", dto.getGrainServices());
            cValues.put("silageServices", dto.getSilageServices());

            cValues.put("visitedCornHybrid", dto.getVisitedCornHybrid());
            cValues.put("visitedCornHybridLike", dto.getVisitedCornHybridLike());
            cValues.put("rateHybrid", dto.getRateHybrid());
            cValues.put("shiftNextYrAcres", dto.getShiftNextYrAcres());

            cValues.put("grainCompetitorHybrid5", dto.getGrainCompetitorHybrid5());
            cValues.put("grainCompetitorHybridValue5", dto.getGrainCompetitorHybridValue5());
            cValues.put("silageCompetitorHybrid5", dto.getSilageCompetitorHybrid5());
            cValues.put("silageCompetitorHybridValue5", dto.getSilageCompetitorHybridValue5());


            dbObject.insert("SEGMENTATION_REQUEST", null, cValues);

            return true;

        } catch (SQLException e) {

            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;


        } finally {
            dbObject.close();
        }

    }

    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            SegmentationRequestDTO dto = (SegmentationRequestDTO) dtoObject;
            /*id NUMBER, name TEXT, districtId TEXT*/

            ContentValues cValues = new ContentValues();

            cValues.put("year", dto.getYear());
            cValues.put("season", dto.getSeason());
            cValues.put("crop", dto.getCrop());
            cValues.put("mobileNo", dto.getMobileNo());
            cValues.put("pincode", dto.getPincode());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("district", dto.getDistrict());
            cValues.put("village", dto.getVillage());
            cValues.put("block", dto.getBlock());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("totalPlanAc", dto.getTotalPlanAc());
            cValues.put("planGrainAc", dto.getPlanGrainAc());
            cValues.put("plansilageAc", dto.getPlansilageAc());
            cValues.put("phiGrainAc", dto.getPhiGrainAc());
            cValues.put("phiSilageAc", dto.getPhiSilageAc());
            cValues.put("grainHybrid1", dto.getGrainHybrid1());
            cValues.put("grainHybrid2", dto.getGrainHybrid2());
            cValues.put("grainHybrid3", dto.getGrainHybrid3());
            cValues.put("grainHybrid4", dto.getGrainHybrid4());
            cValues.put("grainHybridValue1", dto.getGrainHybridValue1());
            cValues.put("grainHybridValue2", dto.getGrainHybridValue2());
            cValues.put("grainHybridValue3", dto.getGrainHybridValue3());
            cValues.put("grainHybridValue4", dto.getGrainHybridValue4());
            cValues.put("silageHybrid1", dto.getSilageHybrid1());
            cValues.put("silageHybrid2", dto.getSilageHybrid2());
            cValues.put("silageHybrid3", dto.getSilageHybrid3());
            cValues.put("silageHybrid4", dto.getSilageHybrid4());
            cValues.put("silageHybridValue1", dto.getSilageHybridValue1());
            cValues.put("silageHybridValue2", dto.getSilageHybridValue2());
            cValues.put("silageHybridValue3", dto.getSilageHybridValue3());
            cValues.put("silageHybridValue4", dto.getSilageHybridValue4());
            cValues.put("grainCompetitorHybrid1", dto.getGrainCompetitorHybrid1());
            cValues.put("grainCompetitorHybrid2", dto.getGrainCompetitorHybrid2());
            cValues.put("grainCompetitorHybrid3", dto.getGrainCompetitorHybrid3());
            cValues.put("grainCompetitorHybrid4", dto.getGrainCompetitorHybrid4());
            cValues.put("grainCompetitorHybridValue1", dto.getGrainCompetitorHybridValue1());
            cValues.put("grainCompetitorHybridValue2", dto.getGrainCompetitorHybridValue2());
            cValues.put("grainCompetitorHybridValue3", dto.getGrainCompetitorHybridValue3());
            cValues.put("grainCompetitorHybridValue4", dto.getGrainCompetitorHybridValue4());
            cValues.put("silageCompetitorHybrid1", dto.getSilageCompetitorHybrid1());
            cValues.put("silageCompetitorHybrid2", dto.getSilageCompetitorHybrid2());
            cValues.put("silageCompetitorHybrid3", dto.getSilageCompetitorHybrid3());
            cValues.put("silageCompetitorHybrid4", dto.getSilageCompetitorHybrid4());
            cValues.put("silageCompetitorHybridValue1", dto.getSilageCompetitorHybridValue1());
            cValues.put("silageCompetitorHybridValue2", dto.getSilageCompetitorHybridValue2());
            cValues.put("silageCompetitorHybridValue3", dto.getSilageCompetitorHybridValue3());
            cValues.put("silageCompetitorHybridValue4", dto.getSilageCompetitorHybridValue4());
            cValues.put("isTBL", dto.getIsTBL());
            cValues.put("localImagePath", dto.getLocalImagePath());
            cValues.put("geoLocation", dto.getGeoLocation());
            cValues.put("timeStamp", dto.getDate());
            cValues.put("grainServices", dto.getGrainServices());
            cValues.put("silageServices", dto.getSilageServices());

            cValues.put("visitedCornHybrid", dto.getVisitedCornHybrid());
            cValues.put("visitedCornHybridLike", dto.getVisitedCornHybridLike());
            cValues.put("rateHybrid", dto.getRateHybrid());
            cValues.put("shiftNextYrAcres", dto.getShiftNextYrAcres());

            cValues.put("grainCompetitorHybrid5", dto.getGrainCompetitorHybrid5());
            cValues.put("grainCompetitorHybridValue5", dto.getGrainCompetitorHybridValue5());
            cValues.put("silageCompetitorHybrid5", dto.getSilageCompetitorHybrid5());
            cValues.put("silageCompetitorHybridValue5", dto.getSilageCompetitorHybridValue5());

            long insertedRow = dbObject.insert("SEGMENTATION_REQUEST", null, cValues);
            if (insertedRow > 0) {
                Cursor cursor = dbObject.rawQuery("SELECT MAX(id) FROM  SEGMENTATION_REQUEST", null);
                if (cursor.getCount() > 0) {

                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            SegmentationRequestDTO dto = (SegmentationRequestDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getId() != 0)
                cValues.put("id", dto.getId());

            if (dto.getYear() != null)
                cValues.put("year", dto.getYear());

            if (dto.getSeason() != 0)
                cValues.put("season", dto.getSeason());

            if (dto.getCrop() != 0)
                cValues.put("crop", dto.getCrop());

            if (dto.getMobileNo() != null)
                cValues.put("mobileNo", dto.getMobileNo());

            if (dto.getPincode() != null)
                cValues.put("pincode", dto.getPincode());

            if (dto.getFarmerName() != null)
                cValues.put("farmerName", dto.getFarmerName());

            if (dto.getDistrict() != null)
                cValues.put("district", dto.getDistrict());

            if (dto.getVillage() != null)
                cValues.put("village", dto.getVillage());

            if (dto.getBlock() != null)
                cValues.put("block", dto.getBlock());

            cValues.put("isSync", dto.getIsSync());

            if (dto.getTotalPlanAc() != 0)
                cValues.put("totalPlanAc", dto.getTotalPlanAc());

            if (dto.getPlanGrainAc() != 0)
                cValues.put("planGrainAc", dto.getPlanGrainAc());

            if (dto.getPlansilageAc() != 0)
                cValues.put("plansilageAc", dto.getPlansilageAc());

            if (dto.getPhiGrainAc() != 0)
                cValues.put("phiGrainAc", dto.getPhiGrainAc());

            if (dto.getPhiSilageAc() != 0)
                cValues.put("phiSilageAc", dto.getPhiSilageAc());

            if (dto.getGrainHybrid1() != null)
                cValues.put("grainHybrid1", dto.getGrainHybrid1());

            if (dto.getGrainHybrid2() != null)
                cValues.put("grainHybrid2", dto.getGrainHybrid2());

            if (dto.getGrainHybrid3() != null)
                cValues.put("grainHybrid3", dto.getGrainHybrid3());

            if (dto.getGrainHybrid4() != null)
                cValues.put("grainHybrid4", dto.getGrainHybrid4());

            if (dto.getGrainHybridValue1() != 0)
                cValues.put("grainHybridValue1", dto.getGrainHybridValue1());

            if (dto.getGrainHybridValue2() != 0)
                cValues.put("grainHybridValue2", dto.getGrainHybridValue2());

            if (dto.getGrainHybridValue3() != 0)
                cValues.put("grainHybridValue3", dto.getGrainHybridValue3());

            if (dto.getGrainHybridValue4() != 0)
                cValues.put("grainHybridValue4", dto.getGrainHybridValue4());

            if (dto.getSilageHybrid1() != null)
                cValues.put("silageHybrid1", dto.getSilageHybrid1());

            if (dto.getSilageHybrid2() != null)
                cValues.put("silageHybrid2", dto.getSilageHybrid2());

            if (dto.getSilageHybrid3() != null)
                cValues.put("silageHybrid3", dto.getSilageHybrid3());

            if (dto.getSilageHybrid4() != null)
                cValues.put("silageHybrid4", dto.getSilageHybrid4());

            if (dto.getSilageHybridValue1() != 0)
                cValues.put("silageHybridValue1", dto.getSilageHybridValue1());

            if (dto.getSilageHybridValue2() != 0)
                cValues.put("silageHybridValue2", dto.getSilageHybridValue2());

            if (dto.getSilageHybridValue3() != 0)
                cValues.put("silageHybridValue3", dto.getSilageHybridValue3());

            if (dto.getSilageHybridValue4() != 0)
                cValues.put("silageHybridValue4", dto.getSilageHybridValue4());

            if (dto.getGrainCompetitorHybrid1() != null)
                cValues.put("grainCompetitorHybrid1", dto.getGrainCompetitorHybrid1());
            if (dto.getGrainCompetitorHybrid2() != null)
                cValues.put("grainCompetitorHybrid2", dto.getGrainCompetitorHybrid2());
            if (dto.getGrainCompetitorHybrid3() != null)
                cValues.put("grainCompetitorHybrid3", dto.getGrainCompetitorHybrid3());
            if (dto.getGrainCompetitorHybrid4() != null)
                cValues.put("grainCompetitorHybrid4", dto.getGrainCompetitorHybrid4());
            if (dto.getGrainCompetitorHybridValue1() != 0)
                cValues.put("grainCompetitorHybridValue1", dto.getGrainCompetitorHybridValue1());
            if (dto.getGrainCompetitorHybridValue2() != 0)
                cValues.put("grainCompetitorHybridValue2", dto.getGrainCompetitorHybridValue2());
            if (dto.getGrainCompetitorHybridValue3() != 0)
                cValues.put("grainCompetitorHybridValue3", dto.getGrainCompetitorHybridValue3());
            if (dto.getGrainCompetitorHybridValue4() != 0)
                cValues.put("grainCompetitorHybridValue4", dto.getGrainCompetitorHybridValue4());
            if (dto.getSilageCompetitorHybrid1() != null)
                cValues.put("silageCompetitorHybrid1", dto.getSilageCompetitorHybrid1());
            if (dto.getSilageCompetitorHybrid2() != null)
                cValues.put("silageCompetitorHybrid2", dto.getSilageCompetitorHybrid2());
            if (dto.getSilageCompetitorHybrid3() != null)
                cValues.put("silageCompetitorHybrid3", dto.getSilageCompetitorHybrid3());
            if (dto.getSilageCompetitorHybrid4() != null)
                cValues.put("silageCompetitorHybrid4", dto.getSilageCompetitorHybrid4());
            if (dto.getSilageCompetitorHybridValue1() != 0)
                cValues.put("silageCompetitorHybridValue1", dto.getSilageCompetitorHybridValue1());
            if (dto.getSilageCompetitorHybridValue2() != 0)
                cValues.put("silageCompetitorHybridValue2", dto.getSilageCompetitorHybridValue2());
            if (dto.getSilageCompetitorHybridValue3() != 0)
                cValues.put("silageCompetitorHybridValue3", dto.getSilageCompetitorHybridValue3());
            if (dto.getSilageCompetitorHybridValue4() != 0)
                cValues.put("silageCompetitorHybridValue4", dto.getSilageCompetitorHybridValue4());

            if (dto.getIsTBL() != null)
                cValues.put("isTBL", dto.getIsTBL());
            if (dto.getLocalImagePath() != null)
                cValues.put("localImagePath", dto.getLocalImagePath());

            if (dto.getGeoLocation() != null)
                cValues.put("geoLocation", dto.getGeoLocation());

            if (dto.getDate() != null)
                cValues.put("timeStamp", dto.getDate());

            if (dto.getGrainServices() != null)
                cValues.put("grainServices", dto.getGrainServices());

            if (dto.getSilageServices() != null)
                cValues.put("silageServices", dto.getSilageServices());

            if (dto.getVisitedCornHybrid() != null)
                cValues.put("visitedCornHybrid", dto.getVisitedCornHybrid());
            if (dto.getVisitedCornHybridLike() != null)
                cValues.put("visitedCornHybridLike", dto.getVisitedCornHybridLike());
            if (dto.getRateHybrid() != null)
                cValues.put("rateHybrid", dto.getRateHybrid());
            if (dto.getShiftNextYrAcres() != null)
                cValues.put("shiftNextYrAcres", dto.getShiftNextYrAcres());

            if (dto.getGrainCompetitorHybrid5() != null)
            cValues.put("grainCompetitorHybrid5", dto.getGrainCompetitorHybrid5());

            if (dto.getGrainCompetitorHybridValue5() != 0)
            cValues.put("grainCompetitorHybridValue5", dto.getGrainCompetitorHybridValue5());

            if (dto.getSilageCompetitorHybrid5() != null)
            cValues.put("silageCompetitorHybrid5", dto.getSilageCompetitorHybrid5());

            if (dto.getSilageCompetitorHybridValue5() != 0)
            cValues.put("silageCompetitorHybridValue5", dto.getSilageCompetitorHybridValue5());


            dbObject.update("SEGMENTATION_REQUEST", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }


    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM SEGMENTATION_REQUEST").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from SEGMENTATION_REQUEST where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }


    public boolean deleteTableDataById(long id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM SEGMENTATION_REQUEST where id = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public List<SegmentationRequestDTO> getAllRecords(SQLiteDatabase dbObject) {
        List<SegmentationRequestDTO> allRecordsList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_REQUEST", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setPlanGrainAc(cursor.getFloat(cursor.getColumnIndex("planGrainAc")));
                    dto.setPlansilageAc(cursor.getFloat(cursor.getColumnIndex("plansilageAc")));
                    dto.setPhiGrainAc(cursor.getFloat(cursor.getColumnIndex("phiGrainAc")));
                    dto.setPhiSilageAc(cursor.getFloat(cursor.getColumnIndex("phiSilageAc")));
                    dto.setGrainHybrid1(cursor.getString(cursor.getColumnIndex("grainHybrid1")));
                    dto.setGrainHybrid2(cursor.getString(cursor.getColumnIndex("grainHybrid2")));
                    dto.setGrainHybrid3(cursor.getString(cursor.getColumnIndex("grainHybrid3")));
                    dto.setGrainHybrid4(cursor.getString(cursor.getColumnIndex("grainHybrid4")));
                    dto.setGrainHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainHybridValue1")));
                    dto.setGrainHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainHybridValue2")));
                    dto.setGrainHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainHybridValue3")));
                    dto.setGrainHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainHybridValue4")));
                    dto.setSilageHybrid1(cursor.getString(cursor.getColumnIndex("silageHybrid1")));
                    dto.setSilageHybrid2(cursor.getString(cursor.getColumnIndex("silageHybrid2")));
                    dto.setSilageHybrid3(cursor.getString(cursor.getColumnIndex("silageHybrid3")));
                    dto.setSilageHybrid4(cursor.getString(cursor.getColumnIndex("silageHybrid4")));
                    dto.setSilageHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageHybridValue1")));
                    dto.setSilageHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageHybridValue2")));
                    dto.setSilageHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageHybridValue3")));
                    dto.setSilageHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageHybridValue4")));
                    dto.setGrainCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid1")));
                    dto.setGrainCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid2")));
                    dto.setGrainCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid3")));
                    dto.setGrainCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid4")));
                    dto.setGrainCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue1")));
                    dto.setGrainCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue2")));
                    dto.setGrainCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue3")));
                    dto.setGrainCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue4")));
                    dto.setSilageCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid1")));
                    dto.setSilageCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid2")));
                    dto.setSilageCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid3")));
                    dto.setSilageCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid4")));
                    dto.setSilageCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue1")));
                    dto.setSilageCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue2")));
                    dto.setSilageCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue3")));
                    dto.setSilageCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue4")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setGrainServices(cursor.getString(cursor.getColumnIndex("grainServices")));
                    dto.setSilageServices(cursor.getString(cursor.getColumnIndex("silageServices")));

                    dto.setVisitedCornHybrid(cursor.getString(cursor.getColumnIndex("visitedCornHybrid")));
                    dto.setVisitedCornHybridLike(cursor.getString(cursor.getColumnIndex("visitedCornHybridLike")));
                    dto.setRateHybrid(cursor.getString(cursor.getColumnIndex("rateHybrid")));
                    dto.setShiftNextYrAcres(cursor.getString(cursor.getColumnIndex("shiftNextYrAcres")));

                    dto.setGrainCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid5")));
                    dto.setGrainCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue5")));
                    dto.setSilageCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid5")));
                    dto.setSilageCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue5")));


                    allRecordsList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return allRecordsList;
    }

    public List<DTO> getRecordsById(long id, SQLiteDatabase dbObject) {

        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_REQUEST where id = '" + id + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setPlanGrainAc(cursor.getFloat(cursor.getColumnIndex("planGrainAc")));
                    dto.setPlansilageAc(cursor.getFloat(cursor.getColumnIndex("plansilageAc")));
                    dto.setPhiGrainAc(cursor.getFloat(cursor.getColumnIndex("phiGrainAc")));
                    dto.setPhiSilageAc(cursor.getFloat(cursor.getColumnIndex("phiSilageAc")));
                    dto.setGrainHybrid1(cursor.getString(cursor.getColumnIndex("grainHybrid1")));
                    dto.setGrainHybrid2(cursor.getString(cursor.getColumnIndex("grainHybrid2")));
                    dto.setGrainHybrid3(cursor.getString(cursor.getColumnIndex("grainHybrid3")));
                    dto.setGrainHybrid4(cursor.getString(cursor.getColumnIndex("grainHybrid4")));
                    dto.setGrainHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainHybridValue1")));
                    dto.setGrainHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainHybridValue2")));
                    dto.setGrainHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainHybridValue3")));
                    dto.setGrainHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainHybridValue4")));
                    dto.setSilageHybrid1(cursor.getString(cursor.getColumnIndex("silageHybrid1")));
                    dto.setSilageHybrid2(cursor.getString(cursor.getColumnIndex("silageHybrid2")));
                    dto.setSilageHybrid3(cursor.getString(cursor.getColumnIndex("silageHybrid3")));
                    dto.setSilageHybrid4(cursor.getString(cursor.getColumnIndex("silageHybrid4")));
                    dto.setSilageHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageHybridValue1")));
                    dto.setSilageHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageHybridValue2")));
                    dto.setSilageHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageHybridValue3")));
                    dto.setSilageHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageHybridValue4")));
                    dto.setGrainCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid1")));
                    dto.setGrainCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid2")));
                    dto.setGrainCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid3")));
                    dto.setGrainCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid4")));
                    dto.setGrainCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue1")));
                    dto.setGrainCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue2")));
                    dto.setGrainCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue3")));
                    dto.setGrainCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue4")));
                    dto.setSilageCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid1")));
                    dto.setSilageCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid2")));
                    dto.setSilageCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid3")));
                    dto.setSilageCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid4")));
                    dto.setSilageCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue1")));
                    dto.setSilageCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue2")));
                    dto.setSilageCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue3")));
                    dto.setSilageCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue4")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setGrainServices(cursor.getString(cursor.getColumnIndex("grainServices")));
                    dto.setSilageServices(cursor.getString(cursor.getColumnIndex("silageServices")));

                    dto.setVisitedCornHybrid(cursor.getString(cursor.getColumnIndex("visitedCornHybrid")));
                    dto.setVisitedCornHybridLike(cursor.getString(cursor.getColumnIndex("visitedCornHybridLike")));
                    dto.setRateHybrid(cursor.getString(cursor.getColumnIndex("rateHybrid")));
                    dto.setShiftNextYrAcres(cursor.getString(cursor.getColumnIndex("shiftNextYrAcres")));

                    dto.setGrainCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid5")));
                    dto.setGrainCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue5")));
                    dto.setSilageCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid5")));
                    dto.setSilageCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue5")));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    public List<SegmentationRequestDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<SegmentationRequestDTO> farmerSegmentationList = new ArrayList<SegmentationRequestDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM SEGMENTATION_REQUEST where isSync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    SegmentationRequestDTO dto = new SegmentationRequestDTO();


                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setSeason(cursor.getLong(cursor.getColumnIndex("season")));
                    dto.setCrop(cursor.getLong(cursor.getColumnIndex("crop")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setTotalPlanAc(cursor.getFloat(cursor.getColumnIndex("totalPlanAc")));
                    dto.setPlanGrainAc(cursor.getFloat(cursor.getColumnIndex("planGrainAc")));
                    dto.setPlansilageAc(cursor.getFloat(cursor.getColumnIndex("plansilageAc")));
                    dto.setPhiGrainAc(cursor.getFloat(cursor.getColumnIndex("phiGrainAc")));
                    dto.setPhiSilageAc(cursor.getFloat(cursor.getColumnIndex("phiSilageAc")));
                    dto.setGrainHybrid1(cursor.getString(cursor.getColumnIndex("grainHybrid1")));
                    dto.setGrainHybrid2(cursor.getString(cursor.getColumnIndex("grainHybrid2")));
                    dto.setGrainHybrid3(cursor.getString(cursor.getColumnIndex("grainHybrid3")));
                    dto.setGrainHybrid4(cursor.getString(cursor.getColumnIndex("grainHybrid4")));
                    dto.setGrainHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainHybridValue1")));
                    dto.setGrainHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainHybridValue2")));
                    dto.setGrainHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainHybridValue3")));
                    dto.setGrainHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainHybridValue4")));
                    dto.setSilageHybrid1(cursor.getString(cursor.getColumnIndex("silageHybrid1")));
                    dto.setSilageHybrid2(cursor.getString(cursor.getColumnIndex("silageHybrid2")));
                    dto.setSilageHybrid3(cursor.getString(cursor.getColumnIndex("silageHybrid3")));
                    dto.setSilageHybrid4(cursor.getString(cursor.getColumnIndex("silageHybrid4")));
                    dto.setSilageHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageHybridValue1")));
                    dto.setSilageHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageHybridValue2")));
                    dto.setSilageHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageHybridValue3")));
                    dto.setSilageHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageHybridValue4")));
                    dto.setGrainCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid1")));
                    dto.setGrainCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid2")));
                    dto.setGrainCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid3")));
                    dto.setGrainCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid4")));
                    dto.setGrainCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue1")));
                    dto.setGrainCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue2")));
                    dto.setGrainCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue3")));
                    dto.setGrainCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue4")));
                    dto.setSilageCompetitorHybrid1(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid1")));
                    dto.setSilageCompetitorHybrid2(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid2")));
                    dto.setSilageCompetitorHybrid3(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid3")));
                    dto.setSilageCompetitorHybrid4(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid4")));
                    dto.setSilageCompetitorHybridValue1(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue1")));
                    dto.setSilageCompetitorHybridValue2(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue2")));
                    dto.setSilageCompetitorHybridValue3(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue3")));
                    dto.setSilageCompetitorHybridValue4(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue4")));
                    dto.setIsTBL(cursor.getString(cursor.getColumnIndex("isTBL")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setGrainServices(cursor.getString(cursor.getColumnIndex("grainServices")));
                    dto.setSilageServices(cursor.getString(cursor.getColumnIndex("silageServices")));

                    dto.setVisitedCornHybrid(cursor.getString(cursor.getColumnIndex("visitedCornHybrid")));
                    dto.setVisitedCornHybridLike(cursor.getString(cursor.getColumnIndex("visitedCornHybridLike")));
                    dto.setRateHybrid(cursor.getString(cursor.getColumnIndex("rateHybrid")));
                    dto.setShiftNextYrAcres(cursor.getString(cursor.getColumnIndex("shiftNextYrAcres")));

                    dto.setGrainCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("grainCompetitorHybrid5")));
                    dto.setGrainCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("grainCompetitorHybridValue5")));
                    dto.setSilageCompetitorHybrid5(cursor.getString(cursor.getColumnIndex("silageCompetitorHybrid5")));
                    dto.setSilageCompetitorHybridValue5(cursor.getFloat(cursor.getColumnIndex("silageCompetitorHybridValue5")));

                    farmerSegmentationList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return farmerSegmentationList;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM SEGMENTATION_REQUEST where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }

}
