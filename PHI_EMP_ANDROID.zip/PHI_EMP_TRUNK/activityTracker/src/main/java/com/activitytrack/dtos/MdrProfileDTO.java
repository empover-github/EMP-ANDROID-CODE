package com.activitytrack.dtos;

import java.util.List;

public class MdrProfileDTO implements DTO {
    private String villageName;
    private long cropId;
    private float totalCropArea;
    private float pioneerShare;
    private String majorCompetitorName1;
    private float majorCompetitor1Share;
    private String majorCompetitorName2;
    private float majorCompetitor2Share;
    private long mobileId;
    private String date;
    private String location;
    private int isSync;
    private String uploadedDate;
    private long regionId;
    private int numberOfFarmers;
    //Adding
    private String pinCode;
    private String blockName;
    private long segment;
    private Float cropHa;
    private Float phiHa;
    private long majorPHIHybrid1;
    private long majorPHIHybrid2;
    private String majorCompetitionHybrid1;
    private String majorCompetitionHybrid2;

    private List<MdrFarmerDTO> farmers;
    private List<MdrSurveyDTO> surveys;
    private List<NewMdrSurveyDTO> surveysNew;

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }


    public float getTotalCropArea() {
        return totalCropArea;
    }

    public void setTotalCropArea(float totalCropArea) {
        this.totalCropArea = totalCropArea;
    }

    public float getPioneerShare() {
        return pioneerShare;
    }

    public void setPioneerShare(float pioneerShare) {
        this.pioneerShare = pioneerShare;
    }

    public String getMajorCompetitorName1() {
        return majorCompetitorName1;
    }

    public void setMajorCompetitorName1(String majorCompetitorName1) {
        this.majorCompetitorName1 = majorCompetitorName1;
    }

    public float getItsShare1() {
        return majorCompetitor1Share;
    }

    public void setItsShare1(float itsShare1) {
        this.majorCompetitor1Share = itsShare1;
    }

    public String getMajorCompetitorName2() {
        return majorCompetitorName2;
    }

    public void setMajorCompetitorName2(String majorCompetitorName2) {
        this.majorCompetitorName2 = majorCompetitorName2;
    }

    public float getItsShare2() {
        return majorCompetitor2Share;
    }

    public void setItsShare2(float itsShare2) {
        this.majorCompetitor2Share = itsShare2;
    }

    public long getId() {
        return mobileId;
    }

    public void setId(long id) {
        this.mobileId = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<MdrFarmerDTO> getFarmers() {
        return farmers;
    }

    public String getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(String uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public long getRegionId() {
        return regionId;
    }

    public void setRegionId(long regionId) {
        this.regionId = regionId;
    }

    public void setFarmers(List<MdrFarmerDTO> farmers) {
        this.farmers = farmers;
    }

    public int getNumberOfFarmers() {
        return numberOfFarmers;
    }

    public void setNumberOfFarmers(int numberOfFarmers) {
        this.numberOfFarmers = numberOfFarmers;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public long getSegment() {
        return segment;
    }

    public void setSegment(long segment) {
        this.segment = segment;
    }

    public Float getCropHa() {
        return cropHa;
    }

    public void setCropHa(Float cropHa) {
        this.cropHa = cropHa;
    }

    public Float getPhiHa() {
        return phiHa;
    }

    public void setPhiHa(Float phiHa) {
        this.phiHa = phiHa;
    }

    public long getMajorPHIHybrid1() {
        return majorPHIHybrid1;
    }

    public void setMajorPHIHybrid1(long majorPHIHybrid1) {
        this.majorPHIHybrid1 = majorPHIHybrid1;
    }

    public long getMajorPHIHybrid2() {
        return majorPHIHybrid2;
    }

    public void setMajorPHIHybrid2(long majorPHIHybrid2) {
        this.majorPHIHybrid2 = majorPHIHybrid2;
    }

    public String getMajorCompetitionHybrid1() {
        return majorCompetitionHybrid1;
    }

    public void setMajorCompetitionHybrid1(String majorCompetitionHybrid1) {
        this.majorCompetitionHybrid1 = majorCompetitionHybrid1;
    }

    public String getMajorCompetitionHybrid2() {
        return majorCompetitionHybrid2;
    }

    public void setMajorCompetitionHybrid2(String majorCompetitionHybrid2) {
        this.majorCompetitionHybrid2 = majorCompetitionHybrid2;
    }

    public List<MdrSurveyDTO> getSurveys() {
        return surveys;
    }

    public void setSurveys(List<MdrSurveyDTO> surveys) {
        this.surveys = surveys;
    }

    public List<NewMdrSurveyDTO> getSurveysNew() {
        return surveysNew;
    }

    public void setSurveysNew(List<NewMdrSurveyDTO> surveysNew) {
        this.surveysNew = surveysNew;
    }
}
