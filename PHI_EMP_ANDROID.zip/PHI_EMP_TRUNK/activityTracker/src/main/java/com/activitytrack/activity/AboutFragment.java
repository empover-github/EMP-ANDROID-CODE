package com.activitytrack.activity;

import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class AboutFragment extends BaseFragment {

	private View view;
	private TextView appVers, privacyPolicy;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		
		view = inflater.inflate(R.layout.about_fragment, container, false);
		appVers=(TextView) view.findViewById(R.id.abtAppVer);
		appVers.setText("Activity Track Version :"+Utility.getVersionName(mActivity));

		privacyPolicy = (TextView) view.findViewById(R.id.loginTxtPrivacyPolicy);
		privacyPolicy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String url = MyConstants.PRIVACY_POLICY_WEB_URL;
				Intent openBrowser = new Intent(Intent.ACTION_VIEW);
				openBrowser.setData(Uri.parse(url));
				startActivity(openBrowser);
			}
		});
		

		setChange();
		 
		return view;
		 
	}
	
	private void setChange() {
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) 
		{
			appVers.setTextColor(Color.WHITE);
			appVers.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

			privacyPolicy.setTextColor(Color.WHITE);
			privacyPolicy.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
	  }else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) 
	   {
		  appVers.setTextColor(Color.BLACK);
		  appVers.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));

		   privacyPolicy.setTextColor(Color.BLACK);
		   privacyPolicy.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
	   
	   }
 
	}

	@Override
	public boolean onBackPressed(int callbackCode) {
		mActivity.onBackPressedCallBack(callbackCode);
		return true;
	}

	
}
