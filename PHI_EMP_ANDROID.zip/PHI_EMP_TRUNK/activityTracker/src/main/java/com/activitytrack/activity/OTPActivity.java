package com.activitytrack.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import com.activitytrack.daos.AgronomySummaryDAO;
import com.activitytrack.daos.CompanyMasterDAO;
import com.activitytrack.daos.DemandSummaryDAO;
import com.activitytrack.daos.FSMasterDivisionDAO;
import com.activitytrack.daos.GerminationListDAO;
import com.activitytrack.daos.ResearchCompanyMasterDAO;
import com.activitytrack.daos.SegmentationCropDAO;
import com.activitytrack.daos.SegmentationGrainHybridDAO;
import com.activitytrack.daos.SegmentationGrainServicesDAO;
import com.activitytrack.daos.SegmentationRiceHybridDAO;
import com.activitytrack.daos.SegmentationRiceServicesDAO;
import com.activitytrack.daos.SegmentationSchoolDAO;
import com.activitytrack.daos.SegmentationSeasonDAO;
import com.activitytrack.daos.SegmentationSilageHybridDAO;
import com.activitytrack.daos.SegmentationSilageServicesDAO;
import com.activitytrack.daos.SegmentationYearDAO;
import com.activitytrack.daos.UploadedVillageListDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.AgronomySummaryDTO;
import com.activitytrack.dtos.CompanyMasterDTO;
import com.activitytrack.dtos.DemandSummaryDTO;
import com.activitytrack.dtos.DipstickDTO;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.dtos.UploadedVillageListDTO;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdaos.DipstickMasterDAO;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.OtherCropMasterDAO;
import com.activitytrack.masterdaos.RetailerMasterDAO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdaos.SeasonMasterDAO;
import com.activitytrack.masterdaos.SegmentMasterDAO;
import com.activitytrack.masterdaos.TargetAgronomyDAO;
import com.activitytrack.masterdaos.TargetDemandOSADAO;
import com.activitytrack.masterdaos.TargetDemandPDADAO;
import com.activitytrack.masterdaos.TargetDemandPSADAO;
import com.activitytrack.masterdaos.Top3HybridsDAO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.masterdtos.DownloadMasterDTO;
import com.activitytrack.masterdtos.HybridMasterDTO;
import com.activitytrack.masterdtos.MasterDataDTO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.masterdtos.OtherCropMasterDTO;
import com.activitytrack.masterdtos.RetailerMasterDTO;
import com.activitytrack.masterdtos.SeasonCalendarDTO;
import com.activitytrack.masterdtos.SeasonMasterDTO;
import com.activitytrack.masterdtos.SegmentMasterDTO;
import com.activitytrack.masterdtos.TargetAgronomyDTO;
import com.activitytrack.masterdtos.TargetDemandOSADTO;
import com.activitytrack.masterdtos.TargetDemandPDADTO;
import com.activitytrack.masterdtos.TargetDemandPSADTO;
import com.activitytrack.masterdtos.Top3HybridsDTO;
import com.activitytrack.models.IdNameModel;
import com.activitytrack.models.SegmentationMasterDataModel;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.List;

public class OTPActivity extends Activity {

    private String loginId;
    private String mobileNo;
    private Context context;
    private String appVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.splash);

        context = this;

        Intent intent = getIntent();

        loginId = intent.getStringExtra("loginId");
        mobileNo = intent.getStringExtra("mobileNumber");
//        loginId = "MAHANTESH";

        appVersion = intent.getStringExtra("versionNo");

        verifyOTPApiCall();
       // scanQRCode(true);
    }

    private void scanQRCode(boolean isFinalScan) {

      Intent  intent = new Intent(context, ATMainActivity.class);

        Bundle bundle = new Bundle();
        bundle.putString("loginId", "");
        bundle.putString("mobileNumber", "");
        bundle.putString("versionNo", "");

        intent.putExtras(bundle);

        startActivity(intent);
        finish();
        //	Log.d(TAG, "inside scanQRCode()");

        //mIntent = new Intent(mContext, QRScannerActivity.class);
//        mIntent = new Intent("com.google.zxing.client.android.SCAN");
//        startActivityForResult(mIntent, requestCode);

//		Log.d(TAG, "Exitting scanQRcode()");
       // this.isFinalScan = isFinalScan;
       // android.support.v4.app.Fragment fragment=new PDAFragment();
       /* FragmentIntentIntegrator integrator = new FragmentIntentIntegrator(fragment);
        integrator.setPrompt("Scan a barcode");
        integrator.setCameraId(0);  // Use a specific camera of the device
        integrator.setOrientationLocked(true);
        integrator.setBeepEnabled(true);
        integrator.setCaptureActivity(ATCaptureActivityPortrait.class);
        integrator.initiateScan();
*/
    }

    private class ValidateOTPAsync extends AsyncTask<String, Void, String> {
        String jsonData;
        ProgressDialog dlg;

        public ValidateOTPAsync(String inputJSON) {
            jsonData = inputJSON;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dlg = new ProgressDialog(OTPActivity.this);
            dlg.setCanceledOnTouchOutside(false);
            dlg.setCancelable(false);
            dlg.setMessage(getResources().getString(R.string.progress_pleaseWait));
            dlg.show();
        }

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpClient = null;
            try {
                HttpParams httpParams = new BasicHttpParams();
                int connectionTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                int socketTimeout = MyConstants.CONNECTION_TIME_LIMIT;
                HttpConnectionParams.setConnectionTimeout(httpParams, connectionTimeout);
                HttpConnectionParams.setSoTimeout(httpParams, socketTimeout);
                httpClient = new DefaultHttpClient(httpParams);
                HttpPost httpPost = new HttpPost(params[0]);
                ATBuildLog.i("LoginAsync", "validate otp request URL :" + params[0]);
                StringEntity stringEntity = new StringEntity(jsonData);
                httpPost.setEntity(stringEntity);
                HttpResponse response = httpClient.execute(httpPost);
                HttpEntity httpEntity = response.getEntity();
                InputStream instream = httpEntity.getContent();
                return Utility.convertStreamToString(instream);
            } catch (Exception exception) {
                exception.printStackTrace();
            } finally {
                if (httpClient != null)
                    httpClient.getConnectionManager().shutdown();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && !result.isEmpty()) {
                if (!Utility.isJSONValid(result)) {
                    if (dlg != null) {
                        dlg.dismiss();
                    }
                    Utility.showAlert(OTPActivity.this, "", getResources().getString(R.string.ntjson));
                } else {
                    try {
                        Gson gson = new Gson();
                        DownloadMasterDTO obj = gson.fromJson(result, DownloadMasterDTO.class);
                        if (obj.getCode() == 100) {
                            MasterDataDTO mainDTO = obj.getData();
                            CropMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            HybridMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            OtherCropMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SeasonCalendarDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            MdrMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            RetailerMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetDemandPDADAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetDemandOSADAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetDemandPSADAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            TargetAgronomyDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            Top3HybridsDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SeasonMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            DipstickMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            CompanyMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            ResearchCompanyMasterDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            GerminationListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));

                            SegmentationSeasonDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationCropDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationYearDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            FSMasterDivisionDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationSchoolDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationGrainHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationSilageHybridDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationGrainServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                            SegmentationSilageServicesDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));

                            //newly added
                            SegmentationRiceHybridDAO.getInstance().deleteTableData(com.activitytrack.database.DBHandler.getInstance(context).getDBObject(1));
                            SegmentationRiceServicesDAO.getInstance().deleteTableData(com.activitytrack.database.DBHandler.getInstance(context).getDBObject(1));

                            List<CropMasterDTO> cropList = mainDTO.getCropMaster();
                            if (cropList != null)
                                for (CropMasterDTO cropMasterDTO : cropList) {
                                    CropMasterDAO.getInstance().insert(cropMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            List<HybridMasterDTO> hybridList = mainDTO.getHybridMaster();
                            if (hybridList != null)
                                for (HybridMasterDTO hybridMasterDTO : hybridList) {
                                    HybridMasterDAO.getInstance().insert(hybridMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<OtherCropMasterDTO> otherCropList = mainDTO.getOtherCropMaster();
                            if (otherCropList != null)
                                for (OtherCropMasterDTO otherCropMasterDTO : otherCropList) {
                                    OtherCropMasterDAO.getInstance().insert(otherCropMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<SegmentMasterDTO> segmentList = mainDTO.getSegmentMaster();
                            if (segmentList != null)
                                for (SegmentMasterDTO segmentMasterDTO : segmentList) {
                                    SegmentMasterDAO.getInstance().insert(segmentMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<SeasonCalendarDTO> seasonList = mainDTO.getSeasonCalendar();
                            if (seasonList != null)
                                for (SeasonCalendarDTO seasonCalendarDTO : seasonList) {
                                    SeasonCalendarDAO.getInstance().insert(seasonCalendarDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<SeasonMasterDTO> seasonMasterList = mainDTO.getSeasonMaster();
                            if (seasonMasterList != null)
                                for (SeasonMasterDTO seasonCalendarDTO : seasonMasterList) {
                                    SeasonMasterDAO.getInstance().insert(seasonCalendarDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<MdrMasterDTO> mdrMasterList = mainDTO.getMdrMaster();
                            if (mdrMasterList != null)
                                for (MdrMasterDTO mdrMasterDTO : mdrMasterList) {
                                    MdrMasterDAO.getInstance().insert(mdrMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<RetailerMasterDTO> retailerMasterList = mainDTO.getRetailerMaster();
                            if (retailerMasterList != null)
                                for (RetailerMasterDTO mdrMasterDTO : retailerMasterList) {
                                    RetailerMasterDAO.getInstance().insert(mdrMasterDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetDemandPDADTO> targetDemandPDAList = mainDTO.getTargetDemandPDA();
                            if (targetDemandPDAList != null)
                                for (TargetDemandPDADTO targetDemandDTO : targetDemandPDAList) {
                                    TargetDemandPDADAO.getInstance().insert(targetDemandDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetDemandOSADTO> targetDemandOSAList = mainDTO.getTargetDemandOSA();
                            if (targetDemandOSAList != null)
                                for (TargetDemandOSADTO targetDemandDTO : targetDemandOSAList) {
                                    TargetDemandOSADAO.getInstance().insert(targetDemandDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetDemandPSADTO> targetDemandPSAList = mainDTO.getTargetDemandPSA();
                            if (targetDemandPSAList != null)
                                for (TargetDemandPSADTO targetDemandDTO : targetDemandPSAList) {
                                    TargetDemandPSADAO.getInstance().insert(targetDemandDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<TargetAgronomyDTO> targetAgronomyList = mainDTO.getTargetAgronomy();
                            if (targetAgronomyList != null)
                                for (TargetAgronomyDTO targetAgronomyDTO : targetAgronomyList) {
                                    TargetAgronomyDAO.getInstance().insert(targetAgronomyDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<Top3HybridsDTO> top3HybridsList = mainDTO.getTop3Hybrids();
                            if (top3HybridsList != null)
                                for (Top3HybridsDTO top3HybridsDTO : top3HybridsList) {
                                    Top3HybridsDAO.getInstance().insert(top3HybridsDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<DemandSummaryDTO> demList = mainDTO.getDemandsumary();
                            if (demList != null) {
                                DemandSummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (DemandSummaryDTO demandSummaryDTO : demList) {
                                    DemandSummaryDAO.getInstance().insert(demandSummaryDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            }

                            List<AgronomySummaryDTO> agrList = mainDTO.getAgronomySummary();
                            if (agrList != null) {
                                AgronomySummaryDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (AgronomySummaryDTO demandSummaryDTO : agrList) {
                                    AgronomySummaryDAO.getInstance().insert(demandSummaryDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            }

                            List<UploadedVillageListDTO> uploadedVillageList = mainDTO.getVillageProfileUploadedData();
                            if (uploadedVillageList != null) {
                                UploadedVillageListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (UploadedVillageListDTO uploadedVillageDTO : uploadedVillageList) {
                                    UploadedVillageListDAO.getInstance().insertActivity(uploadedVillageDTO, DBHandler.getInstance(context).getDBObject(1));
                                }
                            }

                            List<DipstickDTO> dipsticksList = mainDTO.getDipsticks();
                            if (dipsticksList != null)
                                for (DipstickDTO pupchaseDTO : dipsticksList) {
                                    DipstickMasterDAO.getInstance().insertActivity(pupchaseDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<CompanyMasterDTO> companyList = mainDTO.getCompanyMaster();
                            if (companyList != null)
                                for (CompanyMasterDTO companyDTO : companyList) {
                                    CompanyMasterDAO.getInstance().insert(companyDTO, DBHandler.getInstance(context).getDBObject(1));
                                }

                            List<CompanyMasterDTO> researchCompanyList = mainDTO.getResearchCompanyMaster();
                            if (researchCompanyList != null)
                                for (CompanyMasterDTO companyDTO : researchCompanyList) {
                                    ResearchCompanyMasterDAO.getInstance().insert(companyDTO, DBHandler.getInstance(context).getDBObject(1));
                                }


                            List<GerminationverificationListDTO> germinationList = mainDTO.getGerminationPendingVerificationList();
                            if (germinationList != null) {
                                GerminationListDAO.getInstance().deleteTableData(DBHandler.getInstance(context).getDBObject(1));
                                for (GerminationverificationListDTO germinationDto : germinationList) {
                                    GerminationListDAO.getInstance().insertActivity(germinationDto, DBHandler.getInstance(context).getDBObject(1));
                                }
                            }

                            // Farmer Segmentation
                            Utility.setShowFarmerSegmention(mainDTO.isShowFarmerSegmentation(), context);
                            SegmentationMasterDataModel farmerSegmentation = mainDTO.getFarmerSegmentationMasterData();

                            if (farmerSegmentation != null) {
                                List<IdNameModel> segSeasonList = farmerSegmentation.getSeason();
                                if (segSeasonList != null) {
                                    for (IdNameModel dto : segSeasonList) {
                                        SegmentationSeasonDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> segCropList = farmerSegmentation.getCrop();
                                if (segCropList != null) {
                                    for (IdNameModel dto : segCropList) {
                                        SegmentationCropDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> segYearList = farmerSegmentation.getYears();
                                if (segYearList != null) {
                                    for (IdNameModel dto : segYearList) {
                                        SegmentationYearDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> grainHybridList = farmerSegmentation.getGrainHybrid();
                                if (grainHybridList != null) {
                                    for (IdNameModel dto : grainHybridList) {
                                        SegmentationGrainHybridDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> silageHybridList = farmerSegmentation.getSilageHybrid();
                                if (silageHybridList != null) {
                                    for (IdNameModel dto : silageHybridList) {
                                        SegmentationSilageHybridDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                                List<IdNameModel> grainServicesList = farmerSegmentation.getGrainFarmerServicesList();
                                if (grainServicesList != null) {
                                    for (IdNameModel dto : grainServicesList) {
                                        SegmentationGrainServicesDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> silageServicesList = farmerSegmentation.getSilageFarmerServicesList();
                                if (silageServicesList != null) {
                                    for (IdNameModel dto : silageServicesList) {
                                        SegmentationSilageServicesDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                //New Added FS
                                List<IdNameModel> riceHybridList = farmerSegmentation.getRiceHybrid();
                                if (riceHybridList != null) {
                                    for (IdNameModel dto : riceHybridList) {
                                        SegmentationRiceHybridDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> riceServicesList = farmerSegmentation.getRiceFarmerServicesList();
                                if (riceServicesList != null) {
                                    for (IdNameModel dto : riceServicesList) {
                                        SegmentationRiceServicesDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> setDivisionList = farmerSegmentation.getDivisionList();
                                if (setDivisionList != null) {
                                    for (IdNameModel dto : setDivisionList) {
                                        FSMasterDivisionDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }

                                List<IdNameModel> setSchoolList = farmerSegmentation.getSchoolList();
                                if (setSchoolList != null) {
                                    for (IdNameModel dto : setSchoolList) {
                                        SegmentationSchoolDAO.getInstance().insert(dto, DBHandler.getInstance(context).getDBObject(1));
                                    }
                                }
                            }

                            if (dlg != null) {
                                dlg.dismiss();
                            }


                            Utility.setLastDownloadDate(Utility.getCurrentDateAndTime(), context);
                            Utility.setNoOfProfilesUploadedByMdr("" + mainDTO.getVillageProfileCount(), context);
                            Intent intent;
                    /*if(mainDTO.isForceChangePassword())
                        intent=new Intent(context,ChangePasswordActivity.class);
                    else*/
                            intent = new Intent(context, ATMainActivity.class);

                            Bundle bundle = new Bundle();
                            bundle.putString("loginId", loginId);
                            bundle.putString("mobileNumber", mobileNo);
                            bundle.putString("versionNo", appVersion);

                            intent.putExtras(bundle);

                            startActivity(intent);
                            finish();

                        } else if (obj.getCode() == 101) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES101MSG);
                        } else if (obj.getCode() == 201) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES201MSG);
                        } else if (obj.getCode() == 202) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES202MSG);
                        } else if (obj.getCode() == 203) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES203MSG);
                        } else if (obj.getCode() == 104) {
                            if (dlg != null) {
                                dlg.dismiss();
                            }
                            Utility.showAlert(context, "", MyConstants.RES104MSG);
                        }

                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            } else {
                if (dlg != null) {
                    dlg.dismiss();
                }
                Utility.showAlert(context, "", getResources().getString(R.string.networkProblem));
            }

            if (dlg != null) {
                dlg.dismiss();
            }
        }

    }

    private void verifyOTPApiCall() {
        JSONObject sendJSON = new JSONObject();
        try {
            sendJSON.put("loginId", loginId);
            sendJSON.put("mobileNumber", mobileNo);
            sendJSON.put("versionNo", appVersion);
            ValidateOTPAsync validateOTPAsync = new ValidateOTPAsync(sendJSON.toString());
            validateOTPAsync.execute(MyConstants.AppURL + MyConstants.MASTER_DATA);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
