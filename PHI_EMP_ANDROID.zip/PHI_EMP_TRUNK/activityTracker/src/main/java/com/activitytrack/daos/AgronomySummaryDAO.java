package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.AgronomySummaryDTO;
import com.activitytrack.dtos.DTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class AgronomySummaryDAO  implements DAO
{
	private final String TAG = "AgrSummary";
	private static AgronomySummaryDAO agronomySummaryDAO;

	public static AgronomySummaryDAO getInstance()
	{
		if ( agronomySummaryDAO == null)
		{
			agronomySummaryDAO = new AgronomySummaryDAO();
		}
		return agronomySummaryDAO;
	}


	/**
	 * delete the Data
	 */


	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {

		return false;
	}

	/**
	 * Gets the record from the database based on the value passed
	 *
	 * @param columnName
	 *            : Database column name
	 * @param columnValue
	 *            : Column Value
	 * @param dbObject
	 *            : Exposes methods to manage a SQLite database Object
	 */

	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
										  String columnValue, SQLiteDatabase dbObject)

	{
		List<DTO> agronomySummaryInfo = new ArrayList<DTO>();
		Cursor cursor = null;
		try
		{
			if(!(columnName != null && columnName.length() > 0))
				columnName = "id";

			cursor = dbObject.rawQuery("SELECT * FROM AGRONOMY_SUMMARY where "+columnName+"='"+columnValue+"' ", null);
			if (cursor.getCount() > 0)
			{
				cursor.moveToFirst();
				do
				{
                	 /* AGRONOMY_SUMMARY
                    id
                    sampleCount
                    date
                    cropId
                    hybridId
                    seasonId
                    seasonCalendarId
                    */
					AgronomySummaryDTO dto=new AgronomySummaryDTO();

					dto.setId(cursor.getLong(0));
					dto.setActivityCount(cursor.getLong(1));
					dto.setDate(cursor.getString(2));
					dto.setCropId(cursor.getLong(3));
					dto.setHybridId(cursor.getLong(4));
					dto.setSeasonId(cursor.getLong(5));
					dto.setSeasonCalendarId(cursor.getInt(6));


				}while(cursor.moveToNext());
			}

		}catch(Exception e)
		{
			ATBuildLog.e(TAG +"getRecords()",e.getMessage());
		}finally

		{
			if(cursor!=null && !cursor.isClosed())
			{
				cursor.close();
			}

			dbObject.close();

		}



		return agronomySummaryInfo;
	}


	/**
	 * Gets all the records from the database
	 *
	 * @param dbObject
	 *            : Exposes methods to manage a SQLite database Object
	 */

	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)
	{
		List<DTO> agronomySummaryInfo=new  ArrayList<DTO>();
		Cursor cursor=null;
		try{
			cursor=dbObject.rawQuery("SELECT * FROM  AGRONOMY_SUMMARY",null);
			if(cursor.getCount()>0)
			{
				cursor.moveToFirst();
				do{
					AgronomySummaryDTO dto=new AgronomySummaryDTO();
					dto.setId(cursor.getLong(0));
					dto.setActivityCount(cursor.getLong(1));
					dto.setDate(cursor.getString(2));
					dto.setCropId(cursor.getLong(3));
					dto.setHybridId(cursor.getLong(4));
					dto.setSeasonId(cursor.getLong(5));
					dto.setSeasonCalendarId(cursor.getInt(6));
					agronomySummaryInfo.add(dto);
				}while(cursor.moveToNext());
			}
		}catch (Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()",e.getMessage());

		}finally{
			if(cursor!=null && !cursor.isClosed())
			{
				cursor.close();
			}
			dbObject.close();
		}
		return agronomySummaryInfo;
	}

	public int getActivitiesCount(SQLiteDatabase dbObject)
	{
		int count = 0;
		Cursor cursor = null;
		try
		{
			cursor = dbObject.rawQuery("SELECT sum(sampleCount) FROM AGRONOMY_SUMMARY", null);
			if (cursor.getCount() > 0)
			{
				cursor.moveToFirst();
				count = cursor.getInt(0);
			}
		}catch(Exception e)
		{
			ATBuildLog.e(TAG +"getCount()",e.getMessage());
		}finally
		{
			if(cursor!=null && !cursor.isClosed())
			{
				cursor.close();
			}
			dbObject.close();
		}
		return count;
	}

	public List<AgronomySummaryDTO> getRecordsForUpload(SQLiteDatabase dbObject)
	{
		return null;
	}

	/**
	 * Inserts the data in the SQLite database
	 *
	 * @param dbObject
	 *            : Exposes methods to manage a SQLite database Object
	 * @param dtoObject
	 *            : DTO object is passed
	 */



	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject)
	{
		try
		{
			AgronomySummaryDTO  dto=(AgronomySummaryDTO) dtoObject;

			ContentValues cValues=new ContentValues();
			
			 
			 /* AGRONOMY_SUMMARY
             id
             sampleCount
             date
             cropId
             hybridId
             seasonId
             seasonCalendarId  
             */

			cValues.put("sampleCount",dto.getActivityCount());
			cValues.put("Date",dto.getDate());
			cValues.put("cropId",dto.getCropId());
			cValues.put("hybridId",dto.getHybridId());
			cValues.put("seasonId",dto.getSeasonId());
			cValues.put("seasonCalendarId",dto.getSeasonCalendarId());

			dbObject.insert("AGRONOMY_SUMMARY", null, cValues);
			return true;
		}catch(SQLException e)
		{
			ATBuildLog.e(TAG +"insert()",e.getMessage());
			return false;

		}finally{
			dbObject.close();
		}


	}

	/**
	 * Updates the data in the SQLite
	 *
	 * @param dtoObject
	 *            : DTO object is passed
	 * @param dbObject
	 *            : Exposes methods to manage a SQLite database Object
	 * @return boolean : True if data is updated
	 */


	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject)
	{
		return false;
	}
	/**
	 * Deletes all the table Data from SQLite
	 *
	 * @param dbObject
	 *            : DTO object is passed
	 * @param dbObject
	 *            : Exposes methods to manage a SQLite database Object
	 * @return boolean : True if data is to be deleted
	 */
	public boolean deleteTableData(SQLiteDatabase dbObject)
	{
		try
		{
			dbObject.compileStatement("DELETE FROM AGRONOMY_SUMMARY").execute();
			return true;
		} catch (Exception e)
		{
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
		}
		return false;
	}

	public List<Integer> getAchievedCount(long cropId, long hybridId, SQLiteDatabase dbObject)
	{
		List<Integer> achievedInfo = new ArrayList<Integer>();
		Cursor cursor = null;
		try
		{
			cursor = dbObject.rawQuery("select sum(sampleCount) from AGRONOMY_SUMMARY where cropId ='"+cropId+"' and hybridId = '"+hybridId+"'", null);
			if (cursor.getCount() > 0)
			{
				cursor.moveToFirst();
				achievedInfo.add(cursor.getInt(0));
			}
		} catch (Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		} finally
		{
			if (cursor != null && !cursor.isClosed())
			{
				cursor.close();
			}
			dbObject.close();
		}

		return achievedInfo;
	}



}
