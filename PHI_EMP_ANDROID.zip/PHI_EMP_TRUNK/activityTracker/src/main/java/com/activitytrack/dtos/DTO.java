package com.activitytrack.dtos;

public interface DTO {

}
