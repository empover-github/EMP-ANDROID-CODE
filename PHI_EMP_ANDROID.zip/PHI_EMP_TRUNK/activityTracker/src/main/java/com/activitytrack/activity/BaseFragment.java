package com.activitytrack.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.bumptech.glide.Glide;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

public abstract class BaseFragment extends Fragment implements ConnectionCallbacks, OnConnectionFailedListener, LocationListener {

	public ATMainActivity mActivity;

	private ProgressDialog dialog;

	private static boolean flag;

	protected static GoogleApiClient mGoogleApiClient;
	protected static LocationRequest mLocationRequest;
	private final String TAG = "mGoogleApiClient";
	protected static String location;

	protected final int COUNT_DOWN_TIME = 30000;
	protected final int COUNT_DOWN_TIME_INTERVAL = 1000;

	private CountDownTimer mLocationCountDownTimer;

	protected static boolean checkForLocation = true;
	private Dialog imageDialog;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mActivity = (ATMainActivity) this.getActivity();
	}

	public abstract boolean onBackPressed(int callbackCode);
	
	/*public boolean onBackPressed() 
	{
		return false;
	}*/


	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Toast.makeText(getActivity(), "base", Toast.LENGTH_SHORT).show();
	}
	/*
	class PDATabListener implements OnClickListener{

		@Override
		public void onClick(View v) {
			mActivity.popFragments();
			mActivity.pushFragments(MyConstants.TAB_HOME, new PDAFragment(), false, true);
		}
		
	}
	
	class OSATabListener implements OnClickListener{

		@Override
		public void onClick(View v) {
			mActivity.popFragments();
			mActivity.pushFragments(MyConstants.TAB_HOME, new OSAFragment(), false, true);
		}
		
	}
	
	class PSATabListener implements OnClickListener{

		@Override
		public void onClick(View v) {
			mActivity.popFragments();
			mActivity.pushFragments(MyConstants.TAB_HOME, new PSAFragment(), false, true);
		}
		
	}
	*/

	public void showProgressDialog() {
		dialog = new ProgressDialog(mActivity);
		dialog.setCanceledOnTouchOutside(false);
		dialog.setCancelable(false);
		dialog.setMessage("Please wait...");
		dialog.show();
	}

	public void hideProgressDialog() {
		if (dialog != null && dialog.isShowing()) {
			dialog.dismiss();
		}
	}

	/**
	 * Creating google api client object
	 * */
	protected synchronized void buildGoogleApiClient() {
		if (mGoogleApiClient == null) {
			mGoogleApiClient = new GoogleApiClient.Builder(mActivity)
					.addConnectionCallbacks(this)
					.addOnConnectionFailedListener(this)
					.addApi(LocationServices.API).build();
			createLocationRequest();
		}
	}

	/**
	 * Creating location request object
	 * */
	protected void createLocationRequest() {
		if (mLocationRequest == null) {
			mLocationRequest = new LocationRequest();
			mLocationRequest.setInterval(0);
			mLocationRequest.setFastestInterval(0);
			mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
			mLocationRequest.setSmallestDisplacement(0); // 10 meters
		}
	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {
		ATBuildLog.i(TAG, "Connection failed: ConnectionResult.getErrorCode() = " + result.getErrorCode());

	}

	@Override
	public void onConnected(Bundle arg0) {
		if (location != null && location.length() > 0)
			return;
		LocationManager lm = (LocationManager) mActivity.getSystemService(Context.LOCATION_SERVICE);
		if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			startLocationUpdates();
			mLocationCountDownTimer = new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

				@Override
				public void onTick(long millisUntilFinished) {

				}

				@Override
				public void onFinish() {
					stopLocationUpdates();
					if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
						// TO DO: Consider calling
						//    ActivityCompat#requestPermissions
						// here to request the missing permissions, and then overriding
						//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
						//                                          int[] grantResults)
						// to handle the case where the user grants the permission. See the documentation
						// for ActivityCompat#requestPermissions for more details.
						return;
					}
					Location loc = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
					if (loc != null) {
						location = "" + loc.getLatitude() + "," + loc.getLongitude();
					}
				}
			};
			mLocationCountDownTimer.start();
		}
	}

	@Override
	public void onConnectionSuspended(int arg0) {
		mGoogleApiClient.connect();

	}

	/**
	 * Starting the location updates
	 * */
	protected void startLocationUpdates() {
		if (mGoogleApiClient.isConnected()) {
			if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
				// TO DO: Consider calling
				//    ActivityCompat#requestPermissions
				// here to request the missing permissions, and then overriding
				//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
				//                                          int[] grantResults)
				// to handle the case where the user grants the permission. See the documentation
				// for ActivityCompat#requestPermissions for more details.
				return;
			}
			LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
		}
 
    }
 
    /**
     * Stopping location updates
     */
    protected void stopLocationUpdates() {
    	if(mGoogleApiClient.isConnected())
    		LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
    }
 
	@Override
	public void onLocationChanged(Location loc) {
		// Assign the new location
        //mLastLocation = location;
 
        if(loc != null){
        	location = ""+loc.getLatitude()+","+loc.getLongitude();
       		stopLocationUpdates();
        	cancelLocationTimer();
        }
		
	}
	
	private void cancelLocationTimer(){
		if(mLocationCountDownTimer != null){
    		mLocationCountDownTimer.cancel();
    		mLocationCountDownTimer = null;
    	}
	}

	protected void getCurrentLocation(final Context context){
		LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
		if(lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
			if(mGoogleApiClient != null){
				if(mGoogleApiClient.isConnected()){
					mGoogleApiClient.disconnect();
				}
				mGoogleApiClient.connect();
			}
			showProgressDialog();
			new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {
				
				@Override
				public void onTick(long millisUntilFinished) {
					if(location != null){
						hideProgressDialog();
						Toast.makeText(context, MyConstants.GOT_LOCATION_MSG, Toast.LENGTH_SHORT).show();
						this.cancel();
					}
				}
				
				@Override
				public void onFinish() {
					hideProgressDialog();
					Toast.makeText(context, MyConstants.GOT_LOCATION_MSG, Toast.LENGTH_SHORT).show();
					checkForLocation = false;
					this.cancel();
				}
			}.start();
		}else{
			Utility.showAlertToOpenGPS(context);
		}
		
	}

	protected void showAlert(Context context, String title, String message, String btnName, final DialogMangerCallback mDialogCallback){
		AlertDialog dialog;
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		if(Utility.isValidStr(title))
			builder.setTitle(title);
		builder.setMessage(message);
		builder.setPositiveButton(btnName, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if(dialog != null)
					dialog.dismiss();
				if(mDialogCallback != null)
					mDialogCallback.onOkClick();
			}
		});

		dialog = builder.create();
		dialog.setCancelable(false);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();

	}

	public void ImageViewer(Context context, final String imgUrl) {
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View layout = inflater.inflate(R.layout.image_viewer, null);

		ViewGroup root = (ViewGroup) layout.findViewById(R.id.main_activity_view);

		imageDialog = new Dialog(context, android.R.style.Theme_Translucent_NoTitleBar);
		imageDialog.setContentView(layout);
		ImageView closeBtn = (ImageView) imageDialog.findViewById(R.id.closeBtn);
		ImageView editBtn = (ImageView) imageDialog.findViewById(R.id.editBtn);
		editBtn.setVisibility(View.VISIBLE);
		ImageView save_btn = (ImageView) imageDialog.findViewById(R.id.save_btn);
		ImageView imageview = (ImageView) imageDialog.findViewById(R.id.imageview);
		if (imgUrl != null && !imgUrl.isEmpty()) {
			Glide.with(context).load(imgUrl).placeholder(R.drawable.loadinggg).error(R.drawable.image_not_exist).into(imageview);
		}
		editBtn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				imageDialog.dismiss();
			}
		});
		imageDialog.show();

	}
}
