package com.activitytrack.activity;

import com.journeyapps.barcodescanner.CaptureActivity;
/**
 * Created by hareesh.a on 8/18/2017.
 */

public class ATCaptureActivityPortrait extends CaptureActivity {
}
