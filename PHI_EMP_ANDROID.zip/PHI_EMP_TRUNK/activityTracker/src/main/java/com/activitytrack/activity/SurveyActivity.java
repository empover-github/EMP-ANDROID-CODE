package com.activitytrack.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.ActionBar;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.daos.MdrSurveyDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.MdrSurveyDTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdtos.HybridMasterDTO;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import net.sourceforge.opencamera.MainActivityOC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

/**
 * Created by fatima.t on 28-03-2018.
 */

public class SurveyActivity extends BaseActivity implements AdapterView.OnItemSelectedListener {
    private SurveyActivity surveyActivity;
    private Bundle bundle;
    private long activityId, cropId;
    private String previousCropName, previousSegmentName;

    // Components
    private ScrollView mainLayout;
    private Button submitBtn;
    private ImageView profileImage, cameraIcon;
    private TextView /*locationTv,*/farmerNameTv, mobileNoTv, noOfFamiliesTv, totalLandTv,majorCropOneTv,hybridAcresOneTv, majorCroptwoTv, hybridAcresTwoTv, cropAcreaggeForTv, /*segmentDetailsTv,*/ pioneerAcresTv, pioneerHybridOneTv, pioneerHybridTwoTv, majorCompetitorOneTv, majorCompetitorOneAcresTv,  majorCompetitorTwoTv, majorCompetitorTwoAcresTv;
    private EditText /*locationEt,*/farmerNameEt, mobileNoEt, noOfFamiliesEt, totalLandEt, majorCropOneEt,hybridAcresOneEt, majorCropTwoEt, hybridAcresTwoEt,cropAcreaggeForEt, /*segmentDetailsEt,*/ pioneerAcresEt, majorCompetitorOneEt, majorCompetitorOneAcresEt,  majorCompetitorTwoEt, majorCompetitorTwoAcresEt;
    private Spinner pioneerHybridOneSpn, pioneerHybridTwoSpn;private long selectedPioneerHybridOneId = -1, selectedPioneerHybridTwoId = -1 ;

    // Lists
    private ArrayList<String> pioneerHybridOneList = new ArrayList<>();
    private ArrayList<String> pioneerHybridTwoList = new ArrayList<>();

    private List<DTO> pioneerHybridOneDTOList = new ArrayList<>();
    private ArrayList<HybridMasterDTO> pioneerHybridTwoDTOList = new ArrayList<>();

    private ArrayAdapter<String> pioneerHybridOneAdapter;
    private ArrayAdapter<String> pioneerHybridTwoAdapter;

    private File myDir;
    private String imagePath;
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    private static final int REQUEST_CODE_FOR_IMAGE_CROPPING = 65 ;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    public static final int OPENCAMERA = 300;
    private ExecutorService mExecutor;
    private Uri uriStr;
    private String latLongValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);
        surveyActivity = this;
        geoLocation = null;

        bundle = getIntent().getExtras();
        if (bundle != null) {
            activityId = bundle.getLong(MdrSurveyListActivity.EXTRA_ACTIVITY_ID);
            cropId = bundle.getLong(MdrSurveyListActivity.EXTRA_CROP_ID);
            previousCropName = bundle.getString(MdrSurveyListActivity.EXTRA_CROP_NAME);
            previousSegmentName = bundle.getString(MdrSurveyListActivity.EXTRA_SEGMENT_NAME);
        }

        // set Action bar
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setTitle(getResources().getString(R.string.survey));
        }

        initializeViews();
        setChange();

        if (checkLocPermission())
            if (Utility.checkPlayServices(surveyActivity)) {
                buildGoogleApiClient();
            }

        pioneerHybridOneAdapter = new ArrayAdapter<>(surveyActivity, android.R.layout.simple_spinner_dropdown_item, pioneerHybridOneList);
        pioneerHybridOneSpn.setAdapter(pioneerHybridOneAdapter);
        pioneerHybridTwoAdapter = new ArrayAdapter<>(surveyActivity, android.R.layout.simple_spinner_dropdown_item, pioneerHybridTwoList);
        pioneerHybridTwoSpn.setAdapter(pioneerHybridTwoAdapter);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CheckValidations()){
                    if (Utility.isValidStr(latLongValues)) {
                        showAlertToSave();
                    } else {
                        getCurrentLocation(surveyActivity);
                    }
                }
            }
        });
        
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOptionsDialog();
            }
        });
        
        cameraIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOptionsDialog();
            }
        });

        getSpinnersListAndSet();

    }

    @Override
    public void onStart() {
        super.onStart();
        geoLocation = null;
        if (geoLocation == null) {
            if (checkLocPermission())
                getCurrentLocation(surveyActivity);
            else
                showDialogToOpenSetting();

        }

    }

    private void openOptionsDialog() {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(SurveyActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                //Location Permission already granted
                cameraPermission();
            } else {
                //Request Location Permission
                checkLocationPermission();
            }
        } else {
            cameraPermission();
        }
    }

    private void initializeViews() {
        mainLayout = (ScrollView) findViewById(R.id.s_scroll_view);

        profileImage = (ImageView) findViewById(R.id.s_profile_image);
        cameraIcon = (ImageView) findViewById(R.id.s_profile_capture);
//        locationTv = (TextView) findViewById(R.id.s_farmerLocation_TV);
        farmerNameTv = (TextView) findViewById(R.id.s_farmerName_TV);
        mobileNoTv = (TextView) findViewById(R.id.s_mobileNo_TV);
        noOfFamiliesTv = (TextView) findViewById(R.id.s_no_of_families_TV);
        totalLandTv = (TextView) findViewById(R.id.s_totalLand_TV);
        majorCropOneTv = (TextView) findViewById(R.id.s_majorCrop1_TV);
        hybridAcresOneTv = (TextView) findViewById(R.id.s_hybridAcres1_TV);
        majorCroptwoTv = (TextView) findViewById(R.id.s_majorCrop2_TV);
        hybridAcresTwoTv = (TextView) findViewById(R.id.s_hybridAcres2_TV);
        cropAcreaggeForTv = (TextView) findViewById(R.id.s_crop_acreage_TV);
//        segmentDetailsTv = (TextView) findViewById(R.id.s_segment_TV);
        pioneerAcresTv = (TextView) findViewById(R.id.s_pioneerAcres_TV);
        pioneerHybridOneTv = (TextView) findViewById(R.id.s_pioneerHybrid1_TV);
        pioneerHybridTwoTv = (TextView) findViewById(R.id.s_pioneerHybrid2_TV);
        majorCompetitorOneTv = (TextView) findViewById(R.id.s_majrCompetitor1_TV);
        majorCompetitorOneAcresTv = (TextView) findViewById(R.id.s_majrCompetitorOneAcres_TV);
        majorCompetitorTwoTv = (TextView) findViewById(R.id.s_majrCompetitor2_TV);
        majorCompetitorTwoAcresTv = (TextView) findViewById(R.id.s_majrCompetitorTwoAcres_TV);

//        locationEt = (EditText) findViewById(R.id.s_farmerLocation_ET);
        farmerNameEt = (EditText) findViewById(R.id.s_farmerName_ET);
        mobileNoEt = (EditText) findViewById(R.id.s_mobileNo_ET);
        noOfFamiliesEt = (EditText) findViewById(R.id.s_no_of_families_ET);
        totalLandEt = (EditText) findViewById(R.id.s_totalLand_ET);
        majorCropOneEt = (EditText) findViewById(R.id.s_majorCrop1_ET);
        hybridAcresOneEt = (EditText) findViewById(R.id.s_hybridAcres1_ET);
        majorCropTwoEt = (EditText) findViewById(R.id.s_majorCrop2_ET);
        hybridAcresTwoEt = (EditText) findViewById(R.id.s_hybridAcres2_ET);
        cropAcreaggeForEt = (EditText) findViewById(R.id.s_crop_acreage_ET);
//        segmentDetailsEt = (EditText) findViewById(R.id.s_segment_ET);
        pioneerAcresEt = (EditText) findViewById(R.id.s_pioneerAcres_ET);
        majorCompetitorOneEt = (EditText) findViewById(R.id.s_majrCompetitor1_ET);
        majorCompetitorOneAcresEt = (EditText) findViewById(R.id.s_majrCompetitorOneAcres_ET);
        majorCompetitorTwoEt = (EditText) findViewById(R.id.s_majrCompetitor2_ET);
        majorCompetitorTwoAcresEt = (EditText) findViewById(R.id.s_majrCompetitorTwoAcres_ET);

        pioneerHybridOneSpn = (Spinner) findViewById(R.id.s_pioneerHybrid1_Spn);
        pioneerHybridTwoSpn = (Spinner) findViewById(R.id.s_pioneerHybrid2_Spn);

        submitBtn = (Button) findViewById(R.id.s_submit_btn);

        pioneerHybridOneSpn.setOnItemSelectedListener(this);
        pioneerHybridTwoSpn.setOnItemSelectedListener(this);

        String cropAcregeLable = getString(R.string.acreage_for).replace("$1", previousCropName).replace("$2", previousSegmentName);
        cropAcreaggeForTv.setText(cropAcregeLable);

//        cropAcreaggeForEt.setText(previousCropName);
//        segmentDetailsEt.setText(previousSegmentName);

    }

    private void setChange() {
        if (Utility.getCurrentTheme(surveyActivity).equals(MyConstants.THEME_DARK)) {

//            locationTv.setTextColor(Color.WHITE);
            farmerNameTv.setTextColor(Color.WHITE);
            mobileNoTv.setTextColor(Color.WHITE);
            noOfFamiliesTv.setTextColor(Color.WHITE);
            totalLandTv.setTextColor(Color.WHITE);
            majorCropOneTv.setTextColor(Color.WHITE);
            hybridAcresOneTv.setTextColor(Color.WHITE);
            majorCroptwoTv.setTextColor(Color.WHITE);
            hybridAcresTwoTv.setTextColor(Color.WHITE);
            cropAcreaggeForTv.setTextColor(Color.WHITE);
//            segmentDetailsTv.setTextColor(Color.WHITE);
            pioneerAcresTv.setTextColor(Color.WHITE);
            pioneerHybridOneTv.setTextColor(Color.WHITE);
            pioneerHybridTwoTv.setTextColor(Color.WHITE);
            majorCompetitorOneTv.setTextColor(Color.WHITE);
            majorCompetitorOneAcresTv.setTextColor(Color.WHITE);
            majorCompetitorTwoTv.setTextColor(Color.WHITE);
            majorCompetitorTwoAcresTv.setTextColor(Color.WHITE);

            pioneerHybridOneSpn.setBackgroundResource(R.drawable.spinner_bg_img);
            pioneerHybridTwoSpn.setBackgroundResource(R.drawable.spinner_bg_img);

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(surveyActivity).equals(MyConstants.THEME_LIGHT)) {
//            locationTv.setTextColor(Color.BLACK);
            farmerNameTv.setTextColor(Color.BLACK);
            mobileNoTv.setTextColor(Color.BLACK);
            noOfFamiliesTv.setTextColor(Color.BLACK);
            totalLandTv.setTextColor(Color.BLACK);
            majorCropOneTv.setTextColor(Color.BLACK);
            hybridAcresOneTv.setTextColor(Color.BLACK);
            majorCroptwoTv.setTextColor(Color.BLACK);
            hybridAcresTwoTv.setTextColor(Color.BLACK);
            cropAcreaggeForTv.setTextColor(Color.BLACK);
//            segmentDetailsTv.setTextColor(Color.BLACK);
            pioneerAcresTv.setTextColor(Color.BLACK);
            pioneerHybridOneTv.setTextColor(Color.BLACK);
            pioneerHybridTwoTv.setTextColor(Color.BLACK);
            majorCompetitorOneTv.setTextColor(Color.BLACK);
            majorCompetitorOneAcresTv.setTextColor(Color.BLACK);
            majorCompetitorTwoTv.setTextColor(Color.BLACK);
            majorCompetitorTwoAcresTv.setTextColor(Color.BLACK);

            pioneerHybridOneSpn.setBackgroundResource(R.drawable.spinner_bg_img_light);
            pioneerHybridTwoSpn.setBackgroundResource(R.drawable.spinner_bg_img_light);

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
        }
    }

    private void getSpinnersListAndSet() {
        setPioneerHybridOneSpinner();
    }

    private void setPioneerHybridOneSpinner() {
        pioneerHybridOneDTOList = HybridMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(surveyActivity).getDBObject(0));

        if (pioneerHybridOneDTOList != null && pioneerHybridOneDTOList.size() > 0) {
            pioneerHybridOneList.clear();
            for (DTO dto : pioneerHybridOneDTOList) {
                if (pioneerHybridOneList.size() == 0) {
                    pioneerHybridOneList.add("Select");
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                pioneerHybridOneList.add(hybridMasterDTO.getHybridName());
            }
            pioneerHybridOneAdapter.notifyDataSetChanged();
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(surveyActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.noHybrid));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    surveyActivity.onBackPressed();
                }
            });

            builder.create().show();
        }
    }
    private void setPioneerHybridTwoSpinner() {

        if ( pioneerHybridOneDTOList != null && pioneerHybridOneDTOList.size() > 0) {
            String itemToBeRemoved = pioneerHybridOneSpn.getSelectedItem().toString();
            for (DTO dto : pioneerHybridOneDTOList){
                HybridMasterDTO modelDto = (HybridMasterDTO) dto;
                String hybridName = modelDto.getHybridName();
                if (!hybridName.equals(itemToBeRemoved)) {
                    pioneerHybridTwoDTOList.add(modelDto);

                    if (pioneerHybridTwoList.size() == 0)
                        pioneerHybridTwoList.add(getString(R.string.select));

                    pioneerHybridTwoList.add(modelDto.getHybridName());
                }
            }
            pioneerHybridTwoAdapter.notifyDataSetChanged();
            pioneerHybridTwoSpn.setSelection(0);
        }
    }

    private boolean CheckValidations() {

        /*int totalLand_int = 0, cropAcreage_int = 0, hybridAcresOne_int = 0 ,hybridAcresTwo_int = 0, pioneerAcres_int = 0, majorCompeOneAcres_int = 0, majorCompeTwoAcres_int = 0, sumOfAllAcres = 0;
        if (Utility.isValidStr(totalLandEt.getText().toString().trim()))
            totalLand_int = Integer.parseInt(totalLandEt.getText().toString().trim());
        if (Utility.isValidStr(cropAcreaggeForEt.getText().toString().trim()))
            cropAcreage_int = Integer.parseInt(cropAcreaggeForEt.getText().toString().trim());
        if (Utility.isValidStr(hybridAcresOneEt.getText().toString().trim()))
            hybridAcresOne_int = Integer.parseInt(hybridAcresOneEt.getText().toString().trim());
        if (Utility.isValidStr(hybridAcresTwoEt.getText().toString().trim()))
            hybridAcresTwo_int = Integer.parseInt(hybridAcresTwoEt.getText().toString().trim());
        if (Utility.isValidStr(pioneerAcresEt.getText().toString().trim()))
            pioneerAcres_int = Integer.parseInt(pioneerAcresEt.getText().toString().trim());
        if (Utility.isValidStr(majorCompetitorOneAcresEt.getText().toString().trim()))
            majorCompeOneAcres_int = Integer.parseInt(majorCompetitorOneAcresEt.getText().toString().trim());
        if (Utility.isValidStr(majorCompetitorTwoAcresEt.getText().toString().trim()))
            majorCompeTwoAcres_int = Integer.parseInt(majorCompetitorTwoAcresEt.getText().toString().trim());

        sumOfAllAcres =cropAcreage_int + hybridAcresOne_int + hybridAcresTwo_int+ pioneerAcres_int + majorCompeOneAcres_int + majorCompeTwoAcres_int;
        */


        if (!Utility.isValidStr(imagePath)){
            DialogManager.showToast(surveyActivity, getString(R.string.image_error));
            return false;
        } /*else if (!Utility.isValidStr(locationEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.location_error));
            return false;
        }*/ else if (!Utility.isValidStr(farmerNameEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.farmer_name_error));
            return false;
        } else if (!Utility.isValidStr(mobileNoEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.mobile_no_error));
            return false;
        }  else if (Utility.isValidStr(mobileNoEt.getText().toString().trim()) && mobileNoEt.length() < 10) {
            DialogManager.showToast(surveyActivity, getString(R.string.mobile_no_valid_error));
            return false;
        }  else if (!Utility.isValidStr(noOfFamiliesEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.no_of_families_error));
            return false;
        }  else if (Utility.isValidStr(noOfFamiliesEt.getText().toString().trim()) && Integer.parseInt(noOfFamiliesEt.getText().toString()) <= 0) {
            DialogManager.showToast(surveyActivity, getString(R.string.no_of_families_valid_error));
            return false;
        } else if (!Utility.isValidStr(totalLandEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.total_land_error));
            return false;
        } else if (Utility.isValidStr(totalLandEt.getText().toString().trim()) && Integer.parseInt(totalLandEt.getText().toString()) <= 0) {
            DialogManager.showToast(surveyActivity, getString(R.string.total_land_valid_error));
            return false;
        } else if (!Utility.isValidStr(cropAcreaggeForEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.crop_acreage_error));
            return false;
        } else if (Utility.isValidStr(cropAcreaggeForEt.getText().toString().trim()) && Integer.parseInt(cropAcreaggeForEt.getText().toString()) <= 0) {
            DialogManager.showToast(surveyActivity, getString(R.string.crop_acreage_valid_error));
            return false;
        } else if (!Utility.isValidStr(majorCropOneEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_crop1_error));
            return false;
        }  else if (!Utility.isValidStr(hybridAcresOneEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.hybrid_acres_error));
            return false;
        } else if (Utility.isValidStr(hybridAcresOneEt.getText().toString().trim()) && Integer.parseInt(hybridAcresOneEt.getText().toString()) <= 0 ) {
            DialogManager.showToast(surveyActivity, getString(R.string.hybrid_acres_valid_error));
            return false;
        } /*else if (!Utility.isValidStr(majorCropTwoEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_crop2_error));
            return false;
        }else if (!Utility.isValidStr(hybridAcresTwoEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.hybrid_acres_error));
            return false;
        } else if (Utility.isValidStr(hybridAcresTwoEt.getText().toString().trim()) && Integer.parseInt(hybridAcresTwoEt.getText().toString()) <= 0 ) {
            DialogManager.showToast(surveyActivity, getString(R.string.hybrid_acres_valid_error));
            return false;
        }*/ else if (!Utility.isValidStr(pioneerAcresEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.pioneer_acres_error));
            return false;
        } else if (Utility.isValidStr(pioneerAcresEt.getText().toString().trim()) && Integer.parseInt(pioneerAcresEt.getText().toString()) < 0) {
            DialogManager.showToast(surveyActivity, getString(R.string.pioneer_acres_valid_error));
            return false;
        } else if (Utility.isValidStr(pioneerAcresEt.getText().toString().trim()) && Integer.parseInt(pioneerAcresEt.getText().toString()) > 0 && pioneerHybridOneSpn.getSelectedItem().toString().equals(getString(R.string.select)) ){
            DialogManager.showToast(surveyActivity, getString(R.string.spinner_pioneer_hybrid_one_error));
            return false;
        }
        /*else if (!Utility.isValidStr(majorCompetitorOneEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_competitor_one_error));
            return false;
        } else if (!Utility.isValidStr(majorCompetitorOneAcresEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_competitor_one_acres_error));
            return false;
        } else if (Utility.isValidStr(majorCompetitorOneAcresEt.getText().toString().trim()) && Integer.parseInt(majorCompetitorOneAcresEt.getText().toString()) <= 0) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_competitor_one_acres_valid_error));
            return false;
        } else if (!Utility.isValidStr(majorCompetitorTwoEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_competitor_two_error));
            return false;
        } else if (!Utility.isValidStr(majorCompetitorTwoAcresEt.getText().toString().trim())) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_competitor_two_acres_error));
            return false;
        } else if (Utility.isValidStr(majorCompetitorTwoAcresEt.getText().toString().trim()) && Integer.parseInt(majorCompetitorTwoAcresEt.getText().toString()) <= 0 ) {
            DialogManager.showToast(surveyActivity, getString(R.string.major_competitor_two_acres_valid_error));
            return false;
        }else if (pioneerHybridOneSpn.getSelectedItem().toString().equals(getString(R.string.select))) {
            DialogManager.showToast(surveyActivity, getString(R.string.spinner_pioneer_hybrid_one_error));
            return false;
        } else if (pioneerHybridTwoSpn.getSelectedItem().toString().equals(getString(R.string.select))) {
            DialogManager.showToast(surveyActivity, getString(R.string.spinner_pioneer_hybrid_two_error));
            return false;
        }  else if (totalLand_int < sumOfAllAcres){
            DialogManager.showToast(surveyActivity, getString(R.string.all_acres_error));
            return false;
        } */ else if (Utility.isValidStr(mobileNoEt.getText().toString().trim()) && mobileNoEt.length() == 10) {
            int sum = validateMobileOrPin(mobileNoEt.getText().toString().trim());
            if (sum == 0) {
                DialogManager.showToast(surveyActivity, getString(R.string.mobile_no_valid_error));
                return false;
            }
        }
        return true;
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int i = parent.getId();

        if (Utility.getCurrentTheme(surveyActivity).equals(MyConstants.THEME_LIGHT)) {
            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
        } else {
            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
        }

        if (i == R.id.s_pioneerHybrid1_Spn) {
            if (position > 0) {
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) pioneerHybridOneDTOList.get(position - 1);
                selectedPioneerHybridOneId = hybridMasterDTO.getId();

                pioneerHybridTwoList.clear();
                pioneerHybridTwoDTOList.clear();
                pioneerHybridTwoAdapter.notifyDataSetChanged();
                setPioneerHybridTwoSpinner();
            }
        } else if (i == R.id.s_pioneerHybrid2_Spn) {
            if (position > 0) {
                selectedPioneerHybridTwoId = pioneerHybridTwoDTOList.get(position - 1).getId();
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(surveyActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveData();
                finish();
                setResult(RESULT_OK);
            }


        });

        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void saveData() {

        MdrSurveyDTO dto = new MdrSurveyDTO();
        dto.setActivityId(activityId);
        // add image path URL
        dto.setLocalImagePath(imagePath);
        dto.setLatlong(latLongValues);
//        dto.setGeoLocation(locationEt.getText().toString());
        dto.setFarmerName(farmerNameEt.getText().toString());
        dto.setMobileNo(mobileNoEt.getText().toString().trim());
        dto.setNoOfFamilies(Integer.parseInt(noOfFamiliesEt.getText().toString()));
        dto.setTotalLand(Integer.parseInt(totalLandEt.getText().toString()));
        dto.setMajorCropOneName(majorCropOneEt.getText().toString());
        dto.setHybridAcresOne(Integer.parseInt(hybridAcresOneEt.getText().toString().trim()));
        dto.setMajorCropTwoName(majorCropTwoEt.getText().toString());
        if (Utility.isValidStr(hybridAcresTwoEt.getText().toString().trim()))
            dto.setHybridAcresTwo(Integer.parseInt(hybridAcresTwoEt.getText().toString().trim()));
        dto.setCropAcreageFor(cropAcreaggeForEt.getText().toString());
//        dto.setSegmentDetails(segmentDetailsEt.getText().toString());
        dto.setSegmentDetails(previousSegmentName);
        dto.setPioneerAcres(Integer.parseInt(pioneerAcresEt.getText().toString()));
        if (selectedPioneerHybridOneId != -1)
            dto.setPioneerHybridOneId(selectedPioneerHybridOneId);
        if (selectedPioneerHybridTwoId != -1)
            dto.setPioneerHybridTwoId(selectedPioneerHybridTwoId);
        dto.setMajorCompetitorOne(majorCompetitorOneEt.getText().toString());
        if (Utility.isValidStr(majorCompetitorOneAcresEt.getText().toString().trim()))
            dto.setMajorCompetitorOneAcres(Integer.parseInt(majorCompetitorOneAcresEt.getText().toString()));
        dto.setMajorCompetitorTwo(majorCompetitorTwoEt.getText().toString());
        if (Utility.isValidStr(majorCompetitorTwoAcresEt.getText().toString().trim()))
            dto.setMajorCompetitorTwoAcres(Integer.parseInt(majorCompetitorTwoAcresEt.getText().toString()));

        MdrSurveyDAO.getInstance().insert(dto, DBHandler.getInstance(surveyActivity).getDBObject(1));
    }

    @Override
    public void onBackPressed() {
        if (isDataAvaliable()) {
            showAlertToExitScreen();
        } else {
            finish();
            setResult(RESULT_CANCELED);
        }
    }

    private void showAlertToExitScreen() {
        AlertDialog.Builder builder = new AlertDialog.Builder(surveyActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                setResult(RESULT_OK);
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    private boolean isDataAvaliable() {

        /*if (locationEt.getText().toString().trim().length() > 0)
            return true;*/

        if (farmerNameEt.getText().toString().trim().length() > 0)
            return true;

        if (mobileNoEt.getText().toString().trim().length() > 0)
            return true;

        if (noOfFamiliesEt.getText().toString().trim().length() > 0)
            return true;

        if (totalLandEt.getText().toString().trim().length() > 0)
            return true;

        if (cropAcreaggeForEt.getText().toString().length() > 0)
            return true;

        if (majorCropOneEt.getText().toString().trim().length() > 0)
            return true;

        if (hybridAcresOneEt.getText().toString().trim().length() > 0)
            return true;

        if (majorCropTwoEt.getText().toString().trim().length() > 0) {
            return true;
        }

        if (hybridAcresTwoEt.getText().toString().trim().length() > 0)
            return true;

        if (pioneerAcresEt.getText().toString().trim().length() > 0)
            return true;

        if (majorCompetitorOneEt.getText().toString().trim().length() > 0)
            return true;

        if (majorCompetitorOneAcresEt.getText().toString().trim().length() > 0)
            return true;

        if (majorCompetitorTwoEt.getText().toString().trim().length() > 0)
            return true;

        if (majorCompetitorTwoAcresEt.getText().toString().trim().length() > 0)
            return true;

        if (!(pioneerHybridOneSpn.getSelectedItem().equals(getString(R.string.select))))
            return true;

        if (pioneerHybridTwoSpn.getSelectedItem() != null)
            return true;
        /*if (!(pioneerHybridTwoSpn.getSelectedItem().equals(getString(R.string.select))))
            return true;*/

        return false;
    }

    private int validateMobileOrPin(String trim) {
        int sum = 0;
        char[] arrayElements = trim.toCharArray();
        for (int i = 0; i < arrayElements.length; i++) {
            String v = String.valueOf(arrayElements[i]);
            sum += Integer.parseInt(v);
        }
        return sum;
    }

    private void cameraPermission() {
        File newfile = createFile();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkPermission()) {
                if (!Utility.isValidStr(imagePath)) {
                    openCameraApp(newfile);
                } else {
                    showOptionOpenCameraforSurvey(null, surveyActivity, newfile);
                }
            }
        } else {
            if (!Utility.isValidStr(imagePath)) {
                openCameraApp(newfile);
            } else {
                showOptionOpenCameraforSurvey(null, surveyActivity, newfile);
            }
        }
    }

    private File createFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        myDir = new File(root + File.separator + "SurveyFarmerImage");
        if (!myDir.exists())
            myDir.mkdirs();

        File newfile = new File(myDir, "IMG_" + System.currentTimeMillis() + ".JPG");
        try {
            newfile.createNewFile();
        } catch (IOException e) {
        }
        return newfile;
    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(surveyActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(surveyActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(surveyActivity, Manifest.permission.CAMERA) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(surveyActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(surveyActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(surveyActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));

            } else {
                // No explanation needed, we can request the permission.
                if (Utility.isFirstTimeCamera(surveyActivity)) {

                    DialogManager.showConformPopup(surveyActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            Utility.setFirstTimeCamera(false, surveyActivity);
                            ActivityCompat.requestPermissions(surveyActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));


                } else {
                    ActivityCompat.requestPermissions(surveyActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }

        return false;
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(surveyActivity,
                                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }
    public void openCameraApp(File newfile) {
        Uri outputFileUri = Uri.fromFile(newfile);
        String uriString = outputFileUri.toString();

        Intent intent = new Intent(surveyActivity, MainActivityOC.class);
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE); // without this not working, not getting data only
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        startActivityForResult(intent, OPENCAMERA);
    }

    private void showOptionOpenCameraforSurvey(String title, final FragmentActivity context, final File newfile) {
        final Dialog mDialog;
        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.paravakta_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mREmovePhoto, mViewPhoto;
        Button mCancel;
        TextView mTitile = (TextView) mDialog.findViewById(R.id.alertTitle);
        if (Utility.isValidStr(title))
            mTitile.setText(title);
        mFromCamera = (TextView) mDialog.findViewById(R.id.from_camera);
        mREmovePhoto = (TextView) mDialog.findViewById(R.id.remove_photo);
        mViewPhoto = (TextView) mDialog.findViewById(R.id.view_image);
        mCancel = (Button) mDialog.findViewById(R.id.cancel);

        mFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                openCameraApp(newfile);
            }
        });
        mREmovePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                profileImage.setImageResource(R.drawable.img_profile_avatar);
                uriStr = null;
                imagePath = null;
            }
        });

        mViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                if (profileImage.getDrawable() != null) {
                    if (uriStr != null) {
                        ImageViewer(surveyActivity, uriStr.toString());
                    }
                }
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == OPENCAMERA) {
            if (resultCode == RESULT_OK) {
                try {/*
//                    uriStr = (Uri) data.getExtras().get("data");
                    Uri uriStrTremp = (Uri) data.getExtras().get("data");  // if we captured new pic but not cropped, thn showing old pic in imageView but when we click on see full photo thn new pic is shown. thats why created local variable

                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uriStrTremp);

                    if (bitmap != null) {
                        String imagePath = storeImage(bitmap, "survey_profile" + "_");
                        Uri mCapturedUri = Uri.fromFile(new File(imagePath));

                        Intent gotoCropImage = new Intent(surveyActivity, ATCropMyImageActivity.class);
                        gotoCropImage.setData(uriStrTremp);
                        startActivityForResult(gotoCropImage, REQUEST_CODE_FOR_IMAGE_CROPPING);
                    }*/

                    mExecutor = Executors.newSingleThreadExecutor();
                    Uri myUri = (Uri) data.getExtras().get("data");
                    uriStr = myUri;
                    mExecutor.submit(new LoadScaledImageTask(surveyActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                    imagePath = myUri.toString();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (resultCode == RESULT_CANCELED) {
                DialogManager.showToast(surveyActivity, getString(R.string.user_cancelled_image_capture));
            } else {
                DialogManager.showToast(surveyActivity, getString(R.string.failed_to_capture_image));
            }
        } else if (requestCode == REQUEST_CODE_FOR_IMAGE_CROPPING ){
            if (resultCode == RESULT_OK ) {
                mExecutor = Executors.newSingleThreadExecutor();
                Uri myUri = data.getData();
                uriStr = myUri;
                mExecutor.submit(new LoadScaledImageTask(surveyActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                imagePath = myUri.toString();
            } else if (resultCode == RESULT_CANCELED){

                DialogManager.showToast(surveyActivity, getString(R.string.at_user_cancelled_image_cropping));
            }
        }
    }

    private String storeImage(Bitmap image, String fileName) {
        File pictureFile = getOutputMediaFile(fileName);
        if (pictureFile == null) {
            // Log.d(TAG,
            // "Error creating media file, check storage permissions: ");//
            // e.getMessage());
            return "";
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.JPEG, 80, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            // Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            // Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
        System.out.println("Path:" + pictureFile.getAbsolutePath());
        return pictureFile.getAbsolutePath();
    }
    /**
     * Create a File for saving an image or video
     */
    private File getOutputMediaFile(String fileName) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(
                Environment.getExternalStorageDirectory() + "/Android/data/"
                        + getPackageName() + "/Files");

        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }

        File mediaFile;
        String mImageName = "ActivityTracker_" + fileName + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator
                + mImageName);
        return mediaFile;
    }
    private int calcImageSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        Display display =getWindowManager().getDefaultDisplay();
        display.getMetrics(metrics);
        return Math.min(Math.max(metrics.widthPixels, metrics.heightPixels), 2048);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            //ProfileImageSelectionUtil.showOption(null, mActivity);
                            openCameraApp(newfile);
                        else
                            checkPermission();
                    } else {
                        openCameraApp(newfile);
                        //ProfileImageSelectionUtil.showOption(null, mActivity);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }

            }
            break;
            case REQUEST_CAMERA_PERMISSION_DENAIL: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            openCameraApp(newfile);
                        else
                            showDialogToOpenSetting();
                    } else {

                        openCameraApp(newfile);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    showDialogToOpenSetting();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
            break;

            // other 'case' lines to check for other
            // permissions this app might request
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(surveyActivity,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient != null) {
                            mGoogleApiClient.connect();
                        } else {
                            buildGoogleApiClient();
                            mGoogleApiClient.connect();
                        }
                    }
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(surveyActivity, "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }

    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(surveyActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(surveyActivity, getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {
        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        finish();
    }

    public static class LoadScaledImageTask implements Runnable {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        Context context;
        Uri uri;
        ImageView imageView;
        int width;

        public LoadScaledImageTask(Context context, Uri uri, ImageView imageView, int width) {
            this.context = context;
            this.uri = uri;
            this.imageView = imageView;
            this.width = width;
        }
        @Override
        public void run() {
            final int exifRotation = com.isseiaoki.simplecropview.util.Utils.getExifOrientation(context, uri);
            int maxSize = com.isseiaoki.simplecropview.util.Utils.getMaxSize();
            int requestSize = Math.min(width, maxSize);
            try {
                final Bitmap sampledBitmap = com.isseiaoki.simplecropview.util.Utils.decodeSampledBitmapFromUri(context, uri, requestSize);
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        imageView.setImageMatrix(com.isseiaoki.simplecropview.util.Utils.getMatrixFromExifOrientation(exifRotation));
                        imageView.setImageBitmap(sampledBitmap);
                    }
                });
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void refresh() {

        latLongValues = geoLocation;
//        onLocationCompleted(latLongValues);
//        locationEt.setText(latLongValues);

    }

    private boolean checkLocPermission() {

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(surveyActivity, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    protected void getCurrentLocation(final Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (mGoogleApiClient != null) {
                if (mGoogleApiClient.isConnected()) {
                    mGoogleApiClient.disconnect();
                }
                mGoogleApiClient.connect();
            }
            CountDownTimer start = new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

                @Override
                public void onTick(long millisUntilFinished) {
                    if (geoLocation != null) {
                        latLongValues = geoLocation;
//                        onLocationCompleted(latLongValues);
//                        locationEt.setText(latLongValues);
                        hideProgressDialog();

                        this.cancel();
                    }
                }

                @Override
                public void onFinish() {
                    hideProgressDialog();
                    this.cancel();
                }
            }.start();
        } else {
            DialogManager.showSingleBtnPopup(surveyActivity, null, getString(R.string.alert), getString(R.string.gps), getString(R.string.ok));
        }
    }

    /*private void onLocationCompleted(String currentLatLongVals) {

        ATBuildLog.e("SurveyActivityLocations", latLongValues);

        String[] currentLatLong = currentLatLongVals.split(",");
        double latValue = Double.parseDouble(currentLatLong[0]);
        double longValue = Double.parseDouble(currentLatLong[1]);
        LatLng latLng = new LatLng(latValue, longValue);
        StringBuilder builder = null;

        Geocoder geocoder1 = new Geocoder(surveyActivity, Locale.getDefault());
        List<Address> addressList = null;
        try {
            addressList = geocoder1.getFromLocation(latLng.latitude, latLng.longitude, 1);
            if (addressList != null && addressList.size() > 0)
                //BuildLog.d("Test", addressList.get(0).getLocality());
                System.out.println(addressList.get(0).getLocality());

            Address address = addressList.get(0);

            String addline1 = address.getAddressLine(0);

            String data[] = addline1.split(",");
            for (String lo : data) {
                if (builder == null) {
                    builder = new StringBuilder();
                } else {
                    builder.append(",");
                }
                builder.append(lo);
            }
            //String locality = (addline1.split(",")[0]) + "," + (addline1.split(","))[1] + "," + (addline1.split(","))[3] + "," + (addline1.split(","))[4];
            String countryName = address.getCountryName();
            String countryCode = address.getCountryCode();
            double lat = address.getLatitude();
            address.getFeatureName();
            double lon = address.getLongitude();
            if (builder != null) {
                locationEt.setText(builder.toString());
            } else {
                locationEt.setText("");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

}
