package com.activitytrack.dtos;

public class FarmerSegmentationNestleResponseDTO implements DTO {

    private String year;
    private long seasonId;
    private String seasonName;
    private long cropId;
    private String cropName;
    private String serverImagePath;

    private String farmerName;
    private String farmerMobileNumber;
    private String pinCode;
    private String villageName;
    private String blockName;
    private String districtName;

    private long totalNumberCattles;
    private long averageMilkYield;
    private String silageFeeding;
    private String growingProcuring;
    private long acres;

    private String hybridName1;
    private String hybridName2;
    private String hybridName3;
    private String hybridName4;
    private String hybridName;
    private String hybridName5;

    private long hybridValue;
    private long hybridValue1;
    private long hybridValue2;
    private long hybridValue3;
    private long hybridValue4;
    private long hybridValue5;

    private String plant;
    private String grow;
    private String harvest;
    private String store;
    private String feed;

    /*private Long devCenterId;
    private Long schoolId;
    private String devCenterName;
    private String schoolName;

    private String year;

    private String farmerName;
    private String mobileNo;
    private String pincode	;
    private String village;
    private String block;
    private String district;

    private long totalNoOfCattles;
    private long avgMilkYield;

    private String silageFeeding;
    private String growingOrProcuring;
    private double silageAcres;

    private String currHyb1Name;
    private String currHyb2Name;
    private String currHyb3Name;
    private String currHyb4Name;
    private String currHyb5Name;

    private double currHyb1Value;
    private double currHyb2Value;
    private double currHyb3Value;
    private double currHyb4Value;
    private double currHyb5Value;

    private String trainingPlant;
    private String trainingGrow;
    private String trainingHarvest;
    private String trainingStore;
    private String trainingFeed;

    private String isTBL;
    private Timestamp date;

    private String localImagePath;
    private Long mobileId;

    private String geoLocation;

    private String serverImagePath;*/


    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public long getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(long seasonId) {
        this.seasonId = seasonId;
    }

    public String getSeasonName() {
        return seasonName;
    }

    public void setSeasonName(String seasonName) {
        this.seasonName = seasonName;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getServerImagePath() {
        return serverImagePath;
    }

    public void setServerImagePath(String serverImagePath) {
        this.serverImagePath = serverImagePath;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getFarmerMobileNumber() {
        return farmerMobileNumber;
    }

    public void setFarmerMobileNumber(String farmerMobileNumber) {
        this.farmerMobileNumber = farmerMobileNumber;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public long getTotalNumberCattles() {
        return totalNumberCattles;
    }

    public void setTotalNumberCattles(long totalNumberCattles) {
        this.totalNumberCattles = totalNumberCattles;
    }

    public long getAverageMilkYield() {
        return averageMilkYield;
    }

    public void setAverageMilkYield(long averageMilkYield) {
        this.averageMilkYield = averageMilkYield;
    }


    public long getAcres() {
        return acres;
    }

    public void setAcres(long acres) {
        this.acres = acres;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getHybridName1() {
        return hybridName1;
    }

    public void setHybridName1(String hybridName1) {
        this.hybridName1 = hybridName1;
    }

    public String getHybridName2() {
        return hybridName2;
    }

    public void setHybridName2(String hybridName2) {
        this.hybridName2 = hybridName2;
    }

    public String getHybridName3() {
        return hybridName3;
    }

    public void setHybridName3(String hybridName3) {
        this.hybridName3 = hybridName3;
    }

    public String getHybridName4() {
        return hybridName4;
    }

    public void setHybridName4(String hybridName4) {
        this.hybridName4 = hybridName4;
    }

    public long getHybridValue() {
        return hybridValue;
    }

    public void setHybridValue(long hybridValue) {
        this.hybridValue = hybridValue;
    }

    public long getHybridValue1() {
        return hybridValue1;
    }

    public void setHybridValue1(long hybridValue1) {
        this.hybridValue1 = hybridValue1;
    }

    public long getHybridValue2() {
        return hybridValue2;
    }

    public void setHybridValue2(long hybridValue2) {
        this.hybridValue2 = hybridValue2;
    }

    public long getHybridValue3() {
        return hybridValue3;
    }

    public void setHybridValue3(long hybridValue3) {
        this.hybridValue3 = hybridValue3;
    }

    public long getHybridValue4() {
        return hybridValue4;
    }

    public void setHybridValue4(long hybridValue4) {
        this.hybridValue4 = hybridValue4;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getSilageFeeding() {
        return silageFeeding;
    }

    public void setSilageFeeding(String silageFeeding) {
        this.silageFeeding = silageFeeding;
    }

    public String getGrowingProcuring() {
        return growingProcuring;
    }

    public void setGrowingProcuring(String growingProcuring) {
        this.growingProcuring = growingProcuring;
    }

    public String getHybridName5() {
        return hybridName5;
    }

    public void setHybridName5(String hybridName5) {
        this.hybridName5 = hybridName5;
    }

    public long getHybridValue5() {
        return hybridValue5;
    }

    public void setHybridValue5(long hybridValue5) {
        this.hybridValue5 = hybridValue5;
    }

    public String getPlant() {
        return plant;
    }

    public void setPlant(String plant) {
        this.plant = plant;
    }

    public String getGrow() {
        return grow;
    }

    public void setGrow(String grow) {
        this.grow = grow;
    }

    public String getHarvest() {
        return harvest;
    }

    public void setHarvest(String harvest) {
        this.harvest = harvest;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public String getFeed() {
        return feed;
    }

    public void setFeed(String feed) {
        this.feed = feed;
    }
}
