package com.activitytrack.activity;

import java.util.Calendar;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.daos.LiquidationTrackingDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.LiquidationTrackingDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

public class LiquidationFragment extends BaseFragment {

private View view;

private Spinner spnCrop;
private Spinner spnRetailerName;

private TextView tvSalesDate;

private ImageView imgSalesDateImg;
 


private TextView tvCrop;
private TextView tvSales;
private TextView tvRetailerName;
private TextView tvRetailerMobileNo;
private TextView tvPincode;
private TextView tvSeason;
private TextView tvPioneerSales;
private TextView tvCompetitor1Sales;
private TextView tvCompetitor2Sales;
private TextView tvOtherSales;


private EditText edtRetailerMobileNo;
private EditText edtPincode;
private EditText edtSeason;
private EditText edtPioneerSales;
private EditText edtCompetitor1Sales;
private EditText edtCompetitor2Sales;
private EditText edtOtherSales;
	
private LinearLayout mainLayout;
private LinearLayout salesDateLayout;
private Button btnSubmit;
@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.liquidation_fragment, container, false);
		
		spnCrop=(Spinner)view.findViewById(R.id.ld_crop);
		tvSalesDate=(TextView)view.findViewById(R.id.ld_salesDate);
		imgSalesDateImg=(ImageView)view.findViewById(R.id.ld_salesDateImg);
		spnRetailerName=(Spinner)view.findViewById(R.id.ld_retailerName);
		
		tvCrop=(TextView)view.findViewById(R.id.ld_crop_l);
		tvSales=(TextView)view.findViewById(R.id.ld_salesDate_l);
		tvRetailerName=(TextView)view.findViewById(R.id.ld_retailerName_l);
		tvRetailerMobileNo=(TextView)view.findViewById(R.id.ld_retailerMobileNo_l);
		tvPincode=(TextView)view.findViewById(R.id.ld_pincode_l);
		tvSeason=(TextView)view.findViewById(R.id.ld_season_l);
		tvPioneerSales=(TextView)view.findViewById(R.id.ld_pioneerSales_l);
		tvCompetitor1Sales=(TextView)view.findViewById(R.id.ld_competitor1Sales_l);
		tvCompetitor2Sales=(TextView)view.findViewById(R.id.ld_competitor2Sales_l);
		tvOtherSales=(TextView)view.findViewById(R.id.ld_otherSales_l);
	
		edtRetailerMobileNo=(EditText)view.findViewById(R.id.ld_retailerMobileNo);
		edtPincode=(EditText)view.findViewById(R.id.ld_pincode);
		edtSeason=(EditText)view.findViewById(R.id.ld_season);
		edtPioneerSales=(EditText)view.findViewById(R.id.ld_pioneerSales);
		edtCompetitor1Sales=(EditText)view.findViewById(R.id.ld_competitor1Sales);
		edtCompetitor2Sales=(EditText)view.findViewById(R.id.ld_competitor2Sales);
		edtOtherSales=(EditText)view.findViewById(R.id.ld_otherSales);
		
		btnSubmit=(Button)view.findViewById(R.id.ld_submit);
		
		mainLayout=(LinearLayout)view.findViewById(R.id.ld_bg_laylout);
		salesDateLayout=(LinearLayout)view.findViewById(R.id.ld_salesDateLayout);
		
		
		
	
         setChange();
		
		btnSubmit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) 
			{
				String Validation= validationFields();
				if(Validation.trim().length()==0)
				{
					showAlertToSave();
				}
				
				else{
					Utility.showAlert(mActivity, "",Validation);
				}
			}

			
			
		});
		
		imgSalesDateImg.setOnClickListener(new OnClickListener() 
		{
			
			@Override
			public void onClick(View v) 
			{
				showDate();
				
				
			}

			private void showDate() 
			{
				DateListener datePicker=new DateListener();
				showDatePickerDialog(mActivity,datePicker);
				 
				
			}
            class DateListener implements OnDateSetListener
            {

				@Override
				public void onDateSet(DatePicker view, int year,
						int monthOfYear, int dayOfMonth) 
				{
					tvSalesDate.setText(dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
					 
					
				}
            	
            }
			private void showDatePickerDialog(ATMainActivity mActivity, DateListener datePicker) {
				 Calendar calendar=Calendar.getInstance();
				 DatePickerDialog datePickerDialog=new DatePickerDialog(mActivity, datePicker, calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
				 datePickerDialog.getDatePicker().setCalendarViewShown(true);
					datePickerDialog.show();
				
			}
		});
		
		return view;
	}

	private String validationFields() 
	{
		if(spnCrop.getSelectedItemPosition()==0)
			return "Please Select Crop";
		
		if(spnRetailerName.getSelectedItemPosition()==0)
			return "Please Select Retailer Name";
		
			if(edtRetailerMobileNo.getText().toString().trim().length()==0)
			return "RetailerMobile Number Field should not be Empty";
		
		if(edtPincode.getText().toString().trim().length()==0)
			return "Pincode Number Field should not be Empty";
		
		if(edtSeason.getText().toString().trim().length()==0)
			return "Season Number Field should not be Empty";
		
		if(edtPioneerSales.getText().toString().trim().length()==0)
			return "PioneerSales Number Field should not be Empty";
		
		if(edtCompetitor1Sales.getText().toString().trim().length()==0)
			return "Competitor1Sales Number Field should not be Empty";
		
		if(edtCompetitor2Sales.getText().toString().trim().length()==0)
			return "Competitor2Sales Number Field should not be Empty";
		
		if(edtOtherSales.getText().toString().trim().length()==0)
			return "OtherSales Number Field should not be Empty";
		
		return "";
		

    }

	
	private void showAlertToSave() 
	{
	 
		AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		builder.setMessage("Are you want to save date");
		builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
				saveData();
			}

			
		});
	
	builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int which) {
			 
			
		}
	});
	builder.create().show();
	}

	private void saveData() 
	{
		 LiquidationTrackingDTO dto=new LiquidationTrackingDTO();
		
		 dto.setCrop("");
		 dto.setSalesDate(tvSalesDate.getText().toString().trim());
		 dto.setRetailerName("");
		 dto.setRetailerMobileNo(Long.valueOf(edtRetailerMobileNo.getText().toString().trim()));
		 dto.setPinCode(Integer.valueOf(edtPincode.getText().toString().trim()));
		 dto.setSeason(Integer.valueOf(edtSeason.getText().toString().trim()));
		 dto.setPioneerSales(Integer.valueOf(edtPioneerSales.getText().toString().trim()));
		 dto.setCompetitor1Sales(Integer.valueOf(edtCompetitor1Sales.getText().toString().trim()));
		 dto.setCompetitor2Sales(Integer.valueOf(edtCompetitor2Sales.getText().toString().trim()));
		 dto.setOtherSales(Integer.valueOf(edtOtherSales.getText().toString().trim()));
			
		 boolean inserted=LiquidationTrackingDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getDBObject(1));
			  if(inserted)
			  {
				  Toast.makeText(mActivity, "Successfully inserted", Toast.LENGTH_SHORT).show();
					clearFields();
			  }
			
		 
		  
	}
	
	
	private void clearFields() 
	{
		 spnCrop.setSelection(0);
		 spnRetailerName.setSelection(0);
		 edtRetailerMobileNo.setText("");
		 edtPincode.setText("");
		 edtSeason.setText("");
		 edtPioneerSales.setText("");
		 edtCompetitor1Sales.setText("");
		 edtCompetitor2Sales.setText("");
		 edtOtherSales.setText("");
	
	}

	private void setChange(){
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			tvCrop.setTextColor(Color.WHITE);
			tvSales.setTextColor(Color.WHITE);
			tvSalesDate.setTextColor(Color.WHITE);
			tvRetailerName.setTextColor(Color.WHITE);	
			tvRetailerMobileNo.setTextColor(Color.WHITE);
			tvPincode.setTextColor(Color.WHITE);
			tvPioneerSales.setTextColor(Color.WHITE);
			tvSeason.setTextColor(Color.WHITE);
			tvCompetitor1Sales.setTextColor(Color.WHITE);
			tvCompetitor2Sales.setTextColor(Color.WHITE);
			tvOtherSales.setTextColor(Color.WHITE);
			imgSalesDateImg.setImageResource(R.drawable.calender_icon);
			salesDateLayout.setBackgroundResource(R.drawable.textfield_bg);
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
			 
			
		}else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
			tvCrop.setTextColor(Color.BLACK);
			tvSales.setTextColor(Color.BLACK);
			tvSalesDate.setTextColor(Color.BLACK);
			tvRetailerName.setTextColor(Color.BLACK);	
			tvRetailerMobileNo.setTextColor(Color.BLACK);
			tvPincode.setTextColor(Color.BLACK);
			tvPioneerSales.setTextColor(Color.BLACK);
			tvSeason.setTextColor(Color.BLACK);
			tvCompetitor1Sales.setTextColor(Color.BLACK);
			tvCompetitor2Sales.setTextColor(Color.BLACK);
			tvOtherSales.setTextColor(Color.BLACK);
			salesDateLayout.setBackgroundResource(R.drawable.textfield_bg_lite);
			imgSalesDateImg.setImageResource(R.drawable.calendar_iconlight);
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
			 
			 	
		}

	
	
	
	
	
	
	}
	
	@Override
	public boolean onBackPressed(int callbackCode) {
		mActivity.onBackPressedCallBack(callbackCode);
		return true;
	}
}