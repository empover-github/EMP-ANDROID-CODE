package com.activitytrack.masterdtos;

import com.activitytrack.dtos.DTO;

public class SeasonCalendarDTO implements DTO{

	private long seasonId;
	private String seasonName;
	private long cropId;
	private long activityId;
	private String seasonStartDate;
	private String seasonEndDate;
	private int conductesYear;
	private String cropName;
	private String activityName;
	private long id;

	public long getSeasonId() {
		return seasonId;
	}
	public void setSeasonId(long id) {
		this.seasonId = id;
	}
	public String getSeasonName() {
		return seasonName;
	}
	public void setSeasonName(String name) {
		this.seasonName = name;
	}
	public long getCropId() {
		return cropId;
	}
	public void setCropId(long cropId) {
		this.cropId = cropId;
	}
	public long getActivityId() {
		return activityId;
	}
	public void setActivityId(long activityId) {
		this.activityId = activityId;
	}
	public String getSeasonStartDate() {
		return seasonStartDate;
	}
	public void setSeasonStartDate(String seasonStartDate) {
		this.seasonStartDate = seasonStartDate;
	}
	public String getSeasonEndDate() {
		return seasonEndDate;
	}
	public void setSeasonEndDate(String seasonEndDate) {
		this.seasonEndDate = seasonEndDate;
	}
	public int getConductesYear() {
		return conductesYear;
	}
	public void setConductesYear(int conductesYear) {
		this.conductesYear = conductesYear;
	}
	public String getCropName() {
		return cropName;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public long getSeasonCalendarId() {
		return id;
	}
	public void setSeasonCalendarId(long seasonCalendarId) {
		this.id = seasonCalendarId;
	}

}
