package com.activitytrack.masterdaos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdtos.TargetDemandOSADTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class TargetDemandOSADAO  implements MasterDAO{

	
	
	private final String TAG = "TargetDmnd";
    private static TargetDemandOSADAO targetDemandDAO;

	
    public static TargetDemandOSADAO getInstance()
    {
        if (targetDemandDAO == null)
        {
        	targetDemandDAO = new TargetDemandOSADAO();
        }
        
        return targetDemandDAO;
    }

    /**
     * delete the Data
     */

	
	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) 
	
	{
		 
		return false;
	}

	
	 /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
	
	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			{ 
		    	List<DTO> targetDemandInfo = new ArrayList<DTO>();
		        Cursor cursor = null;
		        try
		        {
		        	 
		        	
		            cursor = dbObject.rawQuery("SELECT * FROM TARGET_DEMAND_OSA  where"+columnName+"='"+columnValue+"' ", null);
		            if (cursor.getCount() > 0)
		            {
		                cursor.moveToFirst();
		                do
		                { 
		                	/*TARGET_DEMAND_OSA
		               
		                	 id 
		    				 seasonId  
		    				 cropId 
		    				 hybridId 
		    				 targetActivity  
		    				 targetFarmer 
		    				 date 
		    			     activity
		    			     */
		                	
		                
		                	
		                	TargetDemandOSADTO dto = new TargetDemandOSADTO();                    
		                	
		                	dto.setId(cursor.getLong(0));
		                	dto.setSeasonId(cursor.getLong(1));
		                	dto.setHybridId(cursor.getLong(2));
		                	dto.setTargetActivity(cursor.getLong(3));
		                	dto.setTargetFarmer(cursor.getLong(4));
		                	dto.setDate(cursor.getString(5));
		                    
		                    targetDemandInfo.add(dto);
		                } while (cursor.moveToNext());
		            }
		        } catch (Exception e)
		        {
					ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		        } finally
		        {
		            if (cursor != null && !cursor.isClosed())
		            {
		                cursor.close();
		            }
		            dbObject.close();
		        }

		        return targetDemandInfo;
		    }
		    
		 
	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)  
	{
	List<DTO> targetDemandInfo = new ArrayList<DTO>();
		        Cursor cursor = null;
		        try
		        {
		        	 cursor = dbObject.rawQuery("SELECT * FROM  TARGET_DEMAND_OSA", null);
		 	        if (cursor.getCount() > 0)
		 	        {
		 	            cursor.moveToFirst();
		 	            do
		 	            {
                     
		 	            	TargetDemandOSADTO dto = new TargetDemandOSADTO();                    
		                	
		                	dto.setId(cursor.getLong(0));
		                	dto.setSeasonId(cursor.getLong(1));
		                	dto.setHybridId(cursor.getLong(2));
		                	dto.setTargetActivity(cursor.getLong(3));
		                	dto.setTargetFarmer(cursor.getLong(4));
		                	dto.setDate(cursor.getString(5));
		                    
		                    targetDemandInfo.add(dto);
	
		 } while (cursor.moveToNext());
	                }
		          } catch (Exception e)
					{
						ATBuildLog.e(TAG + "getRecords()", e.getMessage());
					} finally
					{
					   if (cursor != null && !cursor.isClosed())
					   {
					       cursor.close();
					   }
					   dbObject.close();
					}
					
					return targetDemandInfo;
					}


 
	  
    /**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
	 
	
	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		
		try
        {            
        	TargetDemandOSADTO  dto = (TargetDemandOSADTO) dtoObject;

            ContentValues cValues = new ContentValues();
           
            
            /*TARGET_DEMAND_OSA
            
       	      id 
			 seasonId  
			 cropId 
			 hybridId 
			 targetActivity  
			 targetFarmer 
			 date 
		     activity
		     */
       	cValues.put("id",dto.getId());
       	cValues.put("seasonId",dto.getSeasonId());
       	cValues.put("cropId",dto.getCropId());
       	cValues.put("hybridId",dto.getHybridId());
       	cValues.put("targetActivity",dto.getTargetActivity());
       	cValues.put("targetFarmer",dto.getTargetFarmer());
       	cValues.put("date",dto.getDate());
		 
        dbObject.insert("TARGET_DEMAND_OSA", null, cValues);
        
        return true;
    } catch (SQLException e)
    {
		ATBuildLog.e(TAG + "insert()", e.getMessage());
        return false;
    } finally
    {
        dbObject.close();
    }

}

	/**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
  
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		
		try
        {            
        	TargetDemandOSADTO  dto = (TargetDemandOSADTO  ) dtoObject;

            ContentValues cValues = new ContentValues();
        	
            cValues.put("seasonId",dto.getSeasonId());
        	cValues.put("cropId",dto.getCropId());
           	cValues.put("hybridId",dto.getHybridId());
           	cValues.put("targetActivity",dto.getTargetActivity());
           	cValues.put("targetFarmer",dto.getTargetFarmer());
           	cValues.put("date",dto.getDate());
    		
            dbObject.update("TARGET_DEMAND_OSA", cValues, "id='" +dto.getId()+"' ", null);
            return true;
        } catch (SQLException e)
        {
			ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally
        {
            dbObject.close();
        }
        return false;
    }
	/**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM TARGET_DEMAND_OSA").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

	public List<Integer> getTotalTarget(long cropId, SQLiteDatabase dbObject)
	{
	List<Integer> targetDemandInfo = new ArrayList<Integer>();
    Cursor cursor = null;
    try
    {
    	 cursor = dbObject.rawQuery("select sum(targetActivity), sum(targetFarmer) from TARGET_DEMAND_OSA where cropId = '"+cropId+"'", null);
        if (cursor.getCount() > 0)
        {
            cursor.moveToFirst();
            targetDemandInfo.add(cursor.getInt(0));
            targetDemandInfo.add(cursor.getInt(1));
        }
      } catch (Exception e)
	{
		ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	} finally
	{
	   if (cursor != null && !cursor.isClosed())
	   {
	       cursor.close();
	   }
	   dbObject.close();
	}
	
	return targetDemandInfo;
	}
	
	public List<Integer> getTillDateTarget(long cropId, String date, SQLiteDatabase dbObject)
	{
	List<Integer> targetDemandInfo = new ArrayList<Integer>();
    Cursor cursor = null;
    try
    {
    	 cursor = dbObject.rawQuery("select sum(targetActivity), sum(targetFarmer) from TARGET_DEMAND_OSA WHERE cropId = '"+cropId+"' AND date <= '"+date+"'", null);
        if (cursor.getCount() > 0)
        {
            cursor.moveToFirst();
            targetDemandInfo.add(cursor.getInt(0));
            targetDemandInfo.add(cursor.getInt(1));
        }
      } catch (Exception e)
	{
		ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	} finally
	{
	   if (cursor != null && !cursor.isClosed())
	   {
	       cursor.close();
	   }
	   dbObject.close();
	}
	
	return targetDemandInfo;
	}
	
	public List<Integer> getTotalTargetByHybrid(String hybridId, SQLiteDatabase dbObject)  
	{
		List<Integer> targetDemandInfo = new ArrayList<Integer>();
	    Cursor cursor = null;
	    try
	    {
	    	 cursor = dbObject.rawQuery("select sum(targetActivity), sum(targetFarmer) from TARGET_DEMAND_OSA where hybridId = '"+hybridId+"'", null);
	        if (cursor.getCount() > 0)
	        {
	            cursor.moveToFirst();
	            targetDemandInfo.add(cursor.getInt(0));
	            targetDemandInfo.add(cursor.getInt(1));
	        }
	      } catch (Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		} finally
		{
		   if (cursor != null && !cursor.isClosed())
		   {
		       cursor.close();
		   }
		   dbObject.close();
		}
		
		return targetDemandInfo;
	}
}
