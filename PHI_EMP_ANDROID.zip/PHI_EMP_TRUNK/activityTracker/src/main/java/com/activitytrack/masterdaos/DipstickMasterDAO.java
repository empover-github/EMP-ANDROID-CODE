package com.activitytrack.masterdaos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.daos.DAO;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.DipstickDTO;
import com.activitytrack.models.DipstickDashboardCounts;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class DipstickMasterDAO implements DAO{

	private final String TAG = "PDAActivityDAO";
    private static DipstickMasterDAO dipstickDAO;

    public static DipstickMasterDAO getInstance()
    {
        if (dipstickDAO == null)
        {
        	dipstickDAO = new DipstickMasterDAO();
        }
        
        return dipstickDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject)
    {
        return false;
    }
    
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
    	return null;
    }

    /**
     * Gets the record from the database based on the value passed
     * 

     * @param mobileNo
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
    public DipstickDTO getRecordInfoForPhase(String phase, String year, long seasonId, long cropId, String mobileNo, SQLiteDatabase dbObject)
    {
        DipstickDTO dto = null;
        Cursor cursor = null;
        try
        {
        	cursor = dbObject.rawQuery("SELECT * FROM DIPSTICK_MASTER where activityType='"+phase+"' and year='"+year+"' and seasonId='"+seasonId+"' and cropId='"+cropId+"' and farmerNumber='"+mobileNo+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                	/*DIPSTICK_MASTER
        			id 
        			activityType
        			year
        			seasonId
        			cropId
        			isSampleIssued
        			hybridId
        			farmerName
        			farmerNumber
        			cropAcres
        			hybridCropAcres
        			otherCropAcres
        			pioneerHyb1
        			pioneerHyb2
        			competitorHybrid1
        			competitorHybrid2
        			competitorHybrid3
        			competitorHybrid4
        			competitorHybrid5
        			date
        			regionId
        			location
        			isSync
        			uploadedDate
        			pioneerHyb1Name
        			pioneerHyb2Name
        			userType
        			f2Acreages*/
                	dto = new DipstickDTO();
                    
                	dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setActivityType(cursor.getString(cursor.getColumnIndex("activityType")));
                    dto.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setIsSampleIssued(cursor.getInt(cursor.getColumnIndex("isSampleIssued")) > 0 ? true : false);
                    dto.setHybridId(cursor.getLong(cursor.getColumnIndex("hybridId")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setFarmerNumber(cursor.getString(cursor.getColumnIndex("farmerNumber")));
                    dto.setCropAcres(cursor.getFloat(cursor.getColumnIndex("cropAcres")));
                    dto.setHybridCropAcres(cursor.getFloat(cursor.getColumnIndex("hybridCropAcres")));
                    dto.setOtherCropAcres(cursor.getFloat(cursor.getColumnIndex("otherCropAcres")));
                    dto.setPioneerHyb1(cursor.getFloat(cursor.getColumnIndex("pioneerHyb1")));
                    dto.setPioneerHyb2(cursor.getFloat(cursor.getColumnIndex("pioneerHyb2")));
                    dto.setPioneerHyb3(cursor.getFloat(cursor.getColumnIndex("pioneerHyb3")));
                    dto.setPioneerHyb4(cursor.getFloat(cursor.getColumnIndex("pioneerHyb4")));
                    dto.setCompetitorHybrid1(cursor.getFloat(cursor.getColumnIndex("competitorHybrid1")));
                    dto.setCompetitorHybrid2(cursor.getFloat(cursor.getColumnIndex("competitorHybrid2")));
                    dto.setCompetitorHybrid3(cursor.getFloat(cursor.getColumnIndex("competitorHybrid3")));
                    dto.setCompetitorHybrid4(cursor.getFloat(cursor.getColumnIndex("competitorHybrid4")));
                    dto.setCompetitorHybrid5(cursor.getFloat(cursor.getColumnIndex("competitorHybrid5")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setRegionId(cursor.getLong(cursor.getColumnIndex("regionId")));
                    dto.setLocation(cursor.getString(cursor.getColumnIndex("location")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setUploadedDate(cursor.getString(cursor.getColumnIndex("uploadedDate")));
                    dto.setPioneerHyb1Name(cursor.getString(cursor.getColumnIndex("pioneerHyb1Name")));
                    dto.setPioneerHyb2Name(cursor.getString(cursor.getColumnIndex("pioneerHyb2Name")));
                    dto.setPioneerHyb3Name(cursor.getString(cursor.getColumnIndex("pioneerHyb3Name")));
                    dto.setPioneerHyb4Name(cursor.getString(cursor.getColumnIndex("pioneerHyb4Name")));
                    dto.setCompetitorHybrid1Name(cursor.getString(cursor.getColumnIndex("competitorHybrid1Name")));
                    dto.setCompetitorHybrid2Name(cursor.getString(cursor.getColumnIndex("competitorHybrid2Name")));
                    dto.setCompetitorHybrid3Name(cursor.getString(cursor.getColumnIndex("competitorHybrid3Name")));
                    dto.setCompetitorHybrid4Name(cursor.getString(cursor.getColumnIndex("competitorHybrid4Name")));
                    dto.setCompetitorHybrid5Name(cursor.getString(cursor.getColumnIndex("competitorHybrid5Name")));
                    dto.setOtherCrop1(cursor.getLong(cursor.getColumnIndex("otherCrop1")));
                    dto.setOtherCrop2(cursor.getLong(cursor.getColumnIndex("otherCrop2")));
                    dto.setOtherCropArea1(cursor.getDouble(cursor.getColumnIndex("otherCropArea1")));
                    dto.setOtherCropArea2(cursor.getDouble(cursor.getColumnIndex("otherCropArea2")));
                    dto.setUserType(cursor.getString(cursor.getColumnIndex("userType")));
                    dto.setF2Acreages(cursor.getFloat(cursor.getColumnIndex("f2Acreages")));
                    dto.setSeedSettingIssue(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue")));

                    dto.setSeedSettingIssue1(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue1")));
                    dto.setSeedSettingIssue2(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue2")));
                    dto.setSeedSettingIssue3(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue3")));
                    dto.setSeedSettingIssue4(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue4")));

                    dto.setCompetitorHybrid1SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid1SeedSettingIssue")));
                    dto.setCompetitorHybrid2SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid2SeedSettingIssue")));
                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
           /* ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return dto;
    }
    
    public List<Long> getIdsByDate(String columnName, String columnValue, SQLiteDatabase dbObject)
    {
        List<Long> idsList = new ArrayList<Long>();
        Cursor cursor = null;
        try
        {
        	if(!(columnName != null && columnName.length() > 0))
        		columnName = "uploadedDate";
        	
            cursor = dbObject.rawQuery("SELECT id FROM DIPSTICK_MASTER where "+columnName+" < '"+columnValue+"' and isSync = '0' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                    idsList.add(cursor.getLong(0));
                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
          /*  ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return idsList;
    }
    

    /**
     * Gets all the records from the database
     *
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject)
    {
        List<DTO> pdaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT * FROM DIPSTICK_MASTER ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                	DipstickDTO dto = new DipstickDTO();
                    
                	dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setActivityType(cursor.getString(cursor.getColumnIndex("activityType")));
                    dto.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setIsSampleIssued(cursor.getInt(cursor.getColumnIndex("isSampleIssued")) > 0 ? true : false);
                    dto.setHybridId(cursor.getLong(cursor.getColumnIndex("hybridId")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setFarmerNumber(cursor.getString(cursor.getColumnIndex("farmerNumber")));
                    dto.setCropAcres(cursor.getFloat(cursor.getColumnIndex("cropAcres")));
                    dto.setHybridCropAcres(cursor.getFloat(cursor.getColumnIndex("hybridCropAcres")));
                    dto.setOtherCropAcres(cursor.getFloat(cursor.getColumnIndex("otherCropAcres")));
                    dto.setPioneerHyb1(cursor.getFloat(cursor.getColumnIndex("pioneerHyb1")));
                    dto.setPioneerHyb2(cursor.getFloat(cursor.getColumnIndex("pioneerHyb2")));
                    dto.setPioneerHyb3(cursor.getFloat(cursor.getColumnIndex("pioneerHyb3")));
                    dto.setPioneerHyb4(cursor.getFloat(cursor.getColumnIndex("pioneerHyb4")));
                    dto.setCompetitorHybrid1(cursor.getFloat(cursor.getColumnIndex("competitorHybrid1")));
                    dto.setCompetitorHybrid2(cursor.getFloat(cursor.getColumnIndex("competitorHybrid2")));
                    dto.setCompetitorHybrid3(cursor.getFloat(cursor.getColumnIndex("competitorHybrid3")));
                    dto.setCompetitorHybrid4(cursor.getFloat(cursor.getColumnIndex("competitorHybrid4")));
                    dto.setCompetitorHybrid5(cursor.getFloat(cursor.getColumnIndex("competitorHybrid5")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setRegionId(cursor.getLong(cursor.getColumnIndex("regionId")));
                    dto.setLocation(cursor.getString(cursor.getColumnIndex("location")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setUploadedDate(cursor.getString(cursor.getColumnIndex("uploadedDate")));
                    dto.setPioneerHyb1Name(cursor.getString(cursor.getColumnIndex("pioneerHyb1Name")));
                    dto.setPioneerHyb2Name(cursor.getString(cursor.getColumnIndex("pioneerHyb2Name")));
                    dto.setPioneerHyb3Name(cursor.getString(cursor.getColumnIndex("pioneerHyb3Name")));
                    dto.setPioneerHyb4Name(cursor.getString(cursor.getColumnIndex("pioneerHyb4Name")));
                    dto.setCompetitorHybrid1Name(cursor.getString(cursor.getColumnIndex("competitorHybrid1Name")));
                    dto.setCompetitorHybrid2Name(cursor.getString(cursor.getColumnIndex("competitorHybrid2Name")));
                    dto.setCompetitorHybrid3Name(cursor.getString(cursor.getColumnIndex("competitorHybrid3Name")));
                    dto.setCompetitorHybrid4Name(cursor.getString(cursor.getColumnIndex("competitorHybrid4Name")));
                    dto.setCompetitorHybrid5Name(cursor.getString(cursor.getColumnIndex("competitorHybrid5Name")));
                    dto.setOtherCrop1(cursor.getLong(cursor.getColumnIndex("otherCrop1")));
                    dto.setOtherCrop2(cursor.getLong(cursor.getColumnIndex("otherCrop2")));
                    dto.setOtherCropArea1(cursor.getDouble(cursor.getColumnIndex("otherCropArea1")));
                    dto.setOtherCropArea2(cursor.getDouble(cursor.getColumnIndex("otherCropArea2")));
                    dto.setUserType(cursor.getString(cursor.getColumnIndex("userType")));
                    dto.setF2Acreages(cursor.getFloat(cursor.getColumnIndex("f2Acreages")));
                    dto.setSeedSettingIssue(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue")));

                    dto.setSeedSettingIssue1(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue1")));
                    dto.setSeedSettingIssue2(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue2")));
                    dto.setSeedSettingIssue3(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue3")));
                    dto.setSeedSettingIssue4(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue4")));

                    dto.setCompetitorHybrid1SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid1SeedSettingIssue")));
                    dto.setCompetitorHybrid2SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid2SeedSettingIssue")));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            } 
        } catch (Exception e)
        {
           /* ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }
    
    public List<DipstickDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject)
    {
        List<DipstickDTO> pdaActivityInfo = new ArrayList<DipstickDTO>();
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT * FROM DIPSTICK_MASTER where isSync = 1", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                	DipstickDTO dto = new DipstickDTO();
                    
                	dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setActivityType(cursor.getString(cursor.getColumnIndex("activityType")));
                    dto.setYear(cursor.getInt(cursor.getColumnIndex("year")));
                    dto.setSeasonId(cursor.getLong(cursor.getColumnIndex("seasonId")));
                    dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setIsSampleIssued(cursor.getInt(cursor.getColumnIndex("isSampleIssued")) > 0);
                    dto.setHybridId(cursor.getLong(cursor.getColumnIndex("hybridId")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setFarmerNumber(cursor.getString(cursor.getColumnIndex("farmerNumber")));
                    dto.setCropAcres(cursor.getFloat(cursor.getColumnIndex("cropAcres")));
                    dto.setHybridCropAcres(cursor.getFloat(cursor.getColumnIndex("hybridCropAcres")));
                    dto.setOtherCropAcres(cursor.getFloat(cursor.getColumnIndex("otherCropAcres")));
                    dto.setPioneerHyb1(cursor.getFloat(cursor.getColumnIndex("pioneerHyb1")));
                    dto.setPioneerHyb2(cursor.getFloat(cursor.getColumnIndex("pioneerHyb2")));
                    dto.setPioneerHyb3(cursor.getFloat(cursor.getColumnIndex("pioneerHyb3")));
                    dto.setPioneerHyb4(cursor.getFloat(cursor.getColumnIndex("pioneerHyb4")));
                    dto.setCompetitorHybrid1(cursor.getFloat(cursor.getColumnIndex("competitorHybrid1")));
                    dto.setCompetitorHybrid2(cursor.getFloat(cursor.getColumnIndex("competitorHybrid2")));
                    dto.setCompetitorHybrid3(cursor.getFloat(cursor.getColumnIndex("competitorHybrid3")));
                    dto.setCompetitorHybrid4(cursor.getFloat(cursor.getColumnIndex("competitorHybrid4")));
                    dto.setCompetitorHybrid5(cursor.getFloat(cursor.getColumnIndex("competitorHybrid5")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setRegionId(cursor.getLong(cursor.getColumnIndex("regionId")));
                    dto.setLocation(cursor.getString(cursor.getColumnIndex("location")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setUploadedDate(cursor.getString(cursor.getColumnIndex("uploadedDate")));
                    dto.setPioneerHyb1Name(cursor.getString(cursor.getColumnIndex("pioneerHyb1Name")));
                    dto.setPioneerHyb2Name(cursor.getString(cursor.getColumnIndex("pioneerHyb2Name")));
                    dto.setPioneerHyb3Name(cursor.getString(cursor.getColumnIndex("pioneerHyb3Name")));
                    dto.setPioneerHyb4Name(cursor.getString(cursor.getColumnIndex("pioneerHyb4Name")));
                    dto.setCompetitorHybrid1Name(cursor.getString(cursor.getColumnIndex("competitorHybrid1Name")));
                    dto.setCompetitorHybrid2Name(cursor.getString(cursor.getColumnIndex("competitorHybrid2Name")));
                    dto.setCompetitorHybrid3Name(cursor.getString(cursor.getColumnIndex("competitorHybrid3Name")));
                    dto.setCompetitorHybrid4Name(cursor.getString(cursor.getColumnIndex("competitorHybrid4Name")));
                    dto.setCompetitorHybrid5Name(cursor.getString(cursor.getColumnIndex("competitorHybrid5Name")));
                    dto.setOtherCrop1(cursor.getLong(cursor.getColumnIndex("otherCrop1")));
                    dto.setOtherCrop2(cursor.getLong(cursor.getColumnIndex("otherCrop2")));
                    dto.setOtherCropArea1(cursor.getDouble(cursor.getColumnIndex("otherCropArea1")));
                    dto.setOtherCropArea2(cursor.getDouble(cursor.getColumnIndex("otherCropArea2")));
                    dto.setUserType(cursor.getString(cursor.getColumnIndex("userType")));
                    dto.setF2Acreages(cursor.getFloat(cursor.getColumnIndex("f2Acreages")));
                    dto.setSeedSettingIssue(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue")));

                    dto.setSeedSettingIssue1(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue1")));
                    dto.setSeedSettingIssue2(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue2")));
                    dto.setSeedSettingIssue3(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue3")));
                    dto.setSeedSettingIssue4(cursor.getFloat(cursor.getColumnIndex("seedSettingIssue4")));

                    dto.setCompetitorHybrid1SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid1SeedSettingIssue")));
                    dto.setCompetitorHybrid2SeedSettingIssue(cursor.getString(cursor.getColumnIndex("competitorHybrid2SeedSettingIssue")));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            } 
        } catch (Exception e)
        {
           /* ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    /**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
    	
    	return false;
    }
    
    
    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject)
    {
        try
        {            
        	DipstickDTO dto = (DipstickDTO) dtoObject;

            ContentValues cValues = new ContentValues();
            /*DIPSTICK_MASTER
			id 
			activityType
			year
			seasonId
			cropId
			isSampleIssued
			hybridId
			farmerName
			farmerNumber
			cropAcres
			hybridCropAcres
			otherCropAcres
			pioneerHyb1
			pioneerHyb2
			competitorHybrid1
			competitorHybrid2
			competitorHybrid3
			competitorHybrid4
			competitorHybrid5
			date
			regionId
			location
			isSync
			uploadedDate
			pioneerHyb1Name
			pioneerHyb2Name */
            
            cValues.put("activityType", dto.getActivityType());
            cValues.put("year", dto.getYear());
            cValues.put("seasonId", dto.getSeasonId());
            cValues.put("cropId", dto.getCropId());
            cValues.put("isSampleIssued", dto.getIsSampleIssued());
            cValues.put("hybridId", dto.getHybridId());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("farmerNumber", dto.getFarmerNumber());
            cValues.put("cropAcres", dto.getCropAcres());
            cValues.put("hybridCropAcres", dto.getHybridCropAcres());
            cValues.put("otherCropAcres", dto.getOtherCropAcres());
            cValues.put("pioneerHyb1", dto.getPioneerHyb1());
            cValues.put("pioneerHyb2",dto.getPioneerHyb2());
            cValues.put("pioneerHyb3", dto.getPioneerHyb3());
            cValues.put("pioneerHyb4",dto.getPioneerHyb4());
            cValues.put("competitorHybrid1",dto.getCompetitorHybrid1());
            cValues.put("competitorHybrid2",dto.getCompetitorHybrid2());
            cValues.put("competitorHybrid3",dto.getCompetitorHybrid3());
            cValues.put("competitorHybrid4",dto.getCompetitorHybrid4());
            cValues.put("competitorHybrid5",dto.getCompetitorHybrid5());
            cValues.put("date",dto.getDate());
            cValues.put("regionId",dto.getRegionId());
            cValues.put("location",dto.getLocation());
            cValues.put("isSync",dto.getIsSync());
            cValues.put("uploadedDate",dto.getUploadedDate());
            cValues.put("pioneerHyb1Name",dto.getPioneerHyb1Name());
            cValues.put("pioneerHyb2Name",dto.getPioneerHyb2Name());
            cValues.put("pioneerHyb3Name",dto.getPioneerHyb3Name());
            cValues.put("pioneerHyb4Name",dto.getPioneerHyb4Name());
            cValues.put("competitorHybrid1Name",dto.getCompetitorHybrid1Name());
            cValues.put("competitorHybrid2Name",dto.getCompetitorHybrid2Name());
            cValues.put("competitorHybrid3Name",dto.getCompetitorHybrid3Name());
            cValues.put("competitorHybrid4Name",dto.getCompetitorHybrid4Name());
            cValues.put("competitorHybrid5Name",dto.getCompetitorHybrid5Name());
            cValues.put("otherCrop1", dto.getOtherCrop1());
            cValues.put("otherCrop2",dto.getOtherCrop2());
            cValues.put("otherCropArea1", dto.getOtherCropArea1());
            cValues.put("otherCropArea2", dto.getOtherCropArea2());
            cValues.put("userType",dto.getUserType());
            cValues.put("f2Acreages",dto.getF2Acreages());
            cValues.put("seedSettingIssue", dto.getSeedSettingIssue());

            cValues.put("seedSettingIssue1", dto.getSeedSettingIssue1());
            cValues.put("seedSettingIssue2", dto.getSeedSettingIssue2());
            cValues.put("seedSettingIssue3", dto.getSeedSettingIssue3());
            cValues.put("seedSettingIssue4", dto.getSeedSettingIssue4());

            cValues.put("competitorHybrid1SeedSettingIssue", dto.getCompetitorHybrid1SeedSettingIssue());
            cValues.put("competitorHybrid2SeedSettingIssue", dto.getCompetitorHybrid2SeedSettingIssue());

            long insertedRow = dbObject.insert("DIPSTICK_MASTER", null, cValues);
            if(insertedRow > 0){
	            return insertedRow;
            }
            
            return -1;
        } catch (SQLException e)
        {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally
        {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject)
    {

        return false;
    }

    /**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM DIPSTICK_MASTER").execute();
            return true;
        } catch (Exception e)
        {
           /* ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());*/
        }
        return false;
    }
    public boolean deleteTableDataById(Long id,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM DIPSTICK_MASTER where id = '"+id+"'").execute();
            return true;
        } catch (Exception e)
        {
           /* ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());*/
        }
        return false;
    }
    
    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("delete from DIPSTICK_MASTER where id='"+id+"'");
			return true;
		}catch(Exception e)
		{
            ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally
		
		{
		
		dbObject.close();
		
		}
		return false;
	}
    public boolean deleteDataByDate(String date, SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("delete from  DIPSTICK_MASTER  where uploadedDate < '"+date+"' and isSync = '0'");
			return true;
		}catch(Exception e)
		{
            ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally
		
		{
		
		dbObject.close();
		
		}
		return false;
	}

    public DipstickDashboardCounts getDipstickDashboardCounts(String phase, String year, long seasonId, SQLiteDatabase dbObject) {
        DipstickDashboardCounts dto = null;
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT count(activityType), sum(cropAcres), sum(hybridCropAcres), sum(otherCropAcres), sum(pioneerHyb1), sum(pioneerHyb2) FROM DIPSTICK_MASTER where activityType='"+phase+"' and year='"+year+"' and seasonId='"+seasonId+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                    dto = new DipstickDashboardCounts();

                    dto.setNoOfFarmers(cursor.getLong(0));
                    long cropAcres = cursor.getLong(1);
                    long hybridCropAcres = cursor.getLong(2);
                    long otherCropAcres = cursor.getLong(3);
                    dto.setTotalNoOfHybridAcres(hybridCropAcres);
                    dto.setTotalNoOfAcres(cropAcres+hybridCropAcres+otherCropAcres);
                    long totalPHIAcres = cursor.getLong(4) + cursor.getLong(5);
                    dto.setTotalPioneerHybridAcres(totalPHIAcres);


                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
          /*  ATBuildLog.e(TAG + "getRecords()", e.getMessage());*/
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return dto;
    }

    public List<Integer> getIssuedList(String year, long seasonId, long cropId, int isSampled, String phase, SQLiteDatabase dbObject)
    {
        List<Integer> targetDemandInfo = new ArrayList<Integer>();
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("select sum(pioneerHyb1), sum(pioneerHyb2) from DIPSTICK_MASTER where year='"+year+"' and seasonId='"+seasonId+"' and cropId='"+cropId+"' and isSampleIssued = '"+isSampled+"'and activityType = '"+phase+"'", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                long totalPHIAcres = cursor.getLong(0) + cursor.getLong(1);
                targetDemandInfo.add((int)totalPHIAcres);
//                targetDemandInfo.add(cursor.getInt(1));
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return targetDemandInfo;
    }

}
