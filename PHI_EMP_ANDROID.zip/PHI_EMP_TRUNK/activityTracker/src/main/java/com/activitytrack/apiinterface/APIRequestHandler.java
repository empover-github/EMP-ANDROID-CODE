package com.activitytrack.apiinterface;

import android.app.Dialog;

import com.activitytrack.activity.ATMainActivity;
import com.activitytrack.dtos.FarmerSegmentationNestleResponse;
import com.activitytrack.dtos.FarmerSegmentationRequestDTO;
import com.activitytrack.dtos.FarmerSegmentationResponse;
import com.activitytrack.dtos.OTPFarmerSegmentationResponse;
import com.activitytrack.dtos.OTP_FS_Response;
import com.activitytrack.dtos.UpLoadPravaktaFileDTO;
import com.activitytrack.masterdtos.UploadResponse;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.squareup.okhttp.OkHttpClient;

import java.util.concurrent.TimeUnit;

import retrofit.Callback;
import retrofit.RequestInterceptor;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.OkClient;
import retrofit.client.Response;
import retrofit.mime.TypedFile;

import static com.activitytrack.utility.Utility.showProgressDialog;

public class APIRequestHandler {
    RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(
            MyConstants.AppURL).build();

    //private final static String USER_NAME = "admin", PASSWORD = "admin";

    // APICommonInterface getInterface() = restAdapter
    // .create(APICommonInterface.class);

    // private static final APIRequestHandler mInstance = new
    // APIRequestHandler();

    private static APICommonInterface mInterfaces = null;// = createService();
    private static final APIRequestHandler instance = new APIRequestHandler();

    public static APIRequestHandler getInstance() {
        return instance;
    }

    private APIRequestHandler() {

    }

    public void resetAPIInterface(){
        mInterfaces = null;
    }

    private APICommonInterface getInterface(){
        if(mInterfaces == null)
            mInterfaces = createService();
        return mInterfaces;
    }

    /**
     * This Constructor is to call Crop Diagnosis service
     *
     * @return
     */
    private static APICommonInterface createService() {

        final OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.setWriteTimeout(5, TimeUnit.MINUTES);
        okHttpClient.setConnectTimeout(5, TimeUnit.MINUTES);
        okHttpClient.setReadTimeout(5, TimeUnit.MINUTES);

        okHttpClient.setRetryOnConnectionFailure(true);
        // set endpoint url and use OkHTTP as HTTP client
        RestAdapter.Builder builder = new RestAdapter.Builder()
                .setEndpoint(MyConstants.AppURL).setClient(new OkClient(okHttpClient));

        builder.setRequestInterceptor(new RequestInterceptor() {
            @Override
            public void intercept(RequestFacade request) {
                request.addHeader("Accept", "application/json");
            }
        });

        RestAdapter adapter = builder.build();

        return adapter.create(APICommonInterface.class);
    }

    public void uploadImage(UpLoadPravaktaFileDTO dto, TypedFile imageTypedFile, final ComonInterface callBack) {

        createService().uploadImage(dto.getServerId(), dto.getMobileId(), dto.getType(), imageTypedFile, new Callback<UploadResponse>() {

            @Override
            public void success(UploadResponse commonResEntity, Response response) {
                if (commonResEntity != null) {
                    callBack.onRequestSuccess(commonResEntity);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                callBack.onRequestFailure(error);
            }
        });
    }

    public void uploadImageVillageProfSurvey(UpLoadPravaktaFileDTO dto, TypedFile imageTypedFile, final ComonInterface callBack) {

        createService().uploadImageVillageProfSurvey(dto.getServerId(), dto.getMobileId(), dto.getType(), imageTypedFile, new Callback<UploadResponse>() {

            @Override
            public void success(UploadResponse commonResEntity, Response response) {
                if (commonResEntity != null) {
                    callBack.onRequestSuccess(commonResEntity);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                callBack.onRequestFailure(error);
            }
        });
    }

 public void uploadImageFarmerSegmentation(UpLoadPravaktaFileDTO dto, TypedFile imageTypedFile, final ComonInterface callBack) {

        createService().uploadImageFarmerSegmentation(dto.getServerId(), dto.getMobileId(), dto.getType(), imageTypedFile, new Callback<UploadResponse>() {

            @Override
            public void success(UploadResponse commonResEntity, Response response) {
                if (commonResEntity != null) {
                    callBack.onRequestSuccess(commonResEntity);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                callBack.onRequestFailure(error);
            }
        });
    }

    public void getFarmerSegmentation(FarmerSegmentationRequestDTO jsonData, final ATMainActivity mActivity, final ComonInterface callback, boolean shouldShowPro) {
        final Dialog progress = showProgressDialog(mActivity, shouldShowPro);

        createService().getFarmerSegmentation(jsonData, new Callback<FarmerSegmentationResponse>() {

            @Override
            public void success(FarmerSegmentationResponse commonResEntity, Response response) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                if (commonResEntity != null) {
                    callback.onRequestSuccess(commonResEntity);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                callback.onRequestFailure(error);
            }
        });
    }

    public void getFarmerSegmentationNestle(FarmerSegmentationRequestDTO jsonData, final ATMainActivity mActivity, final ComonInterface callback, boolean shouldShowPro) {
        final Dialog progress = showProgressDialog(mActivity, shouldShowPro);

        createService().getFarmerSegmentationNestle(jsonData, new Callback<FarmerSegmentationNestleResponse>() {

            @Override
            public void success(FarmerSegmentationNestleResponse commonResEntity, Response response) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                if (commonResEntity != null) {
                    callback.onRequestSuccess(commonResEntity);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                callback.onRequestFailure(error);
            }
        });
    }
    public void getSubmitDetails(FarmerSegmentationRequestDTO jsonData, final ATMainActivity mActivity, final ComonInterface callback, boolean shouldShowPro) {
        final Dialog progress = showProgressDialog(mActivity, shouldShowPro);

        createService().getSubmitDetails(jsonData, new Callback<OTPFarmerSegmentationResponse>() {

            @Override
            public void success(OTPFarmerSegmentationResponse commonResEntity, Response response) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                if (commonResEntity != null) {
                    callback.onRequestSuccess(commonResEntity);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                callback.onRequestFailure(error);
            }
        });
    }

    public void getResendOTP(FarmerSegmentationRequestDTO jsonData, final ATMainActivity mActivity, final ComonInterface callback, boolean shouldShowPro) {
        final Dialog progress = showProgressDialog(mActivity, shouldShowPro);

        createService().getResendOTP(jsonData, new Callback<OTP_FS_Response>() {

            @Override
            public void success(OTP_FS_Response commonResEntity, Response response) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                if (commonResEntity != null) {
                    callback.onRequestSuccess(commonResEntity);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if (progress != null)
                    Utility.hideProgressDialog(progress);
                callback.onRequestFailure(error);
            }
        });
    }
}
