package com.activitytrack.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.activitytrack.asyncttasks.LoginAsync;
import com.activitytrack.daos.AgronomyActivityDAO;
import com.activitytrack.daos.DipstickDAO;
import com.activitytrack.daos.FarmerEntryDAO;
import com.activitytrack.daos.MdrFarmerDAO;
import com.activitytrack.daos.MdrProfileDAO;
import com.activitytrack.daos.NewMdrSurveyDAO;
import com.activitytrack.daos.OSAActivityDAO;
import com.activitytrack.daos.PDAActivityDAO;
import com.activitytrack.daos.PSAActivityDAO;
import com.activitytrack.daos.RetailerInfoDAO;
import com.activitytrack.daos.ThreeIDAO;
import com.activitytrack.daos.VillageProfileDAO;
import com.activitytrack.daos.YieldCalculatorCropsDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class ATLoginActivity extends Activity {

    private EditText usernameEdt;
	private EditText passwordEdt;
	private TextView txtPrivacyPolicy;
	//private TextView forgotPassword;

	private static final int REQUEST_SMS_READ_PERMISSION = 100;
	private static final int REQUEST_SMS_READ_PERMISSION_DENAIL = 101;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_login);

        Button submit = (Button) findViewById(R.id.login_submit);
		usernameEdt = (EditText) findViewById(R.id.login_userName);
		passwordEdt = (EditText) findViewById(R.id.login_password);
		//forgotPassword = (TextView) findViewById(R.id.login_forgotPassword);


		/*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M  *//*&& checkSMSReadPermission()*//*) {
			checkSMSReadPermission();
			// Dont Do anything
//			registerSMSReadBroadcast();
		}*/

		submit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(usernameEdt.getText().toString().trim().length() > 0){
						if(passwordEdt.getText().toString().trim().length() > 0){
							if(passwordEdt.getText().toString().trim().length() == 6){
								List<DTO> userList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(ATLoginActivity.this).getDBObject(0));
								if(userList != null && userList.size() > 0){
									MdrMasterDTO dto=(MdrMasterDTO) userList.get(0);
									if(usernameEdt.getText().toString().trim().equals(dto.getLoginId())){
										if(passwordEdt.getText().toString().trim().equals(dto.getPassword())){
											deleteLastThreeDaysData();
											navigateToHome();
											
										}else{
											Utility.showAlert(ATLoginActivity.this, "",getResources().getString(R.string.validPassword));
										}
									}else{
										Utility.showAlert(ATLoginActivity.this, "",getResources().getString(R.string.validUserName));
									}
								}else{
									if (Utility.networkAvailability(ATLoginActivity.this)) {
										JSONObject jsonObject = new JSONObject();
										try {
											jsonObject.put("loginId", usernameEdt.getText().toString().trim());
											jsonObject.put("password",passwordEdt.getText().toString().trim());	
											jsonObject.put("confirm",0);
											String deviceID = Utility.getDeviceId(ATLoginActivity.this);
											jsonObject.put("deviceId",deviceID);

											LoginAsync async = new LoginAsync(jsonObject.toString(),ATLoginActivity.this);
											async.execute(MyConstants.AppURL+MyConstants.SENDOTP_URL);
											
										} catch (JSONException e) {
											e.printStackTrace();
										}
			
									} else {
										Utility.showAlert(ATLoginActivity.this, "",getResources().getString(R.string.checkNetwork));
									}
								}
						}
						else {
							Utility.showAlert(ATLoginActivity.this, "",getResources().getString(R.string.passwordLen));
						}
								
					}else {
						Utility.showAlert(ATLoginActivity.this, "",getResources().getString(R.string.passwordEmpty));
					}
				}else{
					Utility.showAlert(ATLoginActivity.this, "", getResources().getString(R.string.userNameEmpty));
				}
			}
		});

		txtPrivacyPolicy = (TextView) findViewById(R.id.loginTxtPrivacyPolicy);
		txtPrivacyPolicy.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String url = MyConstants.PRIVACY_POLICY_WEB_URL;
				Intent openBrowser = new Intent(Intent.ACTION_VIEW);
				openBrowser.setData(Uri.parse(url));
				startActivity(openBrowser);
			}
		});
	}
	  
	public void Click(View v)
	{
		Intent intent = new Intent (this,ForgotPassWordActivity.class);
		startActivity(intent);
	}
	
	
	private void navigateToHome() {
		Intent intent = new Intent(ATLoginActivity.this, ATMainActivity.class);
		finish();
		startActivity(intent);
	}
	
	
	private void deleteLastThreeDaysData(){
		List<Long> pdaIdsList = PDAActivityDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		if(pdaIdsList != null && pdaIdsList.size() > 0){
			for(long id: pdaIdsList){
				PDAActivityDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			    RetailerInfoDAO.getInstance().deleteDataByActivityId(String.valueOf(id),MyConstants.ACTIVITY_PDA,DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
				FarmerEntryDAO.getInstance().deleteDataByActivityId(String.valueOf(id),MyConstants.ACTIVITY_PDA, DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
				YieldCalculatorCropsDAO.getInstance().deleteDataByActivityId(String.valueOf(id), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			}
		}
		
		List<Long> osaIdsList = OSAActivityDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		if(osaIdsList != null && osaIdsList.size() > 0){
			for(long id: osaIdsList){
				OSAActivityDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			    RetailerInfoDAO.getInstance().deleteDataByActivityId(String.valueOf(id),MyConstants.ACTIVITY_OSA,DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
				FarmerEntryDAO.getInstance().deleteDataByActivityId(String.valueOf(id),MyConstants.ACTIVITY_OSA, DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			}
		}
	
		List<Long> psaIdsList = PSAActivityDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		if(psaIdsList != null && psaIdsList.size() > 0){
			for(long id: psaIdsList){
				PSAActivityDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			    RetailerInfoDAO.getInstance().deleteDataByActivityId(String.valueOf(id),MyConstants.ACTIVITY_PSA,DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
				FarmerEntryDAO.getInstance().deleteDataByActivityId(String.valueOf(id),MyConstants.ACTIVITY_PSA, DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			}
		}
		//OSAActivityDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		//PSAActivityDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		
		List<Long> mdrprofileIdsList = MdrProfileDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		if(mdrprofileIdsList != null && mdrprofileIdsList.size() > 0){
			for(long id: mdrprofileIdsList){
				 MdrProfileDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
				MdrFarmerDAO.getInstance().deleteDataById(String.valueOf(id),MyConstants.ACTIVITY_MDR, DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			}
		}


		//TARA
		List<Long> villageProfileIdsList = VillageProfileDAO.getInstance().getIdsByDate("", Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		if(villageProfileIdsList != null && villageProfileIdsList.size() > 0){
			for(long id: villageProfileIdsList){
				VillageProfileDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
				MdrFarmerDAO.getInstance().deleteDataById(String.valueOf(id),MyConstants.ACTIVITY_MDR, DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
				// TARA
				NewMdrSurveyDAO.getInstance().deleteDataById(String.valueOf(id), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
			}
		}

		AgronomyActivityDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		ThreeIDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
		
		DipstickDAO.getInstance().deleteDataByDate(Utility.getDateBefore(MyConstants.DAYS_TO_DELETE_DATA), DBHandler.getInstance(ATLoginActivity.this).getDBObject(1));
	}



	/*
	private boolean checkSMSReadPermission() {
		// Here, thisActivity is the current activity
		if (ActivityCompat.checkSelfPermission(ATLoginActivity.this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {

			// Should we show an explanation?
			if (ActivityCompat.shouldShowRequestPermissionRationale(ATLoginActivity.this, Manifest.permission.READ_SMS)) {

				// Show an explanation to the user *asynchronously* -- don't block
				// this thread waiting for the user's response! After the user
				// sees the explanation, try again to request the permission.

				DialogManager.showConformPopup(ATLoginActivity.this, new DialogMangerCallback() {
					@Override
					public void onOkClick() {
						ActivityCompat.requestPermissions(ATLoginActivity.this, new String[]{Manifest.permission.READ_SMS}, REQUEST_SMS_READ_PERMISSION);
					}

					@Override
					public void onCancelClick(View view) {
					}
				}, "SMS Read Permission", "This app needs SMS read permission to read OTP.", getString(R.string.grant), getString(R.string.cancel));

			} else {

				// No explanation needed, we can request the permission.
				if (Utility.isFirstTime(ATLoginActivity.this)) {
					Utility.setFirstTime(false, ATLoginActivity.this);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
						requestPermissions(new String[]{Manifest.permission.READ_SMS}, REQUEST_SMS_READ_PERMISSION);
					}

					// MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
					// app-defined int constant. The callback method gets the
					// result of the request.
				} else {
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
						requestPermissions(new String[]{Manifest.permission.READ_SMS}, REQUEST_SMS_READ_PERMISSION_DENAIL);
					}
				}
			}
		} else {
			return true;
		}

		return false;
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
		switch (requestCode) {
			case REQUEST_SMS_READ_PERMISSION: {
				// If request is cancelled, the result arrays are empty.
				if (grantResults.length > 0
						&& grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					// permission was granted, yay! Do the
					// SMS-related task you need to do.
//					registerSMSReadBroadcast();
				} *//*else {
                    checkSMSReadPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }*//*
				return;
			}
			case REQUEST_SMS_READ_PERMISSION_DENAIL: {
				// Dont do anythung BCZ it is not necessary to have SMS_Read permission
			}
		}
	}*/
	
	
}
