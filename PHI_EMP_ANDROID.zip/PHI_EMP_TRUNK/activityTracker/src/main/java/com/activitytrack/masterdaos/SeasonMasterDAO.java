package com.activitytrack.masterdaos;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdtos.SeasonMasterDTO;
import com.activitytrack.utility.ATBuildLog;


public class SeasonMasterDAO implements MasterDAO
{
	private final String TAG = "SeasMaster";
    private static SeasonMasterDAO seasonMasterDAO;
   
    
    public static SeasonMasterDAO getInstance()
    {
        if (seasonMasterDAO == null)
        {
        	seasonMasterDAO = new SeasonMasterDAO();
        }
        
        return seasonMasterDAO;
    }

    /**
     * delete the Data
     */
  
	
	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}

    
	 /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject)
    {
        List<DTO> seasonMasterInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
        	
            cursor = dbObject.rawQuery("SELECT * FROM SEASONS where id='"+columnValue+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                    /*id
			     	name */
                	SeasonMasterDTO dto = new SeasonMasterDTO();
                    
                	dto.setId(cursor.getLong(0));
                	dto.setName(cursor.getString(1));
                    
                    seasonMasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return seasonMasterInfo;
    }
    

    /**
     * Gets all the records from the database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */


	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject) 
	
	
	{
		List<DTO> seasonMasterInfo = new ArrayList<DTO>();
       Cursor cursor = null;
    try
    {
        cursor = dbObject.rawQuery("SELECT * FROM SEASONS ", null);
        if (cursor.getCount() > 0)
        {
            cursor.moveToFirst();
            do
            {
            	SeasonMasterDTO dto = new SeasonMasterDTO();
                
            	dto.setId(cursor.getLong(0));
            	dto.setName(cursor.getString(1));
                
                seasonMasterInfo.add(dto);

            } while (cursor.moveToNext());
        } 
    } catch (Exception e)
    {
        ATBuildLog.e(TAG + "getRecords()", e.getMessage());
    } finally
    {
        if (cursor != null && !cursor.isClosed())
        {
            cursor.close();
        }
        dbObject.close();
    }

	 
		return seasonMasterInfo;
	}
	 
	 
	/**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
   	 
		 
 
    
    @Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
    {
    	 try
         {            
         	SeasonMasterDTO dto = (SeasonMasterDTO) dtoObject;

             ContentValues cValues = new ContentValues();
             /*id
 	     	name */
             
             cValues.put("id", dto.getId());
             cValues.put("name", dto.getName());

             dbObject.insert("SEASONS", null, cValues);
             return true;
         } catch (SQLException e)
         {
             ATBuildLog.e(TAG + "insert()", e.getMessage());
             return false;
         } finally
         {
             dbObject.close();
         }

    
		 
	}

	 /**
	     * Updates the data in the SQLite
	     * 
	     * @param dtoObject
	     *            : DTO object is passed
	     * @param dbObject
	     *            : Exposes methods to manage a SQLite database Object
	     * @return boolean : True if data is updated
	     */
	   
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	{
		 try
	        {
	            
	        	SeasonMasterDTO dto = (SeasonMasterDTO) dtoObject;

	            ContentValues cValues = new ContentValues();
	            
	            cValues.put("name", dto.getName());

	            dbObject.update("SEASONS", cValues, "id='" +dto.getId()+"' ", null);
	            return true;
	        } catch (SQLException e)
	        {
                ATBuildLog.e(TAG + "update()", e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        } finally
	        {
	            dbObject.close();
	        }
	        return false;
	    }
	
	/**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM SEASONS").execute();
            return true;
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }
}
