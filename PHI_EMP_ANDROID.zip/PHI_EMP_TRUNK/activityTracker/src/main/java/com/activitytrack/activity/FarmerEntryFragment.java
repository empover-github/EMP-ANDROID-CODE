package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.activitytrack.daos.FarmerEntryDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.FarmerEntryDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.List;

public class FarmerEntryFragment extends BaseFragment {

	private View view;

	private EditText edtS1FarmerName;
	private EditText edtS1MobileNumber;
	private EditText edtS1Acres;
	private EditText edtS2FarmerName;
	private EditText edtS2MobileNumber;
	private EditText edtS2Acres;
	private EditText edtS3FarmerName;
	private EditText edtS3MobileNumber;
	private EditText edtS3Acres;
	private EditText edtS4FarmerName;
	private EditText edtS4MobileNumber;
	private EditText edtS4Acres;
	private EditText edtS5FarmerName;
	private EditText edtS5MobileNumber;
	private EditText edtS5Acres;

	private Button btnSubmit;
	private Button btnAddNext;

	private LinearLayout mainLayout;

	private String activity;
	private long activityId;

	 
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.farmer_entry_fragment, container, false);
		edtS1FarmerName = (EditText) view.findViewById(R.id.fe_s1_farmerName);
		edtS1MobileNumber = (EditText) view.findViewById(R.id.fe_s1_mobileNumber);
		edtS1Acres = (EditText) view.findViewById(R.id.fe_s1_acres);
		edtS2FarmerName = (EditText) view.findViewById(R.id.fe_s2_farmerName);
		edtS2MobileNumber = (EditText) view.findViewById(R.id.fe_s2_mobileNumber);
		edtS2Acres = (EditText) view.findViewById(R.id.fe_s2_acres);
		edtS3FarmerName = (EditText) view.findViewById(R.id.fe_s3_farmerName);
		edtS3MobileNumber = (EditText) view.findViewById(R.id.fe_s3_mobileNumber);
		edtS3Acres = (EditText) view.findViewById(R.id.fe_s3_acres);
		edtS4FarmerName = (EditText) view.findViewById(R.id.fe_s4_farmerName);
		edtS4MobileNumber = (EditText) view.findViewById(R.id.fe_s4_mobileNumber);
		edtS4Acres = (EditText) view.findViewById(R.id.fe_s4_acres);
		edtS5FarmerName = (EditText) view.findViewById(R.id.fe_s5_farmerName);
		edtS5MobileNumber = (EditText) view.findViewById(R.id.fe_s5_mobileNumber);
		edtS5Acres = (EditText) view.findViewById(R.id.fe_s5_acres);

		mainLayout = (LinearLayout) view.findViewById(R.id.fe_bg_laylout);

		btnSubmit = (Button) view.findViewById(R.id.fe_submit);
		btnAddNext = (Button) view.findViewById(R.id.fe_addNext);

		setChange();

		Bundle bundle = getArguments();
		activity = bundle.getString("activity");
		activityId = bundle.getLong("activityId");

		btnAddNext.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String validateFarmer1 = validateFields();
				if (validateFarmer1.trim().length() == 0) {
					String validateFarmer2 = validateFarmer(edtS2FarmerName,
							edtS2MobileNumber, edtS2Acres);
					if (validateFarmer2.trim().length() == 0) {
						String validateFarmer3 = validateFarmer(
								edtS3FarmerName, edtS3MobileNumber, edtS3Acres);
						if (validateFarmer3.trim().length() == 0) {
							String validateFarmer4 = validateFarmer(
									edtS4FarmerName, edtS4MobileNumber,
									edtS4Acres);
							if (validateFarmer4.trim().length() == 0) {
								String validateFarmer5 = validateFarmer(
										edtS5FarmerName, edtS5MobileNumber,
										edtS5Acres);
								if (validateFarmer5.trim().length() == 0) {

									showAlertToAddNext();
								} else{
									if(!validateFarmer5.equals(getResources().getString(R.string.validmobilenum)))
									Utility.showAlert(mActivity, "", validateFarmer5);
								    }
								}else{
									if(!validateFarmer4.equals(getResources().getString(R.string.validmobilenum)))
									Utility.showAlert(mActivity, "", validateFarmer4);
							}
						}else{
							if(!validateFarmer3.equals(getResources().getString(R.string.validmobilenum)))
							Utility.showAlert(mActivity, "", validateFarmer3);
						}
					}else{
						if(!validateFarmer2.equals(getResources().getString(R.string.validmobilenum)))
						Utility.showAlert(mActivity, "", validateFarmer2);
					}
				}else{
					if(!validateFarmer1.equals(getResources().getString(R.string.validmobilenum).trim()))
						Utility.showAlert(mActivity, "", validateFarmer1);
				}
			 

			}
		});

		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String validateFarmer1 = validateFields();
				if (validateFarmer1.trim().length() == 0) {
					String validateFarmer2 = validateFarmer(edtS2FarmerName,
							edtS2MobileNumber, edtS2Acres);
					if (validateFarmer2.trim().length() == 0) {
						String validateFarmer3 = validateFarmer(
								edtS3FarmerName, edtS3MobileNumber, edtS3Acres);
						if (validateFarmer3.trim().length() == 0) {
							String validateFarmer4 = validateFarmer(
									edtS4FarmerName, edtS4MobileNumber,
									edtS4Acres);
							if (validateFarmer4.trim().length() == 0) {
								String validateFarmer5 = validateFarmer(
										edtS5FarmerName, edtS5MobileNumber,
										edtS5Acres);
								if (validateFarmer5.trim().length() == 0) {

									showAlertToSave();
								}  else{
									if(!validateFarmer5.equals(getResources().getString(R.string.validmobilenum)))
									Utility.showAlert(mActivity, "", validateFarmer5);
								    }
								}else{
									if(!validateFarmer4.equals(getResources().getString(R.string.validmobilenum)))
									Utility.showAlert(mActivity, "", validateFarmer4);
							}
						}else{
							if(!validateFarmer3.equals(getResources().getString(R.string.validmobilenum)))
							Utility.showAlert(mActivity, "", validateFarmer3);
						}
					}else{
						if(!validateFarmer2.equals(getResources().getString(R.string.validmobilenum)))
						Utility.showAlert(mActivity, "", validateFarmer2);
					}
				}else{
					if(!validateFarmer1.equals(getResources().getString(R.string.validmobilenum).trim()))
						Utility.showAlert(mActivity, "", validateFarmer1);
				}
			
			}
		});

		return view;
	}

	private String validateFarmer(EditText name, EditText mobileNo, EditText acres) {
		if (name.getText().toString().trim().length() == 0
				&& mobileNo.getText().toString().trim().length() == 0
				&& acres.getText().toString().trim().length() == 0) {
			return "";
		} else if (name.getText().toString().trim().length() == 0
				|| mobileNo.getText().toString().trim().length() == 0
				|| acres.getText().toString().trim().length() == 0) {
			return getResources().getString(R.string.enterallfields);
		}else if(mobileNo.getText().toString().trim().length() != 10) {
			mobileNo.setError(getResources().getString(R.string.validmobilenum));
			return getResources().getString(R.string.validmobilenum);
		}else{
			return "";
		}
	}

	private String validateFields() {
		if (edtS1FarmerName.getText().toString().trim().length() == 0)
			return  getResources().getString(R.string.farmernamentempty);

		if (edtS1MobileNumber.getText().toString().trim().length() == 0)
			return getResources().getString(R.string.mobilenonyempty);
		
		if(edtS1MobileNumber.getText().toString().trim().length() <= 9)
		{
			edtS1MobileNumber.setError(getResources().getString(R.string.validmobilenum));
			return getResources().getString(R.string.validmobilenum);
		}
		if (edtS1Acres.getText().toString().trim().length() == 0)
			return getResources().getString(R.string.acresntempty);

		return "";

	}

	private void showAlertToSave() {
		
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.saveData));
		builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				saveData();
				mActivity.popFragments();
			}

		});
		builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

			}
		});

		builder.create().show();
	}

	private void showAlertToAddNext() {
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.saveData));
		builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

				saveData();
			}

		});
		builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

			}
		});

		builder.create().show();
	}

	private void saveData() {
		List<DTO> avalibleRecordsList = FarmerEntryDAO.getInstance().getRecordInfoById(activity, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
		List<FarmerEntryDTO> dtoList = new ArrayList<FarmerEntryDTO>();
		FarmerEntryDTO dto = new FarmerEntryDTO();
		dto.setFarmerName(edtS1FarmerName.getText().toString().trim());
		dto.setMobileNumber(Long.valueOf(edtS1MobileNumber.getText().toString().trim()));
		dto.setAcres(Float.valueOf(edtS1Acres.getText().toString().trim()));
		dto.setActivity(activity);
		dto.setActivityId(activityId);
		dtoList.add(dto);

		if (edtS2FarmerName.getText().toString().trim().length() > 0
				&& edtS2MobileNumber.getText().toString().trim().length() > 0
				&& edtS2Acres.getText().toString().trim().length() > 0) {
			FarmerEntryDTO dto1 = new FarmerEntryDTO();
			dto1.setFarmerName(edtS2FarmerName.getText().toString().trim());
			dto1.setMobileNumber(Long.valueOf(edtS2MobileNumber.getText()
					.toString().trim()));
			dto1.setAcres(Float.valueOf(edtS2Acres.getText().toString().trim()));
			dto1.setActivity(activity);
			dto1.setActivityId(activityId);
			dtoList.add(dto1);
       
		}

		if (edtS3FarmerName.getText().toString().trim().length() > 0
				&& edtS3MobileNumber.getText().toString().trim().length() > 0
				&& edtS3Acres.getText().toString().trim().length() > 0) {

			FarmerEntryDTO dto2 = new FarmerEntryDTO();
			dto2.setFarmerName(edtS3FarmerName.getText().toString().trim());
			dto2.setMobileNumber(Long.valueOf(edtS3MobileNumber.getText()
					.toString().trim()));
			dto2.setAcres(Float.valueOf(edtS3Acres.getText().toString().trim()));
			dto2.setActivity(activity);
			dto2.setActivityId(activityId);
			dtoList.add(dto2);

		}

		if (edtS4FarmerName.getText().toString().trim().length() > 0
				&& edtS4MobileNumber.getText().toString().trim().length() > 0
				&& edtS4Acres.getText().toString().trim().length() > 0) {
			FarmerEntryDTO dto3 = new FarmerEntryDTO();

			dto3.setFarmerName(edtS4FarmerName.getText().toString().trim());
			dto3.setMobileNumber(Long.valueOf(edtS4MobileNumber.getText()
					.toString().trim()));
			dto3.setAcres(Float.valueOf(edtS4Acres.getText().toString().trim()));
			dto3.setActivity(activity);
			dto3.setActivityId(activityId);
			dtoList.add(dto3);

		}

		if (edtS5FarmerName.getText().toString().trim().length() > 0
				&& edtS5MobileNumber.getText().toString().trim().length() > 0
				&& edtS5Acres.getText().toString().trim().length() > 0) {
			FarmerEntryDTO dto4 = new FarmerEntryDTO();

			dto4.setFarmerName(edtS5FarmerName.getText().toString().trim());
			dto4.setMobileNumber(Long.valueOf(edtS5MobileNumber.getText()
					.toString().trim()));
			dto4.setAcres(Float.valueOf(edtS5Acres.getText().toString().trim()));
			dto4.setActivity(activity);
			dto4.setActivityId(activityId);
			dtoList.add(dto4);

		}

		boolean inserted = false;

		if (avalibleRecordsList != null && avalibleRecordsList.size() < 20) {
			if(avalibleRecordsList.size() == 0){
				if(dtoList.size() >= 1){
					inserted = insertData(dtoList);
				}else{
					Utility.showAlert(mActivity, "", "");
				}
			}else{
				int availCount = avalibleRecordsList.size();
				if (availCount + dtoList.size() <= 20) {
					inserted = insertData(dtoList);
				} else {
					Utility.showAlert(mActivity,getResources().getString(R.string.max20far), "Already " + availCount + " farmers added trying to add " + dtoList.size() + " farmers");
				}
			}
		} else {
			Utility.showAlert(mActivity, "",getResources().getString(R.string.al20far) );
		}

		if (inserted) {
//			Toast.makeText(mActivity, "Successfully inserted", Toast.LENGTH_SHORT).show();
			 
			List<DTO> tempList = FarmerEntryDAO.getInstance().getRecordInfoById(activity, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
			if (tempList != null && tempList.size() > 0) {
				if (tempList.size() >= 15) {
					btnAddNext.setVisibility(View.GONE);
				}
			}

			clearFields();
		} else {
			Toast.makeText(mActivity, "Failed to insert", Toast.LENGTH_SHORT).show();
		}

	}

	private boolean insertData(List<FarmerEntryDTO> list) {
		for (FarmerEntryDTO dto : list) {
			FarmerEntryDAO.getInstance().insert(dto,
					DBHandler.getInstance(mActivity).getDBObject(1));
		}
		return true;

	}

	private void clearFields() {
		edtS1FarmerName.setText("");
		edtS1MobileNumber.setText("");
		edtS1Acres.setText("");
		edtS2FarmerName.setText("");
		edtS2MobileNumber.setText("");
		edtS2Acres.setText("");
		edtS3FarmerName.setText("");
		edtS3MobileNumber.setText("");
		edtS3Acres.setText("");
		edtS4FarmerName.setText("");
		edtS4MobileNumber.setText("");
		edtS4Acres.setText("");
		edtS5FarmerName.setText("");
		edtS5MobileNumber.setText("");
		edtS5Acres.setText("");

	}

	private void setChange() {
		if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
			mainLayout.setBackgroundColor(getResources().getColor(
					R.color.theme_dark_layout_bg));

		} else if (Utility.getCurrentTheme(mActivity).equals(
				MyConstants.THEME_LIGHT)) {

			mainLayout.setBackgroundColor(getResources().getColor(
					R.color.theme_lite_layout_bg));

		}

	}
	

	@Override
	public boolean onBackPressed(int callbackCode) {
		if(isDataAvailable()){
			showAlertToExitScreen(callbackCode);
		}else{
			mActivity.onBackPressedCallBack(callbackCode);
		}
		return true;
	}
	
	private void showAlertToExitScreen(final int callbackCode){
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.formExitMsg));
		builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mActivity.onBackPressedCallBack(callbackCode);
			}
		});
		
		builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
			}
		});
		
		builder.create().show();
	}
	
	
	private boolean isDataAvailable() {
		if (edtS1FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS1MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS1Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS2FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS2MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS2Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS3FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS3MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS3Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS4FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS4MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS4Acres.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS5FarmerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS5MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS5Acres.getText().toString().trim().length() > 0)
			return true;

		return false;
	}
	

}
