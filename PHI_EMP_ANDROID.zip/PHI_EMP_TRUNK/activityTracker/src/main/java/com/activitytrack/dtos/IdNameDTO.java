package com.activitytrack.dtos;

/**
 * Created by fatima.t on 29-03-2018.
 */

public class IdNameDTO implements DTO {
    private long id;
    private String name;
    private String districtId; // common
    private String blockId; // common
    private String seasonId; // Commom
    private String cropId; // Common

    public IdNameDTO(int i, String s) {

        this.id = i;
        this.name = s;
    }
    public IdNameDTO(){

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDistrictId() {
        return districtId;
    }

    public void setDistrictId(String districtId) {
        this.districtId = districtId;
    }

    public String getBlockId() {
        return blockId;
    }

    public void setBlockId(String blockId) {
        this.blockId = blockId;
    }

    public String getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(String seasonId) {
        this.seasonId = seasonId;
    }

    public String getCropId() {
        return cropId;
    }

    public void setCropId(String cropId) {
        this.cropId = cropId;
    }
}
