package com.activitytrack.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.daos.AgronomyActivityDAO;
import com.activitytrack.daos.AgronomySummaryDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.AgronomyActivityDTO;
import com.activitytrack.dtos.AgronomySummaryDTO;
import com.activitytrack.dtos.DTO;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.SeasonCalendarDAO;
import com.activitytrack.masterdtos.HybridMasterDTO;
import com.activitytrack.masterdtos.SeasonCalendarDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class AgronomyFragment extends BaseFragment implements OnClickListener {

    private View view;

    private EditText edtNameOfFarmer;
    private EditText edtMobileNoOfFarmer;

    private EditText edtCompetitorHybrid1;
    private EditText edtCompetitorHybrid2;
    private EditText edtPincode;
    private EditText dateOfSowing;
    private EditText acresSowed;

    private TextView tvNameOfFarmer;
    private TextView tvMobileNoOfFarmer;
    private TextView tvPlotType;
    private TextView tvCompetitorHybrid1;
    private TextView tvCompetitorHybrid2;
    private TextView tvpincode;
    private TextView tvDateOfSowing, tvAcresSowed;

    private Button btnSubmit;

    private Spinner spnPlotType;
    private Spinner spnPravakta;
    private Spinner spnCorpId;
    private Spinner spnHybridType;
    private Spinner spnExisting;

    private LinearLayout mainLayout;

    List<String> spinnerData = new ArrayList<String>();


    private List<DTO> dtoList;
    private List<String> hybridNamesList = new ArrayList<String>();
    private List<DTO> hybridIdDTOList = new ArrayList<DTO>();
    private long hybridId;

    private List<String> cropNameList = new ArrayList<String>();
    private List<DTO> seasonDTOList = new ArrayList<DTO>();
    private long cropId;

    private long seasonId;


    private String[] pravaktaArray;
    private String[] existedArray;


    private String startDate, endDate,formattedDate;
    private int mYear, mMonth, mDay;
    private Dialog d;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        cropId = bundle.getInt("cropId");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.agronomy_fragment, container, false);

        spnPravakta = (Spinner) view.findViewById(R.id.ag_pravakta);
        spnCorpId = (Spinner) view.findViewById(R.id.ag_corn);
        spnHybridType = (Spinner) view.findViewById(R.id.ag_25P25);
        spnExisting = (Spinner) view.findViewById(R.id.ag_Existing);

        edtNameOfFarmer = (EditText) view.findViewById(R.id.ag_nameOfFarmer);
        edtMobileNoOfFarmer = (EditText) view.findViewById(R.id.ag_mobileNoOfFarmers);
        spnPlotType = (Spinner) view.findViewById(R.id.ag_plotType);
        edtCompetitorHybrid1 = (EditText) view.findViewById(R.id.ag_competitorHybrid1);
        edtCompetitorHybrid2 = (EditText) view.findViewById(R.id.ag_competitorHybrid2);
        edtPincode = (EditText) view.findViewById(R.id.ag_pincode);
        dateOfSowing = view.findViewById(R.id.ag_sowingDateEt);
        dateOfSowing.setOnClickListener(this);
        acresSowed = view.findViewById(R.id.ag_acresSowedEt);

        tvNameOfFarmer = (TextView) view.findViewById(R.id.ag_nameOfFarmer_l);
        tvMobileNoOfFarmer = (TextView) view.findViewById(R.id.ag_mobileNoOfFarmers_l);
        tvPlotType = (TextView) view.findViewById(R.id.ag_plotType_l);
        tvCompetitorHybrid1 = (TextView) view.findViewById(R.id.ag_competitorHybrid1_l);
        tvCompetitorHybrid2 = (TextView) view.findViewById(R.id.ag_competitorHybrid2_l);
        tvpincode = (TextView) view.findViewById(R.id.ag_pincode_l);
        tvDateOfSowing = view.findViewById(R.id.ag_sowingDateTv);
        tvAcresSowed = view.findViewById(R.id.ag_acresSowedTv);

        mainLayout = (LinearLayout) view.findViewById(R.id.ag_bg_laylout);

        btnSubmit = (Button) view.findViewById(R.id.ag_submit);

        seasonDTOList = SeasonCalendarDAO.getInstance().getRecordInfoByValue("activityId", "" + MyConstants.ACTIVITY_AGR_ID, DBHandler.getInstance(mActivity).getDBObject(0));
        if (seasonDTOList != null && seasonDTOList.size() > 0) {
            cropNameList.clear();
            for (DTO dto : seasonDTOList) {
                if (cropNameList.size() == 0) {
                    cropNameList.add("Select");
                }
                SeasonCalendarDTO seasonCalendarDTO = (SeasonCalendarDTO) dto;
                cropNameList.add(seasonCalendarDTO.getCropName());
                seasonId = seasonCalendarDTO.getSeasonId();
                startDate = seasonCalendarDTO.getSeasonStartDate();
                endDate = seasonCalendarDTO.getSeasonEndDate();
                if (Utility.isValidStr(startDate)) {
                    dateOfSowing.setText(Utility.formatDateToUser(startDate));
                }
            }
        }

        ArrayAdapter<String> cropAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, cropNameList);
        spnCorpId.setAdapter(cropAdapter);

        if (cropId != 0)
            for (int i = 0; i < seasonDTOList.size(); i++) {
                SeasonCalendarDTO dto = (SeasonCalendarDTO) seasonDTOList.get(i);
                if (cropId == dto.getCropId())
                    spnCorpId.setSelection(i + 1);
            }

        spnCorpId.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    SeasonCalendarDTO cropMasterDTO = (SeasonCalendarDTO) seasonDTOList.get(position - 1);
                    cropId = cropMasterDTO.getCropId();
                    hybridSpinnerPopulation(cropId);
                } else {
                    spnHybridType.setAdapter(null);
                    cropId = 0;
                }

                if (cropId > 0) {
                    String seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(cropId, MyConstants.ACTIVITY_AGR_ID, DBHandler.getInstance(mActivity).getDBObject(0));
                    boolean res = Utility.isSeasonExpire(seasonEndDate, Utility.getCurrentformatedDate());
                    if (res) {
                        Utility.showAlert(mActivity, "", getResources().getString(R.string.seacal) + "Agronomy" + " of crop " + (Utility.getCropNameById((int) cropId)) + " is over");
                    }
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        setChange();

        pravaktaArray = getResources().getStringArray(R.array.agronomy_spn1_items);
        ArrayAdapter<String> pravaktaAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, pravaktaArray);

        existedArray = getResources().getStringArray(R.array.agronomy_spn4_items);
        ArrayAdapter<String> existedAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, existedArray);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, spinnerData);

        spinnerData.add("Select");
        spinnerData.add("SBS");
//        spinnerData.add("MBS"); //commented on 17/07/2018
        spinnerData.add("FS"); //Added on 17/07/2018

        spnPravakta.setAdapter(pravaktaAdapter);
        spnExisting.setAdapter(existedAdapter);
        spnPlotType.setAdapter(adapter);

        spnPlotType.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }catch (Exception ignore){

                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        btnSubmit.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    if (checkForLocation) {
                        if (location != null && location.length() > 0) {
                            showAlertToSave();
                        } else {
                            getCurrentLocation(mActivity);
                        }
                    } else {
                        showAlertToSave();
                    }
                } else {
                    Utility.showAlert(mActivity, "", validation);
                }
            }
        });

        return view;
    }

    private void hybridSpinnerPopulation(long cropId) {
        hybridIdDTOList = HybridMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(mActivity).getDBObject(0));

        if (hybridIdDTOList != null && hybridIdDTOList.size() > 0) {
            hybridNamesList.clear();
            for (DTO dto : hybridIdDTOList) {
                if (hybridNamesList.size() == 0) {
                    hybridNamesList.add("Select");
                }
                HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) dto;
                hybridNamesList.add(hybridMasterDTO.getHybridName());
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.noHybrid));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    mActivity.popFragments();
                }
            });

            builder.create().show();
        }

        ArrayAdapter<String> hybridIdAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_dropdown_item, hybridNamesList);

        spnHybridType.setAdapter(hybridIdAdapter);

        spnHybridType.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    HybridMasterDTO hybridMasterDTO = (HybridMasterDTO) hybridIdDTOList.get(position - 1);
                    hybridId = hybridMasterDTO.getId();

                } else {
                    //spnHybridType.setSelection(1);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    private String validateFields() {

        if (spnPravakta.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.pravakta);

        if (spnCorpId.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.corn);

        if (spnHybridType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.hybrid);

        if (spnExisting.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.existing);

        if (edtNameOfFarmer.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.namfarmerntemp);

        if (edtMobileNoOfFarmer.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.mobfarntempty);

        if (edtMobileNoOfFarmer.getText().toString().trim().length() <= 9) {
            edtMobileNoOfFarmer.setError(getResources().getString(R.string.validmobilenum));
            return getResources().getString(R.string.validmobilenum);
        }

        if (spnPlotType.getSelectedItemPosition() == 0)
            return getResources().getString(R.string.plot);

        if(spnPlotType.getSelectedItemPosition() == 1) {

            if (edtCompetitorHybrid1.getText().toString().trim().length() == 0)
                return getResources().getString(R.string.comhyb1);

            if (edtCompetitorHybrid2.getText().toString().trim().length() == 0)
                return getResources().getString(R.string.comhyd2);
        }

        if (edtPincode.getText().toString().trim().length() == 0)
            return getResources().getString(R.string.pincode);

        if (edtPincode.getText().toString().trim().length() < 6) {
            return getResources().getString(R.string.zeropincode);
        }

        if (dateOfSowing.getText().toString().trim().length() == 0)
            return getString(R.string.select_date_error);

        if (acresSowed.getText().toString().trim().length() == 0)
            return getString(R.string.enter_total_crop_acres_error);

        return "";
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveData();
            }

        });
        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        builder.create().show();

    }

    private void saveData() {
        AgronomyActivityDTO dto = new AgronomyActivityDTO();

        dto.setCategory(pravaktaArray[spnPravakta.getSelectedItemPosition()]);
        dto.setCropId(cropId);
        dto.setHybridId(hybridId);
        dto.setSamplingObjective(existedArray[spnExisting.getSelectedItemPosition()]);
        dto.setNameOfFarmer(edtNameOfFarmer.getText().toString().trim());
        dto.setMobileNoOfFarmer(Long.valueOf(edtMobileNoOfFarmer.getText().toString().trim()));
        dto.setPlotType(spinnerData.get(spnPlotType.getSelectedItemPosition()));
        dto.setCompetitorHybrid1(edtCompetitorHybrid1.getText().toString().trim());
        dto.setCompetitorHybrid2(edtCompetitorHybrid2.getText().toString().trim());
        dto.setPincode(edtPincode.getText().toString().trim());
        dto.setDate(Utility.getCurrentDateAndTime());
        dto.setIsSync(1);
        dto.setLocation(location);
        dto.setSeasonId(seasonId);

        dto.setDateOfSowing(Utility.formatDateToServer(dateOfSowing.getText().toString()));
        dto.setAcresSowed(Double.valueOf(acresSowed.getText().toString().trim()));

        long seasonCalId = SeasonCalendarDAO.getInstance().getSeasonCalId(MyConstants.ACTIVITY_AGR_ID, cropId, DBHandler.getInstance(mActivity).getDBObject(0));
        dto.setSeasonCalendarId(seasonCalId);
        String seasonEndDate = SeasonCalendarDAO.getInstance().getSeasonEndDate(cropId, MyConstants.ACTIVITY_AGR_ID, DBHandler.getInstance(mActivity).getDBObject(0));
        boolean res = Utility.isSeasonExpire(seasonEndDate, Utility.getCurrentformatedDate());
        if (res) {
            Utility.showAlert(mActivity, "", getResources().getString(R.string.seasonExp));
            return;
        }

        long regionId = MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
        if (regionId != 0)
            dto.setRegionId(regionId);

        long activityId = AgronomyActivityDAO.getInstance().insertActivity(dto, DBHandler.getInstance(mActivity).getDBObject(1));

        if (activityId > 0) {
            AgronomySummaryDTO summaryDTO = new AgronomySummaryDTO();
            summaryDTO.setActivityCount(1);
            summaryDTO.setDate(Utility.getCurrentDateFrm());
            summaryDTO.setCropId(dto.getCropId());
            summaryDTO.setHybridId(dto.getHybridId());
            summaryDTO.setSeasonId(dto.getSeasonId());
            summaryDTO.setSeasonCalendarId(dto.getSeasonCalendarId());

            boolean inserted = AgronomySummaryDAO.getInstance().insert(summaryDTO, DBHandler.getInstance(mActivity).getDBObject(1));
            if (inserted) {
                Utility.showAlert(mActivity, null, MyConstants.SUC_MSG);
                checkForLocation = true;
                location = null;
                clearFields();
            }

        }

    }

    private void clearFields() {
        spnPravakta.setSelection(0);
        spnCorpId.setSelection(0);
        spnHybridType.setSelection(0);
        spnExisting.setSelection(0);
        edtNameOfFarmer.setText("");
        edtMobileNoOfFarmer.setText("");
        spnPlotType.setSelection(0);
        edtCompetitorHybrid1.setText("");
        edtCompetitorHybrid2.setText("");
        edtPincode.setText("");
//			  location = null;
    }

    private void setChange() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            tvNameOfFarmer.setTextColor(Color.WHITE);
            tvMobileNoOfFarmer.setTextColor(Color.WHITE);
            tvCompetitorHybrid1.setTextColor(Color.WHITE);
            tvCompetitorHybrid2.setTextColor(Color.WHITE);
            tvpincode.setTextColor(Color.WHITE);
            tvPlotType.setTextColor(Color.WHITE);
            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
            spnPlotType.setBackgroundResource(R.drawable.spinner_bg_img);
            tvDateOfSowing.setTextColor(Color.WHITE);
            tvAcresSowed.setTextColor(Color.WHITE);
            dateOfSowing.setCompoundDrawablesWithIntrinsicBounds(0,0, R.drawable.ic_calender_white, 0);

        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            tvNameOfFarmer.setTextColor(Color.BLACK);
            tvMobileNoOfFarmer.setTextColor(Color.BLACK);
            tvCompetitorHybrid1.setTextColor(Color.BLACK);
            tvCompetitorHybrid2.setTextColor(Color.BLACK);
            tvpincode.setTextColor(Color.BLACK);
            tvPlotType.setTextColor(Color.BLACK);
            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
            spnPlotType.setBackgroundResource(R.drawable.spinner_bg_img_light);
            tvDateOfSowing.setTextColor(Color.BLACK);
            tvAcresSowed.setTextColor(Color.BLACK);

            dateOfSowing.setCompoundDrawablesWithIntrinsicBounds(0,0, R.drawable.ic_calender_black, 0);
        }
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        if (isDataAvailable()) {
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }
        return true;
    }

    private void showAlertToExitScreen(final int callbackCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                mActivity.onBackPressedCallBack(callbackCode);
            }
        });

        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }


    private boolean isDataAvailable() {
        if (spnPravakta.getSelectedItemPosition() > 0)
            return true;

        if (spnHybridType.getSelectedItemPosition() > 0)
            return true;

        if (spnExisting.getSelectedItemPosition() > 0)
            return true;

        if (edtNameOfFarmer.getText().toString().trim().length() > 0)
            return true;

        if (edtMobileNoOfFarmer.getText().toString().trim().length() > 0)
            return true;

        if (spnPlotType.getSelectedItemPosition() > 0)
            return true;

        if (edtCompetitorHybrid1.getText().toString().trim().length() > 0)
            return true;

        if (edtCompetitorHybrid2.getText().toString().trim().length() > 0)
            return true;

        if (edtPincode.getText().toString().trim().length() > 0)
            return true;

        return false;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            if (!mGoogleApiClient.isConnected())
                mGoogleApiClient.connect();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mGoogleApiClient != null) {
            if (mGoogleApiClient.isConnected())
                mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onDestroy() {
        location = null;
        super.onDestroy();
    }

    public void openDatePicker(String s) {
        Date date = Utility.formatDateFromStrToDate2(s);
        //Calendar c = Calendar.getInstance();
        Calendar myCalendar = Calendar.getInstance();
        myCalendar.setTime(date);
        mYear = myCalendar.get(Calendar.YEAR);
        mMonth = myCalendar.get(Calendar.MONTH);
        mDay = myCalendar.get(Calendar.DAY_OF_MONTH);

        d = new Dialog(mActivity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(R.layout.at_date_picker_dialog);
        d.setCancelable(false);
        final TextView tv = d.findViewById(R.id.tv_date_label);

        DatePicker dp = d.findViewById(R.id.dp);
        dp.updateDate(mYear, mMonth, mDay);
        Button ok_btn = d.findViewById(R.id.btn_calendar_ok);
        ok_btn.setOnClickListener(this);
        if (Utility.isValidStr(endDate)) {
            dp.setMaxDate(Utility.convertStrToMilliSeconds(endDate));
        }
        if (Utility.isValidStr(startDate)) {
            dp.setMinDate(Utility.convertStrToMilliSeconds(startDate));
        }
        dp.init(mYear, mMonth, mDay, (view, year, monthOfYear, dayOfMonth) -> {
            // Do something when the date changed from date picker object

            // Create a Date variable/object with user chosen date
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(0);
            cal.set(year, monthOfYear, dayOfMonth, 0, 0, 0);

            Date chosenDate = cal.getTime();

            // Format the date
            DateFormat df2 = new SimpleDateFormat("dd-MMM-yyyy");
            formattedDate = df2.format(chosenDate);
            dateOfSowing.setText(formattedDate);

            String setTextValue = getString(R.string.your_selected_date_is) + " " + formattedDate;
            tv.setText(setTextValue);

        });

        d.show();

    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (viewId == R.id.btn_calendar_ok) {
            d.dismiss();
        } else if (viewId == R.id.ag_sowingDateEt){
            formattedDate = dateOfSowing.getText().toString();
            openDatePicker(formattedDate);
        }
    }
}
