package com.activitytrack.dtos;

import java.io.Serializable;

public class GerminationverificationListDTO implements DTO, Serializable {
    private long germinationClaimTransactionId;
    private long year;
    private String seasonName;
    private String cropName;
    private String name;
    private String farmerMobileNumber;
    private String pincode;
    private double germinationFailedAcres;
    private double totalSowedAcres;
    private String dateOfSowing;
    private String status;
    private long sync;

    // Used for submit
    private String remarks;
    private String geoLocation;
    private String mdrVerifiedDate; // 2018-08-01 yy-mm-dd

    public long getGerminationClaimTransactionId() {
        return germinationClaimTransactionId;
    }

    public void setGerminationClaimTransactionId(long germinationClaimTransactionId) {
        this.germinationClaimTransactionId = germinationClaimTransactionId;
    }

    public long getYear() {
        return year;
    }

    public void setYear(long year) {
        this.year = year;
    }

    public String getSeasonName() {
        return seasonName;
    }

    public void setSeasonName(String seasonName) {
        this.seasonName = seasonName;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFarmerMobileNumber() {
        return farmerMobileNumber;
    }

    public void setFarmerMobileNumber(String farmerMobileNumber) {
        this.farmerMobileNumber = farmerMobileNumber;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public double getGerminationFailedAcres() {
        return germinationFailedAcres;
    }

    public void setGerminationFailedAcres(double germinationFailedAcres) {
        this.germinationFailedAcres = germinationFailedAcres;
    }

    public double getTotalSowedAcres() {
        return totalSowedAcres;
    }

    public void setTotalSowedAcres(double totalSowedAcres) {
        this.totalSowedAcres = totalSowedAcres;
    }

    public String getDateOfSowing() {
        return dateOfSowing;
    }

    public void setDateOfSowing(String dateOfSowing) {
        this.dateOfSowing = dateOfSowing;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getSync() {
        return sync;
    }

    public void setSync(long sync) {
        this.sync = sync;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getGeoLocation() {
        return geoLocation;
    }

    public void setGeoLocation(String geoLocation) {
        this.geoLocation = geoLocation;
    }

    public String getMdrVerifiedDate() {
        return mdrVerifiedDate;
    }

    public void setMdrVerifiedDate(String mdrVerifiedDate) {
        this.mdrVerifiedDate = mdrVerifiedDate;
    }
}
