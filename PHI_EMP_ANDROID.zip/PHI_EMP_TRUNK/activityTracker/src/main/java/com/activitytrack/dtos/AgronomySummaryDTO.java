package com.activitytrack.dtos;

public class AgronomySummaryDTO implements DTO
{
private long id;
private long sampleCount;
private String date;

//new
private long cropId;
private long hybridId;
private long seasonId;
private long isSync;

public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public long getActivityCount() {
	return sampleCount;
}
public void setActivityCount(long activityId) {
	this.sampleCount = activityId;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public long getCropId() {
	return cropId;
}
public void setCropId(long cropId) {
	this.cropId = cropId;
}
public long getHybridId() {
	return hybridId;
}
public void setHybridId(long hybridId) {
	this.hybridId = hybridId;
}
public long getSeasonId() {
	return seasonId;
}
public void setSeasonId(long seasonId) {
	this.seasonId = seasonId;
}
public long getSeasonCalendarId() {
	return isSync;
}
public void setSeasonCalendarId(long isSync) {
	this.isSync = isSync;
}
}
