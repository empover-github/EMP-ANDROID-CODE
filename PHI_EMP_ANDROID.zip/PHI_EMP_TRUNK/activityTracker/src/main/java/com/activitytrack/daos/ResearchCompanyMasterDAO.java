package com.activitytrack.daos;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.CompanyMasterDTO;
import com.activitytrack.dtos.DTO;
import com.activitytrack.models.IdNameModel;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class ResearchCompanyMasterDAO implements DAO {
    private final String TAG = "ResearchCompanyMaster";
    private static ResearchCompanyMasterDAO researchCompanyMasterDAO;

    public static ResearchCompanyMasterDAO getInstance() {
        if (researchCompanyMasterDAO == null) {
            researchCompanyMasterDAO = new ResearchCompanyMasterDAO();
        }

        return researchCompanyMasterDAO;
    }

    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            CompanyMasterDTO dto = (CompanyMasterDTO) dtoObject;
            ContentValues cv = new ContentValues();
            cv.put("id", dto.getId());
            cv.put("name", dto.getName());
            cv.put("cropId",dto.getCropId());

            dbObject.insert("RESEARCH_COMPANY_MASTER", null, cv);
            return true;
            } catch (SQLException e) {
            return false;
        } finally {
            dbObject.close();
        }
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }
    @SuppressLint("LongLogTag")
    public List<DTO> getCompanyNameRecords(long cropId, SQLiteDatabase dbObject) {
        List<DTO> companyName = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM RESEARCH_COMPANY_MASTER where cropId = '" + cropId + "' " , null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    IdNameModel dto = new IdNameModel();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));

                    companyName.add(dto);
                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            e.printStackTrace();
            android.util.Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return companyName;
    }


    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> companyMasterInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
            if(!(columnName !=null && columnName.length() > 0)){
                columnName = "id";
            }

            cursor = dbObject.rawQuery("SELECT * FROM RESEARCH_COMPANY_MASTER where "+columnName+"='"+columnValue+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {

                    CompanyMasterDTO dto = new CompanyMasterDTO();
                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setName(cursor.getString(cursor.getColumnIndex("name")));


                    companyMasterInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return companyMasterInfo;
    }

    public boolean deleteTableData(SQLiteDatabase db) {
        try {
            db.compileStatement("DELETE FROM RESEARCH_COMPANY_MASTER").execute();
            return true;
        } catch (Exception e) {

        } finally {
            db.close();
        }
        return false;
    }

}
