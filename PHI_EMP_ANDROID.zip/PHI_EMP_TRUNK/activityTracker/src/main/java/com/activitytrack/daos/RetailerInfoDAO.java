package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.RetailerInfoDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;
 

public class RetailerInfoDAO implements DAO
{

	private final String TAG = "RetailerDAO";
    private static RetailerInfoDAO retailerInfoDAO;

    public static RetailerInfoDAO getInstance()
    {
        if (retailerInfoDAO == null)
        {
        	retailerInfoDAO = new RetailerInfoDAO();
        }
        
        return retailerInfoDAO;
    }

    /**
     * delete the Data
     */

	
	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}

	  /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
   
    
    
	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			
			
			{
		
		List<DTO> retailerInfoInfo = new ArrayList<DTO>();
	        Cursor cursor = null;
	        try
	        {
	        	if(!(columnName != null && columnName.length() > 0))
	        		columnName = "id";
	        	
	            cursor = dbObject.rawQuery("SELECT * FROM  RETAILER_INFO where "+columnName+"='"+columnValue+"' ", null);
	            if (cursor.getCount() > 0)
	            {
	                cursor.moveToFirst();
	                do
	                {


	                    /*RETAILER_INFO	
	                	  id
	                	  retailerName
	                	  mobileNumber 
	                	  altMobileNumber
	                	  date
	                	  location
	            	      isSync
	            	      activity
	                	  activityId
	                	  
	                	  */
	                
	                	RetailerInfoDTO dto=new RetailerInfoDTO();
	                	
	                	dto.setId(cursor.getLong(0));
	                    dto.setRetailerName(cursor.getString(1));
	                    dto.setMobileNumber(cursor.getLong(2));
	                    dto.setAltMobileNumber(cursor.getLong(3));
	                    dto.setDate(cursor.getString(4));
	                    dto.setLocation(cursor.getString(5));
	                    dto.setIsSync(cursor.getInt(6));
	                    dto.setActivity(cursor.getString(7));
	                    dto.setActivityId(cursor.getLong(8));
	                   
                       
	                    retailerInfoInfo.add(dto);
	                    
	                }while(cursor.moveToNext());
	            }
	            
	            }catch (Exception e) 
	            {
					ATBuildLog.e(TAG + "getRecords()", e.getMessage());
	            }finally
	            {
	                if (cursor != null && !cursor.isClosed())
	                {
	                    cursor.close();
	                }
	                dbObject.close();
	            }
	            	 
	            	 
	            	 
		return retailerInfoInfo;
	}
	
public List<DTO> getRecordInfoById(String activity, long activityId, SQLiteDatabase dbObject) {

	
	List<DTO> retailerInfoInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
        	
            cursor = dbObject.rawQuery("SELECT * FROM  RETAILER_INFO  where activity = '"+activity+"' and activityId = '"+activityId+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {

                    /*RETAILER_INFO	
                	  id
                	  retailerName
                	  mobileNumber 
                	  altMobileNumber
                	  date
                	  location
            	      isSync
            	      activity
                	  activityId
                	  
                	  */
                
                	RetailerInfoDTO dto=new RetailerInfoDTO();
                	
                	dto.setId(cursor.getLong(0));
                    dto.setRetailerName(cursor.getString(1));
                    dto.setMobileNumber(cursor.getLong(2));
                    dto.setAltMobileNumber(cursor.getLong(3));
                    dto.setDate(cursor.getString(4));
                    dto.setLocation(cursor.getString(5));
                    dto.setIsSync(cursor.getInt(6));
                    dto.setActivity(cursor.getString(7));
                    dto.setActivityId(cursor.getLong(8));
                   
                   
                    retailerInfoInfo.add(dto);
                    
                }while(cursor.moveToNext());
            }
            
            }catch (Exception e) 
            {
				ATBuildLog.e(TAG + "getRecords()", e.getMessage());
            }finally
            {
                if (cursor != null && !cursor.isClosed())
                {
                    cursor.close();
                }
                dbObject.close();
            }
            	 
        return retailerInfoInfo;
		}
	
	/**
     * Gets all the records from the database
     *
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
  
	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)
	{
	 List<DTO> retailerRecords=new ArrayList<DTO>();
	 
	 Cursor cursor=null;
	 try
     {
         cursor = dbObject.rawQuery("SELECT * FROM RETAILER_INFO ", null);
         if (cursor.getCount() > 0)
         {
             cursor.moveToFirst();
             do
             {
             	RetailerInfoDTO dto = new RetailerInfoDTO();
                 
             	dto.setId(cursor.getLong(0));
                dto.setRetailerName(cursor.getString(1));
                dto.setMobileNumber(cursor.getLong(2));
                dto.setAltMobileNumber(cursor.getLong(3));
                dto.setDate(cursor.getString(4));
                dto.setLocation(cursor.getString(5));
                dto.setIsSync(cursor.getInt(6));
                dto.setActivity(cursor.getString(7));
                dto.setActivityId(cursor.getLong(8));
                
                retailerRecords.add(dto);

             } while (cursor.moveToNext());
         } 
     } catch (Exception e)
     {
		 ATBuildLog.e(TAG + "getRecords()", e.getMessage());
     } finally
     {
         if (cursor != null && !cursor.isClosed())
         {
             cursor.close();
         }
         dbObject.close();
     }

     return retailerRecords;
 }
 
	 
	 

	
	public List<RetailerInfoDTO> getRecordsForUpload(String activity, long activityId, SQLiteDatabase dbObject)
	    {
			List<RetailerInfoDTO> retailerInfoInfo = new ArrayList<RetailerInfoDTO>();
		        Cursor cursor = null;
		        try
		        {
		        	
		            cursor = dbObject.rawQuery("SELECT * FROM  RETAILER_INFO where activity = '"+activity+"' and activityId = '"+activityId+"' ", null);
		            if (cursor.getCount() > 0)
		            {
		                cursor.moveToFirst();
		                do
		                {

		                    /*RETAILER_INFO	
		                	  id
		                	  retailerName
		                	  mobileNumber 
		                	  altMobileNumber
		                	  date
		                	  location
		            	      isSync
		            	      activity
		                	  activityId
		                	  
		                	  */
		                
		                	RetailerInfoDTO dto=new RetailerInfoDTO();
		                	
		                	dto.setId(cursor.getLong(0));
		                    dto.setRetailerName(cursor.getString(1));
		                    dto.setMobileNumber(cursor.getLong(2));
		                    dto.setAltMobileNumber(cursor.getLong(3));
							dto.setDate(cursor.getString(4));
							dto.setLocation(cursor.getString(5));
		                    dto.setIsSync(cursor.getInt(6));
		                    dto.setActivity(cursor.getString(7));
		                    dto.setActivityId(cursor.getLong(8));
	                       
		                    retailerInfoInfo.add(dto);
		                    
		                }while(cursor.moveToNext());
		            }
		            
		            }catch (Exception e) 
		            {
						ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		            }finally
		            {
		                if (cursor != null && !cursor.isClosed())
		                {
		                    cursor.close();
		                }
		                dbObject.close();
		            }
		            	 
		            	 
		            	 
			return retailerInfoInfo;
	    }

	
			 
	/**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
   
	
	
	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	
	{
		try
		{
			RetailerInfoDTO dto=(RetailerInfoDTO) dtoObject;
			ContentValues cValues=new ContentValues();


	        /*RETAILER_INFO	
	    	  id
	    	  retailerName
	    	  mobileNumber 
	    	  altMobileNumber
	    	  date
	    	  location
		      isSync
		      activity
	    	  activityId
	    	  
	    	  */
			 cValues.put("retailerName",dto.getRetailerName());
			 cValues.put("mobileNumber ",dto.getMobileNumber());
			 cValues.put("altMobileNumber ",dto.getAltMobileNumber());
			 cValues.put("location", dto.getLocation());
	         cValues.put("isSync", dto.getIsSync());
	         cValues.put("date",dto.getDate());
	         cValues.put("activity",dto.getActivity());
	         cValues.put("activityId",dto.getActivityId());
	         
	         dbObject.insert("RETAILER_INFO",null, cValues);
	         return true;
		}catch(Exception e)
		{
			ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;
        } finally
        {
            dbObject.close();
        }
	}
		
		
	  /**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */

		 
	
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) { 
		
		
		
		try
    {
        
    	RetailerInfoDTO dto = (RetailerInfoDTO) dtoObject;
    	
    	ContentValues cValues = new ContentValues();
    	  	
    	if(dto.getRetailerName()!=null)
    		cValues.put("retailerName",dto.getRetailerName());
    	
    	if(dto.getMobileNumber()!= 0)
    		cValues.put("mobileNumber",dto.getMobileNumber());
    	
    	if(dto.getAltMobileNumber()!=0)
    		cValues.put("altMobileNumber",dto.getAltMobileNumber());
    	
    	if(dto.getDate()!=null)
    	  cValues.put("date",dto.getDate());
    	
    	if(dto.getLocation() != null)
    		cValues.put("location", dto.getLocation());
    	
        cValues.put("isSync", dto.getIsSync());
        
        if(dto.getActivity()!=null)
        	cValues.put("activity",dto.getActivity());
        
        if(dto.getActivityId()!=0)
        	cValues.put("activityId",dto.getActivityId());

        dbObject.update("RETAILER_INFO", cValues, "id='" +dto.getId()+"' ", null);
        return true;
    } catch (SQLException e)
    {
		ATBuildLog.e(TAG + "update()", e.getMessage());
        e.printStackTrace();
    } catch (Exception e)
    {
        e.printStackTrace();
    } finally
    {
        dbObject.close();
    }

		 
		return false;
	
	}
	
	
	
	/**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM RETAILER_INFO").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }
    
    public boolean deleteTableDataById(String activity, long activityId,SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM RETAILER_INFO where activity = '"+activity+"' and activityId = '"+activityId+"'").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }
   
    public boolean deleteDataByActivityId(String activityId,String activity,SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("DELETE FROM RETAILER_INFO where   activityId = '"+activityId+"' and activity = '"+activity+"'");
			return true;
		}catch(Exception e)
		{
			ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally
		
		{
		
		dbObject.close();
		
		}
		return false;
	}  
	
}
