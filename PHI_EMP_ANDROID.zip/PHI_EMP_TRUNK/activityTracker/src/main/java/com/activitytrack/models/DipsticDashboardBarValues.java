package com.activitytrack.models;

/**
 * Created by fatima.t on 25-04-2018.
 */

public class DipsticDashboardBarValues {
    private int piValues;
    private int fuValues;

    public int getPiValues() {
        return piValues;
    }

    public void setPiValues(int piValues) {
        this.piValues = piValues;
    }

    public int getFuValues() {
        return fuValues;
    }

    public void setFuValues(int fuValues) {
        this.fuValues = fuValues;
    }
}
