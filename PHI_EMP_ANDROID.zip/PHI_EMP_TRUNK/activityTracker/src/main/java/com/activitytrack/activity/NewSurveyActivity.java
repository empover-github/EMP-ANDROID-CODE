package com.activitytrack.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.ActionBar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.adapter.CropAdapter;
import com.activitytrack.daos.CompanyMasterDAO;
import com.activitytrack.daos.NewMdrSurveyDAO;
import com.activitytrack.daos.ResearchCompanyMasterDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.NewMdrSurveyDTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdaos.HybridMasterDAO;
import com.activitytrack.models.IdNameModel;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import net.sourceforge.opencamera.MainActivityOC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class NewSurveyActivity extends BaseActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    private NewSurveyActivity thisActivity;
    private Bundle bundle;
    private long activityId, cropId;
    private String previousCropName, previousSegmentName, previousblockName, previouspincode, previousisPDAVillage, previousvillageName;
    private ScrollView mainLayout;
    private Button submitBtn;
    private ImageView profileImage, cameraIcon;
    private TextView tvFarmerName, tvFarmerMobile, tvRiceFarming, tvRiceAcreage, tvMajComp1, tvMajComp2, tvMajComp3, tvMajComp4, tvMajComp5, tvTotalComp, tvMajResComp, tvMajComp1Acre, tvMajComp2Acre, tvMajComp3Acre, tvMajComp4Acre, tvMajComp5Acre, tvOtherComp,
            tvUpLand, tvMidLand, tvMidLowLand, tvFineRice, tvLowLand,
            tvPionHybType1, tvPionHybType2, tvPionHybType3, tvSpnPionHyb1Corn, tvSpnPionHyb2Corn, tvPionHybAcresCorn, tvPionHyb2AcresCorn;
    private EditText edtFarmerName, edtMobileNo, edtRiceFarming, edtRiceAcreage, edtMajComp1, edtMajComp2, edtMajComp3, edtMajComp4,
            edtMajComp5, edtTotalResComp, edtOtherComp, edtUpLand, edtMidLand, edtMidLowLand, edtFineRice, edtLowLand, edtPionHybType1,
            edtPionHybType2, edtPionHybType3, edtPionHyb1AcresCorn, edtPionHyb2AcresCorn;

    private Spinner spnMajComp1, spnMajComp2, spnMajComp3, spnMajComp4, spnMajComp5, spnMajResComp, spnPioneerHybird1Corn, spnPioneerHybird2Corn;
    private List<String> majorCompanyList = new ArrayList<>();
    private TextView tvColo1, tvColo2, tvColo3, tvColo4, tvColo5, tvColo6, tvColo7, tvColo8,
            tvColo9, tvColo10, tvColo11, tvColo12, tvColo13, tvColo14, tvColo15, tvColo16, tvColo17, tvColo18, tvColo19, tvColo20, tvColo21, tvColo22, tvColo23, tvColo31, tvColo32;
    private String imagePath;
    private File myDir;
    private Uri uriStr;
    private String latLongValues;
    private ExecutorService mExecutor;
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    private static final int REQUEST_CODE_FOR_IMAGE_CROPPING = 65;
    public static final int OPENCAMERA = 300;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private LinearLayout lnrMajorImg, lnrSegementImg, lnrIndividualImg, lnrIndividualCornImg, lnrMajor,
            lnrIndividual, lnrSegement, lnrIndividualCorn, lnrTotalComp, lnrMajResComp;
    private ImageView imgMajor, imgIndividual, imgSegment, imgIndiviualCorn;
    private List<IdNameModel> companyList = new ArrayList<>();
    private List<IdNameModel> researchCompanyList = new ArrayList<>();
    private List<IdNameModel> hybridList = new ArrayList<>();
    private CropAdapter majorAdapter1, majorAdapter2, majorAdapter3, majorAdapter4, majorAdapter5, majorResAdapter, hybridAdapter1, hybridAdapter2;
    private List<DTO> majorCompanyDTOList, researchCompanyDTOList, hybridDTOList;
    private String cropName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(getApplicationContext()).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }
        super.onCreate(savedInstanceState);

        geoLocation = null;
        setContentView(R.layout.activity_survey_new);
        thisActivity = this;

        bundle = getIntent().getExtras();
        if (bundle != null) {
            activityId = bundle.getLong(MdrSurveyListActivity.EXTRA_ACTIVITY_ID);
            cropId = bundle.getLong(MdrSurveyListActivity.EXTRA_CROP_ID);
            previousCropName = bundle.getString(MdrSurveyListActivity.EXTRA_CROP_NAME);
            previousSegmentName = bundle.getString(MdrSurveyListActivity.EXTRA_SEGMENT_NAME);
          /*  previousblockName = bundle.getString(MdrSurveyListActivity.EXTRA_BLOCK_NAME);
            previousisPDAVillage = bundle.getString(MdrSurveyListActivity.EXTRA_ISPDAVILLAGE);
            previouspincode = bundle.getString(MdrSurveyListActivity.EXTRA_PINCODE);
            previousvillageName = bundle.getString(MdrSurveyListActivity.EXTRA_VILLAGE_NAME);*/
        }

        // set Action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setTitle(getResources().getString(R.string.survey));
        }
        initializeViews();
        cropName = CropMasterDAO.getInstance().getName(cropId, DBHandler.getInstance(thisActivity).getDBObject(0));
        if (cropName.equalsIgnoreCase(getString(R.string.rice))) {
           /* lnrSegementImg.setVisibility(View.VISIBLE);
            //lnrSegement
            lnrIndividualImg.setVisibility(View.VISIBLE);
            //lnrIndividual*/
            lnrIndividualCornImg.setVisibility(View.GONE);
            lnrIndividualCorn.setVisibility(View.GONE);
        } else {
            lnrTotalComp.setVisibility(View.GONE);
            lnrMajResComp.setVisibility(View.GONE);
            lnrSegementImg.setVisibility(View.GONE);
            lnrSegement.setVisibility(View.GONE);
            lnrIndividualImg.setVisibility(View.GONE);
            lnrIndividual.setVisibility(View.GONE);
            lnrIndividualCornImg.setVisibility(View.VISIBLE);
            lnrIndividualCorn.setVisibility(View.VISIBLE);
        }
        tvRiceFarming.setText("No of" + " " + cropName + " " + "Farming Families in Village");
        tvRiceAcreage.setText("Total" + " " + cropName + " " + "Acreage in Village");

        setChange();

        if (checkLocPermission())
            if (Utility.checkPlayServices(thisActivity)) {
                buildGoogleApiClient();
            }

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CheckValidations()) {
                    if (!NewMdrSurveyDAO.getInstance().isSurveyExist(activityId, edtMobileNo.getText().toString(), DBHandler.getInstance(thisActivity).getDBObject(0))) {
                        if (Utility.isValidStr(latLongValues)) {
                            showAlertToSave();
                        } else {
                            getCurrentLocation(thisActivity);
                        }
                    } else {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.survey_exist), getString(R.string.ok));
                    }
                }
            }
        });
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOptionsDialog();
            }
        });

        cameraIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOptionsDialog();
            }
        });

        majorCompanyDTOList = CompanyMasterDAO.getInstance().getCompanyNameRecords(cropId, DBHandler.getInstance(thisActivity).getDBObject(0));
        companyList.clear();
        companyList.add(new IdNameModel(getString(R.string.select)));
        if (majorCompanyDTOList != null && majorCompanyDTOList.size() > 0) {
            for (DTO dto : majorCompanyDTOList) {
                IdNameModel idNameModel = (IdNameModel) dto;
                companyList.add(idNameModel);
            }
        } else {
            DialogManager.showSingleBtnPopup(thisActivity, new DialogMangerCallback() {
                @Override
                public void onOkClick() {
                    finish();
                }

                @Override
                public void onCancelClick(View view) {

                }
            }, getString(R.string.alert), getString(R.string.company_DB_Data), getString(R.string.ok));
        }

        majorAdapter1 = new CropAdapter(thisActivity, companyList);
        majorAdapter2 = new CropAdapter(thisActivity, companyList);
        majorAdapter3 = new CropAdapter(thisActivity, companyList);
        majorAdapter4 = new CropAdapter(thisActivity, companyList);
        majorAdapter5 = new CropAdapter(thisActivity, companyList);

        spnMajComp1.setAdapter(majorAdapter1);
        spnMajComp2.setAdapter(majorAdapter2);
        spnMajComp3.setAdapter(majorAdapter3);
        spnMajComp4.setAdapter(majorAdapter4);
        spnMajComp5.setAdapter(majorAdapter5);

        researchCompanyDTOList = ResearchCompanyMasterDAO.getInstance().getCompanyNameRecords(cropId, DBHandler.getInstance(thisActivity).getDBObject(0));
        researchCompanyList.clear();
        researchCompanyList.add(new IdNameModel(getString(R.string.select)));
        if (researchCompanyDTOList != null && researchCompanyDTOList.size() > 0) {
            for (DTO dto : researchCompanyDTOList) {
                IdNameModel idNameModel = (IdNameModel) dto;
                researchCompanyList.add(idNameModel);
            }
        }
        majorResAdapter = new CropAdapter(thisActivity, researchCompanyList);
        spnMajResComp.setAdapter(majorResAdapter);

        hybridDTOList = HybridMasterDAO.getInstance().getSurveyRecords(cropId, DBHandler.getInstance(thisActivity).getDBObject(0));
        hybridList.clear();
        hybridList.add(new IdNameModel(getString(R.string.select)));
        if (hybridDTOList != null && hybridDTOList.size() > 0) {
            for (DTO dto : hybridDTOList) {
                IdNameModel idNameModel = (IdNameModel) dto;
                hybridList.add(idNameModel);
            }
        }
        hybridAdapter1 = new CropAdapter(thisActivity, hybridList);
        hybridAdapter2 = new CropAdapter(thisActivity, hybridList);
        spnPioneerHybird1Corn.setAdapter(hybridAdapter1);
        spnPioneerHybird2Corn.setAdapter(hybridAdapter2);


        getSpinnersListAndSet();

        edtMajComp1.addTextChangedListener(totalMajorComapnyTextWatcher);
        edtMajComp2.addTextChangedListener(totalMajorComapnyTextWatcher);
        edtMajComp3.addTextChangedListener(totalMajorComapnyTextWatcher);
        edtMajComp4.addTextChangedListener(totalMajorComapnyTextWatcher);
        edtMajComp5.addTextChangedListener(totalMajorComapnyTextWatcher);
        edtOtherComp.addTextChangedListener(totalMajorComapnyTextWatcher);
        edtTotalResComp.addTextChangedListener(totalMajorComapnyTextWatcher);

        // edtOtherComp.addTextChangedListener(totalLandTextWatcher);
        edtUpLand.addTextChangedListener(totalLandTextWatcher);
        edtMidLand.addTextChangedListener(totalLandTextWatcher);
        edtMidLowLand.addTextChangedListener(totalLandTextWatcher);
        edtFineRice.addTextChangedListener(totalLandTextWatcher);
        edtLowLand.addTextChangedListener(totalLandTextWatcher);

    }

    private boolean CheckValidations() {
        /*if (!Utility.isValidStr(imagePath)) {
            DialogManager.showToast(thisActivity, getString(R.string.image_error));
            return false;
        } else */
        if (!Utility.isValidStr(edtFarmerName.getText().toString().trim())) {
            DialogManager.showToast(thisActivity, getString(R.string.farmer_name_error));
            return false;
        }
        if (!Utility.isValidStr(edtMobileNo.getText().toString().trim())) {
            DialogManager.showToast(thisActivity, getString(R.string.mobile_no_error));
            return false;
        }
        if (Utility.isValidStr(edtMobileNo.getText().toString().trim()) && edtMobileNo.length() < 10) {
            DialogManager.showToast(thisActivity, getString(R.string.mobile_no_valid_error));
            return false;
        }
        if (!Utility.isValidNumber(edtRiceFarming.getText().toString().trim())) {
            DialogManager.showToast(thisActivity, getString(R.string.no_of_rice_farming_families_error));
            return false;
        }
        if (!Utility.isValidNumber(edtRiceAcreage.getText().toString().trim())) {
            DialogManager.showToast(thisActivity, getString(R.string.rice_acerage_error));
            return false;
        }
        if (((IdNameModel) majorAdapter1.getItem(spnMajComp1.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
            DialogManager.showToast(thisActivity, getString(R.string.major1));
            return false;
        }
        if (!Utility.isValidNumber(edtMajComp1.getText().toString())) {
            DialogManager.showToast(thisActivity, getString(R.string.edt_major1));
            return false;
        }
        if (!((IdNameModel) majorAdapter2.getItem(spnMajComp2.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
            if (!Utility.isValidNumber(edtMajComp2.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.edt_major2));
                return false;
            }
        }
        if (Utility.isValidNumber(edtMajComp2.getText().toString())) {
            if (((IdNameModel) majorAdapter2.getItem(spnMajComp2.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                DialogManager.showToast(thisActivity, getString(R.string.major2));
                return false;
            }
        }

        if (!((IdNameModel) majorAdapter3.getItem(spnMajComp3.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
            if (!Utility.isValidNumber(edtMajComp3.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.edt_major3));
                return false;
            }
        }
        if (Utility.isValidNumber(edtMajComp3.getText().toString())) {
            if (((IdNameModel) majorAdapter3.getItem(spnMajComp3.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                DialogManager.showToast(thisActivity, getString(R.string.major3));
                return false;
            }
        }
        if (!((IdNameModel) majorAdapter4.getItem(spnMajComp4.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
            if (!Utility.isValidNumber(edtMajComp4.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.edt_major4));
                return false;
            }
        }
        if (Utility.isValidNumber(edtMajComp4.getText().toString())) {
            if (((IdNameModel) majorAdapter4.getItem(spnMajComp4.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                DialogManager.showToast(thisActivity, getString(R.string.major4));
                return false;
            }
        }
        if (!((IdNameModel) majorAdapter5.getItem(spnMajComp5.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
            if (!Utility.isValidNumber(edtMajComp5.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.edt_major5));
                return false;
            }
        }
        if (Utility.isValidNumber(edtMajComp5.getText().toString())) {
            if (((IdNameModel) majorAdapter5.getItem(spnMajComp5.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                DialogManager.showToast(thisActivity, getString(R.string.major5));
                return false;
            }
        }

        int hybridTotalPer = Utility.getNumberInt(edtMajComp1) + Utility.getNumberInt(edtMajComp2)
                + Utility.getNumberInt(edtMajComp3) + Utility.getNumberInt(edtMajComp4) + Utility.getNumberInt(edtMajComp5)
                + Utility.getNumberInt(edtOtherComp) + Utility.getNumberInt(edtTotalResComp);

        if(hybridTotalPer != 100){
            DialogManager.showToast(thisActivity, getString(R.string.hybrid__total_tx));
            return false;
        }

        /*if (!Utility.isValidStr(edtOtherComp.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.edt_major5));
            }*/
        if (cropName.equalsIgnoreCase(getString(R.string.rice))) {
            // && Long.parseLong(edtTotalResComp.getText().toString()) <= 0  && Long.parseLong(edtTotalResComp.getText().toString()) >= 100
            if (Utility.isValidNumber(edtTotalResComp.getText().toString())) {
                if (((IdNameModel) majorResAdapter.getItem(spnMajResComp.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                    DialogManager.showToast(thisActivity, getString(R.string.majorRes));
                    return false;
                }
            }
            if (!((IdNameModel) majorResAdapter.getItem(spnMajResComp.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                if (!Utility.isValidNumber(edtTotalResComp.getText().toString())) {
                    DialogManager.showToast(thisActivity, getString(R.string.edt_major_res));
                    return false;
                }
            }
            if (edtUpLand.getText().toString().isEmpty()) {
                if (edtMidLand.getText().toString().isEmpty()) {
                    if (edtMidLowLand.getText().toString().isEmpty()) {
                        if (edtFineRice.getText().toString().isEmpty()) {
                            if (edtLowLand.getText().toString().isEmpty()) {
                                DialogManager.showToast(thisActivity, getString(R.string.upland_tx));
                                return false;
                            }
                        }
                    }
                }
            }

            int allLandTotalPer = Utility.getNumberInt(edtUpLand) + Utility.getNumberInt(edtMidLand)
                    + Utility.getNumberInt(edtMidLowLand) + Utility.getNumberInt(edtFineRice) + Utility.getNumberInt(edtLowLand);

            if(allLandTotalPer != 100){
                DialogManager.showToast(thisActivity, getString(R.string.upland__total_tx));
                return false;
            }

            /*if (!Utility.isValidStr(edtMidLand.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.mid_land));
                return false;
            }
            if (!Utility.isValidStr(edtMidLowLand.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.mid_low));
                return false;
            }
            if (!Utility.isValidStr(edtFineRice.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.fine_rice_tx));
                return false;
            }
            if (!Utility.isValidStr(edtLowLand.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.low_land_tx));
                return false;
            }*/
            /*if (!Utility.isValidStr(edtPionHybType2.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.hybrid_type2));
                return false;
            }
            if (!Utility.isValidStr(edtPionHybType3.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.hybrid_type3));
                return false;
            }*/
            if (!Utility.isValidNumber(edtPionHybType1.getText().toString())) {
                if (!Utility.isValidNumber(edtPionHybType2.getText().toString())) {
                    if (!Utility.isValidNumber(edtPionHybType3.getText().toString())) {
                        DialogManager.showToast(thisActivity, getString(R.string.hybrid_type1));
                        return false;
                    }
                }
            }

        } else {
            if (((IdNameModel) hybridAdapter1.getItem(spnPioneerHybird1Corn.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                DialogManager.showToast(thisActivity, getString(R.string.pioneer_hyb));
                return false;
            }
            if (!Utility.isValidNumber(edtPionHyb1AcresCorn.getText().toString())) {
                DialogManager.showToast(thisActivity, getString(R.string.pioneer_hyb_acres));
                return false;
            }
            if (!((IdNameModel) hybridAdapter2.getItem(spnPioneerHybird2Corn.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                if (!Utility.isValidNumber(edtPionHyb2AcresCorn.getText().toString())) {
                    DialogManager.showToast(thisActivity, getString(R.string.pioneer_hyb1_acres));
                    return false;
                }
            }
            if (Utility.isValidNumber(edtPionHyb2AcresCorn.getText().toString())) {
                if (((IdNameModel) hybridAdapter2.getItem(spnPioneerHybird2Corn.getSelectedItemPosition())).getName().equalsIgnoreCase(getString(R.string.select))) {
                    DialogManager.showToast(thisActivity, getString(R.string.pioneer_hyb1));
                    return false;
                }
            }

        }

        return true;
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(thisActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveData();
                setResult(RESULT_OK);
                finish();
            }


        });

        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void saveData() {

        NewMdrSurveyDTO dto = new NewMdrSurveyDTO();
        // add image path URL
        dto.setLocalImagePath(imagePath);
        dto.setGeoLocation(latLongValues);
        dto.setFarmerName(edtFarmerName.getText().toString());
        dto.setMobileNo(edtMobileNo.getText().toString());
        dto.setNoOfFamilies(Long.parseLong(edtRiceFarming.getText().toString()));
        dto.setTotalLand(Long.parseLong(edtRiceAcreage.getText().toString()));
        IdNameModel data = (IdNameModel) spnMajComp1.getTag();
        IdNameModel data1 = (IdNameModel) spnMajComp2.getTag();
        IdNameModel data2 = (IdNameModel) spnMajComp3.getTag();
        IdNameModel data3 = (IdNameModel) spnMajComp4.getTag();
        IdNameModel data4 = (IdNameModel) spnMajComp5.getTag();
        IdNameModel data10 = (IdNameModel) spnMajResComp.getTag();
        dto.setMajorCompany1(data.getId());
        dto.setMajorCompany1Acreage(Float.parseFloat(edtMajComp1.getText().toString()));
        if (data1.getId() != 0) {
            dto.setMajorCompany2(data1.getId());
        }
        if (Utility.isValidStr(edtMajComp2.getText().toString())) {
            dto.setMajorCompany2Acreage(Float.parseFloat(edtMajComp2.getText().toString()));
        }
        if (data2.getId() != 0) {
            dto.setMajorCompany3(data2.getId());
        }
        if (Utility.isValidStr(edtMajComp3.getText().toString())) {
            dto.setMajorCompany3Acreage(Float.parseFloat(edtMajComp3.getText().toString()));
        }
        if (data3.getId() != 0) {
            dto.setMajorCompany4(data3.getId());
        }
        if (Utility.isValidStr(edtMajComp4.getText().toString())) {
            dto.setMajorCompany4Acreage(Float.parseFloat(edtMajComp4.getText().toString()));
        }
        if (data4.getId() != 0) {
            dto.setMajorCompany5(data4.getId());
        }

        if (Utility.isValidStr(edtMajComp5.getText().toString())) {
            dto.setMajorCompany5Acreage(Float.parseFloat(edtMajComp5.getText().toString()));
        }
        if (Utility.isValidStr(edtOtherComp.getText().toString())) {
            dto.setOtherCompanyAcreage(Float.parseFloat(edtOtherComp.getText().toString()));
        }
        if (data10 != null) {
            if (data10.getId() != 0) {
                dto.setMajorResearchCompanyName(data10.getId());
            }
        }
        if (Utility.isValidStr(edtTotalResComp.getText().toString())) {
            dto.setTotalResearchAcres(Float.parseFloat(edtTotalResComp.getText().toString()));
        }
        if (Utility.isValidStr(edtUpLand.getText().toString())) {
            dto.setSegmentTypeUpland(Float.parseFloat(edtUpLand.getText().toString()));
        }
        if (Utility.isValidStr(edtMidLand.getText().toString())) {
            dto.setSegmentTypeMidland(Float.parseFloat(edtMidLand.getText().toString()));
        }
        if (Utility.isValidStr(edtMidLowLand.getText().toString())) {
            dto.setSegmentTypeMidLowland(Float.parseFloat(edtMidLowLand.getText().toString()));
        }
        if (Utility.isValidStr(edtFineRice.getText().toString())) {
            dto.setSegmentTypeFineRice(Float.parseFloat(edtFineRice.getText().toString()));
        }
        if (Utility.isValidStr(edtLowLand.getText().toString())) {
            dto.setSegmentTypeLowland(Float.parseFloat(edtLowLand.getText().toString()));
        }
        if (Utility.isValidStr(edtPionHybType1.getText().toString())) {
            dto.setPioneerHybridType1Acres(Float.parseFloat(edtPionHybType1.getText().toString()));
        }
        if (Utility.isValidStr(edtPionHybType2.getText().toString())) {
            dto.setPioneerHybridType2Acres(Float.parseFloat(edtPionHybType2.getText().toString()));
        }
        if (Utility.isValidStr(edtPionHybType3.getText().toString())) {
            dto.setPioneerHybridType3Acres(Float.parseFloat(edtPionHybType3.getText().toString()));
        }
        IdNameModel data5 = (IdNameModel) spnPioneerHybird1Corn.getTag();
        IdNameModel data6 = (IdNameModel) spnPioneerHybird2Corn.getTag();
        if (data5 != null) {
            if (data5.getId() != 0) {
                dto.setPioneerHybrid1(data5.getId());
            }
        }
        if (Utility.isValidStr(edtPionHyb1AcresCorn.getText().toString())) {
            dto.setPioneerHybrid1Acres(Float.parseFloat(edtPionHyb1AcresCorn.getText().toString()));
        }
        if (data6 != null) {
            if (data6.getId() != 0) {
                dto.setPioneerHybrid2(data6.getId());
            }
        }
        if (Utility.isValidStr(edtPionHyb2AcresCorn.getText().toString())) {
            dto.setPioneerHybrid2Acres(Float.parseFloat(edtPionHyb2AcresCorn.getText().toString()));
        }
        /*dto.setCropId(cropId);
        dto.setBlockName(previousblockName);
        dto.setPinCode(previouspincode);
        dto.setRetailerMobileNumber();
        dto.setIsPDAVillage(previousisPDAVillage);
        dto.setVillageName(previousvillageName);*/
        dto.setDate(Utility.getCurrentDateAndTime());
        dto.setActivityId(activityId);

        NewMdrSurveyDAO.getInstance().insert(dto, DBHandler.getInstance(thisActivity).getDBObject(1));

    }


    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.ns_layout_major_company_image) {
            if (lnrMajor.getVisibility() == View.VISIBLE) {
                lnrMajor.setVisibility(View.GONE);
                imgMajor.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrMajor.setVisibility(View.VISIBLE);
                imgMajor.setBackgroundResource(R.drawable.dropdown_down);
            }

        } else if (i == R.id.ns_layout_segment_type_image) {
            if (lnrSegement.getVisibility() == View.VISIBLE) {
                lnrSegement.setVisibility(View.GONE);
                imgSegment.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrSegement.setVisibility(View.VISIBLE);
                imgSegment.setBackgroundResource(R.drawable.dropdown_down);
            }

        } else if (i == R.id.ns_layout_indivial_farmers_image) {
            if (lnrIndividual.getVisibility() == View.VISIBLE) {
                lnrIndividual.setVisibility(View.GONE);
                imgIndividual.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrIndividual.setVisibility(View.VISIBLE);
                imgIndividual.setBackgroundResource(R.drawable.dropdown_down);
            }

        } else if (i == R.id.ns_layout_indivial_farmers_image_corn) {
            if (lnrIndividualCorn.getVisibility() == View.VISIBLE) {
                lnrIndividualCorn.setVisibility(View.GONE);
                imgIndiviualCorn.setBackgroundResource(R.drawable.dropdown_up);
            } else {
                lnrIndividualCorn.setVisibility(View.VISIBLE);
                imgIndiviualCorn.setBackgroundResource(R.drawable.dropdown_down);
            }

        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (isDataAvaliable()) {
            showAlertToExitScreen();
        } else {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    private boolean isDataAvaliable() {

        if (Utility.isValidStr(imagePath))
            return true;
        if (edtFarmerName.getText().toString().trim().length() > 0)
            return true;
        if (edtMobileNo.getText().toString().trim().length() > 0)
            return true;
        if (edtRiceFarming.getText().toString().trim().length() > 0)
            return true;
        if (edtRiceAcreage.getText().toString().trim().length() > 0)
            return true;

        if (spnMajComp1.getSelectedItemPosition() > 0)
            return true;
        if (edtMajComp1.getText().toString().trim().length() > 0)
            return true;
        if (spnMajComp2.getSelectedItemPosition() > 0)
            return true;
        if (edtMajComp2.getText().toString().trim().length() > 0)
            return true;
        if (spnMajComp3.getSelectedItemPosition() > 0)
            return true;
        if (edtMajComp3.getText().toString().trim().length() > 0)
            return true;
        if (spnMajComp4.getSelectedItemPosition() > 0)
            return true;
        if (edtMajComp4.getText().toString().trim().length() > 0)
            return true;
        if (spnMajComp5.getSelectedItemPosition() > 0)
            return true;
        if (edtMajComp5.getText().toString().trim().length() > 0)
            return true;

        if (edtOtherComp.getText().toString().trim().length() > 0)
            return true;
        if (edtTotalResComp.getVisibility() == View.VISIBLE) {
            if (edtTotalResComp.getText().toString().trim().length() > 0)
                return true;
        }

        if (spnMajResComp.getVisibility() == View.VISIBLE) {
            if (spnMajResComp.getSelectedItemPosition() > 0)
                return true;
        }

        if (spnPioneerHybird1Corn.getVisibility() == View.VISIBLE) {
            if (spnPioneerHybird1Corn.getSelectedItemPosition() > 0)
                return true;
        }

        if (spnPioneerHybird2Corn.getVisibility() == View.VISIBLE) {
            if (spnPioneerHybird2Corn.getSelectedItemPosition() > 0)
                return true;
        }

        if (edtPionHyb1AcresCorn.getVisibility() == View.VISIBLE) {
            if (edtPionHyb1AcresCorn.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtPionHyb2AcresCorn.getVisibility() == View.VISIBLE) {
            if (edtPionHyb2AcresCorn.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtUpLand.getVisibility() == View.VISIBLE) {
            if (edtUpLand.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtMidLand.getVisibility() == View.VISIBLE) {
            if (edtMidLand.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtMidLowLand.getVisibility() == View.VISIBLE) {
            if (edtMidLowLand.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtFineRice.getVisibility() == View.VISIBLE) {
            if (edtFineRice.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtLowLand.getVisibility() == View.VISIBLE) {
            if (edtLowLand.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtPionHybType1.getVisibility() == View.VISIBLE) {
            if (edtPionHybType1.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtPionHybType2.getVisibility() == View.VISIBLE) {
            if (edtPionHybType2.getText().toString().trim().length() > 0)
                return true;
        }

        if (edtPionHybType3.getVisibility() == View.VISIBLE) {
            if (edtPionHybType3.getText().toString().trim().length() > 0)
                return true;
        }

        return false;
    }


    private void showAlertToExitScreen() {
        AlertDialog.Builder builder = new AlertDialog.Builder(thisActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                setResult(RESULT_OK);
                finish();
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    private void getSpinnersListAndSet() {
        spnMajComp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }
                IdNameModel data = companyList.get(position);
                spnMajComp1.setTag(data);

                if (position != 0) {
                    String company1 = getCompanyName(spnMajComp1);
                    String company2 = getCompanyName(spnMajComp2);
                    String company3 = getCompanyName(spnMajComp3);
                    String company4 = getCompanyName(spnMajComp4);
                    String company5 = getCompanyName(spnMajComp5);

                    if (company2.equalsIgnoreCase(company1)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company), getString(R.string.ok));
                        spnMajComp1.setSelection(0);
                    }
                    if (company3.equalsIgnoreCase(company1)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company1), getString(R.string.ok));
                        spnMajComp1.setSelection(0);
                    }
                    if (company4.equalsIgnoreCase(company1)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company2), getString(R.string.ok));
                        spnMajComp1.setSelection(0);
                    }
                    if (company5.equalsIgnoreCase(company1)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company3), getString(R.string.ok));
                        spnMajComp1.setSelection(0);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spnMajComp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }
                IdNameModel data = companyList.get(position);
                spnMajComp2.setTag(data);
                if (position != 0) {
                    String company1 = getCompanyName(spnMajComp1);
                    String company2 = getCompanyName(spnMajComp2);
                    String company3 = getCompanyName(spnMajComp3);
                    String company4 = getCompanyName(spnMajComp4);
                    String company5 = getCompanyName(spnMajComp5);
                    if (company1.equalsIgnoreCase(company2)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company4), getString(R.string.ok));
                        spnMajComp2.setSelection(0);
                    }
                    if (company3.equalsIgnoreCase(company2)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company5), getString(R.string.ok));
                        spnMajComp2.setSelection(0);
                    }
                    if (company4.equalsIgnoreCase(company2)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company6), getString(R.string.ok));
                        spnMajComp2.setSelection(0);
                    }
                    if (company5.equalsIgnoreCase(company2)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company7), getString(R.string.ok));
                        spnMajComp2.setSelection(0);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spnMajComp3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }
                IdNameModel data = companyList.get(position);
                spnMajComp3.setTag(data);

                if (position != 0) {

                    String company1 = getCompanyName(spnMajComp1);
                    String company2 = getCompanyName(spnMajComp2);
                    String company3 = getCompanyName(spnMajComp3);
                    String company4 = getCompanyName(spnMajComp4);
                    String company5 = getCompanyName(spnMajComp5);

                    if (company1.equalsIgnoreCase(company3)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company8), getString(R.string.ok));
                        spnMajComp3.setSelection(0);
                    }
                    if (company2.equalsIgnoreCase(company3)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company9), getString(R.string.ok));
                        spnMajComp3.setSelection(0);
                    }
                    if (company4.equalsIgnoreCase(company3)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company10), getString(R.string.ok));
                        spnMajComp3.setSelection(0);
                    }
                    if (company5.equalsIgnoreCase(company3)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company11), getString(R.string.ok));
                        spnMajComp3.setSelection(0);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spnMajComp4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }
                IdNameModel data = companyList.get(position);
                spnMajComp4.setTag(data);

                if (position != 0) {

                    String company1 = getCompanyName(spnMajComp1);
                    String company2 = getCompanyName(spnMajComp2);
                    String company3 = getCompanyName(spnMajComp3);
                    String company4 = getCompanyName(spnMajComp4);
                    String company5 = getCompanyName(spnMajComp5);
                    if (company1.equalsIgnoreCase(company4)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company12), getString(R.string.ok));
                        spnMajComp4.setSelection(0);
                    }
                    if (company2.equalsIgnoreCase(company4)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company13), getString(R.string.ok));
                        spnMajComp4.setSelection(0);
                    }
                    if (company3.equalsIgnoreCase(company4)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company14), getString(R.string.ok));
                        spnMajComp4.setSelection(0);
                    }
                    if (company5.equalsIgnoreCase(company4)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company15), getString(R.string.ok));
                        spnMajComp4.setSelection(0);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spnMajComp5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }

                IdNameModel data = companyList.get(position);
                spnMajComp5.setTag(data);
                if (position != 0) {

                    String company1 = getCompanyName(spnMajComp1);
                    String company2 = getCompanyName(spnMajComp2);
                    String company3 = getCompanyName(spnMajComp3);
                    String company4 = getCompanyName(spnMajComp4);
                    String company5 = getCompanyName(spnMajComp5);
                    if (company1.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company16), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                    if (company2.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company17), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                    if (company3.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company18), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                    if (company4.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company19), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnMajResComp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }
                IdNameModel data = researchCompanyList.get(position);
                spnMajResComp.setTag(data);
             /*   if (position != 0) {

                    String company1 = ((IdNameModel) spnMajComp1.getTag()).getName();
                    String company2 = ((IdNameModel) spnMajComp2.getTag()).getName();
                    String company3 = ((IdNameModel) spnMajComp3.getTag()).getName();
                    String company4 = ((IdNameModel) spnMajComp4.getTag()).getName();
                    String company5 = ((IdNameModel) spnMajComp5.getTag()).getName();
                    if (company1.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company16), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                    if (company2.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company17), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                    if (company3.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company18), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                    if (company4.equalsIgnoreCase(company5)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_company19), getString(R.string.ok));
                        spnMajComp5.setSelection(0);
                    }
                }*/
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnPioneerHybird1Corn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }
                IdNameModel data = hybridList.get(position);
                spnPioneerHybird1Corn.setTag(data);

                if (position != 0) {
                    String hybrid1 = getCompanyName(spnPioneerHybird1Corn);//(IdNameModel) spnPioneerHybird1Corn.getTag()).getName();
                    String hybrid2 = getCompanyName(spnPioneerHybird2Corn);// ((IdNameModel) spnPioneerHybird2Corn.getTag()).getName();
                    if (hybrid2.equalsIgnoreCase(hybrid1)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_hybrid), getString(R.string.ok));
                        spnPioneerHybird1Corn.setSelection(0);
                    }

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spnPioneerHybird2Corn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                } catch (Exception ignore) {

                }

                IdNameModel data = hybridList.get(position);
                spnPioneerHybird2Corn.setTag(data);
                if (position != 0) {
                    String hybrid1 = getCompanyName(spnPioneerHybird1Corn);//(IdNameModel) spnPioneerHybird1Corn.getTag()).getName();
                    String hybrid2 = getCompanyName(spnPioneerHybird2Corn);// ((IdNameModel) spnPioneerHybird2Corn.getTag()).getName();
                    if (hybrid1.equalsIgnoreCase(hybrid2)) {
                        DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.mention_hybrid), getString(R.string.ok));
                        spnPioneerHybird2Corn.setSelection(0);
                    }

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    private String getCompanyName(Spinner spnMajComp) {
        String cmpName = "Select";
        IdNameModel idNameModel = spnMajComp.getTag() != null ? ((IdNameModel) spnMajComp.getTag()) : null;

        return idNameModel != null ? idNameModel.getName() : cmpName;
    }

    private TextWatcher totalMajorComapnyTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(final Editable s) {
            int hybridTotalPer = Utility.getNumberInt(edtMajComp1) + Utility.getNumberInt(edtMajComp2)
                    + Utility.getNumberInt(edtMajComp3) + Utility.getNumberInt(edtMajComp4) + Utility.getNumberInt(edtMajComp5)
                    + Utility.getNumberInt(edtOtherComp) + Utility.getNumberInt(edtTotalResComp);

            if(hybridTotalPer > 100){
                DialogManager.showSingleBtnPopup(thisActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        s.clear();
                    }

                    @Override
                    public void onCancelClick(View view) {

                    }
                }, getString(R.string.alert), getString(R.string.percentage_major), getString(R.string.ok));
            }
        }
    };

    private TextWatcher totalLandTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(final Editable s) {
            int segmentTotalPer = Utility.getNumberInt(edtUpLand) + Utility.getNumberInt(edtMidLand)
                    + Utility.getNumberInt(edtMidLowLand) + Utility.getNumberInt(edtFineRice) + Utility.getNumberInt(edtLowLand);

            if(segmentTotalPer > 100){
                DialogManager.showSingleBtnPopup(thisActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        s.clear();
                    }

                    @Override
                    public void onCancelClick(View view) {

                    }
                }, getString(R.string.alert), getString(R.string.percentage_segment), getString(R.string.ok));
            }
        }
    };

    private void setChange() {
        if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_DARK)) {
            tvFarmerName.setTextColor(Color.WHITE);
            tvFarmerMobile.setTextColor(Color.WHITE);
            tvRiceFarming.setTextColor(Color.WHITE);
            tvRiceAcreage.setTextColor(Color.WHITE);

            tvMajComp1.setTextColor(Color.WHITE);
            tvMajComp2.setTextColor(Color.WHITE);
            tvMajComp3.setTextColor(Color.WHITE);
            tvMajComp4.setTextColor(Color.WHITE);
            tvMajComp5.setTextColor(Color.WHITE);
            tvMajResComp.setTextColor(Color.WHITE);

            tvMajComp1Acre.setTextColor(Color.WHITE);
            tvMajComp2Acre.setTextColor(Color.WHITE);
            tvMajComp3Acre.setTextColor(Color.WHITE);
            tvMajComp4Acre.setTextColor(Color.WHITE);
            tvMajComp5Acre.setTextColor(Color.WHITE);
            tvOtherComp.setTextColor(Color.WHITE);
            tvTotalComp.setTextColor(Color.WHITE);

            tvUpLand.setTextColor(Color.WHITE);
            tvMidLand.setTextColor(Color.WHITE);
            tvMidLowLand.setTextColor(Color.WHITE);
            tvFineRice.setTextColor(Color.WHITE);
            tvLowLand.setTextColor(Color.WHITE);

            tvPionHybType1.setTextColor(Color.WHITE);
            tvPionHybType2.setTextColor(Color.WHITE);
            tvPionHybType3.setTextColor(Color.WHITE);

            tvSpnPionHyb1Corn.setTextColor(Color.WHITE);
            tvSpnPionHyb2Corn.setTextColor(Color.WHITE);
            tvPionHybAcresCorn.setTextColor(Color.WHITE);
            tvPionHyb2AcresCorn.setTextColor(Color.WHITE);

            tvColo1.setTextColor(Color.WHITE);
            tvColo2.setTextColor(Color.WHITE);
            tvColo3.setTextColor(Color.WHITE);
            tvColo4.setTextColor(Color.WHITE);
            tvColo5.setTextColor(Color.WHITE);
            tvColo6.setTextColor(Color.WHITE);
            tvColo7.setTextColor(Color.WHITE);
            tvColo8.setTextColor(Color.WHITE);
            tvColo9.setTextColor(Color.WHITE);
            tvColo10.setTextColor(Color.WHITE);
            tvColo11.setTextColor(Color.WHITE);
            tvColo12.setTextColor(Color.WHITE);
            tvColo13.setTextColor(Color.WHITE);
            tvColo14.setTextColor(Color.WHITE);
            tvColo15.setTextColor(Color.WHITE);
            tvColo16.setTextColor(Color.WHITE);
            tvColo17.setTextColor(Color.WHITE);
            tvColo18.setTextColor(Color.WHITE);
            tvColo19.setTextColor(Color.WHITE);
            tvColo20.setTextColor(Color.WHITE);
            tvColo21.setTextColor(Color.WHITE);
            tvColo22.setTextColor(Color.WHITE);
            tvColo23.setTextColor(Color.WHITE);
            tvColo31.setTextColor(Color.WHITE);
            tvColo32.setTextColor(Color.WHITE);
            spnMajComp1.setBackgroundResource(R.drawable.spinner_bg_img);
            spnMajComp2.setBackgroundResource(R.drawable.spinner_bg_img);
            spnMajComp3.setBackgroundResource(R.drawable.spinner_bg_img);
            spnMajComp4.setBackgroundResource(R.drawable.spinner_bg_img);
            spnMajComp5.setBackgroundResource(R.drawable.spinner_bg_img);
            spnMajResComp.setBackgroundResource(R.drawable.spinner_bg_img);
            spnPioneerHybird1Corn.setBackgroundResource(R.drawable.spinner_bg_img);
            spnPioneerHybird2Corn.setBackgroundResource(R.drawable.spinner_bg_img);


            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));


        } else if (Utility.getCurrentTheme(thisActivity).equals(MyConstants.THEME_LIGHT)) {
            tvFarmerName.setTextColor(Color.BLACK);
            tvFarmerMobile.setTextColor(Color.BLACK);
            tvRiceFarming.setTextColor(Color.BLACK);
            tvRiceAcreage.setTextColor(Color.BLACK);

            tvMajComp1.setTextColor(Color.BLACK);
            tvMajComp2.setTextColor(Color.BLACK);
            tvMajComp3.setTextColor(Color.BLACK);
            tvMajComp4.setTextColor(Color.BLACK);
            tvMajComp5.setTextColor(Color.BLACK);
            tvMajResComp.setTextColor(Color.BLACK);

            tvMajComp1Acre.setTextColor(Color.BLACK);
            tvMajComp2Acre.setTextColor(Color.BLACK);
            tvMajComp3Acre.setTextColor(Color.BLACK);
            tvMajComp4Acre.setTextColor(Color.BLACK);
            tvMajComp5Acre.setTextColor(Color.BLACK);
            tvOtherComp.setTextColor(Color.BLACK);
            tvTotalComp.setTextColor(Color.BLACK);

            tvUpLand.setTextColor(Color.BLACK);
            tvMidLand.setTextColor(Color.BLACK);
            tvMidLowLand.setTextColor(Color.BLACK);
            tvFineRice.setTextColor(Color.BLACK);
            tvLowLand.setTextColor(Color.BLACK);

            tvPionHybType1.setTextColor(Color.BLACK);
            tvPionHybType2.setTextColor(Color.BLACK);
            tvPionHybType3.setTextColor(Color.BLACK);

            tvSpnPionHyb1Corn.setTextColor(Color.BLACK);
            tvSpnPionHyb2Corn.setTextColor(Color.BLACK);
            tvPionHybAcresCorn.setTextColor(Color.BLACK);
            tvPionHyb2AcresCorn.setTextColor(Color.BLACK);

            tvColo1.setTextColor(Color.BLACK);
            tvColo2.setTextColor(Color.BLACK);
            tvColo3.setTextColor(Color.BLACK);
            tvColo4.setTextColor(Color.BLACK);
            tvColo5.setTextColor(Color.BLACK);
            tvColo6.setTextColor(Color.BLACK);
            tvColo7.setTextColor(Color.BLACK);
            tvColo8.setTextColor(Color.BLACK);
            tvColo9.setTextColor(Color.BLACK);
            tvColo10.setTextColor(Color.BLACK);
            tvColo11.setTextColor(Color.BLACK);
            tvColo12.setTextColor(Color.BLACK);
            tvColo13.setTextColor(Color.BLACK);
            tvColo14.setTextColor(Color.BLACK);
            tvColo15.setTextColor(Color.BLACK);
            tvColo16.setTextColor(Color.BLACK);
            tvColo17.setTextColor(Color.BLACK);
            tvColo18.setTextColor(Color.BLACK);
            tvColo19.setTextColor(Color.BLACK);
            tvColo20.setTextColor(Color.BLACK);
            tvColo21.setTextColor(Color.BLACK);
            tvColo22.setTextColor(Color.BLACK);
            tvColo23.setTextColor(Color.BLACK);
            tvColo31.setTextColor(Color.BLACK);
            tvColo32.setTextColor(Color.BLACK);


            spnMajComp1.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnMajComp2.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnMajComp3.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnMajComp4.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnMajComp5.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnMajResComp.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnPioneerHybird1Corn.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnPioneerHybird2Corn.setBackgroundResource(R.drawable.spinner_bg_img_light);
            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));

        }


    }

    @Override
    public void onStart() {
        super.onStart();
        geoLocation = null;
        if (geoLocation == null) {
            if (checkLocPermission())
                getCurrentLocation(thisActivity);
            else
                showDialogToOpenSetting();

        }

    }

    private void initializeViews() {
        mainLayout = (ScrollView) findViewById(R.id.ns_scroll_view);

        profileImage = (ImageView) findViewById(R.id.ns_profile_image);
        cameraIcon = (ImageView) findViewById(R.id.ns_profile_capture);

        tvFarmerMobile = (TextView) findViewById(R.id.ns_mobileNo_TV);
        tvFarmerName = (TextView) findViewById(R.id.ns_farmerName_TV);
        tvRiceFarming = (TextView) findViewById(R.id.ns_no_of_rice_families_TV);
        tvRiceAcreage = (TextView) findViewById(R.id.ns_rice_acreage_TV);

        edtFarmerName = (EditText) findViewById(R.id.ns_farmerName_ET);
        edtMobileNo = (EditText) findViewById(R.id.ns_mobileNo_ET);
        edtRiceFarming = (EditText) findViewById(R.id.ns_no_of_rice_families_ET);
        edtRiceAcreage = (EditText) findViewById(R.id.ns_rice_acreage_ET);

        //Major company
        tvMajComp1 = (TextView) findViewById(R.id.ns_ns_major_company1_TV);
        tvMajComp2 = (TextView) findViewById(R.id.ns_ns_major_company2_TV);
        tvMajComp3 = (TextView) findViewById(R.id.ns_ns_major_company3_TV);
        tvMajComp4 = (TextView) findViewById(R.id.ns_ns_major_company4_TV);
        tvMajComp5 = (TextView) findViewById(R.id.ns_ns_major_company5_TV);
        tvMajResComp = (TextView) findViewById(R.id.ns_major_research_company_TV);

        tvMajComp1Acre = (TextView) findViewById(R.id.ns_major_company1_acreage_TV);
        tvMajComp2Acre = (TextView) findViewById(R.id.ns_major_company2_acreage_TV);
        tvMajComp3Acre = (TextView) findViewById(R.id.ns_major_company3_acreage_TV);
        tvMajComp4Acre = (TextView) findViewById(R.id.ns_major_company4_acreage_TV);
        tvMajComp5Acre = (TextView) findViewById(R.id.ns_major_company5_acreage_TV);
        tvOtherComp = (TextView) findViewById(R.id.ns_other_company_acreage_TV);
        tvTotalComp = (TextView) findViewById(R.id.ns_total_research_acreage_TV);

        edtMajComp1 = (EditText) findViewById(R.id.ns_major_company1_acreage_ET);
        edtMajComp2 = (EditText) findViewById(R.id.ns_major_company2_acreage_ET);
        edtMajComp3 = (EditText) findViewById(R.id.ns_major_company3_acreage_ET);
        edtMajComp4 = (EditText) findViewById(R.id.ns_major_company4_acreage_ET);
        edtMajComp5 = (EditText) findViewById(R.id.ns_major_company5_acreage_ET);
        edtTotalResComp = (EditText) findViewById(R.id.ns_total_research_acreage_ET);

        edtOtherComp = (EditText) findViewById(R.id.ns_other_company_acreage_ET);

        spnMajComp1 = (Spinner) findViewById(R.id.ns_major_company1_Spn);
        spnMajComp2 = (Spinner) findViewById(R.id.ns_major_company2_Spn);
        spnMajComp3 = (Spinner) findViewById(R.id.ns_major_company3_Spn);
        spnMajComp4 = (Spinner) findViewById(R.id.ns_major_company4_Spn);
        spnMajComp5 = (Spinner) findViewById(R.id.ns_major_company5_Spn);
        spnMajResComp = (Spinner) findViewById(R.id.ns_major_research_company_Spn);
        //segement type
        tvUpLand = (TextView) findViewById(R.id.ns_upland_TV);
        tvMidLand = (TextView) findViewById(R.id.ns_midland_TV);
        tvMidLowLand = (TextView) findViewById(R.id.ns_midland_low_TV);
        tvFineRice = (TextView) findViewById(R.id.ns_fine_rice_TV);
        tvLowLand = (TextView) findViewById(R.id.ns_low_land_TV);

        edtUpLand = (EditText) findViewById(R.id.ns_upland_ET);
        edtMidLowLand = (EditText) findViewById(R.id.ns_midland_low_ET);
        edtMidLand = (EditText) findViewById(R.id.ns_midland_ET);
        edtFineRice = (EditText) findViewById(R.id.ns_fne_rice_ET);
        edtLowLand = (EditText) findViewById(R.id.ns_low_land_ET);

        // indivual
        tvPionHybType1 = (TextView) findViewById(R.id.ns_pioneer_hybird_type1_TV);
        tvPionHybType2 = (TextView) findViewById(R.id.ns_pioneer_hybird_type2_TV);
        tvPionHybType3 = (TextView) findViewById(R.id.ns_pioneer_hybird_type3_TV);
        edtPionHybType1 = (EditText) findViewById(R.id.ns_pioneer_hybird_type1_ET);
        edtPionHybType2 = (EditText) findViewById(R.id.ns_pioneer_hybird_type2_ET);
        edtPionHybType3 = (EditText) findViewById(R.id.ns_pioneer_hybird_type3_ET);

        tvSpnPionHyb1Corn = (TextView) findViewById(R.id.ns_pioneer_hybird1_corn_TV);
        tvSpnPionHyb2Corn = (TextView) findViewById(R.id.ns_pionner_hybird2_corn_TV);
        spnPioneerHybird1Corn = (Spinner) findViewById(R.id.ns_pionner_hybird1_corn_spn);
        spnPioneerHybird2Corn = (Spinner) findViewById(R.id.ns_major_pionner_hybird2_corn_spn);
        tvPionHybAcresCorn = (TextView) findViewById(R.id.ns_pioneer_hybird1_acres_corn_TV);
        tvPionHyb2AcresCorn = (TextView) findViewById(R.id.ns_pioneer_hybird2_acres_corn_TV);
        edtPionHyb1AcresCorn = (EditText) findViewById(R.id.ns_pionner_hybird1_acres_corn_ET);
        edtPionHyb2AcresCorn = (EditText) findViewById(R.id.ns_pionner_hybird2_acres_corn_ET);


        tvColo1 = (TextView) findViewById(R.id.ns_column1);
        tvColo2 = (TextView) findViewById(R.id.ns_column2);
        tvColo3 = (TextView) findViewById(R.id.ns_column3);
        tvColo4 = (TextView) findViewById(R.id.ns_column4);
        tvColo5 = (TextView) findViewById(R.id.ns_column5);
        tvColo6 = (TextView) findViewById(R.id.ns_column6);
        tvColo7 = (TextView) findViewById(R.id.ns_column7);
        tvColo8 = (TextView) findViewById(R.id.ns_column8);
        tvColo9 = (TextView) findViewById(R.id.ns_column9);
        tvColo10 = (TextView) findViewById(R.id.ns_column10);
        tvColo11 = (TextView) findViewById(R.id.ns_column11);
        tvColo12 = (TextView) findViewById(R.id.ns_column12);
        tvColo13 = (TextView) findViewById(R.id.ns_column13);
        tvColo14 = (TextView) findViewById(R.id.ns_column14);
        tvColo15 = (TextView) findViewById(R.id.ns_column15);
        tvColo16 = (TextView) findViewById(R.id.ns_column16);
        tvColo17 = (TextView) findViewById(R.id.ns_column17);
        tvColo18 = (TextView) findViewById(R.id.ns_column18);
        tvColo19 = (TextView) findViewById(R.id.ns_column19);
        tvColo20 = (TextView) findViewById(R.id.ns_column20);
        tvColo21 = (TextView) findViewById(R.id.ns_column21);
        tvColo22 = (TextView) findViewById(R.id.ns_column22);
        tvColo23 = (TextView) findViewById(R.id.ns_column23);
        tvColo31 = (TextView) findViewById(R.id.ns_column31);
        tvColo32 = (TextView) findViewById(R.id.ns_column32);


        imgMajor = (ImageView) findViewById(R.id.ns_img_major_company);
        imgSegment = (ImageView) findViewById(R.id.ns_img_segment_type);
        imgIndividual = (ImageView) findViewById(R.id.ns_img_individual_farmers);
        imgIndiviualCorn = (ImageView) findViewById(R.id.ns_img_individual_farmers_corn);


        lnrMajorImg = (LinearLayout) findViewById(R.id.ns_layout_major_company_image);
        lnrSegementImg = (LinearLayout) findViewById(R.id.ns_layout_segment_type_image);
        lnrIndividualImg = (LinearLayout) findViewById(R.id.ns_layout_indivial_farmers_image);
        lnrIndividualCornImg = (LinearLayout) findViewById(R.id.ns_layout_indivial_farmers_image_corn);


        lnrMajor = (LinearLayout) findViewById(R.id.ns_major_company1_LL);
        lnrSegement = (LinearLayout) findViewById(R.id.ns_segement_LL);
        lnrIndividual = (LinearLayout) findViewById(R.id.ns_individal_farmers_LL);
        lnrIndividualCorn = (LinearLayout) findViewById(R.id.ns_indiviual_data_corn_LL);
        lnrTotalComp = (LinearLayout) findViewById(R.id.ns_total_research_acreage_LL);
        lnrMajResComp = (LinearLayout) findViewById(R.id.ns_major_research_company);

        submitBtn = (Button) findViewById(R.id.ns_submit_btn);

        edtMobileNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edtMobileNo.length() == 1 && edtMobileNo.getText().toString().trim().equalsIgnoreCase("0")) {
                    edtMobileNo.setText("");
                }
            }
        });

        lnrIndividualImg.setOnClickListener(this);
        lnrSegementImg.setOnClickListener(this);
        lnrMajorImg.setOnClickListener(this);
        lnrIndividualImg.setOnClickListener(this);
        lnrIndividualCornImg.setOnClickListener(this);


    }

    protected void getCurrentLocation(final Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (mGoogleApiClient != null) {
                if (mGoogleApiClient.isConnected()) {
                    mGoogleApiClient.disconnect();
                }
                mGoogleApiClient.connect();
            }
            CountDownTimer start = new CountDownTimer(COUNT_DOWN_TIME, COUNT_DOWN_TIME_INTERVAL) {

                @Override
                public void onTick(long millisUntilFinished) {
                    if (geoLocation != null) {
                        latLongValues = geoLocation;
//                        onLocationCompleted(latLongValues);
//                        locationEt.setText(latLongValues);
                        hideProgressDialog();

                        this.cancel();
                    }
                }

                @Override
                public void onFinish() {
                    hideProgressDialog();
                    this.cancel();
                }
            }.start();
        } else {
            DialogManager.showSingleBtnPopup(thisActivity, null, getString(R.string.alert), getString(R.string.gps), getString(R.string.ok));
        }
    }

    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(thisActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(thisActivity, getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {
        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        finish();
    }

    private void openOptionsDialog() {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(thisActivity, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                //Location Permission already granted
                cameraPermission();
            } else {
                //Request Location Permission
                checkLocationPermission();
            }
        } else {
            cameraPermission();
        }
    }

    private void cameraPermission() {
        File newfile = createFile();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkPermission()) {
                if (!Utility.isValidStr(imagePath)) {
                    openCameraApp(newfile);
                } else {
                    showOptionOpenCameraforNewSurvey(null, thisActivity, newfile);
                }
            }
        } else {
            if (!Utility.isValidStr(imagePath)) {
                openCameraApp(newfile);
            } else {
                showOptionOpenCameraforNewSurvey(null, thisActivity, newfile);
            }
        }
    }

    private File createFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        myDir = new File(root + File.separator + "SurveyFarmerImage");
        if (!myDir.exists())
            myDir.mkdirs();

        File newfile = new File(myDir, "IMG_" + System.currentTimeMillis() + ".JPG");
        try {
            newfile.createNewFile();
        } catch (IOException e) {
        }
        return newfile;
    }

    private boolean checkLocPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(thisActivity, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public void openCameraApp(File newfile) {
        Uri outputFileUri = Uri.fromFile(newfile);
        String uriString = outputFileUri.toString();

        Intent intent = new Intent(thisActivity, MainActivityOC.class);
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE); // without this not working, not getting data only
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        startActivityForResult(intent, OPENCAMERA);
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(thisActivity,
                                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }


    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(thisActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(thisActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(thisActivity, Manifest.permission.CAMERA) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(thisActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(thisActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(thisActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));

            } else {
                // No explanation needed, we can request the permission.
                if (Utility.isFirstTimeCamera(thisActivity)) {

                    DialogManager.showConformPopup(thisActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            Utility.setFirstTimeCamera(false, thisActivity);
                            ActivityCompat.requestPermissions(thisActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, "Camera and Storage Permissions", "App needs camera and storage permission to capture/browse and upload equipment images.", getString(R.string.ok), getString(R.string.cancel));


                } else {
                    ActivityCompat.requestPermissions(thisActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }

        return false;
    }


    private void showOptionOpenCameraforNewSurvey(String title, final FragmentActivity context, final File newfile) {
        final Dialog mDialog;
        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.paravakta_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mREmovePhoto, mViewPhoto;
        Button mCancel;
        TextView mTitile = (TextView) mDialog.findViewById(R.id.alertTitle);
        if (Utility.isValidStr(title))
            mTitile.setText(title);
        mFromCamera = (TextView) mDialog.findViewById(R.id.from_camera);
        mREmovePhoto = (TextView) mDialog.findViewById(R.id.remove_photo);
        mViewPhoto = (TextView) mDialog.findViewById(R.id.view_image);
        mCancel = (Button) mDialog.findViewById(R.id.cancel);

        mFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                openCameraApp(newfile);
            }
        });
        mREmovePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                profileImage.setImageResource(R.drawable.img_profile_avatar);
                uriStr = null;
                imagePath = null;
            }
        });

        mViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                if (profileImage.getDrawable() != null) {
                    if (uriStr != null) {
                        ImageViewer(thisActivity, uriStr.toString());
                    }
                }
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == OPENCAMERA) {
            if (resultCode == RESULT_OK) {
                try {
                    mExecutor = Executors.newSingleThreadExecutor();
                    Uri myUri = (Uri) data.getExtras().get("data");
                    uriStr = myUri;
                    mExecutor.submit(new NewSurveyActivity.LoadScaledImageTask(thisActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                    imagePath = myUri.toString();
                } catch (Exception ignore) {

                }

                /*try {
//                    uriStr = (Uri) data.getExtras().get("data");
                    Uri uriStrTremp = (Uri) data.getExtras().get("data");  // if we captured new pic but not cropped, thn showing old pic in imageView but when we click on see full photo thn new pic is shown. thats why created local variable

                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uriStrTremp);

                    if (bitmap != null) {
                        String imagePath = storeImage(bitmap, "survey_profile" + "_");
                        Uri mCapturedUri = Uri.fromFile(new File(imagePath));

                        Intent gotoCropImage = new Intent(thisActivity, ATCropMyImageActivity.class);
                        gotoCropImage.setData(uriStrTremp);
                        startActivityForResult(gotoCropImage, REQUEST_CODE_FOR_IMAGE_CROPPING);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }*/
            } else if (resultCode == RESULT_CANCELED) {
                DialogManager.showToast(thisActivity, getString(R.string.user_cancelled_image_capture));
            } else {
                DialogManager.showToast(thisActivity, getString(R.string.failed_to_capture_image));
            }
        } else if (requestCode == REQUEST_CODE_FOR_IMAGE_CROPPING) {
            if (resultCode == RESULT_OK) {
                mExecutor = Executors.newSingleThreadExecutor();
                Uri myUri = data.getData();
                uriStr = myUri;
                mExecutor.submit(new NewSurveyActivity.LoadScaledImageTask(thisActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                imagePath = myUri.toString();
            } else if (resultCode == RESULT_CANCELED) {

                DialogManager.showToast(thisActivity, getString(R.string.at_user_cancelled_image_cropping));
            }
        }
    }

    private String storeImage(Bitmap image, String fileName) {
        File pictureFile = getOutputMediaFile(fileName);
        if (pictureFile == null) {
            // Log.d(TAG,
            // "Error creating media file, check storage permissions: ");//
            // e.getMessage());
            return "";
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.JPEG, 80, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            // Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            // Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
        System.out.println("Path:" + pictureFile.getAbsolutePath());
        return pictureFile.getAbsolutePath();
    }

    private File getOutputMediaFile(String fileName) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(
                Environment.getExternalStorageDirectory() + "/Android/data/"
                        + getPackageName() + "/Files");

        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }

        File mediaFile;
        String mImageName = "ActivityTracker_" + fileName + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator
                + mImageName);
        return mediaFile;
    }

    private int calcImageSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        Display display = getWindowManager().getDefaultDisplay();
        display.getMetrics(metrics);
        return Math.min(Math.max(metrics.widthPixels, metrics.heightPixels), 2048);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            //ProfileImageSelectionUtil.showOption(null, mActivity);
                            openCameraApp(newfile);
                        else
                            checkPermission();
                    } else {
                        openCameraApp(newfile);
                        //ProfileImageSelectionUtil.showOption(null, mActivity);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }

            }
            break;
            case REQUEST_CAMERA_PERMISSION_DENAIL: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            openCameraApp(newfile);
                        else
                            showDialogToOpenSetting();
                    } else {

                        openCameraApp(newfile);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    showDialogToOpenSetting();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
            break;

            // other 'case' lines to check for other
            // permissions this app might request
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(thisActivity,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient != null) {
                            mGoogleApiClient.connect();
                        } else {
                            buildGoogleApiClient();
                            mGoogleApiClient.connect();
                        }
                    }
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(thisActivity, "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }

    public static class LoadScaledImageTask implements Runnable {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        Context context;
        Uri uri;
        ImageView imageView;
        int width;

        public LoadScaledImageTask(Context context, Uri uri, ImageView imageView, int width) {
            this.context = context;
            this.uri = uri;
            this.imageView = imageView;
            this.width = width;
        }

        @Override
        public void run() {
            final int exifRotation = com.isseiaoki.simplecropview.util.Utils.getExifOrientation(context, uri);
            int maxSize = com.isseiaoki.simplecropview.util.Utils.getMaxSize();
            int requestSize = Math.min(width, maxSize);
            try {
                final Bitmap sampledBitmap = com.isseiaoki.simplecropview.util.Utils.decodeSampledBitmapFromUri(context, uri, requestSize);
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        imageView.setImageMatrix(com.isseiaoki.simplecropview.util.Utils.getMatrixFromExifOrientation(exifRotation));
                        imageView.setImageBitmap(sampledBitmap);
                    }
                });
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void refresh() {

        latLongValues = geoLocation;
//        onLocationCompleted(latLongValues);
//        locationEt.setText(latLongValues);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
