package com.activitytrack.models;

import java.util.List;

/**
 * Created by fatima.t on 04-12-2018.
 */

public class SegmentationMasterDataModel {
    private List<IdNameModel> years;
    private List<IdNameModel> season;
    private List<IdNameModel> crop;
    private List<IdNameModel> grainHybrid;
    private List<IdNameModel> silageHybrid;
    private List<IdNameModel> grainFarmerServicesList;
    private List<IdNameModel> silageFarmerServicesList;

    //newly added
    private List<IdNameModel> riceHybrid;
    private List<IdNameModel> riceFarmerServicesList;
    private List<IdNameModel> divisionList;
    private List<IdNameModel> schoolList;
    public List<IdNameModel> getSeason() {
        return season;
    }

    public void setSeason(List<IdNameModel> season) {
        this.season = season;
    }

    public List<IdNameModel> getCrop() {
        return crop;
    }

    public void setCrop(List<IdNameModel> crop) {
        this.crop = crop;
    }

    public List<IdNameModel> getGrainFarmerServicesList() {
        return grainFarmerServicesList;
    }

    public void setGrainFarmerServicesList(List<IdNameModel> grainFarmerServicesList) {
        this.grainFarmerServicesList = grainFarmerServicesList;
    }

    public List<IdNameModel> getSilageFarmerServicesList() {
        return silageFarmerServicesList;
    }

    public void setSilageFarmerServicesList(List<IdNameModel> silageFarmerServicesList) {
        this.silageFarmerServicesList = silageFarmerServicesList;
    }

    public List<IdNameModel> getGrainHybrid() {
        return grainHybrid;
    }

    public void setGrainHybrid(List<IdNameModel> grainHybrid) {
        this.grainHybrid = grainHybrid;
    }

    public List<IdNameModel> getSilageHybrid() {
        return silageHybrid;
    }

    public void setSilageHybrid(List<IdNameModel> silageHybrid) {
        this.silageHybrid = silageHybrid;
    }

    public List<IdNameModel> getYears() {
        return years;
    }

    public void setYears(List<IdNameModel> years) {
        this.years = years;
    }

    public List<IdNameModel> getRiceHybrid() {
        return riceHybrid;
    }

    public void setRiceHybrid(List<IdNameModel> riceHybrid) {
        this.riceHybrid = riceHybrid;
    }

    public List<IdNameModel> getRiceFarmerServicesList() {
        return riceFarmerServicesList;
    }

    public void setRiceFarmerServicesList(List<IdNameModel> riceFarmerServicesList) {
        this.riceFarmerServicesList = riceFarmerServicesList;
    }

    public List<IdNameModel> getDivisionList() {
        return divisionList;
    }

    public void setDivisionList(List<IdNameModel> divisionList) {
        this.divisionList = divisionList;
    }

    public List<IdNameModel> getSchoolList() {
        return schoolList;
    }

    public void setSchoolList(List<IdNameModel> schoolList) {
        this.schoolList = schoolList;
    }
}
