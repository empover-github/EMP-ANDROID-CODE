package com.activitytrack.activity;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.activitytrack.adapter.GerminationVerficationListAdapter;
import com.activitytrack.daos.GerminationListDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.listeners.OnListItemClickListener;

import java.util.List;

import static android.app.Activity.RESULT_OK;

public class GerminationVerificationFragment extends BaseFragment implements OnListItemClickListener {
    private View view;
    private RecyclerView recyclerView;
    private TextView noDataTxt;

    private List<GerminationverificationListDTO> gerPendingList;
    private GerminationVerficationListAdapter listAdapter;
    private static final int NEXT_SCREEN_REQUEST_CODE = 101;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.germination_verification_list_fragment, container, false);

        gerPendingList = GerminationListDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getDBObject(0));

        recyclerView = (RecyclerView)view.findViewById(R.id.gv_recycler_view);
        noDataTxt = (TextView) view.findViewById(R.id.gv_no_data_txt);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity);
        layoutManager.setAutoMeasureEnabled(true);
        recyclerView.setLayoutManager(layoutManager);
        listAdapter = new GerminationVerficationListAdapter(mActivity, gerPendingList, this);
        recyclerView.setAdapter(listAdapter);
        showHideViews();
        return view;
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        mActivity.onBackPressedCallBack(callbackCode);
        return true;
    }
    private void showHideViews() {
        if (gerPendingList.size() > 0 && gerPendingList != null) {
            noDataTxt.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            noDataTxt.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        int i = view.getId();
        if (i == R.id.gvl_parentLL ||  i == R.id.gvl_verifyTvBtn) {
            GerminationverificationListDTO dto = (GerminationverificationListDTO) view.getTag();
            // go to verification activity
            if (dto != null) {
                Intent gotoVerifictaion = new Intent(mActivity, GerminationVerifyActivity.class);
                gotoVerifictaion.putExtra(GerminationVerifyActivity.EXTRA_MODEL_DATA, dto);
                startActivityForResult(gotoVerifictaion, NEXT_SCREEN_REQUEST_CODE);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == NEXT_SCREEN_REQUEST_CODE) {

            if (resultCode == RESULT_OK ){
                gerPendingList.clear();
                gerPendingList.addAll(GerminationListDAO.getInstance().getAllRecords(DBHandler.getInstance(mActivity).getDBObject(0)));
                listAdapter = new GerminationVerficationListAdapter(mActivity, gerPendingList, this);
                recyclerView.setAdapter(listAdapter);
//                listAdapter.notifyDataSetChanged();
                showHideViews();
            }

        }
    }
}
