package com.activitytrack.masterdtos;

import com.activitytrack.dtos.DTO;
 
public class TargetAgronomyDTO implements  DTO
{
	private long id; 
	private long seasonId; 
	private long cropId;
	private long hybridId; 
	private long targetSample;  
	private String date;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getSeasonId() {
		return seasonId;
	}
	public void setSeasonId(long seasonId) {
		this.seasonId = seasonId;
	}
	public long getCropId() {
		return cropId;
	}
	public void setCropId(long cropId) {
		this.cropId = cropId;
	}
	public long getHybridId() {
		return hybridId;
	}
	public void setHybridId(long hybridId) {
		this.hybridId = hybridId;
	}
	public long getTargetSample() {
		return targetSample;
	}
	public void setTargetSample(long targetSample) {
		this.targetSample = targetSample;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
}
