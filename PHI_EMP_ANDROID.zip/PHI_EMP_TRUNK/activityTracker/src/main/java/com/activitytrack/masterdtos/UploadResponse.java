package com.activitytrack.masterdtos;

import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.dtos.UploadedVillageListDTO;
import com.activitytrack.dtos.UpLoadPravaktaFileDTO;

import java.util.List;

/**
 * Created by Yakaswamy.g on 3/13/2018.
 */

public class UploadResponse {

    private int code;
    private String message;
    private boolean dataDownloadRequired;

    private List<UpLoadPravaktaFileDTO> pravaktaVillageHaGainResponse;
    private List<UpLoadPravaktaFileDTO> villageProfileResponse;
    private List<UpLoadPravaktaFileDTO> farmerSegmentationResponse;
    private long villageProfileCount;
    private List<UploadedVillageListDTO> villageProfileUploadedData;
    private List<GerminationverificationListDTO> germinationPendingVerificationList;

    private String serverId;
    private String mobileId;
    private String type;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<UpLoadPravaktaFileDTO> getPravaktaVillageHaGainResponse() {
        return pravaktaVillageHaGainResponse;
    }

    public void setPravaktaVillageHaGainResponse(List<UpLoadPravaktaFileDTO> pravaktaVillageHaGainResponse) {
        this.pravaktaVillageHaGainResponse = pravaktaVillageHaGainResponse;
    }

    public boolean isDataDownloadRequired() {
        return dataDownloadRequired;
    }

    public void setDataDownloadRequired(boolean dataDownloadRequired) {
        this.dataDownloadRequired = dataDownloadRequired;
    }

    public String getServerId() {
        return serverId;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public String getMobileId() {
        return mobileId;
    }

    public void setMobileId(String mobileId) {
        this.mobileId = mobileId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<UpLoadPravaktaFileDTO> getVillageProfileResponse() {
        return villageProfileResponse;
    }

    public void setVillageProfileResponse(List<UpLoadPravaktaFileDTO> villageProfileResponse) {
        this.villageProfileResponse = villageProfileResponse;
    }

    public long getVillageProfileCount() {
        return villageProfileCount;
    }

    public void setVillageProfileCount(long villageProfileCount) {
        this.villageProfileCount = villageProfileCount;
    }

    public List<UploadedVillageListDTO> getVillageProfileUploadedData() {
        return villageProfileUploadedData;
    }

    public void setVillageProfileUploadedData(List<UploadedVillageListDTO> villageProfileUploadedData) {
        this.villageProfileUploadedData = villageProfileUploadedData;
    }

    public List<GerminationverificationListDTO> getGerminationPendingVerificationList() {
        return germinationPendingVerificationList;
    }

    public void setGerminationPendingVerificationList(List<GerminationverificationListDTO> germinationPendingVerificationList) {
        this.germinationPendingVerificationList = germinationPendingVerificationList;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<UpLoadPravaktaFileDTO> getFarmerSegmentationResponse() {
        return farmerSegmentationResponse;
    }

    public void setFarmerSegmentationResponse(List<UpLoadPravaktaFileDTO> farmerSegmentationResponse) {
        this.farmerSegmentationResponse = farmerSegmentationResponse;
    }
}
