package com.activitytrack.dtos;

public class VersionDTO  {
	   private String appVersionCode;
	    private String appVersionName;
	    private String updatedDate;
	    private String deviceType;
	    private String releaseFeature;
	    private boolean forceUpdate;
	    private boolean mandatoryUpdate;
	  
		public String getAppVersionCode() {
			return appVersionCode;
		}
		public String getAppVersionName() {
			return appVersionName;
		}
		public String getUpdatedDate() {
			return updatedDate;
		}
		public String getDeviceType() {
			return deviceType;
		}
		public String getReleaseFeature() {
			return releaseFeature;
		}
		 
		public void setAppVersionCode(String appVersionCode) {
			this.appVersionCode = appVersionCode;
		}
		public void setAppVersionName(String appVersionName) {
			this.appVersionName = appVersionName;
		}
		public void setUpdatedDate(String updatedDate) {
			this.updatedDate = updatedDate;
		}
		public void setDeviceType(String deviceType) {
			this.deviceType = deviceType;
		}
		public void setReleaseFeature(String releaseFeature) {
			this.releaseFeature = releaseFeature;
		}
		public boolean isForceUpdate() {
			return forceUpdate;
		}
		public boolean isMandatoryUpdate() {
			return mandatoryUpdate;
		}
		public void setForceUpdate(boolean forceUpdate) {
			this.forceUpdate = forceUpdate;
		}
		public void setMandatoryUpdate(boolean mandatoryUpdate) {
			this.mandatoryUpdate = mandatoryUpdate;
		}
		 

}
