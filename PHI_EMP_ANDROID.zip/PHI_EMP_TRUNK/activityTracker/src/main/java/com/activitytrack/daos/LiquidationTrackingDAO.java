package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.LiquidationTrackingDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class LiquidationTrackingDAO implements DAO
{

	private final String TAG = "LiquidDAO";
    private static LiquidationTrackingDAO liquidationTrackingDAO;

    
    public static LiquidationTrackingDAO getInstance()
    {
        if (liquidationTrackingDAO == null)
        {
        	liquidationTrackingDAO = new LiquidationTrackingDAO();
        }
        
        return liquidationTrackingDAO;
    }

    /**
     * delete the Data
     */

	@Override
	public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
		 
		return false;
	}

	 /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */

	@Override
	public List<DTO> getRecordInfoByValue(String columnName,
			String columnValue, SQLiteDatabase dbObject) 
			{
		 
		List<DTO> liquidationTrackingInfo =new ArrayList<DTO>();
		Cursor cursor=null;
		try
		{
			if(!( columnName !=null && columnName.length() >0))
				columnName="id";
			
			cursor=dbObject.rawQuery("SELECT * FROM WHERE  LIQUIDATION_TRACKING "+columnName+"='"+columnName+"' ",null);
			
			if(cursor.getCount()>0)
			{
				cursor.moveToFirst();
				
				do{

			          /*LIQUIDATION_TRACKING	
			    	  id
			    	  crop
			    	  salesDate 
			    	  retailerName
			    	  retailerMobileNo
			    	  pinCode
			    	  season
			    	  pioneerSales
			    	  competitor1Sales
			    	  competitor2Sales
			    	  otherSales
			    	  location
	                  isSync
			    	  */
			      LiquidationTrackingDTO dto=new LiquidationTrackingDTO();
			      
			      dto.setId(cursor.getLong(0));
			      dto.setCrop(cursor.getString(1));
			      dto.setSalesDate(cursor.getString(2));
			      dto.setRetailerName(cursor.getString(3));
			      dto.setRetailerMobileNo(cursor.getLong(4));
			      dto.setPinCode(cursor.getInt(5));
			      dto.setSeason(cursor.getInt(6));
			      dto.setPioneerSales(cursor.getInt(7));
			      dto.setCompetitor1Sales(cursor.getInt(8));
			      dto.setCompetitor2Sales(cursor.getInt(9));
			      dto.setOtherSales(cursor.getInt(10));
			      dto.setLocation(cursor.getString(11));
                  dto.setIsSync(cursor.getInt(12));
                 
                  liquidationTrackingInfo.add(dto);
					
				}while(cursor.moveToNext());
			}
			
			
		}catch(Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		}finally 
		{
		
		 if (cursor != null && !cursor.isClosed())
         {
             cursor.close();
         }
         dbObject.close();
		}
		return liquidationTrackingInfo;
	}
	 
	
	
	/**
     * Gets all the records from the database
     *
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
	@Override
	public List<DTO> getRecords(SQLiteDatabase dbObject)
	{
		List<DTO> liquationTrackingInfo =new ArrayList<DTO>();
		
		Cursor cursor=null;
		
		try
		 {
			cursor =dbObject.rawQuery("SELECT * FROM LIQUIDATION_TRACKING ",null);
			if(cursor.getCount()>0)
			{
				cursor.moveToFirst();
				
				do{
					LiquidationTrackingDTO dto=new LiquidationTrackingDTO();
					
					   
				      dto.setId(cursor.getLong(0));
				      dto.setCrop(cursor.getString(1));
				      dto.setSalesDate(cursor.getString(2));
				      dto.setRetailerName(cursor.getString(3));
				      dto.setRetailerMobileNo(cursor.getLong(4));
				      dto.setPinCode(cursor.getInt(5));
				      dto.setSeason(cursor.getInt(6));
				      dto.setPioneerSales(cursor.getInt(7));
				      dto.setCompetitor1Sales(cursor.getInt(8));
				      dto.setCompetitor2Sales(cursor.getInt(9));
				      dto.setOtherSales(cursor.getInt(10));
				      dto.setLocation(cursor.getString(11));
	                  dto.setIsSync(cursor.getInt(12));
	              
					
				 
				}while(cursor.moveToNext());
			}
		 }catch (Exception e) {
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		}finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }
		 
		return liquationTrackingInfo;
	}

	
	  
    public List<LiquidationTrackingDTO> getRecordsForUpload(SQLiteDatabase dbObject)
    {
        List<LiquidationTrackingDTO>  liquidationTrackingInfo = new ArrayList<LiquidationTrackingDTO>();
        Cursor cursor = null;
        
        try
        {
            cursor = dbObject.rawQuery("SELECT * FROM  LIQUIDATION_TRACKING where isSync = 1", null);
            
            if (cursor.getCount() > 0)
            {
            	
                cursor.moveToFirst();
                do
                {
                	LiquidationTrackingDTO dto = new LiquidationTrackingDTO();
                	 
                	  dto.setId(cursor.getLong(0));
				      dto.setCrop(cursor.getString(1));
				      dto.setSalesDate(cursor.getString(2));
				      dto.setRetailerName(cursor.getString(3));
				      dto.setRetailerMobileNo(cursor.getLong(4));
				      dto.setPinCode(cursor.getInt(5));
				      dto.setSeason(cursor.getInt(6));
				      dto.setPioneerSales(cursor.getInt(7));
				      dto.setCompetitor1Sales(cursor.getInt(8));
				      dto.setCompetitor2Sales(cursor.getInt(9));
				      dto.setOtherSales(cursor.getInt(10));
				      dto.setLocation(cursor.getString(11));
	                  dto.setIsSync(cursor.getInt(12));
	              

                    liquidationTrackingInfo.add(dto);

                } while (cursor.moveToNext());
            } 
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return  liquidationTrackingInfo;
    }

	
	/**
     * Inserts the data in the SQLite database
     * 
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
  
	
	@Override
	public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) 
	
	{
		try
		{
			LiquidationTrackingDTO dto= (LiquidationTrackingDTO) dtoObject;
			
			ContentValues cValues=new ContentValues();
			  
			/*LIQUIDATION_TRACKING	
	    	  id
	    	  crop
	    	  salesDate 
	    	  retailerName
	    	  retailerMobileNo
	    	  pinCode
	    	  season
	    	  pioneerSales
	    	  competitor1Sales
	    	  competitor2Sales
	    	  otherSales
	    	  location
               isSync
	    	  */
	      
	      cValues.put("crop", dto.getCrop());
	      cValues.put("salesDate ",dto.getSalesDate());
	      cValues.put("retailerName",dto.getRetailerName());
	      cValues.put("retailerMobileNo",dto.getRetailerMobileNo());
	      cValues.put("pinCode",dto.getPinCode());
	      cValues.put("season",dto.getSeason());
	      cValues.put("pioneerSales",dto.getPioneerSales());
	      cValues.put("competitor1Sales",dto.getCompetitor1Sales());
	      cValues.put("competitor2Sales",dto.getCompetitor2Sales());
	      cValues.put("otherSales",dto.getOtherSales());
	      cValues.put("location", dto.getLocation());
          cValues.put("isSync", dto.getIsSync());
		
		dbObject.insert("LIQUIDATION_TRACKING", null, cValues);
		return true;
		
		}catch(SQLException e)
		{
			ATBuildLog.e(TAG +"insert()",e.getMessage());
			return false;
		}finally{
			dbObject.close();
		}
		 
		
	}
	 
	/**
     * Updates the data in the SQLite
     * 
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
   
	@Override
	public boolean update(DTO dtoObject, SQLiteDatabase dbObject) 
	{
        try{
        	
        	LiquidationTrackingDTO dto=new LiquidationTrackingDTO();
        	ContentValues cValues=new ContentValues();
        	
         
        	
        	if(dto.getCrop()!=null)
        		cValues.put("crop", dto.getCrop());	
        	
        	if(dto.getSalesDate()!=null)
        		cValues.put("salesDate ",dto.getSalesDate());	
        	
        	if(dto.getRetailerName()!=null)
        		 cValues.put("retailerName",dto.getRetailerName());
        	
        	if(dto.getRetailerMobileNo()!=0)
        		cValues.put("retailerMobileNo",dto.getRetailerMobileNo());
        	
        	if(dto.getPinCode()!=0)
        		 cValues.put("pinCode",dto.getPinCode());
        	
        	if(dto.getSeason()!=0)
        		 cValues.put("season",dto.getSeason());
        	
        	if(dto.getPioneerSales()!=0)
        		 cValues.put("pioneerSales",dto.getPioneerSales());
        	
        	if(dto.getCompetitor1Sales()!=0)
        		 cValues.put("competitor1Sales",dto.getCompetitor1Sales());
        	
        	if(dto.getCompetitor2Sales()!=0)
       		 cValues.put("competitor2Sales",dto.getCompetitor2Sales());
        	
        	if(dto.getOtherSales()!=0)
        		 cValues.put("otherSales",dto.getOtherSales());
        	
        	if(dto.getLocation() != null)
        		cValues.put("location", dto.getLocation());
        	
            cValues.put("isSync", dto.getIsSync());
           
            dbObject.update("LIQUIDATION_TRACKING", cValues, "id='" +dto.getId()+"' ", null);
           
            return true;
        }catch(Exception e)
        {
			ATBuildLog.e(TAG +"upadte()",e.getMessage());
        	e.printStackTrace();
        }finally{
        	
        	dbObject.close();
        }
		return false;
	}

	   /**
     * Deletes all the table Data from SQLite
     * 
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM  LIQUIDATION_TRACKING").execute();
            return true;
        } catch (Exception e)
        {
			ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("delete from LIQUIDATION_TRACKING where id='"+id+"'");
			return true;
		}catch(Exception e)
		{
			ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally
		
		{
		
		dbObject.close();
		
		}
		return false;
	}

	public boolean isDataAvailForUpload(SQLiteDatabase dbObject)
	{
		Cursor cursor = null;
		try
		{
			cursor = dbObject.rawQuery("SELECT count(id) FROM LIQUIDATION_TRACKING where isSync = 1", null);
			if (cursor.getCount() > 0)
			{
				cursor.moveToFirst();
				return cursor.getLong(0) > 0;
			}
		} catch (Exception e)
		{
			ATBuildLog.e(TAG + "getRecords()", e.getMessage());
		} finally
		{
			if (cursor != null && !cursor.isClosed())
			{
				cursor.close();
			}
			dbObject.close();
		}

		return  false;
	}

}
