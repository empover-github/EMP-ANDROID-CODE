package com.activitytrack.utility;

import android.util.Log;

import com.activitytrack.activity.BuildConfig;

/**
 * Created by fatima.t on 27-02-2018.
 */

public class ATBuildLog {
    private static final boolean displayLog = BuildConfig.at_print_log;

    public static void i(String tag, String message){
        if(displayLog)
            Log.i(tag, message);
    }

    public static void d(String tag, String message){
        if(displayLog)
            Log.d(tag, message);
    }
    public static void e(String tag, String message){
        if(displayLog)
            Log.e(tag, message);
    }
    public static void e(String tag, String message, Exception e){
        if(displayLog)
            Log.e(tag, message, e);
    }
    public static void w(String tag, String message){
        if(displayLog)
            Log.w(tag, message);
    }
    public static void w(String tag, String message, Exception e){
        if(displayLog)
            Log.w(tag, message, e);
    }

    public static void v(String tag, String message){
        if(displayLog)
            Log.e(tag, message);
    }
}
