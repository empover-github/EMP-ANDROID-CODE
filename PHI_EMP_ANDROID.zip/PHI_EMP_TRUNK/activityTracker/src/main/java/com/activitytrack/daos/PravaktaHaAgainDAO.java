package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.PravaktaFarmerDTO;
import com.activitytrack.dtos.PravaktaHaGainDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rambabu.a on 26-02-2018.
 */

public class PravaktaHaAgainDAO implements DAO {
    private final String TAG = "PravaktaHaAgainDAO";
    private static PravaktaHaAgainDAO pravaktaHaAgainDAO;

    public static PravaktaHaAgainDAO getInstance() {
        if (pravaktaHaAgainDAO == null) {
            pravaktaHaAgainDAO = new PravaktaHaAgainDAO();
        }

        return pravaktaHaAgainDAO;
    }

    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }


    public long insertActivity(DTO dtoObject, SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {

          /*
                  pravaktaName
                    mobileNo
                    villageName
                    pincode
                    imageUrlPath
                    blockName
                    districtName
                    previousYear
                    currentYear
                    totalPreviousAcres
                    totalPresentAcres
                    phiPreviousAcres
                    phiPresentAcres
                    targetPreviousAcres
                    targetPresentAcres
                    rice
                    corn
                    millet
                    mustard
                    targetHybrid
                    blockType
                    isSync

           */

            PravaktaHaGainDTO dto = (PravaktaHaGainDTO) dtoObject;
            ContentValues cValues = new ContentValues();
            cValues.put("pravaktaName", dto.getPravaktaName());
            cValues.put("mobileNo", dto.getMobileNo());
            cValues.put("villageName", dto.getVillageName());
            cValues.put("pincode", dto.getPincode());
            cValues.put("imageUrlPath", dto.getImageUrlPath());
            cValues.put("blockName", dto.getBlockName());
            cValues.put("districtName", dto.getDistrictName());
            cValues.put("previousYear", dto.getPreviousYear());
            cValues.put("currentYear", dto.getCurrentYear());
            cValues.put("totalPreviousAcres", dto.getTotalPreviousAcres());
            cValues.put("totalPresentAcres", dto.getTotalPresentAcres());
            cValues.put("phiPreviousAcres", dto.getPhiPreviousAcres());
            cValues.put("phiPresentAcres", dto.getPhiPresentAcres());
            cValues.put("targetPreviousAcres", dto.getTargetPreviousAcres());
            cValues.put("targetPresentAcres", dto.getTargetPresentAcres());
            cValues.put("rice", String.valueOf(dto.isRice()));
            cValues.put("corn", String.valueOf(dto.isCorn()));
            cValues.put("millet", String.valueOf(dto.isMillet()));
            cValues.put("mustard", String.valueOf(dto.isMustard()));
            cValues.put("targetHybrid", dto.getTargetHybrid());
            cValues.put("blockType", dto.getBlockType());
//            cValues.put("villageType", dto.getVillageType());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("location", dto.getGeoLocation());
            long insertedRow = dbObject.insert("PRAVAKTA_HA_AGAIN", null, cValues);
            if (insertedRow > 0) {
                cursor = dbObject.rawQuery("SELECT MAX(id) FROM  PRAVAKTA_HA_AGAIN", null);
                if (cursor.getCount() > 0) {
                    cursor.moveToFirst();
                    return cursor.getLong(0);
                }
            }

            return -1;
        } catch (SQLException e) {
            Log.e(TAG + "insert()", e.getMessage());
            return -1;
        } finally {
            if (cursor != null)
                cursor.close();
            dbObject.close();
        }

    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            PravaktaHaGainDTO dto = (PravaktaHaGainDTO) dtoObject;

            ContentValues cValues = new ContentValues();
            if (dto.getPravaktaName() != null)
                cValues.put("pravaktaName", dto.getPravaktaName());

            if (dto.getMobileNo() != null)
                cValues.put("mobileNo", dto.getMobileNo());

            if (dto.getVillageName() != null)
                cValues.put("villageName", dto.getVillageName());


            if (dto.getPincode() != null)
                cValues.put("pincode", dto.getPincode());

            if (dto.getImageUrlPath() != null)
                cValues.put("imageUrlPath", dto.getImageUrlPath());

            if (dto.getBlockName() != null)
                cValues.put("blockName", dto.getBlockName());

            if (dto.getDistrictName() != null)
                cValues.put("districtName", dto.getDistrictName());

            if (dto.getPreviousYear() != null)
                cValues.put("previousYear", dto.getPreviousYear());

            if (dto.getCurrentYear() != null)
                cValues.put("currentYear", dto.getCurrentYear());

            if (dto.getTotalPreviousAcres() != null)
                cValues.put("totalPreviousAcres", dto.getTotalPreviousAcres());

            if (dto.getTotalPresentAcres() != null)
                cValues.put("totalPresentAcres", dto.getTotalPresentAcres());

            if (dto.getPhiPreviousAcres() != null)
                cValues.put("phiPreviousAcres", dto.getPhiPreviousAcres());

            if (dto.getPhiPresentAcres() != null)
                cValues.put("phiPresentAcres", dto.getPhiPresentAcres());

            if (dto.getTargetPreviousAcres() != null)
                cValues.put("targetPreviousAcres", dto.getTargetPreviousAcres());

            if (dto.getTargetPresentAcres() != null)
                cValues.put("targetPresentAcres", dto.getTargetPresentAcres());

            cValues.put("corn", String.valueOf(dto.isCorn()));
            cValues.put("rice", String.valueOf(dto.isRice()));
            cValues.put("millet", String.valueOf(dto.isMillet()));
            cValues.put("mustard", String.valueOf(dto.isMustard()));

            if (dto.getTargetHybrid() != null)
                cValues.put("targetHybrid", dto.getTargetHybrid());

            if (dto.getBlockType() != null)
                cValues.put("blockType", dto.getBlockType());

            /*if (dto.getVillageType() != null)
                cValues.put("villageType", dto.getVillageType());*/

            cValues.put("isSync", dto.getIsSync());

            if (dto.getGeoLocation() != null)
                cValues.put("location", dto.getGeoLocation());

            dbObject.update("PRAVAKTA_HA_AGAIN", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            Log.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;

    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        return null;
    }


    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> pravaktaActivityInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM PRAVAKTA_HA_AGAIN where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                  /*
                  PRAVAKTA_HA_AGAIN
                 pravaktaName
                 mobileNo
                 villageName
                 pincode
                 imageUrlPath
                 blockName
                 districtName
                 previousYear
                 currentYear
                 totalPreviousAcres
                 totalPresentAcres
                 phiPreviousAcres
                 phiPresentAcres
                 targetPreviousAcres
                 targetPresentAcres
                 rice
                 corn
                 millet
                 mustard
                 targetHybrid
                 blockType
                 isSync
 */

                    PravaktaHaGainDTO dto = new PravaktaHaGainDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setPravaktaName(cursor.getString(1));
                    dto.setMobileNo(cursor.getString(2));
                    dto.setVillageName(cursor.getString(3));
                    dto.setPincode(cursor.getString(4));
                    dto.setImageUrlPath(cursor.getString(5));
                    dto.setBlockName(cursor.getString(6));
                    dto.setDistrictName(cursor.getString(7));
                    dto.setPreviousYear(cursor.getString(8));
                    dto.setCurrentYear(cursor.getString(9));
                    dto.setTotalPreviousAcres(cursor.getString(10));
                    dto.setTotalPresentAcres(cursor.getString(11));
                    dto.setPhiPreviousAcres(cursor.getString(12));
                    dto.setPhiPresentAcres(cursor.getString(13));
                    dto.setTargetPreviousAcres(cursor.getString(14));
                    dto.setTargetPresentAcres(cursor.getString(15));
                    dto.setRice(cursor.getString(cursor.getColumnIndex("rice")).equals("true"));
                    dto.setCorn(cursor.getString(cursor.getColumnIndex("corn")).equals("true"));
                    dto.setMillet(cursor.getString(cursor.getColumnIndex("millet")).equals("true"));
                    dto.setMustard(cursor.getString(cursor.getColumnIndex("mustard")).equals("true"));
                    dto.setTargetHybrid(cursor.getString(20));
                    dto.setBlockType(cursor.getString(21));
//                    dto.setVillageType(cursor.getString(22));
                    dto.setIsSync(cursor.getInt(23));
                    dto.setGeoLocation(cursor.getString(24));

                    pravaktaActivityInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pravaktaActivityInfo;
    }


    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM PRAVAKTA_HA_AGAIN").execute();
            return true;
        } catch (Exception e) {
            Log.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }


    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from PRAVAKTA_HA_AGAIN where id='" + id + "'");
            return true;
        } catch (Exception e) {
            Log.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }


    public List<PravaktaHaGainDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<PravaktaHaGainDTO> pravaktaHaGainInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM PRAVAKTA_HA_AGAIN where isSync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    PravaktaHaGainDTO dto = new PravaktaHaGainDTO();

                    dto.setId(cursor.getLong(0));

                    dto.setPravaktaName(cursor.getString(1));
                    dto.setMobileNo(cursor.getString(2));
                    dto.setVillageName(cursor.getString(3));
                    dto.setPincode(cursor.getString(4));
                    dto.setImageUrlPath(cursor.getString(5));
                    dto.setBlockName(cursor.getString(6));
                    dto.setDistrictName(cursor.getString(7));
                    dto.setPreviousYear(cursor.getString(8));
                    dto.setCurrentYear(cursor.getString(9));
                    dto.setTotalPreviousAcres(cursor.getString(10));
                    dto.setTotalPresentAcres(cursor.getString(11));
                    dto.setPhiPreviousAcres(cursor.getString(12));
                    dto.setPhiPresentAcres(cursor.getString(13));
                    dto.setTargetPreviousAcres(cursor.getString(14));
                    dto.setTargetPresentAcres(cursor.getString(15));
                    dto.setRice(cursor.getString(cursor.getColumnIndex("rice")).equals("true"));
                    dto.setCorn(cursor.getString(cursor.getColumnIndex("corn")).equals("true"));
                    dto.setMillet(cursor.getString(cursor.getColumnIndex("millet")).equals("true"));
                    dto.setMustard(cursor.getString(cursor.getColumnIndex("mustard")).equals("true"));
                    dto.setTargetHybrid(cursor.getString(20));
                    dto.setBlockType(cursor.getString(21));
//                    dto.setVillageType(cursor.getString(22));
                    //  dto.setIsSync(cursor.getInt(23));
                    dto.setGeoLocation(cursor.getString(24));
                    List<PravaktaFarmerDTO> farmersPravakta = PravaktaFarmerDAO.getInstance().getRecordsForUpload(cursor.getLong(0), DBHandler.getInstance(context).getDBObject(0));
                    dto.setPravaktaFarmers(farmersPravakta);

                    pravaktaHaGainInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pravaktaHaGainInfo;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM PRAVAKTA_HA_AGAIN where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }
}
