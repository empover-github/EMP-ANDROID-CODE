package com.activitytrack.apiinterface;

import retrofit.RetrofitError;

/**
 * Created by yakaswamy.g on 13/3/2018.
 */
public interface ComonInterface {
    public void onRequestSuccess(Object responseObj);
    public void onRequestFailure(RetrofitError errorCode);
}
