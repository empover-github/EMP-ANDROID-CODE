package com.activitytrack.dtos;

public class FarmerSegmentationResponseDTO implements DTO {

    private String year;
    private long seasonId;
    private String seasonName;
    private long cropId;
    private String cropName;
    private String serverImagePath;

    private String farmerName;
    private String farmerMobileNumber;
    private String pinCode;
    private String villageName;
    private String blockName;
    private String districtName;

    private double planTotalCropAcres;
    private double planGrainAcres;
    private double planSilageAcres;

    private double phiCommitmentGrainAcres;
    private double phiCommitmentSilageAcres;

    private String grainHybrid1Name;
    private double grainHybrid1Acres;
    private String grainHybrid2Name;
    private double grainHybrid2Acres;
    private String grainHybrid3Name;
    private double grainHybrid3Acres;
    private String grainHybrid4Name;
    private double grainHybrid4Acres;

    private String silageHybrid1Name;
    private double silageHybrid1Acres;
    private String silageHybrid2Name;
    private double silageHybrid2Acres;
    private String silageHybrid3Name;
    private double silageHybrid3Acres;
    private String silageHybrid4Name;
    private double silageHybrid4Acres;

    private String grainCompetitorHybrid1;
    private double grainCompetitorHybridValue1;
    private String grainCompetitorHybrid2;
    private double grainCompetitorHybridValue2;
    private String grainCompetitorHybrid3;
    private double grainCompetitorHybridValue3;
    private String grainCompetitorHybrid4;
    private double grainCompetitorHybridValue4;
    private String grainCompetitorHybrid5;// added for other
    private double grainCompetitorHybridValue5;//added for other value

    private String silageCompetitorHybrid1;
    private double silageCompetitorHybridValue1;
    private String silageCompetitorHybrid2;
    private double silageCompetitorHybridValue2;
    private String silageCompetitorHybrid3;
    private double silageCompetitorHybridValue3;
    private String silageCompetitorHybrid4;
    private double silageCompetitorHybridValue4;
    private String silageCompetitorHybrid5; // added for other
    private double silageCompetitorHybridValue5; //added for other value

    private String grainFarmerServices;
    private String silageFarmerServices;

    private String tblParticipated;

    //newly added
    //farmer details

    private float hybridAc;
    private String typeOfIrrigation;


    //hybird rice matyrity
    private float maturity124Ac;
    private float maturity134Ac;
    private float maturity135Ac;

    //pioneer hybird
    private String riceHybrid1Name;
    private double riceHybrid1Acres;
    private String riceHybrid2Name;
    private double riceHybrid2Acres;
    private String riceHybrid3Name;
    private double riceHybrid3Acres;
    private String riceHybrid4Name;
    private double riceHybrid4Acres;


    private String riceServices;

    //competitor hybird plan
    private String riceCompetitorHybrid1;
    private double riceCompetitorHybridValue1;
    private String riceCompetitorHybrid2;
    private double riceCompetitorHybridValue2;
    private String riceCompetitorHybrid3;
    private double riceCompetitorHybridValue3;
    private String riceCompetitorHybrid4;
    private double riceCompetitorHybridValue4;
    private String directSowingRice;

    // feedBack spring_corn_1899
    private String visitedCornHybrid; // this is specially for 1899
    private String visitedCornHybridLike; // if yes what you like
    private String rateHybrid;
    private String shiftNextYrAcres;  // how much you increase hybrid acres sowing in next year


    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public long getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(long seasonId) {
        this.seasonId = seasonId;
    }

    public String getSeasonName() {
        return seasonName;
    }

    public void setSeasonName(String seasonName) {
        this.seasonName = seasonName;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }

    public String getFarmerMobileNumber() {
        return farmerMobileNumber;
    }

    public void setFarmerMobileNumber(String farmerMobileNumber) {
        this.farmerMobileNumber = farmerMobileNumber;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public double getPlanTotalCropAcres() {
        return planTotalCropAcres;
    }

    public void setPlanTotalCropAcres(double planTotalCropAcres) {
        this.planTotalCropAcres = planTotalCropAcres;
    }

    public double getPlanGrainAcres() {
        return planGrainAcres;
    }

    public void setPlanGrainAcres(double planGrainAcres) {
        this.planGrainAcres = planGrainAcres;
    }

    public double getPlanSilageAcres() {
        return planSilageAcres;
    }

    public void setPlanSilageAcres(double planSilageAcres) {
        this.planSilageAcres = planSilageAcres;
    }

    public double getPhiCommitmentGrainAcres() {
        return phiCommitmentGrainAcres;
    }

    public void setPhiCommitmentGrainAcres(double phiCommitmentGrainAcres) {
        this.phiCommitmentGrainAcres = phiCommitmentGrainAcres;
    }

    public double getPhiCommitmentSilageAcres() {
        return phiCommitmentSilageAcres;
    }

    public void setPhiCommitmentSilageAcres(double phiCommitmentSilageAcres) {
        this.phiCommitmentSilageAcres = phiCommitmentSilageAcres;
    }

    public String getGrainHybrid1Name() {
        return grainHybrid1Name;
    }

    public void setGrainHybrid1Name(String grainHybrid1Name) {
        this.grainHybrid1Name = grainHybrid1Name;
    }

    public double getGrainHybrid1Acres() {
        return grainHybrid1Acres;
    }

    public void setGrainHybrid1Acres(double grainHybrid1Acres) {
        this.grainHybrid1Acres = grainHybrid1Acres;
    }

    public String getGrainHybrid2Name() {
        return grainHybrid2Name;
    }

    public void setGrainHybrid2Name(String grainHybrid2Name) {
        this.grainHybrid2Name = grainHybrid2Name;
    }

    public double getGrainHybrid2Acres() {
        return grainHybrid2Acres;
    }

    public void setGrainHybrid2Acres(double grainHybrid2Acres) {
        this.grainHybrid2Acres = grainHybrid2Acres;
    }

    public String getGrainHybrid3Name() {
        return grainHybrid3Name;
    }

    public void setGrainHybrid3Name(String grainHybrid3Name) {
        this.grainHybrid3Name = grainHybrid3Name;
    }

    public double getGrainHybrid3Acres() {
        return grainHybrid3Acres;
    }

    public void setGrainHybrid3Acres(double grainHybrid3Acres) {
        this.grainHybrid3Acres = grainHybrid3Acres;
    }

    public String getGrainHybrid4Name() {
        return grainHybrid4Name;
    }

    public void setGrainHybrid4Name(String grainHybrid4Name) {
        this.grainHybrid4Name = grainHybrid4Name;
    }

    public double getGrainHybrid4Acres() {
        return grainHybrid4Acres;
    }

    public void setGrainHybrid4Acres(double grainHybrid4Acres) {
        this.grainHybrid4Acres = grainHybrid4Acres;
    }

    public String getSilageHybrid1Name() {
        return silageHybrid1Name;
    }

    public void setSilageHybrid1Name(String silageHybrid1Name) {
        this.silageHybrid1Name = silageHybrid1Name;
    }

    public double getSilageHybrid1Acres() {
        return silageHybrid1Acres;
    }

    public void setSilageHybrid1Acres(double silageHybrid1Acres) {
        this.silageHybrid1Acres = silageHybrid1Acres;
    }

    public String getSilageHybrid2Name() {
        return silageHybrid2Name;
    }

    public void setSilageHybrid2Name(String silageHybrid2Name) {
        this.silageHybrid2Name = silageHybrid2Name;
    }

    public double getSilageHybrid2Acres() {
        return silageHybrid2Acres;
    }

    public void setSilageHybrid2Acres(double silageHybrid2Acres) {
        this.silageHybrid2Acres = silageHybrid2Acres;
    }

    public String getSilageHybrid3Name() {
        return silageHybrid3Name;
    }

    public void setSilageHybrid3Name(String silageHybrid3Name) {
        this.silageHybrid3Name = silageHybrid3Name;
    }

    public double getSilageHybrid3Acres() {
        return silageHybrid3Acres;
    }

    public void setSilageHybrid3Acres(double silageHybrid3Acres) {
        this.silageHybrid3Acres = silageHybrid3Acres;
    }

    public String getSilageHybrid4Name() {
        return silageHybrid4Name;
    }

    public void setSilageHybrid4Name(String silageHybrid4Name) {
        this.silageHybrid4Name = silageHybrid4Name;
    }

    public double getSilageHybrid4Acres() {
        return silageHybrid4Acres;
    }

    public void setSilageHybrid4Acres(double silageHybrid4Acres) {
        this.silageHybrid4Acres = silageHybrid4Acres;
    }

    public String getGrainFarmerServices() {
        return grainFarmerServices;
    }

    public void setGrainFarmerServices(String grainFarmerServices) {
        this.grainFarmerServices = grainFarmerServices;
    }

    public String getSilageFarmerServices() {
        return silageFarmerServices;
    }

    public void setSilageFarmerServices(String silageFarmerServices) {
        this.silageFarmerServices = silageFarmerServices;
    }

    public String getTblParticipated() {
        return tblParticipated;
    }

    public void setTblParticipated(String tblParticipated) {
        this.tblParticipated = tblParticipated;
    }

    public String getGrainCompetitorHybrid1() {
        return grainCompetitorHybrid1;
    }

    public void setGrainCompetitorHybrid1(String grainCompetitorHybrid1) {
        this.grainCompetitorHybrid1 = grainCompetitorHybrid1;
    }

    public double getGrainCompetitorHybridValue1() {
        return grainCompetitorHybridValue1;
    }

    public void setGrainCompetitorHybridValue1(double grainCompetitorHybridValue1) {
        this.grainCompetitorHybridValue1 = grainCompetitorHybridValue1;
    }

    public String getGrainCompetitorHybrid2() {
        return grainCompetitorHybrid2;
    }

    public void setGrainCompetitorHybrid2(String grainCompetitorHybrid2) {
        this.grainCompetitorHybrid2 = grainCompetitorHybrid2;
    }

    public double getGrainCompetitorHybridValue2() {
        return grainCompetitorHybridValue2;
    }

    public void setGrainCompetitorHybridValue2(double grainCompetitorHybridValue2) {
        this.grainCompetitorHybridValue2 = grainCompetitorHybridValue2;
    }

    public String getGrainCompetitorHybrid3() {
        return grainCompetitorHybrid3;
    }

    public void setGrainCompetitorHybrid3(String grainCompetitorHybrid3) {
        this.grainCompetitorHybrid3 = grainCompetitorHybrid3;
    }

    public double getGrainCompetitorHybridValue3() {
        return grainCompetitorHybridValue3;
    }

    public void setGrainCompetitorHybridValue3(double grainCompetitorHybridValue3) {
        this.grainCompetitorHybridValue3 = grainCompetitorHybridValue3;
    }

    public String getGrainCompetitorHybrid4() {
        return grainCompetitorHybrid4;
    }

    public void setGrainCompetitorHybrid4(String grainCompetitorHybrid4) {
        this.grainCompetitorHybrid4 = grainCompetitorHybrid4;
    }

    public double getGrainCompetitorHybridValue4() {
        return grainCompetitorHybridValue4;
    }

    public void setGrainCompetitorHybridValue4(double grainCompetitorHybridValue4) {
        this.grainCompetitorHybridValue4 = grainCompetitorHybridValue4;
    }

    public String getSilageCompetitorHybrid1() {
        return silageCompetitorHybrid1;
    }

    public void setSilageCompetitorHybrid1(String silageCompetitorHybrid1) {
        this.silageCompetitorHybrid1 = silageCompetitorHybrid1;
    }

    public double getSilageCompetitorHybridValue1() {
        return silageCompetitorHybridValue1;
    }

    public void setSilageCompetitorHybridValue1(double silageCompetitorHybridValue1) {
        this.silageCompetitorHybridValue1 = silageCompetitorHybridValue1;
    }

    public String getSilageCompetitorHybrid2() {
        return silageCompetitorHybrid2;
    }

    public void setSilageCompetitorHybrid2(String silageCompetitorHybrid2) {
        this.silageCompetitorHybrid2 = silageCompetitorHybrid2;
    }

    public double getSilageCompetitorHybridValue2() {
        return silageCompetitorHybridValue2;
    }

    public void setSilageCompetitorHybridValue2(double silageCompetitorHybridValue2) {
        this.silageCompetitorHybridValue2 = silageCompetitorHybridValue2;
    }

    public String getSilageCompetitorHybrid3() {
        return silageCompetitorHybrid3;
    }

    public void setSilageCompetitorHybrid3(String silageCompetitorHybrid3) {
        this.silageCompetitorHybrid3 = silageCompetitorHybrid3;
    }

    public double getSilageCompetitorHybridValue3() {
        return silageCompetitorHybridValue3;
    }

    public void setSilageCompetitorHybridValue3(double silageCompetitorHybridValue3) {
        this.silageCompetitorHybridValue3 = silageCompetitorHybridValue3;
    }

    public String getSilageCompetitorHybrid4() {
        return silageCompetitorHybrid4;
    }

    public void setSilageCompetitorHybrid4(String silageCompetitorHybrid4) {
        this.silageCompetitorHybrid4 = silageCompetitorHybrid4;
    }

    public double getSilageCompetitorHybridValue4() {
        return silageCompetitorHybridValue4;
    }

    public void setSilageCompetitorHybridValue4(double silageCompetitorHybridValue4) {
        this.silageCompetitorHybridValue4 = silageCompetitorHybridValue4;
    }

    public String getServerImagePath() {
        return serverImagePath;
    }

    public void setServerImagePath(String serverImagePath) {
        this.serverImagePath = serverImagePath;
    }



    public float getMaturity124Ac() {
        return maturity124Ac;
    }

    public void setMaturity124Ac(float maturity124Ac) {
        this.maturity124Ac = maturity124Ac;
    }

    public float getMaturity134Ac() {
        return maturity134Ac;
    }

    public void setMaturity134Ac(float maturity134Ac) {
        this.maturity134Ac = maturity134Ac;
    }

    public float getMaturity135Ac() {
        return maturity135Ac;
    }

    public void setMaturity135Ac(float maturity135Ac) {
        this.maturity135Ac = maturity135Ac;
    }



    public String getRiceServices() {
        return riceServices;
    }

    public void setRiceServices(String riceServices) {
        this.riceServices = riceServices;
    }

    public String getRiceCompetitorHybrid1() {
        return riceCompetitorHybrid1;
    }

    public void setRiceCompetitorHybrid1(String riceCompetitorHybrid1) {
        this.riceCompetitorHybrid1 = riceCompetitorHybrid1;
    }

    public double getRiceCompetitorHybridValue1() {
        return riceCompetitorHybridValue1;
    }

    public void setRiceCompetitorHybridValue1(double riceCompetitorHybridValue1) {
        this.riceCompetitorHybridValue1 = riceCompetitorHybridValue1;
    }

    public String getRiceCompetitorHybrid2() {
        return riceCompetitorHybrid2;
    }

    public void setRiceCompetitorHybrid2(String riceCompetitorHybrid2) {
        this.riceCompetitorHybrid2 = riceCompetitorHybrid2;
    }

    public double getRiceCompetitorHybridValue2() {
        return riceCompetitorHybridValue2;
    }

    public void setRiceCompetitorHybridValue2(double riceCompetitorHybridValue2) {
        this.riceCompetitorHybridValue2 = riceCompetitorHybridValue2;
    }

    public String getRiceCompetitorHybrid3() {
        return riceCompetitorHybrid3;
    }

    public void setRiceCompetitorHybrid3(String riceCompetitorHybrid3) {
        this.riceCompetitorHybrid3 = riceCompetitorHybrid3;
    }

    public double getRiceCompetitorHybridValue3() {
        return riceCompetitorHybridValue3;
    }

    public void setRiceCompetitorHybridValue3(double riceCompetitorHybridValue3) {
        this.riceCompetitorHybridValue3 = riceCompetitorHybridValue3;
    }

    public String getRiceCompetitorHybrid4() {
        return riceCompetitorHybrid4;
    }

    public void setRiceCompetitorHybrid4(String riceCompetitorHybrid4) {
        this.riceCompetitorHybrid4 = riceCompetitorHybrid4;
    }

    public double getRiceCompetitorHybridValue4() {
        return riceCompetitorHybridValue4;
    }

    public void setRiceCompetitorHybridValue4(double riceCompetitorHybridValue4) {
        this.riceCompetitorHybridValue4 = riceCompetitorHybridValue4;
    }

    public String getDirectSowingRice() {
        return directSowingRice;
    }

    public void setDirectSowingRice(String directSowingRice) {
        this.directSowingRice = directSowingRice;
    }

    public String getRiceHybrid1Name() {
        return riceHybrid1Name;
    }

    public void setRiceHybrid1Name(String riceHybrid1Name) {
        this.riceHybrid1Name = riceHybrid1Name;
    }

    public double getRiceHybrid1Acres() {
        return riceHybrid1Acres;
    }

    public void setRiceHybrid1Acres(double riceHybrid1Acres) {
        this.riceHybrid1Acres = riceHybrid1Acres;
    }

    public String getRiceHybrid2Name() {
        return riceHybrid2Name;
    }

    public void setRiceHybrid2Name(String riceHybrid2Name) {
        this.riceHybrid2Name = riceHybrid2Name;
    }

    public double getRiceHybrid2Acres() {
        return riceHybrid2Acres;
    }

    public void setRiceHybrid2Acres(double riceHybrid2Acres) {
        this.riceHybrid2Acres = riceHybrid2Acres;
    }

    public String getRiceHybrid3Name() {
        return riceHybrid3Name;
    }

    public void setRiceHybrid3Name(String riceHybrid3Name) {
        this.riceHybrid3Name = riceHybrid3Name;
    }

    public double getRiceHybrid3Acres() {
        return riceHybrid3Acres;
    }

    public void setRiceHybrid3Acres(double riceHybrid3Acres) {
        this.riceHybrid3Acres = riceHybrid3Acres;
    }

    public String getRiceHybrid4Name() {
        return riceHybrid4Name;
    }

    public void setRiceHybrid4Name(String riceHybrid4Name) {
        this.riceHybrid4Name = riceHybrid4Name;
    }

    public double getRiceHybrid4Acres() {
        return riceHybrid4Acres;
    }

    public void setRiceHybrid4Acres(double riceHybrid4Acres) {
        this.riceHybrid4Acres = riceHybrid4Acres;
    }

    public float getHybridAc() {
        return hybridAc;
    }

    public void setHybridAc(float hybridAc) {
        this.hybridAc = hybridAc;
    }

    public String getTypeOfIrrigation() {
        return typeOfIrrigation;
    }

    public void setTypeOfIrrigation(String typeOfIrrigation) {
        this.typeOfIrrigation = typeOfIrrigation;
    }

    public String getVisitedCornHybrid() {
        return visitedCornHybrid;
    }

    public void setVisitedCornHybrid(String visitedCornHybrid) {
        this.visitedCornHybrid = visitedCornHybrid;
    }

    public String getVisitedCornHybridLike() {
        return visitedCornHybridLike;
    }

    public void setVisitedCornHybridLike(String visitedCornHybridLike) {
        this.visitedCornHybridLike = visitedCornHybridLike;
    }

    public String getRateHybrid() {
        return rateHybrid;
    }

    public void setRateHybrid(String rateHybrid) {
        this.rateHybrid = rateHybrid;
    }

    public String getShiftNextYrAcres() {
        return shiftNextYrAcres;
    }

    public void setShiftNextYrAcres(String shiftNextYrAcres) {
        this.shiftNextYrAcres = shiftNextYrAcres;
    }

    // newly added kiran

    public String getGrainCompetitorHybrid5() {
        return grainCompetitorHybrid5;
    }

    public void setGrainCompetitorHybrid5(String grainCompetitorHybrid5) {
        this.grainCompetitorHybrid5 = grainCompetitorHybrid5;
    }

    public double getGrainCompetitorHybridValue5() {
        return grainCompetitorHybridValue5;
    }

    public void setGrainCompetitorHybridValue5(double grainCompetitorHybridValue5) {
        this.grainCompetitorHybridValue5 = grainCompetitorHybridValue5;
    }

    public String getSilageCompetitorHybrid5() {
        return silageCompetitorHybrid5;
    }

    public void setSilageCompetitorHybrid5(String silageCompetitorHybrid5) {
        this.silageCompetitorHybrid5 = silageCompetitorHybrid5;
    }

    public double getSilageCompetitorHybridValue5() {
        return silageCompetitorHybridValue5;
    }

    public void setSilageCompetitorHybridValue5(double silageCompetitorHybridValue5) {
        this.silageCompetitorHybridValue5 = silageCompetitorHybridValue5;
    }
}
