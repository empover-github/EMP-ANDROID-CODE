package com.activitytrack.transdtos;

public class UploadDTO {

	private TransMainDTO data;

	public TransMainDTO getData() {
		return data;
	}

	public void setData(TransMainDTO data) {
		this.data = data;
	}

}
