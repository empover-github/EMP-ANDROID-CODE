package com.activitytrack.listeners;

import android.view.View;

public interface DialogMangerCallback {

	public void onOkClick();
	public void onCancelClick(View view);

}
