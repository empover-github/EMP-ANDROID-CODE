package com.activitytrack.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.activitytrack.adapter.MdrSurveyAdapter;
import com.activitytrack.daos.CompanyMasterDAO;
import com.activitytrack.daos.NewMdrSurveyDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.NewMdrSurveyDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

import static android.app.Activity.RESULT_OK;

/**
 * Created by fatima.t on 29-03-2018.
 */

public class MdrSurveyListActivity extends BaseActivity {
    private Bundle bundle;
    private long activityId, cropId;
    private String cropName, segmentName, blockName, pincode, isPDAVillage, villageName;
    private List<NewMdrSurveyDTO> surveyDataList = new ArrayList<>();
    private ArrayList<NewMdrSurveyDTO> originalList = new ArrayList<>();
    private MdrSurveyAdapter surveyListAdapter;
    private static final int REQUEST_CODE = 100;
    private TextView mTitleTextView;
    public static final String EXTRA_ACTIVITY_ID = "activityId";
    public static final String EXTRA_CROP_ID = "cropId";
    public static final String EXTRA_CROP_NAME = "cropName";
    public static final String EXTRA_SEGMENT_NAME = "segmentName";/*
    public static final String EXTRA_VILLAGE_NAME = "villageName";
    public static final String EXTRA_PINCODE = "pincode";
    public static final String EXTRA_BLOCK_NAME = "blockName";
    public static final String EXTRA_ISPDAVILLAGE = "isPDAVillage";*/
    private EditText edtSearch;
    private ImageView imgClear, imgSearch;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (Utility.getCurrentTheme(MdrSurveyListActivity.this).equals(MyConstants.THEME_LIGHT)) {
            setTheme(R.style.AppThemeLite);
        } else if (Utility.getCurrentTheme(MdrSurveyListActivity.this).equals(MyConstants.THEME_DARK)) {
            setTheme(R.style.AppThemeAT);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mdr_survey_list);

        MdrSurveyListActivity surveyListActivity = this;

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setTitle(getString(R.string.survey));
        ImageView imageAddSurvey = (ImageView) findViewById(R.id.survey_addBtn);
        ListView surveyDataListView = (ListView) findViewById(R.id.listview_survey);
        edtSearch = (EditText) findViewById(R.id.edt_search);
        imgClear = (ImageView) findViewById(R.id.img_clear);
        imgSearch = (ImageView) findViewById(R.id.img_search);


        surveyListAdapter = new MdrSurveyAdapter(MdrSurveyListActivity.this, surveyDataList);
        surveyDataListView.setAdapter(surveyListAdapter);

        bundle = getIntent().getExtras();
        if (bundle != null) {
            activityId = bundle.getLong(EXTRA_ACTIVITY_ID);
            cropId = bundle.getLong(EXTRA_CROP_ID);
            cropName = bundle.getString(EXTRA_CROP_NAME);
            segmentName = bundle.getString(EXTRA_SEGMENT_NAME);
            /*villageName = bundle.getString(EXTRA_VILLAGE_NAME);
            isPDAVillage = bundle.getString(EXTRA_ISPDAVILLAGE);
            pincode = bundle.getString(EXTRA_PINCODE);
            blockName = bundle.getString(EXTRA_BLOCK_NAME);*/

        }

        List<NewMdrSurveyDTO> surveyDataListTemp = NewMdrSurveyDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(MdrSurveyListActivity.this).getDBObject(0));
        if (surveyDataListTemp.size() == 0) {
            // Intent farmerIntent = new Intent(surveyListActivity, SurveyActivity.class);
            Intent farmerIntent = new Intent(surveyListActivity, NewSurveyActivity.class);
            bundle.putLong(EXTRA_ACTIVITY_ID, activityId);
            bundle.putLong(EXTRA_CROP_ID, cropId);
            bundle.putString(EXTRA_CROP_NAME, cropName);
            bundle.putString(EXTRA_SEGMENT_NAME, segmentName);
           /* bundle.putString(MdrSurveyListActivity.EXTRA_VILLAGE_NAME, villageName);
            bundle.putString(MdrSurveyListActivity.EXTRA_PINCODE, pincode);
            bundle.putString(MdrSurveyListActivity.EXTRA_BLOCK_NAME, blockName);
            bundle.putString(MdrSurveyListActivity.EXTRA_ISPDAVILLAGE,isPDAVillage);*/
            farmerIntent.putExtras(bundle);
            startActivityForResult(farmerIntent, REQUEST_CODE);
        } else {
            originalList.clear();
            originalList.addAll(surveyDataListTemp);
            surveyDataList.clear();
            surveyDataList.addAll(originalList);
            sortCompanyByAcgres();
            surveyListAdapter.notifyDataSetChanged();
        }

        imageAddSurvey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<DTO> avalibleRecordsList = NewMdrSurveyDAO.getInstance().getRecordInfoByValue("activityId", "" + activityId, DBHandler.getInstance(MdrSurveyListActivity.this).getDBObject(0));
                edtSearch.setText("");
                if (avalibleRecordsList != null && avalibleRecordsList.size() < 25) {
                    Intent farmerDataIntent = new Intent(MdrSurveyListActivity.this, NewSurveyActivity.class);
                    bundle.putLong("activityId", activityId);
                    bundle.putString(EXTRA_CROP_NAME, cropName);
                    bundle.putString(EXTRA_SEGMENT_NAME, segmentName);
                    farmerDataIntent.putExtras(bundle);
                    startActivityForResult(farmerDataIntent, REQUEST_CODE);
                } else {
                    Utility.showAlert(MdrSurveyListActivity.this, "", getResources().getString(R.string.mdr_add_survey_limit));
                }
            }
        });

        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                surveyDataList.clear();
                if (s.toString().isEmpty()) {
                    surveyDataList.addAll(originalList);
                } else {
                    for (NewMdrSurveyDTO dto : originalList) {
                        if (Pattern.compile(Pattern.quote(edtSearch.getText().toString().trim()), Pattern.CASE_INSENSITIVE).matcher(dto.getMobileNo()).find()) {
                            surveyDataList.add(dto);
                        }
                    }
                }
                surveyListAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setFocusableInTouchMode(true);
                edtSearch.setFocusable(true);
                edtSearch.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(edtSearch, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        imgClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setText("");
            }
        });
        imgSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setFocusableInTouchMode(true);
                edtSearch.setFocusable(true);
                edtSearch.requestFocus();
                InputMethodManager imm1 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm1.showSoftInput(edtSearch, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }

    private void sortCompanyByAcgres() {

        for (NewMdrSurveyDTO dto : originalList) {
            HashMap<Long, Float> codenames = new HashMap<Long, Float>();
            codenames.put(dto.getMajorCompany1(), dto.getMajorCompany1Acreage());
            codenames.put(dto.getMajorCompany2(), dto.getMajorCompany2Acreage());
            codenames.put(dto.getMajorCompany3(), dto.getMajorCompany3Acreage());
            codenames.put(dto.getMajorCompany4(), dto.getMajorCompany4Acreage());
            codenames.put(dto.getMajorCompany5(), dto.getMajorCompany5Acreage());
            Set<Map.Entry<Long, Float>> entries = codenames.entrySet();
            for (Map.Entry<Long, Float> entry : entries) {
                System.out.println(entry.getKey() + " ==> " + entry.getValue());
            } // Now let's sort HashMap by keys first // all you need to do is create a TreeMap with mappings of HashMap // TreeMap keeps all entries in sorted order
            TreeMap<Long, Float> sorted = new TreeMap<>(codenames);
            Set<Map.Entry<Long, Float>> mappings = sorted.entrySet();
            System.out.println("HashMap after sorting by keys in ascending order ");
            for (Map.Entry<Long, Float> mapping : mappings) {
                System.out.println(mapping.getKey() + " ==> " + mapping.getValue());
            } // Now let's sort the HashMap by values // there is no direct way to sort HashMap by values but you // can do this by writing your own comparator, which takes // Map.Entry object and arrange them in order increasing // or decreasing by values.
            Comparator<Map.Entry<Long, Float>> valueComparator = new Comparator<Map.Entry<Long, Float>>() {
                @Override
                public int compare(Map.Entry<Long, Float> e1, Map.Entry<Long, Float> e2) {
                    int result = e1.getValue().compareTo(e2.getValue());
                    if (result > 0) {
                        return -1;
                    } else if (result < 0) {
                        return 1;
                    } else {
                        return result;
                    }
                }
            };
            // Sort method needs a List, so let's first convert Set to List in Java
            List<Map.Entry<Long, Float>> listOfEntries = new ArrayList<Map.Entry<Long, Float>>(entries);
            // sorting HashMap by values using comparator
            Collections.sort(listOfEntries, valueComparator);
            LinkedHashMap<Long, Float> sortedByValue = new LinkedHashMap<Long, Float>(listOfEntries.size());
            // copying entries from List to Map
            for (Map.Entry<Long, Float> entry : listOfEntries) {
                sortedByValue.put(entry.getKey(), entry.getValue());
            }

            if ((float) listOfEntries.get(0).getValue() == (float) listOfEntries.get(1).getValue()) {
                String majorCompanyName1 = CompanyMasterDAO.getInstance().getName(listOfEntries.get(0).getKey(), DBHandler.getInstance(MdrSurveyListActivity.this).getDBObject(0));
                String majorCompanyName2 = CompanyMasterDAO.getInstance().getName(listOfEntries.get(1).getKey(), DBHandler.getInstance(MdrSurveyListActivity.this).getDBObject(0));
                if (majorCompanyName2.equalsIgnoreCase("Pioneer")) {
                    dto.setHighestCompanyName(majorCompanyName2);
                    dto.setHighestCompanyPercentage(listOfEntries.get(1).getValue());
                } else {
                    dto.setHighestCompanyName(majorCompanyName1);
                    dto.setHighestCompanyPercentage(listOfEntries.get(0).getValue());
                }

            } else {
                String majorCompanyName = CompanyMasterDAO.getInstance().getName(listOfEntries.get(0).getKey(), DBHandler.getInstance(MdrSurveyListActivity.this).getDBObject(0));
                dto.setHighestCompanyName(majorCompanyName);
                dto.setHighestCompanyPercentage(listOfEntries.get(0).getValue());
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE) {
            List<NewMdrSurveyDTO> updatedFarmerData = NewMdrSurveyDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(MdrSurveyListActivity.this).getDBObject(0));
            if (updatedFarmerData.size() == 0) {
                onBackPressed();
            } else {
                originalList.clear();
                originalList.addAll(updatedFarmerData);
                surveyDataList.clear();
                surveyDataList.addAll(originalList);
                sortCompanyByAcgres();
                surveyListAdapter.notifyDataSetChanged();
            }
            /*if (resultCode == RESULT_OK) {
                surveyDataList.clear();
                List<MdrSurveyDTO> updatedFarmerData = MdrSurveyDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(MdrSurveyListActivity.this).getDBObject(0));
                if (updatedFarmerData.size() == 0) {
                    onBackPressed();
                } else {
                    surveyDataList.addAll(updatedFarmerData);
                    surveyListAdapter.notifyDataSetChanged();
                }
            }
            if (resultCode == RESULT_CANCELED) {

            }*/
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
