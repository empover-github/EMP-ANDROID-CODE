package com.activitytrack.dtos;

public class PSAActivityDTO implements DTO {

    private long mobileId;
    private String activityType;
    private long cropId;
    private long hybridId;
    private int numberOfFarmers;
    private int numberOfRetailers;
    private String competitorHybrid1;
    private float hybridYield;
    private float competitorYield;
    private String location;
    private int isSync;
    private long seasonId;
    private String date;
    private long seasonCalendarId;
    private String uploadedDate;
    private long regionId;
    private String farmerBarCodeDetails;
    private String farmerAttendanceDetails;
    private String pincode;
   //newly added
   private String isTBLParticipated;
    private int numberOfPravaktas;

    //newly added for faw
    private String isFAWDone;

    public long getId() {
        return mobileId;
    }

    public void setId(long id) {
        this.mobileId = id;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public long getHybridId() {
        return hybridId;
    }

    public void setHybridId(long hybridId) {
        this.hybridId = hybridId;
    }

    public int getNumberOfFarmers() {
        return numberOfFarmers;
    }

    public void setNumberOfFarmers(int numberOfFarmers) {
        this.numberOfFarmers = numberOfFarmers;
    }

    public int getNumberOfRetailers() {
        return numberOfRetailers;
    }

    public void setNumberOfRetailers(int numberOfRetailers) {
        this.numberOfRetailers = numberOfRetailers;
    }

    public String getCompetitorHybrid1() {
        return competitorHybrid1;
    }

    public void setCompetitorHybrid1(String competitorHybrid1) {
        this.competitorHybrid1 = competitorHybrid1;
    }

    public float getHybridAcres() {
        return hybridYield;
    }

    public void setHybridAcres(float hybridAcres) {
        this.hybridYield = hybridAcres;
    }

    public float getCompetitorYield() {
        return competitorYield;
    }

    public void setCompetitorYield(float competitorYield) {
        this.competitorYield = competitorYield;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public long getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(long seasonId) {
        this.seasonId = seasonId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public long getSeasonCalendarId() {
        return seasonCalendarId;
    }

    public void setSeasonCalendarId(long seasonCalendarId) {
        this.seasonCalendarId = seasonCalendarId;
    }

    public String getUploadedDate() {
        return uploadedDate;
    }

    public long getRegionId() {
        return regionId;
    }

    public void setRegionId(long regionId) {
        this.regionId = regionId;
    }

    public void setUploadedDate(String uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public String getFarmerBarCodeDetails() {
        return farmerBarCodeDetails;
    }

    public void setFarmerBarCodeDetails(String farmerBarCodeDetails) {
        this.farmerBarCodeDetails = farmerBarCodeDetails;
    }

    public String getFarmerAttendanceDetails() {
        return farmerAttendanceDetails;
    }

    public void setFarmerAttendanceDetails(String farmerAttendanceDetails) {
        this.farmerAttendanceDetails = farmerAttendanceDetails;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getIsTBLParticipated() {
        return isTBLParticipated;
    }

    public void setIsTBLParticipated(String isTBLParticipated) {
        this.isTBLParticipated = isTBLParticipated;
    }

    public int getNumberOfPravaktas() {
        return numberOfPravaktas;
    }

    public void setNumberOfPravaktas(int numberOfPravaktas) {
        this.numberOfPravaktas = numberOfPravaktas;
    }

    public String getIsFAWDone() {
        return isFAWDone;
    }

    public void setIsFAWDone(String isFAWDone) {
        this.isFAWDone = isFAWDone;
    }
}
