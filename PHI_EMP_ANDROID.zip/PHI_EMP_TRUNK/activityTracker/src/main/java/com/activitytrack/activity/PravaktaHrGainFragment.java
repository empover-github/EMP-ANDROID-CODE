package com.activitytrack.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.core.content.ContextCompat;
import androidx.core.widget.CompoundButtonCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.activitytrack.daos.PravaktaFarmerDAO;
import com.activitytrack.daos.PravaktaHaAgainDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.PravaktaHaGainDTO;
import com.activitytrack.listeners.DialogMangerCallback;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;
import com.bumptech.glide.Glide;
import com.soundcloud.android.crop.Crop;

import net.sourceforge.opencamera.MainActivityOC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit.mime.TypedFile;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

/**
 * Created by rambabu.a on 05-03-2018.
 */

public class PravaktaHrGainFragment extends BaseFragment {
    public static final int OPENCAMERA = 300;
    private View view;

    // text fileds
    private TextView tvFarmerName, tvMobileNo, tvVillageName, tvPincode, tvBlockName, tvDistrictName,
            tvTotalAcres, tvPhiAcres, tvTargetAcres, tvCrop, tvTargerHybrid, tvBlockType, tvPreviousYear, tvCurrentYear, tvAddFarmersCount;
    // edittext
    private EditText edtPravaktarName, edtPravaktaMobileNo, edtVillageName, edtPinCode, edtBlockName, edtDistrictName,
            edtTotalAcresPYear, edtTotalAcresCYear, edtPhiAcresPYear, edtPhiAcresCYear, edtTargetAcresPYear, edtTargetAcresCYear, edtTargerHybrid;

    // Main Layout
    private LinearLayout mainLayout, addFarmers, addFarmersCount;
    private Button btnSubmit;
    private CheckBox checkBoxCorn, checkBoxRice, checkBoxMillet, checkBoxMustard;

    private Spinner spnBlockType;
    private String[] blockTypeArray;
    private long activityId;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    File myDir;
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_CAMERA_PERMISSION_DENAIL = 101;
    private Uri uriStr;
    private int previousYear, currentYear;
    private StringBuilder builder = null;
    private LinearLayout layoutClear, layoutPlus;
    private List<String> listTarget;
    private ImageView profileImage, imageCapture;
    private String imagePath;
    private List<DTO> farmersList;
    private RelativeLayout rlTraget;
    private int HR_REQUEST_CODE = 101;
    private static final int REQUEST_CODE_FOR_IMAGE_CROPPING = 66 ;
    private ExecutorService mExecutor;
    private TypedFile imageTypedFile;
    private Dialog imageDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.pravakta_hr_gain_fragment, container, false);
        initializeViews();

        setChange();

        activityId = Utility.getActivityId(mActivity);
        if (activityId == 0) {
            btnSubmit.setEnabled(false);
        } else {
            refreshCount();
        }

        return view;
    }

    private void refreshCount() {
        List<DTO> pravaktaDTOList = PravaktaHaAgainDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));
        if (pravaktaDTOList != null && pravaktaDTOList.size() > 0) {
            farmersList = PravaktaFarmerDAO.getInstance().getRecordInfoById(activityId, DBHandler.getInstance(mActivity).getDBObject(0));

            if (farmersList != null && farmersList.size() > 0) {
                //set list size to textView
                tvAddFarmersCount.setText(("" + farmersList.size()));
                addFarmersCount.setVisibility(View.VISIBLE);
                if (farmersList.size() >= 1) {
                    btnSubmit.setEnabled(true);
                }
            } else {
                //set empty to textView
                tvAddFarmersCount.setText("");
                addFarmersCount.setVisibility(View.INVISIBLE);
            }

        } else {
            btnSubmit.setEnabled(false);
            activityId = 0;
            Utility.setActivityId(0, mActivity);
        }
    }

    private void initializeViews() {
        tvFarmerName = (TextView) view.findViewById(R.id.ph_farmerName_l);
        tvMobileNo = (TextView) view.findViewById(R.id.ph_farmerMobileNo_l);
        tvVillageName = (TextView) view.findViewById(R.id.ph_village_name_l);
        tvPincode = (TextView) view.findViewById(R.id.ph_pincode_l);

        tvBlockName = (TextView) view.findViewById(R.id.ph_block_name_l);
        tvDistrictName = (TextView) view.findViewById(R.id.ph_district_name_l);
        tvTotalAcres = (TextView) view.findViewById(R.id.ph_total_acres_l);
        tvPhiAcres = (TextView) view.findViewById(R.id.ph_phi_acres_l);
        tvTargetAcres = (TextView) view.findViewById(R.id.ph_taget_acres_l);
        tvCrop = (TextView) view.findViewById(R.id.ph_crop_l);
        tvTargerHybrid = (TextView) view.findViewById(R.id.ph_target_hybrid_l);
        tvBlockType = (TextView) view.findViewById(R.id.ph_block_type_l);

        edtPravaktarName = (EditText) view.findViewById(R.id.ph_farmerName);
        edtPravaktaMobileNo = (EditText) view.findViewById(R.id.ph_farmerMobileNo);
        edtVillageName = (EditText) view.findViewById(R.id.ph_village_name);
        edtPinCode = (EditText) view.findViewById(R.id.ph_pincode);

        edtBlockName = (EditText) view.findViewById(R.id.ph_block_name);
        edtDistrictName = (EditText) view.findViewById(R.id.ph_district_name);

        edtTotalAcresPYear = (EditText) view.findViewById(R.id.ph_total_acres_pY);
        edtTotalAcresCYear = (EditText) view.findViewById(R.id.ph_total_acres_cY);
        edtPhiAcresPYear = (EditText) view.findViewById(R.id.ph_phi_acres_pY);
        edtPhiAcresCYear = (EditText) view.findViewById(R.id.ph_phi_acres_cY);
        edtTargetAcresPYear = (EditText) view.findViewById(R.id.ph_taget_acres_pY);
        edtTargetAcresCYear = (EditText) view.findViewById(R.id.ph_taget_acres_cY);

        edtTargerHybrid = (EditText) view.findViewById(R.id.ph_target_hybrid);

        Calendar calendar = Calendar.getInstance();
        currentYear = calendar.get(Calendar.YEAR);
        previousYear = calendar.get(Calendar.YEAR) - 1;
        tvPreviousYear = (TextView) view.findViewById(R.id.ph_pY);
        tvCurrentYear = (TextView) view.findViewById(R.id.ph_cY);
        //checkbox

        checkBoxCorn = (CheckBox) view.findViewById(R.id.ph_checkbox_cron);
        checkBoxRice = (CheckBox) view.findViewById(R.id.ph_checkbox_rice);
        checkBoxMillet = (CheckBox) view.findViewById(R.id.ph_checkbox_millet);
        checkBoxMustard = (CheckBox) view.findViewById(R.id.ph_checkbox_mustard);

        // layout
        mainLayout = (LinearLayout) view.findViewById(R.id.ph_main_layout);
        // spinner
        spnBlockType = (Spinner) view.findViewById(R.id.ph_spinner_block_type);

        //RelativeLayout
        rlTraget = (RelativeLayout) view.findViewById(R.id.rl_target);

        // Button
        btnSubmit = (Button) view.findViewById(R.id.ph_submit);
        addFarmers = (LinearLayout) view.findViewById(R.id.ph_addFarmers);
        tvAddFarmersCount = (TextView) view.findViewById(R.id.ph_addFarmersCir);
        addFarmersCount = (LinearLayout) view.findViewById(R.id.ph_circle_addFarmers_l);

        blockTypeArray = getResources().getStringArray(R.array.block_type_spln_items);
        ArrayAdapter<String> blockTypeAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, blockTypeArray);
        spnBlockType.setAdapter(blockTypeAdapter);


        tvPreviousYear.setText(tvPreviousYear.getText().toString().replace("$1", String.valueOf(previousYear)));
        tvCurrentYear.setText(tvCurrentYear.getText().toString().replace("$1", String.valueOf(currentYear)));
        layoutClear = (LinearLayout) view.findViewById(R.id.ph_layout_clear);
        layoutPlus = (LinearLayout) view.findViewById(R.id.ph_layout_plus);
        //layoutPht = (LinearLayout)view. findViewById(R.id.ph_layout_pht);
        profileImage = (ImageView) view.findViewById(R.id.ph_profile_image);
        imageCapture = (ImageView) view.findViewById(R.id.ph_profile_capture);
        if (getText(edtTargerHybrid).isEmpty()) {
            layoutClear.setVisibility(View.GONE);
        }

        edtPravaktaMobileNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edtPravaktaMobileNo.length() == 1 && edtPravaktaMobileNo.getText().toString().trim().equalsIgnoreCase("0")) {
                    edtPravaktaMobileNo.setText("");
                }
            }
        });
        edtPinCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (edtPinCode.length() == 1 && edtPinCode.getText().toString().trim().equalsIgnoreCase("0")) {
                    edtPinCode.setText("");
                }
            }
        });

        setListeners();

    }

    private void setListeners() {
        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    if (checkForLocation) {
                        if (location != null && location.length() > 0) {
                            showAlertToSave();
                        } else {
                            getCurrentLocation(mActivity);
                        }
                    } else {
                        showAlertToSave();
                    }
                } else {
                    Utility.showAlert(mActivity, "", validation);
                }
            }
        });

        addFarmers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Remove below code for simply moving to PravaktaFarmerDataActivity.java and setting hardcoded value for activity ID
                // TARA
//                activityId = 1;
                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        PravaktaHaGainDTO pravaktaHaGainDTO = getDataObject();
                        pravaktaHaGainDTO.setIsSync(0);
                        activityId = PravaktaHaAgainDAO.getInstance().insertActivity(pravaktaHaGainDTO, DBHandler.getInstance(mActivity).getDBObject(1));
                        if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                        }
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.isEmpty()) {
                        PravaktaHaGainDTO pravaktaHaGainDTO = getDataObject();
                        pravaktaHaGainDTO.setIsSync(0);
                        pravaktaHaGainDTO.setId(activityId);
                        PravaktaHaAgainDAO.getInstance().update(pravaktaHaGainDTO, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }


                if (activityId > 0) {
                    // if (farmersList != null && farmersList.size() > 0) {
                    Intent pravaktaFarmer = new Intent(getActivity(), PravaktaFarmerActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("activity", MyConstants.ACTIVITY_PRAVAKTA);
                    bundle.putLong("activityId", activityId);
                    pravaktaFarmer.putExtras(bundle);
                    startActivityForResult(pravaktaFarmer, HR_REQUEST_CODE);

                }
            }


        });

        imageCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (ContextCompat.checkSelfPermission(mActivity, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        //Location Permission already granted
                        cameraPermission();
                    } else {
                        //Request Location Permission
                        checkLocationPermission();
                    }
                } else {
                    cameraPermission();
                }
            }
        });


        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (ContextCompat.checkSelfPermission(mActivity, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        //Location Permission already granted
                        cameraPermission();
                    } else {
                        //Request Location Permission
                        checkLocationPermission();
                    }
                } else {
                    cameraPermission();
                }
            }
        });

        layoutClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtTargerHybrid.setText("");
                layoutClear.setVisibility(View.INVISIBLE);
                builder = null;
            }
        });
        layoutPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listTarget = new ArrayList<String>(Arrays.asList(edtTargerHybrid.getText().toString().split(",")));
                if (listTarget.size() > 4) {
                    DialogManager.showSingleBtnPopup(mActivity, null, getString(R.string.alert), getString(R.string.total_hybrid), getString(R.string.ok));
                } else {
                    showOTPPopup(mActivity);
                }
            }
        });

        spnBlockType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getChildCount() > 0) {
                    if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                    } else {
                        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void showOTPPopup(final Context mContex) {
        final Button mokBtn, mcancelBtn;
        final TextView mTextView;
        final EditText mEditText;
        final Dialog mDialog;
        mDialog = new Dialog(mContex);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.pravakta_farmer_popup_btn);
        //  final Dialog mDialog = Utility.getDialog(mContext, R.layout.big_farmer_popup_btn);
        mDialog.setCancelable(true);
        mDialog.setCanceledOnTouchOutside(true);
        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.rc_parent_view_for_font);

        mTextView = (TextView) mDialog.findViewById(R.id.tv_question);
        mEditText = (EditText) mDialog.findViewById(R.id.edt_comment_no);
        mokBtn = (Button) mDialog.findViewById(R.id.btn_ok);
        mcancelBtn = (Button) mDialog.findViewById(R.id.cancel_btn);
        mTextView.setText(tvTargerHybrid.getText().toString());
        mcancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mokBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (getText(mEditText).isEmpty()) {
                    DialogManager.showToast(getActivity(), getString(R.string.min_char));
                } else {
                    if (builder == null) {
                        builder = new StringBuilder();
                    } else {
                        builder.append(",");
                    }
                    builder.append(mEditText.getText().toString().trim());
                    edtTargerHybrid.setText(builder);
                    layoutClear.setVisibility(View.VISIBLE);
                    mDialog.dismiss();
                }
            }
        });
        mDialog.show();

    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(mActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new androidx.appcompat.app.AlertDialog.Builder(mActivity)
                        .setTitle(getString(R.string.permission_location_title))
                        .setMessage(getString(R.string.permission_location_body))
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(mActivity,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    private void cameraPermission() {
        File newfile = createFile();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkPermission()) {
                if (!Utility.isValidStr(imagePath)) {
                    //Dummy
                    openCameraApp(newfile);
                } else {
                    showOptionOpenCameraforPravakta(null, mActivity, newfile);
                }
            }
        } else {
            if (!Utility.isValidStr(imagePath)) {
                openCameraApp(newfile);
            } else {
                showOptionOpenCameraforPravakta(null, mActivity, newfile);
            }
        }
    }

    public void openCameraApp(File newfile) {
        /*String root = Environment.getExternalStorageDirectory().toString();
//		File myDir = new File(root + File.separator+"Fatima_OC_TEST");
		File myDir = new File(root + File.separator+"CropDiagnosis");
//		File myDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);

		if(!myDir.exists())
			myDir.mkdirs();

		File newfile = new File(myDir, "IMG_"+System.currentTimeMillis()+".JPG");
		try {
			newfile.createNewFile();
		} catch (IOException e) {}*/

        Uri outputFileUri = Uri.fromFile(newfile);
        String uriString = outputFileUri.toString();

        Intent intent = new Intent(getActivity(), MainActivityOC.class);
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE); // without this not working, not getting data only
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
        startActivityForResult(intent, OPENCAMERA);
    }

    private File createFile() {
//        String root = Environment.getExternalStorageDirectory().toString();
//        myDir = new File(root + File.separator + "PravathaGainImage");
        String dirPath = getActivity().getFilesDir().getAbsolutePath();//Environment.getExternalStorageDirectory().toString();
        dirPath = dirPath + File.separator + "Files";
        myDir = new File(dirPath + File.separator + "PravathaGainImage");
        if (!myDir.exists())
            myDir.mkdirs();

        File newfile = new File(myDir, "IMG_" + System.currentTimeMillis() + ".JPG");
        try {
            newfile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return newfile;
    }

    private boolean checkPermission() {
        // Here, thisActivity is the current activity
        if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.CAMERA) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
                    @Override
                    public void onOkClick() {
                        ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                    }

                    @Override
                    public void onCancelClick(View view) {
                    }
                }, getString(R.string.permission_camera_storage_title), getString(R.string.permission_camera_storage_euipment_body), getString(R.string.ok), getString(R.string.cancel));

            } else {
                // No explanation needed, we can request the permission.
                if (Utility.isFirstTimeCamera(mActivity)) {

                    DialogManager.showConformPopup(mActivity, new DialogMangerCallback() {
                        @Override
                        public void onOkClick() {
                            Utility.setFirstTimeCamera(false, mActivity);
                            ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION);
                        }

                        @Override
                        public void onCancelClick(View view) {
                        }
                    }, getString(R.string.permission_camera_storage_title), getString(R.string.permission_camera_storage_euipment_body), getString(R.string.ok), getString(R.string.cancel));


                } else {
                    ActivityCompat.requestPermissions(mActivity, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION_DENAIL);
                }
            }
        } else {
            return true;
        }

        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            //ProfileImageSelectionUtil.showOption(null, mActivity);
                            openCameraApp(newfile);
                        else
                            checkPermission();
                    } else {
                        openCameraApp(newfile);
                        //ProfileImageSelectionUtil.showOption(null, mActivity);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }

            }
            break;
            case REQUEST_CAMERA_PERMISSION_DENAIL: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    File newfile = createFile();
                    if (permissions.length == 2) {
                        if (grantResults[1] == PackageManager.PERMISSION_GRANTED)
                            openCameraApp(newfile);
                        else
                            showDialogToOpenSetting();
                    } else {

                        openCameraApp(newfile);
                    }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    showDialogToOpenSetting();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
            }
            break;

            // other 'case' lines to check for other
            // permissions this app might request
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(mActivity,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient != null) {
                            mGoogleApiClient.connect();
                        } else {
                            buildGoogleApiClient();
                            mGoogleApiClient.connect();
                        }
                    }
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(mActivity, "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }

    private void showDialogToOpenSetting() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(mActivity);
        builder.setTitle("Permission Denied");
        builder.setMessage("You denied camera permission with never show option\nPlease enable permissions manually, tap on permissions then enable the camera permission");
        builder.setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                showInstalledAppDetails(mActivity, mActivity.getPackageName());
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish();
            }
        });
        builder.create().show();
    }

    public void showInstalledAppDetails(Context context, String packageName) {

        Intent intent2 = new Intent();
        intent2.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri2 = Uri.fromParts("package", mActivity.getPackageName(), null);
        intent2.setData(uri2);
        context.startActivity(intent2);
        mActivity.finish();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == OPENCAMERA) {
            if (resultCode == RESULT_OK) {
                try {/*
//                    uriStr = (Uri) data.getExtras().get("data");
                    Uri uriStrTremp = (Uri) data.getExtras().get("data");  // if we captured new pic but not cropped, thn showing old pic in imageView but when we click on see full photo thn new pic is shown. thats why created local variable

                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(mActivity.getContentResolver(), uriStrTremp);

                    if (bitmap != null) {
                        String imagePath = storeImage(bitmap, "profile" + "_");
                        Uri mCapturedUri = Uri.fromFile(new File(imagePath));

//                        new Crop(mCapturedUri).output(uriStr).asSquare().start(mActivity, PravaktaHrGainFragment.this);
                        Intent gotoCropImage = new Intent(mActivity, ATCropMyImageActivity.class);
                        gotoCropImage.setData(uriStrTremp);
                        startActivityForResult(gotoCropImage, REQUEST_CODE_FOR_IMAGE_CROPPING);
                    }*/

                    mExecutor = Executors.newSingleThreadExecutor();
                    Uri myUri = (Uri) data.getExtras().get("data");
                    uriStr = myUri;
                    mExecutor.submit(new LoadScaledImageTask(mActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                    imagePath = myUri.toString();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (resultCode == RESULT_CANCELED) {
                // user cancelled Image capture
                DialogManager.showToast(mActivity, getString(R.string.user_cancelled_image_capture));
            } else {
                // failed to capture image
                DialogManager.showToast(mActivity, getString(R.string.failed_to_capture_image));
            }
        } else if (requestCode == Crop.REQUEST_CROP
                && resultCode == RESULT_OK) {

            try {
                // get the returned data
                Bundle extras = data.getExtras();
                // get the cropped bitmap
                Uri thePic = extras.getParcelable(MediaStore.EXTRA_OUTPUT);

                if (thePic == null)
                    return;
                profileImage.setImageBitmap(null);

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(mActivity.getContentResolver(), thePic);

                profileImage.setImageBitmap(bitmap);

//                imageTypedFile = new TypedFile("multipart/form-data", new File(thePic.toString().substring(7)));

                imagePath = thePic.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if(requestCode == HR_REQUEST_CODE && resultCode == RESULT_OK){
            refreshCount();
        } else if (requestCode == REQUEST_CODE_FOR_IMAGE_CROPPING ){
            if (resultCode == RESULT_OK ) {
                mExecutor = Executors.newSingleThreadExecutor();
                Uri myUri = data.getData();
                uriStr = myUri;
                mExecutor.submit(new LoadScaledImageTask(mActivity, myUri, profileImage, calcImageSize()));
//                imageTypedFile = new TypedFile("multipart/form-data", new File(myUri.toString().substring(7)));
                imagePath = myUri.toString();
            } else if (resultCode == RESULT_CANCELED){

                DialogManager.showToast(mActivity, getString(R.string.at_user_cancelled_image_cropping));
            }
        }
    }

    private String storeImage(Bitmap image, String fileName) {
        File pictureFile = getOutputMediaFile(fileName);
        if (pictureFile == null) {
            // Log.d(TAG,
            // "Error creating media file, check storage permissions: ");//
            // e.getMessage());
            return "";
        }
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.JPEG, 80, fos);
            fos.close();
        } catch (FileNotFoundException e) {
            // Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            // Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
        System.out.println("Path:" + pictureFile.getAbsolutePath());
        return pictureFile.getAbsolutePath();
    }

    /**
     * Create a File for saving an image or video
     */
    private File getOutputMediaFile(String fileName) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(
                Environment.getExternalStorageDirectory() + "/Android/data/"
                        + mActivity.getPackageName() + "/Files");

        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }

        File mediaFile;
        String mImageName = "ActivityTracker_" + fileName + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator
                + mImageName);
        return mediaFile;
    }

    private void showOptionOpenCameraforPravakta(String title, final FragmentActivity context, final File newfile) {
        final Dialog mDialog;
        mDialog = new Dialog(context);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        mDialog.setContentView(R.layout.paravakta_photo_selection);
        mDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));

        ViewGroup root = (ViewGroup) mDialog
                .findViewById(R.id.parent_view_for_font);

        WindowManager.LayoutParams wmlp = mDialog.getWindow().getAttributes();
        wmlp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wmlp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        TextView mFromCamera, mREmovePhoto, mViewPhoto;
        Button mCancel;
        TextView mTitile = (TextView) mDialog.findViewById(R.id.alertTitle);
        if (Utility.isValidStr(title))
            mTitile.setText(title);
        mFromCamera = (TextView) mDialog.findViewById(R.id.from_camera);
        mREmovePhoto = (TextView) mDialog.findViewById(R.id.remove_photo);
        mViewPhoto = (TextView) mDialog.findViewById(R.id.view_image);
        mCancel = (Button) mDialog.findViewById(R.id.cancel);

        mFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                openCameraApp(newfile);
            }
        });
        mREmovePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
                profileImage.setImageResource(R.drawable.img_profile_avatar);
                uriStr = null;
                imagePath = null;
            }
        });

        mViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.dismiss();
                if (profileImage.getDrawable() != null) {
                    if (uriStr != null) {
                        ImageViewer(mActivity, uriStr.toString());
                    }
                }
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        mDialog.show();
    }

    private void showAlertToSave() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                saveData();
            }


        });

        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void saveData() {

        PravaktaHaGainDTO dto = getDataObject();
        dto.setIsSync(1);
        boolean updateAck = PravaktaHaAgainDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
        if (updateAck) {
            Utility.showAlert(mActivity, null, MyConstants.SUC_MSG);

            clearFields();
        }
    }

    private void clearFields() {
        edtPravaktarName.setText("");
        edtPravaktaMobileNo.setText("");
        edtVillageName.setText("");
        edtPinCode.setText("");
        edtBlockName.setText("");
        edtDistrictName.setText("");

        edtTotalAcresPYear.setText("");
        edtTotalAcresCYear.setText("");
        edtPhiAcresPYear.setText("");
        edtPhiAcresCYear.setText("");
        edtTargetAcresPYear.setText("");
        edtTargetAcresCYear.setText("");

        edtTargerHybrid.setText("");

        if (checkBoxRice.isChecked())
            checkBoxRice.setChecked(false);
        if (checkBoxCorn.isChecked())
            checkBoxCorn.setChecked(false);
        if (checkBoxMustard.isChecked())
            checkBoxMustard.setChecked(false);
        if (checkBoxMillet.isChecked())
            checkBoxMillet.setChecked(false);

        spnBlockType.setSelection(0);

        profileImage.setImageResource(R.drawable.img_profile_avatar);

        imagePath = null;
        btnSubmit.setEnabled(false);
        activityId = 0;
        Utility.setActivityId(0, mActivity);

        edtTargerHybrid.setText("");
        layoutClear.setVisibility(View.INVISIBLE);
        builder = null;

        addFarmersCount.setVisibility(View.INVISIBLE);
    }

    private PravaktaHaGainDTO getDataObject() {
        PravaktaHaGainDTO dto = new PravaktaHaGainDTO();
        dto.setGeoLocation(location);
        dto.setPravaktaName(edtPravaktarName.getText().toString().trim());
        dto.setMobileNo(edtPravaktaMobileNo.getText().toString().trim());
        dto.setVillageName(edtVillageName.getText().toString().trim());
        dto.setPincode(edtPinCode.getText().toString().trim());
        dto.setBlockName(edtBlockName.getText().toString().trim());
        dto.setDistrictName(edtDistrictName.getText().toString().trim());
        dto.setPreviousYear(String.valueOf(previousYear));
        dto.setCurrentYear(String.valueOf(currentYear));
        dto.setTotalPreviousAcres(edtTotalAcresPYear.getText().toString().trim());
        dto.setTotalPresentAcres(edtTotalAcresCYear.getText().toString().trim());
        dto.setPhiPreviousAcres(edtPhiAcresPYear.getText().toString().trim());
        dto.setPhiPresentAcres(edtPhiAcresCYear.getText().toString().trim());
        dto.setTargetPreviousAcres(edtTargetAcresPYear.getText().toString().trim());
        dto.setTargetPresentAcres(edtTargetAcresCYear.getText().toString().trim());
        dto.setTargetHybrid(edtTargerHybrid.getText().toString().trim());
        dto.setBlockType(spnBlockType.getSelectedItem().toString());
        dto.setImageUrlPath(imagePath);

        if (checkBoxCorn.isChecked())
            dto.setCorn(true);
        else
            dto.setCorn(false);

        if (checkBoxRice.isChecked())
            dto.setRice(true);
        else
            dto.setRice(false);

        if (checkBoxMillet.isChecked())
            dto.setMillet(true);
        else
            dto.setMillet(false);

        if (checkBoxMustard.isChecked())
            dto.setMustard(true);
        else
            dto.setMustard(false);

        dto.setId(activityId);
        return dto;
    }

    private String getText(EditText editText) {
        return editText.getText().toString().trim();
    }

    private boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }

    private String validateFields() {
        /*if (imagePath == null)
            return getString(R.string.pht_farmer);*/

        if (isEmpty(edtPravaktarName)) {
            return getResources().getString(R.string.pravaktanamentempty);
        }
        if (isEmpty(edtPravaktaMobileNo)) {
            return getResources().getString(R.string.pravaktnonempty);
        }
        if (getText(edtPravaktaMobileNo).length() != 10) {
            return getResources().getString(R.string.validmobilenum);
        }
        if (isEmpty(edtVillageName)) {
            return getResources().getString(R.string.vagenamentempty);
        }
        if (isEmpty(edtPinCode)) {
            return getResources().getString(R.string.pincodeempty);
        }
        if (getText(edtPinCode).length() != 6) {
            return getResources().getString(R.string.zeropincode);
        }
        if (isEmpty(edtBlockName)) {
            return getResources().getString(R.string.blocknameempty);
        }
        if (isEmpty(edtDistrictName)) {
            return getResources().getString(R.string.districtnameempty);
        }
        if (isEmpty(edtTotalAcresPYear)) {
            return getResources().getString(R.string.totalacresnameempty);
        }
        if (isEmpty(edtTotalAcresCYear)) {
            return getResources().getString(R.string.totalacrescurrentnameempty);
        }
        if (isEmpty(edtPhiAcresPYear)) {
            return getResources().getString(R.string.phiacresnameempty);
        }
        if (isEmpty(edtPhiAcresCYear)) {
            return getResources().getString(R.string.phiacrescurrentnameempty);
        }
        if (Integer.valueOf(getText(edtPhiAcresPYear)) > Integer.valueOf(getText(edtTotalAcresPYear)))
            return getString(R.string.tot_acre_pre);

        if (Integer.valueOf(getText(edtPhiAcresCYear)) > Integer.valueOf(getText(edtTotalAcresCYear)))
            return getString(R.string.tot_acre_cur);

        if (isEmpty(edtTargetAcresPYear)) {
            return getResources().getString(R.string.targetacresnameempty);
        }
        if (isEmpty(edtTargetAcresCYear)) {
            return getResources().getString(R.string.targetacrescurrentnameempty);
        }
        if (Integer.valueOf(getText(edtTargetAcresPYear)) > Integer.valueOf(getText(edtTotalAcresPYear)))
            return getString(R.string.total_acr_pre);
        if (Integer.valueOf(getText(edtTargetAcresCYear)) > Integer.valueOf(getText(edtTotalAcresCYear))) {
            return getString(R.string.total_acr_cur);
        }
        if (!(checkBoxCorn.isChecked() || checkBoxRice.isChecked() || checkBoxMillet.isChecked() || checkBoxMustard.isChecked())) {
            return getResources().getString(R.string.check_any_crop);
        }
        if (isEmpty(edtTargerHybrid)) {
            return getResources().getString(R.string.targerHybridnamentempty);
        }
        if (spnBlockType.getSelectedItemPosition() == 0) {
            return getResources().getString(R.string.please_select_block_type);
        }
        return "";
    }

    private void setChange() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            tvFarmerName.setTextColor(Color.WHITE);
            tvMobileNo.setTextColor(Color.WHITE);
            tvVillageName.setTextColor(Color.WHITE);
            tvPincode.setTextColor(Color.WHITE);
            tvBlockName.setTextColor(Color.WHITE);
            tvDistrictName.setTextColor(Color.WHITE);
            tvTotalAcres.setTextColor(Color.WHITE);
            tvPhiAcres.setTextColor(Color.WHITE);
            tvTargetAcres.setTextColor(Color.WHITE);
            tvCrop.setTextColor(Color.WHITE);
            tvTargerHybrid.setTextColor(Color.WHITE);
            tvBlockType.setTextColor(Color.WHITE);

            tvPreviousYear.setTextColor(Color.WHITE);
            tvCurrentYear.setTextColor(Color.WHITE);

            rlTraget.setBackgroundResource(R.drawable.textfield_bg);

            spnBlockType.setBackgroundResource(R.drawable.spinner_bg_img);

            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(checkBoxRice, ColorStateList.valueOf(Color.WHITE));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
                CompoundButtonCompat.setButtonTintList(checkBoxCorn, ColorStateList.valueOf(Color.WHITE));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
                CompoundButtonCompat.setButtonTintList(checkBoxMillet, ColorStateList.valueOf(Color.WHITE));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
                CompoundButtonCompat.setButtonTintList(checkBoxMustard, ColorStateList.valueOf(Color.WHITE));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
            } else {
                checkBoxRice.setButtonTintList(ColorStateList.valueOf(Color.WHITE));//setButtonTintList is accessible directly on API>19
                checkBoxCorn.setButtonTintList(ColorStateList.valueOf(Color.WHITE));//setButtonTintList is accessible directly on API>19
                checkBoxMillet.setButtonTintList(ColorStateList.valueOf(Color.WHITE));//setButtonTintList is accessible directly on API>19
                checkBoxMustard.setButtonTintList(ColorStateList.valueOf(Color.WHITE));//setButtonTintList is accessible directly on API>19
            }

            checkBoxRice.setTextColor(Color.WHITE);
            checkBoxCorn.setTextColor(Color.WHITE);
            checkBoxMillet.setTextColor(Color.WHITE);
            checkBoxMustard.setTextColor(Color.WHITE);

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
            //layoutPht.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            tvFarmerName.setTextColor(Color.BLACK);
            tvMobileNo.setTextColor(Color.BLACK);
            tvVillageName.setTextColor(Color.BLACK);
            tvPincode.setTextColor(Color.BLACK);
            tvBlockName.setTextColor(Color.BLACK);
            tvDistrictName.setTextColor(Color.BLACK);
            tvTotalAcres.setTextColor(Color.BLACK);
            tvPhiAcres.setTextColor(Color.BLACK);
            tvTargetAcres.setTextColor(Color.BLACK);
            tvCrop.setTextColor(Color.BLACK);
            tvTargerHybrid.setTextColor(Color.BLACK);
            tvBlockType.setTextColor(Color.BLACK);

            tvPreviousYear.setTextColor(Color.BLACK);
            tvCurrentYear.setTextColor(Color.BLACK);

            rlTraget.setBackgroundResource(R.drawable.textfield_bg_lite);

            spnBlockType.setBackgroundResource(R.drawable.spinner_bg_img_light);

            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(checkBoxRice, ColorStateList.valueOf(Color.BLACK));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
                CompoundButtonCompat.setButtonTintList(checkBoxCorn, ColorStateList.valueOf(Color.BLACK));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
                CompoundButtonCompat.setButtonTintList(checkBoxMillet, ColorStateList.valueOf(Color.BLACK));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
                CompoundButtonCompat.setButtonTintList(checkBoxMustard, ColorStateList.valueOf(Color.BLACK));//Use android.support.v4.widget.CompoundButtonCompat when necessary else
            } else {
                checkBoxRice.setButtonTintList(ColorStateList.valueOf(Color.BLACK));//setButtonTintList is accessible directly on API>19
                checkBoxCorn.setButtonTintList(ColorStateList.valueOf(Color.BLACK));//setButtonTintList is accessible directly on API>19
                checkBoxMillet.setButtonTintList(ColorStateList.valueOf(Color.BLACK));//setButtonTintList is accessible directly on API>19
                checkBoxMustard.setButtonTintList(ColorStateList.valueOf(Color.BLACK));//setButtonTintList is accessible directly on API>19
            }

            checkBoxRice.setTextColor(Color.BLACK);
            checkBoxCorn.setTextColor(Color.BLACK);
            checkBoxMillet.setTextColor(Color.BLACK);
            checkBoxMustard.setTextColor(Color.BLACK);

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
            //layoutPht.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
        }
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        if (isDataAvaliable()) {
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }

        return true;
    }

    private void showAlertToExitScreen(final int callbackCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.formExitMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                mActivity.onBackPressedCallBack(callbackCode);
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }

    private boolean isDataAvaliable() {

        if (imagePath != null)
            return true;

        if (edtPravaktarName.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtPravaktaMobileNo.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtPravaktarName.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtVillageName.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtPinCode.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtBlockName.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtDistrictName.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtTotalAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtTotalAcresCYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtPhiAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtPhiAcresCYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtTargetAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (edtTargetAcresPYear.getText().toString().trim().length() > 0) {
            return true;
        }
        if (checkBoxCorn.isChecked() || checkBoxRice.isChecked() || checkBoxMillet.isChecked() || checkBoxMustard.isChecked()) {
            return true;
        }
        if (edtTargerHybrid.getText().toString().trim().length() > 0) {
            return true;
        }
        if (spnBlockType.getSelectedItemPosition() > 0) {
            return true;

        }
        return false;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            if (!mGoogleApiClient.isConnected())
                mGoogleApiClient.connect();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mGoogleApiClient != null) {
            if (mGoogleApiClient.isConnected())
                mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onDestroy() {
        location = null;
        super.onDestroy();
    }

    // from 1314- 1354 , related to cropping image funcationality
    public static class LoadScaledImageTask implements Runnable {
        private Handler mHandler = new Handler(Looper.getMainLooper());
        Context context;
        Uri uri;
        ImageView imageView;
        int width;

        public LoadScaledImageTask(Context context, Uri uri, ImageView imageView, int width) {
            this.context = context;
            this.uri = uri;
            this.imageView = imageView;
            this.width = width;
        }
        @Override
        public void run() {
            final int exifRotation = com.isseiaoki.simplecropview.util.Utils.getExifOrientation(context, uri);
            int maxSize = com.isseiaoki.simplecropview.util.Utils.getMaxSize();
            int requestSize = Math.min(width, maxSize);
            try {
                final Bitmap sampledBitmap = com.isseiaoki.simplecropview.util.Utils.decodeSampledBitmapFromUri(context, uri, requestSize);
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        imageView.setImageMatrix(com.isseiaoki.simplecropview.util.Utils.getMatrixFromExifOrientation(exifRotation));
                        imageView.setImageBitmap(sampledBitmap);
                    }
                });
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    private int calcImageSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        Display display =mActivity.getWindowManager().getDefaultDisplay();
        display.getMetrics(metrics);
        return Math.min(Math.max(metrics.widthPixels, metrics.heightPixels), 2048);
    }

    //View full Image
    public void ImageViewer(Context context, final String imgUrl) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.image_viewer, null);

        ViewGroup root = (ViewGroup) layout
                .findViewById(R.id.main_activity_view);

        imageDialog = new Dialog(context,
                android.R.style.Theme_Translucent_NoTitleBar);
        imageDialog.setContentView(layout);
        ImageView closeBtn = (ImageView) imageDialog
                .findViewById(R.id.closeBtn);
        ImageView editBtn = (ImageView) imageDialog.findViewById(R.id.editBtn);
        editBtn.setVisibility(View.VISIBLE);
        ImageView save_btn = (ImageView) imageDialog
                .findViewById(R.id.save_btn);
        ImageView imageview = (ImageView) imageDialog
                .findViewById(R.id.imageview);
        if (imgUrl != null && !imgUrl.isEmpty()) {

            //Glide.with(BaseActivity.this).load(imgUrl).placeholder(R.drawable.ic_profile_icon_fifty).error(R.drawable.ic_profile_icon_fifty).into(imageview);
            Glide.with(mActivity).load(imgUrl).placeholder(R.drawable.loadinggg).error(R.drawable.image_not_exist).into(imageview);
        }
        editBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                imageDialog.dismiss();
            }
        });
        imageDialog.show();

    }

}