package com.activitytrack.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.activitytrack.daos.RetailerInfoDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.RetailerInfoDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

public class RetailerInfoFragment extends BaseFragment{

	private View view;
	private EditText edtS1RetailerName;
	private EditText edtS1MobileNumber;
	private EditText edtS1AltMobileNumber;
	private EditText edtS2RetailerName;
	private EditText edtS2MobileNumber;
	private EditText edtS2AltMobileNumber;
	
	private LinearLayout mainLayout;
	private Button btnSubmit;
	private String activity;
	private long activityId;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.retailer_info_fragment, container, false);
		edtS1RetailerName=(EditText)view.findViewById(R.id.ri_s1_retailerName);
		edtS1MobileNumber=(EditText)view.findViewById(R.id.ri_s1_MobileNumber);
		edtS1AltMobileNumber=(EditText)view.findViewById(R.id.ri_s1_altMobileNumber);
		edtS2RetailerName=(EditText)view.findViewById(R.id.ri_s2_retailerName);
		edtS2MobileNumber=(EditText)view.findViewById(R.id.ri_s2_mobileNumber);
		edtS2AltMobileNumber=(EditText)view.findViewById(R.id.ri_s2_altMobileNumber);
		btnSubmit=(Button)view.findViewById(R.id.ri_submit);
		
		mainLayout=(LinearLayout)view.findViewById(R.id.ri_bg_laylout);
		
		setChange();
		
		Bundle bundle =getArguments();
		activity=bundle.getString("activity");
		activityId=bundle.getLong("activityId");
		
		btnSubmit.setOnClickListener(new OnClickListener() 
		{
			
			@Override
			public void onClick(View v) 
			{
				 String validation=validateFields();
				 if(validation.trim().length() == 0)
					{
						showAlertToSave();
					}else{
						if(!validation.equals(getResources().getString(R.string.validmobilenum)))
						Utility.showAlert(mActivity, "", validation);
					}	 
				
			} 
		});
		
		return view;
	}
	
	
	
	
	private String validateFields() 
	{
		if(edtS1RetailerName.getText().toString().trim().length() == 0)
			return  getResources().getString(R.string.retnameemp);
		
		if(edtS1MobileNumber.getText().toString().trim().length() == 0)
			return getResources().getString(R.string.mobilenonyempty);
		
		if(edtS1MobileNumber.getText().toString().trim().length() <= 9)
		{
			edtS1MobileNumber.setError(getResources().getString(R.string.validmobilenum));
			return getResources().getString(R.string.validmobilenum);
		}
		if(edtS1AltMobileNumber.getText().toString().trim().length() > 0)
			
			 if(edtS1AltMobileNumber.getText().toString().trim().length() <= 9)
			 {
				 edtS1AltMobileNumber.setError(getResources().getString(R.string.validmobilenum));
				 
				 return getResources().getString(R.string.validmobilenum); 
			 }
		
		 
		if(edtS2RetailerName.getText().toString().trim().length() == 0 && edtS2MobileNumber.getText().toString().trim().length() == 0){
	    	return "";
	    }
		 
	    if(edtS2RetailerName.getText().toString().trim().length() > 0)
		{
			 if(edtS2MobileNumber.getText().toString().trim().length() > 0)
			 {
				if(edtS2MobileNumber.getText().toString().trim().length() <= 9)
				{
					edtS2MobileNumber.setError(getResources().getString(R.string.validmobilenum));
					return getResources().getString(R.string.validmobilenum);
				}				
				
				if(edtS2AltMobileNumber.getText().toString().trim().length() > 0)
			  if(edtS2AltMobileNumber.getText().toString().trim().length() <= 9)
			  {
				  edtS2AltMobileNumber.setError(getResources().getString(R.string.validmobilenum));
				  return getResources().getString(R.string.validmobilenum);  
			  }
				  return ""; 
			 }else{
				 return  getResources().getString(R.string.mobilenonyempty);
			 }
		}else {
			if(edtS2MobileNumber.getText().toString().trim().length() > 0)
			 {
				if(edtS2MobileNumber.getText().toString().trim().length() <= 9)
				{
					edtS2MobileNumber.setError(getResources().getString(R.string.validmobilenum));
					return getResources().getString(R.string.validmobilenum);
				}
				
				return getResources().getString(R.string.retnameemp); 
			/*	if(edtS2AltMobileNumber.getText().toString().trim().length() <= 9)
					return "Enter valid AltMobile Number";*/
				 
				
			 }
		}
		
		
		return "";
	}
	
	
	 

	private void showAlertToSave() 
	{
		 AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		 builder.setMessage(getResources().getString(R.string.saveData));
		 builder.setPositiveButton(getResources().getString(R.string.yes),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
				saveData();
			}
			
		}); 
		 builder.setNegativeButton(getResources().getString(R.string.no),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				 
			}
		});
		
		 builder.create().show();
	}
		
	
	
	private void saveData()
	{
		boolean inserted = false;
		List<DTO> avalibleRecordsList = RetailerInfoDAO.getInstance().getRecordInfoById(activity, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
		
		List<RetailerInfoDTO> dtoList = new ArrayList<RetailerInfoDTO>();
		
		RetailerInfoDTO dto=new RetailerInfoDTO();
		
		//boolean inserted1 = false;
		
		dto.setRetailerName(edtS1RetailerName.getText().toString().trim());
		dto.setMobileNumber(Long.valueOf(edtS1MobileNumber.getText().toString().trim()));
		dto.setActivity(activity);
		dto.setActivityId(activityId);
		dtoList.add(dto);
		
		if(edtS1AltMobileNumber.getText().toString().trim().length() > 0)
		 
			/*  if(edtS1AltMobileNumber.getText().toString().trim().length() <= 9)
				*/

			dto.setAltMobileNumber(Long.valueOf(edtS1AltMobileNumber.getText().toString().trim()));
		
		//boolean inserted=RetailerInfoDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getDBObject(1));
		
		if(edtS2RetailerName.getText().toString().trim().length() > 0 && edtS2MobileNumber.getText().toString().trim().length() > 0)
		{
			RetailerInfoDTO dto1=new RetailerInfoDTO();
			dto1.setRetailerName(edtS2RetailerName.getText().toString().trim());
			dto1.setMobileNumber(Long.valueOf(edtS2MobileNumber.getText().toString().trim()));
			dto1.setActivity(activity);
			dto1.setActivityId(activityId);
			dtoList.add(dto1);
			if(edtS2AltMobileNumber.getText().toString().trim().length() > 0)
				dto1.setAltMobileNumber(Long.valueOf(edtS2AltMobileNumber.getText().toString().trim()));
			
			//inserted1=RetailerInfoDAO.getInstance().insert(dto1, DBHandler.getInstance(mActivity).getDBObject(1));
		}else{
			//inserted1 = true;
		}
		
		if(avalibleRecordsList != null && avalibleRecordsList.size() > 0){
			inserted = insertData(dtoList);
			if(inserted)
			  {
				  Toast.makeText(mActivity, "Successfully inserted", Toast.LENGTH_SHORT).show();
				  mActivity.popFragments();
				  clearFields();
			  }else{
				  Toast.makeText(mActivity, "Failed to insert", Toast.LENGTH_SHORT).show();
			  }
		}else{
			if(dtoList.size() >= 0){
				inserted = insertData(dtoList);
				if(inserted)
				  {
					  Toast.makeText(mActivity, "Successfully inserted", Toast.LENGTH_SHORT).show();
					  mActivity.popFragments();
					  clearFields();
				  }else{
					  Toast.makeText(mActivity, "Failed to insert", Toast.LENGTH_SHORT).show();
				  }
				
			}else{
			
				Utility.showAlert(mActivity, "", "Enter retailers");
			}	 
		}
		
		/*if(inserted && inserted1)
	  {
		  Toast.makeText(mActivity, "Successfully inserted", Toast.LENGTH_SHORT).show();
			clearFields();
	  }else{
		  Toast.makeText(mActivity, "Failed to insert", Toast.LENGTH_SHORT).show();
	  }*/
	 
}
	private boolean insertData(List<RetailerInfoDTO> list) {
		for (RetailerInfoDTO dto : list) {
			RetailerInfoDAO.getInstance().insert(dto, DBHandler.getInstance(mActivity).getDBObject(1));
		}
		return true;

	}
	

	private void clearFields() 
	{
		edtS1RetailerName.setText("");
		edtS1MobileNumber.setText("");
		edtS1AltMobileNumber.setText("");
		edtS2RetailerName.setText("");
		edtS2MobileNumber.setText("");
		edtS2AltMobileNumber.setText("");
	}

	private void setChange(){
		if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK))
		{
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
			
		}else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) 
		{
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
		}
	}

	@Override
	public boolean onBackPressed(int callbackCode) {
		if(isDataAvailable()){
			showAlertToExitScreen(callbackCode);
		}else{
			mActivity.onBackPressedCallBack(callbackCode);
		}
		return true;
	}
	private void showAlertToExitScreen(final int callbackCode){
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.formExitMsg));
		builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mActivity.onBackPressedCallBack(callbackCode);
			}
		});
		
		builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
			}
		});
		
		builder.create().show();
	}
	
	
	private boolean isDataAvailable() {
		if (edtS1RetailerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS1MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS1AltMobileNumber.getText().toString().trim().length() > 0)
			return true;
		
		if (edtS2RetailerName.getText().toString().trim().length() > 0)
			return true;

		if (edtS2MobileNumber.getText().toString().trim().length() > 0)
			return true;

		if (edtS2AltMobileNumber.getText().toString().trim().length() > 0)
			return true;
		
		return false;
		 
	}
}