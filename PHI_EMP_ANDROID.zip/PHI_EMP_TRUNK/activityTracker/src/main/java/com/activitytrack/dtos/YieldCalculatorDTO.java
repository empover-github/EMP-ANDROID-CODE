package com.activitytrack.dtos;

public class YieldCalculatorDTO  implements DTO 
{
	private long mobileId;
	private String location;
	private int isSync;
	private float length;
	private float  breadth;
	private float yield;
	private float  moisture;
	private String competitorName;
	private String competitorHybrid;
	private float area;
    private float yieldHarvested;
    private float yieldMoisture;
    private String activity;
    private long activityId;
	
	public long getId() {
		return mobileId;
	}
	public void setId(long id) {
		this.mobileId = id;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getIsSync() {
		return isSync;
	}
	public void setIsSync(int isSync) {
		this.isSync = isSync;
	}
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	public float getBreadth() {
		return breadth;
	}
	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}
	public float getYield() {
		return yield;
	}
	public void setYield(float yield) {
		this.yield = yield;
	}
	public float getMoisture() {
		return moisture;
	}
	public void setMoisture(float moisture) {
		this.moisture = moisture;
	}
	public String getCompetitorName() {
		return competitorName;
	}
	public void setCompetitorName(String competitorName) {
		this.competitorName = competitorName;
	}
	public String getCompetitorHybrid() {
		return competitorHybrid;
	}
	public void setCompetitorHybrid(String competitorHybrid) {
		this.competitorHybrid = competitorHybrid;
	}
	public float getArea() {
		return area;
	}
	public void setArea(float area) {
		this.area = area;
	}
	public float getYieldHarvested() {
		return yieldHarvested;
	}
	public void setYieldHarvested(float yieldHarvested) {
		this.yieldHarvested = yieldHarvested;
	}
	public float getYieldMoisture() {
		return yieldMoisture;
	}
	public void setYieldMoisture(float yieldMoisture) {
		this.yieldMoisture = yieldMoisture;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public long getActivityId() {
		return activityId;
	}
	public void setActivityId(long activityId) {
		this.activityId = activityId;
	}
}
