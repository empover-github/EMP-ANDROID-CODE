package com.activitytrack.graph;

import com.github.mikephil.charting.utils.ValueFormatter;

import java.text.DecimalFormat;

public class MyValueFormatter implements ValueFormatter {

    private DecimalFormat mFormat;
    
    public MyValueFormatter() {
        mFormat = new DecimalFormat("#########");
    }
    
    @Override
    public String getFormattedValue(float value) {
        return mFormat.format((int)value);
    }

}
