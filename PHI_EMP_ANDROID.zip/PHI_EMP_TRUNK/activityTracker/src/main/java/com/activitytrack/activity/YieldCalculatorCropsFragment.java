package com.activitytrack.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.daos.YieldCalculatorCropsDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.YieldCalculatorCropsDTO;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.List;

public class YieldCalculatorCropsFragment extends BaseFragment {

private View view;
	
	private LinearLayout mainLayout;
	private String activity;
	private long activityId;
	private long cropId;
	private Spinner spnCropId;
	
	//crop layouts
	private LinearLayout cornLayout;
	private LinearLayout riceLayout;
	private LinearLayout milletLayout;
	private LinearLayout mustardLayout;
	
	//corn pionner
	private EditText edtLengthCornPio;
	private EditText edtRowSpacingCornPio;
	private EditText edtRowHarvestedCornPio;
	private EditText edtBreadthCornPio;
	private EditText edtHarvestedPlantsCornPio;
	private EditText edtPopulCornPio;
	private EditText edtTotCubWeiCornPio;
	private EditText edtShellingCornPio;
	private EditText edtTotGrainWeiCornPio;
	private EditText edtMositureCornPio;
	private TextView tvDryGrainWeiCornPio;
	private TextView tvPerAcreYieldCornPio;
	private Button btnCalcuateCorn;
	private Button btnSubmitCorn;
	private LinearLayout resultLayoutCorn;
	private LinearLayout comparisionLayoutCorn;
	private TextView tvYieldGainOverCorn;
	private TextView tvYieldGainOverPerCorn;
	private ImageView imgInfo_p;
	
	
	//corn others
	private EditText edtLengthCornOth;
	private EditText edtRowSpacingCornOth;
	private EditText edtRowHarvestedCornOth;
	private EditText edtBreadthCornOth;
	private EditText edtHarvestedPlantsCornOth;
	private EditText edtPopulCornOth;
	private EditText edtTotCubWeiCornOth;
	private EditText edtShellingCornOth;
	private EditText edtTotGrainWeiCornOth;
	private EditText edtMositureCornOth;
	private TextView tvDryGrainWeiCornOth;
	private TextView tvPerAcreYieldCornOth;
	private ImageView imgInfo_o;
	
	//rice pio
	private EditText edtLengthRicePio;
	private EditText edtBreadthRicePio;
	private EditText edtHillPerRicePio;
	private EditText edtPopulRicePio;
	private EditText edtTotGrainWeiRicePio;
	private EditText edtMositureRicePio;
	private TextView tvDryGrainWeiRicePio;
	private TextView tvPerAcreYieldRicePio;
	private Button btnCalcuateRice;
	private Button btnSubmitRice;
	private LinearLayout resultLayoutRice;
	private LinearLayout comparisionLayoutRice;
	private TextView tvYieldGainOverRice;
	private TextView tvYieldGainOverPerRice;
   
	//rice--oth
	private EditText edtLengthRiceOth;
	private EditText edtBreadthRiceOth;
	private EditText edtHillPerRiceOth;
	private EditText edtPopulRiceOth;
	private EditText edtTotGrainWeiRiceOth;
	private EditText edtMositureRiceOth;
	private TextView tvDryGrainWeiRiceOth;
	private TextView tvPerAcreYieldRiceOth;

	//millet--pio
	private EditText edtLengthMilletPio;
	private EditText edtBreadthMilletPio;
	private EditText edtTotearHeadMilletPio;
	private EditText edtMositureMilletPio;
	private TextView tvDryGrainWeiMilletPio;
	private TextView tvPerAcreYieldMilletPio;
	private Button btnCalcuateMillet;
	private Button btnSubmitMillet;
	private LinearLayout resultLayoutMillet;
	private LinearLayout comparisionLayoutMillet;
	private TextView tvYieldGainOverMillet;
	private TextView tvYieldGainOverPerMillet;
	
	// millet--others
	private EditText edtLengthMilletOth;
	private EditText edtBreadthMilletOth;
	private EditText edtTotearHeadMilletOth;
	private EditText edtMositureMilletOth;
	private TextView tvDryGrainWeiMilletOth;
	private TextView tvPerAcreYieldMilletOth;
	
	//mustard--pio
	private EditText edtLengthMustardPio;
	private EditText edtBreadthMustardPio;
	private EditText edtTotGrainWeiMustardPio;
	private EditText edtMositureMustardPio;
	private TextView tvDryGrainWeiMustardPio;
	private TextView tvPerAcreYieldMustardPio;
	private Button btnCalcuateMustard;
	private Button btnSubmitMustard;
	private LinearLayout resultLayoutMustard;
	private LinearLayout comparisionLayoutMustard;
	private TextView tvYieldGainOverMustard;
	private TextView tvYieldGainOverPerMustard;
	
	// mustard--others
	private EditText edtLengthMustardOth;
	private EditText edtBreadthMustardOth;
	private EditText edtTotGrainWeiMustardOth;
	private EditText edtMositureMustardOth;
	private TextView tvDryGrainWeiMustardOth;
	private TextView tvPerAcreYieldMustardOth;

	private boolean isSaved;
	
	private List<String> cropNameList=new ArrayList<String>();
    private List<DTO>cropDTOList=new ArrayList<DTO>();
    private long selectedCropId;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.yield_calculator_crops_fragment, container, false);
		mainLayout=(LinearLayout)view.findViewById(R.id.yc_bg_layout);
		
		//corn 
		cornLayout =(LinearLayout)view.findViewById(R.id.corn_layout);
		
        edtLengthCornPio     = (EditText)view.findViewById(R.id.corn_length_p);
	    edtRowSpacingCornPio = (EditText)view.findViewById(R.id.corn_rowSpacing_p);
        edtRowHarvestedCornPio = (EditText)view.findViewById(R.id.corn_rowsHarvested_p);
	    edtBreadthCornPio = (EditText)view.findViewById(R.id.corn_breadth_p);
	    edtHarvestedPlantsCornPio = (EditText)view.findViewById(R.id.corn_harvested_plants_p);
		edtPopulCornPio = (EditText)view.findViewById(R.id.corn_population_p);
	    edtTotCubWeiCornPio = (EditText)view.findViewById(R.id.corn_total_cob_p);
		edtShellingCornPio = (EditText)view.findViewById(R.id.corn_sheeling_p);
	    edtTotGrainWeiCornPio = (EditText)view.findViewById(R.id.corn_total_gain_weight_p);
		edtMositureCornPio =  (EditText)view.findViewById(R.id.corn_moisture_p);
		tvDryGrainWeiCornPio =  (TextView)view.findViewById(R.id.corn_totalDryGain_p);
	    tvPerAcreYieldCornPio = (TextView)view.findViewById(R.id.corn_perAcresYield_p);
		btnCalcuateCorn = (Button)view.findViewById(R.id.corn_calculate);
		btnSubmitCorn = (Button)view.findViewById(R.id.corn_submit);
	    resultLayoutCorn = (LinearLayout)view.findViewById(R.id.corn_result_layout);
	    edtLengthCornOth = (EditText)view.findViewById(R.id.corn_length_o);
	 	edtRowSpacingCornOth = (EditText)view.findViewById(R.id.corn_rowSpacing_o);
	 	edtRowHarvestedCornOth = (EditText)view.findViewById(R.id.corn_rowsHarvested_o);
	    edtBreadthCornOth = (EditText)view.findViewById(R.id.corn_breadth_o);
	 	edtHarvestedPlantsCornOth = (EditText)view.findViewById(R.id.corn_harvested_plants_o);
	 	edtPopulCornOth = (EditText)view.findViewById(R.id.corn_population_o);
	 	edtTotCubWeiCornOth = (EditText)view.findViewById(R.id.corn_total_cob_o);
	    edtShellingCornOth = (EditText)view.findViewById(R.id.corn_sheeling_o);
	    edtTotGrainWeiCornOth = (EditText)view.findViewById(R.id.corn_total_gain_weight_o);
	 	edtMositureCornOth = (EditText)view.findViewById(R.id.corn_moisture_o);
	 	tvDryGrainWeiCornOth = (TextView)view.findViewById(R.id.corn_totalDryGain_o);
	 	tvPerAcreYieldCornOth = (TextView)view.findViewById(R.id.corn_perAcresYield_o);
	 	imgInfo_p = (ImageView) view.findViewById(R.id.corn_info_p);
	 	imgInfo_o = (ImageView) view.findViewById(R.id.corn_info_o);

	 	//rice
		riceLayout =(LinearLayout)view.findViewById(R.id.rice_layout);
		edtLengthRicePio = (EditText)view.findViewById(R.id.rice_length_p);
	    edtBreadthRicePio = (EditText)view.findViewById(R.id.rice_breadth_p);
	    edtHillPerRicePio = (EditText)view.findViewById(R.id.rice_hillPer_p);
		edtPopulRicePio = (EditText)view.findViewById(R.id.rice_population_p);
		edtTotGrainWeiRicePio = (EditText)view.findViewById(R.id.rice_total_grain_weight_p);
		edtMositureRicePio= (EditText)view.findViewById(R.id.rice_moisture_p);
		tvDryGrainWeiRicePio = (TextView)view.findViewById(R.id.rice_totalDryGain_p);
		tvPerAcreYieldRicePio= (TextView)view.findViewById(R.id.rice_perAcresYield_p);
		btnCalcuateRice= (Button)view.findViewById(R.id.rice_calculate);
		btnSubmitRice=(Button)view.findViewById(R.id.rice_submit);
		resultLayoutRice=(LinearLayout)view.findViewById(R.id.rice_result_layout);
		edtLengthRiceOth=(EditText)view.findViewById(R.id.rice_length_o);;
		edtBreadthRiceOth= (EditText)view.findViewById(R.id.rice_breadth_o);
		edtHillPerRiceOth= (EditText)view.findViewById(R.id.rice_hillPer_o);
		edtPopulRiceOth= (EditText)view.findViewById(R.id.rice_population_o);
		edtTotGrainWeiRiceOth= (EditText)view.findViewById(R.id.rice_total_grain_weight_o);
		edtMositureRiceOth= (EditText)view.findViewById(R.id.rice_moisture_o);
		tvDryGrainWeiRiceOth= (TextView)view.findViewById(R.id.rice_totalDryGain_o);
		tvPerAcreYieldRiceOth=(TextView)view.findViewById(R.id.rice_perAcresYield_o);
		
		// millet
		milletLayout =(LinearLayout)view.findViewById(R.id.millet_layout);
		edtLengthMilletPio = (EditText)view.findViewById(R.id.millet_length_p);
		edtBreadthMilletPio= (EditText)view.findViewById(R.id.millet_breadth_p);
		edtTotearHeadMilletPio= (EditText)view.findViewById(R.id.millet_total_ear_weight_p);
		edtMositureMilletPio= (EditText)view.findViewById(R.id.millet_moisture_p);
		tvDryGrainWeiMilletPio= (TextView)view.findViewById(R.id.millet_totalDryGain_p);
	    tvPerAcreYieldMilletPio= (TextView)view.findViewById(R.id.millet_perAcresYield_p);
	    btnCalcuateMillet =(Button)view.findViewById(R.id.millet_calculate);
		btnSubmitMillet=(Button)view.findViewById(R.id.millet_submit);
		resultLayoutMillet=(LinearLayout)view.findViewById(R.id.millet_result_layout);
		edtLengthMilletOth=(EditText)view.findViewById(R.id.millet_length_o);
		edtBreadthMilletOth=(EditText)view.findViewById(R.id.millet_breadth_o);
		edtTotearHeadMilletOth= (EditText)view.findViewById(R.id.millet_total_ear_weight_o);
	    edtMositureMilletOth= (EditText)view.findViewById(R.id.millet_moisture_o);
		tvDryGrainWeiMilletOth= (TextView)view.findViewById(R.id.millet_totalDryGain_o);
		tvPerAcreYieldMilletOth= (TextView)view.findViewById(R.id.millet_perAcresYield_o);

		//mustard
		mustardLayout =(LinearLayout)view.findViewById(R.id.mustard_layout);
		edtLengthMustardPio = (EditText)view.findViewById(R.id.mustard_length_p);
		edtBreadthMustardPio= (EditText)view.findViewById(R.id.mustard_breadth_p);
		edtTotGrainWeiMustardPio= (EditText)view.findViewById(R.id.mustard_total_grain_weight_p);
		edtMositureMustardPio= (EditText)view.findViewById(R.id.mustard_moisture_p);
		tvDryGrainWeiMustardPio= (TextView)view.findViewById(R.id.mustard_totalDryGain_p);
	    tvPerAcreYieldMustardPio= (TextView)view.findViewById(R.id.mustard_perAcresYield_p);
	    btnCalcuateMustard =(Button)view.findViewById(R.id.mustard_calculate);
		btnSubmitMustard=(Button)view.findViewById(R.id.mustard_submit);
		resultLayoutMustard=(LinearLayout)view.findViewById(R.id.mustard_result_layout);
		edtLengthMustardOth = (EditText)view.findViewById(R.id.mustard_length_o);
		edtBreadthMustardOth= (EditText)view.findViewById(R.id.mustard_breadth_o);
		edtTotGrainWeiMustardOth= (EditText)view.findViewById(R.id.mustard_total_grain_weight_o);
		edtMositureMustardOth= (EditText)view.findViewById(R.id.mustard_moisture_o);
		tvDryGrainWeiMustardOth = (TextView)view.findViewById(R.id.mustard_totalDryGain_o);
	    tvPerAcreYieldMustardOth = (TextView)view.findViewById(R.id.mustard_perAcresYield_o);
	    
	    comparisionLayoutCorn = (LinearLayout) view.findViewById(R.id.corn_gainComparsion_layout);
	    comparisionLayoutRice = (LinearLayout) view.findViewById(R.id.rice_gainComparsion_layout);
	    comparisionLayoutMillet = (LinearLayout) view.findViewById(R.id.millet_gainComparsion_layout);
	    comparisionLayoutMustard = (LinearLayout) view.findViewById(R.id.mustard_gainComparsion_layout);
	    

		tvYieldGainOverCorn = (TextView) view.findViewById(R.id.corn_yieldgainover);
		tvYieldGainOverPerCorn = (TextView) view.findViewById(R.id.corn_percentyieldgainovercom);
		
		tvYieldGainOverRice = (TextView) view.findViewById(R.id.rice_yieldgainover);
		tvYieldGainOverPerRice = (TextView) view.findViewById(R.id.rice_percentyieldgainovercom);
		
		tvYieldGainOverMillet = (TextView) view.findViewById(R.id.millet_yieldgainover);
		tvYieldGainOverPerMillet = (TextView) view.findViewById(R.id.millet_percentyieldgainovercom);
		
		tvYieldGainOverMustard = (TextView) view.findViewById(R.id.mustard_yieldgainover);
		tvYieldGainOverPerMustard = (TextView) view.findViewById(R.id.mustard_percentyieldgainovercom);
		
		spnCropId=(Spinner)view.findViewById(R.id.yield_crop);
	    
		
		setChange();
		
		//reading data from bundle
		Bundle bundle = getArguments();
		activity = bundle.getString("activity");
		if(activity.equals(MyConstants.ACTIVITY_PDA)){
			//btnSubmit.setVisibility(View.VISIBLE);
			activityId = bundle.getLong("activityId");
			cropId = bundle.getLong("cropId");
			List<DTO> yList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
			
			if(yList != null && yList.size() > 1){
				populate(yList);
			}
			
		}else{
			spnCropId.setVisibility(View.VISIBLE);
		}
		
		dispScreenByCropId((int)cropId);
		
		edtRowSpacingCornPio.addTextChangedListener(new CornBreadthListnPio());
		edtRowHarvestedCornPio.addTextChangedListener(new CornBreadthListnPio());
		
		edtRowSpacingCornOth.addTextChangedListener(new CornBreadthListnOth());
		edtRowHarvestedCornOth.addTextChangedListener(new CornBreadthListnOth());
		
		edtLengthCornPio.addTextChangedListener(new CornHarvestedPlantsListnPio());
		edtLengthCornOth.addTextChangedListener(new CornHarvestedPlantsListnOth());
		
		edtHarvestedPlantsCornPio.addTextChangedListener(new CornHarvestedPlantsListnPio());
		edtHarvestedPlantsCornOth.addTextChangedListener(new CornHarvestedPlantsListnOth());
		
		edtTotCubWeiCornPio.addTextChangedListener(new CornTotalGainListnPio());
		edtShellingCornPio.addTextChangedListener(new CornTotalGainListnPio());
		
		edtTotCubWeiCornOth.addTextChangedListener(new CornTotalGainListnOth());
		edtShellingCornOth.addTextChangedListener(new CornTotalGainListnOth());
		
		edtHillPerRicePio.addTextChangedListener(new RicePopulationListnPio());
		edtHillPerRiceOth.addTextChangedListener(new RicePopulationListnOth());
		
		cropDTOList = CropMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if(cropDTOList!=null && cropDTOList.size()>0)
        {
        	cropNameList.clear();
        	for(DTO dto:cropDTOList)
        	{
        		if(cropNameList.size() == 0)
        		{
        			cropNameList.add("Select");
        		}
        	 CropMasterDTO  cropMasterDTO=(CropMasterDTO) dto;
        	 cropNameList.add(cropMasterDTO.getName());
        	 
        		
        	}
        }
        
        ArrayAdapter< String> cropAdapter=new ArrayAdapter<String>(mActivity,android.R.layout.simple_spinner_dropdown_item,cropNameList);
        spnCropId.setAdapter(cropAdapter);
        spnCropId.setOnItemSelectedListener(new OnItemSelectedListener() 
        {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) 
			{
				//tvNameOfCrop.setText(tvNameOfCrop.getText() + parent.getItemAtPosition(position).toString().);
				
				if(position > 0)
				{
					 CropMasterDTO cropMasterDTO=(CropMasterDTO) cropDTOList.get(position - 1);
					 selectedCropId=cropMasterDTO.getId();
					dispScreenByCropId((int)selectedCropId);
					 if(parent.getChildCount() > 0)
					 {
						 if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT))
						 {
							 ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
							 
						 }else{
							 ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
						 }
					 }
						 

				}else if(parent.getChildAt(0) != null){
					if(parent.getChildCount() > 0)
					 {
						 if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT))
						 {
							 ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
							 
						 }else{
							 ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
						 }
					 }
				 }
					 
				 
			
			
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) 
			{
				 
			}
		});
		
		btnCalcuateCorn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateCornFields();
				if(validation == null){
					calculateCorn();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		btnSubmitCorn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateCornFields();
				if(validation == null){
					showAlertToSaveCorn();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		btnCalcuateRice.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateRiceFields();
				if(validation == null){
					calculateRice();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		btnSubmitRice.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateRiceFields();
				if(validation == null){
					showAlertToSaveRice();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		btnCalcuateMillet.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateMilletFields();
				if(validation == null){
					calculateMillet();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		btnSubmitMillet.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateMilletFields();
				if(validation == null){
					showAlertToSaveMillet();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		btnCalcuateMustard.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateMustardFields();
				if(validation == null){
					calculateMustard();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		btnSubmitMustard.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String validation = validateMustardFields();
				if(validation == null){
					showAlertToSaveMustard();
				}else{
					Utility.showAlert(mActivity, "", validation);
				}
				
			}
		});
		
		imgInfo_p.setOnClickListener(new InfoClick());
		imgInfo_o.setOnClickListener(new InfoClick());
		
		return view;
	}

	private void calculateCorn(){
		//total_dry_gain_weight = (total_gain_weight * (1-moisture/100))/(1-14 / 100); 
		float lengthPio =Float.parseFloat(edtLengthCornPio.getText().toString().trim());
		float breadthPio =Float.parseFloat(edtBreadthCornPio.getText().toString().trim());
		float mositurePio =Float.parseFloat(edtMositureCornPio.getText().toString().trim());
		float totalGainPio =Float.parseFloat(edtTotGrainWeiCornPio.getText().toString().trim());
		
		float lengthOth =Float.parseFloat(edtLengthCornOth.getText().toString().trim());
		float breadthOth =Float.parseFloat(edtBreadthCornOth.getText().toString().trim());
		float mositureOth =Float.parseFloat(edtMositureCornOth.getText().toString().trim());
		float totalGainOth =Float.parseFloat(edtTotGrainWeiCornOth.getText().toString().trim());
		
		float totalDryDainDeightPio = (totalGainPio * (1-mositurePio/100))/(1-(float)14/100);
		float totalDryGainWeightOth = (totalGainOth * (1-mositureOth/100))/(1-(float)14/100);
		
		tvDryGrainWeiCornPio.setText(""+Utility.round(totalDryDainDeightPio, 2));
		tvDryGrainWeiCornOth.setText(""+Utility.round(totalDryGainWeightOth, 2));
		
		float perAcreYieldPio = (MyConstants.POPULATION_CONST*totalDryDainDeightPio)/(lengthPio * breadthPio);
		tvPerAcreYieldCornPio.setText(""+Utility.round(perAcreYieldPio, 2));
		
		float perAcreYieldOth = (MyConstants.POPULATION_CONST*totalDryGainWeightOth)/(lengthOth * breadthOth);
		tvPerAcreYieldCornOth.setText(""+Utility.round(perAcreYieldOth, 2));
		
		tvYieldGainOverCorn.setText(""+Utility.round((perAcreYieldPio-perAcreYieldOth), 2));
		tvYieldGainOverPerCorn.setText(""+Utility.round((((perAcreYieldPio-perAcreYieldOth)/perAcreYieldOth))*100, 2));
		
		resultLayoutCorn.setVisibility(View.VISIBLE);
		comparisionLayoutCorn.setVisibility(View.VISIBLE);
		if(activity.equals(MyConstants.ACTIVITY_PDA)){
			btnSubmitCorn.setVisibility(View.VISIBLE);
		}
	}
	
	private void calculateRice(){
		//total_dry_gain_weight = (total_gain_weight * (1-moisture/100))/(1-12 / 100); 
		float lengthPio =Float.parseFloat(edtLengthRicePio.getText().toString().trim());
		float breadthPio =Float.parseFloat(edtBreadthRicePio.getText().toString().trim());
		float mositurePio =Float.parseFloat(edtMositureRicePio.getText().toString().trim());
		float totalGainPio =Float.parseFloat(edtTotGrainWeiRicePio.getText().toString().trim());
		
		float lengthOth =Float.parseFloat(edtLengthRiceOth.getText().toString().trim());
		float breadthOth =Float.parseFloat(edtBreadthRiceOth.getText().toString().trim());
		float mositureOth =Float.parseFloat(edtMositureRiceOth.getText().toString().trim());
		float totalGainOth =Float.parseFloat(edtTotGrainWeiRiceOth.getText().toString().trim());
		
		float totalDryDainDeightPio = (totalGainPio * (1-mositurePio/100))/(1-(float)12/100);
		float totalDryGainWeightOth = (totalGainOth * (1-mositureOth/100))/(1-(float)12/100);
	 
		tvDryGrainWeiRicePio.setText(""+Utility.round(totalDryDainDeightPio, 2));
	   tvDryGrainWeiRiceOth.setText(""+Utility.round(totalDryGainWeightOth, 2));

		float perAcreYieldPio = (MyConstants.POPULATION_CONST*totalDryDainDeightPio)/(lengthPio * breadthPio);
		tvPerAcreYieldRicePio.setText(""+Utility.round(perAcreYieldPio, 2));

		float perAcreYieldOth = (MyConstants.POPULATION_CONST*totalDryGainWeightOth)/(lengthOth * breadthOth);
		tvPerAcreYieldRiceOth.setText(""+Utility.round(perAcreYieldOth, 2));
		
		tvYieldGainOverRice.setText(""+Utility.round((perAcreYieldPio-perAcreYieldOth), 2));
		tvYieldGainOverPerRice.setText(""+Utility.round((((perAcreYieldPio-perAcreYieldOth)/perAcreYieldOth))*100, 2));
		
		resultLayoutRice.setVisibility(View.VISIBLE);
		comparisionLayoutRice.setVisibility(View.VISIBLE);
		if(activity.equals(MyConstants.ACTIVITY_PDA)){
			btnSubmitRice.setVisibility(View.VISIBLE);
		}

	}

	private void calculateMillet(){
		//total_dry_gain_weight = (total_gain_weight * (1-moisture/100))/(1-12 / 100); 
				
		        float lengthPio =Float.parseFloat(edtLengthMilletPio.getText().toString().trim());
				float breadthPio =Float.parseFloat(edtBreadthMilletPio.getText().toString().trim());
				float mositurePio =Float.parseFloat(edtMositureMilletPio.getText().toString().trim());
				float totalearheadweightPio =Float.parseFloat(edtTotearHeadMilletPio.getText().toString().trim());
				
				float lengthOth =Float.parseFloat(edtLengthMilletOth.getText().toString().trim());
				float breadthOth =Float.parseFloat(edtBreadthMilletOth.getText().toString().trim());
				float mositureOth =Float.parseFloat(edtMositureMilletOth.getText().toString().trim());
				float totalearheadweightOth =Float.parseFloat(edtTotearHeadMilletOth.getText().toString().trim());
				
				float totalDryDainDeightPio = (float) (((totalearheadweightPio * 0.7) * (1-mositurePio/100))/(1-(float)10/100));
				float totalDryGainWeightOth = (float) (((totalearheadweightOth * 0.7) * (1-mositureOth/100))/(1-(float)10/100));
			 
				tvDryGrainWeiMilletPio.setText(""+Utility.round(totalDryDainDeightPio, 2));
			    tvDryGrainWeiMilletOth.setText(""+Utility.round(totalDryGainWeightOth, 2));

				float perAcreYieldPio = (MyConstants.POPULATION_CONST*totalDryDainDeightPio)/(lengthPio * breadthPio);
				tvPerAcreYieldMilletPio.setText(""+Utility.round(perAcreYieldPio, 2));

				float perAcreYieldOth = (MyConstants.POPULATION_CONST*totalDryGainWeightOth)/(lengthOth * breadthOth);
				tvPerAcreYieldMilletOth.setText(""+Utility.round(perAcreYieldOth, 2));
				
				tvYieldGainOverMillet.setText(""+Utility.round((perAcreYieldPio-perAcreYieldOth), 2));
				tvYieldGainOverPerMillet.setText(""+Utility.round((((perAcreYieldPio-perAcreYieldOth)/perAcreYieldOth))*100, 2));
				
				resultLayoutMillet.setVisibility(View.VISIBLE);
				comparisionLayoutMillet.setVisibility(View.VISIBLE);
				if(activity.equals(MyConstants.ACTIVITY_PDA)){
					btnSubmitMillet.setVisibility(View.VISIBLE);
				}
	
	}

	private void calculateMustard(){
		   
		    float lengthPio =Float.parseFloat(edtLengthMustardPio.getText().toString().trim());
			float breadthPio =Float.parseFloat(edtBreadthMustardPio.getText().toString().trim());
			float mositurePio =Float.parseFloat(edtMositureMustardPio.getText().toString().trim());
			float totalGainPio =Float.parseFloat(edtTotGrainWeiMustardPio.getText().toString().trim());
			
			float lengthOth =Float.parseFloat(edtLengthMustardOth.getText().toString().trim());
			float breadthOth =Float.parseFloat(edtBreadthMustardOth.getText().toString().trim());
			float mositureOth =Float.parseFloat(edtMositureMustardOth.getText().toString().trim());
			float totalGainOth =Float.parseFloat(edtTotGrainWeiMustardOth.getText().toString().trim());
			
			float totalDryDainDeightPio = (float) (totalGainPio * (1-mositurePio/100))/(1-(float)9/100);
			float totalDryGainWeightOth = (float) (totalGainOth * (1-mositureOth/100))/(1-(float)9/100);
			
			tvDryGrainWeiMustardPio.setText(""+Utility.round(totalDryDainDeightPio, 2));
		    tvDryGrainWeiMustardOth.setText(""+Utility.round(totalDryGainWeightOth, 2));

			float perAcreYieldPio = (MyConstants.POPULATION_CONST*totalDryDainDeightPio)/(lengthPio * breadthPio);
			tvPerAcreYieldMustardPio.setText(""+Utility.round(perAcreYieldPio, 2));

			float perAcreYieldOth = (MyConstants.POPULATION_CONST*totalDryGainWeightOth)/(lengthOth * breadthOth);
			tvPerAcreYieldMustardOth.setText(""+Utility.round(perAcreYieldOth, 2));
			
			tvYieldGainOverMustard.setText(""+Utility.round((perAcreYieldPio-perAcreYieldOth), 2));
			tvYieldGainOverPerMustard.setText(""+Utility.round((((perAcreYieldPio-perAcreYieldOth)/perAcreYieldOth))*100, 2));
			
			resultLayoutMustard.setVisibility(View.VISIBLE);
			comparisionLayoutMustard.setVisibility(View.VISIBLE);
			if(activity.equals(MyConstants.ACTIVITY_PDA)){
				btnSubmitMustard.setVisibility(View.VISIBLE);
			}

	}
	 
	private class CornBreadthListnPio implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtRowSpacingCornPio.getText().toString().trim().length() > 0 && edtRowHarvestedCornPio.getText().toString().trim().length() > 0){
				edtBreadthCornPio.setText(""+((float)(Float.valueOf(edtRowSpacingCornPio.getText().toString().trim()) * Float.valueOf(edtRowHarvestedCornPio.getText().toString().trim()))/100));
			}else{
				edtBreadthCornPio.setText("");
			}
			
			if(edtHarvestedPlantsCornPio.getText().toString().trim().length() > 0 && edtLengthCornPio.getText().toString().trim().length() > 0 && edtBreadthCornPio.getText().toString().trim().length() > 0){
				float length = Float.valueOf(edtLengthCornPio.getText().toString().trim());
				float breadth = Float.valueOf(edtBreadthCornPio.getText().toString().trim());
				float harvestedPlants = Float.valueOf(edtHarvestedPlantsCornPio.getText().toString().trim());
				edtPopulCornPio.setText(""+((float)((harvestedPlants)/(length*breadth))*MyConstants.POPULATION_CONST));
			}else{
				edtPopulCornPio.setText("");
			}
		}
		
	}
	
	private class CornBreadthListnOth implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtRowSpacingCornOth.getText().toString().trim().length() > 0 && edtRowHarvestedCornOth.getText().toString().trim().length() > 0){
				edtBreadthCornOth.setText(""+((float)(Float.valueOf(edtRowSpacingCornOth.getText().toString().trim()) * Float.valueOf(edtRowHarvestedCornOth.getText().toString().trim()))/100));
			}else{
				edtBreadthCornOth.setText("");
			}
			
			if(edtHarvestedPlantsCornOth.getText().toString().trim().length() > 0 && edtLengthCornOth.getText().toString().trim().length() > 0 && edtBreadthCornOth.getText().toString().trim().length() > 0){
				float length = Float.valueOf(edtLengthCornOth.getText().toString().trim());
				float breadth = Float.valueOf(edtBreadthCornOth.getText().toString().trim());
				float harvestedPlants = Float.valueOf(edtHarvestedPlantsCornOth.getText().toString().trim());
				edtPopulCornOth.setText(""+((float)((harvestedPlants)/(length*breadth))*MyConstants.POPULATION_CONST));
			}else{
				edtPopulCornOth.setText("");
			}
		}
		
	}
	
	private class CornHarvestedPlantsListnPio implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtHarvestedPlantsCornPio.getText().toString().trim().length() > 0 && edtLengthCornPio.getText().toString().trim().length() > 0 && edtBreadthCornPio.getText().toString().trim().length() > 0){
				float length = Float.valueOf(edtLengthCornPio.getText().toString().trim());
				float breadth = Float.valueOf(edtBreadthCornPio.getText().toString().trim());
				float harvestedPlants = Float.valueOf(edtHarvestedPlantsCornPio.getText().toString().trim());
				edtPopulCornPio.setText(""+((float)((harvestedPlants)/(length*breadth))*MyConstants.POPULATION_CONST));
			}else{
				edtPopulCornPio.setText("");
			}
		}
		
	}
	
	private class CornHarvestedPlantsListnOth implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtHarvestedPlantsCornOth.getText().toString().trim().length() > 0 && edtLengthCornOth.getText().toString().trim().length() > 0 && edtBreadthCornOth.getText().toString().trim().length() > 0){
				float length = Float.valueOf(edtLengthCornOth.getText().toString().trim());
				float breadth = Float.valueOf(edtBreadthCornOth.getText().toString().trim());
				float harvestedPlants = Float.valueOf(edtHarvestedPlantsCornOth.getText().toString().trim());
				edtPopulCornOth.setText(""+((float)((harvestedPlants)/(length*breadth))*MyConstants.POPULATION_CONST));
			}else{
				edtPopulCornOth.setText("");
			}
		}
		
	}
	
	private class CornTotalGainListnPio implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtTotCubWeiCornPio.getText().toString().trim().length() > 0 && edtShellingCornPio.getText().toString().trim().length() > 0){
				float totalCob = Float.valueOf(edtTotCubWeiCornPio.getText().toString().trim());
				float sheelingPer = Float.valueOf(edtShellingCornPio.getText().toString().trim());
				edtTotGrainWeiCornPio.setText(""+((float)totalCob*sheelingPer/100));
			}else{
				edtTotGrainWeiCornPio.setText("");
			}
		}
		
	}
	
	private class CornTotalGainListnOth implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtTotCubWeiCornOth.getText().toString().trim().length() > 0 && edtShellingCornOth.getText().toString().trim().length() > 0){
				float totalCob = Float.valueOf(edtTotCubWeiCornOth.getText().toString().trim());
				float sheelingPer = Float.valueOf(edtShellingCornOth.getText().toString().trim());
				edtTotGrainWeiCornOth.setText(""+((float)totalCob*sheelingPer/100));
			}else{
				edtTotGrainWeiCornOth.setText("");
			}
		}
		
	}
	
	private class RicePopulationListnPio implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtHillPerRicePio.getText().toString().trim().length() > 0){
				edtPopulRicePio.setText(""+((float)Float.valueOf(edtHillPerRicePio.getText().toString().trim())*MyConstants.POPULATION_CONST));
			}else{
				edtPopulRicePio.setText("");
			}
		}
		
	}
	
	private class RicePopulationListnOth implements TextWatcher{

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			if(edtHillPerRiceOth.getText().toString().trim().length() > 0){
				edtPopulRiceOth.setText(""+((float)Float.valueOf(edtHillPerRiceOth.getText().toString().trim())*MyConstants.POPULATION_CONST));
			}else{
				edtPopulRiceOth.setText("");
			}
		}
		
	}
	
	private void showAlertToSaveCorn() 
	{
	 
		AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.saveData));
		builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				saveCornData();
			}
		});
	
	builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int which) {
			 
			
		}
	});
	builder.create().show();
	}
	
	private void showAlertToSaveRice() 
	{
	 
		AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.saveData));
		builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				saveRiceData();
			}
		});
	
	builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int which) {
			 
			
		}
	});
	builder.create().show();
	}
	
	private void showAlertToSaveMillet() 
	{
	 
		AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.saveData));
		builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				saveMilletData();
			}
		});
	
	builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int which) {
			 
			
		}
	});
	builder.create().show();
	}
	
	private void showAlertToSaveMustard() 
	{
	 
		AlertDialog.Builder builder=new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.saveData));
		builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				saveMustardData();
			}
		});
	
	builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int which) {
			 
			
		}
	});
	builder.create().show();
	}


	private void setChange(){
		mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
		/*if(Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)){
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
		}else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
			mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
		}*/
   }

	private void populate(List<DTO> dtoList){
		
		switch ((int)cropId) {
		case MyConstants.CROP_CORN_ID:
			populateCorn(dtoList);
			break;
			
		case MyConstants.CROP_RICE_ID:
			populateRice(dtoList);
			break;

		case MyConstants.CROP_MILLET_ID:
			populateMillet(dtoList);
			break;
			
		case MyConstants.CROP_MUSTARD_ID:
			populateMustard(dtoList);
			break;
		}
		
	}

	@Override
	public boolean onBackPressed(int callbackCode) {
		if(activity.equals(MyConstants.ACTIVITY_PDA))
		{
			if(callbackCode != 200){
			if(isDataAvailable()){
				showAlertToExitScreen(callbackCode);
			}else{
				mActivity.onBackPressedCallBack(callbackCode);
			  }
			}else if(callbackCode == 200 && !isSaved){
				if(isDataAvailable()){
					showAlertToExitScreen(callbackCode);
				}else{
					mActivity.onBackPressedCallBack(callbackCode);
				  }
			}else{
				mActivity.onBackPressedCallBack(callbackCode);
			  }
		}else
		{
			mActivity.onBackPressedCallBack(callbackCode);
		}
		return true;
	}
	
	private void showAlertToExitScreen(final int callbackCode){
		AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
		builder.setMessage(getResources().getString(R.string.formExitMsg));
		builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mActivity.onBackPressedCallBack(callbackCode);
			}
		});
		
		builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
			}
		});
		
		builder.create().show();
	}
	
	private boolean isDataAvailable() 
	{
		return false;
	}
	
	private void clearCornFields(){
		
		edtLengthCornPio.setText("");
		edtRowSpacingCornPio.setText("");
		edtRowHarvestedCornPio.setText("");
		edtBreadthCornPio.setText("");
		edtHarvestedPlantsCornPio.setText("");
		edtPopulCornPio.setText("");
		edtTotCubWeiCornPio.setText("");
		edtShellingCornPio.setText("");
		edtTotGrainWeiCornPio.setText("");
		edtMositureCornPio.setText("");
		tvDryGrainWeiCornPio.setText("");
		tvPerAcreYieldCornPio.setText("");

		edtLengthCornOth.setText("");
		edtRowSpacingCornOth.setText("");
		edtRowHarvestedCornOth.setText("");
		edtBreadthCornOth.setText("");
		edtHarvestedPlantsCornOth.setText("");
		edtPopulCornOth.setText("");
		edtTotCubWeiCornOth.setText("");
		edtShellingCornOth.setText("");
		edtTotGrainWeiCornOth.setText("");
		edtMositureCornOth.setText("");
		tvDryGrainWeiCornOth.setText("");
		tvPerAcreYieldCornOth.setText("");
	}
	
	private void clearRiceFields(){
		 edtLengthRicePio.setText("");	
		 edtBreadthRicePio.setText("");
		 edtHillPerRicePio.setText("");
		 edtPopulRicePio.setText("");
		 edtTotGrainWeiRicePio.setText("");
		 edtMositureRicePio.setText("");
		 tvDryGrainWeiRicePio.setText("");
		 tvPerAcreYieldRicePio.setText("");
		 
		 edtLengthRiceOth.setText("");;
		 edtBreadthRiceOth.setText("");
		 edtHillPerRiceOth.setText("");
		 edtPopulRiceOth.setText("");
		 edtTotGrainWeiRiceOth.setText("");
		 edtMositureRiceOth.setText("");
		 tvDryGrainWeiRiceOth.setText("");
		 tvPerAcreYieldRiceOth.setText("");

	}

	private void clearMilletFields(){
		    
		     edtLengthMilletPio.setText("");
			 edtBreadthMilletPio.setText("");
			 edtTotearHeadMilletPio.setText("");
			 edtMositureMilletPio.setText("");
			 tvDryGrainWeiMilletPio.setText("");
			 tvPerAcreYieldMilletPio.setText("");
			 
			 edtLengthMilletOth.setText("");
			 edtBreadthMilletOth.setText("");
			 edtTotearHeadMilletOth.setText("");
			 edtMositureMilletOth.setText("");
			 tvDryGrainWeiMilletOth.setText("");
			 tvPerAcreYieldMilletOth.setText("");

	}
	
	private void clearMustardFields(){
		 edtLengthMustardPio.setText("");
		 edtBreadthMustardPio.setText("");
		 edtTotGrainWeiMustardPio.setText("");
		 edtMositureMustardPio.setText("");
		 tvDryGrainWeiMustardPio.setText("");
		 tvPerAcreYieldMustardPio.setText("");
		 
		 edtLengthMustardOth.setText("");
		 edtBreadthMustardOth.setText("");
		 edtTotGrainWeiMustardOth.setText("");
		 edtMositureMustardOth.setText("");
		 tvDryGrainWeiMustardOth.setText("");
		 tvPerAcreYieldMustardOth.setText("");

		
	}

	private String validateCornFields(){
		
		if(edtLengthCornPio.getText().toString().trim().length() == 0)
				return "Enter Pioneer Length";
		
		if(edtRowSpacingCornPio.getText().toString().trim().length() == 0)
				return "Enter Pioneer Row spacing";
		
		if(edtRowHarvestedCornPio.getText().toString().trim().length() == 0)
			return "Enter Pioneer Rows harvested";
		
		/*if(edtBreadthCornPio.getText().toString().trim().length() == 0)
			   	return "Enter Pioneer Length"; */
		
		if(edtHarvestedPlantsCornPio.getText().toString().trim().length() == 0)
			return "Enter Pioneer Harvested Plants";
		
		/*if(edtPopulCornPio.getText().toString().trim().length() == 0)
				return true;*/
		
		if(edtTotCubWeiCornPio.getText().toString().trim().length() == 0)
				return "Enter Pioneer Total cob weight";
		
		if(edtShellingCornPio.getText().toString().trim().length() == 0)
				return "Enter Pioneer Sheeling %";
		
		/*if(edtTotGrainWeiCornPio.getText().toString().trim().length() == 0)
		    	return "Enter Pioneer Length";*/
		
		if(edtMositureCornPio.getText().toString().trim().length() == 0)
				return "Enter Pioneer Moisture";
		
		/*if(edtDryGrainWeiCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(edtPerAcreYieldCornPio.getText().toString().trim().length() > 0)
		      	return true;*/

		if(edtLengthCornOth.getText().toString().trim().length() == 0)
			return "Enter Others Length";
	
		if(edtRowSpacingCornOth.getText().toString().trim().length() == 0)
				return "Enter Others Row spacing";
		
		if(edtRowHarvestedCornOth.getText().toString().trim().length() == 0)
			return "Enter Others Rows harvested";
		
		/*if(edtBreadthCornOth.getText().toString().trim().length() == 0)
			   	return "Enter Pioneer Length"; */
		
		if(edtHarvestedPlantsCornOth.getText().toString().trim().length() == 0)
			return "Enter Others Harvested Plants";
		
		/*if(edtPopulCornOth.getText().toString().trim().length() == 0)
				return true;*/
		
		if(edtTotCubWeiCornOth.getText().toString().trim().length() == 0)
				return "Enter Others Total cob weight";
		
		if(edtShellingCornOth.getText().toString().trim().length() == 0)
				return "Enter Others Sheeling %";
		
		/*if(edtTotGrainWeiCornOth.getText().toString().trim().length() == 0)
		    	return "Enter Other Length";*/
		
		if(edtMositureCornOth.getText().toString().trim().length() == 0)
				return "Enter Others Moisture";
		
		/*if(edtDryGrainWeiCornOth.getText().toString().trim().length() > 0)
	      	   return true;
		
		if(edtPerAcreYieldCornOth.getText().toString().trim().length() > 0)
	      	   return true;*/
		
		return null;
	}
	
	
	private String validateRiceFields(){
		 if( edtLengthRicePio.getText().toString().trim().length() ==  0)
    	      return "Enter Pioneer Length";
		  
		if( edtBreadthRicePio.getText().toString().trim().length() == 0)
   	      	return "Enter Pioneer Breadth";
		
		if( edtHillPerRicePio.getText().toString().trim().length() == 0)
				return "Enter Pioneer Hills";
		 
	/*if(edtPopulRicePio.getText().toString().trim().length() > 0)
  	     		return true;*/
	   
		if(edtTotGrainWeiRicePio.getText().toString().trim().length() == 0)
	    	     return "Enter Pioneer Total Grain weight";
		 
		if(edtMositureRicePio.getText().toString().trim().length() == 0)
  	         	return "Enter Pioneer Moisture";
		  
		/* if(tvDryGrainWeiRicePio.getText().toString().trim().length() > 0)
   	      	return true;*/
		 
		 /* if(tvPerAcreYieldRicePio.getText().toString().trim().length() > 0)
   	      	return true;*/
			 
		if(edtLengthRiceOth.getText().toString().trim().length() == 0)
				return "Enter Others Length";
		  
		if(edtBreadthRiceOth.getText().toString().trim().length() == 0)
   	      	return "Enter Others Breadth";
		 	
		if(edtHillPerRiceOth.getText().toString().trim().length() == 0)
   	      	return "Enter Others Hills";
		 
		/*if(edtPopulRiceOth.getText().toString().trim().length() > 0)
				return true;*/
		  
		if(edtTotGrainWeiRiceOth.getText().toString().trim().length() == 0)
   	      	return "Enter Others Total Grain weight";
		 	
		if(edtMositureRiceOth.getText().toString().trim().length() == 0)
   	      	return "Enter Others Moisture";
		  
		/*if(tvDryGrainWeiRiceOth.getText().toString().trim().length() > 0)
				return true;*/
		 
	   /*if(tvPerAcreYieldRiceOth.getText().toString().trim().length() > 0)
  	      		return true;*/
           return null;
	}
	
	private String validateMilletFields(){
 
				if(edtLengthMilletPio.getText().toString().trim().length() == 0)
			 			return  "Enter Pioneer Length";
				
			   if(edtBreadthMilletPio.getText().toString().trim().length() == 0)
			      		return "Enter Pioneer Breadth" ;
				
			   if(edtTotearHeadMilletPio.getText().toString().trim().length() == 0)
			      		return "Enter Pioneer Total Earhead weight";
				
			   if(edtMositureMilletPio.getText().toString().trim().length() == 0)
			      		return "Enter Pioneer Moisture";
				
			  /* if(tvDryGrainWeiMilletPio.getText().toString().trim().length() > 0)
			      		return true;
				
			   if(tvPerAcreYieldMilletPio.getText().toString().trim().length() > 0)
			      		return true;*/
			 
				if(edtLengthMilletOth.getText().toString().trim().length() == 0)
			      		return "Enter Others Length";
				
				if(edtBreadthMilletOth.getText().toString().trim().length() == 0)
			      		return "Enter Others Breadth";
				
				if(edtTotearHeadMilletOth.getText().toString().trim().length() == 0)
			      		return "Enter Others Total Earhead weight";
				
				if(edtMositureMilletOth.getText().toString().trim().length() == 0)
			      		return "Enter Others Moisture";
				
				/*if(tvDryGrainWeiMilletOth.getText().toString().trim().length() > 0)
			      		return true;*/
				
				/*if(tvPerAcreYieldMilletOth.getText().toString().trim().length() > 0)
			      		return true;*/
				return null;

	}
	
	private String validateMustardFields(){
		
				if(edtLengthMustardPio.getText().toString().trim().length() == 0)
		  		    return  "Enter Pioneer Length";
				
				if(edtBreadthMustardPio.getText().toString().trim().length() == 0)
		  		    return "Enter Pioneer Breadth";
				
				if(edtTotGrainWeiMustardPio.getText().toString().trim().length() == 0)
			  		return "Enter Pioneer Total Grain weight";
				
				if(edtMositureMustardPio.getText().toString().trim().length() == 0)
			  		return "Enter Pioneer Moisture";
				
				/*if(tvDryGrainWeiMustardPio.getText().toString().trim().length() > 0)
			  		return true;*/
				
			/*	if(tvPerAcreYieldMustardPio.getText().toString().trim().length() > 0)
			  			return true;*/
				 
			 
				if(edtLengthMustardOth.getText().toString().trim().length() ==  0)
					return "Enter Others Length";
				
				if(edtBreadthMustardOth.getText().toString().trim().length() == 0)
			  		return "Enter Others Breadth";
				
				if(edtTotGrainWeiMustardOth.getText().toString().trim().length() == 0)
			  		return "Enter Others Total Grain weight";
				
				if(edtMositureMustardOth.getText().toString().trim().length() == 0)
			  		return "Enter Others Moisture";
				
			/*	if(tvDryGrainWeiMustardOth.getText().toString().trim().length() > 0)
			  		return true;*/
				
				/*if(tVPerAcreYieldMustardOth.getText().toString().trim().length() > 0)
			  		return true;*/

		
		return null;

	}
	
	private boolean isCornDataAvailable(){
		
		if(edtLengthCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(edtRowSpacingCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(edtRowHarvestedCornPio.getText().toString().trim().length() > 0)
		       	return true;
		if(edtBreadthCornPio.getText().toString().trim().length() > 0)
			   	return true; 
		
		if(edtHarvestedPlantsCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(edtPopulCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(edtTotCubWeiCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(edtShellingCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(edtTotGrainWeiCornPio.getText().toString().trim().length() > 0)
		    	return true;
		
		if(edtMositureCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(tvDryGrainWeiCornPio.getText().toString().trim().length() > 0)
				return true;
		
		if(tvPerAcreYieldCornPio.getText().toString().trim().length() > 0)
		      	return true;

		if(edtLengthCornOth.getText().toString().trim().length() > 0)
      	   		return true;
		
		if(edtRowSpacingCornOth.getText().toString().trim().length() > 0)
				return true;
		
		if(edtRowHarvestedCornOth.getText().toString().trim().length() > 0)
				return true;
		
		if(edtBreadthCornOth.getText().toString().trim().length() > 0)
				return true;
		
		if(edtHarvestedPlantsCornOth.getText().toString().trim().length() > 0)
	      	   return true;
		
		if(edtPopulCornOth.getText().toString().trim().length() > 0)
   	       		return true;
		
		if(edtTotCubWeiCornOth.getText().toString().trim().length() > 0)
	      	   return true;
		
		if(edtShellingCornOth.getText().toString().trim().length() > 0)
	      	   return true;
		
		if(edtTotGrainWeiCornOth.getText().toString().trim().length() > 0)
	      	   return true;
		
		if(edtMositureCornOth.getText().toString().trim().length() > 0)
	      	   return true;
		
		if(tvDryGrainWeiCornOth.getText().toString().trim().length() > 0)
	      	   return true;
		
		if(tvPerAcreYieldCornOth.getText().toString().trim().length() > 0)
	      	   return true;

		
		return false;
	}
	
	private boolean isRiceDataAvailable(){
		
		 if( edtLengthRicePio.getText().toString().trim().length() > 0)
     	      return true;
		  
		if( edtBreadthRicePio.getText().toString().trim().length() > 0)
    	      	return true;
		
		if( edtHillPerRicePio.getText().toString().trim().length() > 0)
				return true;
		 
		if(edtPopulRicePio.getText().toString().trim().length() > 0)
   	     		return true;
	   
		if(edtTotGrainWeiRicePio.getText().toString().trim().length() > 0)
	    	     return true;
		 
		if(edtMositureRicePio.getText().toString().trim().length() > 0)
   	         	return true;
		  
		 if(tvDryGrainWeiRicePio.getText().toString().trim().length() > 0)
    	      	return true;
		 
		 if(tvPerAcreYieldRicePio.getText().toString().trim().length() > 0)
    	      	return true;
			 
		if(edtLengthRiceOth.getText().toString().trim().length() > 0)
				return true;
		  
		if(edtBreadthRiceOth.getText().toString().trim().length() > 0)
    	      	return true;
		 	
		if(edtHillPerRiceOth.getText().toString().trim().length() > 0)
    	      	return true;
		 
		if(edtPopulRiceOth.getText().toString().trim().length() > 0)
				return true;
		  
		if(edtTotGrainWeiRiceOth.getText().toString().trim().length() > 0)
    	      	return true;
		 	
		if(edtMositureRiceOth.getText().toString().trim().length() > 0)
    	      	return true;
		  
		if(tvDryGrainWeiRiceOth.getText().toString().trim().length() > 0)
				return true;
		 
		if(tvPerAcreYieldRiceOth.getText().toString().trim().length() > 0)
   	      		return true;

		return false;
	}
	
	private boolean isMilletDataAvailable(){
	   
		if(edtLengthMilletPio.getText().toString().trim().length() > 0)
     			return true;
		
	   if(edtBreadthMilletPio.getText().toString().trim().length() > 0)
	      		return true;
		
	   if(edtTotearHeadMilletPio.getText().toString().trim().length() > 0)
	      		return true;
		
	   if(edtMositureMilletPio.getText().toString().trim().length() > 0)
	      		return true;
		
	   if(tvDryGrainWeiMilletPio.getText().toString().trim().length() > 0)
	      		return true;
		
	   if(tvPerAcreYieldMilletPio.getText().toString().trim().length() > 0)
	      		return true;
	 
		if(edtLengthMilletOth.getText().toString().trim().length() > 0)
	      		return true;
		
		if(edtBreadthMilletOth.getText().toString().trim().length() > 0)
	      		return true;
		
		if(edtTotearHeadMilletOth.getText().toString().trim().length() > 0)
	      		return true;
		
		if(edtMositureMilletOth.getText().toString().trim().length() > 0)
	      		return true;
		
		if(tvDryGrainWeiMilletOth.getText().toString().trim().length() > 0)
	      		return true;
		
		if(tvPerAcreYieldMilletOth.getText().toString().trim().length() > 0)
	      		return true;
		return false;
	}
	
	private boolean isMustardDataAvailable()
	{
		
		if(edtLengthMustardPio.getText().toString().trim().length() > 0)
  		    return true;
		
		if(edtBreadthMustardPio.getText().toString().trim().length() > 0)
  		    return true;
		
		if(edtTotGrainWeiMustardPio.getText().toString().trim().length() > 0)
	  		return true;
		
		if(edtMositureMustardPio.getText().toString().trim().length() > 0)
	  		return true;
		
		if(tvDryGrainWeiMustardPio.getText().toString().trim().length() > 0)
	  		return true;
		
		if(tvPerAcreYieldMustardPio.getText().toString().trim().length() > 0)
	  		return true;
	 
		if(edtLengthMustardOth.getText().toString().trim().length() > 0)
			return true;
		
		if(edtBreadthMustardOth.getText().toString().trim().length() > 0)
	  		return true;
		
		if(edtTotGrainWeiMustardOth.getText().toString().trim().length() > 0)
	  		return true;
		
		if(edtMositureMustardOth.getText().toString().trim().length() > 0)
	  		return true;
		
		if(tvDryGrainWeiMustardOth.getText().toString().trim().length() > 0)
	  		return true;
		
		if(tvPerAcreYieldMustardOth.getText().toString().trim().length() > 0)
	  		return true;
		
		return false;
	}
	private void saveCornData(){
		YieldCalculatorCropsDTO dtoPioneer = new YieldCalculatorCropsDTO();
		dtoPioneer.setYieldFor(MyConstants.PIONEER);
		
		dtoPioneer.setLength(Float.valueOf(edtLengthCornPio.getText().toString().trim()));
		dtoPioneer.setBreadth(Float.valueOf(edtBreadthCornPio.getText().toString().trim()));
		dtoPioneer.setRowSpacing(Float.valueOf(edtRowSpacingCornPio.getText().toString().trim()));
		dtoPioneer.setRowsHarvested(Float.valueOf(edtRowHarvestedCornPio.getText().toString().trim()));
		dtoPioneer.setHarvestedPlants(Float.valueOf(edtHarvestedPlantsCornPio.getText().toString().trim()));
        dtoPioneer.setPopulation(Float.valueOf(edtPopulCornPio.getText().toString().trim()));
        dtoPioneer.setTotalCobWeight(Float.valueOf(edtTotCubWeiCornPio.getText().toString().trim()));
        dtoPioneer.setShellingPercentage(Float.valueOf(edtShellingCornPio.getText().toString().trim()));
        dtoPioneer.setTotalGrainWeight(Float.valueOf(edtTotGrainWeiCornPio.getText().toString().trim()));
        dtoPioneer.setMoisturePercentage(Float.valueOf(edtMositureCornPio.getText().toString().trim()));
//        dtoPioneer.setHillsPerSQM(Float.valueOf(edtHillPerRicePio.getText().toString().trim()));
//        dtoPioneer.setTotalEarheadWeight(Float.valueOf(edtLengthCornPio.getText().toString().trim()));
        dtoPioneer.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiCornPio.getText().toString().trim()));
        dtoPioneer.setPerAcreYield(Float.valueOf(tvPerAcreYieldCornPio.getText().toString().trim()));
        dtoPioneer.setYieldGain(Float.valueOf(tvYieldGainOverCorn.getText().toString().trim()));
        dtoPioneer.setPerYieldGain(Float.valueOf(tvYieldGainOverPerCorn.getText().toString().trim()));
        
        dtoPioneer.setActivityId(activityId);
        dtoPioneer.setCropId(cropId);
        
        
		//others data
		YieldCalculatorCropsDTO dtoOther = new YieldCalculatorCropsDTO();
		dtoOther.setYieldFor(MyConstants.OTHER);
		
		dtoOther.setLength(Float.valueOf(edtLengthCornOth.getText().toString().trim()));
		dtoOther.setBreadth(Float.valueOf(edtBreadthCornOth.getText().toString().trim()));
		dtoOther.setRowSpacing(Float.valueOf(edtRowSpacingCornOth.getText().toString().trim()));
		dtoOther.setRowsHarvested(Float.valueOf(edtRowHarvestedCornOth.getText().toString().trim()));
		dtoOther.setHarvestedPlants(Float.valueOf(edtHarvestedPlantsCornOth.getText().toString().trim()));
        dtoOther.setPopulation(Float.valueOf(edtPopulCornOth.getText().toString().trim()));
        dtoOther.setTotalCobWeight(Float.valueOf(edtTotCubWeiCornOth.getText().toString().trim()));
        dtoOther.setShellingPercentage(Float.valueOf(edtShellingCornOth.getText().toString().trim()));
        dtoOther.setTotalGrainWeight(Float.valueOf(edtTotGrainWeiCornOth.getText().toString().trim()));
        dtoOther.setMoisturePercentage(Float.valueOf(edtMositureCornOth.getText().toString().trim()));
//        dtoOther.setHillsPerSQM(Float.valueOf(edtHillPerRiceOth.getText().toString().trim()));
//        dtoOther.setTotalEarheadWeight(Float.valueOf(edtLengthCornOth.getText().toString().trim()));
        dtoOther.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiCornOth.getText().toString().trim()));
        dtoOther.setPerAcreYield(Float.valueOf(tvPerAcreYieldCornOth.getText().toString().trim()));
        dtoOther.setYieldGain(Float.valueOf(tvYieldGainOverCorn.getText().toString().trim()));
        dtoOther.setPerYieldGain(Float.valueOf(tvYieldGainOverPerCorn.getText().toString().trim()));
        
        dtoOther.setActivityId(activityId);
        dtoOther.setCropId(cropId);
        
        boolean pionerInsert = false;
        boolean otherInsert = false;
        
        List<DTO> yList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
        if(yList != null && yList.size() > 0){
        	pionerInsert = YieldCalculatorCropsDAO.getInstance().update(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().update(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}else{
    		pionerInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}
        
        if(pionerInsert && otherInsert){
        	isSaved = true;
        	Utility.showAlert(mActivity, "", "Successfully saved");
        	//clearCornFields();
			mActivity.popFragments();
        }
        
	}
	
	private void saveRiceData(){
		YieldCalculatorCropsDTO dtoPioneer = new YieldCalculatorCropsDTO();
		dtoPioneer.setYieldFor(MyConstants.PIONEER);
		
		dtoPioneer.setLength(Float.valueOf(edtLengthRicePio.getText().toString().trim()));
		dtoPioneer.setBreadth(Float.valueOf(edtBreadthRicePio.getText().toString().trim()));
        dtoPioneer.setPopulation(Float.valueOf(edtPopulRicePio.getText().toString().trim()));
        dtoPioneer.setTotalGrainWeight(Float.valueOf(edtTotGrainWeiRicePio.getText().toString().trim()));
        dtoPioneer.setMoisturePercentage(Float.valueOf(edtMositureRicePio.getText().toString().trim()));
        dtoPioneer.setHillsPerSQM(Float.valueOf(edtHillPerRicePio.getText().toString().trim()));
        dtoPioneer.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiRicePio.getText().toString().trim()));
        dtoPioneer.setPerAcreYield(Float.valueOf(tvPerAcreYieldRicePio.getText().toString().trim()));
        dtoPioneer.setYieldGain(Float.valueOf(tvYieldGainOverRice.getText().toString().trim()));
        dtoPioneer.setPerYieldGain(Float.valueOf(tvYieldGainOverPerRice.getText().toString().trim()));
        
        dtoPioneer.setActivityId(activityId);
        dtoPioneer.setCropId(cropId);
        
		//others data
        YieldCalculatorCropsDTO dtoOther = new YieldCalculatorCropsDTO();
		dtoOther.setYieldFor(MyConstants.OTHER);
		
		dtoOther.setLength(Float.valueOf(edtLengthRiceOth.getText().toString().trim()));
		dtoOther.setBreadth(Float.valueOf(edtBreadthRiceOth.getText().toString().trim()));
        dtoOther.setPopulation(Float.valueOf(edtPopulRiceOth.getText().toString().trim()));
        dtoOther.setTotalGrainWeight(Float.valueOf(edtTotGrainWeiRiceOth.getText().toString().trim()));
        dtoOther.setMoisturePercentage(Float.valueOf(edtMositureRiceOth.getText().toString().trim()));
        dtoOther.setHillsPerSQM(Float.valueOf(edtHillPerRiceOth.getText().toString().trim()));
        dtoOther.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiRiceOth.getText().toString().trim()));
        dtoOther.setPerAcreYield(Float.valueOf(tvPerAcreYieldRiceOth.getText().toString().trim()));
        dtoOther.setYieldGain(Float.valueOf(tvYieldGainOverRice.getText().toString().trim()));
        dtoOther.setPerYieldGain(Float.valueOf(tvYieldGainOverPerRice.getText().toString().trim()));
        
        dtoOther.setActivityId(activityId);
        dtoOther.setCropId(cropId);
        
        boolean pionerInsert = false;
        boolean otherInsert = false;
        
        List<DTO> yList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
        if(yList != null && yList.size() > 0){
        	pionerInsert = YieldCalculatorCropsDAO.getInstance().update(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().update(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}else{
    		pionerInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}
        
        if(pionerInsert && otherInsert){
        	isSaved = true;
        	Utility.showAlert(mActivity, "", "Successfully saved");
        	//clearRiceFields();
			mActivity.popFragments();
        }
		
	}
	
	private void saveMilletData(){
		YieldCalculatorCropsDTO dtoPioneer = new YieldCalculatorCropsDTO();
		dtoPioneer.setYieldFor(MyConstants.PIONEER);
		
		dtoPioneer.setLength(Float.valueOf(edtLengthMilletPio.getText().toString().trim()));
		dtoPioneer.setBreadth(Float.valueOf(edtBreadthMilletPio.getText().toString().trim()));
        dtoPioneer.setMoisturePercentage(Float.valueOf(edtMositureMilletPio.getText().toString().trim()));
        dtoPioneer.setTotalEarheadWeight(Float.valueOf(edtTotearHeadMilletPio.getText().toString().trim()));
        dtoPioneer.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiMilletPio.getText().toString().trim()));
        dtoPioneer.setPerAcreYield(Float.valueOf(tvPerAcreYieldMilletPio.getText().toString().trim()));
        dtoPioneer.setYieldGain(Float.valueOf(tvYieldGainOverMillet.getText().toString().trim()));
        dtoPioneer.setPerYieldGain(Float.valueOf(tvYieldGainOverPerMillet.getText().toString().trim()));
        
        dtoPioneer.setActivityId(activityId);
        dtoPioneer.setCropId(cropId);
        
		//others data
        YieldCalculatorCropsDTO dtoOther = new YieldCalculatorCropsDTO();
		dtoOther.setYieldFor(MyConstants.OTHER);
		
		dtoOther.setLength(Float.valueOf(edtLengthMilletOth.getText().toString().trim()));
		dtoOther.setBreadth(Float.valueOf(edtBreadthMilletOth.getText().toString().trim()));
		dtoOther.setMoisturePercentage(Float.valueOf(edtMositureMilletOth.getText().toString().trim()));
		dtoOther.setTotalEarheadWeight(Float.valueOf(edtTotearHeadMilletOth.getText().toString().trim()));
		dtoOther.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiMilletOth.getText().toString().trim()));
		dtoOther.setPerAcreYield(Float.valueOf(tvPerAcreYieldMilletOth.getText().toString().trim()));
		dtoOther.setYieldGain(Float.valueOf(tvYieldGainOverMillet.getText().toString().trim()));
        dtoOther.setPerYieldGain(Float.valueOf(tvYieldGainOverPerMillet.getText().toString().trim()));
        
        dtoOther.setActivityId(activityId);
        dtoOther.setCropId(cropId);
        
        boolean pionerInsert = false;
        boolean otherInsert = false;
        
        List<DTO> yList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
        if(yList != null && yList.size() > 0){
        	pionerInsert = YieldCalculatorCropsDAO.getInstance().update(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().update(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}else{
    		pionerInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}
        
        if(pionerInsert && otherInsert){
        	isSaved = true;
        	Utility.showAlert(mActivity, "", "Successfully saved");
        	//clearMilletFields();
			mActivity.popFragments();
        }
	}
	
	private void saveMustardData(){
		YieldCalculatorCropsDTO dtoPioneer = new YieldCalculatorCropsDTO();
		dtoPioneer.setYieldFor(MyConstants.PIONEER);
		
		dtoPioneer.setLength(Float.valueOf(edtLengthMustardPio.getText().toString().trim()));
		dtoPioneer.setBreadth(Float.valueOf(edtBreadthMustardPio.getText().toString().trim()));
        dtoPioneer.setMoisturePercentage(Float.valueOf(edtMositureMustardPio.getText().toString().trim()));
        dtoPioneer.setTotalGrainWeight(Float.valueOf(edtTotGrainWeiMustardPio.getText().toString().trim()));
        dtoPioneer.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiMustardPio.getText().toString().trim()));
        dtoPioneer.setPerAcreYield(Float.valueOf(tvPerAcreYieldMustardPio.getText().toString().trim()));
        dtoPioneer.setYieldGain(Float.valueOf(tvYieldGainOverMustard.getText().toString().trim()));
        dtoPioneer.setPerYieldGain(Float.valueOf(tvYieldGainOverPerMustard.getText().toString().trim()));
        
        dtoPioneer.setActivityId(activityId);
        dtoPioneer.setCropId(cropId);
        
		//others data
		YieldCalculatorCropsDTO dtoOther = new YieldCalculatorCropsDTO();
		dtoOther.setYieldFor(MyConstants.OTHER);
		
		dtoOther.setLength(Float.valueOf(edtLengthMustardOth.getText().toString().trim()));
		dtoOther.setBreadth(Float.valueOf(edtBreadthMustardOth.getText().toString().trim()));
		dtoOther.setMoisturePercentage(Float.valueOf(edtMositureMustardOth.getText().toString().trim()));
		dtoOther.setTotalGrainWeight(Float.valueOf(edtTotGrainWeiMustardOth.getText().toString().trim()));
		dtoOther.setTotalDryGrainWeight(Float.valueOf(tvDryGrainWeiMustardOth.getText().toString().trim()));
		dtoOther.setPerAcreYield(Float.valueOf(tvPerAcreYieldMustardOth.getText().toString().trim()));
		dtoOther.setYieldGain(Float.valueOf(tvYieldGainOverMustard.getText().toString().trim()));
		dtoOther.setPerYieldGain(Float.valueOf(tvYieldGainOverPerMustard.getText().toString().trim()));
        
        dtoOther.setActivityId(activityId);
        dtoOther.setCropId(cropId);
        
        boolean pionerInsert = false;
        boolean otherInsert = false;
        
        List<DTO> yList = YieldCalculatorCropsDAO.getInstance().getRecordInfoById(cropId, activityId, DBHandler.getInstance(mActivity).getDBObject(0));
        if(yList != null && yList.size() > 0){
        	pionerInsert = YieldCalculatorCropsDAO.getInstance().update(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().update(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}else{
    		pionerInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoPioneer, DBHandler.getInstance(mActivity).getDBObject(1));
            otherInsert = YieldCalculatorCropsDAO.getInstance().insert(dtoOther, DBHandler.getInstance(mActivity).getDBObject(1));
    	}
        
        if(pionerInsert && otherInsert){
        	isSaved = true;
        	Utility.showAlert(mActivity, "", "Successfully saved");
        	//clearMustardFields();
			mActivity.popFragments();
        }
		
	}
	
	private void dispScreenByCropId(int cropId){
		cornLayout.setVisibility(View.GONE);
		riceLayout.setVisibility(View.GONE);
		milletLayout.setVisibility(View.GONE);
		mustardLayout.setVisibility(View.GONE);
		
		switch(cropId) {
		
		case MyConstants.CROP_CORN_ID:
			cornLayout.setVisibility(View.VISIBLE);
			break;
			
		case MyConstants.CROP_RICE_ID:
			riceLayout.setVisibility(View.VISIBLE);
			break;
			
		case MyConstants.CROP_MILLET_ID:
			milletLayout.setVisibility(View.VISIBLE);
			break;
			
		case MyConstants.CROP_MUSTARD_ID:
			mustardLayout.setVisibility(View.VISIBLE);
			break;
			
		}
	}
	
	private void populateCorn(List<DTO> dtoList){
		for(DTO mainDto : dtoList){
			YieldCalculatorCropsDTO dto = (YieldCalculatorCropsDTO) mainDto;
			if(dto.getYieldFor().equals(MyConstants.PIONEER)){
				edtLengthCornPio.setText(""+dto.getLength());
				edtRowSpacingCornPio.setText(""+dto.getRowSpacing());
				edtRowHarvestedCornPio.setText(""+dto.getRowsHarvested());
				edtBreadthCornPio.setText(""+dto.getBreadth());
				edtHarvestedPlantsCornPio.setText(""+dto.getHarvestedPlants());
				edtPopulCornPio.setText(""+dto.getPopulation());
				edtTotCubWeiCornPio.setText(""+dto.getTotalCobWeight());
				edtShellingCornPio.setText(""+dto.getShellingPercentage());
				edtTotGrainWeiCornPio.setText(""+dto.getTotalGrainWeight());
				edtMositureCornPio.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiCornPio.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldCornPio.setText(""+dto.getPerAcreYield());
				tvYieldGainOverCorn.setText(""+dto.getYieldGain());
				tvYieldGainOverPerCorn.setText(""+dto.getPerYieldGain());
			}else if(dto.getYieldFor().equals(MyConstants.OTHER)){
				edtLengthCornOth.setText(""+dto.getLength());
				edtRowSpacingCornOth.setText(""+dto.getRowSpacing());
				edtRowHarvestedCornOth.setText(""+dto.getRowsHarvested());
				edtBreadthCornOth.setText(""+dto.getBreadth());
				edtHarvestedPlantsCornOth.setText(""+dto.getHarvestedPlants());
				edtPopulCornOth.setText(""+dto.getPopulation());
				edtTotCubWeiCornOth.setText(""+dto.getTotalCobWeight());
				edtShellingCornOth.setText(""+dto.getShellingPercentage());
				edtTotGrainWeiCornOth.setText(""+dto.getTotalGrainWeight());
				edtMositureCornOth.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiCornOth.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldCornOth.setText(""+dto.getPerAcreYield());
				tvYieldGainOverCorn.setText(""+dto.getYieldGain());
				tvYieldGainOverPerCorn.setText(""+dto.getPerYieldGain());
			}
		}
		
		resultLayoutCorn.setVisibility(View.VISIBLE);
		comparisionLayoutCorn.setVisibility(View.VISIBLE);
		btnSubmitCorn.setVisibility(View.VISIBLE);
	}
	
	private void populateRice(List<DTO> dtoList){
		for(DTO mainDto : dtoList){
			YieldCalculatorCropsDTO dto = (YieldCalculatorCropsDTO) mainDto;
			if(dto.getYieldFor().equals(MyConstants.PIONEER)){
				edtLengthRicePio.setText(""+dto.getLength());	
				edtBreadthRicePio.setText(""+dto.getBreadth());
				edtHillPerRicePio.setText(""+dto.getHillsPerSQM());
				edtPopulRicePio.setText(""+dto.getPopulation());
				edtTotGrainWeiRicePio.setText(""+dto.getTotalGrainWeight());
				edtMositureRicePio.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiRicePio.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldRicePio.setText(""+dto.getPerAcreYield());
				tvYieldGainOverRice.setText(""+dto.getYieldGain());
				tvYieldGainOverPerRice.setText(""+dto.getPerYieldGain());
			}else if(dto.getYieldFor().equals(MyConstants.OTHER)){
			
				edtLengthRiceOth.setText(""+dto.getLength());	
				edtBreadthRiceOth.setText(""+dto.getBreadth());
				edtHillPerRiceOth.setText(""+dto.getHillsPerSQM());
				edtPopulRiceOth.setText(""+dto.getPopulation());
				edtTotGrainWeiRiceOth.setText(""+dto.getTotalGrainWeight());
				edtMositureRiceOth.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiRiceOth.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldRiceOth.setText(""+dto.getPerAcreYield());
				tvYieldGainOverRice.setText(""+dto.getYieldGain());
				tvYieldGainOverPerRice.setText(""+dto.getPerYieldGain());
			}
		}
		resultLayoutRice.setVisibility(View.VISIBLE);
		comparisionLayoutRice.setVisibility(View.VISIBLE);
		btnSubmitRice.setVisibility(View.VISIBLE);
	}

	private void populateMillet(List<DTO> dtoList){
		for(DTO mainDto : dtoList){
			YieldCalculatorCropsDTO dto = (YieldCalculatorCropsDTO) mainDto;
			if(dto.getYieldFor().equals(MyConstants.PIONEER)){
				edtLengthMilletPio.setText(""+dto.getLength());
				edtBreadthMilletPio.setText(""+dto.getBreadth());
				edtTotearHeadMilletPio.setText(""+dto.getTotalEarheadWeight());
				edtMositureMilletPio.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiMilletPio.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldMilletPio.setText(""+dto.getPerAcreYield());
				tvYieldGainOverMillet.setText(""+dto.getYieldGain());
				tvYieldGainOverPerMillet.setText(""+dto.getPerYieldGain());
			}else if(dto.getYieldFor().equals(MyConstants.OTHER)){
				edtLengthMilletOth.setText(""+dto.getLength());
				edtBreadthMilletOth.setText(""+dto.getBreadth());
				edtTotearHeadMilletOth.setText(""+dto.getTotalEarheadWeight());
				edtMositureMilletOth.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiMilletOth.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldMilletOth.setText(""+dto.getPerAcreYield());
				tvYieldGainOverMillet.setText(""+dto.getYieldGain());
				tvYieldGainOverPerMillet.setText(""+dto.getPerYieldGain());
			}
		}
		 
		resultLayoutMillet.setVisibility(View.VISIBLE);
		comparisionLayoutMillet.setVisibility(View.VISIBLE);
		btnSubmitMillet.setVisibility(View.VISIBLE);
	}

	private void populateMustard(List<DTO> dtoList){
		for(DTO mainDto : dtoList){
			YieldCalculatorCropsDTO dto = (YieldCalculatorCropsDTO) mainDto;
			if(dto.getYieldFor().equals(MyConstants.PIONEER)){
				edtLengthMustardPio.setText(""+dto.getLength());
				edtBreadthMustardPio.setText(""+dto.getBreadth());
				edtTotGrainWeiMustardPio.setText(""+dto.getTotalGrainWeight());
				edtMositureMustardPio.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiMustardPio.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldMustardPio.setText(""+dto.getPerAcreYield());
				tvYieldGainOverMustard.setText(""+dto.getYieldGain());
				tvYieldGainOverPerMustard.setText(""+dto.getPerYieldGain());
			}else if(dto.getYieldFor().equals(MyConstants.OTHER)){
				edtLengthMustardOth.setText(""+dto.getLength());
				edtBreadthMustardOth.setText(""+dto.getBreadth());
				edtTotGrainWeiMustardOth.setText(""+dto.getTotalGrainWeight());
				edtMositureMustardOth.setText(""+dto.getMoisturePercentage());
				tvDryGrainWeiMustardOth.setText(""+dto.getTotalDryGrainWeight());
				tvPerAcreYieldMustardOth.setText(""+dto.getPerAcreYield());
				tvYieldGainOverMustard.setText(""+dto.getYieldGain());
				tvYieldGainOverPerMustard.setText(""+dto.getPerYieldGain());
			}
		}
		resultLayoutMustard.setVisibility(View.VISIBLE);
		comparisionLayoutMustard.setVisibility(View.VISIBLE);
		btnSubmitMustard.setVisibility(View.VISIBLE);
	}
	
	private class InfoClick implements OnClickListener{

		@Override
		public void onClick(View v) {
			final Dialog dialog = new Dialog(mActivity);
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.popup_shelling);
			
			ImageView imageView = (ImageView) dialog.findViewById(R.id.popup_close);
			
			imageView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					dialog.dismiss();
				}
			});
			
			dialog.show();
			
			
			
			/*LayoutInflater layoutInflater = (LayoutInflater) mActivity.getSystemService(mActivity.LAYOUT_INFLATER_SERVICE);
			View popupView = layoutInflater.inflate(R.layout.temp, null);
			
	        final PopupWindow popupWindow = new PopupWindow(popupView,
	                LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT, true);

	        popupWindow.setTouchable(true);
	        popupWindow.setFocusable(true);

	        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);*/
			
		}
		
	}
}
