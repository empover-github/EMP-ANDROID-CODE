package com.activitytrack.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import androidx.core.widget.CompoundButtonCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.activitytrack.daos.MdrFarmerDAO;
import com.activitytrack.daos.NewMdrSurveyDAO;
import com.activitytrack.daos.VillageProfileDAO;
import com.activitytrack.database.DBHandler;
import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.NewMdrSurveyDTO;
import com.activitytrack.dtos.VillageProfileDTO;
import com.activitytrack.masterdaos.CropMasterDAO;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdaos.SegmentMasterDAO;
import com.activitytrack.masterdtos.CropMasterDTO;
import com.activitytrack.masterdtos.SegmentMasterDTO;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.DialogManager;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;

public class MDRProfileFragment extends BaseFragment {
    private View view;
    private TextView villagesProfilesUploadedTv;
    private EditText edtVillageName, edtPinCode, edtBlockName, edtRetailMobNo;
    private TextView tvVillageName, tvPinCode, tvBlockName, tvNameOfCrop, tvSegment, tvAddFarmersCount, tvAddSurveyCount, tvIsPdaVillage, tvRetailerMobNo;
    private LinearLayout mainLayout;
    private Spinner spnCrop, spnSegment;
    private Button btnSubmit, btnSave;
    private RelativeLayout notificationRL;
    private EditText notificationEt;
    private TextView notifictaionCountTv;

    private List<String> cropNameList = new ArrayList<>();
    private List<DTO> cropDTOList = new ArrayList<>();
    private List<String> segmentNamesList = new ArrayList<>();
    private List<DTO> segmentIdDTOList = new ArrayList<>();
    private ArrayAdapter<String> segmentIdAdapter;
    private long cropid;
    private long segmentId;
    private LinearLayout addFarmersCountLL, addFarmersLL, addSurveyLL, addSurveyCountLL;
    private long activityId;
    private static final int SURVEY_LIST_REQUEST_CODE = 101;
    private static final int PENDING_LIST_REQUEST_CODE = 102;
    private static final int UPLOADED_LIST_REQUEST_CODE = 103;
    //    public static final String BTN_PRESSED_IN_VP_LIST_ACTIVITY = "pressedBtnText";
    public static final String ACTIVITY_ID_VP_LIST_ACTIVITY = "activityIdForEdit";
    // newly added
    private RadioGroup radioGroisPdaVillage;
    private RadioButton radioButisPdaVillageYes, radioButisPdaVillageNo;

    private VillageProfileDTO clearBtnDto;
    private int noOfSurveysDone;

    private void initializeViews() {
        mainLayout = (LinearLayout) view.findViewById(R.id.mdr_bg_layout);

        villagesProfilesUploadedTv = (TextView) view.findViewById(R.id.mdr_villageProfilesTv);
        edtVillageName = (EditText) view.findViewById(R.id.mdr_villageName);
        edtPinCode = (EditText) view.findViewById(R.id.mdr_pinCode);
        edtBlockName = (EditText) view.findViewById(R.id.mdr_blockName);
        spnCrop = (Spinner) view.findViewById(R.id.mdr_nameOfCrop);
        spnSegment = (Spinner) view.findViewById(R.id.mdr_segment);
        // newly added
        edtRetailMobNo = (EditText) view.findViewById(R.id.mdr_retailerMobNum);


        tvVillageName = (TextView) view.findViewById(R.id.mdr_villageName_l);
        tvPinCode = (TextView) view.findViewById(R.id.mdr_pincode_l);
        tvBlockName = (TextView) view.findViewById(R.id.mdr_blockname_l);
        tvNameOfCrop = (TextView) view.findViewById(R.id.mdr_nameOfCrop_l);
        tvSegment = (TextView) view.findViewById(R.id.mdr_segment_l);
        // newly added
        tvIsPdaVillage = (TextView) view.findViewById(R.id.mdr_isPdaVillage_l);
        tvRetailerMobNo = (TextView) view.findViewById(R.id.mdr_retailerMobNum_l);

        btnSubmit = (Button) view.findViewById(R.id.mdr_submit);
        btnSave = (Button) view.findViewById(R.id.mdr_save);

        addFarmersLL = (LinearLayout) view.findViewById(R.id.mdr_addFarmers);
        tvAddFarmersCount = (TextView) view.findViewById(R.id.mdr_addFarmersCir);
        addFarmersCountLL = (LinearLayout) view.findViewById(R.id.mdr_circle_addFarmers_l);

        addSurveyLL = (LinearLayout) view.findViewById(R.id.mdr_addSurvey);
        tvAddSurveyCount = (TextView) view.findViewById(R.id.mdr_surveyCir);
        addSurveyCountLL = (LinearLayout) view.findViewById(R.id.mdr_circle_survey_l);

        notificationRL = (RelativeLayout) view.findViewById(R.id.mdr_notificationRL);
        notificationEt = (EditText) view.findViewById(R.id.mdr_pending_profileEt);
        notifictaionCountTv = (TextView) view.findViewById(R.id.mdr_pending_profile_countTxt);

        String headerTxt = getString(R.string.village_profiles_uploaded).replace("$1", Utility.getNoOfProfilesUploadedByMdr(mActivity));
        villagesProfilesUploadedTv.setText(headerTxt);

        // newly added
        radioGroisPdaVillage = (RadioGroup) view.findViewById(R.id.mdr_isPdaVillage_radio);
        radioButisPdaVillageYes = (RadioButton) view.findViewById(R.id.mdr_isPdaVillage_radio_yes);
        radioButisPdaVillageNo = (RadioButton) view.findViewById(R.id.mdr_isPdaVillage_radio_no);

        showNotificationLayout();
        setListeners();
        edtVillageName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                changeBtnTxtFrmClr2Save(s.toString(), "", "", "", "", "", "");
            }
        });

        edtRetailMobNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                changeBtnTxtFrmClr2Save("", s.toString(), "", "", "", "", "");
            }
        });

        edtPinCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                changeBtnTxtFrmClr2Save("", "", s.toString(), "", "", "", "");
            }
        });

        edtBlockName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                changeBtnTxtFrmClr2Save("", "", "", s.toString(), "", "", "");
            }
        });

    }

    private void changeBtnTxtFrmClr2Save(String villageName, String noOdRetailers, String pincode, String blockName, String crop, String segment, String radioBtn) {
        if (clearBtnDto != null) {
            if (villageName.equalsIgnoreCase(clearBtnDto.getVillageName()))
                btnSave.setEnabled(false);
            else
                btnSave.setEnabled(true);

            if (radioBtn.equalsIgnoreCase(clearBtnDto.getIsPDAVillage()))
                btnSave.setEnabled(false);
            else
                btnSave.setEnabled(true);

            if (noOdRetailers.equalsIgnoreCase(clearBtnDto.getRetailerMobileNumber()))
                btnSave.setEnabled(false);
            else
                btnSave.setEnabled(true);

            if (pincode.equalsIgnoreCase(clearBtnDto.getPinCode()))
                btnSave.setEnabled(false);
            else
                btnSave.setEnabled(true);

            if (blockName.equalsIgnoreCase(clearBtnDto.getBlockName()))
                btnSave.setEnabled(false);
            else
                btnSave.setEnabled(true);

            if (crop.equalsIgnoreCase(clearBtnDto.getCropName()))
                btnSave.setEnabled(false);
            else
                btnSave.setEnabled(true);

            if (segment.equalsIgnoreCase(clearBtnDto.getSegmentName()))
                btnSave.setEnabled(false);
            else
                btnSave.setEnabled(true);

        }
    }

    private void setListeners() {

        villagesProfilesUploadedTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utility.isValidStr(Utility.getNoOfProfilesUploadedByMdr(mActivity))) {
                    Intent gotoUploadedList = new Intent(getActivity(), UploadedVillagesListActivity.class);
                    startActivityForResult(gotoUploadedList, UPLOADED_LIST_REQUEST_CODE);
//                    startActivity(gotoUploadedList);
                }
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String validation = validateFields();
                if (validation.trim().length() == 0) {
                    if (checkForLocation) {
                        if (location != null && location.length() > 0) {
                            showAlertToSubmit(btnSubmit.getText().toString().trim());
                        } else {
                            getCurrentLocation(mActivity);
                        }
                    } else {
                        showAlertToSubmit(btnSubmit.getText().toString().trim());
                    }
                } else {
                    Utility.showAlert(mActivity, "", validation);
                }

            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String btnText = btnSave.getText().toString();
                if (btnText.equals(getString(R.string.save))) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        if (checkForLocation) {
                            if (location != null && location.length() > 0) {
                                showAlertToSave(btnSave.getText().toString().trim());
                            } else {
                                getCurrentLocation(mActivity);
                            }
                        } else {
                            showAlertToSave(btnSave.getText().toString().trim());
                        }
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else if (btnText.equals(getString(R.string.clear))) {
                    clearFields();
                }
            }
        });

        addFarmersLL.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        VillageProfileDTO mdrProDto = getDataObject();
                        mdrProDto.setIsSync(0);
                        activityId = VillageProfileDAO.getInstance().insertActivity(mdrProDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        /*if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                        }*/
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        VillageProfileDTO mdrProDto = getDataObject();
//                        mdrProDto.setIsSync(0);
                        mdrProDto.setId(activityId);
                        VillageProfileDAO.getInstance().update(mdrProDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }

                /*if (activityId > 0) {
                    BaseFragment fragment = new MdrFarmerFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("activity", MyConstants.ACTIVITY_MDR);
                    bundle.putLong("activityId", activityId);
                    fragment.setArguments(bundle);
                    mActivity.pushFragments(MyConstants.TAB_PROFILE, fragment, false, true);
                }*/

            }
        });

        addSurveyLL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (activityId == 0) {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        VillageProfileDTO mdrProDto = getDataObject();
                        mdrProDto.setIsSync(0);
                        activityId = VillageProfileDAO.getInstance().insertActivity(mdrProDto, DBHandler.getInstance(mActivity).getDBObject(1));
                        /*if (activityId > 0) {
                            Utility.setActivityId(activityId, mActivity);
                        }*/
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                    }
                } else {
                    String validation = validateFields();
                    if (validation.trim().length() == 0) {
                        VillageProfileDTO mdrProDto = getDataObject();
//                        mdrProDto.setIsSync(0);
                        mdrProDto.setId(activityId);
                        VillageProfileDAO.getInstance().update(mdrProDto, DBHandler.getInstance(mActivity).getDBObject(1));
                    } else {
                        Utility.showAlert(mActivity, "", validation);
                        return;
                    }
                }

                if (activityId > 0 && cropid > 0) {
                    if (Utility.isValidStr(tvAddSurveyCount.getText().toString().trim()))
                        noOfSurveysDone = Integer.parseInt(tvAddSurveyCount.getText().toString().trim());

                    Intent pravaktaFarmer = new Intent(getActivity(), MdrSurveyListActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putLong(MdrSurveyListActivity.EXTRA_ACTIVITY_ID, activityId);
                    bundle.putLong(MdrSurveyListActivity.EXTRA_CROP_ID, cropid);
                    bundle.putString(MdrSurveyListActivity.EXTRA_CROP_NAME, spnCrop.getSelectedItem().toString());
                    bundle.putString(MdrSurveyListActivity.EXTRA_SEGMENT_NAME, spnSegment.getSelectedItem().toString());
                   /* bundle.putString(MdrSurveyListActivity.EXTRA_VILLAGE_NAME, edtVillageName.getText().toString());
                    bundle.putString(MdrSurveyListActivity.EXTRA_PINCODE, edtPinCode.getText().toString());
                    bundle.putString(MdrSurveyListActivity.EXTRA_BLOCK_NAME, edtBlockName.getText().toString());
                    bundle.putString(MdrSurveyListActivity.EXTRA_ISPDAVILLAGE,radioButtonText(radioGroisPdaVillage) );*/
                    pravaktaFarmer.putExtras(bundle);
                    startActivityForResult(pravaktaFarmer, SURVEY_LIST_REQUEST_CODE);
                }

            }
        });

        ArrayAdapter<String> cropAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, cropNameList);
        spnCrop.setAdapter(cropAdapter);
        spnCrop.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position > 0) {
                    CropMasterDTO cropMasterDTO = (CropMasterDTO) cropDTOList.get(position - 1);
                    cropid = cropMasterDTO.getId();
                    changeBtnTxtFrmClr2Save("", "", "", "", cropMasterDTO.getName(), "", "");
                    segmentSpinnerPopulation(cropid);
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }

                } else if (parent.getChildAt(0) != null) {
                    segmentNamesList.clear();

                    if (segmentIdAdapter != null)
                        segmentIdAdapter.notifyDataSetChanged();

                    cropid = 0;
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        notificationEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btnSave.getText().toString().trim().equals(getString(R.string.save))) {
                    Intent gotoPendingList = new Intent(getActivity(), VillageProfilePendingActivity.class);
                    startActivityForResult(gotoPendingList, PENDING_LIST_REQUEST_CODE);
                } else if (isDataAvailable()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                    builder.setTitle(getString(R.string.alert));
                    builder.setMessage(getResources().getString(R.string.cant_goto_pendingList));
                    builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    builder.create().show();
                } else if (btnSave.getText().toString().trim().equals(getString(R.string.save)) && !btnSave.isEnabled()) {
                    Intent gotoPendingList = new Intent(getActivity(), VillageProfilePendingActivity.class);
                    startActivityForResult(gotoPendingList, PENDING_LIST_REQUEST_CODE);
                }


                /*if (btnSave.isEnabled() && isDataAvailable()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                    builder.setTitle(getString(R.string.alert));
                    builder.setMessage(getResources().getString(R.string.cant_goto_pendingList));
                    builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    builder.create().show();

                } else {
                    Intent gotoPendingList = new Intent(getActivity(), VillageProfilePendingActivity.class);
                    startActivityForResult(gotoPendingList, PENDING_LIST_REQUEST_CODE);
                }*/
            }
        });

        radioGroisPdaVillage.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (group.getCheckedRadioButtonId() == R.id.mdr_isPdaVillage_radio_yes) {
                    changeBtnTxtFrmClr2Save("", "", "", "", "", "", "yes");
                } else {
                    changeBtnTxtFrmClr2Save("", "", "", "", "", "", "no");

                }
            }
        });
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cropDTOList = CropMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if (cropDTOList != null && cropDTOList.size() > 0) {
            cropNameList.clear();
            for (DTO dto : cropDTOList) {
                if (cropNameList.size() == 0) {
                    cropNameList.add("Select");
                }
                CropMasterDTO cropMasterDTO = (CropMasterDTO) dto;
                cropNameList.add(cropMasterDTO.getName());

            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.mdr_profile_fragment, container, false);

        initializeViews();
        setChange();

//        activityId = Utility.getActivityId(mActivity);
        if (activityId == 0) {
            btnSubmit.setEnabled(false);
            btnSave.setEnabled(false);
            btnSave.setBackgroundResource(R.drawable.button_bg);
//            btnSave.setBackgroundColor(getResources().getColor(R.color.disable));
        } else {
            List<DTO> mdrDTOList = VillageProfileDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));

            if (mdrDTOList != null && mdrDTOList.size() > 0) {
                List<DTO> farmersList = MdrFarmerDAO.getInstance().getRecordInfoById(activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                List<DTO> surveyList = NewMdrSurveyDAO.getInstance().getRecordInfoById(activityId, DBHandler.getInstance(mActivity).getDBObject(0));

                if (farmersList != null && farmersList.size() > 0) {
                    //set list size to textView
                    tvAddFarmersCount.setText(("" + farmersList.size()));
                    addFarmersCountLL.setVisibility(View.VISIBLE);
                } else {
                    //set empty to textView
                    tvAddFarmersCount.setText("");
                    addFarmersCountLL.setVisibility(View.INVISIBLE);
                }


                if (surveyList != null && surveyList.size() > 0) {
                    //set list size to textView
                    tvAddSurveyCount.setText(("" + surveyList.size()));
                    addSurveyCountLL.setVisibility(View.VISIBLE);
                } else {
                    //set empty to textView
                    tvAddSurveyCount.setText("");
                    addSurveyCountLL.setVisibility(View.INVISIBLE);
                }

                showSaveSubmitButton();

            } /*else {
                btnSubmit.setEnabled(false);
                btnSave.setEnabled(false);
                activityId = 0;
                Utility.setActivityId(0, mActivity);
            }*/
        }
        return view;
    }

    private String validateFields() {
        if (edtVillageName.getText().toString().trim().length() == 0) {
            return getResources().getString(R.string.vagenamentempty);
        }
        // newly added
        if (radioGroisPdaVillage.getCheckedRadioButtonId() == -1) {
            return "Please select Is PDA Village";
        }
        if (edtRetailMobNo.getText().toString().trim().length() == 0) {
            return "No. of Retailers should not be empty";
        }

        /*if (Integer.parseInt(edtRetailMobNo.getText().toString()) == 0){
            return "Please enter valid No of retailers";
        }*/
        /*if (edtRetailMobNo.getText().toString().trim().length() < 10) {
            return "Please enter valid Retailer Mobile No.";
        }*/
        if (edtPinCode.getText().toString().trim().length() == 0) {
            return getResources().getString(R.string.pincodeempty);
        }
        if (edtPinCode.getText().toString().trim().length() < 6) {
            return getResources().getString(R.string.zeropincode);
        }

        if (edtBlockName.getText().toString().trim().length() == 0) {
            return getResources().getString(R.string.blocknameempty);
        }
        if (spnCrop.getSelectedItemPosition() <= 0) {
            return getResources().getString(R.string.cropname_error);
        }

        if (spnSegment.getSelectedItemPosition() <= 0) {
            return getResources().getString(R.string.segmentname_error);
        }

        if (Utility.isValidStr(edtPinCode.getText().toString().trim())) {
            int sum = validateMobileOrPin(edtPinCode.getText().toString().trim());
            if (sum == 0)
                return getResources().getString(R.string.valid_pincode_error);
        }

        return "";
    }

    private int validateMobileOrPin(String trim) {
        int sum = 0;
        char[] arrayElements = trim.toCharArray();
        for (int i = 0; i < arrayElements.length; i++) {
            String v = String.valueOf(arrayElements[i]);
            sum += Integer.parseInt(v);
        }
        return sum;
    }

    private void showAlertToSave(final String pressedBtnTxt) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData_villageProfile));
        builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                saveData(pressedBtnTxt);
            }
        });

        builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void showAlertToSubmit(final String pressedBtnTxt) {
        List<NewMdrSurveyDTO> surveyList = NewMdrSurveyDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(mActivity).getDBObject(0));
        if (surveyList != null && surveyList.size() >= 5) {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setMessage(getResources().getString(R.string.submitData));
            builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    saveData(pressedBtnTxt);
                }
            });

            builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.create().show();
        } else {
            DialogManager.showSingleBtnPopup(mActivity, null, "Alert!", getString(R.string.add_record_upto_five), getString(R.string.ok)); // here what is the aler msg do i need to show?
        }
    }

    private void saveData(String btnPressed) {
        if (btnPressed.equals(getString(R.string.save))) {
            VillageProfileDTO dto = getDataObjectForSaving(btnPressed);
            long regionId = MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
            if (regionId != 0)
                dto.setRegionId(regionId);

            boolean updateAck = VillageProfileDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
            if (updateAck) {
                showNotificationLayout();
                showDataSavedConfirmedMsg();
                btnSave.setEnabled(false);
                clearBtnDto = dto;

            }
        } else {
            VillageProfileDTO dto = getDataObjectForSaving(btnPressed);
            long regionId = MdrMasterDAO.getInstance().getRegionId(DBHandler.getInstance(mActivity).getDBObject(0));
            if (regionId != 0)
                dto.setRegionId(regionId);

            boolean updateAck = VillageProfileDAO.getInstance().update(dto, DBHandler.getInstance(mActivity).getDBObject(1));
            if (updateAck) {
//                Utility.showAlert(mActivity, null, MyConstants.SUC_MSG);
                clearFields();
                showSubmitedConfirmedMsg();
            }
        }
    }

    private void showDataSavedConfirmedMsg() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.saveData_vp_confirmedMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void showSubmitedConfirmedMsg() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(getResources().getString(R.string.submitData_confirmedMsg));
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private void clearFields() {
//        Utility.setActivityId(0, mActivity);
        activityId = 0;
        edtVillageName.setText("");
        // newly added
        radioGroisPdaVillage.clearCheck();
        edtRetailMobNo.setText("");
        edtPinCode.setText("");
        edtBlockName.setText("");
        spnCrop.setSelection(0);
        spnSegment.setSelection(0);

        addFarmersCountLL.setVisibility(View.INVISIBLE);
        addSurveyCountLL.setVisibility(View.INVISIBLE);
        btnSubmit.setEnabled(false);
        btnSave.setEnabled(false);
        btnSave.setText(getString(R.string.save));
//        btnSave.setBackgroundColor(getResources().getColor(R.color.disable));
        btnSave.setBackgroundResource(R.drawable.button_bg);
        showNotificationLayout();

        // only for testing purpose, can be deleted
        List<VillageProfileDTO> uploadList = VillageProfileDAO.getInstance().getRecordsForUpload(mActivity, DBHandler.getInstance(mActivity).getDBObject(0));
        ATBuildLog.e("VillageProfileFrag:RecordsToUpload", "" + uploadList.size());

        clearBtnDto = null;
        noOfSurveysDone = 0;
    }

    private void setChange() {
        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_DARK)) {
            tvVillageName.setTextColor(Color.WHITE);
            tvPinCode.setTextColor(Color.WHITE);
            tvBlockName.setTextColor(Color.WHITE);
            tvNameOfCrop.setTextColor(Color.WHITE);
            tvSegment.setTextColor(Color.WHITE);
            // newly added
            tvIsPdaVillage.setTextColor(Color.WHITE);
            tvRetailerMobNo.setTextColor(Color.WHITE);

            spnCrop.setBackgroundResource(R.drawable.spinner_bg_img);
            spnSegment.setBackgroundResource(R.drawable.spinner_bg_img);

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));

            notificationRL.setBackgroundColor(getResources().getColor(R.color.theme_dark_layout_bg));
            notifictaionCountTv.setBackgroundResource(R.drawable.pending_profiles_notification_light);
            notifictaionCountTv.setTextColor(Color.BLACK);
            // newly added
            radioButisPdaVillageYes.setTextColor(Color.WHITE);
            radioButisPdaVillageNo.setTextColor(Color.WHITE);
            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(radioButisPdaVillageYes, ColorStateList.valueOf(Color.WHITE));
                CompoundButtonCompat.setButtonTintList(radioButisPdaVillageNo, ColorStateList.valueOf(Color.WHITE));
            } else {
                radioButisPdaVillageYes.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
                radioButisPdaVillageNo.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
            }

        } else if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
            tvVillageName.setTextColor(Color.BLACK);
            tvPinCode.setTextColor(Color.BLACK);
            tvBlockName.setTextColor(Color.BLACK);
            tvNameOfCrop.setTextColor(Color.BLACK);
            tvSegment.setTextColor(Color.BLACK);
            // newly added
            tvIsPdaVillage.setTextColor(Color.BLACK);
            tvRetailerMobNo.setTextColor(Color.BLACK);
            spnCrop.setBackgroundResource(R.drawable.spinner_bg_img_light);
            spnSegment.setBackgroundResource(R.drawable.spinner_bg_img_light);

            mainLayout.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));

            notificationRL.setBackgroundColor(getResources().getColor(R.color.theme_lite_layout_bg));
            notifictaionCountTv.setBackgroundResource(R.drawable.pending_profiles_notification_dark);
            notifictaionCountTv.setTextColor(Color.WHITE);

            // newly added
            radioButisPdaVillageYes.setTextColor(Color.BLACK);
            radioButisPdaVillageNo.setTextColor(Color.BLACK);
            if (Build.VERSION.SDK_INT < 21) {
                CompoundButtonCompat.setButtonTintList(radioButisPdaVillageYes, ColorStateList.valueOf(Color.BLACK));
                CompoundButtonCompat.setButtonTintList(radioButisPdaVillageNo, ColorStateList.valueOf(Color.BLACK));
            } else {
                radioButisPdaVillageYes.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
                radioButisPdaVillageNo.setButtonTintList(ColorStateList.valueOf(Color.BLACK));
            }
        }
    }

    @Override
    public boolean onBackPressed(int callbackCode) {

        if (isDataAvailable() && activityId <= 0){
            showAlertToExitScreen(callbackCode);
        } else if (isDataAvailable() && activityId > 0 && btnSave.isEnabled()){
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }
        /*if (isDataAvailable() && btnSave.isEnabled()) {
            showAlertToExitScreen(callbackCode);
        } else {
            mActivity.onBackPressedCallBack(callbackCode);
        }*/
        return true;
    }

    private void showAlertToExitScreen(final int callbackCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage("You have unsaved changes.If you click on \"IGNORE & EXIT\" the data will be lost. Click on \"STAY ON SCREEN\" to go back and save.");
        builder.setPositiveButton(getResources().getString(R.string.ignore_exit), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (activityId > 0) {
                    //Dummy
                    List<DTO> list = VillageProfileDAO.getInstance().getRecordInfoByValue(null, String.valueOf(activityId), DBHandler.getInstance(mActivity).getDBObject(0));
                    if (!list.isEmpty() && list.get(0) != null) {
                        VillageProfileDTO dto = (VillageProfileDTO) list.get(0);
                        if (dto.getIsSync() == 0) {
                            MdrFarmerDAO.getInstance().deleteTableDataById(activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                            VillageProfileDAO.getInstance().deleteDataById("" + activityId, DBHandler.getInstance(mActivity).getDBObject(1));
                            NewMdrSurveyDAO.getInstance().deleteTableDataById(activityId, DBHandler.getInstance(mActivity).getDBObject(1));
//                          Utility.setActivityId(0, mActivity);
                        }
                    }
                }

                mActivity.onBackPressedCallBack(callbackCode);
            }
        });

        builder.setNegativeButton(getResources().getString(R.string.stay_on_screen), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });


        builder.create().show();

        /*builder.create().getButton(DialogInterface.BUTTON_NEGATIVE).setAllCaps(false);
        builder.create().getButton(DialogInterface.BUTTON_POSITIVE).setAllCaps(false);
        builder.create().show();*/


    }

    private boolean isDataAvailable() {
        if (activityId > 0) {
            List<DTO> farmersList = MdrFarmerDAO.getInstance().getRecordInfoById(activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (farmersList != null && farmersList.size() > 0) {
                return true;
            }

            List<DTO> surveyList = NewMdrSurveyDAO.getInstance().getRecordInfoById(activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (surveyList != null && surveyList.size() > 0) {
                return true;
            }
        }

        if (edtVillageName.getText().toString().trim().length() > 0) {
            return true;
        }

        // newly added
        if (radioButisPdaVillageYes.isChecked()) {
            return true;
        }
        if (radioButisPdaVillageNo.isChecked()) {
            return true;
        }
        if (edtRetailMobNo.getText().toString().trim().length() > 0) {
            return true;
        }

        if (edtPinCode.getText().toString().trim().length() > 0) {
            return true;
        }

        if (edtBlockName.getText().toString().trim().length() > 0) {
            return true;
        }

        if (spnCrop.getSelectedItemPosition() > 0) {
            return true;
        }

        if (spnSegment.getSelectedItemPosition() > 0) {
            return true;
        }

        return false;
    }

    private VillageProfileDTO getDataObject() {
        VillageProfileDTO dto = new VillageProfileDTO();

        dto.setVillageName(edtVillageName.getText().toString().trim());
        // newly added
        dto.setIsPDAVillage(radioButtonText(radioGroisPdaVillage));
        dto.setRetailerMobileNumber(edtRetailMobNo.getText().toString().trim());
        dto.setPinCode(edtPinCode.getText().toString().trim());
        dto.setBlockName(edtBlockName.getText().toString().trim());
        dto.setCropId(cropid);
        dto.setCropName(spnCrop.getSelectedItem().toString());
        dto.setSegment(segmentId);
        dto.setSegmentName(spnSegment.getSelectedItem().toString());

        dto.setDate(Utility.getCurrentDateAndTime());
        dto.setLocation(location);
        dto.setId(activityId);
        dto.setIsSync(-1);

        return dto;
    }

    // newly added
    private String radioButtonText(RadioGroup group) {
        if (group != null) {
            int id = group.getCheckedRadioButtonId();
            RadioButton btn = (RadioButton) group.findViewById(id);
            String selection = (String) btn.getText();
            if (selection != null && !selection.isEmpty())
                return (selection);
            else return "";
        }
        return "";
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            if (!mGoogleApiClient.isConnected())
                mGoogleApiClient.connect();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mGoogleApiClient != null) {
            if (mGoogleApiClient.isConnected())
                mGoogleApiClient.disconnect();
        }
    }

    @Override
    public void onDestroy() {
        checkForLocation = true;
        location = null;
        super.onDestroy();
    }

    private void segmentSpinnerPopulation(long cropId) {
        segmentIdDTOList = SegmentMasterDAO.getInstance().getRecordInfoByValue("cropId", String.valueOf(cropId), DBHandler.getInstance(mActivity).getDBObject(0));

        segmentNamesList.clear();
        if (segmentIdDTOList != null && segmentIdDTOList.size() > 0) {
            for (DTO dto : segmentIdDTOList) {
                if (segmentNamesList.size() == 0) {
                    segmentNamesList.add("Select");
                }
                SegmentMasterDTO segmentMasterDTO = (SegmentMasterDTO) dto;
                segmentNamesList.add(segmentMasterDTO.getSegmentName());
            }

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle("Alert");
            builder.setMessage(getResources().getString(R.string.noSegment));
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
//                    mActivity.onBackPressed();
                }
            });
            builder.create().show();
        }


        segmentIdAdapter = new ArrayAdapter<>(mActivity, android.R.layout.simple_spinner_dropdown_item, segmentNamesList);

        spnSegment.setAdapter(segmentIdAdapter);

        spnSegment.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    SegmentMasterDTO segmentMasterDTO = (SegmentMasterDTO) segmentIdDTOList.get(position - 1);
                    segmentId = segmentMasterDTO.getId();
                    changeBtnTxtFrmClr2Save("", "", "", "", "", segmentMasterDTO.getSegmentName(), "");
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }
                } else if (parent.getChildAt(0) != null) {
                    if (parent.getChildCount() > 0) {
                        if (Utility.getCurrentTheme(mActivity).equals(MyConstants.THEME_LIGHT)) {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);

                        } else {
                            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                        }
                    }
                } else {
                    segmentPopulate();
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void segmentPopulate() {
        if (activityId != 0) {
            List<DTO> dtoList = VillageProfileDAO.getInstance().getRecordInfoByValue("", "" + activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (dtoList != null && dtoList.size() > 0) {
                VillageProfileDTO dto = (VillageProfileDTO) dtoList.get(0);
                if (segmentIdDTOList != null && segmentIdDTOList.size() > 0) {
                    for (int i = 0; i < segmentIdDTOList.size(); i++) {
                        SegmentMasterDTO segmentMasterDTO = (SegmentMasterDTO) segmentIdDTOList.get(i);
                        if (dto.getSegment() == segmentMasterDTO.getId()) {
                            spnSegment.setSelection(i + 1);
                            segmentId = segmentMasterDTO.getId();
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SURVEY_LIST_REQUEST_CODE) {
            List<NewMdrSurveyDTO> surveyList = NewMdrSurveyDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(mActivity).getDBObject(0));
            if (surveyList != null && surveyList.size() > 0 && noOfSurveysDone != surveyList.size()) {
                tvAddSurveyCount.setText("" + surveyList.size());
                addSurveyCountLL.setVisibility(View.VISIBLE);
                btnSave.setText(getString(R.string.save));
                showSaveSubmitButton();
                showNotificationLayout();
            }
        } else if (requestCode == PENDING_LIST_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {

                if (data != null && data.getIntExtra(VillageProfilePendingActivity.EXTRA_PENDING_SIZE, -1) >= 0) {
                    clearFields();
                    return;
                }
                long editActivityId = Long.parseLong(data.getStringExtra(ACTIVITY_ID_VP_LIST_ACTIVITY));
                List<DTO> mdrDTOList = VillageProfileDAO.getInstance().getRecordInfoByValue("", "" + editActivityId, DBHandler.getInstance(mActivity).getDBObject(0));
                VillageProfileDTO dto = (VillageProfileDTO) mdrDTOList.get(0);

                activityId = dto.getId();
                edtVillageName.setText(dto.getVillageName());
                // newly added
                if (dto.getIsPDAVillage().equalsIgnoreCase("YES")) {
                    radioButisPdaVillageYes.setChecked(true);
                }
                if (dto.getIsPDAVillage().equalsIgnoreCase("NO")) {
                    radioButisPdaVillageNo.setChecked(true);
                }
                edtRetailMobNo.setText(dto.getRetailerMobileNumber());
                edtPinCode.setText(dto.getPinCode());
                edtBlockName.setText(dto.getBlockName());
                spnCrop.setSelection(cropNameList.indexOf(dto.getCropName()));
                segmentSpinnerPopulation(dto.getCropId());
                spnSegment.setSelection(segmentNamesList.indexOf(dto.getSegmentName()));
                List<NewMdrSurveyDTO> surveyList = NewMdrSurveyDAO.getInstance().getRecordInfoByView(activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                List<DTO> farmersList = MdrFarmerDAO.getInstance().getRecordInfoById(activityId, DBHandler.getInstance(mActivity).getDBObject(0));
                tvAddSurveyCount.setText("" + surveyList.size());
                addSurveyCountLL.setVisibility(View.VISIBLE);
                tvAddFarmersCount.setText("" + farmersList.size());
                addFarmersCountLL.setVisibility(View.VISIBLE);
                showNotificationLayout();
                clearBtnDto = dto;
                btnSave.setEnabled(false);
                btnSave.setText(getString(R.string.save));
                btnSubmit.setEnabled(true);

            }
        } else if (requestCode == UPLOADED_LIST_REQUEST_CODE) {
            String headerTxt = getString(R.string.village_profiles_uploaded).replace("$1", Utility.getNoOfProfilesUploadedByMdr(mActivity));
            villagesProfilesUploadedTv.setText(headerTxt);
        }
    }

    public void showSaveSubmitButton() {
        if (Utility.isValidStr(tvAddSurveyCount.getText().toString().trim())) {
            int totalSurveys = Integer.parseInt(tvAddSurveyCount.getText().toString().trim());
            String validation = validateFields();
            if (totalSurveys > 0 /*&& validation.trim().length() == 0*/) {
                btnSave.setEnabled(true);
//                btnSave.setBackgroundColor(getResources().getColor(R.color.app_color));
                if (btnSave.getText().toString().equalsIgnoreCase(getString(R.string.save)))
                    btnSave.setBackgroundResource(R.drawable.button_bg);
//                else
//                    btnSave.setBackgroundResource(R.drawable.button_bg_orange);
                btnSubmit.setEnabled(true);

            } else {
                btnSave.setEnabled(false);
//                btnSave.setBackgroundResource(R.drawable.button_bg);
                if (btnSave.getText().toString().equalsIgnoreCase(getString(R.string.save)))
                    btnSave.setBackgroundResource(R.drawable.button_bg);
//                else
//                    btnSave.setBackgroundResource(R.drawable.button_bg_orange);
                btnSubmit.setEnabled(false);
            }
        }
    }

    private void showNotificationLayout() {
        List<VillageProfileDTO> list = VillageProfileDAO.getInstance().getPendingRecords(mActivity, DBHandler.getInstance(mActivity).getDBObject(0));
        if (list.size() > 0) {
            notifictaionCountTv.setText("" + list.size());
            notificationRL.setVisibility(View.VISIBLE);
        } else {
            notificationRL.setVisibility(View.GONE);
            notifictaionCountTv.setText("");
        }
    }

    private VillageProfileDTO getDataObjectForSaving(String btnPressed) {
        VillageProfileDTO dto = new VillageProfileDTO();

        dto.setVillageName(edtVillageName.getText().toString().trim());
        // newly added
        dto.setIsPDAVillage(radioButtonText(radioGroisPdaVillage));
        dto.setRetailerMobileNumber(edtRetailMobNo.getText().toString().trim());
        dto.setPinCode(edtPinCode.getText().toString().trim());
        dto.setBlockName(edtBlockName.getText().toString().trim());
        dto.setCropId(cropid);
        dto.setCropName(spnCrop.getSelectedItem().toString());
        dto.setSegment(segmentId);
        dto.setSegmentName(spnSegment.getSelectedItem().toString());

        dto.setDate(Utility.getCurrentDateAndTime());
        dto.setLocation(location);
        dto.setId(activityId);
        if (btnPressed.equals(getString(R.string.submit)))
            dto.setIsSync(1);
        else
            dto.setIsSync(-1);

        return dto;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_clear) {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setMessage("The data will be cleared.Click \"OK\" to continue or \"STAY ON SCREEN\" to go back and save.");
            builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    clearFields();
                }
            });

            builder.setNegativeButton(getResources().getString(R.string.stay_on_screen), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });


            builder.create().show();

            return super.onOptionsItemSelected(item);

            /*clearFields();
            return super.onOptionsItemSelected(item);*/
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

}
