package com.activitytrack.masterdtos;

import com.activitytrack.dtos.DTO;

public class HybridMasterDTO implements DTO  
{
	private long id;
	private String name;
	private long cropId;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getHybridName() {
		return name;
	}
	public void setHybridName(String hybridName) {
		this.name = hybridName;
	}
	public long getCropId() {
		return cropId;
	}
	public void setCropId(long cropId) {
		this.cropId = cropId;
	}
}
