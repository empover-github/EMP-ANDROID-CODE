package com.activitytrack.asyncttasks;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import com.activitytrack.interfaces.AsyncTaskCompleteListener;
import com.activitytrack.utility.ATBuildLog;
import com.activitytrack.utility.MyConstants;
import com.activitytrack.utility.Utility;

import android.os.AsyncTask;

public class MyAsyncTask extends AsyncTask<String, Void, String>    {
	 private String jsonData;
	    private AsyncTaskCompleteListener asyncTaskCompleteListener;
	    private int connectionTimeout;
	    private int socketTimeout;

	    public MyAsyncTask(String requestData, AsyncTaskCompleteListener asyncTaskCompleteListener, int connectionTimeout, int socketTimeout) {
	        jsonData = requestData;
	        this.asyncTaskCompleteListener = asyncTaskCompleteListener;
	        this.connectionTimeout = connectionTimeout;
	        this.socketTimeout = socketTimeout;
	    }
        @Override
	    protected void onPreExecute() {
	        super.onPreExecute();
	    }
        @Override
	    protected String doInBackground(String... params) {
	        HttpURLConnection httpURLConnection = null;
	        try {
	            URL myurl=new URL(MyConstants.AppURL+params[0]);
	            httpURLConnection = (HttpURLConnection) myurl.openConnection();

	            //setting properties to httpURLConnection
	            httpURLConnection.setConnectTimeout(connectionTimeout);
	            httpURLConnection.setReadTimeout(socketTimeout);
	            httpURLConnection.setRequestMethod("POST");
	            httpURLConnection.setDoInput(true);
	            httpURLConnection.setDoOutput(true);
	            httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

	            OutputStream os = httpURLConnection.getOutputStream();
	            os.write(jsonData.getBytes("UTF-8"));
	            os.close();

	            //setting request data to httpURLConnection
	            /*OutputStream outputStream = httpURLConnection.getOutputStream();
	            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
	            writer.write(jsonData);
	            writer.flush();
	            writer.close();*/


				ATBuildLog.i("AsyncTask", "url :" + params[0]);
				ATBuildLog.i("AsyncTask", "request data :" + jsonData);

	            InputStream inputStream = httpURLConnection.getInputStream();
	            String responseStr = Utility.convertStreamToString(inputStream);
				ATBuildLog.i("AsyncTask", "response from server"+responseStr);
	            return responseStr;
	        } catch (Exception exception) {
	            exception.printStackTrace();
	        } finally {
	            if (httpURLConnection != null)
	                httpURLConnection.disconnect();
	        }

	        return null;
	    }
	    @Override
	    protected void onPostExecute(String result) {
	        asyncTaskCompleteListener.onAsynComplete(result);
	    }
}
