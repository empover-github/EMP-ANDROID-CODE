package com.activitytrack.activity;

import android.content.res.TypedArray;
import android.os.Bundle;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.activitytrack.adapter.NavDrawerItem;
import com.activitytrack.adapter.NavDrawerListAdapter;
import com.activitytrack.database.DBHandler;
import com.activitytrack.decorators.AT_SimpleDividerItemDecoration;
import com.activitytrack.dtos.DTO;
import com.activitytrack.listeners.OnListItemClickListener;
import com.activitytrack.masterdaos.MdrMasterDAO;
import com.activitytrack.masterdtos.MdrMasterDTO;
import com.activitytrack.utility.Utility;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yakaswamy.g on 26-12-2017.
 */

public class FragmentDrawer extends BaseFragment implements OnListItemClickListener, View.OnClickListener {
    private static String TAG = FragmentDrawer.class.getSimpleName();
    private FragmentDrawerListener drawerListener;
    private int selectedPos = -1;

    public ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private NavDrawerListAdapter adapter;
    private View containerView;
    private TextView txtVolumePlanner, txtCouponUpload, txtCouponLog,/* txtPayback,*/
            txtNotificat;
    private ImageView imgEdtName;

    private TextView txtAppVersionName, txtRetailerName, txtExit, txtLogout;
    private LinearLayout llDrawerHeader;
    // slide menu items
    private String[] navMenuTitles;
    private TypedArray navMenuIcons;

    private ArrayList<NavDrawerItem> navDrawerItems;
    //    public ListView mDrawerList;
    public RecyclerView recyclerView;
    private ImageView userIconImg, logoutIconImg;
    private TextView userIconTV, logoutIconTV;

    public FragmentDrawer() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
//        navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);
//        // nav drawer icons from resources
//        navMenuIcons = getResources().obtainTypedArray(R.array.nav_drawer_icons);
        super.onCreate(savedInstanceState);
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        mActivity.onBackPressedCallBack(callbackCode);
        return true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //inflating view
        View layout = inflater.inflate(R.layout.fragment_navigation_drawer_at, container, false);

        initComponents(layout);

        List<DTO> userDtoList = MdrMasterDAO.getInstance().getRecords(DBHandler.getInstance(mActivity).getDBObject(0));
        if (userDtoList != null && userDtoList.size() > 0) {
            MdrMasterDTO loginDTO = (MdrMasterDTO) userDtoList.get(0);
//            navMenuTitles[0] = loginDTO.getLoginId();
            userIconTV.setText(loginDTO.getLoginId());
        }

//        mDrawerList = (ListView) layout.findViewById(R.id.list_slidermenu);
        navDrawerItems = new ArrayList<NavDrawerItem>();
        // adding nav drawer items to array
        // Home
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[0], navMenuIcons
//                .getResourceId(0, -1)));
        // Find People

        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_home), R.drawable.at_home_icon));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_dash), R.drawable.dashboard_icon));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_village), R.drawable.mdrprofile_icon));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_pravatha), R.drawable.ic_pravaktha_ha_gain));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_dipstick), R.drawable.dipstick_icon));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_atten), R.drawable.qrcode));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_yield), R.drawable.yield_calculator_icon));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_data), R.drawable.data_sync_icon));
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_change), R.drawable.changetheme_icon));
        if(Utility.getShowFarmerSegmention(mActivity))
        navDrawerItems.add(new NavDrawerItem(getString(R.string.tab_silage_farmer), R.drawable.ic_pravaktha_ha_gain));
//        // Photos
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[2], navMenuIcons
//                .getResourceId(2, -1)));
//        // Communities, Will add a counter here
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[3], navMenuIcons
//                .getResourceId(3, -1)));
//        // Pages
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[4], navMenuIcons
//                .getResourceId(4, -1)));
//
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[5], navMenuIcons
//                .getResourceId(5, -1)));
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[6], navMenuIcons
//                .getResourceId(6, -1)));
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[7], navMenuIcons
//                .getResourceId(7, -1)));
////NEWLY ADDED
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[8], navMenuIcons.
//                getResourceId(8, -1)));
//
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[9], navMenuIcons.
//                getResourceId(9, -1)));
//        navDrawerItems.add(new NavDrawerItem(navMenuTitles[10], navMenuIcons.
//                getResourceId(10, -1)));
        /*navDrawerItems.add(new NavDrawerItem(navMenuTitles[9],navMenuIcons.
                getResourceId(9,-1)));*/
        // What's hot, We will add a counter here
        // Recycle the typed array
//        navMenuIcons.recycle();

        // setting the nav drawer list adapter
        adapter = new NavDrawerListAdapter(mActivity, navDrawerItems, this);
        recyclerView.setAdapter(adapter);

//        mDrawerList.setOnItemClickListener(this);
        return layout;
    }

    private void initComponents(View rootView) {
        recyclerView = (RecyclerView) rootView.findViewById(R.id.list_slidermenu);
        userIconImg = (ImageView) rootView.findViewById(R.id.icon);
        logoutIconImg = (ImageView) rootView.findViewById(R.id.log_icon);
        userIconTV = (TextView) rootView.findViewById(R.id.title);
        logoutIconTV = (TextView) rootView.findViewById(R.id.log_title);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setAutoMeasureEnabled(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new AT_SimpleDividerItemDecoration(getActivity()));
        recyclerView.setFocusable(false);
        logoutIconImg.setOnClickListener(this);
    }

    public boolean isDrawerOpen(int left) {
        return mDrawerLayout.isDrawerOpen(left);
    }

    public void closeDrawer(int left) {
        mDrawerLayout.closeDrawer(left);
    }

//    @Override
//    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        mActivity.displayView(position);
//    }

    @Override
    public void onItemLongClick(View view, int position) {

    }

    @Override
    public void onItemClick(View view, int position) {
        String navItem = navDrawerItems.get(position).getTitle();

        if (navItem.equalsIgnoreCase(getString(R.string.tab_home))) {
            mActivity.displayView(1);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_dash))) {
            mActivity.displayView(2);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_village))) {
            mActivity.displayView(3);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_pravatha))) {
            mActivity.displayView(4);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_dipstick))) {
            mActivity.displayView(5);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_atten))) {
            mActivity.displayView(6);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_yield))) {
            mActivity.displayView(7);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_data))) {
            mActivity.displayView(8);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_change))) {
            mActivity.displayView(9);
        } else if (navItem.equalsIgnoreCase(getString(R.string.tab_silage_farmer))) {
            mActivity.displayView(10);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.log_icon)
            mActivity.displayView(11);
    }

    public static interface ClickListener {
        public void onClick(View view, int position);

        public void onLongClick(View view, int position);
    }

    public interface FragmentDrawerListener {
        public void onDrawerItemSelected(View view, int position);
    }

    public void setDrawerListener(FragmentDrawerListener listener) {
        this.drawerListener = listener;
    }


    public void setUp(int fragmentId, final DrawerLayout drawerLayout, final Toolbar toolbar) {
        containerView = getActivity().findViewById(fragmentId);
        mDrawerLayout = drawerLayout;
        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
//                getActivity().invalidateOptionsMenu();
//                recyclerView.scrollToPosition(0);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
//                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                toolbar.setAlpha(1 - slideOffset / 2);
            }
        };
        mDrawerToggle.setDrawerIndicatorEnabled(false);
        mDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });

    }

}