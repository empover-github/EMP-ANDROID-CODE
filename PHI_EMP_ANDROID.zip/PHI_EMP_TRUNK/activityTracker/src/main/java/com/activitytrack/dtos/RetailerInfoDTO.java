package com.activitytrack.dtos;

public class RetailerInfoDTO  implements DTO
{
	 
	private long mobileId;
	private String location;
	private int isSync;
	private  String name;
	 private long mobileNo; 
	 private long altMobileNumber;
	 private String date;
	 private String activity;
     private long activityId;
	
	 public String getRetailerName() {
		return name;
	}
	public void setRetailerName(String retailerName) {
		this.name = retailerName;
	}
	public long getMobileNumber() {
		return mobileNo;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNo = mobileNumber;
	}
	public long getAltMobileNumber() {
		return altMobileNumber;
	}
	public void setAltMobileNumber(long altMobileNumber) {
		this.altMobileNumber = altMobileNumber;
	}
	public long getId() {
		return mobileId;
	}
	public void setId(long id) {
		this.mobileId = id;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getIsSync() {
		return isSync;
	}
	public void setIsSync(int isSync) {
		this.isSync = isSync;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public long getActivityId() {
		return activityId;
	}
	public void setActivityId(long activityId) {
		this.activityId = activityId;
	}
}
