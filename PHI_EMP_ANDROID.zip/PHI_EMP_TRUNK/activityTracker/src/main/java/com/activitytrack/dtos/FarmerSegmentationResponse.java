package com.activitytrack.dtos;

public class FarmerSegmentationResponse implements DTO {
    private int code;
    private boolean success;
    private FarmerSegmentationResponseDTO farmerSegmentationResponse;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public FarmerSegmentationResponseDTO getFarmerSegmentationResponse() {
        return farmerSegmentationResponse;
    }

    public void setFarmerSegmentationResponse(FarmerSegmentationResponseDTO farmerSegmentationResponse) {
        this.farmerSegmentationResponse = farmerSegmentationResponse;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
