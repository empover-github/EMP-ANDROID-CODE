package com.activitytrack.masterdtos;

import com.activitytrack.dtos.AgronomySummaryDTO;
import com.activitytrack.dtos.CompanyMasterDTO;
import com.activitytrack.dtos.DemandSummaryDTO;
import com.activitytrack.dtos.DipstickDTO;
import com.activitytrack.dtos.GerminationverificationListDTO;
import com.activitytrack.dtos.UploadedVillageListDTO;
import com.activitytrack.models.SegmentationMasterDataModel;

import java.util.List;

public class MasterDataDTO {

	private List<CropMasterDTO> cropMaster;
	private List<HybridMasterDTO> hybridMaster;
	private List<OtherCropMasterDTO> otherCropMaster;
	private List<SegmentMasterDTO> segmentMaster;
	private List<SeasonCalendarDTO> seasonCalendar;
	private List<SeasonMasterDTO> seasonMaster;
	private List<MdrMasterDTO>	mdrMaster;
	private List<RetailerMasterDTO> retailerMaster;
	private List<TargetDemandPDADTO> targetDemandPDADateWise;
	private List<TargetDemandOSADTO> targetDemandOSADateWise;
	private List<TargetDemandPSADTO> targetDemandPSADateWise;
	private List<TargetAgronomyDTO> targetAgronomy;
	private List<Top3HybridsDTO> top3Hybrids;
	private List<DemandSummaryDTO> demandSummary;
	private List<AgronomySummaryDTO> agronomySummary;
	private boolean forceChangePassword;
	private List<DipstickDTO> dipsticks;
	private long villageProfileCount;
	private List<UploadedVillageListDTO> villageProfileUploadedData;
	private List<CompanyMasterDTO> companyMaster;
	private List<CompanyMasterDTO> researchCompanyMaster;
	private List<GerminationverificationListDTO> germinationPendingVerificationList;
	private boolean showFarmerSegmentation;
	private SegmentationMasterDataModel farmerSegmentationMasterData;


	public boolean isShowFarmerSegmentation() {
		return showFarmerSegmentation;
	}

	public void setShowFarmerSegmentation(boolean showFarmerSegmentation) {
		this.showFarmerSegmentation = showFarmerSegmentation;
	}

	public List<DipstickDTO> getDipsticks() {
		return dipsticks;
	}
	public void setDipsticks(List<DipstickDTO> pupchaseIntentions) {
		this.dipsticks = pupchaseIntentions;
	}
	public List<CropMasterDTO> getCropMaster() {
		return cropMaster;
	}
	public void setCropMaster(List<CropMasterDTO> cropMaster) {
		this.cropMaster = cropMaster;
	}
	public List<HybridMasterDTO> getHybridMaster() {
		return hybridMaster;
	}
	public void setHybridMaster(List<HybridMasterDTO> hybridMaster) {
		this.hybridMaster = hybridMaster;
	}
	public List<SeasonCalendarDTO> getSeasonCalendar() {
		return seasonCalendar;
	}
	public void setSeasonCalendar(List<SeasonCalendarDTO> seasonCalendar) {
		this.seasonCalendar = seasonCalendar;
	}
	public List<SeasonMasterDTO> getSeasonMaster() {
		return seasonMaster;
	}
	public void setSeasonMaster(List<SeasonMasterDTO> seasonMaster) {
		this.seasonMaster = seasonMaster;
	}
	public List<MdrMasterDTO> getMdrMaster() {
		return mdrMaster;
	}
	public void setMdrMaster(List<MdrMasterDTO> mdrMaster) {
		this.mdrMaster = mdrMaster;
	}
	public List<RetailerMasterDTO> getRetailerMaster() {
		return retailerMaster;
	}
	public void setRetailerMaster(List<RetailerMasterDTO> retailerMaster) {
		this.retailerMaster = retailerMaster;
	}
	public List<TargetDemandPDADTO> getTargetDemandPDA() {
		return targetDemandPDADateWise;
	}
	public void setTargetDemandPDA(List<TargetDemandPDADTO> targetDemand) {
		this.targetDemandPDADateWise = targetDemand;
	}
	public List<TargetAgronomyDTO> getTargetAgronomy() {
		return targetAgronomy;
	}
	public void setTargetAgronomy(List<TargetAgronomyDTO> targetAgronomy) {
		this.targetAgronomy = targetAgronomy;
	}
	public List<TargetDemandOSADTO> getTargetDemandOSA() {
		return targetDemandOSADateWise;
	}
	public void setTargetDemandOSA(List<TargetDemandOSADTO> targetDemandOSA) {
		this.targetDemandOSADateWise = targetDemandOSA;
	}
	public List<TargetDemandPSADTO> getTargetDemandPSA() {
		return targetDemandPSADateWise;
	}
	public void setTargetDemandPSA(List<TargetDemandPSADTO> targetDemandPSA) {
		this.targetDemandPSADateWise = targetDemandPSA;
	}
	public List<Top3HybridsDTO> getTop3Hybrids() {
		return top3Hybrids;
	}
	public void setTop3Hybrids(List<Top3HybridsDTO> top3Hybrids) {
		this.top3Hybrids = top3Hybrids;
	}
	public List<DemandSummaryDTO> getDemandsumary() {
		return demandSummary;
	}
	public void setDemandsumary(List<DemandSummaryDTO> demandsumary) {
		this.demandSummary = demandsumary;
	}
	public boolean isForceChangePassword() {
		return forceChangePassword;
	}
	public void setForceChangePassword(boolean isForceChangePassword) {
		this.forceChangePassword = isForceChangePassword;
	}
	public List<AgronomySummaryDTO> getAgronomySummary() {
		return agronomySummary;
	}
	public void setAgronomySummary(List<AgronomySummaryDTO> agronomySummary) {
		this.agronomySummary = agronomySummary;
	}

	public List<SegmentMasterDTO> getSegmentMaster() {
		return segmentMaster;
	}

	public void setSegmentMaster(List<SegmentMasterDTO> segmentMaster) {
		this.segmentMaster = segmentMaster;
	}

	public long getVillageProfileCount() {
		return villageProfileCount;
	}

	public void setVillageProfileCount(long villageProfileCount) {
		this.villageProfileCount = villageProfileCount;
	}

	public List<OtherCropMasterDTO> getOtherCropMaster() {
		return otherCropMaster;
	}

	public void setOtherCropMaster(List<OtherCropMasterDTO> otherCropMaster) {
		this.otherCropMaster = otherCropMaster;
	}

	public List<UploadedVillageListDTO> getVillageProfileUploadedData() {
		return villageProfileUploadedData;
	}

	public void setVillageProfileUploadedData(List<UploadedVillageListDTO> villageProfileUploadedData) {
		this.villageProfileUploadedData = villageProfileUploadedData;
	}

	public List<CompanyMasterDTO> getCompanyMaster() {
		return companyMaster;
	}

	public void setCompanyMaster(List<CompanyMasterDTO> companyMaster) {
		this.companyMaster = companyMaster;
	}

	public List<CompanyMasterDTO> getResearchCompanyMaster() {
		return researchCompanyMaster;
	}

	public void setResearchCompanyMaster(List<CompanyMasterDTO> researchCompanyMaster) {
		this.researchCompanyMaster = researchCompanyMaster;
	}

	public List<GerminationverificationListDTO> getGerminationPendingVerificationList() {
		return germinationPendingVerificationList;
	}

	public void setGerminationPendingVerificationList(List<GerminationverificationListDTO> germinationPendingVerificationList) {
		this.germinationPendingVerificationList = germinationPendingVerificationList;
	}

	public SegmentationMasterDataModel getFarmerSegmentationMasterData() {
		return farmerSegmentationMasterData;
	}

	public void setFarmerSegmentationMasterData(SegmentationMasterDataModel farmerSegmentationMasterData) {
		this.farmerSegmentationMasterData = farmerSegmentationMasterData;
	}
}
