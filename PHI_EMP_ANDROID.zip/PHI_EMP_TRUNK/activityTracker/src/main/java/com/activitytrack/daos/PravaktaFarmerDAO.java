package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.PravaktaFarmerDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rambabu.a on 06-03-2018.
 */

public class PravaktaFarmerDAO implements DAO {
    private final String TAG = "PravaktaFarmer";
    private static PravaktaFarmerDAO mdrFarmerDAO;

    public static PravaktaFarmerDAO getInstance() {
        if (mdrFarmerDAO == null) {
            mdrFarmerDAO = new PravaktaFarmerDAO();
        }

        return mdrFarmerDAO;
    }

    /**
     * delete the Data
     */

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {

        return false;
    }


    /**
     * Gets the record from the database based on the value passed
     *
     * @param columnName  : Database column name
     * @param columnValue : Column Value
     * @param dbObject    : Exposes methods to manage a SQLite database Object
     */

    @Override
    public List<DTO> getRecordInfoByValue(String columnName,
                                          String columnValue, SQLiteDatabase dbObject) {
        List<DTO> pravaktaFarmerInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM PRAVAKTA_FARMER where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                         /* PRAVAKTA_FARMER
                              id
                              farmerPhoto
                              pdaAttendPre
                              pdaAttendCurr
                              pionUserPre
                              pionUserCurr
                              previousYear
                              currentYear
                              totalPreviousAcresFarm
                              totalPresentAcresFarm
                              phiPreviousAcresFarm
                              phiPresentAcresFarm
                              targetPreviousAcresFarm
                              targetPresentAcresFarm
                              rice
                              corn
                              millet
                              mustard
                              targetHybridFarm
                              activityId
                              farmerName
                              farmerMobileNo
	                   */
                    PravaktaFarmerDTO dto = new PravaktaFarmerDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setImageUrlPath(cursor.getString(1));
                    dto.setPdaAttendPre(cursor.getString(2));
                    dto.setPdaAttendCurr(cursor.getString(3));
                    dto.setPionUserPre(cursor.getString(4));
                    dto.setPionUserCurr(cursor.getString(5));
                    dto.setPreviousYear(cursor.getString(6));
                    dto.setCurrentYear(cursor.getString(7));
                    dto.setTotalPreviousAcresFarm(cursor.getString(8));
                    dto.setTotalPresentAcresFarm(cursor.getString(9));
                    dto.setPhiPreviousAcresFarm(cursor.getString(10));
                    dto.setPhiPresentAcresFarm(cursor.getString(11));
                    dto.setTargetPreviousAcresFarm(cursor.getString(12));
                    dto.setTargetPresentAcresFarm(cursor.getString(13));
                    dto.setRice(cursor.getString(cursor.getColumnIndex("rice")).equals("true"));
                    dto.setCorn(cursor.getString(cursor.getColumnIndex("corn")).equals("true"));
                    dto.setMillet(cursor.getString(cursor.getColumnIndex("millet")).equals("true"));
                    dto.setMustard(cursor.getString(cursor.getColumnIndex("mustard")).equals("true"));
                    dto.setTargetHybridFarm(cursor.getString(18));
                    dto.setActivityId(cursor.getLong(19));
                    dto.setFarmerName(cursor.getString(20));
                    dto.setFarmerMobileNo(cursor.getString(21));
                    pravaktaFarmerInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pravaktaFarmerInfo;
    }

    public List<DTO> getRecordInfoById(long activityId, SQLiteDatabase dbObject) {

        List<DTO> pravaktaFarmerInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM  PRAVAKTA_FARMER   where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
              /* PRAVAKTA_FARMER
                              id
                              farmerPhoto
                              pdaAttendPre
                              pdaAttendCurr
                              pionUserPre
                              pionUserCurr
                               previousYear
                              currentYear
                              totalPreviousAcresFarm
                              totalPresentAcresFarm
                              phiPreviousAcresFarm
                              phiPresentAcresFarm
                              targetPreviousAcresFarm
                              targetPresentAcresFarm
                              rice
                              corn
                              millet
                              mustard
                              targetHybridFarm
                              activityId
                              farmerName
                              farmerMobileNo

	                   */
                    PravaktaFarmerDTO dto = new PravaktaFarmerDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setImageUrlPath(cursor.getString(1));
                    dto.setPdaAttendPre(cursor.getString(2));
                    dto.setPdaAttendCurr(cursor.getString(3));
                    dto.setPionUserPre(cursor.getString(4));
                    dto.setPionUserCurr(cursor.getString(5));
                    dto.setPreviousYear(cursor.getString(6));
                    dto.setCurrentYear(cursor.getString(7));
                    dto.setTotalPreviousAcresFarm(cursor.getString(8));
                    dto.setTotalPresentAcresFarm(cursor.getString(9));
                    dto.setPhiPreviousAcresFarm(cursor.getString(10));
                    dto.setPhiPresentAcresFarm(cursor.getString(11));
                    dto.setTargetPreviousAcresFarm(cursor.getString(12));
                    dto.setTargetPresentAcresFarm(cursor.getString(13));
                    dto.setRice(cursor.getString(cursor.getColumnIndex("rice")).equals("true"));
                    dto.setCorn(cursor.getString(cursor.getColumnIndex("corn")).equals("true"));
                    dto.setMillet(cursor.getString(cursor.getColumnIndex("millet")).equals("true"));
                    dto.setMustard(cursor.getString(cursor.getColumnIndex("mustard")).equals("true"));
                    dto.setTargetHybridFarm(cursor.getString(18));
                    dto.setActivityId(cursor.getLong(19));
                    dto.setFarmerName(cursor.getString(20));
                    dto.setFarmerMobileNo(cursor.getString(21));
                    pravaktaFarmerInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pravaktaFarmerInfo;
    }

    /**
     * Gets all the records from the database
     *
     * @param dbObject : Exposes methods to manage a SQLite database Object
     */


    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> parvaktaFarmerInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM PRAVAKTA_FARMER", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    PravaktaFarmerDTO dto = new PravaktaFarmerDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setImageUrlPath(cursor.getString(1));
                    dto.setPdaAttendPre(cursor.getString(2));
                    dto.setPdaAttendCurr(cursor.getString(3));
                    dto.setPionUserPre(cursor.getString(4));
                    dto.setPionUserCurr(cursor.getString(5));
                    dto.setPreviousYear(cursor.getString(6));
                    dto.setCurrentYear(cursor.getString(7));
                    dto.setTotalPreviousAcresFarm(cursor.getString(8));
                    dto.setTotalPresentAcresFarm(cursor.getString(9));
                    dto.setPhiPreviousAcresFarm(cursor.getString(10));
                    dto.setPhiPresentAcresFarm(cursor.getString(11));
                    dto.setTargetPreviousAcresFarm(cursor.getString(12));
                    dto.setTargetPresentAcresFarm(cursor.getString(13));

                    dto.setRice(cursor.getString(cursor.getColumnIndex("rice")).equals("true"));
                    dto.setCorn(cursor.getString(cursor.getColumnIndex("corn")).equals("true"));
                    dto.setMillet(cursor.getString(cursor.getColumnIndex("millet")).equals("true"));
                    dto.setMustard(cursor.getString(cursor.getColumnIndex("mustard")).equals("true"));

                    dto.setTargetHybridFarm(cursor.getString(18));
                    dto.setActivityId(cursor.getLong(19));
                    dto.setFarmerName(cursor.getString(20));
                    dto.setFarmerMobileNo(cursor.getString(21));
                    parvaktaFarmerInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return parvaktaFarmerInfo;
    }


    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @param dtoObject : DTO object is passed
     */


    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            PravaktaFarmerDTO dto = (PravaktaFarmerDTO) dtoObject;

            ContentValues cValues = new ContentValues();

	            /* PRAVAKTA_FARMER
                              id
                              farmerPhoto
                              pdaAttendPre
                              pdaAttendCurr
                              pionUserPre
                              pionUserCurr
                               previousYear
                              currentYear
                              totalPreviousAcresFarm
                              totalPresentAcresFarm
                              phiPreviousAcresFarm
                              phiPresentAcresFarm
                              targetPreviousAcresFarm
                              targetPresentAcresFarm
                              rice
                              corn
                              millet
                              mustard
                              targetHybridFarm
                              activityId
                               farmerName
                              farmerMobileNo
	                   */
            cValues.put("imageUrlPath", dto.getImageUrlPath());
            cValues.put("pdaAttendPre", dto.getPdaAttendPre());
            cValues.put("pdaAttendCurr", dto.getPdaAttendCurr());
            cValues.put("pionUserPre", dto.getPionUserPre());
            cValues.put("pionUserCurr", dto.getPionUserCurr());
            cValues.put("previousYear", dto.getPreviousYear());
            cValues.put("currentYear", dto.getCurrentYear());
            cValues.put("totalPreviousAcresFarm", dto.getTotalPreviousAcresFarm());
            cValues.put("totalPresentAcresFarm", dto.getTotalPresentAcresFarm());
            cValues.put("phiPreviousAcresFarm", dto.getPhiPreviousAcresFarm());
            cValues.put("phiPresentAcresFarm", dto.getPhiPresentAcresFarm());
            cValues.put("targetPreviousAcresFarm", dto.getTargetPreviousAcresFarm());
            cValues.put("targetPresentAcresFarm", dto.getTargetPresentAcresFarm());
            cValues.put("rice", String.valueOf(dto.getRice()));
            cValues.put("corn", String.valueOf(dto.getCorn()));
            cValues.put("millet", String.valueOf(dto.getMillet()));
            cValues.put("mustard", String.valueOf(dto.getMustard()));
            cValues.put("targetHybridFarm", dto.getTargetHybridFarm());
            cValues.put("activityId", dto.getActivityId());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("farmerMobileNo", dto.getFarmerMobileNo());

            dbObject.insert("PRAVAKTA_FARMER", null, cValues);
            return true;
        } catch (SQLException e) {
            Log.e(TAG + "insert()", e.getMessage());
            return false;
        } finally {
            dbObject.close();
        }

    }


    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject : DTO object is passed
     * @param dbObject  : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            PravaktaFarmerDTO dto = (PravaktaFarmerDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getImageUrlPath() != null)
                cValues.put("imageUrlPath", dto.getImageUrlPath());

            if (dto.getPdaAttendPre() != null)
                cValues.put("pdaAttendPre", dto.getPdaAttendPre());

            if (dto.getPdaAttendCurr() != null)
                cValues.put("pdaAttendCurr", dto.getPdaAttendCurr());

            if (dto.getPionUserPre() != null)
                cValues.put("pionUserPre", dto.getPionUserPre());

            if (dto.getPionUserCurr() != null)
                cValues.put("pionUserCurr", dto.getPionUserCurr());

            if (dto.getPreviousYear() != null)
                cValues.put("previousYear", dto.getPreviousYear());

            if (dto.getCurrentYear() != null)
                cValues.put("currentYear", dto.getCurrentYear());

            if (dto.getTotalPreviousAcresFarm() != null)
                cValues.put("totalPreviousAcresFarm", dto.getTotalPreviousAcresFarm());

            if (dto.getTotalPresentAcresFarm() != null)
                cValues.put("totalPresentAcresFarm", dto.getTotalPresentAcresFarm());

            if (dto.getPhiPreviousAcresFarm() != null)
                cValues.put("phiPreviousAcresFarm", dto.getPhiPreviousAcresFarm());

            if (dto.getPhiPresentAcresFarm() != null)
                cValues.put("phiPresentAcresFarm", dto.getPhiPresentAcresFarm());

            if (dto.getTargetPreviousAcresFarm() != null)
                cValues.put("targetPreviousAcresFarm", dto.getTargetPreviousAcresFarm());

            if (dto.getTargetPresentAcresFarm() != null)
                cValues.put("targetPresentAcresFarm", dto.getTargetPresentAcresFarm());

            cValues.put("rice", String.valueOf(dto.getRice()));
            cValues.put("corn", String.valueOf(dto.getCorn()));
            cValues.put("millet", String.valueOf(dto.getMillet()));
            cValues.put("mustard", String.valueOf(dto.getMustard()));

            if (dto.getTargetHybridFarm() != null)
                cValues.put("targetHybridFarm", dto.getTargetHybridFarm());

            if (dto.getActivityId() != 0)
                cValues.put("activityId", dto.getActivityId());

            if (dto.getFarmerName() != null)
                cValues.put("farmerName", dto.getFarmerName());

            if (dto.getFarmerMobileNo() != null)
                cValues.put("farmerMobileNo", dto.getFarmerMobileNo());

            dbObject.update("PRAVAKTA_FARMER", cValues, "id='" + dto.getId() + "' ", null);

            return true;
        } catch (SQLException e) {
            Log.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM MDR_FARMER").execute();
            return true;
        } catch (Exception e) {
            Log.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public List<PravaktaFarmerDTO> getRecordsForUpload(long activityId, SQLiteDatabase dbObject) {

        List<PravaktaFarmerDTO> farmerEntryInfo = new ArrayList<PravaktaFarmerDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM  PRAVAKTA_FARMER where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    PravaktaFarmerDTO dto = new PravaktaFarmerDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setImageUrlPath(cursor.getString(1));
                    dto.setPdaAttendPre(cursor.getString(2));
                    dto.setPdaAttendCurr(cursor.getString(3));
                    dto.setPionUserPre(cursor.getString(4));
                    dto.setPionUserCurr(cursor.getString(5));
                    dto.setPreviousYear(cursor.getString(6));
                    dto.setCurrentYear(cursor.getString(7));
                    dto.setTotalPreviousAcresFarm(cursor.getString(8));
                    dto.setTotalPresentAcresFarm(cursor.getString(9));
                    dto.setPhiPreviousAcresFarm(cursor.getString(10));
                    dto.setPhiPresentAcresFarm(cursor.getString(11));
                    dto.setTargetPreviousAcresFarm(cursor.getString(12));
                    dto.setTargetPresentAcresFarm(cursor.getString(13));
                    dto.setRice(cursor.getString(cursor.getColumnIndex("rice")).equals("true"));
                    dto.setCorn(cursor.getString(cursor.getColumnIndex("corn")).equals("true"));
                    dto.setMillet(cursor.getString(cursor.getColumnIndex("millet")).equals("true"));
                    dto.setMustard(cursor.getString(cursor.getColumnIndex("mustard")).equals("true"));
                    dto.setTargetHybridFarm(cursor.getString(18));
                    dto.setActivityId(cursor.getLong(19));
                    dto.setFarmerName(cursor.getString(20));
                    dto.setFarmerMobileNo(cursor.getString(21));
                    farmerEntryInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return farmerEntryInfo;
    }

    public boolean deleteTableDataById(long activityId, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM PRAVAKTA_FARMER  where activityId = '" + activityId + "'").execute();
            return true;
        } catch (Exception e) {
            Log.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public List<PravaktaFarmerDTO> getRecordInfoByView(long activityId, SQLiteDatabase dbObject) {

        List<PravaktaFarmerDTO> pravaktaFarmerInfo = new ArrayList<PravaktaFarmerDTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM  PRAVAKTA_FARMER   where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
              /* PRAVAKTA_FARMER
                              id
                              farmerPhoto
                              pdaAttendPre
                              pdaAttendCurr
                              pionUserPre
                              pionUserCurr
                               previousYear
                              currentYear
                              totalPreviousAcresFarm
                              totalPresentAcresFarm
                              phiPreviousAcresFarm
                              phiPresentAcresFarm
                              targetPreviousAcresFarm
                              targetPresentAcresFarm
                              rice
                              corn
                              millet
                              mustard
                              targetHybridFarm
                              activityId
	                   */
                    PravaktaFarmerDTO dto = new PravaktaFarmerDTO();

                    dto.setId(cursor.getLong(0));
                    dto.setImageUrlPath(cursor.getString(1));
                    dto.setPdaAttendPre(cursor.getString(2));
                    dto.setPdaAttendCurr(cursor.getString(3));
                    dto.setPionUserPre(cursor.getString(4));
                    dto.setPionUserCurr(cursor.getString(5));
                    dto.setPreviousYear(cursor.getString(6));
                    dto.setCurrentYear(cursor.getString(7));
                    dto.setTotalPreviousAcresFarm(cursor.getString(8));
                    dto.setTotalPresentAcresFarm(cursor.getString(9));
                    dto.setPhiPreviousAcresFarm(cursor.getString(10));
                    dto.setPhiPresentAcresFarm(cursor.getString(11));
                    dto.setTargetPreviousAcresFarm(cursor.getString(12));
                    dto.setTargetPresentAcresFarm(cursor.getString(13));
                    dto.setRice(cursor.getString(cursor.getColumnIndex("rice")).equals("true"));
                    dto.setCorn(cursor.getString(cursor.getColumnIndex("corn")).equals("true"));
                    dto.setMillet(cursor.getString(cursor.getColumnIndex("millet")).equals("true"));
                    dto.setMustard(cursor.getString(cursor.getColumnIndex("mustard")).equals("true"));
                    dto.setTargetHybridFarm(cursor.getString(18));
                    dto.setActivityId(cursor.getLong(19));
                    dto.setFarmerName(cursor.getString(20));
                    dto.setFarmerMobileNo(cursor.getString(21));
                    pravaktaFarmerInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pravaktaFarmerInfo;
    }


}
