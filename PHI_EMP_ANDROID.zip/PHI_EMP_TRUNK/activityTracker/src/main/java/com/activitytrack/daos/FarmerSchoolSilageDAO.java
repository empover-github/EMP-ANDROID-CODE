package com.activitytrack.daos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.FarmerSchoolSilageDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class FarmerSchoolSilageDAO implements DAO {

    private final String TAG = "segmentationRiceRequest";
    private static FarmerSchoolSilageDAO farmerSegmentationRiceDAO;

    public static FarmerSchoolSilageDAO getInstance() {
        if (farmerSegmentationRiceDAO == null) {
            farmerSegmentationRiceDAO = new FarmerSchoolSilageDAO();
        }
        return farmerSegmentationRiceDAO;
    }

    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            FarmerSchoolSilageDTO dto = (FarmerSchoolSilageDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            cValues.put("year", dto.getYear());
            cValues.put("mobileNo", dto.getMobileNo());
            cValues.put("pincode", dto.getPincode());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("district", dto.getDistrict());
            cValues.put("village", dto.getVillage());
            cValues.put("block", dto.getBlock());
            cValues.put("geoLocation", dto.getGeoLocation());
            cValues.put("localImagePath", dto.getLocalImagePath());
            cValues.put("timeStamp", dto.getDate());
            cValues.put("isSync", dto.getIsSync());

            cValues.put("devCenterId", dto.getDevCenterId());
            cValues.put("schoolId", dto.getSchoolId());
            cValues.put("totalNoOfCattles", dto.getTotalNoOfCattles());
            cValues.put("avgMilkYield", dto.getAvgMilkYield());
            cValues.put("silageFeeding", dto.getSilageFeeding());
            cValues.put("growingOrProcuring", dto.getGrowingOrProcuring());
            cValues.put("silageAcres", dto.getSilageAcres());
            cValues.put("currHyb1Name", dto.getCurrHyb1Name());
            cValues.put("currHyb1Value", dto.getCurrHyb1Value());
            cValues.put("currHyb2Name", dto.getCurrHyb2Name());
            cValues.put("currHyb2Value", dto.getCurrHyb2Value());
            cValues.put("currHyb3Name", dto.getCurrHyb3Name());
            cValues.put("currHyb3Value", dto.getCurrHyb3Value());
            cValues.put("currHyb4Name", dto.getCurrHyb4Name());
            cValues.put("currHyb4Value", dto.getCurrHyb4Value());
            cValues.put("currHyb5Name", dto.getCurrHyb5Name());
            cValues.put("currHyb5Value", dto.getCurrHyb5Value());
            cValues.put("trainingPlant", dto.getTrainingPlant());
            cValues.put("trainingGrow", dto.getTrainingGrow());
            cValues.put("trainingHarvest", dto.getTrainingHarvest());
            cValues.put("trainingStore", dto.getTrainingStore());
            cValues.put("trainingFeed", dto.getTrainingFeed());

            long inserted = dbObject.insert("FARMER_SCHOOL_SILAGE", null, cValues);

                return true;

        } catch (SQLException e) {

            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;


        } finally {
            dbObject.close();
        }
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {

            FarmerSchoolSilageDTO dto = (FarmerSchoolSilageDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getId() != 0)
                cValues.put("id", dto.getId());

            if (dto.getYear() != null)
                cValues.put("year", dto.getYear());

            if (dto.getMobileNo() != null)
                cValues.put("mobileNo", dto.getMobileNo());

            if (dto.getPincode() != null)
                cValues.put("pincode", dto.getPincode());

            if (dto.getFarmerName() != null)
                cValues.put("farmerName", dto.getFarmerName());

            if (dto.getDistrict() != null)
                cValues.put("district", dto.getDistrict());

            if (dto.getVillage() != null)
                cValues.put("village", dto.getVillage());

            if (dto.getBlock() != null)
                cValues.put("block", dto.getBlock());

            if (dto.getLocalImagePath() != null)
                cValues.put("localImagePath", dto.getLocalImagePath());


            if (dto.getDate() != null)
                cValues.put("timeStamp", dto.getDate());

                cValues.put("isSync", dto.getIsSync());

            if (dto.getGeoLocation() != null)
                cValues.put("geoLocation", dto.getGeoLocation());

            if (dto.getDevCenterId() != 0)
                cValues.put("devCenterId", dto.getDevCenterId());
            if (dto.getSchoolId() != 0)
                cValues.put("schoolId", dto.getSchoolId());
            if (dto.getTotalNoOfCattles() != 0)
                cValues.put("totalNoOfCattles", dto.getTotalNoOfCattles());
            if (dto.getAvgMilkYield() != 0)
                cValues.put("avgMilkYield", dto.getAvgMilkYield());
            if (dto.getSilageFeeding() != null)
                cValues.put("silageFeeding", dto.getSilageFeeding());
            if (dto.getGrowingOrProcuring() != null)
                cValues.put("growingOrProcuring", dto.getGrowingOrProcuring());
            if (dto.getSilageAcres() != 0)
                cValues.put("silageAcres", dto.getSilageAcres());
            if (dto.getCurrHyb1Name() != null)
                cValues.put("currHyb1Name", dto.getCurrHyb1Name());
            if (dto.getCurrHyb1Value() != null)
                cValues.put("currHyb1Value", dto.getCurrHyb1Value());
            if (dto.getCurrHyb2Name() != null)
                cValues.put("currHyb2Name", dto.getCurrHyb2Name());
            if (dto.getCurrHyb2Value() != null)
                cValues.put("currHyb2Value", dto.getCurrHyb2Value());
            if (dto.getCurrHyb3Name() != null)
                cValues.put("currHyb3Name", dto.getCurrHyb3Name());
            if (dto.getCurrHyb3Value() != null)
                cValues.put("currHyb3Value", dto.getCurrHyb3Value());
            if (dto.getCurrHyb4Name() != null)
                cValues.put("currHyb4Name", dto.getCurrHyb4Name());
            if (dto.getCurrHyb4Value() != null)
                cValues.put("currHyb4Value", dto.getCurrHyb4Value());
            if (dto.getCurrHyb5Name() != null)
                cValues.put("currHyb5Name", dto.getCurrHyb5Name());
            if (dto.getCurrHyb5Value() != null)
                cValues.put("currHyb5Value", dto.getCurrHyb5Value());
            if (dto.getTrainingPlant() != null)
                cValues.put("trainingPlant", dto.getTrainingPlant());
            if (dto.getTrainingGrow() != null)
                cValues.put("trainingGrow", dto.getTrainingGrow());
            if (dto.getTrainingHarvest() != null)
                cValues.put("trainingHarvest", dto.getTrainingHarvest());
            if (dto.getTrainingStore() != null)
                cValues.put("trainingStore", dto.getTrainingStore());
            if (dto.getTrainingFeed() != null)
                cValues.put("trainingFeed", dto.getTrainingFeed());


            dbObject.update("FARMER_SCHOOL_SILAGE", cValues, " id='" + dto.getId() + "' ", null);
            return true;
        } catch (SQLException e) {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM FARMER_SCHOOL_SILAGE ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    FarmerSchoolSilageDTO dto = new FarmerSchoolSilageDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));


                    dto.setDevCenterId(cursor.getLong(cursor.getColumnIndex("devCenterId")));
                    dto.setSchoolId(cursor.getLong(cursor.getColumnIndex("schoolId")));
                    dto.setTotalNoOfCattles(cursor.getInt(cursor.getColumnIndex("totalNoOfCattles")));
                    dto.setAvgMilkYield(cursor.getInt(cursor.getColumnIndex("avgMilkYield")));
                    dto.setSilageFeeding(cursor.getString(cursor.getColumnIndex("silageFeeding")));
                    dto.setGrowingOrProcuring(cursor.getString(cursor.getColumnIndex("growingOrProcuring")));
                    dto.setSilageAcres(cursor.getInt(cursor.getColumnIndex("silageAcres")));
                    dto.setCurrHyb1Name(cursor.getString(cursor.getColumnIndex("currHyb1Name")));
                    dto.setCurrHyb1Value(cursor.getString(cursor.getColumnIndex("currHyb1Value")));
                    dto.setCurrHyb2Name(cursor.getString(cursor.getColumnIndex("currHyb2Name")));
                    dto.setCurrHyb2Value(cursor.getString(cursor.getColumnIndex("currHyb2Value")));
                    dto.setCurrHyb3Name(cursor.getString(cursor.getColumnIndex("currHyb3Name")));
                    dto.setCurrHyb3Value(cursor.getString(cursor.getColumnIndex("currHyb3Value")));
                    dto.setCurrHyb4Name(cursor.getString(cursor.getColumnIndex("currHyb4Name")));
                    dto.setCurrHyb4Value(cursor.getString(cursor.getColumnIndex("currHyb4Value")));
                    dto.setCurrHyb5Name(cursor.getString(cursor.getColumnIndex("currHyb5Name")));
                    dto.setCurrHyb5Value(cursor.getString(cursor.getColumnIndex("currHyb5Value")));
                    dto.setTrainingPlant(cursor.getString(cursor.getColumnIndex("trainingPlant")));
                    dto.setTrainingGrow(cursor.getString(cursor.getColumnIndex("trainingGrow")));
                    dto.setTrainingHarvest(cursor.getString(cursor.getColumnIndex("trainingHarvest")));
                    dto.setTrainingStore(cursor.getString(cursor.getColumnIndex("trainingStore")));
                    dto.setTrainingFeed(cursor.getString(cursor.getColumnIndex("trainingFeed")));

                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    @Override

    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> getRecordsListByValue = new ArrayList<>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM FARMER_SCHOOL_SILAGE where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    FarmerSchoolSilageDTO dto = new FarmerSchoolSilageDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    dto.setDevCenterId(cursor.getLong(cursor.getColumnIndex("devCenterId")));
                    dto.setSchoolId(cursor.getLong(cursor.getColumnIndex("schoolId")));
                    dto.setTotalNoOfCattles(cursor.getInt(cursor.getColumnIndex("totalNoOfCattles")));
                    dto.setAvgMilkYield(cursor.getInt(cursor.getColumnIndex("avgMilkYield")));
                    dto.setSilageFeeding(cursor.getString(cursor.getColumnIndex("silageFeeding")));
                    dto.setGrowingOrProcuring(cursor.getString(cursor.getColumnIndex("growingOrProcuring")));
                    dto.setSilageAcres(cursor.getInt(cursor.getColumnIndex("silageAcres")));
                    dto.setCurrHyb1Name(cursor.getString(cursor.getColumnIndex("currHyb1Name")));
                    dto.setCurrHyb1Value(cursor.getString(cursor.getColumnIndex("currHyb1Value")));
                    dto.setCurrHyb2Name(cursor.getString(cursor.getColumnIndex("currHyb2Name")));
                    dto.setCurrHyb2Value(cursor.getString(cursor.getColumnIndex("currHyb2Value")));
                    dto.setCurrHyb3Name(cursor.getString(cursor.getColumnIndex("currHyb3Name")));
                    dto.setCurrHyb3Value(cursor.getString(cursor.getColumnIndex("currHyb3Value")));
                    dto.setCurrHyb4Name(cursor.getString(cursor.getColumnIndex("currHyb4Name")));
                    dto.setCurrHyb4Value(cursor.getString(cursor.getColumnIndex("currHyb4Value")));
                    dto.setCurrHyb5Name(cursor.getString(cursor.getColumnIndex("currHyb5Name")));
                    dto.setCurrHyb5Value(cursor.getString(cursor.getColumnIndex("currHyb5Value")));
                    dto.setTrainingPlant(cursor.getString(cursor.getColumnIndex("trainingPlant")));
                    dto.setTrainingGrow(cursor.getString(cursor.getColumnIndex("trainingGrow")));
                    dto.setTrainingHarvest(cursor.getString(cursor.getColumnIndex("trainingHarvest")));
                    dto.setTrainingStore(cursor.getString(cursor.getColumnIndex("trainingStore")));
                    dto.setTrainingFeed(cursor.getString(cursor.getColumnIndex("trainingFeed")));


                    getRecordsListByValue.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return getRecordsListByValue;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject : DTO object is passed
     * @param dbObject : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM FARMER_SCHOOL_SILAGE").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteTableData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("delete from FARMER_SCHOOL_SILAGE where id='" + id + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }


    public boolean deleteTableDataById(long id, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM FARMER_SCHOOL_SILAGE where id = '" + id + "'").execute();
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }


    public List<FarmerSchoolSilageDTO> getAllRecords(SQLiteDatabase dbObject) {
        List<FarmerSchoolSilageDTO> allRecordsList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM FARMER_SCHOOL_SILAGE", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    FarmerSchoolSilageDTO dto = new FarmerSchoolSilageDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    dto.setDevCenterId(cursor.getLong(cursor.getColumnIndex("devCenterId")));
                    dto.setSchoolId(cursor.getLong(cursor.getColumnIndex("schoolId")));
                    dto.setTotalNoOfCattles(cursor.getInt(cursor.getColumnIndex("totalNoOfCattles")));
                    dto.setAvgMilkYield(cursor.getInt(cursor.getColumnIndex("avgMilkYield")));
                    dto.setSilageFeeding(cursor.getString(cursor.getColumnIndex("silageFeeding")));
                    dto.setGrowingOrProcuring(cursor.getString(cursor.getColumnIndex("growingOrProcuring")));
                    dto.setSilageAcres(cursor.getInt(cursor.getColumnIndex("silageAcres")));
                    dto.setCurrHyb1Name(cursor.getString(cursor.getColumnIndex("currHyb1Name")));
                    dto.setCurrHyb1Value(cursor.getString(cursor.getColumnIndex("currHyb1Value")));
                    dto.setCurrHyb2Name(cursor.getString(cursor.getColumnIndex("currHyb2Name")));
                    dto.setCurrHyb2Value(cursor.getString(cursor.getColumnIndex("currHyb2Value")));
                    dto.setCurrHyb3Name(cursor.getString(cursor.getColumnIndex("currHyb3Name")));
                    dto.setCurrHyb3Value(cursor.getString(cursor.getColumnIndex("currHyb3Value")));
                    dto.setCurrHyb4Name(cursor.getString(cursor.getColumnIndex("currHyb4Name")));
                    dto.setCurrHyb4Value(cursor.getString(cursor.getColumnIndex("currHyb4Value")));
                    dto.setCurrHyb5Name(cursor.getString(cursor.getColumnIndex("currHyb5Name")));
                    dto.setCurrHyb5Value(cursor.getString(cursor.getColumnIndex("currHyb5Value")));
                    dto.setTrainingPlant(cursor.getString(cursor.getColumnIndex("trainingPlant")));
                    dto.setTrainingGrow(cursor.getString(cursor.getColumnIndex("trainingGrow")));
                    dto.setTrainingHarvest(cursor.getString(cursor.getColumnIndex("trainingHarvest")));
                    dto.setTrainingStore(cursor.getString(cursor.getColumnIndex("trainingStore")));
                    dto.setTrainingFeed(cursor.getString(cursor.getColumnIndex("trainingFeed")));

                    allRecordsList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return allRecordsList;
    }

    public List<DTO> getRecordsById(long id, SQLiteDatabase dbObject) {

        List<DTO> addSurveyInfo = new ArrayList<>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM FARMER_SCHOOL_SILAGE where id = '" + id + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    FarmerSchoolSilageDTO dto = new FarmerSchoolSilageDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    dto.setDevCenterId(cursor.getLong(cursor.getColumnIndex("devCenterId")));
                    dto.setSchoolId(cursor.getLong(cursor.getColumnIndex("schoolId")));
                    dto.setTotalNoOfCattles(cursor.getInt(cursor.getColumnIndex("totalNoOfCattles")));
                    dto.setAvgMilkYield(cursor.getInt(cursor.getColumnIndex("avgMilkYield")));
                    dto.setSilageFeeding(cursor.getString(cursor.getColumnIndex("silageFeeding")));
                    dto.setGrowingOrProcuring(cursor.getString(cursor.getColumnIndex("growingOrProcuring")));
                    dto.setSilageAcres(cursor.getInt(cursor.getColumnIndex("silageAcres")));
                    dto.setCurrHyb1Name(cursor.getString(cursor.getColumnIndex("currHyb1Name")));
                    dto.setCurrHyb1Value(cursor.getString(cursor.getColumnIndex("currHyb1Value")));
                    dto.setCurrHyb2Name(cursor.getString(cursor.getColumnIndex("currHyb2Name")));
                    dto.setCurrHyb2Value(cursor.getString(cursor.getColumnIndex("currHyb2Value")));
                    dto.setCurrHyb3Name(cursor.getString(cursor.getColumnIndex("currHyb3Name")));
                    dto.setCurrHyb3Value(cursor.getString(cursor.getColumnIndex("currHyb3Value")));
                    dto.setCurrHyb4Name(cursor.getString(cursor.getColumnIndex("currHyb4Name")));
                    dto.setCurrHyb4Value(cursor.getString(cursor.getColumnIndex("currHyb4Value")));
                    dto.setCurrHyb5Name(cursor.getString(cursor.getColumnIndex("currHyb5Name")));
                    dto.setCurrHyb5Value(cursor.getString(cursor.getColumnIndex("currHyb5Value")));
                    dto.setTrainingPlant(cursor.getString(cursor.getColumnIndex("trainingPlant")));
                    dto.setTrainingGrow(cursor.getString(cursor.getColumnIndex("trainingGrow")));
                    dto.setTrainingHarvest(cursor.getString(cursor.getColumnIndex("trainingHarvest")));
                    dto.setTrainingStore(cursor.getString(cursor.getColumnIndex("trainingStore")));
                    dto.setTrainingFeed(cursor.getString(cursor.getColumnIndex("trainingFeed")));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    public List<FarmerSchoolSilageDTO> getRecordsForUpload(Context context, SQLiteDatabase dbObject) {
        List<FarmerSchoolSilageDTO> farmerSegmentationList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM FARMER_SCHOOL_SILAGE where isSync = 1", null);
            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                do {
                    FarmerSchoolSilageDTO dto = new FarmerSchoolSilageDTO();


                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    dto.setDevCenterId(cursor.getLong(cursor.getColumnIndex("devCenterId")));
                    dto.setSchoolId(cursor.getLong(cursor.getColumnIndex("schoolId")));
                    dto.setTotalNoOfCattles(cursor.getInt(cursor.getColumnIndex("totalNoOfCattles")));
                    dto.setAvgMilkYield(cursor.getInt(cursor.getColumnIndex("avgMilkYield")));
                    dto.setSilageFeeding(cursor.getString(cursor.getColumnIndex("silageFeeding")));
                    dto.setGrowingOrProcuring(cursor.getString(cursor.getColumnIndex("growingOrProcuring")));
                    dto.setSilageAcres(cursor.getInt(cursor.getColumnIndex("silageAcres")));
                    dto.setCurrHyb1Name(cursor.getString(cursor.getColumnIndex("currHyb1Name")));
                    dto.setCurrHyb1Value(cursor.getString(cursor.getColumnIndex("currHyb1Value")));
                    dto.setCurrHyb2Name(cursor.getString(cursor.getColumnIndex("currHyb2Name")));
                    dto.setCurrHyb2Value(cursor.getString(cursor.getColumnIndex("currHyb2Value")));
                    dto.setCurrHyb3Name(cursor.getString(cursor.getColumnIndex("currHyb3Name")));
                    dto.setCurrHyb3Value(cursor.getString(cursor.getColumnIndex("currHyb3Value")));
                    dto.setCurrHyb4Name(cursor.getString(cursor.getColumnIndex("currHyb4Name")));
                    dto.setCurrHyb4Value(cursor.getString(cursor.getColumnIndex("currHyb4Value")));
                    dto.setCurrHyb5Name(cursor.getString(cursor.getColumnIndex("currHyb5Name")));
                    dto.setCurrHyb5Value(cursor.getString(cursor.getColumnIndex("currHyb5Value")));
                    dto.setTrainingPlant(cursor.getString(cursor.getColumnIndex("trainingPlant")));
                    dto.setTrainingGrow(cursor.getString(cursor.getColumnIndex("trainingGrow")));
                    dto.setTrainingHarvest(cursor.getString(cursor.getColumnIndex("trainingHarvest")));
                    dto.setTrainingStore(cursor.getString(cursor.getColumnIndex("trainingStore")));
                    dto.setTrainingFeed(cursor.getString(cursor.getColumnIndex("trainingFeed")));

                    farmerSegmentationList.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return farmerSegmentationList;
    }


    public List<FarmerSchoolSilageDTO> getRecordByList(SQLiteDatabase dbObject) {
        List<FarmerSchoolSilageDTO> pdaActivityInfo = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM FARMER_SCHOOL_SILAGE ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    FarmerSchoolSilageDTO dto = new FarmerSchoolSilageDTO();

                    dto.setMobileId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setYear(cursor.getString(cursor.getColumnIndex("year")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setPincode(cursor.getString(cursor.getColumnIndex("pincode")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setDistrict(cursor.getString(cursor.getColumnIndex("district")));
                    dto.setVillage(cursor.getString(cursor.getColumnIndex("village")));
                    dto.setBlock(cursor.getString(cursor.getColumnIndex("block")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setDate(cursor.getString(cursor.getColumnIndex("timeStamp")));
                    dto.setIsSync(cursor.getInt(cursor.getColumnIndex("isSync")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));

                    dto.setDevCenterId(cursor.getLong(cursor.getColumnIndex("devCenterId")));
                    dto.setSchoolId(cursor.getLong(cursor.getColumnIndex("schoolId")));
                    dto.setTotalNoOfCattles(cursor.getInt(cursor.getColumnIndex("totalNoOfCattles")));
                    dto.setAvgMilkYield(cursor.getInt(cursor.getColumnIndex("avgMilkYield")));
                    dto.setSilageFeeding(cursor.getString(cursor.getColumnIndex("silageFeeding")));
                    dto.setGrowingOrProcuring(cursor.getString(cursor.getColumnIndex("growingOrProcuring")));
                    dto.setSilageAcres(cursor.getInt(cursor.getColumnIndex("silageAcres")));
                    dto.setCurrHyb1Name(cursor.getString(cursor.getColumnIndex("currHyb1Name")));
                    dto.setCurrHyb1Value(cursor.getString(cursor.getColumnIndex("currHyb1Value")));
                    dto.setCurrHyb2Name(cursor.getString(cursor.getColumnIndex("currHyb2Name")));
                    dto.setCurrHyb2Value(cursor.getString(cursor.getColumnIndex("currHyb2Value")));
                    dto.setCurrHyb3Name(cursor.getString(cursor.getColumnIndex("currHyb3Name")));
                    dto.setCurrHyb3Value(cursor.getString(cursor.getColumnIndex("currHyb3Value")));
                    dto.setCurrHyb4Name(cursor.getString(cursor.getColumnIndex("currHyb4Name")));
                    dto.setCurrHyb4Value(cursor.getString(cursor.getColumnIndex("currHyb4Value")));
                    dto.setCurrHyb5Name(cursor.getString(cursor.getColumnIndex("currHyb5Name")));
                    dto.setCurrHyb5Value(cursor.getString(cursor.getColumnIndex("currHyb5Value")));
                    dto.setTrainingPlant(cursor.getString(cursor.getColumnIndex("trainingPlant")));
                    dto.setTrainingGrow(cursor.getString(cursor.getColumnIndex("trainingGrow")));
                    dto.setTrainingHarvest(cursor.getString(cursor.getColumnIndex("trainingHarvest")));
                    dto.setTrainingStore(cursor.getString(cursor.getColumnIndex("trainingStore")));
                    dto.setTrainingFeed(cursor.getString(cursor.getColumnIndex("trainingFeed")));



                    pdaActivityInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return pdaActivityInfo;
    }

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject) {
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT count(id) FROM FARMER_SCHOOL_SILAGE where isSync = 1", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e) {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return false;
    }
}