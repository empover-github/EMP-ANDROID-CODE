package com.activitytrack.activity;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.activitytrack.utility.FragmentIntentIntegrator;

public class TestFragment extends BaseFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FragmentIntentIntegrator integrator = new FragmentIntentIntegrator(this);
        integrator.setPrompt("Scan a barcode");
        integrator.setCameraId(0);  // Use a specific camera of the device
        integrator.setOrientationLocked(true);
        integrator.setBeepEnabled(true);
        integrator.setCaptureActivity(ATCaptureActivityPortrait.class);
        integrator.initiateScan();
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public boolean onBackPressed(int callbackCode) {
        return false;
    }
}
