package com.activitytrack.daos;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.NewMdrSurveyDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class NewMdrSurveyDAO implements DAO {
    private final String TAG = "NewVillageSurvey";
    private static NewMdrSurveyDAO mdrSurveyDAO;

    public static NewMdrSurveyDAO getInstance() {
        if (mdrSurveyDAO == null) {
            mdrSurveyDAO = new NewMdrSurveyDAO();
        }

        return mdrSurveyDAO;
    }

    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            NewMdrSurveyDTO dto = (NewMdrSurveyDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            cValues.put("localImagePath", dto.getLocalImagePath());
            cValues.put("geoLocation", dto.getGeoLocation());
            cValues.put("farmerName", dto.getFarmerName());
            cValues.put("mobileNo", dto.getMobileNo());
            cValues.put("noOfFamilies", dto.getNoOfFamilies());
            cValues.put("totalLand", dto.getTotalLand());
            cValues.put("majorCompany1", dto.getMajorCompany1());
            cValues.put("majorCompany1Acreage", dto.getMajorCompany1Acreage());
            cValues.put("majorCompany2", dto.getMajorCompany2());
            cValues.put("majorCompany2Acreage", dto.getMajorCompany2Acreage());
            cValues.put("majorCompany3", dto.getMajorCompany3());
            cValues.put("majorCompany3Acreage", dto.getMajorCompany3Acreage());
            cValues.put("majorCompany4", dto.getMajorCompany4());
            cValues.put("majorCompany4Acreage", dto.getMajorCompany4Acreage());
            cValues.put("majorCompany5", dto.getMajorCompany5());
            cValues.put("majorCompany5Acreage", dto.getMajorCompany5Acreage());
            cValues.put("otherCompanyAcreage", dto.getOtherCompanyAcreage());
            cValues.put("segmentTypeUpland", dto.getSegmentTypeUpland());
            cValues.put("segmentTypeMidland", dto.getSegmentTypeMidland());
            cValues.put("segmentTypeMidLowland", dto.getSegmentTypeMidLowland());
            cValues.put("segmentTypeFineRice", dto.getSegmentTypeFineRice());
            cValues.put("segmentTypeLowland", dto.getSegmentTypeLowland());
            cValues.put("pioneerHybridType1Acres", dto.getPioneerHybridType1Acres());
            cValues.put("pioneerHybridType2Acres", dto.getPioneerHybridType2Acres());
            cValues.put("pioneerHybridType3Acres", dto.getPioneerHybridType3Acres());
            cValues.put("pioneerHybrid1", dto.getPioneerHybrid1());
            cValues.put("pioneerHybrid1Acres", dto.getPioneerHybrid1Acres());
            cValues.put("pioneerHybrid2", dto.getPioneerHybrid2());
            cValues.put("pioneerHybrid2Acres", dto.getPioneerHybrid2Acres());
           /* cValues.put("cropId", dto.getCropId());
            cValues.put("blockName", dto.getBlockName());
            cValues.put("pinCode", dto.getPinCode());
            cValues.put("retailerMobileNumber", dto.getRetailerMobileNumber());
            cValues.put("isPDAVillage", dto.getIsPDAVillage());
            cValues.put("villageName", dto.getVillageName());
            cValues.put("segment", dto.getSegment());*/
            cValues.put("date", dto.getDate());
            cValues.put("activityId", dto.getActivityId());
            cValues.put("totalResearchAcres", dto.getTotalResearchAcres());
            cValues.put("majorResearchCompanyName", dto.getMajorResearchCompanyName());

            dbObject.insert("ADD_MDR_NEW_SURVEY", null, cValues);
            return true;
        } catch (SQLException e) {
            return false;
        } finally {
            dbObject.close();
        }
    }

    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject) {
        try {
            NewMdrSurveyDTO dto = (NewMdrSurveyDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            if (dto.getLocalImagePath() != null)
                cValues.put("localImagePath", dto.getLocalImagePath());

            if (dto.getGeoLocation() != null)
                cValues.put("latlong", dto.getGeoLocation());

            if (dto.getFarmerName() != null)
                cValues.put("farmerName", dto.getFarmerName());

            if (dto.getMobileNo() != null)
                cValues.put("mobileNo", dto.getMobileNo());

            if (dto.getNoOfFamilies() != 0)
                cValues.put("noOfFamilies", dto.getNoOfFamilies());

            if (dto.getTotalLand() != 0)
                cValues.put("totalLand", dto.getTotalLand());

            if (dto.getMajorCompany1() != 0) {
                cValues.put("majorCompany1", dto.getMajorCompany1());
            }

            if (dto.getMajorCompany1Acreage() != 0) {
                cValues.put("majorCompany1Acreage", dto.getMajorCompany1Acreage());
            }

            if (dto.getMajorCompany2() != 0) {
                cValues.put("majorCompany2", dto.getMajorCompany2());
            }

            if (dto.getMajorCompany2Acreage() != 0) {
                cValues.put("majorCompany2Acreage", dto.getMajorCompany2Acreage());
            }

            if (dto.getMajorCompany3() != 0) {
                cValues.put("majorCompany3", dto.getMajorCompany3());
            }

            if (dto.getMajorCompany3Acreage() != 0) {
                cValues.put("majorCompany3Acreage", dto.getMajorCompany3Acreage());
            }

            if (dto.getMajorCompany4() != 0) {
                cValues.put("majorCompany4", dto.getMajorCompany4());
            }

            if (dto.getMajorCompany4Acreage() != 0) {
                cValues.put("majorCompany4Acreage", dto.getMajorCompany4Acreage());
            }

            if (dto.getMajorCompany5() != 0) {
                cValues.put("majorCompany5", dto.getMajorCompany5());
            }

            if (dto.getMajorCompany5Acreage() != 0) {
                cValues.put("majorCompany5Acreage", dto.getMajorCompany5Acreage());
            }

            if (dto.getOtherCompanyAcreage() != 0) {
                cValues.put("otherCompanyAcreage", dto.getOtherCompanyAcreage());
            }

            if (dto.getSegmentTypeUpland() != 0) {
                cValues.put("segmentTypeUpland", dto.getSegmentTypeUpland());
            }

            if (dto.getSegmentTypeMidland() != 0) {
                cValues.put("segmentTypeMidland", dto.getSegmentTypeMidland());
            }

            if (dto.getSegmentTypeMidLowland() != 0) {
                cValues.put("segmentTypeMidLowland", dto.getSegmentTypeMidLowland());
            }

            if (dto.getSegmentTypeFineRice() != 0) {
                cValues.put("segmentTypeFineRice", dto.getSegmentTypeFineRice());
            }

            if (dto.getSegmentTypeLowland() != 0) {
                cValues.put("segmentTypeLowland", dto.getSegmentTypeLowland());
            }

            if (dto.getPioneerHybridType1Acres() != 0) {
                cValues.put("pioneerHybridType1Acres", dto.getPioneerHybridType1Acres());
            }

            if (dto.getPioneerHybridType2Acres() != 0) {
                cValues.put("pioneerHybridType2Acres", dto.getPioneerHybridType2Acres());
            }

            if (dto.getPioneerHybridType3Acres() != 0) {
                cValues.put("pioneerHybridType3Acres", dto.getPioneerHybridType3Acres());
            }

            if (dto.getPioneerHybrid1() != 0) {
                cValues.put("pioneerHybrid1", dto.getPioneerHybrid1());
            }

            if (dto.getPioneerHybrid1Acres() != 0) {
                cValues.put("pioneerHybrid1Acres", dto.getPioneerHybrid1Acres());
            }

            if (dto.getPioneerHybrid2() != 0) {
                cValues.put("pioneerHybrid2", dto.getPioneerHybrid2());
            }

            if (dto.getPioneerHybrid2Acres() != 0) {
                cValues.put("pioneerHybrid2Acres", dto.getPioneerHybrid2Acres());
            }

          /*  if (dto.getCropId() != 0) {
                cValues.put("cropId", dto.getCropId());
            }

            if (dto.getBlockName() != null) {
                cValues.put("blockName", dto.getBlockName());
            }

            if (dto.getPinCode() != null) {
                cValues.put("pinCode", dto.getPinCode());
            }

            if (dto.getRetailerMobileNumber() != 0) {
                cValues.put("retailerMobileNumber", dto.getRetailerMobileNumber());
            }

            if (dto.getIsPDAVillage() != null) {
                cValues.put("isPDAVillage", dto.getIsPDAVillage());
            }

            if (dto.getSegment() != null) {
                cValues.put("segment", dto.getSegment());
            }

            if (dto.getVillageName() != null) {
                cValues.put("villageName", dto.getVillageName());
            }*/

            if (dto.getDate() != null) {
                cValues.put("date", dto.getDate());
            }

            if (dto.getActivityId() != 0) {
                cValues.put("activityId", dto.getActivityId());
            }
            if (dto.getTotalResearchAcres() != 0) {
                cValues.put("totalResearchAcres", dto.getTotalResearchAcres());

            }
            if (dto.getMajorResearchCompanyName() != 0) {
                cValues.put("majorResearchCompanyName", dto.getMajorResearchCompanyName());
            }


            dbObject.update("ADD_MDR_NEW_SURVEY", cValues, "id='" + dto.getId() + "' ", null);

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            dbObject.close();
        }
        return false;
    }

    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject) {
        return false;
    }

    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject) {
        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_NEW_SURVEY", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {

                    NewMdrSurveyDTO dto = new NewMdrSurveyDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setNoOfFamilies(cursor.getLong(cursor.getColumnIndex("noOfFamilies")));
                    dto.setTotalLand(cursor.getLong(cursor.getColumnIndex("totalLand")));
                    dto.setMajorCompany1(cursor.getLong(cursor.getColumnIndex("majorCompany1")));
                    dto.setMajorCompany1Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany1Acreage")));
                    dto.setMajorCompany2(cursor.getLong(cursor.getColumnIndex("majorCompany2")));
                    dto.setMajorCompany2Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany2Acreage")));
                    dto.setMajorCompany3(cursor.getLong(cursor.getColumnIndex("majorCompany3")));
                    dto.setMajorCompany3Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany3Acreage")));
                    dto.setMajorCompany4(cursor.getLong(cursor.getColumnIndex("majorCompany4")));
                    dto.setMajorCompany4Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany4Acreage")));
                    dto.setMajorCompany5(cursor.getLong(cursor.getColumnIndex("majorCompany5")));
                    dto.setMajorCompany5Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany5Acreage")));
                    dto.setOtherCompanyAcreage(cursor.getLong(cursor.getColumnIndex("otherCompanyAcreage")));
                    dto.setSegmentTypeUpland(cursor.getLong(cursor.getColumnIndex("segmentTypeUpland")));
                    dto.setSegmentTypeMidland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidland")));
                    dto.setSegmentTypeMidLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidLowland")));
                    dto.setSegmentTypeFineRice(cursor.getLong(cursor.getColumnIndex("segmentTypeFineRice")));
                    dto.setSegmentTypeLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeLowland")));
                    dto.setPioneerHybridType1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType1Acres")));
                    dto.setPioneerHybridType2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType2Acres")));
                    dto.setPioneerHybridType3Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType3Acres")));
                    dto.setPioneerHybrid1(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1")));
                    dto.setPioneerHybrid1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1Acres")));
                    dto.setPioneerHybrid2(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2")));
                    dto.setPioneerHybrid2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2Acres")));
                  /*  dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setPinCode(cursor.getString(cursor.getColumnIndex("pinCode")));
                    dto.setRetailerMobileNumber(cursor.getLong(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setIsPDAVillage(cursor.getString(cursor.getColumnIndex("isPDAVillage")));
                    dto.setSegment(cursor.getString(cursor.getColumnIndex("segment")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));*/
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setActivityId(cursor.getLong(cursor.getColumnIndex("activityId")));
                    dto.setTotalResearchAcres(cursor.getLong(cursor.getColumnIndex("totalResearchAcres")));
                    dto.setMajorResearchCompanyName(cursor.getLong(cursor.getColumnIndex("majorResearchCompanyName")));


                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject) {
        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {
            if (!(columnName != null && columnName.length() > 0))
                columnName = "id";

            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_NEW_SURVEY where " + columnName + "='" + columnValue + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                do {
                    NewMdrSurveyDTO dto = new NewMdrSurveyDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setNoOfFamilies(cursor.getLong(cursor.getColumnIndex("noOfFamilies")));
                    dto.setTotalLand(cursor.getLong(cursor.getColumnIndex("totalLand")));
                    dto.setMajorCompany1(cursor.getLong(cursor.getColumnIndex("majorCompany1")));
                    dto.setMajorCompany1Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany1Acreage")));
                    dto.setMajorCompany2(cursor.getLong(cursor.getColumnIndex("majorCompany2")));
                    dto.setMajorCompany2Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany2Acreage")));
                    dto.setMajorCompany3(cursor.getLong(cursor.getColumnIndex("majorCompany3")));
                    dto.setMajorCompany3Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany3Acreage")));
                    dto.setMajorCompany4(cursor.getLong(cursor.getColumnIndex("majorCompany4")));
                    dto.setMajorCompany4Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany4Acreage")));
                    dto.setMajorCompany5(cursor.getLong(cursor.getColumnIndex("majorCompany5")));
                    dto.setMajorCompany5Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany5Acreage")));
                    dto.setOtherCompanyAcreage(cursor.getLong(cursor.getColumnIndex("otherCompanyAcreage")));
                    dto.setSegmentTypeUpland(cursor.getLong(cursor.getColumnIndex("segmentTypeUpland")));
                    dto.setSegmentTypeMidland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidland")));
                    dto.setSegmentTypeMidLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidLowland")));
                    dto.setSegmentTypeFineRice(cursor.getLong(cursor.getColumnIndex("segmentTypeFineRice")));
                    dto.setSegmentTypeLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeLowland")));
                    dto.setPioneerHybridType1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType1Acres")));
                    dto.setPioneerHybridType2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType2Acres")));
                    dto.setPioneerHybridType3Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType3Acres")));
                    dto.setPioneerHybrid1(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1")));
                    dto.setPioneerHybrid1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1Acres")));
                    dto.setPioneerHybrid2(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2")));
                    dto.setPioneerHybrid2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2Acres")));
                   /* dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setPinCode(cursor.getString(cursor.getColumnIndex("pinCode")));
                    dto.setRetailerMobileNumber(cursor.getLong(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setIsPDAVillage(cursor.getString(cursor.getColumnIndex("isPDAVillage")));
                    dto.setSegment(cursor.getString(cursor.getColumnIndex("segment")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));*/
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setActivityId(cursor.getLong(cursor.getColumnIndex("activityId")));
                    dto.setTotalResearchAcres(cursor.getLong(cursor.getColumnIndex("totalResearchAcres")));
                    dto.setMajorResearchCompanyName(cursor.getLong(cursor.getColumnIndex("majorResearchCompanyName")));

                    addSurveyInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }

    @SuppressLint("LongLogTag")
    public boolean deleteTableData(SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM ADD_MDR_NEW_SURVEY").execute();
            return true;
        } catch (Exception e) {
            Log.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    @SuppressLint("LongLogTag")
    public boolean deleteTableDataById(long activityId, SQLiteDatabase dbObject) {
        try {
            dbObject.compileStatement("DELETE FROM ADD_MDR_NEW_SURVEY where activityId = '" + activityId + "'").execute();
            return true;
        } catch (Exception e) {
            Log.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String activityId, SQLiteDatabase dbObject) {
        try {
            dbObject.execSQL("DELETE FROM ADD_MDR_NEW_SURVEY where activityId = '" + activityId + "'");
            return true;
        } catch (Exception e) {
            ATBuildLog.e(TAG + "delete", e.getMessage());
        } finally

        {

            dbObject.close();

        }
        return false;
    }

    @SuppressLint("LongLogTag")
    public List<DTO> getRecordInfoById(long activityId, SQLiteDatabase dbObject) {

        List<DTO> addSurveyInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_NEW_SURVEY where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    NewMdrSurveyDTO dto = new NewMdrSurveyDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setNoOfFamilies(cursor.getLong(cursor.getColumnIndex("noOfFamilies")));
                    dto.setTotalLand(cursor.getLong(cursor.getColumnIndex("totalLand")));
                    dto.setMajorCompany1(cursor.getLong(cursor.getColumnIndex("majorCompany1")));
                    dto.setMajorCompany1Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany1Acreage")));
                    dto.setMajorCompany2(cursor.getLong(cursor.getColumnIndex("majorCompany2")));
                    dto.setMajorCompany2Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany2Acreage")));
                    dto.setMajorCompany3(cursor.getLong(cursor.getColumnIndex("majorCompany3")));
                    dto.setMajorCompany3Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany3Acreage")));
                    dto.setMajorCompany4(cursor.getLong(cursor.getColumnIndex("majorCompany4")));
                    dto.setMajorCompany4Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany4Acreage")));
                    dto.setMajorCompany5(cursor.getLong(cursor.getColumnIndex("majorCompany5")));
                    dto.setMajorCompany5Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany5Acreage")));
                    dto.setOtherCompanyAcreage(cursor.getLong(cursor.getColumnIndex("otherCompanyAcreage")));
                    dto.setSegmentTypeUpland(cursor.getLong(cursor.getColumnIndex("segmentTypeUpland")));
                    dto.setSegmentTypeMidland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidland")));
                    dto.setSegmentTypeMidLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidLowland")));
                    dto.setSegmentTypeFineRice(cursor.getLong(cursor.getColumnIndex("segmentTypeFineRice")));
                    dto.setSegmentTypeLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeLowland")));
                    dto.setPioneerHybridType1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType1Acres")));
                    dto.setPioneerHybridType2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType2Acres")));
                    dto.setPioneerHybridType3Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType3Acres")));
                    dto.setPioneerHybrid1(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1")));
                    dto.setPioneerHybrid1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1Acres")));
                    dto.setPioneerHybrid2(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2")));
                    dto.setPioneerHybrid2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2Acres")));
                   /* dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setPinCode(cursor.getString(cursor.getColumnIndex("pinCode")));
                    dto.setRetailerMobileNumber(cursor.getLong(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setIsPDAVillage(cursor.getString(cursor.getColumnIndex("isPDAVillage")));
                    dto.setSegment(cursor.getString(cursor.getColumnIndex("segment")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));*/
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setActivityId(cursor.getLong(cursor.getColumnIndex("activityId")));
                    dto.setTotalResearchAcres(cursor.getLong(cursor.getColumnIndex("totalResearchAcres")));
                    dto.setMajorResearchCompanyName(cursor.getLong(cursor.getColumnIndex("majorResearchCompanyName")));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }


    @SuppressLint("LongLogTag")
    public List<NewMdrSurveyDTO> getRecordsForUpload(long activityId, SQLiteDatabase dbObject) {

        List<NewMdrSurveyDTO> addSurveyInfo = new ArrayList<NewMdrSurveyDTO>();
        Cursor cursor = null;
        try {
            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_NEW_SURVEY where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    NewMdrSurveyDTO dto = new NewMdrSurveyDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setNoOfFamilies(cursor.getLong(cursor.getColumnIndex("noOfFamilies")));
                    dto.setTotalLand(cursor.getLong(cursor.getColumnIndex("totalLand")));
                    dto.setMajorCompany1(cursor.getLong(cursor.getColumnIndex("majorCompany1")));
                    dto.setMajorCompany1Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany1Acreage")));
                    dto.setMajorCompany2(cursor.getLong(cursor.getColumnIndex("majorCompany2")));
                    dto.setMajorCompany2Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany2Acreage")));
                    dto.setMajorCompany3(cursor.getLong(cursor.getColumnIndex("majorCompany3")));
                    dto.setMajorCompany3Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany3Acreage")));
                    dto.setMajorCompany4(cursor.getLong(cursor.getColumnIndex("majorCompany4")));
                    dto.setMajorCompany4Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany4Acreage")));
                    dto.setMajorCompany5(cursor.getLong(cursor.getColumnIndex("majorCompany5")));
                    dto.setMajorCompany5Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany5Acreage")));
                    dto.setOtherCompanyAcreage(cursor.getLong(cursor.getColumnIndex("otherCompanyAcreage")));
                    dto.setSegmentTypeUpland(cursor.getLong(cursor.getColumnIndex("segmentTypeUpland")));
                    dto.setSegmentTypeMidland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidland")));
                    dto.setSegmentTypeMidLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidLowland")));
                    dto.setSegmentTypeFineRice(cursor.getLong(cursor.getColumnIndex("segmentTypeFineRice")));
                    dto.setSegmentTypeLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeLowland")));
                    dto.setPioneerHybridType1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType1Acres")));
                    dto.setPioneerHybridType2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType2Acres")));
                    dto.setPioneerHybridType3Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType3Acres")));
                    dto.setPioneerHybrid1(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1")));
                    dto.setPioneerHybrid1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1Acres")));
                    dto.setPioneerHybrid2(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2")));
                    dto.setPioneerHybrid2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2Acres")));
                  /*  dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setPinCode(cursor.getString(cursor.getColumnIndex("pinCode")));
                    dto.setRetailerMobileNumber(cursor.getLong(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setIsPDAVillage(cursor.getString(cursor.getColumnIndex("isPDAVillage")));
                    dto.setSegment(cursor.getString(cursor.getColumnIndex("segment")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));*/
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setActivityId(cursor.getLong(cursor.getColumnIndex("activityId")));
                    dto.setTotalResearchAcres(cursor.getLong(cursor.getColumnIndex("totalResearchAcres")));
                    dto.setMajorResearchCompanyName(cursor.getLong(cursor.getColumnIndex("majorResearchCompanyName")));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }

            dbObject.close();
        }

        return addSurveyInfo;
    }


    @SuppressLint("LongLogTag")
    public List<NewMdrSurveyDTO> getRecordInfoByView(long activityId, SQLiteDatabase dbObject) {

        List<NewMdrSurveyDTO> addSurveyInfo = new ArrayList<NewMdrSurveyDTO>();
        Cursor cursor = null;
        try {

            cursor = dbObject.rawQuery("SELECT * FROM ADD_MDR_NEW_SURVEY where activityId = '" + activityId + "' ", null);
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                do {
                    NewMdrSurveyDTO dto = new NewMdrSurveyDTO();

                    dto.setId(cursor.getLong(cursor.getColumnIndex("id")));
                    dto.setLocalImagePath(cursor.getString(cursor.getColumnIndex("localImagePath")));
                    dto.setGeoLocation(cursor.getString(cursor.getColumnIndex("geoLocation")));
                    dto.setFarmerName(cursor.getString(cursor.getColumnIndex("farmerName")));
                    dto.setMobileNo(cursor.getString(cursor.getColumnIndex("mobileNo")));
                    dto.setNoOfFamilies(cursor.getLong(cursor.getColumnIndex("noOfFamilies")));
                    dto.setTotalLand(cursor.getLong(cursor.getColumnIndex("totalLand")));
                    dto.setMajorCompany1(cursor.getLong(cursor.getColumnIndex("majorCompany1")));
                    dto.setMajorCompany1Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany1Acreage")));
                    dto.setMajorCompany2(cursor.getLong(cursor.getColumnIndex("majorCompany2")));
                    dto.setMajorCompany2Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany2Acreage")));
                    dto.setMajorCompany3(cursor.getLong(cursor.getColumnIndex("majorCompany3")));
                    dto.setMajorCompany3Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany3Acreage")));
                    dto.setMajorCompany4(cursor.getLong(cursor.getColumnIndex("majorCompany4")));
                    dto.setMajorCompany4Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany4Acreage")));
                    dto.setMajorCompany5(cursor.getLong(cursor.getColumnIndex("majorCompany5")));
                    dto.setMajorCompany5Acreage(cursor.getLong(cursor.getColumnIndex("majorCompany5Acreage")));
                    dto.setOtherCompanyAcreage(cursor.getLong(cursor.getColumnIndex("otherCompanyAcreage")));
                    dto.setSegmentTypeUpland(cursor.getLong(cursor.getColumnIndex("segmentTypeUpland")));
                    dto.setSegmentTypeMidland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidland")));
                    dto.setSegmentTypeMidLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeMidLowland")));
                    dto.setSegmentTypeFineRice(cursor.getLong(cursor.getColumnIndex("segmentTypeFineRice")));
                    dto.setSegmentTypeLowland(cursor.getLong(cursor.getColumnIndex("segmentTypeLowland")));
                    dto.setPioneerHybridType1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType1Acres")));
                    dto.setPioneerHybridType2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType2Acres")));
                    dto.setPioneerHybridType3Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybridType3Acres")));
                    dto.setPioneerHybrid1(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1")));
                    dto.setPioneerHybrid1Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid1Acres")));
                    dto.setPioneerHybrid2(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2")));
                    dto.setPioneerHybrid2Acres(cursor.getLong(cursor.getColumnIndex("pioneerHybrid2Acres")));
                   /* dto.setCropId(cursor.getLong(cursor.getColumnIndex("cropId")));
                    dto.setBlockName(cursor.getString(cursor.getColumnIndex("blockName")));
                    dto.setPinCode(cursor.getString(cursor.getColumnIndex("pinCode")));
                    dto.setRetailerMobileNumber(cursor.getLong(cursor.getColumnIndex("retailerMobileNumber")));
                    dto.setIsPDAVillage(cursor.getString(cursor.getColumnIndex("isPDAVillage")));
                    dto.setSegment(cursor.getString(cursor.getColumnIndex("segment")));
                    dto.setVillageName(cursor.getString(cursor.getColumnIndex("villageName")));*/
                    dto.setDate(cursor.getString(cursor.getColumnIndex("date")));
                    dto.setActivityId(cursor.getLong(cursor.getColumnIndex("activityId")));
                    dto.setTotalResearchAcres(cursor.getLong(cursor.getColumnIndex("totalResearchAcres")));
                    dto.setMajorResearchCompanyName(cursor.getLong(cursor.getColumnIndex("majorResearchCompanyName")));

                    addSurveyInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG + "getRecords()", e.getMessage());
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            dbObject.close();
        }

        return addSurveyInfo;
    }


    public boolean isSurveyExist(long activityId,String mobileNo, SQLiteDatabase readableDb) {
        Cursor cursor = null;
        try {
            cursor = readableDb.rawQuery("SELECT * FROM ADD_MDR_NEW_SURVEY where activityId = '" + activityId + "' and mobileNo = '" + mobileNo + "' ", null);
            return cursor.getCount() > 0;
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
            readableDb.close();
        }
        return false;
    }
}
