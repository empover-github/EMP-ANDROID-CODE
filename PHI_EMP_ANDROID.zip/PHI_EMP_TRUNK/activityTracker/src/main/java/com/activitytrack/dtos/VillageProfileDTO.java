package com.activitytrack.dtos;

import java.util.List;

public class VillageProfileDTO implements DTO {
    private String villageName;
    private String pinCode;
    private String blockName;
    private long cropId;
    private String cropName;
    private long segment;
    private String segmentName;
    private String date;
    private String location;
    private long regionId;
    private int isSync;
    private String uploadedDate;
    private long mobileId;

    private List<MdrFarmerDTO> farmers;
    private List<MdrSurveyDTO> surveys;
    private List<NewMdrSurveyDTO> surveysNew;

    // newly added
    private String isPDAVillage;
    private String retailerMobileNumber;

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public long getSegment() {
        return segment;
    }

    public void setSegment(long segment) {
        this.segment = segment;
    }

    public String getSegmentName() {
        return segmentName;
    }

    public void setSegmentName(String segmentName) {
        this.segmentName = segmentName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public long getRegionId() {
        return regionId;
    }

    public void setRegionId(long regionId) {
        this.regionId = regionId;
    }

    public int getIsSync() {
        return isSync;
    }

    public void setIsSync(int isSync) {
        this.isSync = isSync;
    }

    public String getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(String uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public List<MdrFarmerDTO> getFarmers() {
        return farmers;
    }

    public void setFarmers(List<MdrFarmerDTO> farmers) {
        this.farmers = farmers;
    }


    public long getId() {
        return mobileId;
    }

    public void setId(long mobileid) {

        this.mobileId = mobileid;
    }

    public String getIsPDAVillage() {
        return isPDAVillage;
    }

    public void setIsPDAVillage(String isPDAVillage) {
        this.isPDAVillage = isPDAVillage;
    }

    public String getRetailerMobileNumber() {
        return retailerMobileNumber;
    }

    public void setRetailerMobileNumber(String retailerMobileNumber) {
        this.retailerMobileNumber = retailerMobileNumber;
    }

    public List<MdrSurveyDTO> getSurveys() {
        return surveys;
    }

    public void setSurveys(List<MdrSurveyDTO> surveys) {
        this.surveys = surveys;
    }

    public List<NewMdrSurveyDTO> getSurveysNew() {
        return surveysNew;
    }

    public void setSurveysNew(List<NewMdrSurveyDTO> surveysNew) {
        this.surveysNew = surveysNew;
    }
}
