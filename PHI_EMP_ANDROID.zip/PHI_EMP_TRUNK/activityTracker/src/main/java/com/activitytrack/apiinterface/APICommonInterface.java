package com.activitytrack.apiinterface;


import com.activitytrack.dtos.FarmerSegmentationNestleResponse;
import com.activitytrack.dtos.FarmerSegmentationRequestDTO;
import com.activitytrack.dtos.FarmerSegmentationResponse;
import com.activitytrack.dtos.OTPFarmerSegmentationResponse;
import com.activitytrack.dtos.OTP_FS_Response;
import com.activitytrack.masterdtos.UploadResponse;
import com.activitytrack.masterdtos.UploadedVillageListRefreshRes;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.Multipart;
import retrofit.http.POST;
import retrofit.http.Part;
import retrofit.mime.TypedFile;

public interface APICommonInterface {

    @Multipart
    @POST("/datasync/uploadImageInPravaktaVillageHaGainInActivityTracker")
    void uploadImage(@Part("serverId") String serverId,
                     @Part("mobileId") String mobileId,
                     @Part("type") String type,
                     @Part("photo") TypedFile multipart, Callback<UploadResponse> callback);


    @Multipart
    @POST("/datasync/uploadImageInVillageProfileInActivityTracker")
    void uploadImageVillageProfSurvey(@Part("serverId") String serverId,
                     @Part("mobileId") String mobileId,
                     @Part("type") String type,
                     @Part("photo") TypedFile multipart, Callback<UploadResponse> callback);

    @Multipart
    @POST("/datasync/uploadImageInFarmerSegmentationInActivityTracker")
    void uploadImageFarmerSegmentation(@Part("serverId") String serverId,
                     @Part("mobileId") String mobileId,
                     @Part("type") String type,
                     @Part("photo") TypedFile multipart, Callback<UploadResponse> callback);

    @POST("/datasync/getVillageProfileDataOfMDRInPHISalesEmpApp")
    void getVillageProfiles(@Body String jsonData, Callback<UploadedVillageListRefreshRes> callback);

    @POST("/datasync/getFarmerSegmentationDetailsByMobileNumberInActivityTracker")
    void getFarmerSegmentation(@Body FarmerSegmentationRequestDTO jsonData, Callback<FarmerSegmentationResponse> callback);

    @POST("/datasync/getFarmerSegmentationDairyDevDetailsByMobileNumberInActivityTracker")
    void getFarmerSegmentationNestle(@Body FarmerSegmentationRequestDTO jsonData, Callback<FarmerSegmentationNestleResponse> callback);

    @POST("/datasync/verifyFarmerSegmentationOTPByMobileNumberInActivityTracker")
    void getSubmitDetails(@Body FarmerSegmentationRequestDTO jsonData, Callback<OTPFarmerSegmentationResponse> callback);

    @POST("/datasync/resendOTPInFarmerSegmentationByMobileNumberInActivityTracker")
    void getResendOTP(@Body FarmerSegmentationRequestDTO jsonData, Callback<OTP_FS_Response> callback);

}