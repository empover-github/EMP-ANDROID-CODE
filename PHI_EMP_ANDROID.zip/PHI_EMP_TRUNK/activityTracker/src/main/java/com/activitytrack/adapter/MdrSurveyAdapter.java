package com.activitytrack.adapter;


import android.content.Context;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.activitytrack.activity.R;
import com.activitytrack.dtos.NewMdrSurveyDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rambabu.a on 07-03-2018.
 */

public class MdrSurveyAdapter extends BaseAdapter {

    private List<NewMdrSurveyDTO> surveyListDTOs = new ArrayList<>();
    private Context context;
    private static LayoutInflater inflater = null;
    ;


    public MdrSurveyAdapter(Context context, List<NewMdrSurveyDTO> pravaktaFarmerDTOs) {
        this.surveyListDTOs = pravaktaFarmerDTOs;
        this.context = context;
        inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return surveyListDTOs.size();
    }

    @Override
    public Object getItem(int position) {

        return surveyListDTOs.get(position);
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.mdr_survey_list_item, null);
            holder = new ViewHolder();
            holder.mainLayout = (LinearLayout) convertView.findViewById(R.id.s_list_mainLayout);
            holder.tvFarmerName = (TextView) convertView.findViewById(R.id.s_list_farmerName);
            holder.tvFarmerMob = (TextView) convertView.findViewById(R.id.s_list_mobileNo);
            holder.tvNoOfAgriFamilies = (TextView) convertView.findViewById(R.id.s_list_noOfAgriFamilies);
            holder.tvTotalLandHolding = (TextView) convertView.findViewById(R.id.s_list_totalLand);
            holder.tvComapnyName = (TextView) convertView.findViewById(R.id.s_company_name);



            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        NewMdrSurveyDTO dto = (NewMdrSurveyDTO) getItem(position);
        if (dto != null) {

            holder.tvFarmerName.setText(dto.getFarmerName());
            holder.tvFarmerMob.setText(dto.getMobileNo());
            holder.tvNoOfAgriFamilies.setText("" + dto.getNoOfFamilies() + " " + context.getString(R.string.families));
            holder.tvTotalLandHolding.setText("" + dto.getTotalLand() + " " + context.getString(R.string.acre));
            holder.tvComapnyName.setText("" + dto.getHighestCompanyName() + " " + ":" + " " + Math.round(dto.getHighestCompanyPercentage()));
            holder.tvComapnyName.setText(holder.tvComapnyName.getText().toString() + "%");

            if (position % 2 == 1) {
                holder.mainLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.survey_yellow));
            } else {
                holder.mainLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.survey_blue));
            }
        }

        return convertView;
    }

    public static class ViewHolder {
        TextView tvFarmerName, tvFarmerMob, tvNoOfAgriFamilies, tvTotalLandHolding, tvComapnyName;
        LinearLayout mainLayout;
    }
}
