package com.activitytrack.daos;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.activitytrack.dtos.DTO;
import com.activitytrack.dtos.ThreeIDTO;
import com.activitytrack.utility.ATBuildLog;

import java.util.ArrayList;
import java.util.List;

public class ThreeIDAO  implements DAO{
	
	
	private final String TAG = "ThreeIDAO";
    private static ThreeIDAO threeIDAO;

    
    public static ThreeIDAO getInstance()
    {
        if (threeIDAO == null)
        {
        	threeIDAO = new ThreeIDAO();
        }
        
        return threeIDAO;
    }

    /**
     * delete the Data
     */
    @Override
    public boolean delete(DTO dtoObject, SQLiteDatabase dbObject)
    {
        return false;
    }

    /**
     * Gets the record from the database based on the value passed
     * 
     * @param columnName
     *            : Database column name
     * @param columnValue
     *            : Column Value
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecordInfoByValue(String columnName, String columnValue, SQLiteDatabase dbObject)
    {
        List<DTO> threeIInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
        	if(!(columnName != null && columnName.length() > 0))
        		columnName = "id";
        	
            cursor = dbObject.rawQuery("SELECT * FROM   THREE_I where "+columnName+"='"+columnValue+"' ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                	/*THREEI_ACTIVITY
                    id 
    	            retailerMobileNo
    	            retailersFirmName
    	            threeIPhaseNo     
                    date
                    location
                    isSync
                    uploadedDate
                    regionId 
                     */
                	ThreeIDTO dto = new ThreeIDTO();
                    
                	dto.setId(cursor.getLong(0));
                    dto.setRetailerMobileNo(cursor.getLong(1));
                    dto.setRetailersFirmName(cursor.getString(2));
                    dto.setThreeIPhaseNo(cursor.getInt(3));
                    dto.setDate(cursor.getString(4));
                    dto.setLocation(cursor.getString(5));
                    dto.setIsSync(cursor.getInt(6));
                    dto.setUploadedDate(cursor.getString(7));
                    dto.setRegionId(cursor.getLong(8));
                    
                    threeIInfo.add(dto);
                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return threeIInfo;
    }
    

    /**
     * Gets all the records from the database
     *
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     */
    @Override
    public List<DTO> getRecords(SQLiteDatabase dbObject)
    {
        List<DTO> threeIInfo = new ArrayList<DTO>();
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT * FROM THREE_I ", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                do
                {
                	ThreeIDTO dto = new ThreeIDTO();
                    
                	dto.setId(cursor.getLong(0));
                    dto.setRetailerMobileNo(cursor.getLong(1));
                    dto.setRetailersFirmName(cursor.getString(2));
                    dto.setThreeIPhaseNo(cursor.getInt(3));
                    dto.setDate(cursor.getString(4));
                    dto.setLocation(cursor.getString(5));
                    dto.setIsSync(cursor.getInt(6));
                    dto.setUploadedDate(cursor.getString(7));
                    dto.setRegionId(cursor.getLong(8));

                    threeIInfo.add(dto);

                } while (cursor.moveToNext());
            } 
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return threeIInfo;
    }


    public List<ThreeIDTO> getRecordsForUpload(SQLiteDatabase dbObject)
    {
        List<ThreeIDTO>  threeIInfo = new ArrayList<ThreeIDTO>();
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT * FROM  THREE_I where isSync = 1", null);
            if (cursor.getCount() > 0)
            {

                cursor.moveToFirst();
                do
                {
                	ThreeIDTO dto = new ThreeIDTO();

                	dto.setId(cursor.getLong(0));
                    dto.setRetailerMobileNo(cursor.getLong(1));
                    dto.setRetailersFirmName(cursor.getString(2));
                    dto.setThreeIPhaseNo(cursor.getInt(3));
                    dto.setDate(cursor.getString(4));
                    dto.setLocation(cursor.getString(5));
                    dto.setIsSync(cursor.getInt(6));
                    dto.setUploadedDate(cursor.getString(7));
                    dto.setRegionId(cursor.getLong(8));

                    threeIInfo.add(dto);

                } while (cursor.moveToNext());
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return  threeIInfo;
    }

    /**
     * Inserts the data in the SQLite database
     *
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @param dtoObject
     *            : DTO object is passed
     */
    @Override
    public boolean insert(DTO dtoObject, SQLiteDatabase dbObject)
    {
        try
        {
        	ThreeIDTO dto = (ThreeIDTO) dtoObject;

            ContentValues cValues = new ContentValues();

            /*THREEI_ACTIVITY
            id
            retailerMobileNo
            retailersFirmName
            threeIPhaseNo
            date
            location
            isSync
            uploadedDate
            regionId
             */

            cValues.put("retailerMobileNo", dto.getRetailerMobileNo());
            cValues.put("retailersFirmName", dto.getRetailersFirmName());
            cValues.put("threeIPhaseNo", dto.getThreeIPhaseNo());
            cValues.put("date",dto.getDate());
            cValues.put("location", dto.getLocation());
            cValues.put("isSync", dto.getIsSync());
            cValues.put("uploadedDate",dto.getUploadedDate());
            cValues.put("regionId",dto.getRegionId());

            dbObject.insert("THREE_I", null, cValues);
            return true;
        } catch (SQLException e)
        {
            ATBuildLog.e(TAG + "insert()", e.getMessage());
            return false;
        } finally
        {
            dbObject.close();
        }

    }

    /**
     * Updates the data in the SQLite
     *
     * @param dtoObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is updated
     */
    @Override
    public boolean update(DTO dtoObject, SQLiteDatabase dbObject)
    {
        try
        {

        	ThreeIDTO dto = (ThreeIDTO) dtoObject;

        	ContentValues cValues = new ContentValues();


        	if(dto.getRetailerMobileNo()!=0)
        		cValues.put("retailerMobileNo",dto.getRetailerMobileNo());

        	if(dto.getRetailersFirmName()!= null)
        		cValues.put("retailersFirmName",dto.getRetailersFirmName());

        	if(dto.getThreeIPhaseNo()!=0)
        		cValues.put("threeIPhaseNo",dto.getThreeIPhaseNo());

        	if(dto.getDate()!=null)
        	   cValues.put("date",dto.getDate());

        	if(dto.getLocation() != null)
        		cValues.put("location", dto.getLocation());

            cValues.put("isSync", dto.getIsSync());

            if(dto.getUploadedDate()!=null)
            cValues.put("uploadedDate",dto.getUploadedDate());

            if(dto.getRegionId()!=0)
            	  cValues.put("regionId",dto.getRegionId());

            dbObject.update("THREE_I", cValues, "id='" +dto.getId()+"' ", null);

            return true;
        } catch (SQLException e)
        {
            ATBuildLog.e(TAG + "update()", e.getMessage());
            e.printStackTrace();
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally
        {
            dbObject.close();
        }
        return false;
    }

    /**
     * Deletes all the table Data from SQLite
     *
     * @param dbObject
     *            : DTO object is passed
     * @param dbObject
     *            : Exposes methods to manage a SQLite database Object
     * @return boolean : True if data is to be deleted
     */
    public boolean deleteTableData(SQLiteDatabase dbObject)
    {
        try
        {
            dbObject.compileStatement("DELETE FROM THREE_I").execute();
            return true;
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "deleteData()", e.getMessage());
        }
        return false;
    }

    public boolean deleteDataById(String id, SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("delete from THREE_I where id='"+id+"'");
			return true;
		}catch(Exception e)
		{
            ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally

		{

		dbObject.close();

		}
		return false;
	}
    public boolean deleteDataByDate(String date, SQLiteDatabase dbObject) {
		try
		{
			dbObject.execSQL("delete from THREE_I where uploadedDate < '"+date+"' and isSync = '0'");
			return true;
		}catch(Exception e)
		{
            ATBuildLog.e(TAG +"delete",e.getMessage());
		}finally

		{

		dbObject.close();

		}
		return false;
	}

    public boolean isDataAvailForUpload(SQLiteDatabase dbObject)
    {
        Cursor cursor = null;
        try
        {
            cursor = dbObject.rawQuery("SELECT count(id) FROM THREE_I where isSync = 1", null);
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                return cursor.getLong(0) > 0;
            }
        } catch (Exception e)
        {
            ATBuildLog.e(TAG + "getRecords()", e.getMessage());
        } finally
        {
            if (cursor != null && !cursor.isClosed())
            {
                cursor.close();
            }
            dbObject.close();
        }

        return  false;
    }
}
